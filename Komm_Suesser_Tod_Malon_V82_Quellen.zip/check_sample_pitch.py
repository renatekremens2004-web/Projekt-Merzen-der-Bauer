from pathlib import Path
import subprocess,wave,numpy as np,json
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
def fundamental(path,root):
 with wave.open(str(path))as f:rate=f.getframerate();y=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2').astype(float)
 y=y[len(y)//4:];n=2**int(np.ceil(np.log2(len(y)*8)));sp=np.abs(np.fft.rfft(y*np.hanning(len(y)),n=n));hz=np.fft.rfftfreq(n,1/rate);target=440*2**((root-69)/12);ok=np.where((hz>target*2**(-1/12))&(hz<target*2**(1/12)))[0];k=ok[np.argmax(sp[ok])];l=np.log(np.maximum(sp[k-1:k+2],1e-9));d=.5*(l[0]-l[2])/(l[0]-2*l[1]+l[2]);return (k+d)*rate/n
checks=[]
for n,factor,name,root in [(354,2,'ORGAN_HIGH',60),(374,2,'STRINGS_HIGH',68),(382,4,'HORN_HIGH',45),(364,2,'FLUTE_HIGH',60),(366,2,'BASSOON_HIGH',40)]:
 src=O/f'extracted/pal-1.0/assets/audio/samples/SampleBank_0/Sample{n}.wav';aifc=O/f'build/pal-1.0/assets/audio/samples/SampleBank_0/MalonV82_{name}.aifc';out=W/f'check-{name}.wav'
 subprocess.run([str(O/'tools/audio/sampleconv/sampleconv'),'pcm16',str(aifc),str(out)],check=True)
 a=fundamental(src,root);b=fundamental(out,root+round(12*np.log2(factor)));error=1200*np.log2(b/(a*factor));checks.append(dict(name=name,original_fundamental_hz=a,new_fundamental_hz=b,expected_factor=factor,additional_tuning_error_cents=error));assert abs(error)<5,(name,error)
(W/'sample-pitch-check.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))

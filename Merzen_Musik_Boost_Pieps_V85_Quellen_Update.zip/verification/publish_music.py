from pathlib import Path
import json
import publish_ram_artifacts as pub
W=Path(__file__).resolve().parent;p=Path('/tmp/player-music-v85/Komm_Suesser_Tod_Malon_5m15_V85.mp3');r=pub.publish({p.name:p.read_bytes()},'V85 music preview: raise quiet supporting voices, preserve piano and Malon, fade by5m15');(W/'public-music.json').write_text(json.dumps(r,indent=2));print('MUSIC_PUBLIC',r)

static void capture_render(void){}
static void onframe(unsigned f){
 static unsigned seen=0,first=0,help=0;unsigned v=0;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 unsigned room=DebugMemRead8(play+0x11cbc),bird=target(0x72,0x7501),m=play+0x20d8,text=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),c=0,visible=0;
 for(unsigned a=r32(play+0x1c34+5*8),n=0;a>=0x80000000&&a<0x80400000&&n<70;a=r32(a+0x124),n++)if(DebugMemRead16(a)==0x25&&r32(a+0x130)&&DebugMemRead16(a+0x3ec)==5){c++;if(DebugMemRead8(a+0x3f4)==255)visible++;}
 if(f>390&&(room!=3||rf(player+0x2c)>-1600)){v=0x20|0x40000000;if(f%20<2)v|=0x80;}
 if(text==0x7239&&mode)help=1;
 if(room==3&&bird&&c==2){seen=1;if(!first)first=f;}
 if(f>=430&&f<=510&&f%5==0){printf("DENIED f=%u ovl=%u inst=%u last=%x\n",f,DebugMemRead16(DENIED_OVERLAY),DebugMemRead16(DENIED_INSTANCE),DebugMemRead16(DENIED_LAST));if(f==470||f==500)for(unsigned j=0;j<0x1d7;j++){unsigned p=overlays+j*0x20;if(r32(p+0x10))printf("OVERLAY id=%x size=%u users=%u\n",j,r32(p+0xc)-r32(p+8),DebugMemRead8(p+0x1e));}}
 if(f%30==0){printf("WALK f=%u room=%u player=%.1f %.1f %.1f bird=%x lizalfos=%u help=%u text=%x sw=%x clear=%x\n",f,room,rf(player+0x24),rf(player+0x28),rf(player+0x2c),bird,c,help,text,r32(play+0x1d28),r32(play+0x1d3c));}
 if(first&&f>first+170){bank();CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);need(help,"Pieps help camera runs after normal door transition");need(visible==2,"both Lizalfos become visible and fight after intro");puts("PIEPS_NORMAL_DOOR_ENTRY_PASSED two Lizalfos, cage, help cutscene");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(f==390)photo(3560,270,-1010,3560,140,-1290);
 if(buttons)buttons(v);if(f>1200){bank();need(seen,"normal entry must load cage and both lower Lizalfos");exit(96);}
}

from pathlib import Path
import subprocess,json,hashlib
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer')
with (W/'finish-sources.log').open('w')as log:
 subprocess.run(['/workspace/toolchain/venv/bin/python3',str(R/'tools/build_debug_version.py'),str(O),'--restore'],check=True,stdout=log,stderr=subprocess.STDOUT)
 objects=['src/code/graph.o','src/code/z_sram.o','src/overlays/gamestates/ovl_select/z_select.o','src/overlays/misc/ovl_kaleido_scope/z_kaleido_scope.o','src/overlays/misc/ovl_kaleido_scope/z_kaleido_debug.o']
 subprocess.run(['make','-s','-j4','VERSION=pal-1.0','COMPARE=0','PYTHON=/workspace/toolchain/venv/bin/python3',*['build/pal-1.0/'+r for r in objects]],cwd=O,check=True,stdout=log,stderr=subprocess.STDOUT)
rels=[str(p.relative_to(W/'original'))for p in(W/'original').rglob('*')if p.is_file()];report={rel:dict(before=hashlib.sha256((W/'original'/rel).read_bytes()).hexdigest(),after=hashlib.sha256((O/rel).read_bytes()).hexdigest())for rel in rels};(W/'source-changes.json').write_text(json.dumps(report,indent=2));print('NORMAL_PRODUCTION_SOURCES_RESTORED_GAME_CHANGES_RETAINED')

from pathlib import Path
import wave,json,numpy as np
W=Path('/tmp/player-music-v85');raw=np.fromfile(W/'master-5m15.pcm',dtype='<i2').reshape(-1,2)
with wave.open(str(W/'decoded-title.wav'),'rb')as f:d=np.frombuffer(f.readframes(f.getnframes()),dtype='<i2')
n=min(len(d),len(raw));a=raw[:n,0].astype(float);b=d[:n].astype(float);noise=np.sqrt(np.mean((a-b)**2));rms=np.sqrt(np.mean(a*a));r=dict(peak=int(abs(raw.astype(np.int32)).max()),clipped_samples=int((abs(raw.astype(np.int32))>=32767).sum()),decoded_snr_db=float(20*np.log10(rms/noise)),seconds=len(raw)/31995,final_frame=raw[-1].tolist(),gain=1.6,foreground_levels_unchanged=True)
Path('/workspace/player-music-v85/audio-verification.json').write_text(json.dumps(r,indent=2));print(r)

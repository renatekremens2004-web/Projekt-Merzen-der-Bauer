from pathlib import Path
import os,sys,json,subprocess,struct,re,runpy
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];fd=int(rom.rsplit('/',1)[1]);case=(W/'qa-case.txt').read_text().strip();sy=json.loads((W/f'symbols-{mode}.json').read_text());alls=json.loads((W/f'all-symbols-{mode}.json').read_text());sy['gKaleidoMgrOverlayTable']=alls['gKaleidoMgrOverlayTable'];sy['gActorLastDeniedV68']=alls['gActorLastDeniedV68']
if case=='batch':
 cases=['block-pull-normal','block-pull-fast','crate-fast']if mode=='normal'else['water','sword','block-fast','crate-fast','walk-cage']
 for sub in cases:
  (W/'qa-case.txt').write_text(sub);subprocess.run([sys.executable,__file__,rom,mode],pass_fds=(fd,),check=True)
 (W/f'batch-{mode}-passed.json').write_text(json.dumps(cases));sys.exit(0)
if case in ['publish','pieps','collapse','menu']:
 runpy.run_path(str(W/(case+'_qa.py' if case!='publish'else'deliver.py')),run_name='__main__');sys.exit(0)
base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text();old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text())
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=(W/('walk_body.c'if case=='walk-cage'else'block_body.c'if case.startswith('block')or case.startswith('crate')else'player_body.c')).read_text()
for m,n in [('DENIED_OVERLAY','gActorOverlayDeniedV68'),('DENIED_INSTANCE','gActorInstanceDeniedV68'),('DENIED_LAST','gActorLastDeniedV68'),('KALEIDO','gKaleidoMgrOverlayTable'),('PLAYER_VRAM','_ovl_player_actorSegmentStart'),('SLASH','Player_Action_808502D0'),('AUDIO_CONTEXT','gAudioCtx')]:body=body.replace(m,hex(sy[n]))
runner=W/f'qa-{mode}-{case}';c=runner.with_suffix('.c');c.write_text(base[:a]+body+base[b:]);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/zoras-erwachsen/boots-water.save'if 'water'in case or 'sword'in case else'/workspace/zoras-erwachsen/boots-land.save').read_bytes());struct.pack_into('>H',q,0xf30,(struct.unpack_from('>H',q,0xf30)[0]|0x1000)&~0x800)
# Correct equipped sword and all native owned boots, retain normal hazards.
q[0x68]=0x3c;struct.pack_into('>H',q,0x70,(struct.unpack_from('>H',q,0x70)[0]&0x0ff0)|0x1002);struct.pack_into('>H',q,0x9c,0x7777);q[0x1409]=1
if case.startswith('block')or case.startswith('crate'):
 q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0,1,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,-1365,-880,1290,-32768,0xdff,0,5);struct.pack_into('>H',q,0xf30,0x1000);struct.pack_into('>I',q,0xd4,0);q[0x1409]=1
if case.startswith('crate'):
 e=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\(ENTR_LON_LON_BUILDINGS_1,',(O/'include/tables/entrance_table.h').read_text())[1],16);struct.pack_into('>I',q,0,e);struct.pack_into('>fffhHhB',q,0x1368,-221,20,-50,-16384,0xdff,e,0)
if case=='walk-cage':
 q=bytearray(Path('/workspace/pieps-v79/cage-visual.save').read_bytes());struct.pack_into('>fffhHhB',q,0x1368,3560,100,-1170,-32768,0xdff,struct.unpack_from('>I',q)[0],1)
fixture=W/(case+'.save');fixture.write_bytes(q)
env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null');logfile=W/f'{mode}-{case}.log'
with logfile.open('w')as log:p=subprocess.run([str(runner),rom,'v85-'+mode+'-'+case+'-direct','1800','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(fixture)],pass_fds=(fd,),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240)
assert p.returncode==0,(p.returncode,logfile.read_text()[-2000:]);print('PLAYER_QA_FINISHED',mode,case,flush=True)

from pathlib import Path
import json,struct,subprocess,concurrent.futures,xml.etree.ElementTree as E,shutil,numpy as np
W=Path(__file__).resolve().parent;M=Path('/tmp/malon-mix-v85');O=Path('/workspace/oot-burns-pal');B=W/'original'

def backup(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(O/rel,p)
 return p
rateinfo=json.loads((M/'recording.json').read_text());rate=rateinfo['rate'];first=rateinfo['first_sample'];count=round(315*rate)
raw=np.memmap(M/'native-full.pcm',dtype='<i2',mode='r').reshape(-1,2);audio=np.array(raw[first:first+count],dtype=float);assert len(audio)==count
peak=float(np.max(abs(audio)));gain=1.6;assert peak*gain<32767,('native peak headroom',peak);audio*=gain
# A fifteen-second musical fade; fully silent by5:15. Preserve the relative mix.
n=round(15*rate);audio[-n:]*=np.cos(np.linspace(0,np.pi/2,n))[:,None]**2;audio[-1]=0
native=np.round(audio).clip(-32767,32767).astype('<i2');(W/'master-5m15.pcm').write_bytes(native.tobytes())
entry=round(25.25*rate);collapse=native[entry:].astype(float);fade=round(1.25*rate);collapse[:fade]*=np.sin(np.linspace(0,np.pi/2,fade))[:,None]**2;collapse[0]=0;collapse=np.round(collapse).astype('<i2')
# MIDI orchestration was rendered by OoT; only two streaming ADPCM voices are
# required in the shipping game. No private orchestra heap/spec is carried over.
samples=[]
def chunk(k,d):return k+struct.pack('<I',len(d))+d+(b'\0'if len(d)&1 else b'')
for ix,(tag,data)in enumerate([('TITLE_L',native[:,0]),('TITLE_R',native[:,1]),('COLLAPSE_L',collapse[:,0]),('COLLAPSE_R',collapse[:,1])]):
 filename='MalonV84_'+tag;wav=W/(filename+'.wav');aifc=W/(filename+'.aifc');N=len(data)
 fmt=struct.pack('<HHIIHH',1,1,32000,64000,2,16);inst=bytes([60,0,0,0,127,0,127,0]);smpl=struct.pack('<9I',0,0,31250,60,0,0,0,1,0)+struct.pack('<6I',0,0,0,N-1,0,0xFFFFFFFF)
 payload=b'WAVE'+chunk(b'fmt ',fmt)+chunk(b'fact',struct.pack('<I',N))+chunk(b'data',data.tobytes())+chunk(b'inst',inst)+chunk(b'smpl',smpl);wav.write_bytes(b'RIFF'+struct.pack('<I',len(payload))+payload)
 for ext,target in [('wav',wav),('aifc',aifc)]:
  p=O/('assets'if ext=='wav'else'build/pal-1.0/assets')/'audio/samples/SampleBank_0'/(filename+'.'+ext)
  assert not p.exists() or p.is_symlink(),p
  if p.is_symlink():p.unlink()
  p.symlink_to(target)
 samples.append(dict(index=1400+ix,name=f'SAMPLE_0_{1400+ix}',filename=filename,wav=str(wav),aifc=str(aifc),frames=N))
def encode(s):
 log=W/(s['filename']+'-encode.log')
 with log.open('w')as f:subprocess.run([str(O/'tools/audio/sampleconv/sampleconv'),'vadpcm',s['wav'],s['aifc']],stdout=f,stderr=subprocess.STDOUT,check=True)
 return Path(s['aifc']).stat().st_size
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:sizes=list(pool.map(encode,samples))
for s,size in zip(samples,sizes):s['encoded_bytes']=size
report=dict(source_native_recording=rateinfo,rate=rate,seconds=315,fade_start=300,fade_end=315,collapse_entry=25.25,collapse_fade_in=1.25,gain=gain,source_peak=peak,peak=int(np.max(np.abs(native.astype(np.int32)))),samples=samples,shipping_audio_heap=0x38000,shipping_music_notes=2)
(W/'stream-assets.json').write_text(json.dumps(report,indent=2));print('STREAM_ASSETS_READY',sum(sizes),'bytes',flush=True)

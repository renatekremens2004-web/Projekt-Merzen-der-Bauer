from pathlib import Path
import os,sys,subprocess,json,hashlib,io,zipfile
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];romfd=int(rom.rsplit('/',1)[1]);base=O/'baseroms/pal-1.0/baserom.z64'
assert hashlib.md5(base.read_bytes()).hexdigest()=='e040de91a74b61e3201db0e2323f768a'
fd=os.memfd_create('v85-'+mode+'-bps');out='/proc/self/fd/'+str(fd);fds=(romfd,fd)
subprocess.run(['/workspace/toolchain/Flips/flips','--create','--bps',str(base),rom,out],pass_fds=fds,check=True)
js="const fs=require('fs'),c=require('crypto');global.BinFile=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/modules/BinFile');const p=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/RomPatcher');const actual=Buffer.from(p.applyPatch(new BinFile(process.argv[1]),p.parsePatchFile(new BinFile(process.argv[2])),{requireValidation:true})._u8array);const expected=fs.readFileSync(process.argv[3]);if(!actual.equals(expected))throw Error('Mismatch');console.log(c.createHash('sha256').update(actual).digest('hex'));"
sha=subprocess.check_output(['node','-e',js,str(base),out,rom],pass_fds=fds,text=True).strip();patch=Path(out).read_bytes();name='Mr_Burns_Mr_Bean_DE_PAL10_'+('DEBUG_'if mode=='debug'else'')+'Musik_Boost_Pieps_V85.bps';proof=dict(mode=mode,file=name,rom_sha256=sha,patch_sha256=hashlib.sha256(patch).hexdigest(),source_md5='e040de91a74b61e3201db0e2323f768a',byte_identical_after_independent_apply=True,patch_bytes=len(patch),rom_bytes=Path(rom).stat().st_size);(W/f'patch-{mode}-verification.json').write_text(json.dumps(proof,indent=2));files={name:patch};prefix=''
if mode=='normal':
 guide='''V85 — Begleitstimmen, Speed-Boost, Unterwasserschwert und Pieps

Kumulativer BPS-Patch mit allen bisherigen Inhalten einschließlich V84. Jeweils auf eine SAUBERE OoT-PAL-1.0-ROM anwenden. Basis-MD5 e040de91a74b61e3201db0e2323f768a. Nicht über eine bereits gepatchte ROM patchen. Spielstände können weiterverwendet werden. Normale und DEBUG-Ausgabe haben denselben Spielinhalt.

MUSIK
Die leisen Holzbläser, Harfe und Gitarren-Gegenstimmen sind nochmals ungefähr 2dB präsenter. Die Orgel während Malons Gesang wurde zusätzlich rund 1.9dB angehoben; im späteren Abschnitt sind die begleitenden Streicher und Chöre ebenfalls deutlicher. Klavier, Malon, Bass, Schlagzeug und bereits laute Stimmen wurden nicht abgesenkt. Keine neuen Noten, Transpositionen oder harmonischen Änderungen. Native Aufnahme erneut erstellt, kein Clipping; Peak 30782/32767 bei unverändertem Gesamtgain1.6. 5:00–5:15 Ausblende, Titel-Loop, Einsturz-Einstieg25.25s und harter Stopp bei Kontrollrückgabe bleiben bestehen. Weiterhin zwei native ADPCM-Streaming-Stimmen, Original-Audioheap0x38000; privates36-Stimmen-Aufnahmesetup wird nicht ins Spiel übernommen.

STEUERUNG
Der bestehende beim Kokiri freigeschaltete D-Links-Schalter beschleunigt jetzt auch das Gehen mit Eisenstiefeln, an Land und am Unterwasserboden. Maximalgeschwindigkeit jeweils1.5x; Ausschalten stellt die ursprünglichen Werte wieder her. Gewöhnliche Schiebeblöcke und hölzerne Milchkisten bewegen sich beim Schieben/Ziehen ebenfalls schneller. Die ursprüngliche20-Einheiten-Schrittweite, Wand-/Bodenprüfungen, Rätselschalter und Kollisionslogik bleiben erhalten. Rutschende Eisblöcke und andere gesonderte Mechanismen werden nicht global beschleunigt.

Schwerter können unter Wasser gezogen und eingesetzt werden, sowohl mit Eisenstiefeln am Boden als auch beim Schwimmen. Native Schwertanimationen und Trefferflächen werden verwendet; beim schwimmenden Schlag bleibt der normale Auftrieb aktiv, danach wird wieder geschwommen. Wassergefahren, Sauerstoff und die Beschränkungen anderer Gegenstände bleiben bestehen.

PIEPS
Der reguläre Türübergang in den unteren ersten Echsenraum wurde als gesonderter Test ergänzt. Während alter und neuer Raum gleichzeitig geladen waren, konnte Pieps'32kB-Overlay nicht reserviert werden. Ein direkter Start im Raum hatte diesen Fehler verdeckt. Der Käfigauftritt wird jetzt erst nach dem Freigeben des vorherigen Raums geladen. Es wird kein zusätzlicher Actor und kein Object-Slot benötigt; nur eine16-Byte-Kopie des wartenden Actor-Eintrags mit einem flüchtigen Raum-Marker. Bei Raum-/Szenenwechsel wird der Auftrag verworfen. Keine neuen Spielstandflags. Durch dieselbe Tür wurden beide Echsen, Käfig und Hilfe-Kamerafahrt mit4MiB und ohne abgelehnte Actor-/Object-Ladevorgänge geprüft. Der Boss-Eingriff setzt weiterhin das abgeschlossene Befreiungsgespräch voraus; direktes Debug-Warpen zum Boss rettet Pieps nicht automatisch.

PRÜFUNG
Native Engine mit4MiB, keine Expansion-Pak-Pflicht. Eisenstiefel normal/Boost/normal: an Land3/4.5/3, unter Wasser5.389/8.083/5.389. Schieben und Ziehen: Originalblockspitze2, Boostspitze3, weiterhin exakte20-Einheiten-Schritte. Unterwasserschwert am Boden und beim Schwimmen mit aktiven Trefferflächen, anschließend normale Bewegung. Pieps' Türübergang, Befreiung sowie Boss-Varianten mit/ohne Rettung geprüft. Normal und DEBUG separat gebaut; beide BPS unabhängig mit RomPatcher.js angewendet und bytegleich mit der gebauten ROM verglichen. Das ersetzt keinen vollständigen Spieldurchlauf.

QUELLEN
Das Quellen-Update enthält die kumulativen geänderten Produktionsdateien aus V84 und V85 sowie die vier bereits codierten Musik-Assets. Auf die bisherigen V79-Quellen anwendbar. Nach Entpacken:
python3 apply_sources_v85.py /PFAD/ZUR/oot-burns-pal
Danach mit der vorhandenen Toolchain PAL1.0 bauen. Normale/DEBUG-Ausgabe weiterhin über tools/build_debug_version.py. Keine Basis-ROM enthalten.
'''
 files['V85_Musik_Boost_Pieps_Hinweise.txt']=guide.encode()
 rels=set()
 for origin in [Path('/workspace/title-collapse-v84/original'),W/'original']:
  rels.update(str(p.relative_to(origin))for p in origin.rglob('*')if p.is_file())
 rels.update(['assets/audio/soundfonts/Soundfont_40.xml','assets/audio/sequences/seq_112.seq','assets/audio/sequences/seq_113.seq','include/fast_run_v66.h'])
 rels.update(str(p.relative_to(O))for p in(O/'assets/audio/samples/SampleBank_0').glob('MalonV84_*.aifc'))
 apply='''from pathlib import Path
import sys,shutil
root=Path(__file__).resolve().parent;target=Path(sys.argv[1]).resolve()
assert (target/'Makefile').is_file(),target
for p in (root/'production').rglob('*'):
 if p.is_file():
  q=target/p.relative_to(root/'production');q.parent.mkdir(parents=True,exist_ok=True)
  if q.is_symlink():q.unlink()
  shutil.copy2(p,q)
print('V85 cumulative production files and native music assets installed.')
'''
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  z.writestr('LIESMICH_V85.txt',guide);z.writestr('apply_sources_v85.py',apply)
  for rel in sorted(rels):z.write(O/rel,'production/'+rel)
  for folder,prefix2 in [(W,'verification'),(W/'music-arrangement','music-arrangement')]:
   for p in folder.iterdir():
    if p.is_file() and p.suffix in('.py','.c','.json','.log','.seq','.xml') and p.stat().st_size<1500000 and not p.name.startswith(('build-owner','objects-','qa-normal-','qa-debug-')):z.write(p,prefix2+'/'+p.name)
 files['Merzen_Musik_Boost_Pieps_V85_Quellen_Update.zip']=buf.getvalue()
 prefix='''## V85 — Begleitstimmen, Speed-Boost, Unterwasserschwert und Pieps

Leise Musikstimmen erneut angehoben, Vordergrund und Malon beibehalten. D-Links beschleunigt jetzt Eisenstiefel sowie das Schieben und Ziehen von Blöcken und Milchkisten. Schwertbenutzung unter Wasser am Boden und beim Schwimmen. Pieps' echter Ladefehler am Türübergang wurde reproduziert und behoben. Weiterhin4MiB, keine Änderungen am Spielstandformat.

- [Normaler kumulativer BPS-Patch](Mr_Burns_Mr_Bean_DE_PAL10_Musik_Boost_Pieps_V85.bps)
- [DEBUG-BPS-Patch](Mr_Burns_Mr_Bean_DE_PAL10_DEBUG_Musik_Boost_Pieps_V85.bps)
- [Neue Musik-Hörprobe](Komm_Suesser_Tod_Malon_5m15_V85.mp3)
- [Hinweise und Prüfungen](V85_Musik_Boost_Pieps_Hinweise.txt)
- [Quellen-Update](Merzen_Musik_Boost_Pieps_V85_Quellen_Update.zip)

BPS jeweils auf die saubere PAL1.0-Basis anwenden.

---

'''
import publish_ram_artifacts as pub
report=pub.publish(files,'V85 cumulative '+mode+' patch: stronger quiet accompaniment, iron-boot/push speed, underwater sword and deferred Pieps room entry',prefix);(W/f'public-{mode}.json').write_text(json.dumps(report,indent=2));print('PATCH_PUBLIC',mode,report,flush=True)

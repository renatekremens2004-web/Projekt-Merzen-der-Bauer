static void capture_render(void){}
static unsigned plfunc(unsigned v){return r32(KALEIDO+0x1c)+v-PLAYER_VRAM;}
static void onframe(unsigned f){
 static float speeds[3]={0};static unsigned cuts[2]={0},hits[2]={0};unsigned v=0;
 baseframe(f);if(f<340)return;findplay();if(!play||!player)return;
 unsigned flags=r32(player+0x66c),act=r32(player+0x664),m=play+0x20d8;
 int water=strstr(scenario,"water")!=NULL,sword=strstr(scenario,"sword")!=NULL;
 if(sword){
  if(f==390) v=4;
  if(f>=460&&f<560&&f%16<2)v=0x40;
  if(f==570)v=4;
  if(f==600)position(player,-195,650,810,0);
  if(f>=610&&f<710&&f%16<2)v=0x40;
  unsigned stage=f<570?0:1;
  if(act==plfunc(SLASH)&&flags&0x8000000){cuts[stage]++;if(DebugMemRead8(player+0x833))hits[stage]++;}
  if(f==500||f==650)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  if(f%25==0)printf("SWORD f=%u y=%.1f depth=%.1f bg=%x flags=%x boots=%u action=%x held=%d melee=%u B=%u cuts=%u,%u hits=%u,%u\n",f,rf(player+0x28),rf(player+0x84),DebugMemRead16(player+0x88),flags,DebugMemRead8(player+0x13f),act,(signed char)DebugMemRead8(player+0x141),DebugMemRead8(player+0x833),DebugMemRead8(savebase+0x13e2),cuts[0],cuts[1],hits[0],hits[1]);
  if(f>790){bank();need(cuts[0]>5&&hits[0]>0,"underwater iron-boots sword animation and active hitboxes");need(cuts[1]>5&&hits[1]>0,"swimming sword animation and active hitboxes");need(act!=plfunc(SLASH),"sword action ends and native swimming resumes");puts("PLAYER_SWORD_QA_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }else{
  if(f==390)v=4;
  if(f>=440&&f<680){unsigned stage=(f-440)/80,dt=(f-440)%80;
   if(dt==0){position(player,water?-195:-786,water?620:14,water?810:-431,0);}
   if(dt==1&&stage>0)v=2;
   if(dt>=10&&dt<40)v=0x40000000;
   if(dt>=15&&dt<40&&fabsf(rf(player+0x828))>speeds[stage])speeds[stage]=fabsf(rf(player+0x828));
   if(dt%20==0)printf("SPEED f=%u stage=%u speed=%.2f boots=%u bg=%x flags=%x xyz=%.1f %.1f %.1f\n",f,stage,rf(player+0x828),DebugMemRead8(player+0x13f),DebugMemRead16(player+0x88),flags,rf(player+0x24),rf(player+0x28),rf(player+0x2c));
  }
  if(f>700){bank();printf("SPEED_RESULT water=%d normal=%.3f fast=%.3f normal_again=%.3f\n",water,speeds[0],speeds[1],speeds[2]);need(speeds[0]>.5f,"native speed measured");need(speeds[1]>speeds[0]*1.3f,"D-left increases speed with iron boots");need(fabsf(speeds[2]-speeds[0])<.3f,"toggle restores normal speed");puts("PLAYER_SPEED_QA_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(buttons)buttons(v);if(f>1500)exit(96);
}

static void capture_render(void){}
static void onframe(unsigned f){
 static unsigned start=0,steps[2]={0},last=0,phase=0;static float oldx=0,oldz=0,maxspeed[2]={0};unsigned v=0;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;unsigned mm=DebugMemRead8(play+0x20d8+0xe304);if(mm){start=0;if(buttons)buttons(f%15<2?0x80:0);return;}int crate=strstr(scenario,"crate")!=NULL;unsigned b=actor(crate?0x107:0xff);if(crate&&phase)b=phase;else if(crate){for(unsigned a=r32(play+0x1c34+1*8),n=0;a>=0x80000000&&a<0x80400000&&n<80;a=r32(a+0x124),n++)if(DebugMemRead16(a)==0x107&&fabsf(rf(a+0x24)+270)<2&&fabsf(rf(a+0x2c)+50)<100)b=a;}if(crate)phase=b;if(!b){if(f%100==0)printf("NO_BLOCK scene=%x room=%u\n",DebugMemRead16(play+0xa4),DebugMemRead8(play+0x11cbc));if(f>550)exit(96);return;}
 if(!start){start=f;oldx=rf(b+0x24);oldz=rf(b+0x2c);position(player,crate?oldx+49:oldx,rf(b+0x28)+(crate?20:0),crate?oldz:oldz+49,crate?-16384:-32768);photo(crate?oldx+300:oldx,rf(b+0x28)+180,crate?oldz:oldz+300,oldx,rf(b+0x28)+30,oldz);}
 unsigned dt=f-start;
 
 if((dt==10||dt==30||dt==40)&&strstr(scenario,"fast")&&!(DebugMemRead16(savebase+0xf30)&0x800))v=2;
 if(dt>=20)v|=0x80;if(dt>=50){v|=0x40000000;if(dt>=120&&(strstr(scenario,"pull")||crate))v=(v&~0xff000000)|0xc0000000;}
 if(dt>30&&rf(b+0x164)>maxspeed[0])maxspeed[0]=rf(b+0x164);if(rf(b+0x16c)<0&&rf(b+0x164)>maxspeed[1])maxspeed[1]=rf(b+0x164);
 if(dt%10==0)printf("BOOST flags=%x wall=%u blockBg=%u force=%.2f\n",DebugMemRead16(savebase+0xf30),DebugMemRead8(player+0x7c),r32(b+0x13c),rf(b+0x140));if(dt%10==0)printf("BLOCK dt=%u b=%.1f %.1f dist=%.2f speed=%.2f p=%.1f %.1f wall=%u flags=%x action=%x\n",dt,rf(b+0x24),rf(b+0x2c),rf(b+0x168),rf(b+0x164),rf(player+0x24),rf(player+0x2c),DebugMemRead16(player+0x8c),r32(player+0x670),r32(player+0x664));
 if(dt==150)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
 if(dt>240){bank();printf("BLOCK_RESULT fast=%d dx=%.2f dz=%.2f speed=%.3f\n",strstr(scenario,"fast")!=NULL,rf(b+0x24)-oldx,rf(b+0x2c)-oldz,maxspeed[0]);printf("PULL_RESULT peak=%.3f\n",maxspeed[1]);need(maxspeed[(strstr(scenario,"pull")||crate)?1:0]>(strstr(scenario,"fast")?2.8f:1.8f),"native block movement observed");need(fabsf(rf(player+0x28)-rf(b+0x28))<50,"player remains on floor");puts("PLAYER_BLOCK_QA_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(buttons)buttons(v);
}

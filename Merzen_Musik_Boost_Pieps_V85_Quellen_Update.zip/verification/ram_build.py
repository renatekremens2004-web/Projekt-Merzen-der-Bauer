"""Regular PAL partial links and relocations, with temporary ELF files held in RAM."""
from pathlib import Path
import os,sys,re,json,subprocess,struct,hashlib,importlib.util,time
import ipl3checksum
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer');sys.path.insert(0,str(O/'tools'));import compress
held=[];state={}
def fd(name):
 n=os.memfd_create(name);held.append(n);return n
def path(n):return '/proc/self/fd/'+str(n)
def run(args,**kw):return subprocess.run(args,check=True,**kw)
def build(mode):
 run([sys.executable,str(R/'tools/build_debug_version.py'),str(O),*(['--restore']if mode=='normal'else[])])
 names=['ovl_Bg_Spot15_Rrbox','ovl_player_actor','ovl_Obj_Oshihiki','ovl_Boss_Ganon2','ganon_demo_room_0','boot','buffers','code','ovl_select','ovl_kaleido_scope','ovl_Sonichu_V70','hakaana_ouke_room_2','ovl_En_Ko','ovl_Demo_Ec','ovl_En_Go2','spot00_room_0','spot20_room_0','spot18_room_1','ovl_En_Bird','ovl_Boss_Dodongo','ddan_room_3','ovl_Elf_Msg2','nes_message_data_static','ger_message_data_static','fra_message_data_static']
 objects=set()
 for n in names:
  s=(O/'build/pal-1.0/segments'/(n+'.ld')).read_text();objects.update(re.findall(r'\b(build/[^\s()]+\.o)\(',s))
 with(W/f'objects-{mode}.log').open('w')as log:run(['make','-j4','VERSION=pal-1.0','COMPARE=0','PYTHON='+sys.executable,*sorted(objects)],cwd=O,stdout=log,stderr=subprocess.STDOUT)
 replacements={};fds=[]
 for n in names:
  p=fd(n+'-partial');fds.append(p);run(['mips-linux-gnu-ld','-r','-T','build/pal-1.0/segments/'+n+'.ld','-o',path(p)],cwd=O,pass_fds=(p,));replacements['build/pal-1.0/segments/'+n+'.plf']=path(p)
  if n.startswith('ovl_'):
   s=fd(n+'-reloc-source');o=fd(n+'-reloc-object');fds +=[s,o]
   run(['tools/fado/fado.elf',path(p),'-n',n,'-o',path(s)],cwd=O,pass_fds=(p,s))
   run(['mips-linux-gnu-as','-march=vr4300','-32','-no-pad-sections','-Iinclude','-Iextracted/pal-1.0',path(s),'-o',path(o)],cwd=O,pass_fds=(s,o));replacements['build/pal-1.0/segments/'+n+'.reloc.o']=path(o)
 script=(O/'build/pal-1.0/oot-pal-1.0.ld').read_text()
 for a,b in replacements.items():script=script.replace(a,b)
 lds=fd(mode+'-main-script');os.write(lds,script.encode());fds.append(lds);elf=fd(mode+'-main-elf');fds.append(elf)
 with(W/f'link-{mode}.log').open('w')as log:run(['mips-linux-gnu-ld','-T',path(lds),'-T','build/pal-1.0/linker_scripts/makerom.ld','-T','build/pal-1.0/undefined_syms.txt','--emit-relocs','-o',path(elf)],cwd=O,pass_fds=tuple(fds),stdout=log,stderr=subprocess.STDOUT)
 out=subprocess.check_output(['mips-linux-gnu-nm','-n',path(elf)],pass_fds=(elf,),text=True);symbols={n:int(a,16)for a,t,n in re.findall(r'^([0-9a-f]{8}) ([A-Za-z]) (\S+)$',out,re.M)}
 wanted=['Player_Action_808502D0','Player_Action_8084B898','Player_Action_8084B9E4','Player_Action_8084D610','Player_Action_8084D84C','ObjOshihiki_Push','ObjOshihiki_SetupPush','_ovl_player_actorSegmentStart','_ovl_Obj_OshihikiSegmentStart','gSaveContext','gActorOverlayTable','gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68','gAudioCtx','sAudioSeqCmds','gSeqCmdWritePos','gSeqCmdReadPos','Sequence_111_Size','Soundfont_39_Size','Sequence_98_Size','Soundfont_38_Size','Sequence_112_Size','Sequence_113_Size','Soundfont_40_Size','gAudioHeap','func_808FD5F4','gAudioSpecId','_ovl_En_BirdSegmentRomSize','_ovl_En_BirdSegmentStart','_ovl_Boss_DodongoSegmentRomSize','_ovl_Boss_DodongoSegmentStart','BossDodongo_Explode','BossDodongo_Inhale','BossDodongo_SetupDeathCutscene','EnZf_SetupDie','_ovl_En_ZfSegmentStart','BossDodongo_DeathCutscene','EnZf_Die']
 selected={n:symbols[n]for n in wanted};(W/f'all-symbols-{mode}.json').write_text(json.dumps(symbols,indent=2));(W/f'symbols-{mode}.json').write_text(json.dumps(selected,indent=2))
 raw=fd(mode+'-raw');run(['mips-linux-gnu-objcopy','--pad-to',hex(symbols['_RomSize']),'-O','binary',path(elf),path(raw)],pass_fds=(elf,raw));os.lseek(raw,0,0);b=bytearray(os.read(raw,symbols['_RomSize']));struct.pack_into('>II',b,16,*ipl3checksum.CICKind.CIC_X105.calculateChecksum(b));ranges=set()
 for p in(O/'build/pal-1.0/compress_ranges.txt').read_text().strip().split(','):
  a=p.split('-');ranges.update(range(int(a[0]),int(a[-1])+1))
 b=bytearray(compress.compress_rom(memoryview(b),symbols['_dmadataSegmentRomStart'],ranges,'yaz0',0x800000,True,4));struct.pack_into('>II',b,16,*ipl3checksum.CICKind.CIC_X105.calculateChecksum(b));assert len(b)<=0x4000000,('ROM exceeds64MiB',len(b));rom=fd(mode+'-rom');os.write(rom,b);state[mode]=dict(fd=rom,sha256=hashlib.sha256(b).hexdigest(),symbols=selected)
 for n in [*fds,raw]:held.remove(n);os.close(n)
 print('BUILD_READY',mode,state[mode]['sha256'],selected,flush=True)
 return rom

def main():
 build('normal');seen=0;print('WAITING_FOR_COMMAND',flush=True)
 while True:
  q=W/'ram-command.json'
  if q.exists():
   m=json.loads(q.read_text())
   if m['id']!=seen:
    seen=m['id']
    try:
     if m['action']=='build':build(m['mode'])
     elif m['action']=='qa':
      n=state[m['mode']]['fd'];run([sys.executable,str(W/'qa.py'),path(n),m['mode']],pass_fds=(n,))
     elif m['action']=='finish':break
     (W/'ram-result.json').write_text(json.dumps(dict(id=seen,passed=True)))
    except Exception as e:(W/'ram-result.json').write_text(json.dumps(dict(id=seen,passed=False,error=str(e))));print('ACTION_FAILED',repr(e),flush=True)
    print('WAITING_FOR_COMMAND',flush=True)
  time.sleep(.5)
if __name__=='__main__':main()

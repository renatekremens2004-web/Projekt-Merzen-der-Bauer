from pathlib import Path
import time,re,json,hashlib,subprocess
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
report={}
for rel,sha in json.loads((W/'original-sha256.json').read_text()).items():
 p=O/rel;p.write_bytes((W/'original'/rel).read_bytes());report[rel]=hashlib.sha256(p.read_bytes()).hexdigest();assert report[rel]==sha
with(W/'restore-build.log').open('w')as log:
 subprocess.run(['make','-j4','VERSION=pal-1.0','COMPARE=0','PYTHON=/workspace/toolchain/venv/bin/python3','build/pal-1.0/segments/Audiotable.plf','build/pal-1.0/src/audio/tables/samplebank_table.o','build/pal-1.0/segments/Audioseq.plf','build/pal-1.0/segments/Audiobank.plf','build/pal-1.0/src/audio/tables/soundfont_table.o','build/pal-1.0/src/audio/game/session_init.o','build/pal-1.0/src/audio/game/session_config.o','build/pal-1.0/src/buffers/audio_heap.o'],cwd=O,stdout=log,stderr=subprocess.STDOUT,check=True)
for n in ['code','ovl_En_Ko','ovl_Demo_Ec','ovl_En_Go2','spot00_room_0','spot20_room_0','spot18_room_1']:
 for ext in ['.plf','.map']:
  p=O/'build/pal-1.0/segments'/(n+ext)
  if p.exists():p.unlink()
for p in (O/'assets/audio/samples/SampleBank_0').glob('MalonV82_*.wav'):p.unlink()
report['production_sources_restored']=True;report['compiled_audio_restored']=True;(W/'production-restored.json').write_text(json.dumps(report,indent=2));print('PRODUCTION_AUDIO_RESTORED',flush=True)

from pathlib import Path
import sys,copy,collections,json,math,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
# Read every written part, including the late orchestral development and final ritardando.
s=Path(__file__).with_name('read_midi.py').read_text()
ns={'__file__':__file__};exec(s,ns);O=ns['O'];tracks=ns['tracks'];tempos=ns['tempos'];source=ns['source'];m=ns['m']
fonts={i:ET.parse(O/f'extracted/pal-1.0/assets/audio/soundfonts/Soundfont_{i}.xml').getroot()for i in(3,5,9,13)}
font=ET.Element('Soundfont',Name='Soundfont_38',Index='38',Medium='MEDIUM_CART',CachePolicy='CACHE_LOAD_TEMPORARY',SampleBank='$(BUILD_DIR)/assets/audio/samplebanks/SampleBank_0.xml',Indirect='1')
envs=ET.SubElement(font,'Envelopes');samples=ET.SubElement(font,'Samples');insts=ET.SubElement(font,'Instruments');used=set()
def env(fi,name):
 key=f'F{fi}_{name}'
 if not any(e.get('Name')==key for e in envs):
  e=copy.deepcopy(fonts[fi].find(f'./Envelopes/Envelope[@Name="{name}"]'));e.set('Name',key);envs.append(e)
 return key
def add_samples(e):
 for k,v in e.attrib.items():
  if k.startswith('Sample')and v.startswith('SAMPLE_')and v not in used:ET.SubElement(samples,'Sample',Name=v);used.add(v)
programs=[(0,13,0,'MALON'),(1,5,0,'PIANO'),(2,3,10,'VIOLINS'),(3,13,2,'ACOUSTIC_GUITAR'),(4,3,11,'CELLOS'),(5,3,14,'CHOIR'),(6,9,6,'ORGAN'),(7,3,5,'FLUTE'),(8,3,3,'HORNS'),(9,3,0,'HARP'),(10,3,8,'OBOE'),(11,3,1,'TRUMPET'),(12,3,2,'TROMBONE'),(13,3,12,'PIZZICATO'),(14,3,7,'BASSOON'),(15,13,3,'GUITAR_HIGH')]
for index,fi,program,name in programs:
 e=copy.deepcopy(fonts[fi].find(f'./Instruments/Instrument[@ProgramNumber="{program}"]'));e.set('Name',name);e.set('ProgramNumber',str(index));e.set('Envelope',env(fi,e.get('Envelope')));insts.append(e);add_samples(e)
# Real pre-pitched sample registers keep every part below the native4x ceiling.
# Five sample registers are generated from the original waveforms, not substitute timbres.
for program,sample,root,threshold in [(2,1374,'AF5',None),(6,1354,'C5','C6'),(7,1364,'C5','C6'),(8,1382,'A4','E4'),(14,1366,'E3','C4')]:
 e=insts.find(f'./Instrument[@ProgramNumber="{program}"]')
 if threshold is not None:e.set('RangeHi',threshold)
 e.set('SampleHi',f'SAMPLE_0_{sample}');e.set('BaseNoteHi',root)
 if f'SAMPLE_0_{sample}'not in used:ET.SubElement(samples,'Sample',Name=f'SAMPLE_0_{sample}');used.add(f'SAMPLE_0_{sample}')
drums=copy.deepcopy(fonts[3].find('Drums'))
for e in drums:e.set('Envelope',env(3,e.get('Envelope')));add_samples(e)
font.insert(2,drums);ET.indent(font,space='    ');(W/'Soundfont_38.xml').write_text(ET.tostring(font,encoding='unicode')+'\n')

def notes(ti,boost=1.,offset=0):
 return [[a,z,p+offset,max(1,min(123,round(v*boost)))]for a,z,p,v in tracks[ti]]
def allocate(ns,count):
 voices=[[]for _ in range(count)];ends=[0]*count
 for a,group in __import__('itertools').groupby(sorted(ns),key=lambda n:n[0]):
  unique={}
  for n in group:
   if n[2]not in unique or (n[3],n[1])>(unique[n[2]][3],unique[n[2]][1]):unique[n[2]]=list(n)
  candidates=sorted(unique.values(),key=lambda n:(n[3],n[2]),reverse=True)[:count]
  for n in sorted(candidates,key=lambda n:n[2]):
   free=[i for i,e in enumerate(ends)if e<=a];i=min(free,key=lambda i:ends[i])if free else min(range(count),key=lambda i:ends[i])
   if ends[i]>a:
    if voices[i][-1][0]==a:continue
    voices[i][-1][1]=a
   voices[i].append(n);ends[i]=n[1]
 return voices
# Additional orchestration uses only actually written notes, with exact timing.
# The former two-beat pitch-class vote mixed passing tones and successive chords.
# Never concatenate early accompaniment with a later line without clipping the boundary.
def clip_before(v, boundary):
 return [[a,min(z,boundary),p,vel] for a,z,p,vel in v if a<boundary and min(z,boundary)>a]
early_upper=allocate(notes(6,.76),2)
early_lower=allocate(notes(6,.73,-12),2)
channels=[]
def add(name,voices,programs,pan,volume,priority):
 assert len(voices)==len(programs)<=4,(name,len(voices))
 channels.append(dict(name=name,voices=voices,voice_programs=programs,pan=pan,volume=volume,priority=priority,reverb=16))
# Three distinct vocal lines, including written choir melody once the solo line ends.
v0=allocate(notes(0,1.20),1);v1=allocate(notes(1,.63),1);v2=allocate([n for n in notes(2,.98) if n[0]>=352*48],1)
add('Malon solo + harmony + choral doubling',v0+v1+v2,[0,0,0],64,127,15)
add('Grand piano, both hands',allocate(notes(4),3)+allocate(notes(5),1),[1]*4,44,91,11)
violins=allocate(notes(16),2)+allocate(notes(17),2)
violas=allocate(notes(18),2)+allocate(notes(19),2)
for vs in (violins,violas):
 for v in vs:
  for n in v:n[3]=min(115,round(32+n[3]*.78))
for i in range(2):violins[i]=clip_before(early_upper[i],274*48)+violins[i]
for i in range(2):violas[i]=clip_before(early_lower[i],274*48)+violas[i]
add('Violins I and II, full score + exact written organ doubling',violins,[2]*4,25,89,12)
add('Violas and cellos, full score + exact written organ doubling',violas,[4]*4,99,85,12)
add('Double basses + plucked bass',allocate(notes(20,1.4),1)+allocate(notes(10,1.15),1),[4,3],64,96,13)
brass=allocate(notes(6,.88,-12),3)
add('Horns + trumpet + trombone, exact written organ harmonies',brass,[8,11,12],78,69,11)
add('Flute violin solo, oboe harmony and bassoon cello line',allocate(notes(15,.87),1)+allocate(notes(1,.78),1)+allocate(notes(19,.74),1),[7,10,14],34,92,10)
add('Female choir, three written voices',allocate(notes(2,1.01),3),[5]*3,79,66,11)
add('Male choir, two written voices',allocate(notes(3,1.05),2),[5]*2,49,69,11)
add('Pipe organ, full chords',allocate(notes(6,1.10),3),[6]*3,66,61,8)
add('Harp, doubled piano figures',allocate(notes(4,.92),2),[9]*2,100,60,8)
add('Acoustic guitars',allocate(notes(7,.85),2),[3]*2,95,61,7)
add('Guitar counterline from original electric guitar part',allocate(notes(9,1.05),1),[15],27,79,9)
# Font 3: sample370 (21..32) is cymbal/noise; sample371 (33+) is PITCHED TIMPANI.
# Never map GM crash/ride to 34: that caused an unrelated low pitched note.
def percussion(ti,accent=False):
 out=[]
 for a,z,p,v in tracks[ti]:
  if accent and v<78:continue
  if p in(35,36):key=15
  elif p in(37,38,40):key=16 if p==37 else 17
  elif p in(42,44,46):
   if accent:continue
   key=21 if p!=46 else 23
  elif p in(41,43,45,47,48,50):key=17
  else:key=26
  out.append([a,min(z,a+(32 if key==26 else 6)),key,min(120,round(v*1.02))])
 return out
add('Drum kit, clear snare and cymbals',allocate(percussion(11),3),[127]*3,64,66,10)
add('Low orchestral drum accents',allocate(percussion(12,True),2),[127]*2,53,46,9)
pizz=[[a,min(z,a+16),p,v]for a,z,p,v in notes(4,.87)if a%48 in(0,24)]
add('Pizzicato strings and written solo violin',allocate(pizz,2)+allocate(notes(15,.90),1),[13,13,2],44,64,9)
assert len(channels)==16
# Keep 32 simultaneous written notes, with release headroom in the private 36-note listening spec.
rank=[100,78,95,93,94,92,79,90,89,60,56,51,69,74,65,70]
events=[];active=[];cut=0
for ci,c in enumerate(channels):
 for vi,v in enumerate(c['voices']):
  for n in v:events.append((n[0],rank[ci]+(1 if vi==0 else 0),n))
for a,score,n in sorted(events,key=lambda e:(e[0],-e[1])):
 active=[x for x in active if x[1][1]>a];active.append((score,n))
 if len(active)>32:
  loser=min(active,key=lambda x:(x[0],x[1][3],-x[1][0]));loser[1][1]=a;active.remove(loser);cut+=1
for c in channels:c['voices']=[[n for n in v if n[1]>n[0]]for v in c['voices']]
# This validates the exact schedule consumed by the monophonic native layers.
# In V80 714 cello attacks were delayed by up to190 ticks (3.958 beats).
for c in channels:
 for vi,v in enumerate(c['voices']):
  end_previous=0
  for a,z,p,vel in v:
   assert a>=end_previous,(c['name'],vi,'overlap would cause native timing drift',a,end_previous)
   assert z>a and 21<=p<=127 if c['voice_programs'][vi]!=127 else z>a
   end_previous=z
from audit_registers import audit as audit_registers
register_check=audit_registers(channels,font)
assert register_check['clipped_notes']==0,('native playback-rate limit exceeded',register_check['examples'])
(W/'register-audit-v82.json').write_text(json.dumps(register_check,indent=2))
end=math.ceil(max(n[1]for c in channels for v in c['voices']for n in v)/48)*48+96
lines=['#include "aseq.h"','#include "Soundfont_38.h"','.startseq Sequence_98','.sequence MAIN','mutebhv 0x20','mutescale 50','initchan 65535','vol 73','tempo 76']
for i in range(16):lines.append(f'ldchan {i}, CH_{i}')
at=0
for tick,tempo in sorted(tempos.items()):
 if not tick or tick>=end:continue
 if tick>at:lines.append(f'delay {tick-at}')
 lines.append(f'tempo {tempo}');at=tick
lines +=[f'delay {end-at}','end']
for i,c in enumerate(channels):
 lines +=[f'.channel CH_{i}','noshort',f'vol {c["volume"]}',f'pan {c["pan"]}',f'notepri 0, {c["priority"]}',f'reverb {c["reverb"]}',f'instr {c["voice_programs"][0]}']
 for j,v in enumerate(c['voices']):
  if v:lines.append(f'ldlayer {j}, L_{i}_{j}')
 if i==9:
  # +2.02 dB only during Malon's solo and the following sung choir melody.
  # Leave the instrumental introduction and ending at their V82 level.
  lines +=['delay 3072','vol 61','delay 48','vol 69','delay 48','vol 96',
           'delay 16896','vol 69','delay 48','vol 61',f'delay {end+48-419*48}','end']
 elif i in (2,3,5,7,8,10,12):
  # The later supporting lines gain about1dB; never lower any existing part.
  boosted={2:119,3:114,5:97,7:94,8:97,10:69,12:90}[i]
  middle=(c['volume']+boosted)//2
  lines +=['delay 8688',f'vol {middle}','delay 48',f'vol {boosted}',f'delay {end+48-182*48}','end']
 else:lines +=[f'delay {min(end+48,32767)}','end']
 for j,v in enumerate(c['voices']):
  if not v:continue
  prog=c['voice_programs'][j];shift=max(0,max(n[2]for n in v)-84)if prog!=127 else 0
  lines +=[f'.layer L_{i}_{j}',f'instr {prog}']
  if shift:lines.append(f'transpose {shift}')
  at=0
  for ni,(a,z,p,vel)in enumerate(v):
   assert a>=at,('writer is late',i,j,a,at)
   if a>at:lines.append(f'ldelay {a-at}')
   pitch=p if prog==127 else p-21-shift;assert 0<=pitch<64,(i,j,pitch,p,shift)
   nxt=v[ni+1][0]if ni+1<len(v)else z;gate=round(256*(nxt-z)/(nxt-a))if nxt>a else 0
   if 0<gate<255 and nxt-z<480:lines.append(f'notedvg {pitch}, {nxt-a}, {vel}, {gate}');at=nxt
   else:lines.append(f'notedv {pitch}, {z-a}, {vel}');at=z
  lines.append('end')
from compress_motifs import compress
lines,motifs=compress(lines);lines.append('.endseq Sequence_98');(W/'seq_98.seq').write_text('\n'.join(lines)+'\n')
seconds=0;at=0;prev=76
for tick,tempo in sorted(tempos.items()):seconds+=(tick-at)/48*60/prev;at=tick;prev=tempo
seconds+=(end-at)/48*60/prev
report=dict(revision=85,organ_vocal_section_gain_db=20*math.log10(96/61),organ_volume_automation=[[0,61],[65,69],[66,96],[418,69],[419,61]],timing_validation='all monophonic layers have exact source start times',added_harmonies='only exact source-note or octave doublings; no guessed pitch-class pads',percussion_fix='cymbal sample370 replaces erroneously triggered timpani371',source='Komm,_süsser_Tod_-_Evangelion_(Complete).mid',source_tracks=source,full_score=True,source_end_beats=end/48,native_seconds=seconds,tempos=tempos,native_note_budget=32,preview_note_pool=36,overlap_cuts=cut,motifs=motifs,instruments=[dict(program=i,native_font=f,native_program=p,name=n)for i,f,p,n in programs],channels=[{k:v for k,v in c.items()if k!='voices'}|dict(layers=len(c['voices']),notes=sum(map(len,c['voices'])))for c in channels])
(W/'arrangement.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));(W/'notes.json').write_text(json.dumps(channels,separators=(',',':')));print('FULL ORCHESTRA',seconds,'seconds; cuts',cut,'motifs',motifs,flush=True)

from pathlib import Path
import numpy as np,struct,json,subprocess,xml.etree.ElementTree as E
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
# Pitch the *waveform* into a real higher sample register, then retune its root.
# Merely changing metadata leaves the same >4x engine playback rate and cannot fix it.
spec=[(354,2,'ORGAN_HIGH'),(374,2,'STRINGS_HIGH'),(382,4,'HORN_HIGH'),(364,2,'FLUTE_HIGH'),(366,2,'BASSOON_HIGH')]
info={};entries=[];proof=[]
for n,factor,name in spec:
 src=O/f'extracted/pal-1.0/assets/audio/samples/SampleBank_0/Sample{n:03}.wav';raw=src.read_bytes();chunks={};i=12
 while i+8<len(raw):
  k=raw[i:i+4];z=int.from_bytes(raw[i+4:i+8],'little');chunks[k]=raw[i+8:i+8+z];i+=8+z+(z&1)
 fmt=chunks[b'fmt '];rate=struct.unpack_from('<I',fmt,4)[0];old=np.frombuffer(chunks[b'data'],dtype='<i2').astype(float)
 # Anti-alias filtering BEFORE decimation. Preserve native sample timbre and tuning.
 half=128*factor;x=np.arange(-half,half+1);cutoff=.475/factor;h=2*cutoff*np.sinc(2*cutoff*x)*np.kaiser(len(x),10);h/=h.sum()
 filtered=np.convolve(np.pad(old,(half,half),mode='reflect'),h,mode='valid');y=filtered[::factor];y=np.round(y).clip(-32768,32767).astype('<i2')
 inst=bytearray(chunks[b'inst']);root=inst[0]+round(12*np.log2(factor));inst[0]=root
 smpl=bytearray(chunks[b'smpl']);struct.pack_into('<I',smpl,12,root)
 loops=struct.unpack_from('<I',smpl,28)[0]
 for li in range(loops):
  pos=36+li*24;start,end=struct.unpack_from('<II',smpl,pos+8);start2=round(start/factor);end2=round((end+1)/factor)-1;struct.pack_into('<II',smpl,pos+8,start2,end2)
  # Compare seam jump with nearby derivative; loop phase stays within one source sample.
  seam=float(abs(int(y[start2])-int(y[end2])));local=float(np.sqrt(np.mean(np.diff(y[max(0,start2-30):min(len(y),end2+30)].astype(float))**2)))
  proof.append(dict(name=name,root=root,loop_start=start2,loop_end=end2,seam_jump=seam,typical_difference=local))
 def chunk(k,d):return k+struct.pack('<I',len(d))+d+(b'\0'if len(d)&1 else b'')
 data=b'WAVE'+chunk(b'fmt ',fmt)+chunk(b'fact',struct.pack('<I',len(y)))+chunk(b'data',y.tobytes())+chunk(b'inst',inst)+chunk(b'smpl',smpl)
 dest=O/f'assets/audio/samples/SampleBank_0/MalonV82_{name}.wav';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b'RIFF'+struct.pack('<I',len(data))+data)
 aifc=O/f'build/pal-1.0/assets/audio/samples/SampleBank_0/MalonV82_{name}.aifc'
 subprocess.run([str(O/'tools/audio/sampleconv/sampleconv'),'vadpcm',str(dest),str(aifc)],check=True)
 num=n+1000;entries.append(E.Element('Sample',Name=f'SAMPLE_0_{num}',Path=f'$(BUILD_DIR)/assets/audio/samples/SampleBank_0/MalonV82_{name}.aifc'));info[str(num)]=[rate,root]
(W/'custom-sample-info.json').write_text(json.dumps(info,indent=2));(W/'sample-loop-check.json').write_text(json.dumps(proof,indent=2))
bank=O/'extracted/pal-1.0/assets/audio/samplebanks/SampleBank_0.xml';e=E.parse(bank).getroot()
for el in entries:e.append(el)
E.indent(e,space='    ');bank.write_text(E.tostring(e,encoding='unicode')+'\n')
print('FIVE_REAL_HIGH_REGISTERS_GENERATED',info)

from pathlib import Path
import os,sys,json,subprocess,re,struct,hashlib,importlib.util,numpy as np
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');spec=importlib.util.spec_from_file_location('ram_builder',W/'memory_build.py');mb=importlib.util.module_from_spec(spec);spec.loader.exec_module(mb)
fd=mb.build('normal');sy=mb.state['normal']['symbols'];assert sy['Sequence_98_Size']<0xE000 and sy['Soundfont_38_Size']<0x2880,sy
base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text();old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text())
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static void queue_audio(unsigned command){unsigned p=DebugMemRead8(WRITE_POS);DebugMemWrite32(SEQ_COMMANDS+4*p,command);DebugMemWrite8(WRITE_POS,(p+1)&255);}
static void onframe(unsigned f){
 static unsigned requested=0,started=0,voice=0,ended=0,peaknotes=0;static uint64_t start=0,last=0;unsigned seq=AUDIO_CONTEXT+0x3530,flags=DebugMemRead8(seq),id=DebugMemRead8(seq+4);
 baseframe(f);if(f<340)return;findplay();if(!play||!player)return;
 if(!requested&&f>=420){
  queue_audio(0x00000062);queue_audio(0x4001007f);
  for(unsigned i=1;i<4;i++)queue_audio(0x40010000|(i<<24));requested=1;
  printf("MUSIC_REQUEST frame=%u scene=%x\n",f,DebugMemRead16(play+0xa4));
 }
 if(requested&&!started&&id==98&&(flags&0x80)&&DebugMemRead16(seq+0x10)>0){
  start=audioSamples();started=1;printf("MUSIC_BEGIN sample=%llu rate=%u frame=%u\n",(unsigned long long)start,audioRate(),f);
 }
 if(f==1000)need(started,"orchestra sequence starts");
 if(started){
  unsigned np=r32(AUDIO_CONTEXT+0x352c),nn=0;need(r32(AUDIO_CONTEXT+0x2894)==36,"private orchestra has36 native note slots");
  for(unsigned ni=0;ni<36;ni++)if(DebugMemRead8(np+ni*0xe0+0xc0)&0x80)nn++;
  if(nn>peaknotes)peaknotes=nn;
  if(f%250==0)printf("ORCHESTRA_NOTES active=%u peak=%u\n",nn,peaknotes);
  unsigned c=r32(seq+0x38);
  if(c>=0x80000000&&c<0x80400000&&DebugMemRead8(c+7)==38&&DebugMemRead16(c+0x24)==2&&r32(c+0x48))voice++;
  if(f%250==0)printf("MUSIC_PROGRESS seconds=%.2f seq=%u enabled=%u delay=%u voice=%u\n",(audioSamples()-start)/(double)audioRate(),id,(flags&0x80)!=0,DebugMemRead16(seq+0x10),voice);
  need(r32(0x80000318)==4194304,"native 4 MiB");
  if(!ended&&(audioSamples()-start)/(double)audioRate()>=315.0){ended=1;last=audioSamples();printf("MUSIC_END sample=%llu frame=%u\n",(unsigned long long)last,f);}
  if(ended&&audioSamples()>last){need(voice>1000,"Malon original instrument remains loaded");need(peaknotes>=26,"expanded orchestra actually sounds simultaneously");printf("MUSIC_CAPTURE_PASSED begin=%llu end=%llu rate=%u malon_frames=%u\n",(unsigned long long)start,(unsigned long long)audioSamples(),audioRate(),voice);CoreDoCommand(M64CMD_STOP,0,NULL);}
  if(audioSamples()>start+audioRate()*540){puts("MUSIC_TIMEOUT");exit(96);}
 }
 if(f>15000){puts("FRAME_TIMEOUT");exit(96);}
}
'''
for akey,key in [('WRITE_POS','gSeqCmdWritePos'),('SEQ_COMMANDS','sAudioSeqCmds'),('AUDIO_CONTEXT','gAudioCtx')]:body=body.replace(akey,hex(sy[key]))
p=W/'music-runner.c';p.write_text(base[:a]+body+base[b:]);runner=W/'music-runner';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(p),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0xbb,1,0);struct.pack_into('>i',q,0x1364,0);q[0x1409]=1;fixture=W/'listen.save';fixture.write_bytes(q)
pcm=os.memfd_create('malon-native-pcm');env=os.environ.copy();env.update(DISPLAY=':99',CREDITS_AUDIO_PATH='/proc/self/fd/'+str(pcm))
with(W/'capture-runtime.log').open('w')as log:r=subprocess.run([str(runner),'/proc/self/fd/'+str(fd),'malon-native-listen-v85','15200','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(fixture)],pass_fds=(fd,pcm),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1500)

text=(W/'capture-runtime.log').read_text();assert r.returncode==0 and'MUSIC_CAPTURE_PASSED'in text,text[-3500:]
first,last,rate,frames=map(int,re.search(r'MUSIC_CAPTURE_PASSED begin=(\d+) end=(\d+) rate=(\d+) malon_frames=(\d+)',text).groups());seconds=(last-first)/rate
(W/'native-full.pcm').write_bytes(Path('/proc/self/fd/'+str(pcm)).read_bytes())
os.lseek(pcm,first*4,0);audio=np.frombuffer(os.read(pcm,(last-first)*4),dtype='<i2').reshape(-1,2);assert len(audio)==last-first
stats=dict(rate=rate,seconds=seconds,first_sample=first,last_sample=last,malon_instrument_frames=frames,peak=int(np.max(np.abs(audio.astype(np.int32)))),rms=float(np.sqrt(np.mean(audio.astype(float)**2))),clipped_fraction=float(np.mean(np.abs(audio.astype(np.int32))>=32760)),native_sequence_bytes=sy['Sequence_98_Size'],native_font_bytes=sy['Soundfont_38_Size'],native_ram_bytes=4194304)
assert stats['clipped_fraction']<.0001,stats
stats['peak_native_notes']=max(map(int,re.findall(r'ORCHESTRA_NOTES active=\d+ peak=(\d+)',text)));stats['native_note_pool']=36;stats['private_preview_audio_heap_bytes']=0x58000
(W/'recording.json').write_text(json.dumps(stats,indent=2))
print('NATIVE_MASTER_READY',flush=True)

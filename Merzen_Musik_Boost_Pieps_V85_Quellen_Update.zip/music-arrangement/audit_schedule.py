from pathlib import Path
import json,gzip,re,collections,runpy,sys
W=Path(__file__).resolve().parent

def timeline_audit(channels):
 count=late=0;maxlate=0;first=None
 for c in channels:
  for vi,v in enumerate(c['voices']):
   at=0
   for ni,(a,z,p,vel)in enumerate(v):
    at=max(at,a);drift=at-a;count+=1
    if drift:
     late+=1;maxlate=max(maxlate,drift)
     if first is None:first=dict(section=c['name'],voice=vi,source_beat=a/48,drift_beats=drift/48)
    nxt=v[ni+1][0]if ni+1<len(v)else z;gate=round(256*(nxt-z)/(nxt-a))if nxt>a else 0
    at+=nxt-a if 0<gate<255 and nxt-z<480 else z-a
 return dict(notes=count,late_attacks=late,max_drift_ticks=maxlate,max_drift_beats=maxlate/48,first=first)
old=json.loads(gzip.decompress(Path('/workspace/malon-orchestra-v80/notes.json.gz').read_bytes()))
new=json.loads((W/'notes.json').read_text())
# Independently interpret emitted layer instructions, including shared motifs.
lines=(W/'seq_98.seq').read_text().splitlines();blocks={};label=None
for line in lines:
 if line.startswith('.layer '):label=line.split()[1];blocks[label]=[]
 elif line.startswith(('.channel ','.endseq ')):label=None
 elif label is not None:blocks[label].append(line)
def expand(label):
 out=[]
 for l in blocks[label]:
  if l.startswith('call '):out+=expand(l.split()[1])
  elif l!='end':out.append(l)
 return out
errors=[];checked=0;durations=[]
for ci,c in enumerate(new):
 for vi,voice in enumerate(c['voices']):
  if not voice:continue
  at=0;trans=0;events=[]
  for line in expand(f'L_{ci}_{vi}'):
   if line.startswith('instr '):continue
   if line.startswith('transpose '):trans=int(line.split()[1]);continue
   if line.startswith('ldelay '):at+=int(line.split()[1]);continue
   cmd,args=line.split(' ',1);args=list(map(int,args.split(',')));pitch,d,v=args[:3];gate=args[3]if cmd=='notedvg'else 0
   p=pitch if c['voice_programs'][vi]==127 else pitch+21+trans
   events.append((at,at+d-((gate*d)>>8),p,v));at+=d
  if len(events)!=len(voice):errors.append((ci,vi,'length'));continue
  for idx,((a,z,p,v),(aa,zz,pp,vv))in enumerate(zip(voice,events)):
   checked+=1
   if (a,p,v)!=(aa,pp,vv):errors.append((ci,vi,idx,'wrong onset/pitch/velocity',(a,p,v),(aa,pp,vv)))
   durations.append(abs(z-zz))
   if abs(z-zz)>2:errors.append((ci,vi,idx,'gate duration',z,zz))
# No arbitrary pitch-class approximations: all melodic notes must lie within
# a real original note of that pitch class at exactly that time.
sys.argv=[str(W/'read_midi.py')];ns=runpy.run_path(sys.argv[0]);source=[n for ti,t in enumerate(ns['tracks'])if ti not in(11,12,13,14)for n in t];by_pc=collections.defaultdict(list)
for n in source:by_pc[n[2]%12].append(n)
non_source=[]
for ci,c in enumerate(new):
 for vi,voice in enumerate(c['voices']):
  if c['voice_programs'][vi]==127:continue
  for a,z,p,v in voice:
   if not any(x<=a and zz>=z for x,zz,pp,vv in by_pc[p%12]):non_source.append((ci,vi,a,z,p))
r=dict(v80=timeline_audit(old),v82=timeline_audit(new),emitted_sequence_notes_checked=checked,emitted_sequence_errors=errors,max_gate_rounding_ticks=max(durations),non_source_harmonies=non_source)
(W/'timing-audit.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2));assert not errors and not non_source and not r['v82']['late_attacks']

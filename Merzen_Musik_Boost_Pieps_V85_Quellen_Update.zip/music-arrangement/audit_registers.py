from pathlib import Path
import json,xml.etree.ElementTree as E,struct,wave,math,collections
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
PITCH={'C':0,'DF':1,'D':2,'EF':3,'E':4,'F':5,'GF':6,'G':7,'AF':8,'A':9,'BF':10,'B':11}
def midi(s):return 12*(int(s[-1])+1)+PITCH[s[:-1]]
def wavinfo(n):
 p=O/f'extracted/pal-1.0/assets/audio/samples/SampleBank_0/Sample{n:03}.wav';b=p.read_bytes();i=12;root=None
 while i+8<len(b):
  k=b[i:i+4];z=int.from_bytes(b[i+4:i+8],'little');d=b[i+8:i+8+z]
  if k==b'inst':root=d[0]
  i+=8+z+(z&1)
 with wave.open(str(p))as f:rate=f.getframerate()
 return rate,root

def audit(cs,font):
 insts={int(i.get('ProgramNumber')):i for i in font.find('Instruments')};bad=[];peaks={}
 for ci,c in enumerate(cs):
  for vi,v in enumerate(c['voices']):
   program=c['voice_programs'][vi]
   if program==127:continue
   inst=insts[program]
   for a,z,p,vel in v:
    suf='Lo'if p<int(midi(inst.get('RangeLo','A0')))else 'Hi'if p>int(midi(inst.get('RangeHi','G9')))else ''
    sample=inst.get('Sample'+suf);num=int(sample.rsplit('_',1)[1]);rate,root=wavinfo(num)if num<1000 else custom[str(num)]
    rate=int(inst.get('SampleRate'+suf,rate));root=midi(inst.get('BaseNote'+suf))if inst.get('BaseNote'+suf)else root
    ratio=rate/31995*2**((p-root)/12)
    key=f'{ci}:{vi}:{program}';peaks[key]=max(peaks.get(key,0),ratio)
    if ratio>3.99996:
     actual=p+12*math.log2(3.99996/ratio);bad.append(dict(channel=ci,voice=vi,program=program,sample=num,seconds=round(a/48*60/76,3),pitch=p,ratio=round(ratio,5),actual_pitch=round(actual,4),error_semitones=round(actual-p,4)))
 return dict(clipped_notes=len(bad),by_program=dict(collections.Counter(str(n['program'])for n in bad)),first_minute=[n for n in bad if n['seconds']<60],around_5_16=[n for n in bad if 310<n['seconds']<323],max_ratio_by_voice=peaks,examples=bad[:20])
custom={}
if (W/'custom-sample-info.json').exists():custom=json.loads((W/'custom-sample-info.json').read_text())
# Cache metadata reads to keep full-score checks cheap.
from functools import lru_cache
wavinfo=lru_cache(None)(wavinfo)
if __name__=='__main__':
 import sys
 src=Path(sys.argv[1])if len(sys.argv)>1 else Path('/workspace/malon-repair-v81');out=audit(json.loads((src/'notes.json').read_text()),E.parse(src/'Soundfont_38.xml').getroot());(W/'register-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items()if k not in('first_minute','around_5_16','max_ratio_by_voice','examples')},indent=2));print('first minute examples',out['first_minute'][:3]);print('5:16 examples',out['around_5_16'][:3])

from pathlib import Path
import re,hashlib,json,subprocess,shutil
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
rels=['assets/audio/sequences/seq_98.seq','assets/audio/soundfonts/Soundfont_38.xml','include/buffers.h','src/buffers/audio_heap.c','src/audio/game/session_config.c','extracted/pal-1.0/assets/audio/samplebanks/SampleBank_0.xml']
h={}
for rel in rels:
 q=W/'original'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(O/rel,q);h[rel]=hashlib.sha256(q.read_bytes()).hexdigest()
(W/'original-sha256.json').write_text(json.dumps(h,indent=2))
for name,rel in zip(['seq_98.seq','Soundfont_38.xml'],rels):shutil.copyfile(W/name,O/rel)
subprocess.run(['/workspace/toolchain/venv/bin/python3',str(W/'build_high_registers.py')],check=True)
for rel in rels[2:4]:
 p=O/rel;p.write_text(p.read_text().replace('0x38000','0x58000'))
p=O/rels[4];s=p.read_text();s=re.sub(r'(\{ (?:32000|22050), 1, )\d+(,)',r'\g<1>36\2',s);s=s.replace('0x3800, 0x2880','0xE000, 0x2880').replace('0x4000, 0x2880','0xE000, 0x2880');p.write_text(s)
with(W/'build-assets.log').open('w')as log:subprocess.run(['make','-j4','VERSION=pal-1.0','COMPARE=0','PYTHON=/workspace/toolchain/venv/bin/python3','build/pal-1.0/segments/Audiotable.plf','build/pal-1.0/src/audio/tables/samplebank_table.o','build/pal-1.0/segments/Audioseq.plf','build/pal-1.0/segments/Audiobank.plf','build/pal-1.0/src/audio/tables/soundfont_table.o','build/pal-1.0/src/audio/game/session_init.o','build/pal-1.0/src/audio/game/session_config.o','build/pal-1.0/src/buffers/audio_heap.o'],cwd=O,stdout=log,stderr=subprocess.STDOUT,check=True)
print('PRIVATE_PREVIEW_ASSETS_READY')

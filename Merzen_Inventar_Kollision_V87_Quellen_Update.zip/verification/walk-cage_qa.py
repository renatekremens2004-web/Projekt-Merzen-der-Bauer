from pathlib import Path
import os,sys,json,re,subprocess,struct
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];fd=int(rom.rsplit('/',1)[1]);sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);body=(W/'walk-combined.c').read_text()
for m,n in [('DENIED_OVERLAY','gActorOverlayDeniedV68'),('DENIED_INSTANCE','gActorInstanceDeniedV68'),('DENIED_LAST','gActorLastDeniedV68')]:body=body.replace(m,hex(sy[n]))
s=base[:a]+body+base[b:];runner=W/f'walk-combined-{mode}';c=runner.with_suffix('.c');c.write_text(s);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());entr=(O/'include/tables/entrance_table.h').read_text();e=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\(ENTR_DODONGOS_CAVERN_0,',entr)[1],16);struct.pack_into('>III',q,0,e,1,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,920,0,-320,16384,0xdff,e,0);q[0x1409]=1;q[0xd4+0x1c:0xd4+0x38]=bytes(0x1c);struct.pack_into('>HH',q,0x2e,0x140,0x140);struct.pack_into('>H',q,0xf30,struct.unpack_from('>H',q,0xf30)[0]&~0x400);fixture=W/'walk-combined.save';fixture.write_bytes(q)
log=W/f'{mode}-walk-combined.log'
with log.open('w')as f:r=subprocess.run([str(runner),rom,f'combined-v86-{mode}-direct','2800','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(fixture)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=280)
assert r.returncode==0,(r.returncode,log.read_text()[-1800:]);print('COMBINED_DDAN_QA_PASSED',mode)

from pathlib import Path
import os,sys,subprocess,json,hashlib,io,zipfile
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];romfd=int(rom.rsplit('/',1)[1]);base=O/'baseroms/pal-1.0/baserom.z64'
assert hashlib.md5(base.read_bytes()).hexdigest()=='e040de91a74b61e3201db0e2323f768a'
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());assert 'gRoomAuditV86'not in sy
assert 'gRoomAuditV86'not in(O/'src/code/z_actor.c').read_text()
assert (W/f'batch-{mode}-passed.json').exists()
fd=os.memfd_create('v87-'+mode+'-bps');out='/proc/self/fd/'+str(fd);fds=(romfd,fd)
subprocess.run(['/workspace/toolchain/Flips/flips','--create','--bps',str(base),rom,out],pass_fds=fds,check=True)
js="const fs=require('fs'),c=require('crypto');global.BinFile=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/modules/BinFile');const p=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/RomPatcher');const actual=Buffer.from(p.applyPatch(new BinFile(process.argv[1]),p.parsePatchFile(new BinFile(process.argv[2])),{requireValidation:true})._u8array);const expected=fs.readFileSync(process.argv[3]);if(!actual.equals(expected))throw Error('Mismatch');console.log(c.createHash('sha256').update(actual).digest('hex'));"
sha=subprocess.check_output(['node','-e',js,str(base),out,rom],pass_fds=fds,text=True).strip();patch=Path(out).read_bytes();name='Mr_Burns_Mr_Bean_DE_PAL10_'+('DEBUG_'if mode=='debug'else'')+'Inventar_Kollision_V87.bps';proof=dict(mode=mode,file=name,rom_sha256=sha,patch_sha256=hashlib.sha256(patch).hexdigest(),source_md5='e040de91a74b61e3201db0e2323f768a',byte_identical_after_independent_apply=True,patch_bytes=len(patch),rom_bytes=Path(rom).stat().st_size);(W/f'patch-{mode}-verification.json').write_text(json.dumps(proof,indent=2));files={name:patch};prefix=''
if mode=='normal':
 guide=(W/'README-release.txt').read_text();files['V87_Inventar_Kollision_Hinweise.txt']=guide.encode()
 rels=set()
 for origin in [Path('/workspace/title-collapse-v84/original'),Path('/workspace/player-music-v85/original'),Path('/workspace/room-audio-v86/original'),W/'original']:
  rels.update(str(p.relative_to(origin))for p in origin.rglob('*')if p.is_file())
 rels.update(['assets/audio/soundfonts/Soundfont_40.xml','assets/audio/sequences/seq_112.seq','assets/audio/sequences/seq_113.seq','include/fast_run_v66.h','include/object_room_budget_v86.h','tools/build_object_room_budget_v86.py'])
 rels.update(str(p.relative_to(O))for p in(O/'assets/audio/samples/SampleBank_0').glob('MalonV84_*.aifc'))
 manifest={rel:hashlib.sha256((O/rel).read_bytes()).hexdigest()for rel in sorted(rels)};(W/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
 checks=dict(native_ram_bytes=4194304,normal_cases=json.loads((W/'batch-normal-passed.json').read_text()),regression_normal=json.loads((W/'rooms-normal-passed.json').read_text()),baseline_overflow_bytes=27616,baseline_y_after_close=-2473.5,full_start_to_finish_playthrough=False,private_stress_hooks_in_release=False,enemy_reduction=json.loads((W/'enemy-reduction.json').read_text()))
 (W/'verification-summary.json').write_text(json.dumps(checks,indent=2))
 apply='''from pathlib import Path
import sys,shutil,json,hashlib
root=Path(__file__).resolve().parent;target=Path(sys.argv[1]).resolve()
assert (target/'Makefile').is_file(),target
manifest=json.loads((root/'source-manifest.json').read_text())
for rel,expected in manifest.items():
 p=root/'production'/rel
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,rel
for rel in manifest:
 p=root/'production'/rel;q=target/rel;q.parent.mkdir(parents=True,exist_ok=True)
 if q.is_symlink():q.unlink()
 shutil.copyfile(p,q)
print('V87 production sources and native music assets installed. Build PAL1.0 with the existing toolchain.')
'''
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  z.writestr('LIESMICH_V87.txt',guide);z.writestr('apply_sources_v87.py',apply);z.writestr('source-manifest.json',json.dumps(manifest,indent=2));z.writestr('V87_Pruefungen.json',json.dumps(checks,indent=2))
  for rel in sorted(rels):z.write(O/rel,'production/'+rel)
  for p in W.iterdir():
   if p.is_file()and p.suffix in('.py','.c','.json','.log')and p.stat().st_size<1500000 and not any(x in p.name for x in ['stress','build-owner','objects-','qa-normal-','qa-debug-']):z.write(p,'verification/'+p.name)
 files['Merzen_Inventar_Kollision_V87_Quellen_Update.zip']=buf.getvalue()
 with zipfile.ZipFile(io.BytesIO(files['Merzen_Inventar_Kollision_V87_Quellen_Update.zip']))as z:
  for rel,h in manifest.items():assert hashlib.sha256(z.read('production/'+rel)).hexdigest()==h
 prefix='''## V87 — Inventarmenü und Kollision korrigiert

V86 ließ dem Inventarmenü in Dodongos Höhle und im Brunnen zu wenig Arbeitsfläche. Das verursachte Speicherüberschreibungen und fehlende Bodenkollision nach dem Menüschließen. Die Mindestgröße berücksichtigt nun auch das vollständige Menü samt Sprachtexturen und Reserve. Die Raumlade-Korrekturen und alle bisherigen Inhalte bleiben enthalten. Wiederholtes Ausrüsten/Menüschließen und Raumwechsel mit 4 MiB geprüft. Zusätzlich zwei ReDeads im Brunnen-Keller sowie zwei Beamos und vier Fledermäuse in Dodongos Höhle entfernt.

- [DEBUG-BPS-Patch](Mr_Burns_Mr_Bean_DE_PAL10_DEBUG_Inventar_Kollision_V87.bps)
- [Normaler BPS-Patch](Mr_Burns_Mr_Bean_DE_PAL10_Inventar_Kollision_V87.bps)
- [Hinweise](V87_Inventar_Kollision_Hinweise.txt)
- [Quellen-Update](Merzen_Inventar_Kollision_V87_Quellen_Update.zip)

Kumulativ einschließlich V86. Jeweils auf eine saubere PAL-1.0-ROM anwenden. Kein vollständiger Spieldurchlauf als getestet behauptet.

---

'''
if mode=='debug':
 summary=json.loads((W/'verification-summary.json').read_text());summary['debug_cases']=json.loads((W/'batch-debug-passed.json').read_text());summary['regression_debug']=json.loads((W/'rooms-debug-passed.json').read_text());summary['patch_verification']={m:json.loads((W/f'patch-{m}-verification.json').read_text())for m in ['normal','debug']}
 (W/'verification-final.json').write_text(json.dumps(summary,indent=2));files['V87_Pruefungen.json']=json.dumps(summary,indent=2).encode()
import publish_ram_artifacts as pub
report=pub.publish(files,'V87 cumulative '+mode+' patch: reserve complete pause-menu workspace, preserve room actor headroom',prefix);(W/f'public-{mode}.json').write_text(json.dumps(report,indent=2));print('PATCH_PUBLIC',mode,report,flush=True)

from pathlib import Path
import os,sys,json,re,subprocess,struct,runpy
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];fd=int(rom.rsplit('/',1)[1]);case=os.environ.get('V87_CASE')or(W/'qa-case.txt').read_text().strip();sy=json.loads((W/f'all-symbols-{mode}.json').read_text())
if case=='release':
 import concurrent.futures,hashlib
 def run(sub):subprocess.run([sys.executable,__file__,rom,mode],pass_fds=(fd,),env=dict(os.environ,V87_CASE=sub),check=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,['batch','rooms','handheld']))
 (W/f'release-{mode}-passed.json').write_text(json.dumps(dict(rom_sha256=hashlib.sha256(Path(rom).read_bytes()).hexdigest(),menu_and_room_checks=True)));sys.exit(0)
if case=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit(0)
if case=='handheld':runpy.run_path(str(W/'handheld_qa.py'),run_name='__main__');sys.exit(0)
if case=='puzzle':
 subprocess.run([sys.executable,str(W/'rooms_qa.py'),rom,mode],pass_fds=(fd,),env=dict(os.environ,V86_QA_CASE='well-silver'),check=True);(W/f'puzzle-{mode}-passed.json').write_text(json.dumps(dict(silver_rupees=5,native_switch=31,gate_unbarred=True,no_redeads=True)));sys.exit(0)
if case=='rooms':
 subprocess.run([sys.executable,str(W/'rooms_qa.py'),rom,mode],pass_fds=(fd,),env=dict(os.environ,V86_QA_CASE='walk-cage'),check=True);subprocess.run([sys.executable,str(W/'rooms_qa.py'),rom,mode],pass_fds=(fd,),env=dict(os.environ,V86_QA_CASE='well-silver'),check=True);(W/f'rooms-{mode}-passed.json').write_text(json.dumps(['DD0->1 menu roundtrip, blue switch, door->3, Pieps and both Lizalfos','Well0->1->0->1 Velma/organs/silver rupees']));sys.exit(0)
if case=='batch':
 cases=['child-dd','child-well','adult-dd','adult-well','child-well-fra','adult-field','adult-field-fra']
 import concurrent.futures
 def one(sub):subprocess.run([sys.executable,__file__,rom,mode],pass_fds=(fd,),env=dict(os.environ,V87_CASE=sub),check=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(one,cases))
 (W/f'batch-{mode}-passed.json').write_text(json.dumps(cases));sys.exit(0)
base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text();old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text())
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);body=(W/'pause_body.c').read_text();runner=W/f'pause-{mode}-{case}';c=runner.with_suffix('.c');c.write_text(base[:a]+body+base[b:]);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
field='field'in case;well='well'in case;adult='adult'in case;age=0 if adult else 1;q=bytearray(Path('/workspace/zoras-erwachsen/boots-land.save'if adult else'/workspace/kokiri-speed-v66/child.save').read_bytes());entr=(O/'include/tables/entrance_table.h').read_text();e=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\('+('ENTR_HYRULE_FIELD_0'if field else'ENTR_BOTTOM_OF_THE_WELL_0'if well else'ENTR_DODONGOS_CAVERN_0')+r',',entr)[1],16)
struct.pack_into('>III',q,0,e,age,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,-3000 if field else 0 if well else 920,240 if well else 0,1600 if well else 1000 if field else -320,0,0xdff,e,0);q[0x1409]=2 if'fra'in case else 1;struct.pack_into('>HH',q,0x2e,0x140,0x140);scene=8 if well else 1;q[0xd4+scene*0x1c:0xd4+(scene+1)*0x1c]=bytes(0x1c);q[0x74]=0;q[0x75]=1;q[0x8c]=20;q[0x8d]=20;q[0x6b]=255;fixture=W/(case+'.save');fixture.write_bytes(q);log=W/f'{mode}-{case}.log'
with log.open('w')as f:r=subprocess.run([str(runner),rom,'pause-v87-'+mode+'-'+case+'-direct','2600','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(fixture)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=220)
assert r.returncode==0,(r.returncode,log.read_text()[-2400:]);print('PAUSE_CASE_PASSED',mode,case,flush=True)

static void capture_render(void){}
static unsigned hashbytes(unsigned p,unsigned n){unsigned h=2166136261;for(unsigned i=0;i<n;i++)h=(h^DebugMemRead8(p+i))*16777619;return h;}
static void onframe(unsigned f){
 static unsigned phase=0,mark=0,old=999,cycles=0,overrun=0;static float beforeY;
 unsigned v=0;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 need(DebugMemRead16(play+0xa4)==(strstr(scenario,"field")?0x51:strstr(scenario,"well")?8:1),"expected scene remains loaded during pause test");
 unsigned pc=play+0x10760,st=DebugMemRead16(pc+0x1d4),bankstart=r32(play+0x117a4),bankend=r32(play+0x117a8);
 if(st!=old){printf("PAUSE_STATE f=%u state=%u page=%u xyz=%.2f,%.2f,%.2f bg=%x bank=%x..%x\n",f,st,DebugMemRead16(pc+0x1e8),rf(player+0x24),rf(player+0x28),rf(player+0x2c),DebugMemRead16(player+0x88),bankstart,bankend);fflush(stdout);old=st;}
 if(phase==0&&f>400){v=0x10;phase=1;beforeY=rf(player+0x28);mark=f;}
 if(phase==1&&st==6){
  unsigned name=r32(pc+0x138),tail=((name+3584+15)&~15)+64*112;int excess=(int)(tail-bankend);
  printf("PAUSE_BOUNDS cycle=%u scratch_end=%x buffer_end=%x excess=%d\n",cycles,tail,bankend,excess);fflush(stdout);
  if(excess>0)overrun=1;
  if(!strstr(scenario,"before"))need(excess<=0,"pause scratch including coverage buffer fits object allocation");
  phase=2;mark=f;
 }
 if(phase==2){unsigned dt=f-mark;
  if(dt==0){DebugMemWrite16(pc+0x218,1);DebugMemWrite16(pc+0x222,1);DebugMemWrite16(pc+0x22c,0);DebugMemWrite16(pc+0x23e,1);DebugMemWrite16(pc+0x246,1);}
  if(dt==32)printf("EQUIP c_right=%u target=%u cursor=%u page=%u main=%u\n",DebugMemRead8(savebase+0x6b),DebugMemRead16(pc+0x24e),DebugMemRead16(pc+0x218),DebugMemRead16(pc+0x1e8),DebugMemRead16(pc+0x1e4));
  if(dt==8||dt==30)v=0x100; /* C-right: equip current item on the item page. */
  if(dt==75)v=0x10;
  if(dt>75&&st==0){phase=3;mark=f;}
 }
 if(phase==3&&f>mark+80){
  printf("RESUMED cycle=%u before_y=%.2f after_y=%.2f bg=%x\n",cycles,beforeY,rf(player+0x28),DebugMemRead16(player+0x88));fflush(stdout);
  if(strstr(scenario,"before")){need(overrun,"V86 pause overflow reproduced");puts("BASELINE_PAUSE_OVERFLOW_REPRODUCED");CoreDoCommand(M64CMD_STOP,0,NULL);return;}
  need(DebugMemRead8(savebase+0x6b)==1,"Deku nut equipped to C-right in native menu");
  need(fabsf(rf(player+0x28)-beforeY)<4.0f,"player remains on floor after closing inventory");bank();cycles++;
  if(cycles>=3){puts("PAUSE_ROUNDTRIP_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);return;}
  phase=0;
 }
 if(buttons)buttons(v);
 if(f>2200){puts("PAUSE_QA_TIMEOUT");exit(96);}
}

from pathlib import Path
import os,sys,json,re,subprocess,struct
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];fd=int(rom.rsplit('/',1)[1]);case=os.environ.get('V86_QA_CASE')or(W/'qa-case.txt').read_text().strip();sy=json.loads((W/f'all-symbols-{mode}.json').read_text())
if case=='final-batch':
 cases=['well-final','ddan-final','pieps','menu','title-loop','collapse']if mode=='normal'else['well-final','walk-cage','menu']
 for sub in cases:subprocess.run([sys.executable,__file__,rom,mode],pass_fds=(fd,),env=dict(os.environ,V86_QA_CASE=sub),check=True)
 (W/f'batch-{mode}-passed.json').write_text(json.dumps(cases));sys.exit(0)
if case in ['publish','pieps','collapse','menu','title-loop','walk-cage']:
 import runpy;runpy.run_path(str(W/('title_qa.py'if case in ['menu','collapse','title-loop']else case+'_qa.py'if case!='publish'else'deliver.py')),run_name='__main__');sys.exit(0)
if case=='stress':
 import runpy;runpy.run_path(str(W/'stress_qa.py'),run_name='__main__');sys.exit(0)
base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text();old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text())
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);body=(W/'rooms_body.c').read_text()
for m,n in [('ARENA','sZeldaArena'),('DENIED_O','gActorOverlayDeniedV68'),('DENIED_I','gActorInstanceDeniedV68'),('DENIED_L','gActorLastDeniedV68')]:body=body.replace(m,hex(sy[n]))
runner=W/f'qa-{mode}-{case}';c=runner.with_suffix('.c');c.write_text(base[:a]+body+base[b:]);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());text=(O/'include/tables/entrance_table.h').read_text();well='well'in case;e=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\('+('ENTR_BOTTOM_OF_THE_WELL_0'if well else'ENTR_DODONGOS_CAVERN_0')+r',',text)[1],16)
struct.pack_into('>III',q,0,e,1,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,-310 if well else 920,-100 if well else 0,-540 if well else -320,0,0xdff,e,0);q[0x1409]=1
# Preserve every puzzle's native switches/clear state at the start of this run.
scene=8 if well else 1
q[0xd4+scene*0x1c:0xd4+(scene+1)*0x1c]=bytes(0x1c)
# Begin room0 at the shaft, keep native room transitions active.
struct.pack_into('>HH',q,0x2e,0x140,0x140)
fixture=W/(case+'.save');fixture.write_bytes(q);logfile=W/f'{mode}-{case}.log'
with logfile.open('w')as log:r=subprocess.run([str(runner),rom,'room-v86-'+mode+'-'+case+'-direct','2200','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(fixture)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=log,stderr=subprocess.STDOUT,timeout=400)
assert r.returncode==0,(r.returncode,logfile.read_text()[-1800:]);print('ROOM_QA_FINISHED',mode,case,flush=True)

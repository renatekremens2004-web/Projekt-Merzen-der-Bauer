static void capture_render(void){}
static void onframe(unsigned f){
 unsigned v=0;static unsigned first=0;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 need(DebugMemRead16(play+0xa4)==0x55,"test remains in Kokiri Forest");
 if(f==375)photo(2160,150,450,2160,40,-100);
 if(f>=380&&f<440)position(player,2160,0,150.0f-(f-380)*10.0f,0);
 if(f>=440&&f<460)position(player,2160,0,-450,0);
 unsigned room=DebugMemRead8(play+0x11cbc),g=target(0x173,0x3f9f);
 if(f%30==0)printf("HANDHELD_ENTRY f=%u room=%u prev=%d g=%x xyz=%.1f %.1f %.1f\n",f,room,(signed char)DebugMemRead8(play+0x11cd0),g,rf(player+0x24),rf(player+0x28),rf(player+0x2c));
 if(room==1&&g&&!first)first=f;
 if(f==600)photo(1865,48,180,1800,4,130);
 if(f==650){bank();need(g&&r32(g+0x134),"Game Boy has a draw function after real room0-to1 transition");need(DebugMemRead16(g+0x10e)==(r32(savebase+4)?0x71ea:0x71eb),"age-correct handheld text");CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 if(f>700){bank();need(first&&g,"handheld persists after native room transition");puts("HANDHELD_ROOM_ENTRY_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(buttons)buttons(v);
}

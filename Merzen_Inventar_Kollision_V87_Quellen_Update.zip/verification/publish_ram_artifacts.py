
from pathlib import Path
import os,subprocess,zlib,hashlib,json,urllib.request,datetime,time
D=Path('/workspace/bean-download-delivery')
REPO='renatekremens2004-web/Projekt-Merzen-der-Bauer'
URL='https://github.com/'+REPO+'.git'
BRANCH='downloads/bean-proportionen'
fds=[];created=[]
def git(args,check=True):
 return subprocess.run(['git',*args],cwd=D,stdout=subprocess.PIPE,stderr=subprocess.PIPE,pass_fds=tuple(fds),check=check)
def api(path):
 req=urllib.request.Request('https://api.github.com/repos/'+REPO+path,headers={'User-Agent':'Codex-artifact-delivery','Accept':'application/vnd.github+json'})
 with urllib.request.urlopen(req,timeout=30)as r:return json.load(r)
def put(kind,data,expected=None):
 raw=kind.encode()+b' '+str(len(data)).encode()+b'\0'+data;oid=hashlib.sha1(raw).hexdigest()
 if expected:assert oid==expected,(kind,'public metadata hash mismatch')
 p=D/'.git/objects'/oid[:2]/oid[2:]
 if p.exists():
  assert git(['cat-file','-t',oid]).stdout.decode().strip()==kind
  return oid
 assert p.parent.is_dir(),'Missing existing object directory'
 if kind in ('commit','tree'):
  p.write_bytes(zlib.compress(raw));return oid
 fd=os.memfd_create('git-'+kind);os.write(fd,zlib.compress(raw));fds.append(fd)
 p.symlink_to('/proc/self/fd/'+str(fd));created.append(p)
 return oid
def ensure_commit(oid):
 r=git(['cat-file','commit',oid],False)
 if not r.returncode:return r.stdout
 c=api('/git/commits/'+oid)
 def ident(x):
  epoch=int(datetime.datetime.fromisoformat(x['date'].replace('Z','+00:00')).timestamp())
  return f"{x['name']} <{x['email']}> {epoch} +0000"
 raw=('tree '+c['tree']['sha']+'\n'+''.join('parent '+p['sha']+'\n'for p in c['parents'])+'author '+ident(c['author'])+'\ncommitter '+ident(c['committer'])+'\n\n'+c['message']).encode()
 put('commit',raw,oid)
 for parent in c['parents']:
  if git(['cat-file','-e',parent['sha']],False).returncode:ensure_commit(parent['sha'])
 return raw
def ensure_tree(oid):
 r=git(['cat-file','tree',oid],False)
 if not r.returncode:return r.stdout
 t=api('/git/trees/'+oid);assert not t.get('truncated',False)
 items=sorted(t['tree'],key=lambda x:(x['path']+('/'if x['mode']=='040000'else'')).encode())
 raw=b''.join((x['mode'].lstrip('0')+' '+x['path']).encode()+b'\0'+bytes.fromhex(x['sha'])for x in items)
 put('tree',raw,oid);return raw
def _publish(files,message,prefix=''):
 head=git(['ls-remote',URL,'refs/heads/'+BRANCH]).stdout.decode().split()[0]
 commit=ensure_commit(head);tree_id=commit.split(b'\n',1)[0].split()[1].decode()
 raw=ensure_tree(tree_id);entries={};at=0
 while at<len(raw):
  space=raw.index(b' ',at);nul=raw.index(b'\0',space)
  mode=raw[at:space];name=raw[space+1:nul];oid=raw[nul+1:nul+21];entries[name]=(mode,oid);at=nul+21
 if prefix:
  with urllib.request.urlopen('https://raw.githubusercontent.com/'+REPO+'/'+head+'/README.md',timeout=30)as r:prior=r.read()
  files['README.md']=prefix.encode()+prior
 for name,data in files.items():entries[name.encode()]=(b'100644',bytes.fromhex(put('blob',data)))
 raw=b''.join(mode+b' '+name+b'\0'+oid for name,(mode,oid) in sorted(entries.items(),key=lambda x:x[0]+(b'/'if x[1][0]==b'40000'else b'')))
 tree=put('tree',raw)
 name=git(['config','user.name']).stdout.decode().strip().replace('\n',' ')
 email=git(['config','user.email']).stdout.decode().strip().replace('\n','')
 stamp=str(int(time.time()));who=f'{name} <{email}> {stamp} +0000'
 raw=('tree '+tree+'\nparent '+head+'\nauthor '+who+'\ncommitter '+who+'\n\n'+message).encode()
 new=put('commit',raw)
 result=git(['push',URL,new+':refs/heads/'+BRANCH],False)
 remote=git(['ls-remote',URL,'refs/heads/'+BRANCH]).stdout.decode().split()[0]
 if remote!=new:raise RuntimeError(result.stderr.decode()[-1200:])
 report={'commit':new,'files':[]}
 for name,data in files.items():
  url='https://raw.githubusercontent.com/'+REPO+'/'+new+'/'+name
  h=hashlib.sha256()
  with urllib.request.urlopen(url,timeout=30)as r:
   while b:=r.read(1048576):h.update(b)
  assert h.hexdigest()==hashlib.sha256(data).hexdigest()
  report['files'].append({'name':name,'url':url,'bytes':len(data),'verified':True})
 return report


def publish(files,message,prefix=''):
 import fcntl
 with open('/workspace/pieps-v79/artifact-publish.lock','a')as guard:
  fcntl.flock(guard,fcntl.LOCK_EX)
  try:return _publish(files,message,prefix)
  finally:
   for p in created:p.unlink(missing_ok=True)
   for n in fds:os.close(n)
   created.clear();fds.clear()

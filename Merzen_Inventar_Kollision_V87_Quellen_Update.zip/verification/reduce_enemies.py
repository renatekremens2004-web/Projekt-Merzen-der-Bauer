from pathlib import Path
import re,shutil,json
O=Path('/workspace/oot-burns-pal');W=Path(__file__).resolve().parent
jobs=[('ddan',0,{'ACTOR_EN_FIREFLY':2,'ACTOR_EN_VM':2}),('ddan',1,{'ACTOR_EN_FIREFLY':2}),('HAKAdanCH',1,{'ACTOR_EN_RD':2})];report=[]
for folder,room,remove in jobs:
 d=O/f'extracted/pal-1.0/assets/scenes/dungeons/{folder}';p=next(d.glob(f'{folder}_room_{room}_*ActorEntryList.inc.c'));header=d/f'{folder}_room_{room}.h'
 for f in [p,header]:
  b=W/'original'/f.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
  if not b.exists():shutil.copy2(f,b)
 counts={k:0 for k in remove}
 def repl(m):
  block=m[0]
  for k,n in remove.items():
   if re.search(r'\b'+k+r'\b',block)and counts[k]<n:counts[k]+=1;return''
  return block
 s=re.sub(r'^    \{\n.*?^    \}, // \d+\n',repl,p.read_text(),flags=re.M|re.S);assert counts==remove,(p,counts);p.write_text(s)
 h=header.read_text();sym='LENGTH_'+p.name.removesuffix('.inc.c');a=re.search(r'#define '+sym+r' (\d+)',h);assert a
 old=int(a[1]);new=old-sum(counts.values());header.write_text(h.replace(a[0],f'#define {sym} {new}'))
 report.append(dict(file=str(p.relative_to(O)),removed=counts,before=old,after=new))
(W/'enemy-reduction.json').write_text(json.dumps(report,indent=2));print(report)

#ifndef FAST_RUN_V66_H
#define FAST_RUN_V66_H
/* Two reserved mod bits adjacent to the existing tunic bits 1CD..1CF. */
#define FAST_RUN_UNLOCK_FLAG 0x1CC
#define FAST_RUN_ACTIVE_FLAG 0x1CB
#define FAST_RUN_UNLOCKED() GET_INFTABLE(FAST_RUN_UNLOCK_FLAG)
#define FAST_RUN_ACTIVE() (FAST_RUN_UNLOCKED() && GET_INFTABLE(FAST_RUN_ACTIVE_FLAG))
#endif

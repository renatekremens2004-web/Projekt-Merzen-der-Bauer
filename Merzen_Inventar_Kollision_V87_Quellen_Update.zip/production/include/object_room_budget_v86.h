#ifndef OBJECT_ROOM_BUDGET_V86_H
#define OBJECT_ROOM_BUDGET_V86_H
typedef struct ObjectBudgetGroupV86 { const s16* ids; u32 count; } ObjectBudgetGroupV86;
typedef struct ObjectBudgetSceneV86 { s16 sceneId; const s16* keeps; u32 keepCount; const ObjectBudgetGroupV86* groups; u32 groupCount; } ObjectBudgetSceneV86;
static const s16 sBudgetIdsV86_1_0[] = {OBJECT_AM, OBJECT_BOMBF, OBJECT_BOX, OBJECT_BWALL, OBJECT_DDAN_OBJECTS, OBJECT_DODOJR, OBJECT_DODONGO, OBJECT_FIREFLY, OBJECT_KUSA, OBJECT_SYOKUDAI, OBJECT_TRAP, OBJECT_VM};
static const s16 sBudgetIdsV86_1_1[] = {OBJECT_AM, OBJECT_BOMBF, OBJECT_BOX, OBJECT_BWALL, OBJECT_DDAN_OBJECTS, OBJECT_DODOJR, OBJECT_FIREFLY, OBJECT_GI_HEART, OBJECT_GS, OBJECT_KA, OBJECT_KUSA, OBJECT_SHOPNUTS, OBJECT_ST, OBJECT_TRAP, OBJECT_VM};
static const s16 sBudgetIdsV86_1_2[] = {OBJECT_AM, OBJECT_BOMBF, OBJECT_BOX, OBJECT_BWALL, OBJECT_DDAN_OBJECTS, OBJECT_DODOJR, OBJECT_FIREFLY, OBJECT_GI_SOUL, OBJECT_GS, OBJECT_KA, OBJECT_KUSA, OBJECT_SHOPNUTS, OBJECT_ST, OBJECT_TRAP, OBJECT_VM};
static const s16 sBudgetIdsV86_1_3[] = {OBJECT_AM, OBJECT_BWALL, OBJECT_DDAN_OBJECTS, OBJECT_FIREFLY, OBJECT_GI_SUTARU, OBJECT_ST, OBJECT_SYOKUDAI};
static const s16 sBudgetIdsV86_1_4[] = {OBJECT_BOMBF, OBJECT_BWALL, OBJECT_DDAN_OBJECTS, OBJECT_GI_SUTARU, OBJECT_ST};
static const s16 sBudgetIdsV86_1_5[] = {OBJECT_BOX, OBJECT_BWALL, OBJECT_DDAN_OBJECTS, OBJECT_FIREFLY, OBJECT_KUSA, OBJECT_SHOPNUTS, OBJECT_SYOKUDAI};
static const s16 sBudgetIdsV86_1_6[] = {OBJECT_BWALL, OBJECT_DDAN_OBJECTS, OBJECT_GI_HEART, OBJECT_ZF};
static const s16 sBudgetKeepsV86_1[] = {OBJECT_GAMEPLAY_DANGEON_KEEP};
static const ObjectBudgetGroupV86 sBudgetGroupsV86_1[] = {
    { sBudgetIdsV86_1_0, ARRAY_COUNT(sBudgetIdsV86_1_0) },
    { sBudgetIdsV86_1_1, ARRAY_COUNT(sBudgetIdsV86_1_1) },
    { sBudgetIdsV86_1_2, ARRAY_COUNT(sBudgetIdsV86_1_2) },
    { sBudgetIdsV86_1_3, ARRAY_COUNT(sBudgetIdsV86_1_3) },
    { sBudgetIdsV86_1_4, ARRAY_COUNT(sBudgetIdsV86_1_4) },
    { sBudgetIdsV86_1_5, ARRAY_COUNT(sBudgetIdsV86_1_5) },
    { sBudgetIdsV86_1_6, ARRAY_COUNT(sBudgetIdsV86_1_6) },
};
static const s16 sBudgetIdsV86_8_0[] = {OBJECT_BB, OBJECT_BOMBIWA, OBJECT_BOX, OBJECT_EFC_FLASH, OBJECT_FIREFLY, OBJECT_GI_CLOTHES, OBJECT_GI_SHIELD_1, OBJECT_GI_SHIELD_2, OBJECT_GI_SUTARU, OBJECT_HAKACH_OBJECTS, OBJECT_HAKA_DOOR, OBJECT_KUSA, OBJECT_RR, OBJECT_SHAGGY, OBJECT_ST, OBJECT_WALLMASTER};
static const s16 sBudgetIdsV86_8_1[] = {OBJECT_BOMBF, OBJECT_BOMBIWA, OBJECT_BOX, OBJECT_DH, OBJECT_EFC_FLASH, OBJECT_HAKACH_OBJECTS, OBJECT_HAKA_DOOR, OBJECT_KUSA, OBJECT_RD, OBJECT_SYOKUDAI, OBJECT_VELMA};
static const s16 sBudgetIdsV86_8_2[] = {OBJECT_BOMBF, OBJECT_BOMBIWA, OBJECT_BOX, OBJECT_EFC_FLASH, OBJECT_FIREFLY, OBJECT_FRED, OBJECT_GI_SUTARU, OBJECT_HAKACH_OBJECTS, OBJECT_HAKA_DOOR, OBJECT_KUSA, OBJECT_ST};
static const s16 sBudgetIdsV86_8_3[] = {OBJECT_BOX, OBJECT_EFC_FLASH, OBJECT_FIREFLY, OBJECT_HAKACH_OBJECTS, OBJECT_HAKA_DOOR, OBJECT_VM};
static const s16 sBudgetIdsV86_8_4[] = {OBJECT_DAPHNE, OBJECT_FIREFLY, OBJECT_GI_HEART, OBJECT_HAKACH_OBJECTS, OBJECT_HAKA_DOOR, OBJECT_RD, OBJECT_SYOKUDAI};
static const s16 sBudgetIdsV86_8_5[] = {OBJECT_DEKUBABA, OBJECT_GI_SUTARU, OBJECT_HAKACH_OBJECTS, OBJECT_HAKA_DOOR, OBJECT_SCOOBY, OBJECT_ST};
static const s16 sBudgetKeepsV86_8[] = {OBJECT_GAMEPLAY_DANGEON_KEEP};
static const ObjectBudgetGroupV86 sBudgetGroupsV86_8[] = {
    { sBudgetIdsV86_8_0, ARRAY_COUNT(sBudgetIdsV86_8_0) },
    { sBudgetIdsV86_8_1, ARRAY_COUNT(sBudgetIdsV86_8_1) },
    { sBudgetIdsV86_8_2, ARRAY_COUNT(sBudgetIdsV86_8_2) },
    { sBudgetIdsV86_8_3, ARRAY_COUNT(sBudgetIdsV86_8_3) },
    { sBudgetIdsV86_8_4, ARRAY_COUNT(sBudgetIdsV86_8_4) },
    { sBudgetIdsV86_8_5, ARRAY_COUNT(sBudgetIdsV86_8_5) },
};
static const ObjectBudgetSceneV86 sObjectBudgetScenesV86[] = {
    { SCENE_DODONGOS_CAVERN, sBudgetKeepsV86_1, ARRAY_COUNT(sBudgetKeepsV86_1), sBudgetGroupsV86_1, ARRAY_COUNT(sBudgetGroupsV86_1) },
    { SCENE_BOTTOM_OF_THE_WELL, sBudgetKeepsV86_8, ARRAY_COUNT(sBudgetKeepsV86_8), sBudgetGroupsV86_8, ARRAY_COUNT(sBudgetGroupsV86_8) },
};
static u32 Scene_ObjectBytesV86(s16 id) {
    if (id == OBJECT_INVALID) return 0;
    return ALIGN16(gObjectTable[id].vromEnd - gObjectTable[id].vromStart);
}
/* The object bank is also the pause menu's temporary model/icon/coverage area.
 * Keep its largest live extent, including alignment and an 8 KiB guard, even if
 * the dungeon's ordinary object lists are smaller. Language may change without
 * reloading the scene, so reserve the largest PAL icon-language segment. */
static u32 Scene_PauseSpaceV87(PlayState* play) {
    u32 language = MAX((uintptr_t)_icon_item_nes_staticSegmentRomEnd - (uintptr_t)_icon_item_nes_staticSegmentRomStart,
                       (uintptr_t)_icon_item_ger_staticSegmentRomEnd - (uintptr_t)_icon_item_ger_staticSegmentRomStart);
    u32 size;
    u32 keepPeak;
    u32 alternate;
    /* Match the native pause menu's dungeon-icon selection. */
    s32 dungeon = (play->sceneId >= SCENE_DEKU_TREE && play->sceneId <= SCENE_ICE_CAVERN) ||
                  (play->sceneId >= SCENE_DEKU_TREE_BOSS && play->sceneId <= SCENE_SHADOW_TEMPLE_BOSS);
    alternate = dungeon ? ((uintptr_t)_icon_item_dungeon_staticSegmentRomEnd - (uintptr_t)_icon_item_dungeon_staticSegmentRomStart)
                        : ((uintptr_t)_icon_item_field_staticSegmentRomEnd - (uintptr_t)_icon_item_field_staticSegmentRomStart);
    language = MAX(language, (uintptr_t)_icon_item_fra_staticSegmentRomEnd - (uintptr_t)_icon_item_fra_staticSegmentRomStart);
    size = PAUSE_PLAYER_SEGMENT_TOTAL_SIZE(Scene_ObjectBytesV86(gLinkObjectIds[gSaveContext.save.linkAge]));
    size = ALIGN16(size) + ((uintptr_t)_icon_item_staticSegmentRomEnd - (uintptr_t)_icon_item_staticSegmentRomStart);
    size = ALIGN16(size) + ((uintptr_t)_icon_item_24_staticSegmentRomEnd - (uintptr_t)_icon_item_24_staticSegmentRomStart);
    size = ALIGN16(size) + alternate;
    size = ALIGN16(size) + language;
    size = ALIGN16(size) + MAX(MAP_NAME_TEX1_SIZE, ITEM_NAME_TEX_SIZE) + MAP_NAME_TEX2_SIZE;
    size = ALIGN16(size) + PAUSE_EQUIP_PLAYER_WIDTH * PAUSE_EQUIP_PLAYER_HEIGHT;
    /* InitPauseDrawData briefly DMA-loads the complete gameplay_keep. */
    keepPeak = PAUSE_PLAYER_SEGMENT_RENDER_TEXTURE_SIZE + Scene_ObjectBytesV86(OBJECT_GAMEPLAY_KEEP);
    return ALIGN16(MAX(size, keepPeak)) + 0x40 + 0x2000;
}
static u32 Scene_DungeonObjectSpaceV86(PlayState* play, u32 original) {
    const ObjectBudgetSceneV86* scene = NULL;
    u32 i, j, size, maximum = 0, keepMaximum = 0;
    if (gSaveContext.gameMode != GAMEMODE_NORMAL || gSaveContext.sceneLayer > 3) return original;
    for (i = 0; i < ARRAY_COUNT(sObjectBudgetScenesV86); i++) {
        if (sObjectBudgetScenesV86[i].sceneId == play->sceneId) { scene = &sObjectBudgetScenesV86[i]; break; }
    }
    /* Also protect the older adult Hyrule Field model-space reduction. */
    if (scene == NULL) return MAX(original, (Scene_PauseSpaceV87(play) + 0xFFF) & ~0xFFF);
    for (i = 0; i < scene->groupCount; i++) {
        size = 0;
        for (j = 0; j < scene->groups[i].count; j++) size += Scene_ObjectBytesV86(scene->groups[i].ids[j]);
        if (size > maximum) maximum = size;
    }
    for (i = 0; i < scene->keepCount; i++) {
        size = Scene_ObjectBytesV86(scene->keeps[i]);
        if (size > keepMaximum) keepMaximum = size;
    }
    maximum += Scene_ObjectBytesV86(OBJECT_GAMEPLAY_KEEP) + keepMaximum +
               Scene_ObjectBytesV86(gLinkObjectIds[gSaveContext.save.linkAge]);
    maximum = MAX(maximum + 0x8000, Scene_PauseSpaceV87(play));
    maximum = (maximum + 0xFFF) & ~0xFFF;
    return maximum < original ? maximum : original;
}
#endif

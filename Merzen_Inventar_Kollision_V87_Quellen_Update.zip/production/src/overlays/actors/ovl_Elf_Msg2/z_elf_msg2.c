/*
 * File: z_elf_msg2.c
 * Overlay: ovl_Elf_Msg2
 * Description: Targetable Navi check spot
 */

#include "z_elf_msg2.h"
#include "array_count.h"

#include "gfx.h"
#include "gfx_setupdl.h"
#include "ichain.h"
#include "printf.h"
#include "regs.h"
#include "sys_matrix.h"
#include "terminal.h"
#include "translation.h"
#include "play_state.h"
#include "player.h"
#include "object.h"
#include "save.h"
#include "segmented_address.h"
#include "z_lib.h"
#include "libc/math.h"

/* Segmented room-3 display list; no console assets in this overlay. */
extern Gfx gNintendo64DL[];
extern Gfx gMajoraMaskDL[];
static void ElfMsg2_DrawMajoraMask(Actor* thisx, PlayState* play);

static void ElfMsg2_DrawNintendo64(Actor* thisx, PlayState* play);

#define FLAGS ACTOR_FLAG_UPDATE_CULLING_DISABLED

void ElfMsg2_Init(Actor* thisx, PlayState* play);
void ElfMsg2_Destroy(Actor* thisx, PlayState* play);
void ElfMsg2_Update(Actor* thisx, PlayState* play);
#if DEBUG_ASSETS
void ElfMsg2_Draw(Actor* thisx, PlayState* play);
#endif

s32 ElfMsg2_GetMessageId(ElfMsg2* this);
void ElfMsg2_WaitUntilActivated(ElfMsg2* this, PlayState* play);
void ElfMsg2_WaitForTextRead(ElfMsg2* this, PlayState* play);

ActorProfile Elf_Msg2_Profile = {
    /**/ ACTOR_ELF_MSG2,
    /**/ ACTORCAT_BG,
    /**/ FLAGS,
    /**/ OBJECT_GAMEPLAY_KEEP,
    /**/ sizeof(ElfMsg2),
    /**/ ElfMsg2_Init,
    /**/ ElfMsg2_Destroy,
    /**/ ElfMsg2_Update,
#if DEBUG_ASSETS
    /**/ ElfMsg2_Draw,
#else
    /**/ NULL,
#endif
};

static InitChainEntry sInitChain[] = {
    ICHAIN_VEC3F_DIV1000(scale, 200, ICHAIN_CONTINUE),
    ICHAIN_F32(cullingVolumeDistance, 1000, ICHAIN_STOP),
};

void ElfMsg2_SetupAction(ElfMsg2* this, ElfMsg2ActionFunc actionFunc) {
    this->actionFunc = actionFunc;
}

/**
 * Checks a scene flag - if flag is set, the actor is killed and function returns 1. Otherwise returns 0.
 * Can also set a switch flag from params while killing.
 */
s32 ElfMsg2_KillCheck(ElfMsg2* this, PlayState* play) {
    if ((this->actor.world.rot.y > 0) && (this->actor.world.rot.y < 0x41) &&
        Flags_GetSwitch(play, this->actor.world.rot.y - 1)) {
        LOG_STRING_T("共倒れ", "Mutual destruction", "../z_elf_msg2.c", 171);
        if (PARAMS_GET_U(this->actor.params, 8, 6) != 0x3F) {
            Flags_SetSwitch(play, PARAMS_GET_U(this->actor.params, 8, 6));
        }
        Actor_Kill(&this->actor);
        return 1;
    } else if ((this->actor.world.rot.y == -1) && Flags_GetClear(play, this->actor.room)) {
        LOG_STRING_T("共倒れ２", "Mutual destruction 2", "../z_elf_msg2.c", 182);
        if (PARAMS_GET_U(this->actor.params, 8, 6) != 0x3F) {
            Flags_SetSwitch(play, PARAMS_GET_U(this->actor.params, 8, 6));
        }
        Actor_Kill(&this->actor);
        return 1;
    } else if (PARAMS_GET_U(this->actor.params, 8, 6) == 0x3F) {
        return 0;
    } else if (Flags_GetSwitch(play, PARAMS_GET_U(this->actor.params, 8, 6))) {
        LOG_STRING_T("共倒れ", "Mutual destruction", "../z_elf_msg2.c", 192);
        Actor_Kill(&this->actor);
        return 1;
    }
    return 0;
}

/* Dedicated mode only. All ordinary Elf_Msg2 objects keep their native actions. */
extern Gfx gWallaceDL[];
static ColliderCylinderInit sWallaceCylinderInit = {
    { COL_MATERIAL_NONE, AT_NONE, AC_NONE, OC1_ON | OC1_TYPE_ALL, OC2_TYPE_1, COLSHAPE_CYLINDER },
    { ELEM_MATERIAL_UNK0,
      { 0, HIT_SPECIAL_EFFECT_NONE, 0 }, { 0, HIT_BACKLASH_NONE, 0 },
      ATELEM_NONE, ACELEM_NONE, OCELEM_ON },
    { 16, 82, 0, { 0, 0, 0 } },
};

static s32 ElfMsg2_IsWallace(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_DODONGOS_CAVERN && actor->room == 2 && actor->params == 0x3F9A;
}

static void ElfMsg2_DrawWallace(Actor* actor, PlayState* play) {
    static Vec3f pivots[4] = { {0,0,0}, {0,6851,-275}, {918,6186,-574}, {-918,6186,-574} };
    void* roomSegment = NULL;
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 520));
    f32 gesture = Math_SinS((s16)(play->gameplayFrames * 970));
    if (play->roomCtx.curRoom.num == actor->room) roomSegment = play->roomCtx.curRoom.segment;
    else if (play->roomCtx.prevRoom.num == actor->room) roomSegment = play->roomCtx.prevRoom.segment;
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "wallace", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateX(idle * 0.025f, MTXMODE_APPLY);
        else if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.025f : -0.025f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(gesture * 0.06f, MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i], "wallace", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gWallaceDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "wallace", 3);
}

static void ElfMsg2_InitWallace(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    /* Initialization precedes removal, so the destroy path is valid for adults too. */
    if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x019A;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 22);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    Actor_SetFocus(actor, 75);
    actor->draw = ElfMsg2_DrawWallace;
}

static void ElfMsg2_UpdateWallace(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 75);
    actor->textId = 0x019A;
    if (!Actor_TalkOfferAccepted(actor, play)) {
        if (actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
            Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
            Actor_OfferTalk(actor, play, 115.0f);
        }
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Private Water Temple modes. Assets live in the native room segment, not object slots. */
extern Gfx gPepsimanDL[];
extern Gfx gPepsiCanRoom7DL[];
extern Gfx gPepsiCanRoom9DL[];
extern Gfx gPepsiCanRoom16DL[];
extern Gfx gPepsiCrushedRoom16DL[];
extern Gfx gPepsiCanRoom17DL[];
extern Gfx gPepsiCanRoom19DL[];

static s32 ElfMsg2_IsPepsiman(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_WATER_TEMPLE && actor->room == 16 && actor->params == 0x3F72;
}
static s32 ElfMsg2_IsPepsiCan(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_WATER_TEMPLE &&
        (actor->params == 0x3F73 || actor->params == 0x3F74) &&
        (actor->room == 7 || actor->room == 9 || actor->room == 16 || actor->room == 17 || actor->room == 19);
}
static void* ElfMsg2_PepsiRoom(Actor* actor, PlayState* play) {
    if (play->roomCtx.curRoom.num == actor->room) return play->roomCtx.curRoom.segment;
    if (play->roomCtx.prevRoom.num == actor->room) return play->roomCtx.prevRoom.segment;
    return NULL;
}
static void ElfMsg2_DrawPepsiman(Actor* actor, PlayState* play) {
    static Vec3f pivots[4] = { {0,6313,0}, {0,8280,0}, {-1242,7918,-311}, {1242,7918,-311} };
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 430));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1100));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "pepsiman", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.035f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.025f : -0.025f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.07f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "pepsiman", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gPepsimanDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "pepsiman", 3);
}
static void ElfMsg2_DrawPepsiCan(Actor* actor, PlayState* play) {
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Gfx* dl = NULL;
    if (roomSegment == NULL) return;
    switch (actor->room) {
        case 7: dl = gPepsiCanRoom7DL; break;
        case 9: dl = gPepsiCanRoom9DL; break;
        case 16: dl = actor->params == 0x3F74 ? gPepsiCrushedRoom16DL : gPepsiCanRoom16DL; break;
        case 17: dl = gPepsiCanRoom17DL; break;
        case 19: dl = gPepsiCanRoom19DL; break;
    }
    if (dl == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "pepsi-can", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "pepsi-can", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, dl);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "pepsi-can", 3);
}
static void ElfMsg2_InitPepsiman(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x3072;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 17);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 14;
    this->wallaceCollider.dim.height = 94;
    Actor_SetFocus(actor, 82);
    actor->draw = ElfMsg2_DrawPepsiman;
}
static void ElfMsg2_UpdatePepsiman(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 82);
    actor->textId = 0x3072;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 115.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Two independent, room-local guests. */
extern Gfx gShrekDL[];
extern Gfx gMonopolyDL[];
static s32 ElfMsg2_IsDoofGuest(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_LOST_WOODS && actor->room == 3 && actor->params == 0x3F90) ||
        (play->sceneId == SCENE_INSIDE_GANONS_CASTLE && actor->room == 1 && actor->params == 0x3F91);
}
static void ElfMsg2_DrawDoofGuest(Actor* actor, PlayState* play) {
    static s16 objects[2] = { OBJECT_SHREK, OBJECT_MONOPOLY };
    static Gfx* lists[2] = { gShrekDL, gMonopolyDL };
    static Vec3f pivots[2][4] = { {{0,0,0},{0,6549,0},{-2415,6334,0},{2415,6334,0}},{{0,0,0},{0,4799,0},{-1208,4676,0},{1208,4676,0}} };
    s32 index = actor->params - 0x3F90;
    s32 slot = Object_GetSlot(&play->objectCtx, objects[index]);
    s32 speaking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 330 + index * 12000));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 900));
    Mtx* matrices;
    s32 i;
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "doof_guests", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Vec3f* pivot = &pivots[index][i];
        Matrix_Push();
        Matrix_RotateZ(idle * 0.003f, MTXMODE_APPLY);
        Matrix_Translate(pivot->x, pivot->y, pivot->z, MTXMODE_APPLY);
        if (i == 1) {
            Matrix_RotateY(idle * 0.012f, MTXMODE_APPLY);
            Matrix_RotateX(speaking ? talk * 0.018f : idle * 0.006f, MTXMODE_APPLY);
        } else if (i >= 2) {
            Matrix_RotateZ((i == 2 ? 1 : -1) * (idle * 0.006f +
                (speaking ? talk * 0.025f : 0)), MTXMODE_APPLY);
        }
        Matrix_Translate(-pivot->x, -pivot->y, -pivot->z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "doof_guests", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, lists[index]);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    CLOSE_DISPS(play->state.gfxCtx, "doof_guests", 3);
}
static void ElfMsg2_InitDoofGuest(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 index = actor->params - 0x3F90;
    static f32 heights[2] = { 70, 53 };
    static s16 radii[2] = { 19, 12 };
    Collider_InitCylinder(play, &this->wallaceCollider);
    if ((index == 0 && LINK_IS_ADULT) || (index == 1 && LINK_IS_CHILD) ||
        gSaveContext.language != LANGUAGE_GER) { Actor_Kill(actor); return; }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = index ? 0x71DB : 0x71DA;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1600;
    actor->cullingVolumeScale = 140;
    actor->cullingVolumeDownward = 110;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, radii[index]);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = radii[index];
    this->wallaceCollider.dim.height = heights[index];
    Actor_SetFocus(actor, heights[index]);
    actor->draw = ElfMsg2_DrawDoofGuest;
}
static void ElfMsg2_UpdateDoofGuest(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 index = actor->params - 0x3F90;
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1) actor->world.pos.y = actor->floorHeight;
    }
    Actor_SetFocus(actor, index ? 53 : 70);
    Math_SmoothStepToS(&actor->shape.rot.y,
        play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE ?
        actor->yawTowardsPlayer : actor->home.rot.y, 6, 0x300, 1);
    if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE &&
        !Player_InCsMode(play) && Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
        actor->xzDistToPlayer < 140 && fabsf(actor->yDistToPlayer) < 55) Actor_OfferTalk(actor, play, 125);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Small own-proportion guests, scoped to three adult rooms. */
extern Gfx gMeowthDL[];
extern Gfx gJimmyDL[];
extern Gfx gMackeyDL[];
static s32 ElfMsg2_IsDesertGuest(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_SPIRIT_TEMPLE && actor->room == 19 && actor->params == 0x3F8D) ||
        (play->sceneId == SCENE_KAKARIKO_CENTER_GUEST_HOUSE && actor->room == 0 && actor->params == 0x3F8F);
}
static void ElfMsg2_DrawDesertGuest(Actor* actor, PlayState* play) {
    static s16 objects[3] = { OBJECT_MEOWTH, OBJECT_JIMMY, OBJECT_MACKEY };
    static Gfx* lists[3] = { gMeowthDL, gJimmyDL, gMackeyDL };
    static Vec3f pivots[3][4] = { {{0,0,0},{-1,1190,0},{-249,942,0},{247,942,0}},{{0,0,0},{-41,2527,0},{-457,2198,0},{375,2198,0}},{{0,0,0},{0,4194,0},{-610,3889,0},{610,3889,0}} };
    s32 index = actor->params - 0x3F8D;
    s32 slot = Object_GetSlot(&play->objectCtx, objects[index]);
    s32 speaking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 360 + index * 9000));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 900));
    Mtx* matrices;
    s32 i;
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "desert_guests", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Vec3f* pivot = &pivots[index][i];
        Matrix_Push();
        Matrix_RotateZ(idle * 0.004f, MTXMODE_APPLY);
        Matrix_Translate(pivot->x, pivot->y, pivot->z, MTXMODE_APPLY);
        if (i == 1) {
            Matrix_RotateY(idle * 0.018f, MTXMODE_APPLY);
            Matrix_RotateX(speaking ? talk * 0.024f : idle * 0.008f, MTXMODE_APPLY);
        } else if (i >= 2) {
            Matrix_RotateZ((i == 2 ? 1 : -1) * (idle * 0.008f +
                (speaking ? talk * (index == 1 ? 0.045f : 0.03f) : 0)), MTXMODE_APPLY);
        }
        Matrix_Translate(-pivot->x, -pivot->y, -pivot->z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "desert_guests", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, lists[index]);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "desert_guests", 3);
}
static void ElfMsg2_InitDesertGuest(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 heights[3] = { 19, 40, 65 };
    static s16 radii[3] = { 7, 10, 13 };
    s32 index = actor->params - 0x3F8D;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) { Actor_Kill(actor); return; }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71C3 + index;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1600;
    actor->cullingVolumeScale = 120;
    actor->cullingVolumeDownward = 100;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, radii[index]);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = radii[index];
    this->wallaceCollider.dim.height = heights[index];
    Actor_SetFocus(actor, heights[index]);
    actor->draw = ElfMsg2_DrawDesertGuest;
}
static void ElfMsg2_UpdateDesertGuest(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 heights[3] = { 19, 40, 65 };
    s32 index = actor->params - 0x3F8D;
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1) actor->world.pos.y = actor->floorHeight;
    }
    Actor_SetFocus(actor, heights[index]);
    actor->textId = 0x71C3 + index;
    Math_SmoothStepToS(&actor->shape.rot.y,
        play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE ?
        actor->yawTowardsPlayer : actor->home.rot.y, 6, 0x300, 1);
    if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE &&
        !Player_InCsMode(play) && Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
        actor->xzDistToPlayer < 140 && fabsf(actor->yDistToPlayer) < 55) Actor_OfferTalk(actor, play, 125);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Parked van: only the child day/night spawn lists contain this prop. */
extern Gfx gMysteryMachineDL[];
static s32 ElfMsg2_IsMysteryMachine(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_KAKARIKO_VILLAGE && actor->room == 0 && actor->params == 0x3F8C;
}
static s32 ElfMsg2_MysteryMachineVisible(void) {
    /* Permanent song ownership survives time travel; transient windmill flags do not. */
    return LINK_IS_CHILD && CHECK_QUEST_ITEM(QUEST_SONG_STORMS);
}
static void ElfMsg2_DrawMysteryMachine(Actor* actor, PlayState* play) {
    void* room = play->roomCtx.curRoom.segment;
    if (!ElfMsg2_MysteryMachineVisible() || room == NULL || play->roomCtx.curRoom.num != 0) return;
    OPEN_DISPS(play->state.gfxCtx, "mystery_machine", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "mystery_machine", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, room);
    gSPDisplayList(POLY_OPA_DISP++, gMysteryMachineDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "mystery_machine", 3);
}
static void ElfMsg2_InitMysteryMachine(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    if (!ElfMsg2_MysteryMachineVisible()) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_PROP);
    actor->flags = 0;
    actor->textId = 0;
    actor->cullingVolumeDistance = 2000;
    actor->cullingVolumeScale = 180;
    actor->cullingVolumeDownward = 120;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 35);
    actor->draw = ElfMsg2_DrawMysteryMachine;
    /* Flat native verge verified at all four wheel positions; no moving collider,
     * enemy collision, talk sequence or changes to scene collision/pathfinding. */
}
static void ElfMsg2_UpdateMysteryMachine(ElfMsg2* this, PlayState* play) {
    if (!ElfMsg2_MysteryMachineVisible()) Actor_Kill(&this->actor);
}

/* Five independently loaded N64 guests. No quest bits, combat or puzzle actions. */
extern Gfx gShaggyDL[];
extern Gfx gVelmaDL[];
extern Gfx gDaphneDL[];
extern Gfx gScoobyDL[];
extern Gfx gFredDL[];
static s32 ElfMsg2_IsMysteryInc(Actor* actor, PlayState* play) {
    static s8 rooms[5] = { 0, 1, 2, 6, 5 };
    s32 index = actor->params - 0x3F87;
    return play->sceneId == SCENE_BOTTOM_OF_THE_WELL && index >= 0 && index < 5 && actor->room == rooms[index];
}
static void ElfMsg2_DrawMysteryInc(Actor* actor, PlayState* play) {
    static s16 objects[5] = { OBJECT_SHAGGY, OBJECT_VELMA, OBJECT_DAPHNE, OBJECT_SCOOBY, OBJECT_FRED };
    static Gfx* lists[5] = { gShaggyDL, gVelmaDL, gDaphneDL, gScoobyDL, gFredDL };
    static Vec3f pivots[5][4] = { {{0,0,0},{0,7426,0},{-1974,7332,0},{1974,7332,0}},{{0,0,0},{0,6004,0},{-1596,5928,0},{1596,5928,0}},{{0,0,0},{0,6794,0},{-1806,6708,0},{1806,6708,0}},{{0,0,0},{19,4047,849},{19,2774,-2476},{19,0,0}},{{0,0,0},{0,7268,0},{-1932,7176,0},{1932,7176,0}} };
    s32 index = actor->params - 0x3F87;
    s32 slot = Object_GetSlot(&play->objectCtx, objects[index]);
    s32 speaking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 350 + index * 6000));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 850));
    Mtx* matrices;
    s32 i;
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "mystery_inc", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Vec3f* pivot = &pivots[index][i];
        Matrix_Push();
        Matrix_Translate(pivot->x, pivot->y, pivot->z, MTXMODE_APPLY);
        if (i == 1) {
            Matrix_RotateY(idle * 0.015f, MTXMODE_APPLY);
            Matrix_RotateX(speaking ? talk * 0.018f : idle * 0.006f, MTXMODE_APPLY);
        } else if (index == 3 && i == 2) {
            Matrix_RotateY(idle * 0.09f, MTXMODE_APPLY);
        } else if (index != 3 && i >= 2) {
            /* At most 1.4 degrees: authored shoulder seams remain together. */
            Matrix_RotateZ((i == 2 ? 1 : -1) * (idle * 0.006f + (speaking ? talk * 0.018f : 0)), MTXMODE_APPLY);
        }
        Matrix_Translate(-pivot->x, -pivot->y, -pivot->z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "mystery_inc", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, lists[index]);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "mystery_inc", 3);
}
static void ElfMsg2_InitMysteryInc(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 heights[5] = { 86, 69, 78, 52, 83 };
    s32 index = actor->params - 0x3F87;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71BA + index;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1600;
    actor->cullingVolumeScale = 130;
    actor->cullingVolumeDownward = 100;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, index == 3 ? 14 : 12);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 12;
    this->wallaceCollider.dim.height = heights[index];
    Actor_SetFocus(actor, heights[index]);
    actor->draw = ElfMsg2_DrawMysteryInc;
}
static void ElfMsg2_UpdateMysteryInc(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 heights[5] = { 86, 69, 78, 52, 83 };
    s32 index = actor->params - 0x3F87;
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight;
    }
    Actor_SetFocus(actor, heights[index]);
    Math_SmoothStepToS(&actor->shape.rot.y, play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE ? actor->yawTowardsPlayer : actor->home.rot.y, 6, 0x400, 1);
    actor->textId = 0x71BA + index;
    if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE &&
        !Player_InCsMode(play) && Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
        actor->xzDistToPlayer < 140 && fabsf(actor->yDistToPlayer) < 55) {
        Actor_OfferTalk(actor, play, 125);
    }
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Two room-local appearances. Only read the native owned-hover-boots bit. */
extern Gfx gKennyDL[];
extern Gfx gKennyDeadDL[];
static s32 ElfMsg2_IsKenny(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_SHADOW_TEMPLE &&
        ((actor->room == 2 && actor->params == 0x3F85) ||
         (actor->room == 6 && actor->params == 0x3F86));
}
static s32 ElfMsg2_KennyVisible(Actor* actor) {
    s32 boots = CHECK_OWNED_EQUIP(EQUIP_TYPE_BOOTS, EQUIP_INV_BOOTS_HOVER) != 0;
    return actor->params == 0x3F86 ? boots : !boots;
}
static void ElfMsg2_DrawKenny(Actor* actor, PlayState* play) {
    s32 slot = Object_GetSlot(&play->objectCtx, OBJECT_KENNY);
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot) || !ElfMsg2_KennyVisible(actor)) return;
    OPEN_DISPS(play->state.gfxCtx, "kenny", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    if (actor->params == 0x3F85) {
        /* Small rigid idle sway, no foreign skeleton or scaling animation. */
        Matrix_RotateZ(Math_SinS((s16)(play->gameplayFrames * 400)) * 0.008f, MTXMODE_APPLY);
    }
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "kenny", 2);
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPDisplayList(POLY_OPA_DISP++, actor->params == 0x3F86 ? gKennyDeadDL : gKennyDL);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    CLOSE_DISPS(play->state.gfxCtx, "kenny", 3);
}
static void ElfMsg2_InitKenny(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 dead = actor->params == 0x3F86;
    if (!LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_PROP);
    actor->flags = ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = dead ? 0x71B9 : 0x71B8;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    actor->shape.rot.x = actor->shape.rot.z = 0;
    ActorShape_Init(&actor->shape, 0, NULL, 14);
    Actor_SetFocus(actor, dead ? 12 : 40);
    actor->draw = ElfMsg2_DrawKenny;
    ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
}
static void ElfMsg2_UpdateKenny(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 dead = actor->params == 0x3F86;
    s32 visible = ElfMsg2_KennyVisible(actor);
    actor->draw = visible ? ElfMsg2_DrawKenny : NULL;
    actor->shape.shadowDraw = visible && !dead ? ActorShadow_DrawCircle : NULL;
    if (!visible) {
        actor->flags &= ~(ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_TALK_WITH_C_UP);
        return;
    }
    actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_TALK_WITH_C_UP;
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight + (dead ? 1.0f : 0.0f);
    }
    Actor_SetFocus(actor, dead ? 12 : 40);
    this->actionFunc(this, play);
}

/* Time travellers: child castle and their first meeting with adult Link in the desert. */
extern Gfx gMartyDL[];
extern Gfx gDocDL[];
extern Gfx gDeloreanDL[];
static s32 ElfMsg2_IsBttf(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_HYRULE_CASTLE || play->sceneId == SCENE_DESERT_COLOSSUS) && actor->room == 0 &&
        actor->params >= 0x3F82 && actor->params <= 0x3F84;
}
static void ElfMsg2_DrawBttf(Actor* actor, PlayState* play) {
    static Vec3f martyPivots[4] = { {0,0,0},{0,6896,0},{-1000,6700,0},{1000,6700,0} };
    static Vec3f docPivots[4] = { {0,0,0},{0,7596,0},{-1000,7250,0},{1000,7250,0} };
    s32 car = actor->params == 0x3F84;
    s32 doc = actor->params == 0x3F83;
    s32 slot = Object_GetSlot(&play->objectCtx, OBJECT_BTTF);
    Vec3f* pivots = doc ? docPivots : martyPivots;
    Mtx* matrices;
    s32 i;
    u16 first = play->sceneId == SCENE_DESERT_COLOSSUS ? 0x71BF : 0x71B4;
    s32 conversation = play->msgCtx.textId >= first && play->msgCtx.textId <= first + 3 &&
        Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    s32 speaking = conversation && ((play->msgCtx.textId - first) & 1) == doc;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (doc ? 340 : 410) + (doc ? 12000 : 0)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * (doc ? 850 : 1050)));
    f32 gesture = Math_SinS((s16)(play->gameplayFrames * (doc ? 510 : 640) + 7000));
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, (car ? 1 : 4) * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "bttf", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < (car ? 1 : 4); i++) {
        Matrix_Push();
        if (!car) Matrix_RotateZ(idle * 0.004f, MTXMODE_APPLY);
        if (!car) {
            Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
            if (i == 1) {
                Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
                if (speaking) Matrix_RotateX(talk * 0.026f, MTXMODE_APPLY);
            }
            if (i >= 2) {
                Matrix_RotateZ((i == 2 ? 1 : -1) * (idle * 0.012f +
                    (speaking ? gesture * (doc ? 0.065f : 0.045f) : 0)), MTXMODE_APPLY);
                if (speaking) Matrix_RotateX(talk * (i == 2 ? 0.022f : -0.015f), MTXMODE_APPLY);
            }
            Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i], "bttf", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, car ? gDeloreanDL : doc ? gDocDL : gMartyDL);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "bttf", 3);
}
static void ElfMsg2_InitBttf(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 car = actor->params == 0x3F84;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if ((play->sceneId == SCENE_DESERT_COLOSSUS ? LINK_IS_CHILD : LINK_IS_ADULT) || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, car ? ACTORCAT_PROP : ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    if (!car) actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = car ? 0 : play->sceneId == SCENE_DESERT_COLOSSUS ? 0x71BF : 0x71B4;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1800.0f;
    actor->cullingVolumeScale = car ? 240.0f : 130.0f;
    actor->cullingVolumeDownward = 120.0f;
    Actor_SetScale(actor, 0.0085f);
    ActorShape_Init(&actor->shape, 0, car ? NULL : ActorShadow_DrawCircle, 14);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = car ? 37 : 14;
    this->wallaceCollider.dim.height = car ? 40 : actor->params == 0x3F83 ? 77 : 70;
    Actor_SetFocus(actor, actor->params == 0x3F83 ? 72 : 65);
    actor->draw = ElfMsg2_DrawBttf;
}
static void ElfMsg2_UpdateBttf(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 car = actor->params == 0x3F84;
    u16 first = play->sceneId == SCENE_DESERT_COLOSSUS ? 0x71BF : 0x71B4;
    /* These three instances never move and the meadow has static collision.
     * Resolve their floor once instead of three full raycasts every frame. */
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight + (car ? 1.0f : 0.0f);
    }
    if (!car) {
        Actor_SetFocus(actor, actor->params == 0x3F83 ? 72 : 65);
        actor->textId = first;
        Math_SmoothStepToS(&actor->shape.rot.y,
            play->msgCtx.textId >= first && play->msgCtx.textId <= first + 3 &&
            Message_GetState(&play->msgCtx) != TEXT_STATE_NONE && actor->xzDistToPlayer < 350 ?
            actor->yawTowardsPlayer : actor->home.rot.y, 6, 0x280, 1);
        if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) == TEXT_STATE_EVENT &&
            play->msgCtx.textId >= first && play->msgCtx.textId < first + 3 && Message_ShouldAdvance(play)) {
            Message_ContinueTextbox(play, play->msgCtx.textId + 1);
        } else if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE &&
            !Player_InCsMode(play) && Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
            actor->xzDistToPlayer < 140.0f && fabsf(actor->yDistToPlayer) < 65.0f) {
            Actor_OfferTalk(actor, play, 125.0f);
        }
    }
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Private child-field traveller. Model uses one dedicated field-only object slot. */
extern Gfx gJabbaDL[];
static s32 ElfMsg2_IsJabba(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_HYRULE_FIELD && actor->room == 0 && actor->params == 0x3F81;
}
static void ElfMsg2_DrawJabba(Actor* actor, PlayState* play) {
    static Vec3f pivots[2] = { {0,0,0}, {0,4832,1095} };
    s32 slot = Object_GetSlot(&play->objectCtx, OBJECT_JABBA);
    void* objectSegment;
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 350));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 870));
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    objectSegment = play->objectCtx.slots[slot].segment;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 2 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "jabba", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 2; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) {
            Matrix_RotateY(idle * 0.01f, MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.008f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "jabba", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, objectSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gJabbaDL);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "jabba", 3);
}
static void ElfMsg2_InitJabba(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71B3;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1700.0f;
    actor->cullingVolumeScale = 180.0f;
    actor->cullingVolumeDownward = 100.0f;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 32);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 42;
    this->wallaceCollider.dim.height = 76;
    Actor_SetFocus(actor, 68);
    actor->draw = ElfMsg2_DrawJabba;
}
static void ElfMsg2_UpdateJabba(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 68);
    actor->textId = 0x71B3;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 160.0f && fabsf(actor->yDistToPlayer) < 70.0f) {
        Actor_OfferTalk(actor, play, 150.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Two isolated Forest Temple NPC rooms; never a connected room pair. */
extern Gfx gBen10DL[];
extern Gfx gIceFanboyDL[];
extern Gfx gIceChumChumDL[];
extern Gfx gFanboyDL[];
extern Gfx gWaterFanboyDL[];
extern Gfx gWaterChumChumDL[];
extern Gfx gChumChumDL[];
extern Gfx gCrockerDL[];
static s32 ElfMsg2_IsSuperhero(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_FOREST_TEMPLE &&
        ((actor->room == 3 && actor->params == 0x3F75) || (actor->room == 5 && actor->params == 0x3F76))) ||
        (play->sceneId == SCENE_SHADOW_TEMPLE && actor->room == 12 && actor->params == 0x3F77) ||
        (play->sceneId == SCENE_WATER_TEMPLE &&
            ((actor->room == 7 && actor->params == 0x3F75) || (actor->room == 19 && actor->params == 0x3F76))) ||
        (play->sceneId == SCENE_ICE_CAVERN &&
            ((actor->room == 9 && actor->params == 0x3F75) || (actor->room == 10 && actor->params == 0x3F76))) ||
        (play->sceneId == SCENE_GERUDO_TRAINING_GROUND && actor->room == 3 && actor->params == 0x3F80);
}
static s32 ElfMsg2_ChumFrozen(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_ICE_CAVERN && actor->room == 10 && actor->params == 0x3F76 &&
        actor->home.rot.z == 1 && !Flags_GetSwitch(play, 0x1E);
}
static void ElfMsg2_DrawSuperhero(Actor* actor, PlayState* play) {
    static Vec3f benPivots[4] = { {0,21,0}, {0,5028,0}, {-830,4485,0}, {687,4485,0} };
    static Vec3f fanboyPivots[4] = { {0,47,0}, {0,5039,0}, {-947,4121,0}, {947,4121,0} };
    static Vec3f chumPivots[4] = { {0,-6,0}, {0,2858,0}, {-1403,2332,0}, {1403,2332,0} };
    static Vec3f crockerPivots[4] = { {0,35,0}, {0,7058,0}, {-850,6651,0}, {850,6651,0} };
    s32 ben = actor->params == 0x3F80;
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Vec3f* pivots = ben ? benPivots : crocker ? crockerPivots : fanboy ? fanboyPivots : chumPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (fanboy ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (ElfMsg2_ChumFrozen(actor, play)) idle = talk = 0.0f;
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "superhelden", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "superhelden", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, ben ? gBen10DL : crocker ? gCrockerDL : play->sceneId == SCENE_ICE_CAVERN ? (fanboy ? gIceFanboyDL : gIceChumChumDL) : play->sceneId == SCENE_WATER_TEMPLE ? (fanboy ? gWaterFanboyDL : gWaterChumChumDL) : fanboy ? gFanboyDL : gChumChumDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "superhelden", 3);
}
static void ElfMsg2_InitSuperhero(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 ben = actor->params == 0x3F80;
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = ben ? 0x706A : crocker ? 0x6089 : fanboy ? (play->sceneId == SCENE_ICE_CAVERN ? 0x403D : play->sceneId == SCENE_WATER_TEMPLE ? 0x7068 : 0x6087) : (play->sceneId == SCENE_ICE_CAVERN ? 0x4040 : play->sceneId == SCENE_WATER_TEMPLE ? 0x7069 : 0x6088);
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, ben ? 14 : crocker ? 16 : fanboy ? 15 : 18);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = ben ? 13 : crocker ? 13 : fanboy ? 13 : 18;
    this->wallaceCollider.dim.height = ben ? 68 : crocker ? 86 : fanboy ? 76 : 47;
    Actor_SetFocus(actor, ben ? 60 : crocker ? 75 : fanboy ? 66 : 40);
    actor->draw = ElfMsg2_DrawSuperhero;
    if (play->sceneId == SCENE_ICE_CAVERN && actor->room == 10 && actor->params == 0x3F76 &&
        !Flags_GetSwitch(play, 0x1E)) {
        Actor* ice = Actor_Spawn(&play->actorCtx, play, ACTOR_BG_ICE_SHELTER,
                                actor->world.pos.x, actor->world.pos.y, actor->world.pos.z,
                                0, 0, 0, 0x011E);
        if (ice != NULL) {
            ice->room = actor->room;
            actor->home.rot.z = 1;
            actor->flags &= ~ACTOR_FLAG_ATTENTION_ENABLED;
        }
    }
}
static void ElfMsg2_UpdateSuperhero(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 ben = actor->params == 0x3F80;
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Actor_SetFocus(actor, ben ? 60 : crocker ? 75 : fanboy ? 66 : 40);
    actor->textId = ben ? 0x706A : crocker ? 0x6089 : fanboy ? (play->sceneId == SCENE_ICE_CAVERN ? 0x403D : play->sceneId == SCENE_WATER_TEMPLE ? 0x7068 : 0x6087) : (play->sceneId == SCENE_ICE_CAVERN ? 0x4040 : play->sceneId == SCENE_WATER_TEMPLE ? 0x7069 : 0x6088);
    if (ElfMsg2_ChumFrozen(actor, play)) {
        actor->flags &= ~ACTOR_FLAG_ATTENTION_ENABLED;
        return;
    }
    actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

#include "player.h"
/* Room-local flavor: no boss changes, collision, object slots, save flags or forced text. */
#include "../ovl_Boss_Ganon2/z_boss_ganon2.h"
extern Gfx gTriangleGuyDL[];
extern Gfx gPregtestDL[];
extern Gfx gFlatSquidDL[];
static s32 ElfMsg2_IsTriangleGuy(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_GANON_BOSS && actor->room == 0 && actor->params == 0x3F78;
}
static s32 ElfMsg2_IsFundstueck(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_BOTTOM_OF_THE_WELL && actor->room == 6 && actor->params == 0x3F79) ||
           (play->sceneId == SCENE_WATER_TEMPLE_BOSS && actor->room == 1 && actor->params == 0x3F7A);
}
static void ElfMsg2_DrawFundstueck(Actor* actor, PlayState* play) {
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Gfx* dl = actor->params == 0x3F78 ? gTriangleGuyDL : actor->params == 0x3F79 ? gPregtestDL : gFlatSquidDL;
    if (roomSegment == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "fundstuecke", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "fundstuecke", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, dl);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "fundstuecke", 3);
}
/* Triangle Guy has three rigid parts. No skin scaling or vertex deformation.
 * Render-only gestures: actor position, targeting, boss and cutscene logic stay native.
 * Three frame matrices replace the previous single model matrix (+128 bytes/draw).
 */
/* Three original rigid parts, unchanged matrix budget. Render-only arm waves. */
static void ElfMsg2_DrawTriangleGuy(Actor* actor, PlayState* play) {
    static Lights1 readableLight = gdSPDefLights1(72, 72, 64, 160, 160, 150, 40, 60, 80);
    static Vec3f pivots[3] = { { 0, 0, 0 }, { 1450, 5750, -570 }, { -1450, 5750, -570 } };
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    s32 speaking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 390));
    Mtx* matrices;
    Actor* boss=play->actorCtx.actorLists[ACTORCAT_BOSS].head;
    s32 shocked=false;
    s32 i;
    if(actor->home.rot.z==0)return;
    while(boss!=NULL) {
        if(boss->id==ACTOR_BOSS_GANON2 && boss->update!=NULL) {
            s16 phase=((BossGanon2*)boss)->unk_39C;
            shocked=phase>=14 && phase<=28;break;
        }
        boss=boss->next;
    }
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 5 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "triangle_v24", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    gSPSetLights1(POLY_OPA_DISP++, readableLight);
    for (i = 0; i < 5; i++) {
        Matrix_Push();
        Matrix_RotateY(idle * 0.012f, MTXMODE_APPLY);
        Matrix_RotateZ(idle * 0.003f, MTXMODE_APPLY);
        if(i>0 && shocked) {
            f32 side=(i==1 || i==3)?1.f:-1.f;
            f32 tremble=Math_SinS((s16)(play->gameplayFrames*1800))*.012f;
            if(i<3) {
                Matrix_Translate(side*1450,5750,-570,MTXMODE_APPLY);
                Matrix_RotateY(-side*1.218f,MTXMODE_APPLY);
                Matrix_RotateZ(-side*(.687f+tremble),MTXMODE_APPLY);
                Matrix_Translate(-side*1450,-5750,570,MTXMODE_APPLY);
            } else {
                Matrix_Translate(side*2137,4133,1292,MTXMODE_APPLY);
                Matrix_RotateY(-side*3.00f,MTXMODE_APPLY);
                Matrix_RotateZ(side*(.93f+tremble),MTXMODE_APPLY);
                Matrix_Translate(-side*4000,-5750,570,MTXMODE_APPLY);
            }
        } else if (i > 0) {
            s32 arm=i>2?i-2:i;
            Vec3f* pivot = &pivots[arm];
            f32 side = arm == 1 ? -1.0f : 1.0f;
            f32 wave = Math_SinS((s16)(play->gameplayFrames * (speaking ? 1100 : 650) + (arm == 1 ? 0 : 0x8000)));
            f32 pump = Math_SinS((s16)(play->gameplayFrames * 920 + arm * 0x3000));
            Matrix_Translate(pivot->x, pivot->y, pivot->z, MTXMODE_APPLY);
            Matrix_RotateZ(side * (0.95f - (speaking ? 1.2f : 0.75f) * (0.5f + 0.5f * wave)), MTXMODE_APPLY);
            Matrix_RotateX(pump * (speaking ? 0.18f : 0.08f), MTXMODE_APPLY);
            Matrix_RotateY(side * pump * 0.10f, MTXMODE_APPLY);
            Matrix_Translate(-pivot->x, -pivot->y, -pivot->z, MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i], "triangle_v24", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gTriangleGuyDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "triangle_v24", 3);
}

static void ElfMsg2_InitTriangleGuy(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_0;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x608A;
    Actor_SetScale(actor, 0.01f);
    Actor_SetFocus(actor, 65);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 17);
    actor->draw = ElfMsg2_DrawTriangleGuy;
    actor->shape.shadowAlpha=0;
}
static void ElfMsg2_UpdateTriangleGuy(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 65);
    if (Actor_TalkOfferAccepted(actor, play) ||
        (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)) return;
    /* Native talking freezes bosses. Offer only in free play, never during a boss cinematic. */
    if (play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play)) {
        actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED;
        if (actor->xzDistToPlayer < 300.0f) {
            Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 6, 0x280, 0);
        }
        if (Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
            actor->xzDistToPlayer < 105.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
            Actor_OfferTalk(actor, play, 100.0f);
        }
    } else {
        actor->flags &= ~ACTOR_FLAG_ATTENTION_ENABLED;
    }
}

/* Separate adult-only rooms; preserve all native guards, capture and escape logic. */
extern Gfx gWawarioDL[];
extern Gfx gWawaluigiDL[];
static s32 ElfMsg2_IsWawarioBros(Actor* actor, PlayState* play) {
    return actor->room == 0 &&
        ((play->sceneId == SCENE_GERUDOS_FORTRESS && actor->params == 0x3F7B) ||
         (play->sceneId == SCENE_GERUDO_VALLEY && actor->params == 0x3F7C));
}
static void ElfMsg2_DrawWawarioBros(Actor* actor, PlayState* play) {
    static Vec3f wawarioPivots[4] = { {0,0,0}, {0,7317,0}, {1463,6585,0}, {-1463,6585,0} };
    static Vec3f wawaluigiPivots[4] = { {0,0,0}, {0,7788,0}, {986,6901,0}, {-986,6901,0} };
    s32 orange = actor->params == 0x3F7B;
    Vec3f* pivots = orange ? wawarioPivots : wawaluigiPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (orange ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "wawario", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "wawario", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, orange ? gWawarioDL : gWawaluigiDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "wawario", 3);
}
static void ElfMsg2_InitWawarioBros(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 orange = actor->params == 0x3F7B;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = orange ? 0x608D : 0x608E;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 14);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 14;
    this->wallaceCollider.dim.height = orange ? 65 : 80;
    Actor_SetFocus(actor, orange ? 65 : 80);
    actor->draw = ElfMsg2_DrawWawarioBros;
}
static void ElfMsg2_UpdateWawarioBros(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 orange = actor->params == 0x3F7B;
    Actor_SetFocus(actor, orange ? 65 : 80);
    actor->textId = orange ? 0x608D : 0x608E;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Each supplied character is restricted to its own scene, room, marker and era. */
extern Gfx gYellowGuyDL[];
extern Gfx gPunkYellowDL[];
extern Gfx gWarioDL[];
static s32 ElfMsg2_IsYellowCast(Actor* actor, PlayState* play) {
    return actor->room == 0 &&
        ((play->sceneId == SCENE_HYRULE_CASTLE && actor->params == 0x3F7D) ||
         (play->sceneId == SCENE_OUTSIDE_GANONS_CASTLE && actor->params == 0x3F7E) ||
         (play->sceneId == SCENE_KAKARIKO_VILLAGE && actor->params == 0x3F7F));
}
static void ElfMsg2_DrawYellowCast(Actor* actor, PlayState* play) {
    static Vec3f yellowPivots[4] = { {0,0,0}, {0,4580,0}, {-975,4265,-375}, {975,4265,-375} };
    static Vec3f punkPivots[4] = { {0,0,0}, {0,4768,0}, {-842,4207,0}, {842,4207,0} };
    static Vec3f warioPivots[4] = { {0,0,0}, {0,4775,0}, {-2029,4083,0}, {2029,4083,0} };
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Vec3f* pivots = normal ? yellowPivots : wario ? warioPivots : punkPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (normal ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "yellowcast", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "yellowcast", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, normal ? gYellowGuyDL : wario ? gWarioDL : gPunkYellowDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "yellowcast", 3);
}
static void ElfMsg2_InitYellowCast(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if ((LINK_IS_CHILD ? actor->params == 0x3F7E : actor->params != 0x3F7E) || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = normal ? 0x608F : wario ? 0x601C : 0x6073;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, wario ? 19 : 14);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = wario ? 22 : 13;
    this->wallaceCollider.dim.height = normal ? 55 : wario ? 65 : 59;
    Actor_SetFocus(actor, normal ? 55 : wario ? 65 : 59);
    actor->draw = ElfMsg2_DrawYellowCast;
}
static void ElfMsg2_UpdateYellowCast(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Actor_SetFocus(actor, normal ? 55 : wario ? 65 : 59);
    actor->textId = normal ? 0x608F : wario ? 0x601C : 0x6073;
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight;
    if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play) &&
        Message_GetState(&play->msgCtx) == TEXT_STATE_NONE && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Room-local static CDU bomb. No attack/AC collider and no explosive action. */
extern Gfx gGoronBombDL[];
static s32 ElfMsg2_IsGoronBomb(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_GORON_CITY && actor->room == 3 && actor->params == 0x3F90;
}
static void ElfMsg2_DrawGoronBomb(Actor* actor, PlayState* play) {
    void* segment = play->roomCtx.curRoom.num == actor->room ? play->roomCtx.curRoom.segment : play->roomCtx.prevRoom.segment;
    if (segment != NULL) {
        OPEN_DISPS(play->state.gfxCtx, "goron bomb", 1);
        gSPSegment(POLY_OPA_DISP++, 0x03, segment);
        Gfx_DrawDListOpa(play, gGoronBombDL);
        gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
        CLOSE_DISPS(play->state.gfxCtx, "goron bomb", 2);
    }
}
static void ElfMsg2_InitGoronBomb(ElfMsg2* this, PlayState* play) {
    static ColliderCylinderInit collider = {
        { COL_MATERIAL_NONE, AT_NONE, AC_NONE, OC1_ON | OC1_TYPE_ALL, OC2_TYPE_2, COLSHAPE_CYLINDER },
        { ELEM_MATERIAL_UNK0, {0, HIT_SPECIAL_EFFECT_NONE, 0}, {0, HIT_BACKLASH_NONE, 0}, ATELEM_NONE, ACELEM_NONE, OCELEM_ON },
        { 47, 177, 0, {0,0,0} }
    };
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &collider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER || gSaveContext.gameMode != GAMEMODE_NORMAL || gSaveContext.save.cutsceneIndex >= CS_INDEX_0) {
        Actor_Kill(actor);
        return;
    }
    actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_TALK_WITH_C_UP | ACTOR_FLAG_FRIENDLY;
    actor->attentionRangeType = ATTENTION_RANGE_2;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71DD;
    actor->world.rot.z = 1;
    Actor_SetFocus(actor, 100.0f);
    ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1800.0f;
    actor->cullingVolumeScale = 250.0f;
    actor->cullingVolumeDownward = 250.0f;
    Actor_SetScale(actor, 0.01f);
    actor->draw = ElfMsg2_DrawGoronBomb;
}
static void ElfMsg2_UpdateGoronBomb(ElfMsg2* this, PlayState* play) {
    Actor_SetFocus(&this->actor, 100.0f);
    this->actionFunc(this, play);
    Collider_UpdateCylinder(&this->actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Room-local supplied penguin. Four rigid parts; no imported animation engine. */
extern Gfx gPinguDL[];
static s32 ElfMsg2_IsPingu(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_ICE_CAVERN && actor->room == 2 && actor->params == 0x3F93;
}
static void ElfMsg2_DrawPingu(Actor* actor, PlayState* play) {
    static Vec3f pivots[4] = { {0,0,0}, {0,3538,0}, {-831,3157,-76}, {831,3157,-76} };
    void* room = ElfMsg2_PepsiRoom(actor, play);
    s32 talking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 550));
    f32 flap = Math_SinS((s16)(play->gameplayFrames * (talking ? 1050 : 650)));
    Mtx* matrices;
    s32 i;
    if (room == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "pingu_v25", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_RotateZ(idle * 0.008f, MTXMODE_APPLY);
        if (i > 0) {
            Vec3f* p = &pivots[i];
            Matrix_Translate(p->x, p->y, p->z, MTXMODE_APPLY);
            if (i == 1) {
                Matrix_RotateY(idle * 0.04f, MTXMODE_APPLY);
                Matrix_RotateX(flap * (talking ? 0.07f : 0.02f), MTXMODE_APPLY);
            } else {
                f32 side = i == 2 ? 1.0f : -1.0f;
                Matrix_RotateZ(side * (1.00f - flap * (talking ? 0.06f : 0.025f)), MTXMODE_APPLY);
                Matrix_RotateY(side * idle * 0.035f, MTXMODE_APPLY);
            }
            Matrix_Translate(-p->x, -p->y, -p->z, MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i], "pingu_v25", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, room);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gPinguDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "pingu_v25", 3);
}
static void ElfMsg2_InitPingu(ElfMsg2* this, PlayState* play) {
    static ColliderCylinderInit cylinder = {
        { COL_MATERIAL_NONE, AT_NONE, AC_NONE, OC1_ON | OC1_TYPE_ALL, OC2_TYPE_2, COLSHAPE_CYLINDER },
        { ELEM_MATERIAL_UNK0, {0,HIT_SPECIAL_EFFECT_NONE,0}, {0,HIT_BACKLASH_NONE,0}, ATELEM_NONE, ACELEM_NONE, OCELEM_ON },
        { 11, 43, 0, {0,0,0} }
    };
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &cylinder);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER || gSaveContext.gameMode != GAMEMODE_NORMAL) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_0;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71DE;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    Actor_SetFocus(actor, 38.0f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 11);
    actor->draw = ElfMsg2_DrawPingu;
}
static void ElfMsg2_UpdatePingu(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 38.0f);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
    if (Actor_TalkOfferAccepted(actor, play) ||
        (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)) return;
    if (play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play)) {
        if (actor->xzDistToPlayer < 220.0f) {
            Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 6, 0x200, 0);
        }
        if (Message_GetState(&play->msgCtx) == TEXT_STATE_NONE && actor->xzDistToPlayer < 105.0f &&
            fabsf(actor->yDistToPlayer) < 50.0f) Actor_OfferTalk(actor, play, 100.0f);
    }
}

/* Room-local supplied penguin. Four rigid parts; no imported animation engine. */
extern Gfx gCrazyFrogDL[];
static s32 ElfMsg2_IsCrazyFrog(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_ZORAS_RIVER && actor->room == 0 && actor->params == 0x3F94;
}
static void ElfMsg2_DrawCrazyFrog(Actor* actor, PlayState* play) {
    static Vec3f pivots[4] = { {0,0,0}, {0,2728,0}, {-654,2387,0}, {654,2387,0} };
    void* room = ElfMsg2_PepsiRoom(actor, play);
    s32 talking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 550));
    f32 flap = Math_SinS((s16)(play->gameplayFrames * (talking ? 1050 : 650)));
    Mtx* matrices;
    s32 i;
    if (room == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "crazy_frog_v25", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_RotateZ(idle * 0.008f, MTXMODE_APPLY);
        if (i > 0) {
            Vec3f* p = &pivots[i];
            Matrix_Translate(p->x, p->y, p->z, MTXMODE_APPLY);
            if (i == 1) {
                Matrix_RotateY(idle * 0.04f, MTXMODE_APPLY);
                Matrix_RotateX(flap * (talking ? 0.07f : 0.02f), MTXMODE_APPLY);
            } else {
                f32 side = i == 2 ? 1.0f : -1.0f;
                Matrix_RotateZ(side * (0.95f - flap * (talking ? 0.30f : 0.10f)), MTXMODE_APPLY);
                Matrix_RotateY(side * idle * 0.035f, MTXMODE_APPLY);
            }
            Matrix_Translate(-p->x, -p->y, -p->z, MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i], "crazy_frog_v25", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, room);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gCrazyFrogDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "crazy_frog_v25", 3);
}
static void ElfMsg2_InitCrazyFrog(ElfMsg2* this, PlayState* play) {
    static ColliderCylinderInit cylinder = {
        { COL_MATERIAL_NONE, AT_NONE, AC_NONE, OC1_ON | OC1_TYPE_ALL, OC2_TYPE_2, COLSHAPE_CYLINDER },
        { ELEM_MATERIAL_UNK0, {0,HIT_SPECIAL_EFFECT_NONE,0}, {0,HIT_BACKLASH_NONE,0}, ATELEM_NONE, ACELEM_NONE, OCELEM_ON },
        { 10, 39, 0, {0,0,0} }
    };
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &cylinder);
    if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER || gSaveContext.gameMode != GAMEMODE_NORMAL) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_0;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71DF;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    Actor_SetFocus(actor, 34.0f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 11);
    actor->draw = ElfMsg2_DrawCrazyFrog;
}
static void ElfMsg2_UpdateCrazyFrog(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 34.0f);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
    if (Actor_TalkOfferAccepted(actor, play) ||
        (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)) return;
    if (play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play)) {
        if (actor->xzDistToPlayer < 220.0f) {
            Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 6, 0x200, 0);
        }
        if (Message_GetState(&play->msgCtx) == TEXT_STATE_NONE && actor->xzDistToPlayer < 105.0f &&
            fabsf(actor->yDistToPlayer) < 50.0f) Actor_OfferTalk(actor, play, 100.0f);
    }
}

/* Four separate room-local guests; dynamite is non-interactive scenery. */
extern Gfx gSkipperV26DL[], gKowalskiV26DL[], gPrivateV26DL[], gRicoV26DL[];
extern Gfx gSkipperPropsV26DL[], gKowalskiPropsV26DL[], gPrivatePropsV26DL[], gRicoPropsV26DL[];
static s32 ElfMsg2_IsPenguin(Actor* actor, PlayState* play) {
    static s8 rooms[4] = {0,1,9,5};
    s32 i = actor->params - 0x3F95;
    return play->sceneId == SCENE_INSIDE_GANONS_CASTLE && i >= 0 && i < 4 && actor->room == rooms[i];
}
static void ElfMsg2_DrawPenguin(Actor* actor, PlayState* play) {
    static Gfx* lists[4] = {gSkipperV26DL,gKowalskiV26DL,gPrivateV26DL,gRicoV26DL};
    static Gfx* props[4] = {gSkipperPropsV26DL,gKowalskiPropsV26DL,gPrivatePropsV26DL,gRicoPropsV26DL};
    static Vec3f pivots[4][4] = {{ {0,0,0}, {0,3775,0}, {-966,3481,0}, {966,3481,0} },
{ {0,0,0}, {0,4756,0}, {-721,4360,0}, {721,4360,0} },
{ {0,0,0}, {0,3446,0}, {-892,2959,0}, {892,2959,0} },
{ {0,0,0}, {0,3900,0}, {-892,3657,0}, {892,3657,0} }};
    static Lights1 light = gdSPDefLights1(70,70,75,160,160,150,30,70,60);
    s32 type = actor->params - 0x3F95;
    s32 talking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 410 + type * 9000));
    f32 flap = Math_SinS((s16)(play->gameplayFrames * (talking ? 850 : 480)));
    void* room = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    if (room == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 5 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "penguins_v26", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_RotateZ(idle * (type == 3 ? 0.012f : 0.006f), MTXMODE_APPLY);
        if (i > 0) {
            Vec3f* p = &pivots[type][i];
            Matrix_Translate(p->x,p->y,p->z,MTXMODE_APPLY);
            if (i == 1) {
                Matrix_RotateY(idle * 0.035f,MTXMODE_APPLY);
                Matrix_RotateX(flap * (talking ? 0.045f : 0.012f),MTXMODE_APPLY);
            } else {
                f32 side = i == 2 ? 1.0f : -1.0f;
                f32 base = type == 2 && i == 3 ? -0.20f : 0.22f;
                f32 amplitude = type == 2 && i == 3 ? 0.018f : talking ? (type == 3 ? 0.15f : 0.07f) : 0.025f;
                Matrix_RotateZ(side * (base + flap * amplitude),MTXMODE_APPLY);
            }
            Matrix_Translate(-p->x,-p->y,-p->z,MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i],"penguins_v26",2);
        Matrix_Pop();
    }
    /* Floor props stay fixed while the penguin turns towards Link. */
    Matrix_Push();
    Matrix_RotateY(-BINANG_TO_RAD(actor->shape.rot.y),MTXMODE_APPLY);
    MATRIX_TO_MTX(&matrices[4],"penguins_v26",3);
    Matrix_Pop();
    gSPSegment(POLY_OPA_DISP++,0x03,room);
    gSPSetLights1(POLY_OPA_DISP++,light);
    gSPSegment(POLY_OPA_DISP++,0x0D,&matrices[4]);
    gSPDisplayList(POLY_OPA_DISP++,props[type]);
    gSPSegment(POLY_OPA_DISP++,0x0D,matrices);
    gSPDisplayList(POLY_OPA_DISP++,lists[type]);
    gSPSegment(POLY_OPA_DISP++,0x03,OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++,0x0D,OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx,"penguins_v26",4);
}
static void ElfMsg2_InitPenguin(ElfMsg2* this, PlayState* play) {
    static ColliderCylinderInit cylinder = {
        { COL_MATERIAL_NONE, AT_NONE, AC_NONE, OC1_ON | OC1_TYPE_ALL, OC2_TYPE_2, COLSHAPE_CYLINDER },
        { ELEM_MATERIAL_UNK0, {0,HIT_SPECIAL_EFFECT_NONE,0}, {0,HIT_BACKLASH_NONE,0}, ATELEM_NONE, ACELEM_NONE, OCELEM_ON },
        { 10, 45, 0, {0,0,0} }
    };
    static f32 focus[4] = {44,55,40,47};
    Actor* actor = &this->actor;
    s32 type = actor->params - 0x3F95;
    Collider_InitCylinder(play,&this->wallaceCollider);
    Collider_SetCylinder(play,&this->wallaceCollider,actor,&cylinder);
    if (!LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER || gSaveContext.gameMode != GAMEMODE_NORMAL) {
        Actor_Kill(actor);return;
    }
    Actor_ChangeCategory(play,&play->actorCtx,actor,ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_0;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71E0 + type;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor,0.01f);
    Actor_SetFocus(actor,focus[type]);
    ActorShape_Init(&actor->shape,0,ActorShadow_DrawCircle,10);
    actor->draw = ElfMsg2_DrawPenguin;
}
static void ElfMsg2_UpdatePenguin(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 focus[4] = {44,55,40,47};
    Actor_SetFocus(actor,focus[actor->params - 0x3F95]);
    Collider_UpdateCylinder(actor,&this->wallaceCollider);
    CollisionCheck_SetOC(play,&play->colChkCtx,&this->wallaceCollider.base);
    if (Actor_TalkOfferAccepted(actor,play) ||
        (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)) return;
    if (play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play)) {
        if (actor->xzDistToPlayer < 220.0f) Math_SmoothStepToS(&actor->shape.rot.y,actor->yawTowardsPlayer,6,0x200,0);
        if (Message_GetState(&play->msgCtx) == TEXT_STATE_NONE && actor->xzDistToPlayer < 105.0f &&
            fabsf(actor->yDistToPlayer) < 50.0f) Actor_OfferTalk(actor,play,100.0f);
    }
}

/* Supplied anatomical models, one static native Navi-check spot. No collider or animation. */
extern Gfx gWellPropsV27DL[];
static s32 ElfMsg2_IsWellPropsV27(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_BOTTOM_OF_THE_WELL && actor->room == 1 && actor->params == 0x3F99;
}
static void ElfMsg2_DrawWellPropsV27(Actor* actor, PlayState* play) {
    void* room = ElfMsg2_PepsiRoom(actor,play);
    static Lights1 light = gdSPDefLights1(78,78,78,150,150,150,40,80,30);
    if (room == NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"well_props_v27",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++,play->state.gfxCtx,"well_props_v27",2);
    gSPSetLights1(POLY_OPA_DISP++,light);
    gSPSegment(POLY_OPA_DISP++,0x03,room);
    gSPDisplayList(POLY_OPA_DISP++,gWellPropsV27DL);
    gSPSegment(POLY_OPA_DISP++,0x03,OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx,"well_props_v27",3);
}

/* Room-local, original low-poly Franky variants. No new object banks or boss state writes. */
extern Gfx gFrankyCastleV28DL[], gFrankyHealthyV28DL[], gFrankyBrokenV28DL[], gFrankyTapedV28DL[], gBurntBodyV28DL[];
static s32 ElfMsg2_IsFrankyV28(Actor* actor, PlayState* play) {
    return actor->room == 0 &&
        ((play->sceneId == SCENE_LON_LON_RANCH && (actor->params == 0x3F9A || actor->params == 0x3F9D)) ||
         (play->sceneId == SCENE_INSIDE_GANONS_CASTLE && actor->params == 0x3F9B) ||
         (play->sceneId == SCENE_GANON_BOSS && actor->params == 0x3F9C));
}
static s32 ElfMsg2_IsBurntBodyV28(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_DEATH_MOUNTAIN_CRATER && actor->room == 1 && actor->params == 0x3F9E;
}
static void ElfMsg2_DrawBurntBodyV28(Actor* actor, PlayState* play) {
    void* room = ElfMsg2_PepsiRoom(actor,play);
    if (room == NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"body_v28",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++,play->state.gfxCtx,"body_v28",2);
    gSPSegment(POLY_OPA_DISP++,0x03,room);
    gSPDisplayList(POLY_OPA_DISP++,gBurntBodyV28DL);
    gSPSegment(POLY_OPA_DISP++,0x03,OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx,"body_v28",3);
}
static void ElfMsg2_DrawFrankyV28(Actor* actor, PlayState* play) {
    void* room = ElfMsg2_PepsiRoom(actor,play);
    s32 broken = actor->params == 0x3F9C;
    s32 taped = actor->params == 0x3F9D;
    s32 talking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 430));
    f32 speech = Math_SinS((s16)(play->gameplayFrames * 1050));
    Mtx* matrices;
    s32 i;
    if (room == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx,(broken ? 1 : 2)*sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"franky_v28",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < (broken ? 1 : 2); i++) {
        Matrix_Push();
        if (!broken) {
            Matrix_RotateZ(idle*(taped ? 0.012f : 0.006f),MTXMODE_APPLY);
            if (i == 1) {
                f32 pivot = taped ? 3872.0f : 5124.0f;
                Matrix_Translate(0,pivot,0,MTXMODE_APPLY);
                Matrix_RotateY(idle*0.025f,MTXMODE_APPLY);
                Matrix_RotateX(talking ? speech*0.035f : idle*0.007f,MTXMODE_APPLY);
                Matrix_Translate(0,-pivot,0,MTXMODE_APPLY);
            }
        }
        MATRIX_TO_MTX(&matrices[i],"franky_v28",2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++,0x03,room);
    gSPSegment(POLY_OPA_DISP++,0x0D,matrices);
    gSPDisplayList(POLY_OPA_DISP++,broken ? gFrankyBrokenV28DL : taped ? gFrankyTapedV28DL : actor->params == 0x3F9B ? gFrankyCastleV28DL : gFrankyHealthyV28DL);
    gSPSegment(POLY_OPA_DISP++,0x03,OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++,0x0D,OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx,"franky_v28",3);
}
static void ElfMsg2_InitFrankyV28(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 taped = actor->params == 0x3F9D;
    if (gSaveContext.language != LANGUAGE_GER ||
        (!taped && gSaveContext.gameMode != GAMEMODE_NORMAL) ||
        (taped && gSaveContext.sceneLayer != 9) ||
        ((actor->params == 0x3F9B || actor->params == 0x3F9C) && LINK_IS_CHILD)) {
        Actor_Kill(actor);return;
    }
    Actor_ChangeCategory(play,&play->actorCtx,actor,ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    if (!taped) actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED;
    actor->attentionRangeType = ATTENTION_RANGE_0;
    actor->naviEnemyId = 0xFF;
    actor->textId = actor->params == 0x3F9A ? (LINK_IS_CHILD ? 0x71E5 : 0x71E6) : actor->params == 0x3F9B ? 0x71E7 : 0x71E8;
    Actor_SetScale(actor,0.01f);
    Actor_SetFocus(actor,actor->params == 0x3F9C ? 8.0f : 64.0f);
    actor->draw = ElfMsg2_DrawFrankyV28;
}
static void ElfMsg2_UpdateFrankyV28(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 broken = actor->params == 0x3F9C;
    if (actor->params == 0x3F9D) return; /* No talk offers, collision or story writes in credits. */
    Actor_SetFocus(actor,broken ? 8.0f : 64.0f);
    if (Actor_TalkOfferAccepted(actor,play) || (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)) return;
    if (play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play)) {
        actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED;
        if (!broken && actor->xzDistToPlayer < 220.0f) Math_SmoothStepToS(&actor->shape.rot.y,actor->yawTowardsPlayer,6,0x200,0);
        if (Message_GetState(&play->msgCtx) == TEXT_STATE_NONE && actor->xzDistToPlayer < 105.0f && fabsf(actor->yDistToPlayer)<50.0f) Actor_OfferTalk(actor,play,100.0f);
    } else actor->flags &= ~ACTOR_FLAG_ATTENTION_ENABLED;
}

/* A single targetable handheld per age, at the same floor spot. */
extern Gfx gGameBoyColorV28DL[], gGameBoyAdvanceV28DL[];
static s32 ElfMsg2_IsHandheldV28(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_KOKIRI_FOREST && actor->room == 1 && actor->params == 0x3F9F;
}
static void ElfMsg2_DrawHandheldV28(Actor* actor, PlayState* play) {
    void* room = ElfMsg2_PepsiRoom(actor,play);
    if (room == NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"handheld_v28",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++,play->state.gfxCtx,"handheld_v28",2);
    gSPSegment(POLY_OPA_DISP++,0x03,room);
    gSPDisplayList(POLY_OPA_DISP++,LINK_IS_CHILD ? gGameBoyColorV28DL : gGameBoyAdvanceV28DL);
    gSPSegment(POLY_OPA_DISP++,0x03,OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx,"handheld_v28",3);
}

/* Credits guests never offer text, create collisions, move the camera or write story flags. */
#include "../ovl_Demo_Ec/z_demo_ec.h"
#include "array_count.h"
extern Gfx gCreditsV29SkipperV26DL[];
extern Gfx gCreditsV29KowalskiV26DL[];
extern Gfx gCreditsV29PrivateV26DL[];
extern Gfx gCreditsV29RicoV26DL[];
extern Gfx gCreditsV29PinguV25DL[];
extern Gfx gCreditsV29FanboyDL[];
extern Gfx gCreditsV29ChumchumDL[];
extern Gfx gCreditsV29ShaggyDL[];
extern Gfx gCreditsV29VelmaDL[];
extern Gfx gCreditsV29DaphneDL[];
extern Gfx gCreditsV29ScoobyDL[];
extern Gfx gCreditsV29FredDL[];
extern Gfx gCreditsV29MysterymachineDL[];
extern Gfx gCreditsV29MackeyDL[];
extern Gfx gCreditsV29DoofevilDL[];
extern Gfx gCreditsV29PepsimanDL[];
extern Gfx gCreditsV29PepsiCanDL[];
extern Gfx gCreditsV29PepsiCrushedDL[];
extern Gfx gCreditsV29WawarioDL[];
extern Gfx gCreditsV29WawaluigiDL[];
extern Gfx gCreditsV29CrockerDL[];
extern Gfx gCreditsV29WarioDL[];
extern Gfx gCreditsV29MartyDL[];
extern Gfx gCreditsV29DocDL[];
typedef struct { s16 object; u8 layer; u8 bones; f32 scale; Gfx* dl; Vec3f pivots[4]; } CreditsV29Guest;
typedef struct { s16 bob; Vec3s angles[4]; } CreditsV29Dance;
/* Original gDemoEcPotionShopOwnerAnim, 59 frames; upright-rest retarget. */
static CreditsV29Dance sCreditsV29Dance[59] = {
    { 0, { {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0} } },
    { -1, { {0,7,124}, {0,17,288}, {-44,195,256}, {-63,339,-50} } },
    { -4, { {0,8,136}, {2,41,690}, {-84,398,530}, {-93,740,12} } },
    { -11, { {0,3,60}, {4,67,1131}, {-115,604,808}, {-77,1182,177} } },
    { -18, { {0,-5,-82}, {7,90,1537}, {-133,810,1079}, {-5,1641,441} } },
    { -28, { {1,-15,-266}, {10,108,1837}, {-132,1008,1333}, {128,2086,790} } },
    { -36, { {1,-28,-468}, {11,115,1956}, {-113,1192,1560}, {318,2491,1208} } },
    { -44, { {2,-40,-666}, {8,98,1668}, {-71,1355,1751}, {548,2830,1664} } },
    { -52, { {2,-50,-836}, {3,60,1024}, {-8,1490,1894}, {792,3087,2121} } },
    { -56, { {3,-58,-955}, {0,22,366}, {78,1591,1981}, {1011,3256,2530} } },
    { -59, { {4,-60,-1001}, {0,2,33}, {187,1655,1997}, {1166,3337,2838} } },
    { -54, { {4,-58,-973}, {0,1,19}, {370,1700,1930}, {1221,3352,3029} } },
    { -42, { {3,-53,-895}, {0,5,78}, {650,1754,1785}, {1180,3325,3129} } },
    { -28, { {2,-47,-781}, {0,11,194}, {1000,1838,1580}, {1069,3261,3164} } },
    { -16, { {2,-38,-640}, {0,21,348}, {1393,1964,1336}, {913,3161,3157} } },
    { -12, { {1,-28,-483}, {1,31,526}, {1793,2139,1072}, {740,3025,3135} } },
    { -18, { {1,-20,-322}, {2,42,709}, {2170,2350,804}, {575,2856,3122} } },
    { -26, { {0,-10,-167}, {2,52,880}, {2488,2572,539}, {442,2657,3136} } },
    { -36, { {0,-2,-31}, {3,60,1024}, {2712,2763,276}, {361,2429,3193} } },
    { -48, { {0,5,77}, {4,66,1122}, {2809,2876,5}, {349,2175,3305} } },
    { -61, { {0,9,145}, {4,68,1157}, {2748,2853,-278}, {421,1893,3477} } },
    { -74, { {0,10,163}, {4,67,1136}, {2506,2637,-559}, {589,1577,3709} } },
    { -84, { {0,7,118}, {4,64,1080}, {1948,2050,-794}, {915,1142,4035} } },
    { -93, { {0,0,0}, {3,58,993}, {1042,1056,-820}, {1385,516,4406} } },
    { -98, { {1,-23,-380}, {2,52,877}, {-153,-100,-439}, {1904,-274,4717} } },
    { -100, { {5,-65,-1095}, {2,43,737}, {-1632,-1097,420}, {2418,-1165,4897} } },
    { -84, { {14,-117,-1979}, {1,34,575}, {-3303,-1647,1639}, {2903,-2072,4913} } },
    { -51, { {30,-169,-2869}, {1,23,396}, {-4911,-1669,2910}, {3349,-2909,4772} } },
    { -17, { {46,-209,-3598}, {0,12,204}, {-6189,-1359,3946}, {3740,-3595,4520} } },
    { 0, { {57,-231,-4003}, {0,0,0}, {-7013,-1058,4642}, {4024,-4077,4246} } },
    { 0, { {60,-238,-4127}, {0,-17,-288}, {-7470,-1012,5112}, {4208,-4403,3980} } },
    { -3, { {61,-238,-4139}, {1,-41,-690}, {-7731,-1217,5490}, {4343,-4660,3701} } },
    { -9, { {58,-234,-4063}, {3,-67,-1131}, {-7857,-1635,5787}, {4440,-4860,3426} } },
    { -17, { {55,-227,-3921}, {6,-90,-1537}, {-7891,-2203,5989}, {4501,-5018,3168} } },
    { -26, { {50,-217,-3737}, {9,-108,-1837}, {-7859,-2840,6088}, {4538,-5144,2933} } },
    { -36, { {45,-206,-3535}, {10,-115,-1956}, {-7782,-3451,6092}, {4556,-5249,2728} } },
    { -46, { {39,-195,-3337}, {7,-98,-1668}, {-7691,-3936,6039}, {4570,-5337,2554} } },
    { -54, { {35,-185,-3166}, {3,-60,-1024}, {-7638,-4194,5998}, {4586,-5413,2415} } },
    { -60, { {33,-179,-3047}, {0,-22,-366}, {-7638,-4274,5998}, {4618,-5479,2309} } },
    { -62, { {32,-176,-3002}, {0,-2,-33}, {-7656,-4296,6010}, {4676,-5537,2236} } },
    { -58, { {33,-178,-3030}, {0,-1,-19}, {-7684,-4269,6028}, {4773,-5591,2196} } },
    { -45, { {35,-182,-3107}, {0,-5,-78}, {-7713,-4203,6042}, {4929,-5664,2195} } },
    { -30, { {37,-188,-3221}, {0,-11,-194}, {-7735,-4108,6045}, {5143,-5775,2237} } },
    { -18, { {41,-196,-3362}, {0,-21,-348}, {-7742,-3994,6027}, {5401,-5928,2309} } },
    { -12, { {44,-205,-3519}, {1,-31,-526}, {-7728,-3870,5983}, {5687,-6125,2398} } },
    { -15, { {48,-214,-3681}, {1,-42,-709}, {-7687,-3747,5907}, {5985,-6359,2497} } },
    { -20, { {52,-222,-3835}, {2,-52,-880}, {-7611,-3632,5793}, {6273,-6613,2602} } },
    { -28, { {56,-230,-3972}, {3,-60,-1024}, {-7495,-3533,5638}, {6526,-6858,2724} } },
    { -36, { {59,-235,-4080}, {3,-66,-1122}, {-7331,-3456,5436}, {6708,-7056,2888} } },
    { -46, { {61,-239,-4148}, {3,-68,-1157}, {-7111,-3403,5183}, {6782,-7162,3129} } },
    { -54, { {61,-240,-4166}, {3,-67,-1136}, {-6825,-3374,4871}, {6716,-7119,3472} } },
    { -63, { {60,-238,-4121}, {3,-64,-1080}, {-6461,-3365,4495}, {6504,-6865,3901} } },
    { -70, { {57,-231,-4003}, {3,-58,-993}, {-5819,-3399,3864}, {6060,-6120,4424} } },
    { -74, { {47,-211,-3622}, {2,-52,-877}, {-4790,-3363,2896}, {5462,-4761,4758} } },
    { -74, { {30,-171,-2908}, {1,-43,-737}, {-3563,-3084,1804}, {4744,-3082,4594} } },
    { -62, { {15,-121,-2023}, {1,-34,-575}, {-2364,-2516,841}, {3776,-1508,3858} } },
    { -38, { {5,-68,-1134}, {0,-23,-396}, {-1358,-1756,178}, {2548,-449,2676} } },
    { -12, { {1,-24,-404}, {0,-12,-204}, {-609,-980,-142}, {1303,-56,1398} } },
    { 0, { {0,0,0}, {0,0,0}, {-142,-355,-174}, {381,-65,423} } },
};

extern Gfx gCreditsV32TerriDL[];
static CreditsV29Guest sCreditsV29Guests[] = {
    { OBJECT_CREDITS_V29_PENGUINS, 7, 4, 0.01f, gCreditsV29SkipperV26DL, { {0,0,0}, {0,3775,0}, {-1137,3469,73}, {1140,3468,72} } }, /* skipper_v26 */
    { OBJECT_CREDITS_V29_PENGUINS, 7, 4, 0.01f, gCreditsV29KowalskiV26DL, { {0,0,0}, {0,4756,0}, {-899,4126,-67}, {899,4126,-67} } }, /* kowalski_v26 */
    { OBJECT_CREDITS_V29_PENGUINS, 7, 4, 0.01f, gCreditsV29PrivateV26DL, { {0,0,0}, {0,3446,0}, {-1002,2953,-80}, {1002,2953,-80} } }, /* private_v26 */
    { OBJECT_CREDITS_V29_PENGUINS, 7, 4, 0.01f, gCreditsV29RicoV26DL, { {0,0,0}, {0,3900,0}, {-926,3694,-431}, {924,3694,-431} } }, /* rico_v26 */
    { OBJECT_CREDITS_V29_PENGUINS, 7, 4, 0.01f, gCreditsV29PinguV25DL, { {0,0,0}, {0,3538,0}, {-831,3157,-76}, {831,3157,-76} } }, /* pingu_v25 */
    { OBJECT_CREDITS_V29_HEROES, 8, 4, 0.0085f, gCreditsV29FanboyDL, { {0,47,0}, {0,5039,0}, {-947,4121,0}, {947,4121,0} } }, /* fanboy */
    { OBJECT_CREDITS_V29_HEROES, 8, 4, 0.0088f, gCreditsV29ChumchumDL, { {0,-6,0}, {0,2858,0}, {-1403,2332,0}, {1403,2332,0} } }, /* chumchum */
    { OBJECT_CREDITS_V29_MYSTERY, 9, 4, 0.01f, gCreditsV29ShaggyDL, { {0,0,0}, {0,7426,0}, {-850,6740,-280}, {850,6740,-280} } }, /* shaggy */
    { OBJECT_CREDITS_V29_MYSTERY, 9, 4, 0.01f, gCreditsV29VelmaDL, { {0,0,0}, {0,6004,0}, {-1596,5928,0}, {1596,5928,0} } }, /* velma */
    { OBJECT_CREDITS_V29_MYSTERY, 9, 4, 0.01f, gCreditsV29DaphneDL, { {0,0,0}, {0,6794,0}, {-1806,6708,0}, {1806,6708,0} } }, /* daphne */
    { OBJECT_CREDITS_V29_MYSTERY, 9, 4, 0.01f, gCreditsV29ScoobyDL, { {0,0,0}, {19,4047,849}, {19,2774,-2476}, {19,0,0} } }, /* scooby */
    { OBJECT_CREDITS_V29_MYSTERY, 9, 4, 0.01f, gCreditsV29FredDL, { {0,0,0}, {0,7268,0}, {-1330,7100,-240}, {1410,7180,-290} } }, /* fred */
    { OBJECT_CREDITS_V29_MYSTERY, 9, 4, 0.01f, gCreditsV29MysterymachineDL, { {0,0,0}, {0,7557,0}, {-2009,7462,0}, {2009,7462,0} } }, /* mysterymachine */
    { OBJECT_CREDITS_V29_DANCERS, 11, 4, 0.01f, gCreditsV29MackeyDL, { {0,0,0}, {0,4194,0}, {-610,3889,0}, {610,3889,0} } }, /* mackey */
    { OBJECT_CREDITS_V29_DANCERS, 11, 4, 0.01f, gCreditsV29DoofevilDL, { {0,0,0}, {0,6016,0}, {-1051,5432,0}, {1051,5432,0} } }, /* doofevil */
    { OBJECT_CREDITS_V29_DANCERS, 11, 4, 0.01f, gCreditsV29PepsimanDL, { {0,6313,0}, {0,8280,0}, {-1242,7918,-311}, {1242,7918,-311} } }, /* pepsiman */
    { OBJECT_CREDITS_V29_DANCERS, 11, 1, 0.01f, gCreditsV29PepsiCanDL, { {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0} } }, /* pepsi_can */
    { OBJECT_CREDITS_V29_DANCERS, 11, 1, 0.01f, gCreditsV29PepsiCrushedDL, { {0,0,0}, {0,0,0}, {0,0,0}, {0,0,0} } }, /* pepsi_crushed */
    { OBJECT_CREDITS_V29_DANCERS, 11, 4, 0.008f, gCreditsV29WawarioDL, { {0,0,0}, {0,7317,0}, {1463,6585,0}, {-1463,6585,0} } }, /* wawario */
    { OBJECT_CREDITS_V29_DANCERS, 11, 4, 0.008f, gCreditsV29WawaluigiDL, { {0,0,0}, {0,7788,0}, {986,6901,0}, {-986,6901,0} } }, /* wawaluigi */
    { OBJECT_CREDITS_V29_DANCERS, 11, 4, 0.01f, gCreditsV29CrockerDL, { {0,35,0}, {0,7058,0}, {-850,6651,0}, {850,6651,0} } }, /* crocker */
    { OBJECT_CREDITS_V29_WARIO, 10, 4, 0.0095f, gCreditsV29WarioDL, { {0,-1036,0}, {0,3739,0}, {-2029,3047,0}, {2029,3047,0} } }, /* wario */
    { OBJECT_CREDITS_V29_COURTYARD, 4, 4, 0.0085f, gCreditsV29MartyDL, { {0,0,0}, {0,6896,0}, {-1000,6700,0}, {1000,6700,0} } }, /* marty */
    { OBJECT_CREDITS_V29_COURTYARD, 4, 4, 0.0085f, gCreditsV29DocDL, { {0,0,0}, {0,7596,0}, {-1000,7250,0}, {1000,7250,0} } }, /* doc */
    { OBJECT_CREDITS_V29_HEROES, 8, 4, 0.0085f, gCreditsV32TerriDL, { {0,0,0}, {0,6241,0}, {-950,5134,0}, {950,5134,0} } }, /* terri */
};
static s32 ElfMsg2_IsCreditsV29(Actor* actor, PlayState* play) {
    s32 i = actor->params - 0x3FA0;
    if (i < 0 || i >= ARRAY_COUNT(sCreditsV29Guests)) return false;
    if (gSaveContext.sceneLayer != sCreditsV29Guests[i].layer) return false;
    return actor->room == 0 && (sCreditsV29Guests[i].layer == 4 ?
        play->sceneId == SCENE_CASTLE_COURTYARD_ZELDA && LINK_IS_CHILD :
        play->sceneId == SCENE_LON_LON_RANCH);
}
static s32 ElfMsg2_CreditsV29DanceFrame(PlayState* play) {
    Actor* row = play->actorCtx.actorLists[ACTORCAT_NPC].head;
    while (row != NULL) {
        if (row->id == ACTOR_DEMO_EC && row->params == 26 && row->update != NULL)
            return (s32)((DemoEc*)row)->skelAnime.curFrame % 59;
        row = row->next;
    }
    return play->gameplayFrames % 59;
}
static void ElfMsg2_DrawCreditsV29(Actor* actor, PlayState* play) {
    s32 type = actor->params - 0x3FA0;
    CreditsV29Guest* guest = &sCreditsV29Guests[type];
    s32 slot = Object_GetSlot(&play->objectCtx, guest->object);
    CreditsV29Dance* dance = &sCreditsV29Dance[ElfMsg2_CreditsV29DanceFrame(play)];
    s32 row = type == 13 || type == 14 || type == 5;
    f32 danceAmount = 1.0f; /* Keep the approved four-man row and Fanboy dance. */
    s32 conversation = type == 15 || type == 20;
    s32 i;
    s32 frame = actor->home.rot.x;
    f32 idle = Math_SinS((s16)(frame * 410 + type * 2700));
    f32 beat = Math_SinS((s16)(frame * 1024));
    f32 beat2 = Math_CosS((s16)(frame * 1024));
    Mtx* matrices;
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx,slot)) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, (guest->bones + (type == 20 ? 1 : 0)) * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"credits_v29",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < guest->bones; i++) {
        Vec3f* pivot = &guest->pivots[i];
        Matrix_Push();
        if (row) {
            Matrix_Translate(0,3500,0,MTXMODE_APPLY);
            Matrix_RotateY(BINANG_TO_RAD(dance->angles[0].y) * danceAmount,MTXMODE_APPLY);
            Matrix_Translate(0,-3500,0,MTXMODE_APPLY);
        } else if (conversation) {
            Matrix_RotateY(idle*0.035f,MTXMODE_APPLY);
        } else if (guest->bones > 1 && type != 12 && type != 21) {
            /* Stationary legs remain planted; head and arms provide the idle. */
        }
        if (i > 0) {
            Matrix_Translate(pivot->x,pivot->y,pivot->z,MTXMODE_APPLY);
            if (row) {
                Matrix_RotateZYX((s16)(dance->angles[i].x*danceAmount),(s16)(dance->angles[i].y*danceAmount),(s16)(dance->angles[i].z*danceAmount),MTXMODE_APPLY);
            } else if (conversation) {
                f32 speaking = 0.5f + 0.5f * Math_SinS((s16)(frame * 1800 +
                    (type == 20 ? 0x8000 : 0) + (i == 3 ? 0x2000 : 0)));
                if (i == 1) {
                    Matrix_RotateY(idle * 0.06f,MTXMODE_APPLY);
                    Matrix_RotateX(speaking * 0.06f,MTXMODE_APPLY);
                } else {
                    f32 side = i == 2 ? 1.0f : -1.0f;
                    f32 reach = type == 20 && i == 3 ? 0.55f : 0.85f;
                    Matrix_RotateX(-0.12f - speaking * reach,MTXMODE_APPLY);
                    Matrix_RotateZ(-side * (0.08f + speaking * 0.20f),MTXMODE_APPLY);
                }
            } else if (type == 7 || type == 11) {
                f32 speech = 0.5f + 0.5f * Math_SinS((s16)(frame * 1800 +
                    (type == 11 ? 0x8000 : 0) + (i == 3 ? 0x2000 : 0)));
                if (i == 1) {
                    Matrix_RotateY(idle * 0.10f,MTXMODE_APPLY);
                    Matrix_RotateX(0.015f + speech * 0.10f,MTXMODE_APPLY);
                } else {
                    f32 side = i == 2 ? 1.0f : -1.0f;
                    Matrix_RotateX(-0.12f - speech * (i == 2 ? 1.10f : 0.85f),MTXMODE_APPLY);
                    Matrix_RotateZ(-side * (0.12f + speech * 0.30f),MTXMODE_APPLY);
                }
            } else if (type == 4) {
                f32 flap = Math_SinS((s16)(frame * 6144 + (i == 3 ? 0x2000 : 0)));
                if (i == 1) {
                    Matrix_RotateY(beat * 0.14f,MTXMODE_APPLY);
                    Matrix_RotateX(flap * 0.12f,MTXMODE_APPLY);
                } else {
                    f32 side = i == 2 ? 1.0f : -1.0f;
                    Matrix_RotateZ(side * (0.30f + flap * 0.95f),MTXMODE_APPLY);
                    Matrix_RotateX(beat2 * 0.28f,MTXMODE_APPLY);
                }
            } else if (type <= 3) {
                static f32 flipperBase[4] = { -0.65f, -0.50f, -0.45f, -0.45f };
                f32 flap = Math_SinS((s16)(frame * 6144 + type * 0x3000 +
                    (i == 3 ? 0x2000 : 0)));
                if (i == 1) {
                    Matrix_RotateY(beat * 0.14f,MTXMODE_APPLY);
                    Matrix_RotateX(flap * 0.12f,MTXMODE_APPLY);
                } else {
                    f32 side = i == 2 ? 1.0f : -1.0f;
                    /* These four assets already have lowered flippers. Their
                     * individual neutral angle keeps the broad stroke outside
                     * the belly instead of rotating a wing through the body. */
                    Matrix_RotateZ(side * (flipperBase[type] + flap * 0.95f),MTXMODE_APPLY);
                    Matrix_RotateX(beat2 * 0.28f,MTXMODE_APPLY);
                }
            } else if (i == 1) {
                Matrix_RotateY(idle*.025f,MTXMODE_APPLY);
                Matrix_RotateX(beat*.008f,MTXMODE_APPLY);
            } else if (type == 24) {
                f32 side = i == 2 ? 1.0f : -1.0f;
                f32 gesture = Math_SinS((s16)(frame * 750));
                Matrix_RotateZ(side * (1.18f + gesture * 0.06f),MTXMODE_APPLY);
                Matrix_RotateX(-0.12f + idle * 0.05f,MTXMODE_APPLY);
            } else if (type == 18 || type == 19) {
                f32 side = i == 2 ? 1.0f : -1.0f;
                f32 groove = Math_SinS((s16)(frame * 2048));
                f32 groove2 = Math_CosS((s16)(frame * 2048));
                Matrix_RotateX(side * groove * 0.35f,MTXMODE_APPLY);
                Matrix_RotateZ(side * (0.08f + groove2 * 0.20f),MTXMODE_APPLY);
            } else if (type == 21) {
                Matrix_RotateZ((i == 2 ? 1.0f : -1.0f)*(.55f + idle*.01f),MTXMODE_APPLY);
            } else if (type == 22 || type == 23) {
                f32 side = i == 2 ? 1.0f : -1.0f;
                Matrix_RotateZ(side * (0.10f + idle * 0.014f),MTXMODE_APPLY);
                Matrix_RotateX((type == 23 && i == 3 ? -0.15f : 0.025f) + idle * 0.02f,MTXMODE_APPLY);
            } else if (type == 10 && i == 2) {
                Matrix_RotateY(idle*.09f,MTXMODE_APPLY);
            } else if (type != 12 && type != 10) {
                Matrix_RotateZ((i == 2 ? 1.0f : -1.0f)*idle*.012f,MTXMODE_APPLY);
            }
            Matrix_Translate(-pivot->x,-pivot->y,-pivot->z,MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i],"credits_v29",2);
        if (type == 20 && i == 3) {
            /* Same arm/body transform: the can cannot drift away while dancing. */
            Matrix_Translate(2360.0f,4400.0f,350.0f,MTXMODE_APPLY);
            Matrix_Scale(1.30f,1.30f,1.30f,MTXMODE_APPLY);
            MATRIX_TO_MTX(&matrices[4],"credits_v33_can",1);
        }
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++,0x06,play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++,0x0D,matrices);
    gSPDisplayList(POLY_OPA_DISP++,guest->dl);
    if (type == 20) {
        /* Reuse the existing single-matrix can in this already-loaded bank. */
        gSPSegment(POLY_OPA_DISP++,0x0D,&matrices[4]);
        gSPDisplayList(POLY_OPA_DISP++,gCreditsV29PepsiCanDL);
    }
    gSPSegment(POLY_OPA_DISP++,0x06,OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++,0x0D,OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx,"credits_v29",3);
}
static void ElfMsg2_InitCreditsV29(Actor* actor, PlayState* play) {
    CreditsV29Guest* guest = &sCreditsV29Guests[actor->params - 0x3FA0];
    Actor_ChangeCategory(play,&play->actorCtx,actor,ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->cullingVolumeDistance = 2200.0f;
    actor->cullingVolumeScale = 120.0f;
    actor->cullingVolumeDownward = 140.0f;
    actor->attentionRangeType = ATTENTION_RANGE_0;
    Actor_SetScale(actor,guest->scale);
    ActorShape_Init(&actor->shape,0.0f,
        guest->bones > 1 && actor->params != 0x3FAC ? ActorShadow_DrawCircle : NULL,
        actor->params <= 0x3FA4 ? 20.0f : 28.0f);
    Actor_UpdateBgCheckInfo(play,actor,0.0f,0.0f,0.0f,UPDBGCHECKINFO_FLAG_2);
    if (actor->floorPoly != NULL && actor->floorHeight > BGCHECK_Y_MIN + 1.0f)
        actor->world.pos.y = actor->floorHeight;
    if (actor->params == 0x3FB0 && actor->shape.rot.x == 0x4000)
        actor->world.pos.y += 1.75f; /* Sideways can radius: bottom meets floor. */
    if (actor->params == 0x3FB8) {
        /* Deliberate credits-only stage cheat requested by the author. The box
         * hides the legs; its collision top must not lift Terri above the shot. */
        actor->world.pos.y = 28.0f;
        actor->shape.shadowDraw = NULL;
    }
    actor->home.rot.x = (s16)play->gameplayFrames;
    actor->draw = ElfMsg2_DrawCreditsV29;
}
static void ElfMsg2_UpdateCreditsV29(Actor* actor, PlayState* play) {
    /* Pose clock follows actor updates, so the native final freeze also stops our idle. */
    actor->home.rot.x = (s16)play->gameplayFrames;
}

/* Native credits layers only. No collision, dialogue, story flags or camera edits. */
#include "assets/objects/object_credits_v38_ruto/object_credits_v38_ruto.h"
extern Gfx gCreditsV38MeowthDL[];
extern Gfx gCreditsV38WawarioDL[];
extern Gfx gCreditsV38WawaluigiDL[];
typedef struct { SkelAnime skel; Vec3s joint[23]; Vec3s morph[23]; Actor* owner; } CreditsV38Ruto;
static CreditsV38Ruto sCreditsV38Ruto;
static s32 ElfMsg2_IsCreditsV38(Actor* actor,PlayState* play) {
    s32 type=(u16)actor->params-0x7F50;
    if (gSaveContext.gameMode!=GAMEMODE_END_CREDITS) return false;
    return (type==0 && play->sceneId==SCENE_GERUDO_VALLEY && gSaveContext.sceneLayer==6) ||
        ((type==1 || type==2) && play->sceneId==SCENE_GERUDOS_FORTRESS && gSaveContext.sceneLayer==5) ||
        (type==3 && play->sceneId==SCENE_ZORAS_DOMAIN && gSaveContext.sceneLayer==4);
}
static void ElfMsg2_DrawCreditsV38(Actor* actor,PlayState* play) {
    static Vec3f pivots[3][4]={
        {{0,0,0},{-1,1190,0},{-249,942,0},{247,942,0}},
        {{0,0,0},{0,7317,0},{1463,6585,0},{-1463,6585,0}},
        {{0,0,0},{0,7788,0},{986,6901,0},{-986,6901,0}}
    };
    static Gfx* lists[]={gCreditsV38MeowthDL,gCreditsV38WawarioDL,gCreditsV38WawaluigiDL};
    static Lights1 light=gdSPDefLights1(95,95,100,160,160,150,30,70,60);
    static void* eyes[]={gCreditsV38RutoEyeOpenTex,gCreditsV38RutoEyeHalfTex,gCreditsV38RutoEyeClosedTex};
    s32 type=(u16)actor->params-0x7F50;
    s32 slot=Object_GetSlot(&play->objectCtx,type==3?OBJECT_CREDITS_V38_RUTO:OBJECT_CREDITS_V38_DESERT);
    s32 i;
    s32 eye=(play->gameplayFrames%90<3)?2:((play->gameplayFrames%90<6)?1:0);
    f32 wave=Math_SinS((s16)(play->gameplayFrames*640+type*8000));
    Mtx* m;
    if (slot<0 || !Object_IsLoaded(&play->objectCtx,slot)) return;
    if (type==3 && sCreditsV38Ruto.owner!=actor) return;
    m=GRAPH_ALLOC(play->state.gfxCtx,4*sizeof(Mtx));
    if (m==NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"credits_v38",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    gSPSegment(POLY_OPA_DISP++,6,play->objectCtx.slots[slot].segment);
    if (type==3) {
        gSPSegment(POLY_OPA_DISP++,8,SEGMENTED_TO_VIRTUAL(eyes[eye]));
        gDPSetEnvColor(POLY_OPA_DISP++,0,0,0,255);
        gSPSegment(POLY_OPA_DISP++,12,ACTOR_SETUP_OPA_DL);
        SkelAnime_DrawFlexOpa(play,sCreditsV38Ruto.skel.skeleton,sCreditsV38Ruto.skel.jointTable,sCreditsV38Ruto.skel.dListCount,NULL,NULL,actor);
    } else {
        for (i=0;i<4;i++) {
            Vec3f* pivot=&pivots[type][i];
            Matrix_Push();
            Matrix_Translate(pivot->x,pivot->y,pivot->z,MTXMODE_APPLY);
            if (i==1) Matrix_RotateY(wave*.04f,MTXMODE_APPLY);
            if (i>=2) {
                Matrix_RotateZ((i==2?1.0f:-1.0f)*(.08f+wave*.055f),MTXMODE_APPLY);
                Matrix_RotateX(wave*.06f,MTXMODE_APPLY);
            }
            Matrix_Translate(-pivot->x,-pivot->y,-pivot->z,MTXMODE_APPLY);
            MATRIX_TO_MTX(&m[i],"credits_v38",2);
            Matrix_Pop();
        }
        gSPSetLights1(POLY_OPA_DISP++,light);
        gSPSegment(POLY_OPA_DISP++,13,m);
        gSPDisplayList(POLY_OPA_DISP++,lists[type]);
    }
    gSPSegment(POLY_OPA_DISP++,6,OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++,13,OS_PHYSICAL_TO_K0(gSegments[13]));
    if (type==3) gSPSegment(POLY_OPA_DISP++,12,OS_PHYSICAL_TO_K0(gSegments[12]));
    CLOSE_DISPS(play->state.gfxCtx,"credits_v38",3);
}
static void ElfMsg2_UpdateCreditsV38(Actor* actor,PlayState* play) {
    s32 slot;
    if ((u16)actor->params==0x7F53) {
        slot=Object_GetSlot(&play->objectCtx,OBJECT_CREDITS_V38_RUTO);
        if (slot<0 || !Object_IsLoaded(&play->objectCtx,slot)) return;
        actor->objectSlot=slot;
        Actor_SetObjectDependency(play,actor);
        if (sCreditsV38Ruto.owner!=actor || actor->home.rot.z==0) {
            SkelAnime_InitFlex(play,&sCreditsV38Ruto.skel,&gCreditsV38RutoSkel,&gCreditsV38RutoIdleHandsOnHipsAnim,sCreditsV38Ruto.joint,sCreditsV38Ruto.morph,23);
            sCreditsV38Ruto.owner=actor; actor->home.rot.z=1;
        }
        SkelAnime_Update(&sCreditsV38Ruto.skel);
    }
}
static void ElfMsg2_InitCreditsV38(Actor* actor,PlayState* play) {
    s32 type=(u16)actor->params-0x7F50;
    actor->flags=ACTOR_FLAG_UPDATE_CULLING_DISABLED|ACTOR_FLAG_DRAW_CULLING_DISABLED;
    Actor_ChangeCategory(play,&play->actorCtx,actor,ACTORCAT_NPC);
    Actor_SetScale(actor,type==0?.018f:(type==1?.0075f:(type==2?.0075f:.01f)));
    actor->home.rot.z=0;
    actor->draw=ElfMsg2_DrawCreditsV38;
}

/* Inert props only: no weapons, timers, scene switches or collision walls. */
/* One solid hull during normal gameplay only. The barrel stays passable.
 * Native player OC resolves against a single immovable body, including the
 * middle of the hull. No attacks, damage, targeting or story flags. */
static void ElfMsg2_TankCollisionV42(ElfMsg2* this, PlayState* play) {
    if (!this->tankCollidersReady) return;
    Collider_UpdateCylinder(&this->actor,&this->wallaceCollider);
    CollisionCheck_SetOC(play,&play->colChkCtx,&this->wallaceCollider.base);
}

/* V43 room-local guests. No extra object slots, save writes or cutscene camera edits. */
extern Gfx gHarkinianV43DL[],gMosebyV43DL[],gSkeletonV43DL[];
static s32 ElfMsg2_IsGuestV43(Actor* actor,PlayState* play) {
    return (actor->params==0x7FAA && play->sceneId==SCENE_CASTLE_COURTYARD_ZELDA && actor->room==0) ||
           (actor->params==0x7FAB && play->sceneId==SCENE_LAKE_HYLIA && actor->room==0) ||
           (actor->params==0x7FAC && play->sceneId==SCENE_SHADOW_TEMPLE && actor->room==21);
}
static void ElfMsg2_DrawGuestV43(Actor* actor,PlayState* play) {
    static Vec3f kingPivots[4]={{0,0,0},{0,6784,0},{-1995,6984,0},{1995,6984,0}};
    static Vec3f mosebyPivots[4]={{0,0,0},{0,6394,165},{-1484,5306,0},{1484,5306,0}};
    static Vec3f skeletonPivots[4]={{0,0,0},{0,6273,0},{-1008,6217,429},{1008,6217,429}};
    s32 king=actor->params==0x7FAA;
    s32 skeleton=actor->params==0x7FAC;
    s32 talking=play->msgCtx.talkActor==actor && Message_GetState(&play->msgCtx)!=TEXT_STATE_NONE;
    s32 i;
    f32 wave=Math_SinS((s16)(play->gameplayFrames*(king?720:talking?1000:420)));
    Vec3f* pivots=king?kingPivots:skeleton?skeletonPivots:mosebyPivots;
    void* room=ElfMsg2_PepsiRoom(actor,play);
    Mtx* matrices;
    if (room==NULL) return;
    /* The King is present in the throne room, only drawn while that room is viewed. */
    if (king && (play->csCtx.state==CS_STATE_IDLE || play->csCtx.actorCues[1]==NULL)) return;
    matrices=GRAPH_ALLOC(play->state.gfxCtx,4*sizeof(Mtx));
    if (matrices==NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"guests_v43",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for(i=0;i<4;i++) {
        Vec3f* p=&pivots[i];
        Matrix_Push();
        if(i==1) {
            Matrix_Translate(p->x,p->y,p->z,MTXMODE_APPLY);
            Matrix_RotateY(wave*(talking||king?.085f:.025f),MTXMODE_APPLY);
            Matrix_RotateX(Math_SinS((s16)(play->gameplayFrames*550))*.025f,MTXMODE_APPLY);
            Matrix_Translate(-p->x,-p->y,-p->z,MTXMODE_APPLY);
        } else if(i>1) {
            f32 side=i==2?1.f:-1.f;
            f32 speech=Math_SinS((s16)(play->gameplayFrames*900+i*0x4000));
            Matrix_Translate(p->x,p->y,p->z,MTXMODE_APPLY);
            Matrix_RotateX((king?-.35f:talking?-.20f:0.f)+speech*(king?.18f:talking?.16f:.035f),MTXMODE_APPLY);
            Matrix_RotateZ(side*wave*(king?.16f:talking?.10f:.025f),MTXMODE_APPLY);
            Matrix_Translate(-p->x,-p->y,-p->z,MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i],"guests_v43",2);Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++,3,room);
    gSPSegment(POLY_OPA_DISP++,13,matrices);
    gSPDisplayList(POLY_OPA_DISP++,king?gHarkinianV43DL:skeleton?gSkeletonV43DL:gMosebyV43DL);
    gSPSegment(POLY_OPA_DISP++,3,OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++,13,OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx,"guests_v43",3);
}
static Actor* ElfMsg2_GuestShipV43(PlayState* play) {
    Actor* ship=play->actorCtx.actorLists[ACTORCAT_BG].head;
    while(ship!=NULL) {
        if(ship->id==ACTOR_BG_HAKA_SHIP && ship->params==0 && ship->update!=NULL) return ship;
        ship=ship->next;
    }
    return NULL;
}
static void ElfMsg2_InitGuestV43(ElfMsg2* this,PlayState* play) {
    Actor* actor=&this->actor;
    s32 king=actor->params==0x7FAA;
    if(gSaveContext.language!=LANGUAGE_GER || gSaveContext.gameMode!=GAMEMODE_NORMAL ||
       (king?!LINK_IS_CHILD:LINK_IS_CHILD)) {Actor_Kill(actor);return;}
    Actor_ChangeCategory(play,&play->actorCtx,actor,ACTORCAT_NPC);
    actor->flags=ACTOR_FLAG_FRIENDLY|ACTOR_FLAG_UPDATE_CULLING_DISABLED|ACTOR_FLAG_DRAW_CULLING_DISABLED;
    if(!king) actor->flags|=ACTOR_FLAG_ATTENTION_ENABLED;
    actor->naviEnemyId=0xFF;actor->attentionRangeType=ATTENTION_RANGE_1;
    actor->textId=actor->params==0x7FAB?0x7210:0x7211;
    Actor_SetScale(actor,king?.009f:.01f);Actor_SetFocus(actor,king?80:64);
    ActorShape_Init(&actor->shape,0,ActorShadow_DrawCircle,king?22:15);
    actor->draw=ElfMsg2_DrawGuestV43;
}
static void ElfMsg2_UpdateGuestV43(ElfMsg2* this,PlayState* play) {
    Actor* actor=&this->actor;
    Actor* ship;
    if(actor->params==0x7FAA) return;
    if(actor->params==0x7FAC) {
        ship=ElfMsg2_GuestShipV43(play);
        if(ship==NULL) {actor->draw=NULL;return;}
        actor->draw=ElfMsg2_DrawGuestV43;
        /* Deck side: clear of the Triforce, Stalfos spawn points and exit edge. */
        actor->world.pos.x=ship->world.pos.x-190;
        actor->world.pos.y=ship->world.pos.y+232;
        actor->world.pos.z=ship->world.pos.z-135;
    }
    Actor_SetFocus(actor,64);
    if(play->csCtx.state!=CS_STATE_IDLE || Player_InCsMode(play)) {actor->flags&=~ACTOR_FLAG_ATTENTION_ENABLED;return;}
    actor->flags|=ACTOR_FLAG_ATTENTION_ENABLED;
    if(Actor_TalkOfferAccepted(actor,play) || (play->msgCtx.talkActor==actor && Message_GetState(&play->msgCtx)!=TEXT_STATE_NONE)) return;
    if(actor->xzDistToPlayer<220) Math_SmoothStepToS(&actor->shape.rot.y,actor->yawTowardsPlayer,6,600,0);
    if(Message_GetState(&play->msgCtx)==TEXT_STATE_NONE && actor->xzDistToPlayer<110 && fabsf(actor->yDistToPlayer)<55) Actor_OfferTalk(actor,play,105);
}

/* Supplied low-poly Starwalker. Private room-local NPCs; no quest/switch writes. */
typedef struct {
    s16 scene;
    s8 room;
    u8 childOnly;
    u8 style;
    u16 text;
    Gfx* displayList;
    Vec3f* pivots;
    u8 boneCount;
} DeltaruneGuestV51Spec;
extern Gfx gStarwalkerV51Role0DL[];
extern Gfx gStarwalkerV51Role1DL[];
extern Gfx gStarwalkerV51Role2DL[];
extern Gfx gStarwalkerV51Role3DL[];
extern Gfx gStarwalkerV51Role4DL[];
extern Gfx gStarwalkerV51Role5DL[];
extern Gfx gStarwalkerV51Role6DL[];
extern Gfx gStarwalkerV51Role7DL[];
extern Gfx gStarwalkerV51Role8DL[];
extern Gfx gStarwalkerV51Role9DL[];
extern Gfx gStarwalkerV51Role10DL[];
static Vec3f sStarwalkerV51Pivots[7]={{77,2241,13},{456,1973,13},{309,1135,13},{10,249,13},{-380,2152,13},{-666,1304,13},{-885,418,13}};
extern Gfx gKrisV52DL[];
static Vec3f sKrisV52Pivots[4]={{0,0,0},{-3,3918,-202},{567,3552,-171},{-572,3552,-171}};
extern Gfx gSusieV52DL[];
static Vec3f sSusieV52Pivots[4]={{0,0,0},{4,3941,-49},{945,3866,-49},{-954,3866,-49}};
extern Gfx gRalseiV52DL[];
static Vec3f sRalseiV52Pivots[4]={{0,0,0},{3,3227,10},{775,3166,10},{-782,3166,10}};
static DeltaruneGuestV51Spec sDeltaruneGuestsV51[]={
    { SCENE_DEKU_TREE, 1, 0, 0, 0x7216, gStarwalkerV51Role0DL, sStarwalkerV51Pivots, 7 },
    { SCENE_DODONGOS_CAVERN, 4, 0, 0, 0x7217, gStarwalkerV51Role1DL, sStarwalkerV51Pivots, 7 },
    { SCENE_JABU_JABU, 2, 0, 0, 0x7218, gStarwalkerV51Role2DL, sStarwalkerV51Pivots, 7 },
    { SCENE_FOREST_TEMPLE, 4, 0, 0, 0x7219, gStarwalkerV51Role3DL, sStarwalkerV51Pivots, 7 },
    { SCENE_FIRE_TEMPLE, 17, 0, 0, 0x721A, gStarwalkerV51Role4DL, sStarwalkerV51Pivots, 7 },
    { SCENE_WATER_TEMPLE, 6, 0, 0, 0x721B, gStarwalkerV51Role5DL, sStarwalkerV51Pivots, 7 },
    { SCENE_SHADOW_TEMPLE, 7, 0, 0, 0x721C, gStarwalkerV51Role6DL, sStarwalkerV51Pivots, 7 },
    { SCENE_SPIRIT_TEMPLE, 14, 0, 0, 0x721D, gStarwalkerV51Role7DL, sStarwalkerV51Pivots, 7 },
    { SCENE_INSIDE_GANONS_CASTLE, 16, 0, 0, 0x721E, gStarwalkerV51Role8DL, sStarwalkerV51Pivots, 7 },
    { SCENE_BOTTOM_OF_THE_WELL, 3, 0, 0, 0x721F, gStarwalkerV51Role9DL, sStarwalkerV51Pivots, 7 },
    { SCENE_ICE_CAVERN, 8, 0, 0, 0x7220, gStarwalkerV51Role10DL, sStarwalkerV51Pivots, 7 },
    { SCENE_DODONGOS_CAVERN, 2, 1, 1, 0x7221, gKrisV52DL, sKrisV52Pivots, 4 },
    { SCENE_DODONGOS_CAVERN, 2, 1, 2, 0x7222, gSusieV52DL, sSusieV52Pivots, 4 },
    { SCENE_DODONGOS_CAVERN, 2, 1, 3, 0x7223, gRalseiV52DL, sRalseiV52Pivots, 4 },
};
static s32 ElfMsg2_IsDeltaruneV51(Actor* actor) {
    u16 role=(u16)actor->params-0x7FB1;
    return role<ARRAY_COUNT(sDeltaruneGuestsV51);
}
static void ElfMsg2_DrawDeltaruneV51(Actor* actor,PlayState* play) {
    DeltaruneGuestV51Spec* spec=&sDeltaruneGuestsV51[(u16)actor->params-0x7FB1];
    void* room=ElfMsg2_PepsiRoom(actor,play);
    Mtx* matrices;
    s32 i;
    s32 speaking=play->msgCtx.talkActor==actor && Message_GetState(&play->msgCtx)!=TEXT_STATE_NONE;
    f32 idle=Math_SinS((s16)(play->gameplayFrames*600+actor->params*2300));
    f32 talk=Math_SinS((s16)(play->gameplayFrames*1100));
    if(room==NULL) return;
    matrices=GRAPH_ALLOC(play->state.gfxCtx,spec->boneCount*sizeof(Mtx));
    if(matrices==NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"deltarune_guests",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for(i=0;i<spec->boneCount;i++) {
        Vec3f* p=&spec->pivots[i];
        Matrix_Push();
        Matrix_Translate(p->x,p->y,p->z,MTXMODE_APPLY);
        if(spec->style==0) {
            if(i==0) Matrix_RotateZ(idle*.018f,MTXMODE_APPLY);
            else if(i==1||i==4) Matrix_RotateY(idle*(i==1?.018f:-.018f),MTXMODE_APPLY);
        } else if(i==1) {
            Matrix_RotateY(idle*.025f+(speaking?talk*.035f:0),MTXMODE_APPLY);
        } else if(i==2||i==3) {
            Matrix_RotateZ(idle*(i==2?.025f:-.025f),MTXMODE_APPLY);
            if(speaking) Matrix_RotateX(talk*(spec->style==2?.13f:.07f),MTXMODE_APPLY);
        }
        Matrix_Translate(-p->x,-p->y,-p->z,MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i],"deltarune_guests",2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++,3,room);
    gSPSegment(POLY_OPA_DISP++,13,matrices);
    gSPDisplayList(POLY_OPA_DISP++,spec->displayList);
    gSPSegment(POLY_OPA_DISP++,3,OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++,13,OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx,"deltarune_guests",3);
}
static void ElfMsg2_InitDeltaruneV51(ElfMsg2* this,PlayState* play) {
    Actor* actor=&this->actor;
    DeltaruneGuestV51Spec* spec=&sDeltaruneGuestsV51[(u16)actor->params-0x7FB1];
    Collider_InitCylinder(play,&this->wallaceCollider);
    if(play->sceneId!=spec->scene||actor->room!=spec->room||
       gSaveContext.language!=LANGUAGE_GER||gSaveContext.gameMode!=GAMEMODE_NORMAL||
       (spec->childOnly&&!LINK_IS_CHILD)) {Actor_Kill(actor);return;}
    Actor_ChangeCategory(play,&play->actorCtx,actor,ACTORCAT_NPC);
    actor->flags=ACTOR_FLAG_FRIENDLY|ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->naviEnemyId=0xFF;
    actor->attentionRangeType=ATTENTION_RANGE_1;
    actor->textId=spec->text;
    actor->colChkInfo.mass=MASS_IMMOVABLE;
    Actor_SetScale(actor,.01f);
    Actor_SetFocus(actor,spec->style==0?32:42);
    ActorShape_Init(&actor->shape,0,ActorShadow_DrawCircle,spec->style==0?12:16);
    Collider_SetCylinder(play,&this->wallaceCollider,actor,&sWallaceCylinderInit);
    this->wallaceCollider.dim.radius=spec->style==0?12:14;
    this->wallaceCollider.dim.height=spec->style==0?40:55;
    actor->draw=ElfMsg2_DrawDeltaruneV51;
}
static void ElfMsg2_UpdateDeltaruneV51(ElfMsg2* this,PlayState* play) {
    Actor* actor=&this->actor;
    DeltaruneGuestV51Spec* spec=&sDeltaruneGuestsV51[(u16)actor->params-0x7FB1];
    Actor_UpdateBgCheckInfo(play,actor,8,20,0,UPDBGCHECKINFO_FLAG_2);
    if(actor->floorHeight>BGCHECK_Y_MIN+1 && fabsf(actor->floorHeight-actor->home.pos.y)<12)
        actor->world.pos.y=actor->floorHeight;
    Collider_UpdateCylinder(actor,&this->wallaceCollider);
    CollisionCheck_SetOC(play,&play->colChkCtx,&this->wallaceCollider.base);
    Actor_SetFocus(actor,spec->style==0?32:42);
    if(play->csCtx.state!=CS_STATE_IDLE||Player_InCsMode(play)) {
        actor->flags&=~ACTOR_FLAG_ATTENTION_ENABLED;return;
    }
    actor->flags|=ACTOR_FLAG_ATTENTION_ENABLED;
    if(Actor_TalkOfferAccepted(actor,play)||
       (play->msgCtx.talkActor==actor&&Message_GetState(&play->msgCtx)!=TEXT_STATE_NONE)) return;
    if(actor->xzDistToPlayer<180) Math_SmoothStepToS(&actor->shape.rot.y,actor->yawTowardsPlayer,6,650,0);
    if(actor->xzDistToPlayer<125 && fabsf(actor->yDistToPlayer)<65) Actor_OfferTalk(actor,play,125);
}

/* Credits-only additions. No text, collision, camera or progress changes. */
extern Gfx gCreditsStarwalkerV53DL[];
static s32 ElfMsg2_IsCreditsV53(Actor* actor,PlayState* play) {
    if(gSaveContext.gameMode!=GAMEMODE_END_CREDITS || actor->room!=0) return false;
    return (actor->params==0x7FBF && play->sceneId==SCENE_LAKE_HYLIA && gSaveContext.sceneLayer==5) ||
        (actor->params==0x7FC0 && play->sceneId==SCENE_LON_LON_RANCH && gSaveContext.sceneLayer==10);
}
static void ElfMsg2_DrawCreditsV53(Actor* actor,PlayState* play) {
    static Vec3f moseby[4]={{0,0,0},{0,6394,165},{-1484,5306,0},{1484,5306,0}};
    static Vec3f starwalker[7]={{77,2241,13},{456,1973,13},{309,1135,13},{10,249,13},{-380,2152,13},{-666,1304,13},{-885,418,13}};
    s32 star=actor->params==0x7FC0;
    s32 count=star?7:4;
    Vec3f* pivots=star?starwalker:moseby;
    void* room=ElfMsg2_PepsiRoom(actor,play);
    f32 wave=Math_SinS((s16)(play->gameplayFrames*530));
    s32 i;
    Mtx* matrices;
    if(room==NULL || (star && (play->csCtx.curFrame<317 || play->csCtx.curFrame>472))) return;
    matrices=GRAPH_ALLOC(play->state.gfxCtx,count*sizeof(Mtx));
    if(matrices==NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"credits_guests_v53",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for(i=0;i<count;i++) {
        Vec3f* p=&pivots[i];
        Matrix_Push();Matrix_Translate(p->x,p->y,p->z,MTXMODE_APPLY);
        if(star) {
            if(i==0) Matrix_RotateZ(wave*.014f,MTXMODE_APPLY);
        } else if(i==1) {
            Matrix_RotateY(wave*.03f,MTXMODE_APPLY);
        } else if(i>=2) {
            Matrix_RotateX(wave*.055f,MTXMODE_APPLY);
            Matrix_RotateZ((i==2?1.f:-1.f)*wave*.035f,MTXMODE_APPLY);
        }
        Matrix_Translate(-p->x,-p->y,-p->z,MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i],"credits_guests_v53",2);Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++,3,room);
    gSPSegment(POLY_OPA_DISP++,13,matrices);
    gSPDisplayList(POLY_OPA_DISP++,star?gCreditsStarwalkerV53DL:gMosebyV43DL);
    gSPSegment(POLY_OPA_DISP++,3,OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++,13,OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx,"credits_guests_v53",3);
}
static void ElfMsg2_InitCreditsV53(Actor* actor,PlayState* play) {
    actor->flags=ACTOR_FLAG_UPDATE_CULLING_DISABLED|ACTOR_FLAG_DRAW_CULLING_DISABLED;
    Actor_ChangeCategory(play,&play->actorCtx,actor,ACTORCAT_NPC);
    Actor_SetScale(actor,.01f);
    ActorShape_Init(&actor->shape,0,ActorShadow_DrawCircle,actor->params==0x7FC0?12:15);
    actor->draw=ElfMsg2_DrawCreditsV53;
}

/* Parked child-castle Mini. Native Navi text; no quest flags, AI or object slot. */
extern Gfx gBeanMiniV56DL[];
static s32 ElfMsg2_IsMiniV56(Actor* actor,PlayState* play) {
    return actor->params==0x7FC1 && play->sceneId==SCENE_HYRULE_CASTLE && actor->room==0;
}
static void ElfMsg2_DrawMiniV56(Actor* actor,PlayState* play) {
    void* room=ElfMsg2_PepsiRoom(actor,play);
    if (room==NULL) return;
    OPEN_DISPS(play->state.gfxCtx,"mini_v56",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    gSPSegment(POLY_OPA_DISP++,3,room);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++,play->state.gfxCtx,"mini_v56",2);
    gSPDisplayList(POLY_OPA_DISP++,gBeanMiniV56DL);
    gSPSegment(POLY_OPA_DISP++,3,OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx,"mini_v56",3);
}
static void ElfMsg2_InitMiniV56(ElfMsg2* this,PlayState* play) {
    Actor* actor=&this->actor;
    this->tankCollidersReady=false;
    if (LINK_IS_ADULT || gSaveContext.gameMode!=GAMEMODE_NORMAL || gSaveContext.language!=LANGUAGE_GER) {
        Actor_Kill(actor);return;
    }
    actor->flags=ACTOR_FLAG_UPDATE_CULLING_DISABLED|ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_TALK_WITH_C_UP;
    Actor_SetScale(actor,.01f);
    Actor_SetFocus(actor,38.0f);
    actor->attentionRangeType=ATTENTION_RANGE_1;
    actor->naviEnemyId=0xFF;
    actor->textId=0x7227;
    actor->world.rot.z=1; /* Reusable check spot, never sets a switch on close. */
    actor->shape.rot.x=actor->shape.rot.z=0;
    actor->draw=ElfMsg2_DrawMiniV56;
    actor->cullingVolumeDistance=1800;
    actor->cullingVolumeScale=150;
    actor->cullingVolumeDownward=100;
    ElfMsg2_SetupAction(this,ElfMsg2_WaitForTextRead);
    actor->colChkInfo.mass=MASS_IMMOVABLE;
    Collider_InitCylinder(play,&this->wallaceCollider);
    Collider_SetCylinder(play,&this->wallaceCollider,actor,&sWallaceCylinderInit);
    this->wallaceCollider.dim.radius=43;
    this->wallaceCollider.dim.height=58;
    this->tankCollidersReady=true;
}
static void ElfMsg2_UpdateMiniV56(ElfMsg2* this,PlayState* play) {
    ElfMsg2_TankCollisionV42(this,play);
    this->actionFunc(this,play);
}

void ElfMsg2_Init(Actor* thisx, PlayState* play) {
    ElfMsg2* this = (ElfMsg2*)thisx;
    if(ElfMsg2_IsMiniV56(thisx,play)) {ElfMsg2_InitMiniV56(this,play);return;}
    if(ElfMsg2_IsCreditsV53(thisx,play)) {ElfMsg2_InitCreditsV53(thisx,play);return;}
    if(ElfMsg2_IsDeltaruneV51(thisx)) {ElfMsg2_InitDeltaruneV51(this,play);return;}
    if(ElfMsg2_IsGuestV43(thisx,play)) {ElfMsg2_InitGuestV43(this,play);return;}
    if (ElfMsg2_IsCreditsV38(thisx,play)) { ElfMsg2_InitCreditsV38(thisx,play); return; }
    if (ElfMsg2_IsCreditsV29(thisx,play)) { ElfMsg2_InitCreditsV29(thisx,play); return; }
    if (ElfMsg2_IsFrankyV28(thisx,play)) { ElfMsg2_InitFrankyV28(this,play); return; }
    if (ElfMsg2_IsPenguin(thisx, play)) {
        ElfMsg2_InitPenguin(this, play);
        return;
    }
    if (ElfMsg2_IsCrazyFrog(thisx, play)) {
        ElfMsg2_InitCrazyFrog(this, play);
        return;
    }
    if (ElfMsg2_IsPingu(thisx, play)) {
        ElfMsg2_InitPingu(this, play);
        return;
    }
    if (ElfMsg2_IsGoronBomb(thisx, play)) {
        ElfMsg2_InitGoronBomb((ElfMsg2*)thisx, play);
        return;
    }
    if (ElfMsg2_IsDoofGuest(thisx, play)) {
        ElfMsg2_InitDoofGuest(this, play);
        return;
    }
    if (ElfMsg2_IsDesertGuest(thisx, play)) {
        ElfMsg2_InitDesertGuest(this, play);
        return;
    }
    if (ElfMsg2_IsMysteryMachine(thisx, play)) {
        ElfMsg2_InitMysteryMachine(this, play);
        return;
    }
    if (ElfMsg2_IsMysteryInc(thisx, play)) {
        ElfMsg2_InitMysteryInc(this, play);
        return;
    }
    if (ElfMsg2_IsKenny(thisx, play)) {
        ElfMsg2_InitKenny(this, play);
        return;
    }
    if (ElfMsg2_IsBttf(thisx, play)) {
        ElfMsg2_InitBttf(this, play);
        return;
    }
    if (ElfMsg2_IsJabba(thisx, play)) {
        ElfMsg2_InitJabba(this, play);
        return;
    }

    if (ElfMsg2_IsTriangleGuy(thisx, play)) {
        ElfMsg2_InitTriangleGuy(this, play);
        return;
    }
    if (ElfMsg2_IsYellowCast(thisx, play)) {
        ElfMsg2_InitYellowCast(this, play);
        return;
    }
    if (ElfMsg2_IsWawarioBros(thisx, play)) {
        ElfMsg2_InitWawarioBros(this, play);
        return;
    }
    if (ElfMsg2_IsSuperhero(thisx, play)) {
        ElfMsg2_InitSuperhero(this, play);
        return;
    }
    if (ElfMsg2_IsPepsiman(thisx, play)) {
        ElfMsg2_InitPepsiman(this, play);
        return;
    }

    if (ElfMsg2_IsWallace(thisx, play)) {
        ElfMsg2_InitWallace(this, play);
        return;
    }

    PRINTF(VT_FGCOL(CYAN) " Elf_Msg2_Actor_ct %04x\n\n" VT_RST, this->actor.params);
    if (!ElfMsg2_KillCheck(this, play)) {
        if ((this->actor.world.rot.x > 0) && (this->actor.world.rot.x < 8)) {
            this->actor.attentionRangeType = this->actor.world.rot.x - 1;
        }
        Actor_ProcessInitChain(thisx, sInitChain);
        if (this->actor.world.rot.y >= 0x41) {
            ElfMsg2_SetupAction(this, ElfMsg2_WaitUntilActivated);
        } else {
            ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
            this->actor.flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_TALK_WITH_C_UP;
            this->actor.textId = ElfMsg2_GetMessageId(this);
        }
        this->actor.shape.rot.x = this->actor.shape.rot.y = this->actor.shape.rot.z = 0;
        if (ElfMsg2_IsHandheldV28(thisx,play)) {
            if (gSaveContext.language != LANGUAGE_GER || gSaveContext.gameMode != GAMEMODE_NORMAL) { Actor_Kill(thisx); return; }
            Actor_SetScale(thisx,0.01f);
            Actor_SetFocus(thisx,3.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = LINK_IS_CHILD ? 0x71EA : 0x71EB;
            thisx->world.rot.z = 1;
            thisx->draw = ElfMsg2_DrawHandheldV28;
        }
        if (ElfMsg2_IsBurntBodyV28(thisx,play)) {
            if (gSaveContext.language != LANGUAGE_GER || gSaveContext.gameMode != GAMEMODE_NORMAL) { Actor_Kill(thisx); return; }
            Actor_SetScale(thisx,0.01f);
            Actor_SetFocus(thisx,6.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = 0x71E9;
            thisx->world.rot.z = 1;
            thisx->draw = ElfMsg2_DrawBurntBodyV28;
        }
        if (ElfMsg2_IsWellPropsV27(thisx,play)) {
            if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER || gSaveContext.gameMode != GAMEMODE_NORMAL) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx,0.01f);
            Actor_SetFocus(thisx,5.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = 0x71E4;
            thisx->world.rot.z = 1;
            thisx->cullingVolumeScale = 50.0f;
            thisx->cullingVolumeDownward = 50.0f;
            thisx->draw = ElfMsg2_DrawWellPropsV27;
        }
        if (ElfMsg2_IsFundstueck(thisx, play)) {
            s32 test = thisx->params == 0x3F79;
            if (gSaveContext.language != LANGUAGE_GER || (test ? !LINK_IS_CHILD : LINK_IS_CHILD)) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, test ? 2.0f : 5.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = test ? 0x608B : 0x608C;
            thisx->draw = ElfMsg2_DrawFundstueck;
        }
        if (ElfMsg2_IsPepsiCan(thisx, play)) {
            if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 4.0f);
            thisx->shape.rot.y = (s16)(thisx->home.pos.x * 71.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = 0x3073;
            thisx->draw = ElfMsg2_DrawPepsiCan;
        }
        /* Room 21 is a later west-side corridor, below the twisted hallway. */
        if (play->sceneId == SCENE_FOREST_TEMPLE && thisx->room == 21 && thisx->params == 0x3F09) {
            if (gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 5.0f);
            thisx->draw = ElfMsg2_DrawMajoraMask;
        }
        /* One German decoration; all other check spots retain their native setup. */
        if (play->sceneId == SCENE_JABU_JABU && thisx->room == 3 && thisx->params == 0x3F25) {
            if (gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 3.0f);
            thisx->draw = ElfMsg2_DrawNintendo64;
        }
    }
}

void ElfMsg2_Destroy(Actor* thisx, PlayState* play) {
    if(ElfMsg2_IsMiniV56(thisx,play)) {
        if(((ElfMsg2*)thisx)->tankCollidersReady) Collider_DestroyCylinder(play,&((ElfMsg2*)thisx)->wallaceCollider);
        return;
    }
    if(ElfMsg2_IsCreditsV53(thisx,play)) return; /* No collider. */
    if(ElfMsg2_IsDeltaruneV51(thisx)) {Collider_DestroyCylinder(play,&((ElfMsg2*)thisx)->wallaceCollider);return;}
    if(ElfMsg2_IsGuestV43(thisx,play)) return; /* No collider allocated. */
    if (ElfMsg2_IsCreditsV38(thisx,play)) return;
    if (ElfMsg2_IsCreditsV29(thisx,play)) return; /* No collider allocated. */
    if (ElfMsg2_IsFrankyV28(thisx,play)) return; /* No collider allocated. */
    if (ElfMsg2_IsPenguin(thisx, play)) {
        Collider_DestroyCylinder(play, &((ElfMsg2*)thisx)->wallaceCollider);
        return;
    }
    if (ElfMsg2_IsCrazyFrog(thisx, play)) {
        Collider_DestroyCylinder(play, &((ElfMsg2*)thisx)->wallaceCollider);
        return;
    }
    if (ElfMsg2_IsPingu(thisx, play)) {
        Collider_DestroyCylinder(play, &((ElfMsg2*)thisx)->wallaceCollider);
        return;
    }
    if (ElfMsg2_IsGoronBomb(thisx, play)) {
        Collider_DestroyCylinder(play, &((ElfMsg2*)thisx)->wallaceCollider);
        return;
    }
    if (ElfMsg2_IsDoofGuest(thisx, play) || ElfMsg2_IsDesertGuest(thisx, play) || ElfMsg2_IsMysteryInc(thisx, play) || ElfMsg2_IsBttf(thisx, play) || ElfMsg2_IsJabba(thisx, play) || ElfMsg2_IsWallace(thisx, play) || ElfMsg2_IsPepsiman(thisx, play) || ElfMsg2_IsSuperhero(thisx, play) || ElfMsg2_IsWawarioBros(thisx, play) || ElfMsg2_IsYellowCast(thisx, play)) {
        Collider_DestroyCylinder(play, &((ElfMsg2*)thisx)->wallaceCollider);
    }
}

s32 ElfMsg2_GetMessageId(ElfMsg2* this) {
    return PARAMS_GET_U(this->actor.params, 0, 8) + 0x100;
}

/**
 * Runs while Navi text is up. Kills the actor upon closing the text box unless rot.z == 1, can also set a switch flag
 * from params.
 */
void ElfMsg2_WaitForTextClose(ElfMsg2* this, PlayState* play) {
    s32 switchFlag;

    if (Actor_TextboxIsClosing(&this->actor, play)) {
        if (this->actor.world.rot.z != 1) {
            Actor_Kill(&this->actor);
            switchFlag = PARAMS_GET_U(this->actor.params, 8, 6);
            if (switchFlag != 0x3F) {
                Flags_SetSwitch(play, switchFlag);
            }
        } else {
            ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
        }
    }
}

/**
 * Runs while Navi text is not up.
 */
void ElfMsg2_WaitForTextRead(ElfMsg2* this, PlayState* play) {
    if (Actor_TalkOfferAccepted(&this->actor, play)) {
        ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextClose);
    }
}

/**
 * Idles until a switch flag is set, at which point the actor becomes interactable
 */
void ElfMsg2_WaitUntilActivated(ElfMsg2* this, PlayState* play) {
    // If (y >= 0x41) && (y <= 0x80), Idles until switch flag (actor.world.rot.y - 0x41) is set
    // If (y > 0x80), Idles forever (Bug?)
    if ((this->actor.world.rot.y >= 0x41) && (this->actor.world.rot.y <= 0x80) &&
        (Flags_GetSwitch(play, (this->actor.world.rot.y - 0x41)))) {
        ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
        this->actor.flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_TALK_WITH_C_UP;
        this->actor.textId = ElfMsg2_GetMessageId(this);
    }
}

void ElfMsg2_Update(Actor* thisx, PlayState* play) {
    ElfMsg2* this = (ElfMsg2*)thisx;
    if(ElfMsg2_IsMiniV56(thisx,play)) {ElfMsg2_UpdateMiniV56(this,play);return;}
    if(ElfMsg2_IsCreditsV53(thisx,play)) return;
    if(ElfMsg2_IsDeltaruneV51(thisx)) {ElfMsg2_UpdateDeltaruneV51(this,play);return;}
    if(ElfMsg2_IsGuestV43(thisx,play)) {ElfMsg2_UpdateGuestV43(this,play);return;}
    if (ElfMsg2_IsCreditsV38(thisx,play)) { ElfMsg2_UpdateCreditsV38(thisx,play); return; }
    if (ElfMsg2_IsCreditsV29(thisx,play)) { ElfMsg2_UpdateCreditsV29(thisx,play); return; }
    if (ElfMsg2_IsFrankyV28(thisx,play)) { ElfMsg2_UpdateFrankyV28(this,play); return; }
    if (ElfMsg2_IsPenguin(thisx, play)) {
        ElfMsg2_UpdatePenguin(this, play);
        return;
    }
    if (ElfMsg2_IsCrazyFrog(thisx, play)) {
        ElfMsg2_UpdateCrazyFrog(this, play);
        return;
    }
    if (ElfMsg2_IsPingu(thisx, play)) {
        ElfMsg2_UpdatePingu(this, play);
        return;
    }
    if (ElfMsg2_IsGoronBomb(thisx, play)) {
        ElfMsg2_UpdateGoronBomb((ElfMsg2*)thisx, play);
        return;
    }
    if (ElfMsg2_IsDoofGuest(thisx, play)) {
        ElfMsg2_UpdateDoofGuest(this, play);
        return;
    }
    if (ElfMsg2_IsDesertGuest(thisx, play)) {
        ElfMsg2_UpdateDesertGuest(this, play);
        return;
    }
    if (ElfMsg2_IsMysteryMachine(thisx, play)) {
        ElfMsg2_UpdateMysteryMachine(this, play);
        return;
    }
    if (ElfMsg2_IsMysteryInc(thisx, play)) {
        ElfMsg2_UpdateMysteryInc(this, play);
        return;
    }
    if (ElfMsg2_IsKenny(thisx, play)) {
        ElfMsg2_UpdateKenny(this, play);
        return;
    }
    if (ElfMsg2_IsBttf(thisx, play)) {
        ElfMsg2_UpdateBttf(this, play);
        return;
    }
    if (ElfMsg2_IsJabba(thisx, play)) {
        ElfMsg2_UpdateJabba(this, play);
        return;
    }
    if (ElfMsg2_IsTriangleGuy(thisx, play)) {
        ElfMsg2_UpdateTriangleGuy(this, play);
        return;
    }
    if (ElfMsg2_IsYellowCast(thisx, play)) {
        ElfMsg2_UpdateYellowCast(this, play);
        return;
    }
    if (ElfMsg2_IsWawarioBros(thisx, play)) {
        ElfMsg2_UpdateWawarioBros(this, play);
        return;
    }
    if (ElfMsg2_IsSuperhero(thisx, play)) {
        ElfMsg2_UpdateSuperhero(this, play);
        return;
    }
    if (ElfMsg2_IsPepsiman(thisx, play)) {
        ElfMsg2_UpdatePepsiman(this, play);
        return;
    }
    if (ElfMsg2_IsWallace(thisx, play)) {
        ElfMsg2_UpdateWallace(this, play);
        return;
    }


    if (!ElfMsg2_KillCheck(this, play)) {
        this->actionFunc(this, play);
    }
}

#if DEBUG_ASSETS

static Gfx sMaterialDL[8] = {
#include "assets/overlays/ovl_Elf_Msg2/sMaterialDL.inc.c"
};

static Vtx sCubeVtx[] = {
#include "assets/overlays/ovl_Elf_Msg2/sCubeVtx.inc.c"
};

static Gfx sCubeDL[8] = {
#include "assets/overlays/ovl_Elf_Msg2/sCubeDL.inc.c"
};

void ElfMsg2_Draw(Actor* thisx, PlayState* play) {
    OPEN_DISPS(play->state.gfxCtx, "../z_elf_msg2.c", 355);

    if (R_NAVI_MSG_REGION_ALPHA == 0) {
        return;
    }

    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    gDPSetPrimColor(POLY_XLU_DISP++, 0, 0, 100, 100, 255, R_NAVI_MSG_REGION_ALPHA);
    MATRIX_FINALIZE_AND_LOAD(POLY_XLU_DISP++, play->state.gfxCtx, "../z_elf_msg2.c", 362);
    gSPDisplayList(POLY_XLU_DISP++, sMaterialDL);
    gSPDisplayList(POLY_XLU_DISP++, sCubeDL);

    CLOSE_DISPS(play->state.gfxCtx, "../z_elf_msg2.c", 367);
}
#endif

/* Rendering only: targeting, C-Up, closing and repeat behavior are all native Elf_Msg2. */
static void ElfMsg2_DrawNintendo64(Actor* thisx, PlayState* play) {
    void* roomSegment = NULL;
    if (play->roomCtx.curRoom.num == thisx->room) {
        roomSegment = play->roomCtx.curRoom.segment;
    } else if (play->roomCtx.prevRoom.num == thisx->room) {
        roomSegment = play->roomCtx.prevRoom.segment;
    }
    if (roomSegment == NULL) {
        return;
    }
    OPEN_DISPS(play->state.gfxCtx, "nintendo64", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "nintendo64", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, gNintendo64DL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "nintendo64", 3);
}

static void ElfMsg2_DrawMajoraMask(Actor* thisx, PlayState* play) {
    void* roomSegment = NULL;
    if (play->roomCtx.curRoom.num == thisx->room) {
        roomSegment = play->roomCtx.curRoom.segment;
    } else if (play->roomCtx.prevRoom.num == thisx->room) {
        roomSegment = play->roomCtx.prevRoom.segment;
    }
    if (roomSegment == NULL) {
        return;
    }
    OPEN_DISPS(play->state.gfxCtx, "majoras-mask", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "majoras-mask", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, gMajoraMaskDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "majoras-mask", 3);
}

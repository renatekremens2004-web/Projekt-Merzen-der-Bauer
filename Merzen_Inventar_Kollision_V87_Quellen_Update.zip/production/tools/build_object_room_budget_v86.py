"""Reserve the two affected dungeons’ largest model set plus32KiB, using current runtime object sizes.
Only maximal multisets need to be retained: a subset can never occupy more model RAM.
The allocator applies this only in ordinary gameplay; credits/special scene setups retain stock reservations.
"""
from pathlib import Path
from collections import Counter
import re,sys
O=Path(__file__).resolve().parent.parent;version=sys.argv[1]if len(sys.argv)>1 else'pal-1.0'
scenes=re.findall(r'DEFINE_SCENE\((\w+)_scene,[^,]+,\s*(SCENE_\w+)',(O/'include/tables/scene_table.h').read_text())[:16]
lines=['#ifndef OBJECT_ROOM_BUDGET_V86_H','#define OBJECT_ROOM_BUDGET_V86_H','typedef struct ObjectBudgetGroupV86 { const s16* ids; u32 count; } ObjectBudgetGroupV86;','typedef struct ObjectBudgetSceneV86 { s16 sceneId; const s16* keeps; u32 keepCount; const ObjectBudgetGroupV86* groups; u32 groupCount; } ObjectBudgetSceneV86;']
entries=[]
for si,(folder,scene)in enumerate(scenes):
 if si not in (1,8):continue
 D=O/f'extracted/{version}/assets/scenes/dungeons'/folder
 groups=sorted({tuple(sorted(re.findall(r'\bOBJECT_[A-Z0-9_]+\b',p.read_text())))for p in D.glob('*ObjectList.inc.c')})
 maximal=[g for g in groups if not any(Counter(g)<Counter(h)for h in groups)]
 if not maximal:continue
 keeps=set()
 for p in D.glob('*scene*.inc.c'):keeps.update(re.findall(r'SCENE_CMD_SPECIAL_FILES\([^,]+,\s*(OBJECT_\w+)\)',p.read_text()))
 keeps.discard('OBJECT_INVALID');keeps=sorted(keeps)
 if not keeps:keeps=['OBJECT_INVALID']
 for gi,g in enumerate(maximal):lines +=[f'static const s16 sBudgetIdsV86_{si}_{gi}[] = {{'+', '.join(g)+'};']
 lines +=[f'static const s16 sBudgetKeepsV86_{si}[] = {{'+', '.join(keeps)+'};',f'static const ObjectBudgetGroupV86 sBudgetGroupsV86_{si}[] = {{']
 for gi,g in enumerate(maximal):lines +=[f'    {{ sBudgetIdsV86_{si}_{gi}, ARRAY_COUNT(sBudgetIdsV86_{si}_{gi}) }},']
 lines +=['};'];entries.append(f'    {{ {scene}, sBudgetKeepsV86_{si}, ARRAY_COUNT(sBudgetKeepsV86_{si}), sBudgetGroupsV86_{si}, ARRAY_COUNT(sBudgetGroupsV86_{si}) }},')
lines+=['static const ObjectBudgetSceneV86 sObjectBudgetScenesV86[] = {',*entries,'};']
lines +=['''static u32 Scene_ObjectBytesV86(s16 id) {
    if (id == OBJECT_INVALID) return 0;
    return ALIGN16(gObjectTable[id].vromEnd - gObjectTable[id].vromStart);
}
/* The object bank is also the pause menu's temporary model/icon/coverage area.
 * Keep its largest live extent, including alignment and an 8 KiB guard, even if
 * the dungeon's ordinary object lists are smaller. Language may change without
 * reloading the scene, so reserve the largest PAL icon-language segment. */
static u32 Scene_PauseSpaceV87(PlayState* play) {
    u32 language = MAX((uintptr_t)_icon_item_nes_staticSegmentRomEnd - (uintptr_t)_icon_item_nes_staticSegmentRomStart,
                       (uintptr_t)_icon_item_ger_staticSegmentRomEnd - (uintptr_t)_icon_item_ger_staticSegmentRomStart);
    u32 size;
    u32 keepPeak;
    u32 alternate;
    /* Match the native pause menu's dungeon-icon selection. */
    s32 dungeon = (play->sceneId >= SCENE_DEKU_TREE && play->sceneId <= SCENE_ICE_CAVERN) ||
                  (play->sceneId >= SCENE_DEKU_TREE_BOSS && play->sceneId <= SCENE_SHADOW_TEMPLE_BOSS);
    alternate = dungeon ? ((uintptr_t)_icon_item_dungeon_staticSegmentRomEnd - (uintptr_t)_icon_item_dungeon_staticSegmentRomStart)
                        : ((uintptr_t)_icon_item_field_staticSegmentRomEnd - (uintptr_t)_icon_item_field_staticSegmentRomStart);
    language = MAX(language, (uintptr_t)_icon_item_fra_staticSegmentRomEnd - (uintptr_t)_icon_item_fra_staticSegmentRomStart);
    size = PAUSE_PLAYER_SEGMENT_TOTAL_SIZE(Scene_ObjectBytesV86(gLinkObjectIds[gSaveContext.save.linkAge]));
    size = ALIGN16(size) + ((uintptr_t)_icon_item_staticSegmentRomEnd - (uintptr_t)_icon_item_staticSegmentRomStart);
    size = ALIGN16(size) + ((uintptr_t)_icon_item_24_staticSegmentRomEnd - (uintptr_t)_icon_item_24_staticSegmentRomStart);
    size = ALIGN16(size) + alternate;
    size = ALIGN16(size) + language;
    size = ALIGN16(size) + MAX(MAP_NAME_TEX1_SIZE, ITEM_NAME_TEX_SIZE) + MAP_NAME_TEX2_SIZE;
    size = ALIGN16(size) + PAUSE_EQUIP_PLAYER_WIDTH * PAUSE_EQUIP_PLAYER_HEIGHT;
    /* InitPauseDrawData briefly DMA-loads the complete gameplay_keep. */
    keepPeak = PAUSE_PLAYER_SEGMENT_RENDER_TEXTURE_SIZE + Scene_ObjectBytesV86(OBJECT_GAMEPLAY_KEEP);
    return ALIGN16(MAX(size, keepPeak)) + 0x40 + 0x2000;
}
static u32 Scene_DungeonObjectSpaceV86(PlayState* play, u32 original) {
    const ObjectBudgetSceneV86* scene = NULL;
    u32 i, j, size, maximum = 0, keepMaximum = 0;
    if (gSaveContext.gameMode != GAMEMODE_NORMAL || gSaveContext.sceneLayer > 3) return original;
    for (i = 0; i < ARRAY_COUNT(sObjectBudgetScenesV86); i++) {
        if (sObjectBudgetScenesV86[i].sceneId == play->sceneId) { scene = &sObjectBudgetScenesV86[i]; break; }
    }
    /* Also protect the older adult Hyrule Field model-space reduction. */
    if (scene == NULL) return MAX(original, (Scene_PauseSpaceV87(play) + 0xFFF) & ~0xFFF);
    for (i = 0; i < scene->groupCount; i++) {
        size = 0;
        for (j = 0; j < scene->groups[i].count; j++) size += Scene_ObjectBytesV86(scene->groups[i].ids[j]);
        if (size > maximum) maximum = size;
    }
    for (i = 0; i < scene->keepCount; i++) {
        size = Scene_ObjectBytesV86(scene->keeps[i]);
        if (size > keepMaximum) keepMaximum = size;
    }
    maximum += Scene_ObjectBytesV86(OBJECT_GAMEPLAY_KEEP) + keepMaximum +
               Scene_ObjectBytesV86(gLinkObjectIds[gSaveContext.save.linkAge]);
    maximum = MAX(maximum + 0x8000, Scene_PauseSpaceV87(play));
    maximum = (maximum + 0xFFF) & ~0xFFF;
    return maximum < original ? maximum : original;
}
#endif''']
text='\n'.join(lines)+'\n';target=O/'include/object_room_budget_v86.h'
if not target.exists()or target.read_text()!=text:target.write_text(text)
print('Dungeon model reservations generated for',len(entries),'scenes')

from pathlib import Path
import json,sys
R=Path('/workspace/Projekt-Merzen-der-Bauer');W=Path('/workspace/gerudo-dialogue');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts');O=Path('/workspace/oot-burns-pal');sys.path.insert(0,str(R/'tools'));from build_story import messages,plain,split_pages
entries={k:v for p in (R/'story').glob('*.json')for k,v in json.loads(p.read_text())['messages'].items()};ids=json.loads((R/'tools/intro_gerudo_ids.json').read_text());m=messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
header=['# Neue Dialoge: Intro, Gerudos, Wüste und Hexen','', 'Aktueller eingebauter Stand. Alte Rechtschreibung; [Spielername] wird im Spiel durch den gewählten Namen ersetzt. Absätze entsprechen manuell weitergeschalteten Seiten, außer bei den ausdrücklich zeitgesteuerten Hexen- und Geisterzeilen. Die festen Originalzeiten bleiben erhalten.','']
for k in ids:
 header+=['## '+k,'']
 for page in entries[k]['pages']:header+=[page.replace('{name}','[Spielername]'),'']
 if entries[k].get('choices'):header+=['Antworten: '+' / '.join(entries[k]['choices']),'']
name='Dialoge_Intro_Gerudos_Hexen.md'
for target in [R/'planning'/name,D/name,A/name]:target.write_text('\n'.join(header)+'\n')
rows=[('0157','Auge der Wahrheit vorhanden, Schattenamulett noch nicht erhalten.'),('0158','Schattenamulett vorhanden, Requiem der Geister noch nicht gelernt.'),('0156','Requiem gelernt, Krafthandschuhe noch nicht erhalten. Unverändert.'),('015A','Krafthandschuhe vorhanden, Geisteramulett noch nicht erhalten.'),('015B','Geisteramulett vorhanden, Lichtpfeile noch nicht erhalten; frühere offene Bedingungen haben weiterhin Vorrang.'),('0124','Örtlicher Navi-Ruf in Geistertempelraum 5.'),('0191','Örtlicher Navi-Ruf in Geistertempelraum 2; dieser Text wird auch in anderen Dungeons benutzt.'),('005C','Zusatz nach den normalen Informationen beim Erhalt der Titanhandschuhe. Navi spricht ausdrücklich mit eigener Kennzeichnung und hellblauer Schrift. Kein neuer wiederholter Questhinweis.'),('0076','Sheiks beiläufige Warnung nach der Bestätigung, daß das Requiem der Geister erlernt wurde. Die eigentliche Lied-Lektion bleibt unverändert.')]
text=['# Navi und Sheiks Nachsatz: aktueller Stand','','Allgemeine Storyhinweise können bei Navis normalen Rufgelegenheiten wiederkehren, solange die jeweilige Questbedingung gilt. Frühere offene Bedingungen können spätere Hinweise überlagern. Keine zusätzlichen Rufstellen und keine veränderten Lesezeiten. Gegnerbeschreibungen sind hier ausgenommen.','']
for k,trigger in rows:
 text+=['## '+k,'',trigger,'']
 text+=[' '.join(plain(p).split()).replace('{name}','[Spielername]')+'\n'for p in split_pages(m[k]['parts'][2][2])[0]]
name='Navi_Schatten_bis_Geistertempel_Aktuell.md'
for target in [R/'planning'/name,D/name,A/name]:target.write_text('\n'.join(text)+'\n')
p=R/'story/LEITLINIEN.md';s=p.read_text();s+='''

## Hexen und Rückverweise im Wüstenkapitel

Koume/Kotake behalten alle nativen verzögerten Seitenwechsel und Ausblendzeiten. Für sehr kurze Streitzeilen werden die Ideen gekürzt, nicht die Lesezeit erhöht. 6058 beendet den Streit; 6059/605A sind die getrennte Fusion mit Dragon-Ball-Anspielung. Der genaue deutsche Hexi-Beiname aus 605A erscheint als echte Bossnamen-Textur beim nativen Zwinkern der Fusion. Keine Änderung an Kampf, Animation, Schaden, Rätseln oder Cutscene-Timern. 128×64 pro PAL-Sprache, zwei native TMEM-Ladevorgänge; 9.216 zusätzliche Objektbytes. Englisch/Französisch behalten ihre originalen Glyphen an derselben Bildschirmposition.

Navi 0158: Sonnencreme, Handtuch und begeistertes WÜÜÜÜÜÜSTE. 0156 bleibt unverändert. 015A stellt eine dritte Handschuhstufe in Aussicht; der ausdrücklich als Navi gekennzeichnete Rückverweis folgt dem normalen Titanhandschuh-Fundtext 005C. Originales Item-Icon und Bedienhinweis bleiben auf der ersten Seite. 015B: Gummibärchen in der Zitadelle. 0124: Mund-Running-Gag. Sheiks Warnung vor schnellen schwebenden Krügen folgt als beiläufiger Nachsatz auf der Requiem-Erlernt-Bestätigung 0076, somit nach der nativen Lektion, nicht vor dem Lied.

Letzte kumulative Builder: build_desert_guests.py, dann build_gerudo_dialogue.py und build_twinrova_title.py. Zusatzseiten gewöhnlicher Item-/Liedertexte sind manuell bestätigt. Kein neuer Navi-Polling-Hook, keine Quest- oder Inventarbits für diese Rückverweise.
''';p.write_text(s)
print('Exported current 85-message chapter plus Navi/Sheik trigger reference.')

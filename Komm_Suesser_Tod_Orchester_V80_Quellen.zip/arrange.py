from pathlib import Path
import sys,copy,collections,json,math,xml.etree.ElementTree as ET
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
# Read every written part, including the late orchestral development and final ritardando.
s=Path(__file__).with_name('read_midi.py').read_text()
ns={'__file__':__file__};exec(s,ns);O=ns['O'];tracks=ns['tracks'];tempos=ns['tempos'];source=ns['source'];m=ns['m']
fonts={i:ET.parse(O/f'extracted/pal-1.0/assets/audio/soundfonts/Soundfont_{i}.xml').getroot()for i in(3,5,9,13)}
font=ET.Element('Soundfont',Name='Soundfont_38',Index='38',Medium='MEDIUM_CART',CachePolicy='CACHE_LOAD_TEMPORARY',SampleBank='$(BUILD_DIR)/assets/audio/samplebanks/SampleBank_0.xml',Indirect='1')
envs=ET.SubElement(font,'Envelopes');samples=ET.SubElement(font,'Samples');insts=ET.SubElement(font,'Instruments');used=set()
def env(fi,name):
 key=f'F{fi}_{name}'
 if not any(e.get('Name')==key for e in envs):
  e=copy.deepcopy(fonts[fi].find(f'./Envelopes/Envelope[@Name="{name}"]'));e.set('Name',key);envs.append(e)
 return key
def add_samples(e):
 for k,v in e.attrib.items():
  if k.startswith('Sample')and v.startswith('SAMPLE_')and v not in used:ET.SubElement(samples,'Sample',Name=v);used.add(v)
programs=[(0,13,0,'MALON'),(1,5,0,'PIANO'),(2,3,10,'VIOLINS'),(3,13,2,'ACOUSTIC_GUITAR'),(4,3,11,'CELLOS'),(5,3,14,'CHOIR'),(6,9,6,'ORGAN'),(7,3,5,'FLUTE'),(8,3,3,'HORNS'),(9,3,0,'HARP'),(10,3,8,'OBOE'),(11,3,1,'TRUMPET'),(12,3,2,'TROMBONE'),(13,3,12,'PIZZICATO'),(14,3,7,'BASSOON'),(15,13,3,'GUITAR_HIGH')]
for index,fi,program,name in programs:
 e=copy.deepcopy(fonts[fi].find(f'./Instruments/Instrument[@ProgramNumber="{program}"]'));e.set('Name',name);e.set('ProgramNumber',str(index));e.set('Envelope',env(fi,e.get('Envelope')));insts.append(e);add_samples(e)
drums=copy.deepcopy(fonts[3].find('Drums'))
for e in drums:e.set('Envelope',env(3,e.get('Envelope')));add_samples(e)
font.insert(2,drums);ET.indent(font,space='    ');(W/'Soundfont_38.xml').write_text(ET.tostring(font,encoding='unicode')+'\n')

def notes(ti,boost=1.,offset=0):
 return [[a,z,p+offset,max(1,min(123,round(v*boost)))]for a,z,p,v in tracks[ti]]
def allocate(ns,count):
 voices=[[]for _ in range(count)];ends=[0]*count
 for a,group in __import__('itertools').groupby(sorted(ns),key=lambda n:n[0]):
  unique={}
  for n in group:
   if n[2]not in unique or (n[3],n[1])>(unique[n[2]][3],unique[n[2]][1]):unique[n[2]]=list(n)
  candidates=sorted(unique.values(),key=lambda n:(n[3],n[2]),reverse=True)[:count]
  for n in sorted(candidates,key=lambda n:n[2]):
   free=[i for i,e in enumerate(ends)if e<=a];i=min(free,key=lambda i:ends[i])if free else min(range(count),key=lambda i:ends[i])
   if ends[i]>a:
    if voices[i][-1][0]==a:continue
    voices[i][-1][1]=a
   voices[i].append(n);ends[i]=n[1]
 return voices
# Voicings use the MIDI's piano harmony. Slow changes keep bowed instruments legato.
pads=[[],[],[],[]]
for a in range(0,580*48,96):
 score=collections.Counter();roots=[]
 for ti in(4,5):
  for x,z,p,v in tracks[ti]:
   if x>=a+96:break
   if z<=a:continue
   score[p%12]+=max(1,min(z,a+96)-max(x,a))*(.7+v/127)*(1.6 if x==a else 1)
   if ti==5:roots.append(p)
 if not score:continue
 pcs=[p for p,_ in score.most_common(4)];root=min(roots)if roots else min(p for _,_,p,_ in tracks[5])
 root=max(36,min(59,root))
 while root%12 not in pcs:root+=1
 chord=sorted({60+((pc-0)%12)for pc in pcs})
 voicing=[chord[-1],chord[0],root,48+pcs[1 if len(pcs)>1 else 0]]
 for i,p in enumerate(voicing):pads[i].append([a,a+94,p,90])
def merge(v,gap=4):
 out=[]
 for a,z,p,vel in sorted(v):
  if out and out[-1][2]==p and a-out[-1][1]<=gap:out[-1][1]=z;out[-1][3]=max(out[-1][3],vel)
  else:out.append([a,z,p,vel])
 return out
pads=[merge(v)for v in pads]
channels=[]
def add(name,voices,programs,pan,volume,priority):
 assert len(voices)==len(programs)<=4,(name,len(voices))
 channels.append(dict(name=name,voices=voices,voice_programs=programs,pan=pan,volume=volume,priority=priority,reverb=24))
# Three distinct vocal lines, including written choir melody once the solo line ends.
v0=allocate(notes(0,1.08),1);v1=allocate(notes(1,1.03),1);v2=allocate(notes(2,.80),1)
add('Malon solo + harmony + choral doubling',v0+v1+v2,[0,0,0],64,110,15)
add('Grand piano, both hands',allocate(notes(4),3)+allocate(notes(5),1),[1]*4,44,102,11)
violins=allocate(notes(16),2)+allocate(notes(17),2)
violas=allocate(notes(18),2)+allocate(notes(19),2)
for vs in (violins,violas):
 for v in vs:
  for n in v:n[3]=min(120,round(62+n[3]*.58))
for i in range(2):violins[i]=[n for n in pads[i]if n[0]<274*48]+violins[i]
for i in range(2):violas[i]=[n for n in pads[i+2]if n[0]<274*48]+violas[i]
add('Violins I and II, full score + early harmonic pads',violins,[2]*4,25,118,12)
add('Violas and cellos, full score + early harmonic pads',violas,[4]*4,99,111,12)
add('Double basses + plucked bass',allocate(notes(20,1.4),1)+allocate(notes(10,1.15),1),[4,3],64,100,13)
brass=[]
for i in(0,1,2):
 voice=copy.deepcopy(pads[i])
 for n in voice:
  # The brass section grows with the song; preserve the written harmony.
  n[3]=53 if n[0]<65*48 else 75 if n[0]<182*48 else 108
  if i==0:n[2]-=12
 brass.append(voice)
add('Horns + trumpet + trombone harmony',brass,[8,11,12],78,108,11)
add('Flute, oboe and bassoon counterlines',allocate(notes(0,.95),1)+allocate(notes(2),1)+allocate(notes(5,.9,12),1),[7,10,14],34,83,10)
add('Female choir, three written voices',allocate(notes(2,1.17),3),[5]*3,79,105,11)
add('Male choir, two written voices',allocate(notes(3,1.22),2),[5]*2,49,108,11)
add('Pipe organ, full chords',allocate(notes(6,1.10),3),[6]*3,66,81,8)
add('Harp, doubled piano figures',allocate(notes(4,.92),2),[9]*2,100,76,8)
add('Acoustic guitars',allocate(notes(7,.85),2),[3]*2,95,69,7)
add('Guitar counterline from original electric guitar part',allocate(notes(9,1.05),1),[15],27,82,9)
# Native drum indices: kick C2=15, snare D2=17, hats F#2=21, crashes G3=34.
def percussion(ti,accent=False):
 out=[]
 for a,z,p,v in tracks[ti]:
  if accent and v<78:continue
  if p in(35,36):key=10 if accent else 15
  elif p in(37,38,40):key=16 if p==37 else 17
  elif p in(42,44,46):
   if accent:continue
   key=21 if p!=46 else 23
  elif p in(41,43,45,47,48,50):key={41:9,43:11,45:12,47:13,48:14,50:15}[p]
  else:key=34
  out.append([a,min(z,a+(15 if key==34 else 6)),key,min(120,round(v*1.02))])
 return out
add('Drum kit, clear snare and cymbals',allocate(percussion(11),3),[127]*3,64,86,10)
add('Low orchestral drum accents',allocate(percussion(12,True),2),[127]*2,53,70,9)
pizz=[[a,min(z,a+16),p,v]for a,z,p,v in notes(4,.87)if a%48 in(0,24)]
add('Pizzicato strings and upper octave string reinforcement',allocate(pizz,2)+allocate(notes(16,.75,12),1),[13,13,2],44,83,9)
assert len(channels)==16
# Keep 32 simultaneous written notes, with release headroom in the private 36-note listening spec.
rank=[100,78,95,93,94,92,79,90,89,60,56,51,69,74,65,70]
events=[];active=[];cut=0
for ci,c in enumerate(channels):
 for vi,v in enumerate(c['voices']):
  for n in v:events.append((n[0],rank[ci]+(1 if vi==0 else 0),n))
for a,score,n in sorted(events,key=lambda e:(e[0],-e[1])):
 active=[x for x in active if x[1][1]>a];active.append((score,n))
 if len(active)>32:
  loser=min(active,key=lambda x:(x[0],x[1][3],-x[1][0]));loser[1][1]=a;active.remove(loser);cut+=1
for c in channels:c['voices']=[[n for n in v if n[1]>n[0]]for v in c['voices']]
end=math.ceil(max(n[1]for c in channels for v in c['voices']for n in v)/48)*48+96
lines=['#include "aseq.h"','#include "Soundfont_38.h"','.startseq Sequence_98','.sequence MAIN','mutebhv 0x20','mutescale 50','initchan 65535','vol 68','tempo 76']
for i in range(16):lines.append(f'ldchan {i}, CH_{i}')
at=0
for tick,tempo in sorted(tempos.items()):
 if not tick or tick>=end:continue
 if tick>at:lines.append(f'delay {tick-at}')
 lines.append(f'tempo {tempo}');at=tick
lines +=[f'delay {end-at}','end']
for i,c in enumerate(channels):
 lines +=[f'.channel CH_{i}','noshort',f'vol {c["volume"]}',f'pan {c["pan"]}',f'notepri 0, {c["priority"]}',f'reverb {c["reverb"]}',f'instr {c["voice_programs"][0]}']
 for j,v in enumerate(c['voices']):
  if v:lines.append(f'ldlayer {j}, L_{i}_{j}')
 lines +=[f'delay {min(end+48,32767)}','end']
 for j,v in enumerate(c['voices']):
  if not v:continue
  prog=c['voice_programs'][j];shift=max(0,max(n[2]for n in v)-84)if prog!=127 else 0
  lines +=[f'.layer L_{i}_{j}',f'instr {prog}']
  if shift:lines.append(f'transpose {shift}')
  at=0
  for ni,(a,z,p,vel)in enumerate(v):
   if a>at:lines.append(f'ldelay {a-at}')
   pitch=p if prog==127 else p-21-shift;assert 0<=pitch<64,(i,j,pitch,p,shift)
   nxt=v[ni+1][0]if ni+1<len(v)else z;gate=round(256*(nxt-z)/(nxt-a))if nxt>a else 0
   if 0<gate<255 and nxt-z<480:lines.append(f'notedvg {pitch}, {nxt-a}, {vel}, {gate}');at=nxt
   else:lines.append(f'notedv {pitch}, {z-a}, {vel}');at=z
  lines.append('end')
from compress_motifs import compress
lines,motifs=compress(lines);lines.append('.endseq Sequence_98');(W/'seq_98.seq').write_text('\n'.join(lines)+'\n')
seconds=0;at=0;prev=76
for tick,tempo in sorted(tempos.items()):seconds+=(tick-at)/48*60/prev;at=tick;prev=tempo
seconds+=(end-at)/48*60/prev
report=dict(source='Komm,_süsser_Tod_-_Evangelion_(Complete).mid',source_tracks=source,full_score=True,source_end_beats=end/48,native_seconds=seconds,tempos=tempos,native_note_budget=32,preview_note_pool=36,overlap_cuts=cut,motifs=motifs,instruments=[dict(program=i,native_font=f,native_program=p,name=n)for i,f,p,n in programs],channels=[{k:v for k,v in c.items()if k!='voices'}|dict(layers=len(c['voices']),notes=sum(map(len,c['voices'])))for c in channels])
(W/'arrangement.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));(W/'notes.json').write_text(json.dumps(channels,separators=(',',':')));print('FULL ORCHESTRA',seconds,'seconds; cuts',cut,'motifs',motifs,flush=True)

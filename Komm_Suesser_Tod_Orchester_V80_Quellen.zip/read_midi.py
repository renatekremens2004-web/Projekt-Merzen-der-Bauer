from pathlib import Path
import mido,collections,math,json,copy,xml.etree.ElementTree as ET,hashlib,sys
W=Path(__file__).resolve().parent;O=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/workspace/oot-burns-pal')
midi_path=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/attachments/42ed36a9-054c-43a9-bb55-11c5f9238483/Komm,_süsser_Tod_-_Evangelion_(Complete).mid')
# Log malformed MIDI controller bytes before accepting mido's bounded 0..127 normalization.
import mido.midifiles.midifiles as mf
read=mf.read_message;repairs=[]
def bounded(f,status,peek,delta,clip=False):
 at=f.tell()
 try:return read(f,status,peek,delta,False)
 except (ValueError,OSError) as e:
  if 'data byte' not in str(e):raise
  repairs.append(dict(byte_offset=at,status=hex(status),error=str(e)));f.seek(at);return read(f,status,peek,delta,True)
mf.read_message=bounded
m=mido.MidiFile(midi_path,clip=True);mf.read_message=read
tracks=[];tempos={0:76};source=[]
for ti,t in enumerate(m.tracks):
 now=0;on=collections.defaultdict(list);notes=[];volume=expression=127;pedal=False;held=[]
 def close(a,z,n,v,vol,expr):
  a=round(a*48/m.ticks_per_beat);z=max(a+1,round(z*48/m.ticks_per_beat))
  # Keep the written dynamic contour; controller volume influences attacks rather than exploding the MML.
  velocity=round(v*(.60+.40*vol/127)*(.65+.35*expr/127));notes.append([a,z,n,max(1,min(126,velocity))])
 for x in t:
  now+=x.time
  if x.type=='set_tempo':tempos[round(now*48/m.ticks_per_beat)]=max(1,min(255,round(mido.tempo2bpm(x.tempo))))
  elif x.type=='control_change':
   if x.control==7:volume=x.value
   if x.control==11:expression=x.value
   if x.control==64:
    new=x.value>=64
    if pedal and not new:
     for n,(a,v,vol,expr)in held:close(a,now,n,v,vol,expr)
     held=[]
    pedal=new
  elif x.type=='note_on'and x.velocity:on[x.channel,x.note].append((now,x.velocity,volume,expression))
  elif x.type=='note_off'or(x.type=='note_on'and not x.velocity):
   if on[x.channel,x.note]:
    a,v,vol,expr=on[x.channel,x.note].pop(0)
    if pedal and ti in(4,5):held.append((x.note,(a,v,vol,expr)))
    else:close(a,now,x.note,v,vol,expr)
 for n,(a,v,vol,expr)in held:close(a,now,n,v,vol,expr)
 for (ch,n),left in on.items():
  for a,v,vol,expr in left:close(a,now,n,v,vol,expr)
 tracks.append(sorted(notes));source.append(dict(track=ti,name=t.name,notes=len(notes)))

"""Prepare a dormant weapon attachment for the existing standing Goron soldier.
No scene, actor, ROM, dialogue or save modification. Run from any directory.
"""
from pathlib import Path
import json,re,hashlib,math
import numpy as np
from PIL import Image
from n64_model import emit
R=Path(__file__).resolve().parents[1];D=R/'models/goron-hunting-rifle-reserve';p=D/'source/hunting_rifle.obj'
v=[];uv=[];norm=[];tris=[]
for line in p.read_text().splitlines():
 a=line.split()
 if not a:continue
 if a[0]=='v':v.append(list(map(float,a[1:4])))
 elif a[0]=='vt':uv.append(list(map(float,a[1:3])))
 elif a[0]=='vn':norm.append(list(map(float,a[1:4])))
 elif a[0]=='f':
  cs=[tuple(int(i)-1 for i in q.split('/'))for q in a[1:]]
  tris.extend([[cs[0],cs[i],cs[i+1]]for i in range(1,len(cs)-1)])
v=np.array(v);norm=np.array(norm);rig=json.loads((D/'goron-rig-reference.json').read_text());js=[list(map(int,row))for row in re.findall(r'\{(-?\d+),(-?\d+),(-?\d+)\}',(D/'soldier-pose.inc.c').read_text())];parents={int(k):v for k,v in rig['parents'].items()};limbs={int(k):v for k,v in rig['limbs'].items()}
def matrix(i):
 if i==0:return np.eye(4)
 m=np.eye(4);m[:3,3]=js[0]if i==1 else limbs[i]['position']
 x,y,z=np.array(js[i])*np.pi/32768;sx,cx=math.sin(x),math.cos(x);sy,cy=math.sin(y),math.cos(y);sz,cz=math.sin(z),math.cos(z)
 m[:3,:3]=[[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]]
 return matrix(parents[i])@m
# Source is lying sideways, with muzzle pointing -Z and stock down along +X.
up=np.array([.243,.970,0]);up/=np.linalg.norm(up);fwd=np.array([-up[1],up[0],0]);basis=np.stack([-up,[0,0,-1],-fwd],axis=1);assert abs(np.linalg.det(basis)-1)<1e-8
hand=matrix(13);grip=np.array([-.1,0,3.5]);palm=np.array([1200,3600,2450]);scale=5200/np.ptp(v[:,2]);pos=((v-grip)@basis.T*scale+palm-hand[:3,3])@hand[:3,:3];T=hand[:3,:3].T@basis
# Keep just the weapon's own 64x64 atlas region, with a one-pixel border.
crop=(127,63,193,129);im=Image.open(D/'source/TIM00.png').convert('RGBA').crop(crop);im.save(D/'hunting_rifle.png')
m=dict(bones=[],materials=[dict(name='hunting_rifle',texture='hunting_rifle.png',size=[64,64])],vertices=[dict(bone=0,position=[round(float(x))for x in q])for q in pos],triangles=[],animations={})
for f in tris:
 cs=[]
 for vi,ti,ni in f:
  n=T@norm[ni];n/=max(1e-8,np.linalg.norm(n));u,w=uv[ti];u=(u*256-crop[0])/66;w=1-((1-w)*256-crop[1])/66
  cs.append(dict(vertex=vi,uv=[u,w],normal=[round(float(x)*127)for x in n]))
 m['triangles'].append(dict(material=0,corners=cs))
(D/'hunting_rifle_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');(D/'hunting_rifle_model.inc.c').write_text(emit(m,D,'GoronHuntingRifleReserve'))
manifest=dict(variant='standing_goron_hunting_rifle_reserve',status='prepared_not_placed',triangles=len(tris),source_vertices=len(v),weapon_length_game_units=52,texture_size=[64,64],texture_format='CI4 / RGBA16 palette',texture_payload_bytes=2080,display_list='gGoronHuntingRifleReserveDL',attach_limb=13,soldier_scale=.01,body='existing gGoronSkel / object_oF1d_map',helmet='existing gGoronSoldierV39HelmetDL',pose='soldier-pose.inc.c',local_matrix_units=True,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),world_placements=[],new_dialogues=[],new_shooting_logic=False,production_ROM_unchanged=True)
(D/'variant.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(manifest,indent=2))

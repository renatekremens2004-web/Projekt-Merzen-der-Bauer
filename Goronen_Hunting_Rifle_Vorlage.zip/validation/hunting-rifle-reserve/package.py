from pathlib import Path
import json,hashlib,shutil,zipfile
from PIL import Image
W=Path(__file__).resolve().parent;R=Path('/workspace/Projekt-Merzen-der-Bauer');A=Path('/workspace/artifacts');D=Path('/workspace/bean-download-delivery');M=R/'models/goron-hunting-rifle-reserve';report=json.loads((W/'verification.json').read_text());assert all(report['production_restored_byte_identical'].values())
photo='Gorone_Hunting_Rifle_Vorschau.png';archive='Goronen_Hunting_Rifle_Vorlage.zip';checks='SHA256SUMS_Hunting_Rifle_Vorlage.txt'
Image.open(W/'joe-hunting-reserve-direct-clip-on-shot0.ppm').save(A/photo);shutil.copyfile(A/photo,D/photo)
V=R/'validation/hunting-rifle-reserve';V.mkdir(parents=True,exist_ok=True)
for n in['verification.json','runtime.log','build-preview.log','build-restore.log','baseline-hashes.json','verify.py','package.py']:shutil.copyfile(W/n,V/n)
files=[p for p in M.rglob('*')if p.is_file()]+[R/'tools/export_goron_hunting_rifle_reserve.py',R/'tools/n64_model.py']+[p for p in V.iterdir()if p.is_file()]
with zipfile.ZipFile(A/archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(files):z.write(p,str(p.relative_to(R)))
 z.write(M/'README.md','README.md');z.write(A/photo,photo)
with zipfile.ZipFile(A/archive)as z:
 assert z.testzip()is None;assert not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.elf','.o','.so'}for n in z.namelist())
shutil.copyfile(A/archive,D/archive);(A/checks).write_text(''.join(hashlib.sha256((A/n).read_bytes()).hexdigest()+'  '+n+'\n'for n in[archive,photo]));shutil.copyfile(A/checks,D/checks)
head='## Vorbereitet: Hunting-Rifle-Soldat für später\n\n[Vorlagen-Paket]('+archive+'?raw=true) · [Vorschau im Spiel]('+photo+'?raw=true)\n\nEine zusätzliche Soldaten-Goronen-Variante mit der Silent-Hill-Hunting-Rifle ist fertig angepaßt und mit 4 MiB im Emulator geprüft. 128 Dreiecke, an die bestehende Handhaltung gebunden. Noch keine neue Platzierung oder Dialoge. Die untenstehenden V56-Patches bleiben unverändert.\n\n'
p=D/'README.md';s=p.read_text();p.write_text(s if s.startswith(head)else head+s)
(W/'package-manifest.json').write_text(json.dumps(dict(files=[archive,photo,checks],source_files=[str(p.relative_to(R))for p in files]),indent=2)+'\n');print('Packaged',archive,(A/archive).stat().st_size,'bytes')

# Soldaten-Gorone mit Hunting Rifle – vorbereitete Variante

Diese Variante ist für eine spätere Platzierung vorbereitet. Es gibt keine zusätzlichen Figuren, Dialoge oder Platzierungen in der aktuellen ROM. Die normalen V56-Patches bleiben unverändert.

Der vorhandene stehende Soldaten-Gorone erhält die Silent-Hill-Hunting-Rifle als starres Zubehör an seiner rechten Hand (Limb 13). Die linke Hand stützt den Laufbereich. Körper, Helm, Größe, Blinzeln, Atmen und Kopfdrehung stammen von der bestehenden Soldaten-Variante. Er bleibt dauerhaft aufrecht. Die Waffe hat keine Schuß- oder Schadenslogik.

## Fertige Daten

- `hunting_rifle_model.inc.c`: fertige native N64-Display-List `gGoronHuntingRifleReserveDL`.
- `hunting_rifle_source.json`: konvertierte Geometrie mit Positionen im lokalen Raum von Hand 13.
- `hunting_rifle.png`, `n64_hunting_rifle.png`: zugeschnittene Textur und N64-Farbpalette.
- `soldier-pose.inc.c`, `goron-rig-reference.json`: passende Haltung und Referenz des vorhandenen Goronen-Skeletts.
- `variant.json`: Größen, Bindung und Status der Vorlage.
- `source/`: hochgeladene OBJ-, MTL- und PNG-Quelldateien.

128 Dreiecke, 64 ursprüngliche Modellpunkte, Waffenlänge 52 Spiel-Einheiten bei der üblichen Goronen-Skalierung 0,01. Aus dem Texturatlas wird nur der Waffenbereich verwendet: 64×64 Pixel, CI4 mit RGBA16-Palette, 2.080 Bytes Textur und Palette. Im Test mit allen bisherigen Waffen im gemeinsamen Objekt betrug der zusätzliche Bankbedarf 9.024 Bytes.

## Spätere Integration

Den Ordner unter `models/goron-hunting-rifle-reserve` und das Exportwerkzeug unter `tools/export_goron_hunting_rifle_reserve.py` im bestehenden Merzen-Quellenprojekt ablegen. Das vorhandene `tools/n64_model.py` wird mitbenutzt. Neu exportieren mit:

```
python3 tools/export_goron_hunting_rifle_reserve.py
```

Benötigt Python mit numpy und Pillow. Der Export ändert ausschließlich diese vorbereiteten Modell-Dateien.

Bei der späteren Integration die Display-List dem gemeinsamen `object_goron_soldiers_v39` hinzufügen und nur für die gewünschte neue Soldaten-Variante anstelle der bisherigen Waffen-Display-List auswählen. Nach dem Zeichnen des bestehenden Goronen die erfaßte Handmatrix für Limb 13 sowie Segment 6 des Ausrüstungsobjekts verwenden. Körper, Helm und bestehende Arme-/Handhaltung beibehalten. Eine freie Variantenkennung erst bei der tatsächlichen Integration vergeben; hier ist noch keine Actor-Parameternummer reserviert. Im Zustand dieser Vorlage wird die Geometrie nicht in die Spiel-ROM geladen.

## Prüfung

Eine interne Test-ROM rüstete einen vorhandenen Goronen vorübergehend mit der Hunting Rifle aus. Stand, Griff, Atmen, Blinzeln, Kopfdrehung und zwei normale Gespräche liefen in einer nativen 4-MiB-Konfiguration durch. Dabei waren noch 88.240 Bytes in der Objektbank frei. Die PNG-Vorschau zeigt diesen internen Test mit einer Testkamera; sie stellt keine neue Position für die spätere Verwendung fest.

Anschließend wurden die Produktionsquellen und die reguläre V56-ROM wieder bytegenau hergestellt (SHA256 `31cf851bb6e57200a9088130a76bb58c3cc56158851feed436d773de01838e9a`). Der Asset-Export wurde wiederholt und erzeugte identische Dateien. Testprotokoll und Prüfung liegen im Vorlagen-Paket. Die Test-ROM wird nicht verteilt.

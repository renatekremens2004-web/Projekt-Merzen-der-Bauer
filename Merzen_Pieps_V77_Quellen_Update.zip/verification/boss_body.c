static void capture_render(void){}
static unsigned seenBird=0,seenInhale=0,swallowed=0,seenDeath=0,seenTheme=0,bombBirth=0,done=0;
static unsigned lastAction=0;
static unsigned bossfunc(unsigned v){return r32(overlays+0x27*0x20+0x10)+v-BOSS_VRAM;}
static void onframe(unsigned f){
 unsigned value=0,boss=0,bird=0,action=0,bomb=0;int plain=strstr(scenario,"plain")!=NULL,cleared=strstr(scenario,"cleared")!=NULL;
 baseframe(f);if(f<340)return;findplay();if(!play||!player)return;
 boss=r32(play+0x1c34+9*8);if(boss<0x80000000||boss>=0x80400000)boss=0;
 if(cleared){need(!boss,"already-cleared boss not respawned");if(f>700){bank();need(actor(0x5f)&&actor(0x5d),"native heart and warp after cleared entry");puts("PIEPS_QA_PASSED cleared boss entry");CoreDoCommand(M64CMD_STOP,0,NULL);}return;}
 if(!boss){if(f%200==0){printf("NO_BOSS f=%u scene=%x room=%d player=%.0f,%.0f,%.0f lists=%x/%x\n",f,DebugMemRead16(play+0xa4),(int)(signed char)DebugMemRead8(play+0x11cbc),rf(player+0x24),rf(player+0x28),rf(player+0x2c),r32(play+0x1c34+9*8),r32(play+0x1d3c));bank();CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}if(f>900){puts("ASSERT_FAILED missing boss");exit(96);}return;}
 action=r32(boss+0x180);bird=target(0x72,0x7502);bomb=actor(0x10);
 if(action!=lastAction){printf("BOSS f=%u action=%x state=%d timer=%d xyz=%.0f,%.0f,%.0f mouth=%.0f,%.0f,%.0f\n",f,action,DebugMemRead16(boss+0x18c),DebugMemRead16(boss+0x1ca),rf(boss+0x24),rf(boss+0x28),rf(boss+0x2c),rf(boss+0x40c),rf(boss+0x410),rf(boss+0x414));lastAction=action;}
 if(bird){if(!seenBird){bank();CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}seenBird=1;}
 if((DebugMemRead8(AUDIO_CONTEXT+0x3534)==111)&&(DebugMemRead8(AUDIO_CONTEXT+0x3530)&0x80))seenTheme=1;
 if(action==bossfunc(INHALE))seenInhale=1;
 if(action==bossfunc(EXPLODE)&&seenInhale)swallowed=1;
 if(action==bossfunc(DEATH))seenDeath=1;
 if(!seenBird&&!seenDeath){
  if(f>600&&DebugMemRead16(boss+0x1a4)==0){
   float x=rf(boss+0x24),z=rf(boss+0x2c);double yaw=DebugMemRead16(boss+0xb6)*6.283185307179586/65536.;position(player,x+sin(yaw)*210,-1523.76f,z+cos(yaw)*210,(int)(DebugMemRead16(boss+0xb6)+32768));
   if(!bomb&&f%70<2)value=0x200;
   if(bomb){if(!bombBirth)bombBirth=f;if(r32(bomb+0x118)){if(f>bombBirth+15&&f%10<2)value=0x80;}else if(action==bossfunc(INHALE)){position(bomb,rf(boss+0x40c),rf(boss+0x410),rf(boss+0x414),0);wf(bomb+0x60,0);wf(bomb+0x6c,0);}}
   else bombBirth=0;
  }
 }
 if(plain&&swallowed&&f%30==0){need(!seenBird&&!seenDeath&&!seenTheme,"without rescue boss remains vanilla");bank();puts("PIEPS_QA_PASSED native bomb swallow without rescue");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(!plain&&seenDeath&&DebugMemRead16(boss+0x18c)==100){
  if(!done){bank();need(seenBird&&swallowed&&seenTheme&&!bird,"assisted bomb swallow and native death without lingering bird");need(actor(0x5f)&&actor(0x5d),"native heart container and exit warp");need(r32(play+0x1d3c)&2,"native room clear flag");CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);done=f;}
  if(f>done+100){need((DebugMemRead8(AUDIO_CONTEXT+0x3534)==111),"theme persists after boss clear");need(!(r32(player+0x66c)&0x20000000),"player control restored");puts("PIEPS_QA_PASSED assisted boss; native heart, warp, clear, control, music");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(f%200==0){printf("TRACE f=%u boss=%x act=%x bird=%x bomb=%x par=%x inhale=%u swallow=%u death=%u theme=%u playerflags=%x\n",f,boss,action,bird,bomb,bomb?r32(bomb+0x118):0,seenInhale,swallowed,seenDeath,seenTheme,r32(player+0x66c));CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 if(buttons)buttons(value);if(f>4600){puts("PIEPS_QA_TIMEOUT boss");exit(96);}
}

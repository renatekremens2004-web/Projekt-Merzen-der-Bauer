static unsigned pending=0,encoded=0;
static uint64_t firstAudio=0,lastAudio=0;
static unsigned char previous[640*480*3];
static void hold_frame_until(uint64_t now){
 if(!video||now<firstAudio)return;
 unsigned target=(unsigned)(((now-firstAudio)*50+audioRate()/2)/audioRate());
 while(encoded<target){for(int y=479;y>=0;y--)if(fwrite(previous+y*640*3,1,640*3,video)!=640*3)exit(94);encoded++;}lastAudio=now;
}
static void capture_render(void){
 static unsigned char pixels[640*480*3];if(!pending)return;
 if(CoreDoCommand(M64CMD_READ_SCREEN,0,pixels))exit(94);uint64_t now=audioSamples();
 if(!video){char cmd[1500];snprintf(cmd,sizeof(cmd),"ffmpeg -y -v error -f rawvideo -pixel_format rgb24 -video_size 640x480 -framerate 50 -i - -an -c:v libx264 -threads 2 -preset veryfast -crf 20 -pix_fmt yuv420p -movflags +faststart -f mp4 %s",getenv("PIEPS_VIDEO_PATH"));video=popen(cmd,"w");if(!video)exit(94);firstAudio=now;}
 else hold_frame_until(now);
 memcpy(previous,pixels,sizeof(previous));pending=0;
}

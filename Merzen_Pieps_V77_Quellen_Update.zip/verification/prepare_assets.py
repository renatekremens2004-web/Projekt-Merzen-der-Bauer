from pathlib import Path
import os,subprocess,re,math,json
from PIL import Image
W=Path(__file__).resolve().parent;R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal')
fd=os.memfd_create('native-bird');subprocess.run(['mips-linux-gnu-objcopy','-O','binary','-j','..object_bird',str(O/'build/pal-1.0/oot-pal-1.0.elf'),'/proc/self/fd/'+str(fd)],pass_fds=(fd,),check=True);os.lseek(fd,0,0);data=os.read(fd,100000);os.close(fd)
(R/'tools/pieps_bird_model_v75.inc.c').write_text('/* Native unused bird, private overlay data; segment 6 retained. */\nu64 gPiepsNativeModelV75[]={\n'+''.join('0x'+data[i:i+8].hex()+',\n'for i in range(0,len(data),8))+'};\n')
vs=[];uv=[];norm=[];tri=[]
for line in (W/'cage/Cage.obj').read_text().splitlines():
 a=line.split()
 if not a:continue
 if a[0]=='v':vs.append(tuple(float(x)*1600 for x in a[1:4]))
 elif a[0]=='vt':uv.append(tuple(map(float,a[1:3])))
 elif a[0]=='vn':norm.append(tuple(map(float,a[1:4])))
 elif a[0]=='f':
  face=[tuple(int(i)-1 for i in x.split('/'))for x in a[1:]]
  for k in range(1,len(face)-1):tri.append([face[0],face[k],face[k+1]])
verts=[];batches=[];local={};indices=[];start=0
for t in tri:
 if len(set(t)-local.keys())+len(local)>30:
  batches.append((start,len(local),indices));start=len(verts);local={};indices=[]
 it=[]
 for key in t:
  if key not in local:local[key]=len(local);verts.append(key)
  it.append(local[key])
 indices.append(it)
batches.append((start,len(local),indices))
s='static Vtx sPiepsCageVerticesV75[]={\n'
for v,t,n in verts:
 x,y,z=map(round,vs[v]);u,vv=uv[t];nx,ny,nz=(max(-127,min(127,round(x*127)))for x in norm[n]);s+=f'VTX({x},{y},{z},{round(u*32*32)},{round((1-vv)*32*32)},{nx&255},{ny&255},{nz&255},255),\n'
s+='};\nstatic u64 sPiepsCageTextureV75[]={\n';im=Image.open(W/'cage/Cage.png').convert('RGB').resize((32,32),Image.Resampling.LANCZOS);packed=b''.join((((r>>3)<<11)|((g>>3)<<6)|((b>>3)<<1)|1).to_bytes(2,'big')for r,g,b in im.getdata());s+=''.join('0x'+packed[i:i+8].hex()+',\n'for i in range(0,len(packed),8));s+='};\nstatic Gfx sPiepsCageDLV75[]={\ngDPPipeSync(),\n'
s=s.replace('gDPPipeSync()','gsDPPipeSync()');s+='gsSPClearGeometryMode(G_CULL_BACK),\ngsSPSetGeometryMode(G_LIGHTING),\ngsDPSetCombineLERP(TEXEL0,0,SHADE,0,0,0,0,TEXEL0,TEXEL0,0,SHADE,0,0,0,0,TEXEL0),\ngsSPTexture(0xFFFF,0xFFFF,0,G_TX_RENDERTILE,G_ON),\ngsDPLoadTextureBlock(sPiepsCageTextureV75,G_IM_FMT_RGBA,G_IM_SIZ_16b,32,32,0,G_TX_WRAP,G_TX_WRAP,5,5,G_TX_NOLOD,G_TX_NOLOD),\n'
for start,n,ts in batches:
 s+=f'gsSPVertex(sPiepsCageVerticesV75+{start},{n},0),\n'
 for a,b,c in ts:s+=f'gsSP1Triangle({a},{b},{c},0),\n'
s+='gsSPSetGeometryMode(G_CULL_BACK),\ngsSPEndDisplayList(),\n};\n';(R/'tools/pieps_cage_model_v75.inc.c').write_text(s)
print('Native bird bytes',len(data),'cage triangles',len(tri),'batched vertices',len(verts))
# Native floor queries for placing the cage away from required paths.
F=O/'extracted/pal-1.0/assets/scenes/dungeons/ddan';v=next(F.glob('*VtxList.inc.c')).read_text();vertices=[tuple(map(int,x))for x in re.findall(r'\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\}',v)];polys=re.findall(r'COLPOLY_VTX\((\d+),[^)]*\).*?COLPOLY_VTX\((\d+),[^)]*\).*?COLPOLY_VTX\((\d+),[^)]*\)',next(F.glob('*PolyList.inc.c')).read_text(),re.S)
for x,z in [(2960,-2340),(3000,-2160),(2820,-2080),(3970,-2300),(4080,-2160)]:
 heights=[]
 for ia,ib,ic in polys:
  a,b,c=(vertices[int(i)]for i in(ia,ib,ic));det=(b[2]-c[2])*(a[0]-c[0])+(c[0]-b[0])*(a[2]-c[2])
  if not det:continue
  u=((b[2]-c[2])*(x-c[0])+(c[0]-b[0])*(z-c[2]))/det;vv=((c[2]-a[2])*(x-c[0])+(a[0]-c[0])*(z-c[2]))/det
  if min(u,vv,1-u-vv)>=-1e-6:heights.append(round(u*a[1]+vv*b[1]+(1-u-vv)*c[1],2))
 print('Floor probe',x,z,sorted(set(heights)))

from pathlib import Path
import mido,collections,copy,xml.etree.ElementTree as ET,json,math
W=Path(__file__).resolve().parent;R=Path('/workspace/Projekt-Merzen-der-Bauer');D=R/'audio/pieps-v75';D.mkdir(parents=True,exist_ok=True)
m=mido.MidiFile('/workspace/attachments/614cf279-7428-4778-b330-afd3e889b386/bird-s-paradise.mid');tracks=[]
for t in m.tracks:
 now=0;on=collections.defaultdict(list);ns=[]
 for x in t:
  now+=x.time
  if x.type=='note_on'and x.velocity:on[x.channel,x.note].append((now,x.velocity))
  if x.type=='note_off'or(x.type=='note_on'and not x.velocity):
   if on[x.channel,x.note]:
    a,v=on[x.channel,x.note].pop(0);a=round(a*48/m.ticks_per_beat);z=round(now*48/m.ticks_per_beat)
    if z>a:ns.append([a,z,x.note,v])
 tracks.append(sorted(ns))
font=ET.parse('/workspace/malon-preview-v75/Soundfont_38.xml').getroot();font.set('Name','Soundfont_39');font.set('Index','39');inst=font.find('Instruments')
for e in list(inst):
 if int(e.get('ProgramNumber'))not in{1,2,3,4,5}:inst.remove(e)
drums=font.find('Drums');font.remove(drums)
used={v for e in inst for k,v in e.attrib.items()if k.startswith('Sample') and v.startswith('SAMPLE_')}
for e in list(font.find('Samples')):
 if e.get('Name')not in used:font.find('Samples').remove(e)
used={e.get('Envelope')for e in inst}
for e in list(font.find('Envelopes')):
 if e.get('Name')not in used:font.find('Envelopes').remove(e)
ET.indent(font,space='    ');(D/'Soundfont_39.xml').write_text(ET.tostring(font,encoding='unicode')+'\n')
roles=[('Bass',1,3,1,64,88),('Plucked lead',3,3,1,40,99),('Lead echo',5,3,1,88,42),('Viola melody',4,2,1,79,92),('Viola echo',6,2,1,34,40),('Choir',7,5,2,64,65),('Upper strings',8,2,1,32,50),('Piano',9,1,3,48,88),('Piano echo',10,1,3,89,37)]
channels=[]
for name,ti,program,count,pan,volume in roles:
 voices=[[]for _ in range(count)];ends=[0]*count
 for a,z,p,v in tracks[ti]:
  if name=='Upper strings':p-=12
  free=[i for i,e in enumerate(ends)if e<=a];i=min(free,key=lambda i:ends[i])if free else min(range(count),key=lambda i:ends[i])
  if ends[i]>a:
   if voices[i][-1][0]==a:continue
   voices[i][-1][1]=a
  voices[i].append([a,z,p,min(120,v)]);ends[i]=z
 channels.append(dict(name=name,program=program,pan=pan,volume=volume,voices=voices))
end=max(n[1]for c in channels for v in c['voices']for n in v);end=math.ceil(end/48)*48
l=['#include "aseq.h"','#include "Soundfont_39.h"','.startseq Sequence_111','.sequence MAIN','mutebhv 0x20','mutescale 50','initchan 511','tempo 130','vol 75']
for i in range(len(channels)):l.append(f'ldchan {i}, CH_{i}')
l+=['MAIN_HOLD:',f'delay {end}','jump MAIN_HOLD']
for i,c in enumerate(channels):
 l +=[f'.channel CH_{i}','noshort',f'vol {c["volume"]}',f'pan {c["pan"]}','notepri 0, 8','reverb 23',f'instr {c["program"]}']
 for j in range(len(c['voices'])):l.append(f'ldlayer {j}, L_{i}_{j}')
 l +=[f'CH_HOLD_{i}:','delay 32000',f'jump CH_HOLD_{i}']
 for j,v in enumerate(c['voices']):
  shift=max(0,max(n[2]for n in v)-84);l +=[f'.layer L_{i}_{j}']
  if shift:l.append(f'transpose {shift}')
  l +=[f'LOOP_{i}_{j}:'];at=0
  for k,(a,z,p,vel)in enumerate(v):
   if z<=a:continue
   if a>at:l.append(f'ldelay {a-at}')
   pitch=p-21-shift;assert 0<=pitch<64
   nxt=v[k+1][0]if k+1<len(v)else z;gate=round(256*(nxt-z)/(nxt-a))if nxt>a else 0
   if 0<gate<255:l.append(f'notedvg {pitch}, {nxt-a}, {vel}, {gate}');at=nxt
   else:l.append(f'notedv {pitch}, {z-a}, {vel}');at=z
  if at<end:l.append(f'ldelay {end-at}')
  l.append(f'jump LOOP_{i}_{j}')
l.append('.endseq Sequence_111');(D/'seq_111.seq').write_text('\n'.join(l)+'\n');(D/'notes.json').write_text(json.dumps(channels,separators=(',',':')));print('Pieps theme loop:',end,'ticks,',end/48*60/130,'seconds')

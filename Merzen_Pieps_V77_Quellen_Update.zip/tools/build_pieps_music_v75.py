"""Add the private looping bird theme; existing music IDs and banks remain stable."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];O=Path(sys.argv[1]);B=R/'tools/originals/pieps-music-v75';D=R/'audio/pieps-v75'
def original(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((O/rel).read_bytes())
 return p.read_text()
for rel,n in [('assets/audio/sequences/seq_111.seq','seq_111.seq'),('assets/audio/soundfonts/Soundfont_39.xml','Soundfont_39.xml')]:
 p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((D/n).read_bytes())
rel='spec/spec';s=original(rel)
for folder,old,new in [('sequences','seq_110','seq_111'),('soundfonts','Soundfont_38','Soundfont_39')]:
 needle=f'    include "$(BUILD_DIR)/assets/audio/{folder}/{old}.o"';assert s.count(needle)==1;s=s.replace(needle,needle+f'\n    include "$(BUILD_DIR)/assets/audio/{folder}/{new}.o"')
(O/rel).write_text(s);rel='include/tables/sequence_table.h';s=original(rel);assert'NA_BGM_PIEPS'not in s;(O/rel).write_text(s+'\nDEFINE_SEQUENCE(Sequence_111, NA_BGM_PIEPS, MEDIUM_CART, CACHE_LOAD_TEMPORARY, 0)\n')
print('Bird theme111/font39 installed. Existing escape98 and Wallace110 retained.')

"""Private bird rescue and assistance, applied after V72 and remove_jimmy_v75."""
from pathlib import Path
import re,sys
from build_story import messages,Layout,rewrite
R=Path(__file__).resolve().parents[1];O=Path(sys.argv[1]);B=R/'tools/originals/pieps-v75'
def original(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((O/rel).read_bytes())
 return p.read_text()
def write(rel,s):
 p=O/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists()or p.read_text()!=s:p.write_text(s)
folder='src/overlays/actors/ovl_En_Bird/'
for n in ['pieps_actor_v75.inc.c','pieps_bird_model_v75.inc.c','pieps_cage_model_v75.inc.c']:write(folder+n,(R/'tools'/n).read_text())
rel=folder+'z_en_bird.c';original(rel)
write(rel,'''#include "z_en_bird.h"
#include "ichain.h"
#include "z_lib.h"
#include "play_state.h"
#include "assets/objects/object_bird/object_bird.h"
#include "pieps_actor_v75.inc.c"
void EnBird_Init(Actor* a,PlayState* p){Pieps_InitV75((EnBird*)a,p);}
void EnBird_Destroy(Actor* a,PlayState* p){Pieps_DestroyV75((EnBird*)a,p);}
void EnBird_Update(Actor* a,PlayState* p){Pieps_UpdateV75((EnBird*)a,p);}
void EnBird_Draw(Actor* a,PlayState* p){Pieps_DrawV75((EnBird*)a,p);}
ActorProfile En_Bird_Profile={ACTOR_EN_BIRD,ACTORCAT_PROP,ACTOR_FLAG_UPDATE_CULLING_DISABLED|ACTOR_FLAG_DRAW_CULLING_DISABLED,OBJECT_GAMEPLAY_KEEP,sizeof(EnBird),EnBird_Init,EnBird_Destroy,EnBird_Update,EnBird_Draw};
''')
folder='src/overlays/actors/ovl_Boss_Dodongo/';write(folder+'pieps_boss_v75.inc.c',(R/'tools/pieps_boss_v75.inc.c').read_text());rel=folder+'z_boss_dodongo.c';s=original(rel)
needle='void BossDodongo_Init(Actor* thisx, PlayState* play) {';assert needle in s;s=s.replace(needle,'#include "pieps_boss_v75.inc.c"\n\n'+needle)
needle='    play->specialEffects = this->effects;';assert s.count(needle)==1;s=s.replace(needle,'    sPiepsFlightBirdV75=NULL;sPiepsFlightCamV75=CAM_ID_NONE;sPiepsAssistedV75=false;\n'+needle)
needle='    Math_SmoothStepToF(&this->unk_208, 0.05f, 1.0f, 0.005f, 0.0f);';i=s.index('void BossDodongo_Explode(BossDodongo* this, PlayState* play) {');a=s.index(needle,i);s=s[:a]+'    if(Pieps_BeginBossFlightV75(this,play))return;\n'+s[a:]
# Only assisted death retains the theme; normal boss and clear cues remain untouched.
i=s.index('void BossDodongo_SetupDeathCutscene(BossDodongo* this) {');j=s.index('void BossDodongo_DeathCutscene(BossDodongo* this, PlayState* play) {',i)
s=s[:i]+s[i:j].replace('    SEQCMD_STOP_SEQUENCE(SEQ_PLAYER_BGM_MAIN, 1);','    if(!sPiepsAssistedV75)SEQCMD_STOP_SEQUENCE(SEQ_PLAYER_BGM_MAIN, 1);')+s[j:]
s=s.replace('                SEQCMD_PLAY_SEQUENCE(SEQ_PLAYER_BGM_MAIN, 0, 0, NA_BGM_BOSS_CLEAR);','                if(!sPiepsAssistedV75)SEQCMD_PLAY_SEQUENCE(SEQ_PLAYER_BGM_MAIN, 0, 0, NA_BGM_BOSS_CLEAR);');write(rel,s)
# The lower Lizalfos platform has a native floor at y100 and clear switch5.
folder='extracted/pal-1.0/assets/scenes/dungeons/ddan/';p=O/folder/'ddan_room_3_03000048_ActorEntryList.inc.c';s=original(str(p.relative_to(O)));n=s.count('ACTOR_');write(str(p.relative_to(O)),s+'    {ACTOR_EN_BIRD,{2960,100,-2340},{0,0,0},0x7501}, /* Pieps, first Lizalfos encounter */\n');rel=folder+'ddan_room_3.h';s=original(rel);s,k=re.subn(r'(#define LENGTH_ddan_room_3_03000048_ActorEntryList )'+str(n)+r'\b',lambda m:m[1]+str(n+1),s);assert k==1;write(rel,s)
# Exactly two new German messages, existing choices/links are preserved.
rel='extracted/pal-1.0/text/message_data.h';s=original(rel);L=Layout(O)
for id,text in [('7239','Hilfe!!'),('723A','Puuh, das war ja ganz schön knapp. Ich bin Pieps der Vogel. Diese Echsenmenschen haben mich gefangen genommen um mich zu kochen. Du kamst wirklich gerade rechtzeitig. Ich werde mich erkenntlich zeigen!')]:
 assert id not in messages(s);lines=L.wrap(text,210);body,_=rewrite('COLOR(DEFAULT) ""',dict(pages=['\n'.join(lines[i:i+4])for i in range(0,len(lines),4)]),L,id);block=f'DEFINE_MESSAGE(0x{id}, TEXTBOX_TYPE_BLACK, TEXTBOX_POS_VARIABLE,\nMSG(/* MISSING */),\nMSG("Help!"),\nMSG('+body+'),\nMSG("Salut!")\n)\n';at=re.search(r'DEFINE_MESSAGE\(0x(?:FFFC|FFFD)',s);at=at.start()if at else len(s);s=s[:at]+block+s[at:]
write(rel,s);print('Pieps native private actor, rescue texts and boss handoff installed. Theme111 must be installed separately.')

"""Remove Jimmy placements and room object requirements without renumbering shared IDs."""
from pathlib import Path
import re,sys
R=Path(__file__).resolve().parents[1];O=Path(sys.argv[1]);B=R/'tools/originals/remove-jimmy-v75'
def original(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((O/rel).read_bytes())
 return p.read_text()
folder='extracted/pal-1.0/assets/scenes/overworld/spot20/';header=original(folder+'spot20_room_0.h');removed=[]
for p in (O/folder).glob('*.inc.c'):
 if 'ActorEntryList'not in p.name and'ObjectList'not in p.name:continue
 cached=B/p.relative_to(O);check=cached.read_text()if cached.exists()else p.read_text()
 if not any(x in check for x in ['0x3F8E','OBJECT_JIMMY']):continue
 rel=str(p.relative_to(O));s=original(rel);lines=s.splitlines(True);new=''.join(x for x in lines if not ('0x3F8E'in x or'OBJECT_JIMMY'in x));count=len(lines)-len(new.splitlines());assert count==1
 p.write_text(new);macro='LENGTH_'+p.name.removesuffix('.inc.c');header,n=re.subn(r'(#define '+macro+r' )(\d+)',lambda m:m[1]+str(int(m[2])-count),header);assert n==1;removed.append(rel)
(O/folder/'spot20_room_0.h').write_text(header)
rel='src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(rel);s,n=re.subn(r'^.*play->sceneId == SCENE_LON_LON_RANCH.*actor->params == 0x3F8E.*\n','',s,flags=re.M);assert n==1;(O/rel).write_text(s)
print('Jimmy removed:',len(removed),'room actor/object lists, and shared guest activation condition. Existing IDs retained.')

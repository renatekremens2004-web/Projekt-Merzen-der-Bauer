/* Only this boss overlay owns the rescue choreography. No shared NPC state. */
static Actor* sPiepsFlightBirdV75;
static Vec3f sPiepsFlightStartV75;
static s16 sPiepsFlightCamV75=CAM_ID_NONE;
static s16 sPiepsFlightFrameV75;
static u8 sPiepsAssistedV75;
static void Pieps_BossFlightV75(BossDodongo* this,PlayState* play){
 Vec3f target,eye,at;Camera* mainCam;f32 t,s;
 this->actor.speed=0;this->unk_1E4=0;
 sPiepsFlightFrameV75++;
 t=CLAMP((sPiepsFlightFrameV75-8)/62.0f,0.0f,1.0f);s=t*t*(3-2*t);target=this->mouthPos;
 if(sPiepsFlightBirdV75!=NULL&&sPiepsFlightBirdV75->update!=NULL){
  Actor* bird=sPiepsFlightBirdV75;
  bird->world.pos.x=sPiepsFlightStartV75.x+(target.x-sPiepsFlightStartV75.x)*s+sinf(t*M_PI)*120;
  bird->world.pos.z=sPiepsFlightStartV75.z+(target.z-sPiepsFlightStartV75.z)*s;
  bird->world.pos.y=sPiepsFlightStartV75.y+(target.y-sPiepsFlightStartV75.y)*s;
  bird->shape.rot.y=Math_Vec3f_Yaw(&bird->world.pos,&target);bird->shape.rot.x=Math_Vec3f_Pitch(&bird->world.pos,&target);Actor_SetScale(bird,.035f);
  at=bird->world.pos;eye.x=-760;eye.y=-1250;eye.z=-3000;
  Play_SetCameraAtEye(play,sPiepsFlightCamV75,&at,&eye);
 }
 if(sPiepsFlightFrameV75>=70){
  if(sPiepsFlightBirdV75!=NULL){Actor_Kill(sPiepsFlightBirdV75);sPiepsFlightBirdV75=NULL;}
  mainCam=Play_GetCamera(play,CAM_ID_MAIN);
  mainCam->eye=Play_GetCamera(play,sPiepsFlightCamV75)->eye;
  mainCam->eyeNext=mainCam->eye;mainCam->at=Play_GetCamera(play,sPiepsFlightCamV75)->at;
  Play_ReturnToMainCam(play,sPiepsFlightCamV75,0);sPiepsFlightCamV75=CAM_ID_NONE;Cutscene_StopManual(play,&play->csCtx);
  Actor_RequestQuakeAndRumble(&this->actor,play,3,6);this->health=0;
  BossDodongo_SetupDeathCutscene(this);
 }
}
static s32 Pieps_BeginBossFlightV75(BossDodongo* this,PlayState* play){
 Vec3f eye,at;
 if(!GET_INFTABLE(0x1CA)||sPiepsAssistedV75)return false;
 sPiepsFlightStartV75.x=-890;sPiepsFlightStartV75.y=-760;sPiepsFlightStartV75.z=-2784;
 sPiepsFlightBirdV75=Actor_Spawn(&play->actorCtx,play,ACTOR_EN_BIRD,-890,-760,-2784,0,0,0,0x7502);
 if(sPiepsFlightBirdV75==NULL)return false;
 sPiepsFlightCamV75=Play_CreateSubCamera(play);
 if(sPiepsFlightCamV75<=CAM_ID_MAIN){Actor_Kill(sPiepsFlightBirdV75);sPiepsFlightBirdV75=NULL;sPiepsFlightCamV75=CAM_ID_NONE;return false;}
 sPiepsAssistedV75=true;sPiepsFlightFrameV75=0;this->actor.speed=0;this->unk_1E4=0;
 Cutscene_StartManual(play,&play->csCtx);Player_SetCsActionWithHaltedActors(play,&this->actor,PLAYER_CSACTION_1);
 Play_ChangeCameraStatus(play,CAM_ID_MAIN,CAM_STAT_WAIT);Play_ChangeCameraStatus(play,sPiepsFlightCamV75,CAM_STAT_ACTIVE);
 eye.x=-760;eye.y=-1250;eye.z=-3000;at=sPiepsFlightStartV75;Play_SetCameraAtEye(play,sPiepsFlightCamV75,&at,&eye);
 SEQCMD_PLAY_SEQUENCE(SEQ_PLAYER_BGM_MAIN,0,0,111);this->actionFunc=Pieps_BossFlightV75;return true;
}

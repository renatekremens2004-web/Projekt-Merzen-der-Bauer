    {
        ACTOR_EN_RIVER_SOUND,
        {  -1817,      0,   1466 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0015, // params
    }, // 0
    {
        ACTOR_EN_RIVER_SOUND,
        {     73,     46,  -2644 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0015, // params
    }, // 1
    {
        ACTOR_EN_WEATHER_TAG,
        {   1185,      0,  -3770 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0201, // params
    }, // 2
    {
        ACTOR_BG_INGATE,
        {    820,    -40,  -2420 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0000, // params
    }, // 3
    {
        ACTOR_BG_INGATE,
        {    980,    -40,  -2420 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0000, // params
    }, // 4
    {
        ACTOR_BG_INGATE,
        {   -302,      0,  -1504 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x0000, // params
    }, // 5
    {
        ACTOR_BG_INGATE,
        {   -142,      0,  -1504 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x0000, // params
    }, // 6
    {
        ACTOR_EN_TA,
        {     -4,      0,  -1534 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x0002, // params
    }, // 7
    {
        ACTOR_EN_WONDER_ITEM,
        {    295,    123,   -979 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x1278, // params
    }, // 8
    {
        ACTOR_EN_WONDER_ITEM,
        {   -443,    119,   -311 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x1279, // params
    }, // 9
    {
        ACTOR_EN_MA2,
        {     66,      0,   -402 }, // pos
        {  0x0000,  0x0000,  0x0006 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 10
    {
        ACTOR_EN_MA2,
        {     66,      0,   -402 }, // pos
        {  0x0000,  0x0000,  0x0008 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 11
    {
        ACTOR_BG_UMAJUMP,
        {   -444,      0,   -312 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0000, // params
    }, // 12
    {
        ACTOR_BG_UMAJUMP,
        {    295,    -27,   -989 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0000, // params
    }, // 13

    { ACTOR_ELF_MSG2, { 850, 0, -2850 }, { 0, 0, 0 }, 0x3F8E }, /* Jimmy, outer yard outside horse racing track */
    { ACTOR_ELF_MSG2, { 500, 0, -2200 }, { 0, 0, 0 }, 0x3F9A }, /* V28 */

    OBJECT_HORSE_NORMAL, // 0
    OBJECT_IN, // 1
    OBJECT_UMAJUMP, // 2
    OBJECT_HORSE, // 3
    OBJECT_NIW, // 4
    OBJECT_HNI, // 5
    OBJECT_INGATE, // 6
    OBJECT_MA2, // 7

    OBJECT_JIMMY, /* one room-local guest object */

"""Convert three supplied models to small rigid N64 meshes, keeping native proportions."""
import bpy,bmesh,json,math,sys,shutil
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1])
transforms={'triangle':Matrix(((0,1,0),(0,0,1),(1,0,0))),'pregtest':Matrix(((1,0,0),(0,0,1),(0,-1,0))),'flatsquid':Matrix(((1,0,0),(0,0,1),(0,-1,0)))}
def srgb(x):return round(255*(12.92*x if x<=.0031308 else 1.055*x**(1/2.4)-.055))
for key in ['triangle','pregtest','flatsquid']:
 bpy.ops.wm.open_mainfile(filepath=str(W/(key+'-import.blend')),load_ui=False)
 D=R/'models'/key;D.mkdir(parents=True,exist_ok=True);objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];original=0;outline_removed=0;T=transforms[key]
 if key=='triangle':
  materials=[];matids={}
  for o in objects:
   for mat in o.data.materials:
    if mat.name in matids:continue
    color=mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color'].default_value;rgb=[srgb(x)for x in color[:3]]
    image=bpy.data.images.new(mat.name,width=8,height=8);image.pixels=[*(x/255 for x in rgb),1]*64;image.filepath_raw=str(D/(mat.name+'.png'));image.file_format='PNG';image.save();matids[mat.name]=len(materials);materials.append({'name':mat.name.replace('.','_'),'texture':mat.name+'.png','size':[8,8]})
 else:
  texture=next((W/'input'/key/'textures').glob('Pregtest2.png'if key=='pregtest'else '*Base_Color.png'));shutil.copyfile(texture,D/(key+'.png'));materials=[{'name':key,'texture':key+'.png','size':[64,64]}]
 for o in objects:
  bpy.context.view_layer.objects.active=o;o.select_set(True);o.data=o.data.copy();me=o.data;me.calc_loop_triangles();original+=len(me.loop_triangles)
  for mod in list(o.modifiers):o.modifiers.remove(mod)
  if key=='flatsquid':
   bm=bmesh.new();bm.from_mesh(me);faces=[f for f in bm.faces if f.material_index>0];outline_removed+=sum(len(f.verts)-2 for f in faces);bmesh.ops.delete(bm,geom=faces,context='FACES');bm.to_mesh(me);bm.free()
  me.transform(T.to_4x4()@o.matrix_world);o.matrix_world=Matrix.Identity(4)
  me.calc_loop_triangles();count=len(me.loop_triangles)
  if key=='triangle':ratio=1 if count<50 else .2 if count<500 else .08 if count<1200 else .025
  else:ratio=.13 if key=='pregtest'else .015
  mod=o.modifiers.new('N64 reduction preserving UV','DECIMATE');mod.ratio=ratio;bpy.ops.object.modifier_apply(modifier=mod.name)
 pts=[v.co for o in objects for v in o.data.vertices];lo=Vector(tuple(min(v[i]for v in pts)for i in range(3)));hi=Vector(tuple(max(v[i]for v in pts)for i in range(3)));center=(lo+hi)/2;center.y=lo.y
 scale=(88*100/(hi.y-lo.y))if key=='triangle'else(14*100/(hi.x-lo.x))if key=='pregtest'else(105*100/(hi.z-lo.z))
 m={'bones':[{'name':'root','parent':-1,'position':[0,0,0]}],'materials':materials,'vertices':[],'triangles':[]}
 for o in objects:
  me=o.data;me.calc_loop_triangles();off=len(m['vertices'])
  for v in me.vertices:m['vertices'].append({'bone':0,'position':[round(x*scale)for x in(v.co-center)]})
  for t in me.loop_triangles:
   mat=matids[me.materials[t.material_index].name]if key=='triangle'else 0
   m['triangles'].append({'material':mat,'corners':[{'vertex':off+vi,'uv':[.5,.5]if key=='triangle'else list(me.uv_layers.active.data[li].uv),'normal':[round(x*127)for x in me.vertices[vi].normal.normalized()]}for vi,li in zip(t.vertices,t.loops)]})
 m.update(source_triangles=original,outline_triangles_removed=outline_removed,dimensions_game_units=[round((hi[i]-lo[i])*scale/100,2)for i in range(3)],native_lighting=True,static=True)
 (R/f'tools/{key}_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');print(key,original,'->',len(m['triangles']),'triangles; dimensions',m['dimensions_game_units'],flush=True)

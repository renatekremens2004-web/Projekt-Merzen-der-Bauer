/* Isolated title backgrounds. No gameplay actor lists, save writes or credits scripts are changed. */
#include "cutscene_commands.h"
#include "audio.h"
#include "environment.h"
static u8 sTitleEnabledV92;
static u8 sTitleBackgroundV92;
static u8 sTitleShotV92;
static u8 sTitleNextShotV92;
static s8 sTitlePendingV92 = -1;
static ActorEntry sTitleActorsV92[24];
static s16 sTitleObjectsV92[5][8] = {
 {OBJECT_MAG,OBJECT_OF1D_MAP,OBJECT_GORON_SOLDIERS_V39,OBJECT_TANK_V40},
 {OBJECT_MAG,OBJECT_OF1D_MAP,OBJECT_GORON_SOLDIERS_V39},
 {OBJECT_MAG,OBJECT_OF1D_MAP,OBJECT_GORON_SOLDIERS_V39,OBJECT_TANK_V40,OBJECT_SPOT09_OBJ},
 {OBJECT_MAG,OBJECT_OF1D_MAP,OBJECT_GORON_SOLDIERS_V39,OBJECT_TANK_V40,OBJECT_SPECIAL_SOLDIERS_V57},
 {OBJECT_MAG,OBJECT_CREDITS_V38_DESERT,OBJECT_TANK_V40,OBJECT_SPOT09_OBJ,OBJECT_OS_ANIME,OBJECT_KM1,OBJECT_OE9}
};
static u8 sTitleObjectCountsV92[]={4,3,5,5,7};
static s16 sTitleEntrancesV92[]={ENTR_DEATH_MOUNTAIN_TRAIL_0,ENTR_GORON_CITY_0,ENTR_GERUDO_VALLEY_0,ENTR_HYRULE_FIELD_0,ENTR_GERUDO_VALLEY_0};

static CutsceneData sTitleCameraV92_0[]={
CS_HEADER(4, 350),
CS_MISC_LIST(1),
 CS_MISC(CS_MISC_SET_CSFLAG_3,1,2,0,0,0,0,0,0,0,0,0,0,0),
CS_CAM_EYE_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),-380,1300,-1530,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),-380,1300,-1530,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),-420,1300,-1550,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),-420,1300,-1550,0),
 CS_CAM_POINT(CS_CAM_STOP,0,0,CS_FLOAT(0x425C0000,55.0f),-420,1300,-1550,0),
CS_CAM_AT_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),-405,1260,-1800,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),-405,1260,-1800,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),-405,1260,-1800,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),-405,1260,-1800,0),
 CS_CAM_POINT(CS_CAM_STOP,0,100,CS_FLOAT(0x425C0000,55.0f),-405,1260,-1800,0),
CS_DESTINATION(CS_DEST_TITLE_SCREEN_DEMO,280,281),
CS_END_OF_SCRIPT(),
};

static CutsceneData sTitleCameraV92_1[]={
CS_HEADER(4, 350),
CS_MISC_LIST(1),
 CS_MISC(CS_MISC_SET_CSFLAG_3,1,2,0,0,0,0,0,0,0,0,0,0,0),
CS_CAM_EYE_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),80,130,300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),80,130,300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),80,140,330,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),80,140,330,0),
 CS_CAM_POINT(CS_CAM_STOP,0,0,CS_FLOAT(0x425C0000,55.0f),80,140,330,0),
CS_CAM_AT_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),80,70,-20,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),80,70,-20,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),80,70,-20,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),80,70,-20,0),
 CS_CAM_POINT(CS_CAM_STOP,0,100,CS_FLOAT(0x425C0000,55.0f),80,70,-20,0),
CS_DESTINATION(CS_DEST_TITLE_SCREEN_DEMO,280,281),
CS_END_OF_SCRIPT(),
};

static CutsceneData sTitleCameraV92_2[]={
CS_HEADER(4, 350),
CS_MISC_LIST(1),
 CS_MISC(CS_MISC_SET_CSFLAG_3,1,2,0,0,0,0,0,0,0,0,0,0,0),
CS_CAM_EYE_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1450,140,-250,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1450,140,-250,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1450,140,-150,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1450,140,-150,0),
 CS_CAM_POINT(CS_CAM_STOP,0,0,CS_FLOAT(0x425C0000,55.0f),1450,140,-150,0),
CS_CAM_AT_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),1100,65,-200,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),1100,65,-200,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),1100,65,-200,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),1100,65,-200,0),
 CS_CAM_POINT(CS_CAM_STOP,0,100,CS_FLOAT(0x425C0000,55.0f),1100,65,-200,0),
CS_DESTINATION(CS_DEST_TITLE_SCREEN_DEMO,280,281),
CS_END_OF_SCRIPT(),
};

static CutsceneData sTitleCameraV92_3[]={
CS_HEADER(4, 350),
CS_MISC_LIST(1),
 CS_MISC(CS_MISC_SET_CSFLAG_3,1,2,0,0,0,0,0,0,0,0,0,0,0),
CS_CAM_EYE_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),-8950,-130,8150,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),-8950,-130,8150,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),-9020,-110,8200,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),-9020,-110,8200,0),
 CS_CAM_POINT(CS_CAM_STOP,0,0,CS_FLOAT(0x425C0000,55.0f),-9020,-110,8200,0),
CS_CAM_AT_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),-8950,-240,7700,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),-8950,-240,7700,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),-8950,-240,7700,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),-8950,-240,7700,0),
 CS_CAM_POINT(CS_CAM_STOP,0,100,CS_FLOAT(0x425C0000,55.0f),-8950,-240,7700,0),
CS_DESTINATION(CS_DEST_TITLE_SCREEN_DEMO,280,281),
CS_END_OF_SCRIPT(),
};

static CutsceneData sTitleCameraV92_4[]={
CS_HEADER(4, 350),
CS_MISC_LIST(1),
 CS_MISC(CS_MISC_SET_CSFLAG_3,1,2,0,0,0,0,0,0,0,0,0,0,0),
CS_CAM_EYE_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,190,-654,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,190,-654,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,140,-654,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,140,-654,0),
 CS_CAM_POINT(CS_CAM_STOP,0,0,CS_FLOAT(0x425C0000,55.0f),1286,140,-654,0),
CS_CAM_AT_SPLINE(0, 340),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),1168,170,-613,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),1168,170,-613,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),1168,170,-613,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,100,CS_FLOAT(0x425C0000,55.0f),1168,170,-613,0),
 CS_CAM_POINT(CS_CAM_STOP,0,100,CS_FLOAT(0x425C0000,55.0f),1168,170,-613,0),
CS_DESTINATION(CS_DEST_TITLE_SCREEN_DEMO,280,281),
CS_END_OF_SCRIPT(),
};

static CutsceneData* sTitleCamerasV92[]={sTitleCameraV92_0,sTitleCameraV92_1,sTitleCameraV92_2,sTitleCameraV92_3,sTitleCameraV92_4};
/* En_Mag switches to FILE_SELECT before the outgoing PlayState is destroyed.
 * Keep its title-only actors in the same mode throughout that fade. */
s32 TitleMontage_IsActiveV92(void){return (gSaveContext.gameMode==GAMEMODE_TITLE_SCREEN||gSaveContext.gameMode==GAMEMODE_FILE_SELECT)&&sTitleEnabledV92&&sTitleBackgroundV92;}
s32 TitleMontage_ShotV92(void){return sTitleShotV92;}
s32 TitleMontage_LayerV92(void){return sTitleShotV92==4?6:2;}
void* TitleMontage_ScriptV92(void){return sTitleCamerasV92[sTitleShotV92];}
static void TitleMontage_TimeV92(void){
 gSaveContext.save.linkAge=LINK_AGE_ADULT;
 gSaveContext.save.dayTime=sTitleShotV92==4?CLOCK_TIME(19,30):CLOCK_TIME(15,0);
 gSaveContext.skyboxTime=gSaveContext.save.dayTime;
 gSaveContext.save.nightFlag=sTitleShotV92==4;
 gSaveContext.nextDayTime=NEXT_TIME_NONE;
 gSaveContext.forceRisingButtonAlphas=true;
}
void TitleMontage_StartV92(void){
 sTitleEnabledV92=true;sTitleBackgroundV92=true;sTitleShotV92=0;sTitlePendingV92=-1;
 gSaveContext.save.entranceIndex=sTitleEntrancesV92[0];TitleMontage_TimeV92();
}
void TitleMontage_BeginSceneV92(void){
 if(gSaveContext.gameMode!=GAMEMODE_TITLE_SCREEN||!sTitleEnabledV92)return;
 if(sTitlePendingV92>=0){
  sTitleBackgroundV92=sTitlePendingV92;
  if(sTitleBackgroundV92){sTitleShotV92=sTitleNextShotV92;TitleMontage_TimeV92();}
  sTitlePendingV92=-1;
 }
 if(sTitleBackgroundV92)gSaveContext.showTitleCard=false;
}
static void TitleMontage_TransitionV92(PlayState* play,u8 next){
 sTitleNextShotV92=next;sTitlePendingV92=1;
 play->nextEntranceIndex=sTitleEntrancesV92[next];
 gSaveContext.save.cutsceneIndex=CS_INDEX_0;
 play->transitionTrigger=TRANS_TRIGGER_START;
 play->transitionType=TRANS_TYPE_FADE_BLACK_FAST;
 gSaveContext.nextTransitionType=TRANS_TYPE_FADE_BLACK_FAST;
}
s32 TitleMontage_ReturnV92(PlayState* play){
 if(gSaveContext.gameMode!=GAMEMODE_TITLE_SCREEN||!sTitleEnabledV92)return false;
 TitleMontage_TransitionV92(play,0);return true;
}
s32 TitleMontage_AdvanceV92(PlayState* play){
 if(!TitleMontage_IsActiveV92())return false;
 if(sTitleShotV92==4){sTitlePendingV92=0;return false;} /* Commit only after the outgoing scene has been destroyed. */
 TitleMontage_TransitionV92(play,sTitleShotV92+1);return true;
}
static void TitleMontage_PlayerIdleV92(UNUSED Actor* actor,UNUSED PlayState* play){}
void TitleMontage_UpdateV92(PlayState* play){
 Player* player;
 if(!TitleMontage_IsActiveV92())return;
 play->csCtx.script=TitleMontage_ScriptV92();
 play->actorCtx.titleCtx.durationTimer=0;play->actorCtx.titleCtx.delayTimer=0;play->actorCtx.titleCtx.alpha=0;
 player=GET_PLAYER(play);
 if(player!=NULL){player->actor.draw=NULL;player->actor.update=TitleMontage_PlayerIdleV92;player->actor.shape.shadowDraw=NULL;}
}
s16* TitleMontage_ObjectsV92(s32* count){*count=sTitleObjectCountsV92[sTitleShotV92];return sTitleObjectsV92[sTitleShotV92];}
u32 TitleMontage_ObjectSpaceV92(void){
 s32 count,i;u32 size=0;u32 extra; s16* list=TitleMontage_ObjectsV92(&count);
 s16 keep[]={OBJECT_GAMEPLAY_KEEP,OBJECT_GAMEPLAY_FIELD_KEEP,OBJECT_LINK_BOY};
 for(i=0;i<3;i++){extra=gObjectTable[keep[i]].vromEnd-gObjectTable[keep[i]].vromStart;size+=ALIGN16(extra);}
 for(i=0;i<count;i++){extra=gObjectTable[list[i]].vromEnd-gObjectTable[list[i]].vromStart;size+=ALIGN16(extra);}
 return ALIGN16(size+32*1024);
}
void TitleMontage_ActorsV92(PlayState* play){
 s32 i,n=0;ActorEntry* src=play->actorEntryList;ActorEntry a;
 for(i=0;i<play->numActorEntries&&n<20;i++){
  a=src[i];
  if(play->sceneId==SCENE_GORON_CITY&&a.id==ACTOR_ELF_MSG2&&(u16)a.params==0x3F90)a.pos.x=-20;
  if(a.id==ACTOR_TANK_V68 || (a.id==ACTOR_EN_GO2&&(u16)a.params>=0x7F60&&(u16)a.params<=0x7F71) ||
     (a.id==ACTOR_ELF_MSG2&&((play->sceneId==SCENE_GORON_CITY&&a.params==0x3F90)||(sTitleShotV92==4&&a.params==0x7F50))) ||
     (play->sceneId==SCENE_GERUDO_VALLEY&&a.id==ACTOR_BG_SPOT09_OBJ))sTitleActorsV92[n++]=a;
 }
 a.id=ACTOR_EN_MAG;a.pos.x=a.pos.y=a.pos.z=0;a.rot.x=a.rot.y=a.rot.z=0;a.params=0;sTitleActorsV92[n++]=a;
 if(sTitleShotV92==4){a.id=ACTOR_EN_KO;a.pos.x=600;a.pos.y=100;a.pos.z=-200;a.rot.y=-16384;a.params=0x7E00;sTitleActorsV92[n++]=a;}
 play->actorEntryList=sTitleActorsV92;play->numActorEntries=n;
}

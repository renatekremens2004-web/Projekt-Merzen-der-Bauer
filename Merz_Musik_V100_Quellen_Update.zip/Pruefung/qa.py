from pathlib import Path
import os,sys,json,subprocess,struct,re,runpy
W=Path(__file__).resolve().parent;rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1])
if (W/'qa-case.txt').exists()and(W/'qa-case.txt').read_text().strip()=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit()
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('obj<=0x1af','obj<=0x1b0')
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);video=Path('/workspace/pieps-v79/video_capture.c').read_text()
body=r'''
static unsigned began=0,sawtext=0,sawmusic=0,sawstereo=0,finished=0,leftframe=0,maxpos=0,minspec=999;
static void onframe(unsigned f){
 baseframe(f);if(f<305)return;findplay();if(!play||!player)return;
 unsigned scene=DebugMemRead16(play+0xa4),cs=DebugMemRead16(play+0x1d74),msg=play+0x20d8,mode=DebugMemRead8(msg+0xe304),id=DebugMemRead16(msg+0xe2f8),seq=AUDIO+0x3530,music=DebugMemRead8(seq+4),enabled=DebugMemRead8(seq)&128;
 if(f%150==0)printf("STATE f=%u scene=%x cs=%u text=%x mode=%x music=%u enabled=%u spec=%u\n",f,scene,cs,id,mode,music,enabled,DebugMemRead8(SPEC));
 if(scene==0x47){
  if(!began){began=1;printf("VOID_BEGIN f=%u cs=%u\n",f,cs);bank();}
  pending=1;
  if(id==0x700a&&mode)sawtext=1;
  if(music==114&&enabled){
   sawmusic=1;unsigned notes=r32(AUDIO+0x352c),num=r32(AUDIO+0x2894),streams=0,pp[2]={0,0};
   need(num==28,"native cinematic note budget remains28");
   for(unsigned k=0;k<num;k++){
    unsigned n=notes+k*0xe0;if(!(DebugMemRead8(n+0xc0)&128)||DebugMemRead8(n+0x33)!=41)continue;
    unsigned t=r32(n+0xd0),s=r32(t),loop=r32(s+8),end=r32(loop+4),pos=r32(n+0x18);
    if(f<315)printf("STREAM sample=%x end=%u pos=%u header=%x tuning=%.6f\n",s,end,pos,r32(s),rf(t+4));need(end>=LENGTH-1&&end<=LENGTH+32,"correct uploaded audio sample active");need(((r32(s)>>26)&3)==2,"large sample stays on cartridge, not in RAM cache");need(fabsf(rf(t+4)-1.0f)<.0001f,"32kHz sample tuning correct");
    if(streams<2)pp[streams]=pos;streams++;if(pos>maxpos)maxpos=pos;
   }
   if(streams==2){need(abs((int)pp[0]-(int)pp[1])<=2,"stereo streams remain synchronized");sawstereo=1;}
  }
  if(cs==180||cs==330||f==600)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
 }else if(began){
  pending=1;if(!leftframe){leftframe=f;printf("VOID_LEFT scene=%x music=%u enabled=%u maxpos=%u\n",scene,music,enabled,maxpos);}
  if(f>leftframe+120){
   need(scene==0x44,"normal destination is Chamber of Sages");need(music!=114||!enabled,"Merz score stops at scene change");need(sawtext&&sawmusic&&sawstereo&&maxpos>100000,"native cutscene, dialogue and two streamed voices work");bank();puts("MERZ_VOID_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);
  }
 }
 if(buttons)buttons((f>650&&f%32<2&&(mode==6||mode==7||mode==0x34||mode==0x35))?0x80:0);
 need(f<2600,"cutscene returns to normal sage sequence");
}
'''.replace('AUDIO',hex(sy['gAudioCtx'])).replace('SPEC',hex(sy['gAudioSpecId'])).replace('LENGTH',str(json.loads((W/'manifest.json').read_text())['frames']))
s=base[:a]+video+body+base[b:];s=s.replace('if(video && pclose(video)!=0)return 96;','if(video){hold_frame_until(audioSamples());printf("VIDEO_CAPTURE first=%llu last=%llu rate=%u frames=%u\\n",(unsigned long long)firstAudio,(unsigned long long)lastAudio,audioRate(),encoded);}if(video && pclose(video)!=0)return 96;')
c=W/f'probe-{mode}.c';c.write_text(s);exe=W/f'probe-{mode}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0xa0,1,0xfff3);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,0,0,0,0,0xdff,0xa0,0);q[0x1409]=1;save=W/'void.save';save.write_bytes(q)
pcm=W/f'{mode}.pcm';vid=W/f'{mode}-silent.mp4'
with(W/f'qa-{mode}.log').open('w')as log:
 r=subprocess.run([str(exe),rom,f'merz-void-v100-direct-{mode}','2800','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH=str(pcm),PIEPS_VIDEO_PATH=str(vid)),stdout=log,stderr=subprocess.STDOUT,timeout=400)
log=(W/f'qa-{mode}.log').read_text();assert r.returncode==0 and'MERZ_VOID_PASSED'in log,(r.returncode,log[-2300:])
if mode=='normal':
 first,last,rate,frames=map(int,re.search(r'VIDEO_CAPTURE first=(\d+) last=(\d+) rate=(\d+) frames=(\d+)',log).groups());out=W/'Merz_weisse_Leere_V100_mit_Musik.mp4'
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(vid),'-f','s16le','-ar',str(rate),'-ac','2','-skip_initial_bytes',str(first*4),'-i',str(pcm),'-map','0:v','-map','1:a','-t',str(frames/50),'-c:v','copy','-c:a','aac','-b:a','192k','-movflags','+faststart',str(out)],check=True)
 (W/'video-verification.json').write_text(json.dumps(dict(first=first,last=last,rate=rate,frames=frames,seconds=frames/50,includes_scene_transition=True),indent=2))
print('MERZ_NATIVE_QA_PASSED',mode,flush=True)

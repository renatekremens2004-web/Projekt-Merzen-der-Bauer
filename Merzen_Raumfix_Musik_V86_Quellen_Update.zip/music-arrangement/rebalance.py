from pathlib import Path
import numpy as np,json
W=Path(__file__).resolve().parent;rate=31995;N=315*rate;oldfirst=574464
oldg=[0,0,4.5,4,1,10,18,6,8,10,10,0,12,0,1,4.5]
newg=[0,0,2.0,2.0,.5,5.0,12.0,5.4,7.4,4.5,2.5,0,4.0,0,.5,2.0]
out=np.zeros((N,2),np.float32);a=51*rate;b=55*rate;fade=np.linspace(0,1,b-a,dtype=np.float32)
for ci,(before,after)in enumerate(zip(oldg,newg)):
 m=json.loads((W/f'stem-{ci:02d}.json').read_text());off=round(rate*60/76)+oldfirst-m['first_sample'];part=np.memmap(W/f'stem-{ci:02d}.pcm','<i2',mode='r').reshape(-1,2)[m['first_sample']+off:m['first_sample']+off+N].astype(np.float32)
 curve=np.full(N,10**(before/20),np.float32)
 if ci==9:
  t0=50*rate;t1=53*rate;curve[:t0]=10**(4/20);curve[t0:t1]=np.linspace(10**(4/20),10**(10/20),t1-t0)
 target=10**(after/20);curve[a:b]=curve[a:b]*(1-fade)+target*fade;curve[b:]=target
 if ci==12:
  # The single high counterline C5 attack is at82.895s, ending85.263s.
  # Leave it present, far behind the other revised accompaniment.
  p0=round(82.83*rate);p1=round(82.89*rate);p2=round(85.27*rate);p3=round(85.47*rate);quiet=10**(-8/20)
  curve[p0:p1]=np.linspace(curve[p0],quiet,p1-p0);curve[p1:p2]=quiet;curve[p2:p3]=np.linspace(quiet,target,p3-p2)
 out+=part*curve[:,None]
(out*1.6).tofile(W/'mix-V86b-unlimited.f32')
r=dict(revision='86b',original_gains_db=oldg,new_gains_db=newg,unchanged_intro_seconds=51,crossfade_end_seconds=55,choir_reduction_db=.6,local_high_counterline=dict(start=82.895,end=85.263,gain_db_relative_v85=-8),source='sixteen isolated native OoT instrument stems',new_notes=False,new_transposition=False)
(W/'rebalance-report.json').write_text(json.dumps(r,indent=2));print('BALANCED_MIX_READY',float(abs(out).max()*1.6))

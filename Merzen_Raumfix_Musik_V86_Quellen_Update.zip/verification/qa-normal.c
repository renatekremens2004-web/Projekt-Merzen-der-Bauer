#define M64P_CORE_PROTOTYPES
#include "m64p_common.h"
#include "m64p_frontend.h"
#include "m64p_config.h"
#include "m64p_debugger.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <execinfo.h>
#include <math.h>
static void crash(int n){void* b[40];int c=backtrace(b,40);backtrace_symbols_fd(b,c,2);_exit(128+n);}

static void alarmcb(int sig){(void)sig;uint32_t* c=DebugGetCPUDataPtr(M64P_CPU_REG_COP0);printf("CPU pc=%08x cause=%08x epc=%08x bad=%08x\n",*(uint32_t*)DebugGetCPUDataPtr(M64P_CPU_PC),c[13],c[14],c[8]);for(uint32_t t=DebugMemRead32(0x8000633c),n=0;t>=0x80000000 && t<0x80800000 && n<15;t=DebugMemRead32(t+12),n++){printf("THREAD %08x id=%u state=%u pc=%08x ra=%08x sp=%08x\n",t,DebugMemRead32(t+20),DebugMemRead16(t+16),DebugMemRead32(t+0x11c),DebugMemRead32(t+0x104),DebugMemRead32(t+0xf4));}FILE* d=fopen("/workspace/bean-rider/stalled-ram.bin","wb");for(uint32_t a=0x80000000;a<0x80400000;a+=4){uint32_t v=__builtin_bswap32(DebugMemRead32(a));fwrite(&v,4,1,d);}fclose(d);alarm(15);}
static uint32_t savebase=0x80118450, overlays=0x800e6500;
static int limit=2400;static int memory_mb=4;
static const char* scenario;
static const char* snapshotfile;
static void (*buttons)(unsigned);
static unsigned actors[32],player;static int count;
static uint32_t r32(uint32_t a){return DebugMemRead32(a);}
static float rf(uint32_t a){uint32_t x=r32(a);float f;memcpy(&f,&x,4);return f;}
static void debugcb(void* ctx,int level,const char* message){static int bad=0;if(strstr(message,"UNKNOWN GBI COMMAND") || strstr(message,"Using Vertex outside buffer")){if(++bad>100)exit(98);}if(level<=2)fprintf(stderr,"EMU %d: %s\n",level,message);}
static void scan(void){
 count=0;
 for(uint32_t a=0x80120000;a<0x80400000-0x700;a+=4){
  unsigned id=DebugMemRead16(a);if(id==0 && r32(a+0x138)==overlays && DebugMemRead8(a+2)==2 && r32(a+0x130))player=a;if(id!=0xe8 && id!=0x2a && id!=0x17a && id!=0x52)continue;
  if(r32(a+0x138)!=overlays+id*0x20 || !r32(a+0x130))continue;
  int params=(int16_t)DebugMemRead16(a+0x1c);
  if(id==0xe8 && params>=100)continue;
  if(id==0x2a && (params>>8)!=3 && (params>>8)!=5 && (params>>8)!=7 && (params>>8)!=8 && (params>>8)!=9)continue;
  if(count<32)actors[count++]=a;
 }
}
static uint32_t play;
static uint32_t actor(int id){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130))return a;
 return 0;
}
static uint32_t actor_type(int id,int type){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130) && (type<0 || (DebugMemRead16(a+0x1c)&127)==type))return a;
 return 0;
}
static void findplay(void){
 if(play && r32(play+0x1c44)==player && player && r32(player+0x130))return;
 play=0;player=0;scan();if(!player)return;
 for(uint32_t a=0x80120000;a<0x80400000;a+=4)if(r32(a)==player && a>0x80121c44 && r32(a-4)==1){uint32_t p=a-0x1c44;if(DebugMemRead16(p+0xa4)<0x70 && r32(p)>=0x80000000){play=p;break;}}
 if(play)printf("PLAY %08x player=%08x scene=%x\n",play,player,DebugMemRead16(play+0xa4));
}
static void wf(uint32_t a,float f){uint32_t v;memcpy(&v,&f,4);DebugMemWrite32(a,v);}
static void position(uint32_t a,float x,float y,float z,int facing){wf(a+0x24,x);wf(a+0x28,y);wf(a+0x2c,z);wf(a+0x100,x);wf(a+0x104,y);wf(a+0x108,z);DebugMemWrite16(a+0xb6,facing);DebugMemWrite16(a+0x32,facing);}
static void baseframe(unsigned f){
 alarm(30);
 if (snapshotfile && f == 300) {
   findplay();
   if (strstr(scenario,"export")) {
     FILE* snap=fopen(snapshotfile,"wb");if(!snap)exit(90);
     for(unsigned i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),snap);
     fclose(snap);printf("EXPORTED save=%08x entrance=%x age=%d mode=%d\n",savebase,r32(savebase),r32(savebase+4),r32(savebase+0x135c));
     CoreDoCommand(M64CMD_STOP,0,NULL);return;
   }
   if(!play){fprintf(stderr,"No title PlayState found\n");exit(91);}
   printf("INJECT title scene=%x mode=%d save=%08x\n",DebugMemRead16(play+0xa4),r32(savebase+0x135c),savebase);
   FILE* snap=fopen(snapshotfile,"rb");if(!snap)exit(92);
   for(unsigned i=0;i<0x1428;i++){int ch=fgetc(snap);if(ch<0)exit(93);DebugMemWrite8(savebase+i,ch);}fclose(snap);
   DebugMemWrite32(savebase+0x135c,0);
   DebugMemWrite8(play+0x11de8,r32(savebase+4));
   DebugMemWrite16(savebase+0x1412,r32(savebase+8)?r32(savebase+8):0xffef);
   DebugMemWrite8(play+0x1d6c,0);
   if(strstr(scenario,"direct")) {
     uint32_t game=0x800f0c10+3*0x30;
     if(r32(game+0x2c)!=0x12518){fprintf(stderr,"Invalid Play gamestate entry\n");exit(97);}
     DebugMemWrite8(play+0x11de9,1);
     DebugMemWrite32(play+0xc,r32(game+0x18));DebugMemWrite32(play+0x10,0x12518);DebugMemWrite32(play+0x98,0);
     printf("DIRECT Play_Init=%08x\n",r32(game+0x18));
   }else{
     DebugMemWrite16(play+0x11e1a,r32(savebase));
     DebugMemWrite8(play+0x11e5e,2);DebugMemWrite8(play+0x11e15,20);
   }
   printf("START entrance=%x age=%d cs=%x\n",r32(savebase),r32(savebase+4),r32(savebase+8));
 }
}

static uint64_t (*audioSamples)(void);static unsigned (*audioRate)(void);
static FILE* video=NULL;
static void need(int ok,const char*why){if(!ok){printf("ASSERT_FAILED %s\n",why);exit(96);}}
static unsigned target(unsigned id,unsigned param){
 for(int cat=0;cat<12;cat++)for(unsigned p=r32(play+0x1c34+cat*8),n=0;p>=0x80000000&&p<0x80400000&&n<200;p=r32(p+0x124),n++)if(DebugMemRead16(p)==id&&DebugMemRead16(p+0x1c)==param&&r32(p+0x130))return p;
 return 0;
}
static void bank(void){
 unsigned c=play+0x117a4,begin=r32(c),end=r32(c+4),last=begin,count=DebugMemRead8(c+8);
 for(unsigned i=0;i<count&&i<19;i++){unsigned p=c+12+i*0x44;int obj=(int16_t)DebugMemRead16(p);if(obj<0)obj=-obj;if(obj>0&&obj<=0x1af){unsigned e=r32(p+4)+r32(0x800f8978+obj*8+4)-r32(0x800f8978+obj*8);if(e>last)last=e;}}
 need(DebugMemRead16(0x8011c690)==0,"no rejected object loads");need(DebugMemRead16(0x80119268)==0&&DebugMemRead16(0x8011926a)==0,"all actor allocations succeed");for(unsigned q=0;q<3;q++){unsigned ctx=r32(play),off=0x2a8+q*16;need(r32(ctx+off+8)<=r32(ctx+off+12),"graphics command and matrix buffers stay within bounds");}printf("BANK slots=%u used=%u free=%d RAM=%u\n",count,last-begin,(int)(end-last),r32(0x80000318));need(count<=19&&last<=end,"object bank within budget");need(r32(0x80000318)==4194304,"native 4 MiB");
}
static void photo(float x,float y,float z,float ax,float ay,float az){
 unsigned c=r32(play+0x790+DebugMemRead16(play+0x7a0)*4);DebugMemWrite16(c+0x142,0x21);DebugMemWrite16(c+0x144,0);DebugMemWrite16(c+0x15e,1);DebugMemWrite16(c+0x14c,0);wf(c+0xfc,55);wf(c+0x5c,x);wf(c+0x60,y);wf(c+0x64,z);wf(c+0x74,x);wf(c+0x78,y);wf(c+0x7c,z);wf(c+0x50,ax);wf(c+0x54,ay);wf(c+0x58,az);
}






static void capture_render(void){}
static unsigned ticks=0,seen=0,help=0,rescued=0,music=0,finished=0;
static void cageframe(unsigned f){
 unsigned value=0,bird=0,msg=0,id=0;int farm=strstr(scenario,"farm")!=NULL,absent=strstr(scenario,"absent")!=NULL,visual=strstr(scenario,"visual")!=NULL;
 baseframe(f);if(f<340)return;findplay();if(!play||!player)return;msg=play+0x20d8;id=DebugMemRead16(msg+0xe2f8);bird=target(0x72,0x7501);
 if(bird&&r32(bird+0x134))seen=1;
 if(farm){need(!target(0x173,0x3f8e),"Jimmy actor absent");if(f==430||f==650){bank();}if(f>750){puts("PIEPS_QA_PASSED Jimmy absent; bank in budget");CoreDoCommand(M64CMD_STOP,0,NULL);}return;}
 if(absent){need(!bird,"rescued bird absent on next entry");if(f==600)bank();if(f>650){puts("PIEPS_QA_PASSED bird absent after rescue");CoreDoCommand(M64CMD_STOP,0,NULL);}return;}
 if(id==0x7239)help=1;
 if((DebugMemRead8(0x80125f00+0x3534)==111)&&(DebugMemRead8(0x80125f00+0x3530)&0x80))music=1;
 if(bird&&DebugMemRead16(bird+0x18c)>=2&&!visual){
  float x=rf(bird+0x24),y=rf(bird+0x28),z=rf(bird+0x2c);position(player,x-40,y,z+48,26000);if(f==500)photo(x+65,y+42,z+95,x,y+20,z);
  if(f>650){
   for(unsigned p=r32(play+0x1c34+5*8),n=0;p>=0x80000000&&p<0x80400000&&n<80;p=r32(p+0x124),n++){
    if(DebugMemRead16(p)==0x25&&DebugMemRead16(p+0x3ec)==5&&r32(p+0x130)&&r32(p+0x3cc)<10){DebugMemWrite8(p+0xb0,20);DebugMemWrite8(p+0xb1,0);DebugMemWrite8(p+0x419,DebugMemRead8(p+0x419)|2);}
   }
   value=0;if(f%15<2)value|=0x80;
  }
 }
 if(f==365||f==385||f==420||f==500||f==620||f==950||f==1250){bank();printf("PIEPS f=%u bird=%x help=%u state=%u text=%x music=%u flag=%x\n",f,bird,help,bird?DebugMemRead16(bird+0x18c):0,id,music,DebugMemRead16(savebase+0xf30));}
 if(DebugMemRead16(savebase+0xf30)&0x400){rescued=1;if(!finished)finished=f;}
 if(f%200==0&&bird)printf("TALK f=%u playerstate=%x cs=%u talk=%x birdflag=%x dist=%.1f msgmode=%u lock=%u\n",f,r32(player+0x66c),DebugMemRead8(player+0x434),r32(player+0x684),r32(bird+4),rf(bird+0x90),DebugMemRead8(msg+0xe304),DebugMemRead8(bird+0x10c));
 if(buttons)buttons(value);
 if(visual&&f>720){need(seen&&help&&bird&&DebugMemRead16(bird+0x18c)>=2,"bird intro and camera restore");puts("PIEPS_QA_PASSED native bird/cage/intro");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(!visual&&rescued&&f>finished+50){bank();need(seen&&help&&music,"rescue after combat with own theme");FILE* q=fopen("/workspace/room-audio-v86/pieps-rescued.save","wb");need(q!=NULL,"save fixture");for(unsigned i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),q);fclose(q);puts("PIEPS_QA_PASSED rescue persisted");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(f>2500){puts("PIEPS_QA_TIMEOUT");exit(96);}
}

static unsigned seenBird=0,seenInhale=0,swallowed=0,seenDeath=0,seenTheme=0,bombBirth=0,done=0;
static unsigned lastAction=0,postTalk=0,postClosed=0;
static unsigned bossfunc(unsigned v){return r32(overlays+0x27*0x20+0x10)+v-0x808a12b0;}
static void bossframe(unsigned f){
 unsigned value=0,boss=0,bird=0,action=0,bomb=0;int plain=strstr(scenario,"plain")!=NULL,cleared=strstr(scenario,"cleared")!=NULL;
 baseframe(f);if(f<340)return;findplay();if(!play||!player)return;
 boss=r32(play+0x1c34+9*8);if(boss<0x80000000||boss>=0x80400000)boss=0;
 if(cleared){
  unsigned post=target(0x72,0x7503),msg=play+0x20d8;need(!boss,"already-cleared boss not respawned");
  if(f>430){need(post&&r32(post+0x134),"friendly bird also present on cleared re-entry");position(player,rf(post+0x24)-25,rf(post+0xc)-12,rf(post+0x2c)+42,27000);if(f%18<2)value=0x80;}
  if(DebugMemRead16(msg+0xe2f8)==0x723b&&DebugMemRead8(msg+0xe304))postTalk=1;
  if(postTalk&&DebugMemRead16(post+0x18c)==2&&!DebugMemRead8(msg+0xe304))postClosed=1;
  if(buttons)buttons(value);
  if(f>700&&postClosed){bank();need(actor(0x5f)&&actor(0x5d),"native heart and warp after cleared entry");puts("PIEPS_QA_PASSED cleared entry: bird conversation723B, native heart/warp");CoreDoCommand(M64CMD_STOP,0,NULL);}if(f>1500)exit(96);return;
 }
 if(!boss){if(f%200==0){unsigned post=target(0x72,0x7503);printf("POST bird=%x state=%u text=%x mode=%u flags=%x xz=%.1f talk=%u closed=%u\n",post,post?DebugMemRead16(post+0x18c):0,DebugMemRead16(play+0x20d8+0xe2f8),DebugMemRead8(play+0x20d8+0xe304),post?r32(post+4):0,post?rf(post+0x90):0,postTalk,postClosed);printf("NO_BOSS f=%u scene=%x room=%d player=%.0f,%.0f,%.0f lists=%x/%x\n",f,DebugMemRead16(play+0xa4),(int)(signed char)DebugMemRead8(play+0x11cbc),rf(player+0x24),rf(player+0x28),rf(player+0x2c),r32(play+0x1c34+9*8),r32(play+0x1d3c));bank();}if(f>900){puts("ASSERT_FAILED missing boss");exit(96);}return;}
 action=r32(boss+0x180);bird=target(0x72,0x7502);bomb=actor(0x10);
 if(action!=lastAction){printf("BOSS f=%u action=%x state=%d timer=%d xyz=%.0f,%.0f,%.0f mouth=%.0f,%.0f,%.0f\n",f,action,DebugMemRead16(boss+0x18c),DebugMemRead16(boss+0x1ca),rf(boss+0x24),rf(boss+0x28),rf(boss+0x2c),rf(boss+0x40c),rf(boss+0x410),rf(boss+0x414));lastAction=action;}
 if(bird){if(!seenBird){bank();}seenBird=1;}
 if((DebugMemRead8(0x80125f00+0x3534)==111)&&(DebugMemRead8(0x80125f00+0x3530)&0x80))seenTheme=1;
 if(action==bossfunc(0x808a391c))seenInhale=1;
 if(action==bossfunc(0x808a3358)&&seenInhale)swallowed=1;
 if(action==bossfunc(0x808a5c0c))seenDeath=1;
 if(!seenBird&&!seenDeath){
  if(f>600&&DebugMemRead16(boss+0x1a4)==0){
   float x=rf(boss+0x24),z=rf(boss+0x2c);double yaw=DebugMemRead16(boss+0xb6)*6.283185307179586/65536.;position(player,x+sin(yaw)*210,-1523.76f,z+cos(yaw)*210,(int)(DebugMemRead16(boss+0xb6)+32768));
   if(!bomb&&f%70<2)value=0x200;
   if(bomb){if(!bombBirth)bombBirth=f;if(r32(bomb+0x118)){if(f>bombBirth+15&&f%10<2)value=0x80;}else if(action==bossfunc(0x808a391c)){position(bomb,rf(boss+0x40c),rf(boss+0x410),rf(boss+0x414),0);wf(bomb+0x60,0);wf(bomb+0x6c,0);}}
   else bombBirth=0;
  }
 }
 if(plain&&swallowed&&f%30==0){need(!seenBird&&!seenDeath&&!seenTheme,"without rescue boss remains vanilla");bank();puts("PIEPS_QA_PASSED native bomb swallow without rescue");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(!plain&&seenDeath&&DebugMemRead16(boss+0x18c)==100){
  unsigned post=target(0x72,0x7503),msg=play+0x20d8;need(post&&r32(post+0x134),"friendly bird remains after boss");
  if(f>done+30&&done){position(player,rf(post+0x24)-25,rf(post+0xc)-12,rf(post+0x2c)+42,27000);if(f%18<2)value=0x80;}
  if(DebugMemRead16(msg+0xe2f8)==0x723b&&DebugMemRead8(msg+0xe304))postTalk=1;
  if(postTalk&&DebugMemRead16(post+0x18c)==2&&!DebugMemRead8(msg+0xe304))postClosed=1;
  if(!done){bank();need(seenBird&&swallowed&&seenTheme&&!bird,"assisted bomb swallow and native death without lingering bird");need(actor(0x5f)&&actor(0x5d),"native heart container and exit warp");need(r32(play+0x1d3c)&2,"native room clear flag");done=f;}
  if(f>done+100&&postClosed){need((DebugMemRead8(0x80125f00+0x3534)==111),"theme persists after boss clear");need(!(r32(player+0x66c)&0x20000000),"player control restored");puts("PIEPS_QA_PASSED assisted boss; native heart, warp, clear, control, music; post-boss conversation723B completed");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(f%200==0){unsigned post=target(0x72,0x7503);printf("POST bird=%x state=%u text=%x mode=%u flags=%x xz=%.1f talk=%u closed=%u\n",post,post?DebugMemRead16(post+0x18c):0,DebugMemRead16(play+0x20d8+0xe2f8),DebugMemRead8(play+0x20d8+0xe304),post?r32(post+4):0,post?rf(post+0x90):0,postTalk,postClosed);printf("BOSS_STATE cs=%u room=%u done=%u\n",DebugMemRead16(boss+0x18c),DebugMemRead8(play+0x11cbc),done);printf("TRACE f=%u boss=%x act=%x bird=%x bomb=%x par=%x inhale=%u swallow=%u death=%u theme=%u playerflags=%x\n",f,boss,action,bird,bomb,bomb?r32(bomb+0x118):0,seenInhale,swallowed,seenDeath,seenTheme,r32(player+0x66c));}
 if(buttons)buttons(value);if(f>4600){puts("PIEPS_QA_TIMEOUT boss");exit(96);}
}

static void onframe(unsigned f){if(strstr(scenario,"boss"))bossframe(f);else cageframe(f);}static void setting(const char* section,const char* key,m64p_type type,const void* value){m64p_handle h;ConfigOpenSection(section,&h);ConfigSetParameter(h,key,type,value);}
static void integer(const char* section,const char* key,int value){setting(section,key,M64TYPE_INT,&value);}
static void boolean(const char* section,const char* key,int value){setting(section,key,M64TYPE_BOOL,&value);}
int main(int argc,char** argv){signal(SIGSEGV,crash);
 if(argc<3)return 2;scenario=argv[2];if(strstr(scenario,"-us")){savebase=0x8011a5d0;overlays=0x800e8530;}if(argc>3)limit=atoi(argv[3]);if(argc>4)memory_mb=atoi(argv[4]);setbuf(stdout,NULL);
 if(argc>5)savebase=strtoul(argv[5],NULL,0);if(argc>6)overlays=strtoul(argv[6],NULL,0);
 if(argc>7)snapshotfile=argv[7];
 char config[512],shots[512];snprintf(config,sizeof(config),"/workspace/bean-rider/config-%s",scenario);snprintf(shots,sizeof(shots),"/workspace/bean-rider/screens-%s",scenario);mkdir(config,0700);mkdir(shots,0700);
 void* sdl=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_GLOBAL);int(*sdlinit)(unsigned)=dlsym(sdl,"SDL_Init");sdlinit(0x20|0x200);
 int r=CoreStartup(0x020001,config,"/workspace/toolchain/root/usr/share/games/mupen64plus",NULL,debugcb,NULL,NULL);if(r)return r;
 integer("Video-GLideN64","EnableCopyColorToRDRAM",1);
 boolean("Video-GLideN64","EnableClipping",1);
 boolean("Video-GLideN64","EnableCustomSettings",0);
 setting("Core","SharedDataPath",M64TYPE_STRING,"/workspace/toolchain/root/usr/share/games/mupen64plus");
 setting("Core","ScreenshotPath",M64TYPE_STRING,shots);setting("Core","SaveStatePath",M64TYPE_STRING,config);setting("Core","SaveSRAMPath",M64TYPE_STRING,config);
 boolean("Core","DisableExtraMem",memory_mb==4);integer("Core","R4300Emulator",memory_mb==4?1:2);boolean("Core","OnScreenDisplay",0);integer("Video-General","ScreenWidth",640);integer("Video-General","ScreenHeight",480);boolean("Video-General","Fullscreen",0);boolean("Video-General","VerticalSync",0);
 FILE* file=fopen(argv[1],"rb");if(!file)return 3;fseek(file,0,SEEK_END);long n=ftell(file);rewind(file);void* rom=malloc(n);if(fread(rom,1,n,file)!=(size_t)n)return 4;fclose(file);r=CoreDoCommand(M64CMD_ROM_OPEN,n,rom);if(r)return r;
 fprintf(stderr,"Core paths: %s | %s | %s\n",ConfigGetUserDataPath(),ConfigGetUserCachePath(),ConfigGetUserConfigPath());
 m64p_rom_settings rs;memset(&rs,0,sizeof(rs));r=CoreDoCommand(M64CMD_ROM_GET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 rs.disableextramem=memory_mb==4;r=CoreDoCommand(M64CMD_ROM_SET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 printf("Requested memory: %d MiB; disableextramem=%d\n",memory_mb,rs.disableextramem);
 const char* paths[]={"/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-rsp-hle.so","/workspace/toolchain/RMG-060/glide-build/plugin/Release/mupen64plus-video-GLideN64.so","/workspace/kakariko-parking-v50/capture_audio.so","/workspace/wallace-cheer/record_input.so"};
 if(strstr(scenario,"mk2"))paths[1]="/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-video-glide64mk2.so";
 void* core=dlopen("libmupen64plus.so.2",RTLD_NOW|RTLD_GLOBAL);int order[]={1,2,3,0};
 for(int k=0;k<4;k++){int i=order[k];if(!paths[i])continue;void* plugin=dlopen(paths[i],RTLD_NOW|RTLD_LOCAL|RTLD_DEEPBIND);if(!plugin){puts(dlerror());return 5;}ptr_PluginStartup startup=dlsym(plugin,"PluginStartup");if((r=startup(core,NULL,debugcb)))return r;if((r=CoreAttachPlugin(i+1,plugin)))return r;if(i==2){audioSamples=dlsym(plugin,"CaptureAudioSamples");audioRate=dlsym(plugin,"CaptureAudioRate");}if(i==3){buttons=dlsym(plugin,"TestSetButtons");void(*setCapture)(void(*)(void))=dlsym(plugin,"TestSetRenderCapture");if(!setCapture)return 95;setCapture(capture_render);}}
 int speed=0;CoreDoCommand(M64CMD_CORE_STATE_SET,M64CORE_SPEED_LIMITER,&speed);CoreDoCommand(M64CMD_SET_FRAME_CALLBACK,0,onframe);signal(SIGALRM,alarmcb);alarm(15);r=CoreDoCommand(M64CMD_EXECUTE,0,NULL);
 if(video && pclose(video)!=0)return 96;printf("SCENARIO %s completed: %d\n",scenario,r);CoreDoCommand(M64CMD_ROM_CLOSE,0,NULL);CoreShutdown();return r;
}

from pathlib import Path
import re,sys
O=Path(__file__).resolve().parent.parent
version=sys.argv[1]if len(sys.argv)>1 else 'pal-1.0'
lines=['/* Room object lists audited for the two affected dungeons. Sizes come from', ' * the current object table at runtime, so no model size is hardcoded. */']
names=[]
for folder,name in [('ddan','Ddan'),('HAKAdanCH','Well')]:
 groups=sorted({tuple(re.findall(r'\bOBJECT_[A-Z0-9_]+\b',p.read_text()))for p in(O/f'extracted/{version}/assets/scenes/dungeons'/folder).glob('*ObjectList.inc.c')})
 for i,g in enumerate(groups):lines +=[f'static const s16 s{name}ObjectsV86_{i}[] = {{'+', '.join(g)+'};']
 lines +=[f'static const ObjectBudgetGroupV86 s{name}ObjectGroupsV86[] = {{']
 for i,g in enumerate(groups):lines +=[f'    {{ s{name}ObjectsV86_{i}, ARRAY_COUNT(s{name}ObjectsV86_{i}) }},']
 lines +=['};'];names.append((name,len(groups)))
header='''#ifndef OBJECT_ROOM_BUDGET_V86_H
#define OBJECT_ROOM_BUDGET_V86_H
typedef struct ObjectBudgetGroupV86 { const s16* ids; u32 count; } ObjectBudgetGroupV86;
'''+ '\n'.join(lines)+'''
static u32 Scene_ObjectBytesV86(s16 id) {
    return ALIGN16(gObjectTable[id].vromEnd - gObjectTable[id].vromStart);
}
static u32 Scene_DungeonObjectSpaceV86(PlayState* play, u32 original) {
    const ObjectBudgetGroupV86* groups;
    u32 count, i, j, size, maximum = 0;
    if (gSaveContext.gameMode != GAMEMODE_NORMAL || gSaveContext.sceneLayer > 3) return original;
    if (play->sceneId == SCENE_DODONGOS_CAVERN) {
        groups = sDdanObjectGroupsV86; count = ARRAY_COUNT(sDdanObjectGroupsV86);
    } else if (play->sceneId == SCENE_BOTTOM_OF_THE_WELL) {
        groups = sWellObjectGroupsV86; count = ARRAY_COUNT(sWellObjectGroupsV86);
    } else return original;
    for (i = 0; i < count; i++) {
        size = 0;
        for (j = 0; j < groups[i].count; j++) size += Scene_ObjectBytesV86(groups[i].ids[j]);
        if (size > maximum) maximum = size;
    }
    maximum += Scene_ObjectBytesV86(OBJECT_GAMEPLAY_KEEP) +
               Scene_ObjectBytesV86(OBJECT_GAMEPLAY_DANGEON_KEEP) +
               Scene_ObjectBytesV86(gLinkObjectIds[gSaveContext.save.linkAge]);
    /* Keep32KiB spare model space; return the unused reservation to actors. */
    maximum = (maximum + 0x8000 + 0xFFF) & ~0xFFF;
    return maximum < original ? maximum : original;
}
#endif
'''
target=O/'include/object_room_budget_v86.h'
if not target.exists() or target.read_text()!=header:target.write_text(header)


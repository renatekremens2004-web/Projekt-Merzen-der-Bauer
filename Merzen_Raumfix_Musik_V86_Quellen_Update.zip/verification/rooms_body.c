static void capture_render(void){}
static unsigned count_id(unsigned id){unsigned n=0;for(int c=0;c<12;c++)for(unsigned a=r32(play+0x1c34+c*8),i=0;a>=0x80000000&&a<0x80400000&&i<180;a=r32(a+0x124),i++)if(DebugMemRead16(a)==id&&r32(a+0x130))n++;return n;}
static void heap(void){unsigned free=0,big=0,used=0;for(unsigned a=r32(ARENA),i=0;a>=0x80000000&&a<0x80400000&&i<400;a=r32(a+8),i++){unsigned size=r32(a+4);if(DebugMemRead16(a+2)){free+=size;if(size>big)big=size;}else used+=size;}printf("HEAP free=%u largest=%u used=%u denied=%u/%u last=%x\n",free,big,used,DebugMemRead16(DENIED_O),DebugMemRead16(DENIED_I),DebugMemRead16(DENIED_L));}
static void onframe(unsigned f){
 static unsigned seen=0;unsigned v=0;int well=strstr(scenario,"well")!=NULL;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;

 if(DebugMemRead8(play+0x20d8+0xe304)&&f%15<2)v=0x80;
 if(!well&&(f==375||f==645||f==795))photo(1140,180,100,1140,30,-320);
 if(well){
  if(f>=380&&f<425)position(player,-310,-180.0f-(f-380)*14.0f,-540,0);
  if(f>=425&&f<450)position(player,-310,-720,-540,0);
  if(f==470)position(player,400,-720,-1200,0);
  if(f>=650&&f<695)position(player,-310,-720.0f+(f-650)*14.0f,-540,0);
  if(f>=695&&f<720)position(player,-310,-100,-540,0);
  if(f>=800&&f<845)position(player,-310,-180.0f-(f-800)*14.0f,-540,0);
  if(f>=845&&f<870)position(player,-310,-720,-540,0);
  if(f==890)position(player,400,-720,-1200,0);
 }else{
  if(f>=380&&f<425)position(player,930+(f-380)*10,0,-320,16384);
  if(f>=425&&f<450)position(player,1380,0,-320,16384);
  
  if(f>=650&&f<695)position(player,1370-(f-650)*10,0,-320,-16384);
  if(f>=695&&f<720)position(player,920,0,-320,-16384);
  if(f>=800&&f<845)position(player,930+(f-800)*10,0,-320,16384);
  if(f>=845&&f<870)position(player,1380,0,-320,16384);
  
 }
 if(f%30==0){printf("ROOMS f=%u well=%d room=%u prev=%d xyz=%.1f,%.1f,%.1f statues=%u switch=%x velma=%x organs=%x silver=%u\n",f,well,DebugMemRead8(play+0x11cbc),(signed char)DebugMemRead8(play+0x11cd0),rf(player+0x24),rf(player+0x28),rf(player+0x2c),count_id(0x54),target(0x12a,0x3620),target(0x173,0x3f88),target(0x173,0x3f99),count_id(0x117));heap();}
 if(f==580||f==980){
  if(well){need(target(0x173,0x3f88)&&target(0x173,0x3f99)&&count_id(0x117)>=5,"basement Velma, organs and silver-rupee actors all spawn after real transition");}
  else{need(count_id(0x54)>=2&&target(0x12a,0x3620),"blue switch and both Armos statues spawn after real transition");}
  seen++;
 }
 if(f>1050){bank();need(seen==2,"repeated room-entry coverage");puts("ROOM_TRANSITIONS_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(buttons)buttons(v);
}

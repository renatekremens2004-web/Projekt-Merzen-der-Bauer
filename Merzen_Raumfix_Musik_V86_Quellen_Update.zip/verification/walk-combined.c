static void capture_render(void){}
static unsigned countid(unsigned id){unsigned c=0;for(int cat=0;cat<12;cat++)for(unsigned p=r32(play+0x1c34+cat*8),n=0;p>=0x80000000&&p<0x80400000&&n<180;p=r32(p+0x124),n++)if(DebugMemRead16(p)==id&&r32(p+0x130))c++;return c;}
static void onframe(unsigned f){
 static unsigned first=0,help=0,gate=0;unsigned v=0;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 unsigned room=DebugMemRead8(play+0x11cbc),bird=target(0x72,0x7501),m=play+0x20d8,text=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),liz=0,visible=0;
 if(f==375)photo(1140,180,100,1140,30,-320);
 if(f>=380&&f<425)position(player,930+(f-380)*10,0,-320,16384);
 if(f>=425&&f<470)position(player,1380,0,-320,16384);
 if(f==470){need(countid(0x54)==2&&target(0x12a,0x3620),"both statues and blue switch loaded through room0 entrance");bank();}
 if(f>=480&&f<515){unsigned statue=actor(0x54);need(statue,"statue retained");position(statue,3564,40,-331,0);}
 if(f==520){need(r32(play+0x1d2c)&(1u<<(54-32)),"blue switch activated by statue pressure without changing flags");gate=1;printf("BLUE_SWITCH_OPENED f=%u\n",f);}
 if(f>=530&&f<750)position(player,1380+(f-530)*10, f>720?80:0,-320,16384);
 if(f>=750&&f<835)position(player,3560,100,-320.0f-(f-750)*10.0f,-32768);
 if(f==835)photo(3560,270,-1010,3560,140,-1290);
 if(f>=835&&(room!=3||rf(player+0x2c)>-1600)){v=0x20|0x40000000;if(f%20<2)v|=0x80;}
 if(f>530&&f<835&&f%20<2)v|=0x80;
 for(unsigned a=r32(play+0x1c34+5*8),n=0;a>=0x80000000&&a<0x80400000&&n<70;a=r32(a+0x124),n++)if(DebugMemRead16(a)==0x25&&r32(a+0x130)&&DebugMemRead16(a+0x3ec)==5){liz++;if(DebugMemRead8(a+0x3f4)==255)visible++;}
 if(text==0x7239&&mode)help=1;
 if(room==3&&bird&&liz==2&&!first)first=f;
 if(f%30==0){printf("COMBINED f=%u room=%u prev=%d xyz=%.1f %.1f %.1f bird=%x liz=%u visible=%u help=%u text=%x denied=%u/%u last=%x\n",f,room,(signed char)DebugMemRead8(play+0x11cd0),rf(player+0x24),rf(player+0x28),rf(player+0x2c),bird,liz,visible,help,text,DebugMemRead16(DENIED_OVERLAY),DebugMemRead16(DENIED_INSTANCE),DebugMemRead16(DENIED_LAST));}
 if(first&&f>first+170){bank();need(gate&&help&&visible==2,"native blue gate followed by cage, intro and both active Lizalfos");puts("COMBINED_DDAN_QA_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(buttons)buttons(v);if(f>2100){bank();need(0,"combined route timed out");}
}

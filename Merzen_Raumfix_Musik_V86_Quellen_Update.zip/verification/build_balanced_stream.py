from pathlib import Path
import numpy as np,json,struct,subprocess,concurrent.futures,shutil
W=Path('/workspace/room-audio-v86');T=Path('/tmp/malon-remix-v86');D=T/'encoded-balanced';D.mkdir(exist_ok=True);O=Path('/workspace/oot-burns-pal');A=W/'audio';A.mkdir(exist_ok=True)
rate=31995;raw=np.fromfile(T/'master-balanced.pcm',dtype='<i2').reshape(-1,2);assert len(raw)==315*rate
x=raw.astype(float);n=15*rate;x[-n:]*=np.cos(np.linspace(0,np.pi/2,n))[:,None];x[-1]=0;native=np.round(x).astype('<i2');(D/'master-5m15.pcm').write_bytes(native.tobytes())
collapse=native[round(25.25*rate):].astype(float);n=round(1.25*rate);collapse[:n]*=np.sin(np.linspace(0,np.pi/2,n))[:,None]**2;collapse[0]=0;collapse=np.round(collapse).astype('<i2')
def chunk(k,d):return k+struct.pack('<I',len(d))+d+(b'\0'if len(d)&1 else b'')
samples=[]
for tag,data in [('TITLE_L',native[:,0]),('TITLE_R',native[:,1]),('COLLAPSE_L',collapse[:,0]),('COLLAPSE_R',collapse[:,1])]:
 name='MalonV84_'+tag;wav=D/(name+'.wav');aifc=A/(name+'.aifc');N=len(data);fmt=struct.pack('<HHIIHH',1,1,32000,64000,2,16);inst=bytes([60,0,0,0,127,0,127,0]);smpl=struct.pack('<9I',0,0,31250,60,0,0,0,1,0)+struct.pack('<6I',0,0,0,N-1,0,0xFFFFFFFF);payload=b'WAVE'+chunk(b'fmt ',fmt)+chunk(b'fact',struct.pack('<I',N))+chunk(b'data',data.tobytes())+chunk(b'inst',inst)+chunk(b'smpl',smpl);wav.write_bytes(b'RIFF'+struct.pack('<I',len(payload))+payload);samples.append(dict(name=name,wav=str(wav),aifc=str(aifc),frames=N))
def encode(s):
 subprocess.run([str(O/'tools/audio/sampleconv/sampleconv'),'vadpcm',s['wav'],s['aifc']],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 for folder in ['assets','build/pal-1.0/assets']:
  p=O/folder/'audio/samples/SampleBank_0'/(s['name']+'.aifc')
  assert p.is_symlink() or not p.exists(),p
  if p.is_symlink():p.unlink()
  p.symlink_to(s['aifc'])
 p=O/'assets/audio/samples/SampleBank_0'/(s['name']+'.wav')
 if p.is_symlink():p.unlink()
 s['bytes']=Path(s['aifc']).stat().st_size
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(encode,samples))
report=dict(rate=rate,seconds=315,fade_start=300,fade_end=315,collapse_entry=25.25,collapse_fade_in=1.25,gain=1,source='native-stem balanced V86b, master gain already applied',peak=int(abs(native.astype('int32')).max()),samples=samples,shipping_audio_heap=0x38000,shipping_music_notes=2)
(W/'stream-assets.json').write_text(json.dumps(report,indent=2));print('BALANCED_STREAM_ENCODED',sum(s['bytes']for s in samples))

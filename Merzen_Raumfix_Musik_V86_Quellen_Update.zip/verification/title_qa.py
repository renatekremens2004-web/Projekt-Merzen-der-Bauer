from pathlib import Path
import os,sys,json,re,subprocess,struct
W=Path(__file__).resolve().parent;rom=sys.argv[1];mode=sys.argv[2];romfd=int(rom.rsplit('/',1)[1]);case=os.environ.get('V86_QA_CASE')or(W/'qa-case.txt').read_text().strip();sy=json.loads((W/f'symbols-{mode}.json').read_text())
if case=='publish':
 import runpy
 runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit(0)
base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text();old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text())
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
video='static unsigned pending=0,encoded=0; static void capture_render(void){} static void hold_frame_until(uint64_t n){}'
body=video+r'''
static void onframe(unsigned f){
 static unsigned first=0,oldscene=999,oldphase=999,oldpos=0,loops=0,scenes=0,sawMusic=0,sawIntro=0,sawOldTalk=0,freeframe=0,donevideo=0,talkdone=0,transformed=0;
 static uint64_t start=0;
 unsigned seq=AUDIO_CONTEXT+0x3530,id=DebugMemRead8(seq+4),enabled=(DebugMemRead8(seq)&0x80)!=0,gm=r32(savebase+0x135c),val=0;
 baseframe(f);findplay();
 if(strstr(scenario,"title-loop")){
  if(id==113&&enabled&&!first){first=f;start=audioSamples();printf("TITLE_BEGIN f=%u sample=%llu rate=%u\n",f,(unsigned long long)start,audioRate());}
  if(first){
   double seconds=(audioSamples()-start)/(double)audioRate();
   need(r32(AUDIO_CONTEXT+0x2894)==28,"original title28-note spec retained");
   need(DebugMemRead8(AUDIO_SPEC)==10,"native title spec retained");
   need(r32(0x80000318)==4194304,"native4MiB");
   if(gm==1){need(id==113&&enabled,"title music continues through attract demos");
    unsigned c0=r32(seq+0x38),c1=r32(seq+0x3c),l0=r32(c0+0x50),l1=r32(c1+0x50),n0=r32(l0+0x2c),n1=r32(l1+0x2c);
    if(n0&&n1&&n0<0x80400000&&n1<0x80400000){unsigned p0=r32(n0+0x18),p1=r32(n1+0x18);
     need(abs((int)p0-(int)p1)<=2,"left/right stream remains aligned");
     if(oldpos>1000000&&p0<oldpos){loops++;printf("TITLE_SAMPLE_LOOP t=%.6f previous=%u now=%u\n",seconds,oldpos,p0);}
     oldpos=p0;
    }
   }
   if(play&&player){unsigned sc=DebugMemRead16(play+0xa4);if(sc!=oldscene){printf("TITLE_SCENE f=%u t=%.2f scene=%x mode=%u\n",f,seconds,sc,gm);oldscene=sc;scenes++;}if(f%500==0)bank();}
   if(f%250==0)printf("TITLE_PROGRESS seconds=%.2f id=%u on=%u loops=%u mode=%u\n",seconds,id,enabled,loops,gm);
   pending=1;
   if(seconds>325){need(loops==1,"one native315-second sample restart");need(scenes>=2,"native attract scenes continue");printf("TITLE_LOOP_QA_PASSED sample=%llu loops=%u scenes=%u\n",(unsigned long long)audioSamples(),loops,scenes);hold_frame_until(audioSamples());CoreDoCommand(M64CMD_STOP,0,NULL);}
  }
 }else if(strstr(scenario,"menu")){
  if(first==0&&id==113&&enabled)first=f;
  if(first&&f>first+300&&f<first+400&&f%40<2)val=0x10;
  if(gm==2&&first){static unsigned menu=0;if(!menu)menu=f;if(f>menu+160){need(!(id==113&&enabled),"title score stops at file select");puts("TITLE_MENU_QA_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}}
 }else{
  if(!play||!player)return;
  unsigned boss=actor(0x17a),tri=target(0x173,0x3f78),msg=play+0x20d8,text=DebugMemRead16(msg+0xe2f8),mm=DebugMemRead8(msg+0xe304);
  if(!first && DebugMemRead16(play+0xa4)==0x4f && id==112 && enabled) {
   first=f;start=audioSamples();printf("COLLAPSE_BEGIN f=%u sample=%llu rate=%u\n",f,(unsigned long long)start,audioRate());
  }
  if(first&&!freeframe)pending=1;
  if(!boss||!tri){if(first)need(id==112&&enabled,"music persists through scripted castle collapse and native room transition");return;}
  unsigned phase=DebugMemRead16(boss+0x38c),timer=r32(boss+0x388),shown=DebugMemRead16(tri+0x18);
  if(!first&&phase==1){first=f;start=audioSamples();printf("COLLAPSE_BEGIN f=%u sample=%llu rate=%u\n",f,(unsigned long long)start,audioRate());}
  if(!first)return;
  if(!freeframe && id==112 && enabled) {
   unsigned c=r32(seq+0x38),layer=r32(c+0x50),note=r32(layer+0x2c),p=r32(note+0x18);
   if(oldpos>0)need(p>=oldpos,"music not restarted between collapse scenes");oldpos=p;
  }
  if(phase!=oldphase){printf("COLLAPSE_PHASE f=%u phase=%u timer=%u shown=%u music=%u on=%u text=%x mode=%u cs=%u\n",f,phase,timer,shown,id,enabled,text,mm,DebugMemRead8(player+0x434));oldphase=phase;}
  if(!freeframe){
   pending=1;
   if(phase<=4)need(!shown,"triangle invisible before its own camera shot");
   if(id==112&&enabled)sawMusic=1;
   if(sawMusic&&phase!=5)need(id==112&&enabled,"collapse music stays on until control returns");
   if(phase==6&&timer>0)need(shown==1,"triangle revealed in its own shot");
   if(text==0x723c&&mm)sawIntro=1;
   if(phase==6&&(timer==18||timer==40))CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
   if(mm&&f%25<2)val=0x80;
   if(phase==5){freeframe=f;need(sawMusic&&sawIntro&&shown,"music, presentation and reveal completed");printf("CONTROL_RETURNED f=%u sample=%llu\n",f,(unsigned long long)audioSamples());}
  }else{
   if(f<=freeframe+20)pending=1;
   if(f>freeframe+5){need(!(id==112&&enabled),"score cuts off with returned player control");need(shown==1,"triangle remains visible after cinematic");}
   if(f==freeframe+21){hold_frame_until(audioSamples());donevideo=1;printf("VIDEO_END sample=%llu frames=%u\n",(unsigned long long)audioSamples(),encoded);}
   if(f==freeframe+30)position(player,rf(tri+0x24)+70,1086,rf(tri+0x2c)+45,-22000);
   if(!sawOldTalk&&f>freeframe+35&&f%25<2)val=0x80;
   if(text==0x608a&&mm)sawOldTalk=1;
   if(sawOldTalk&&mm&&f%25<2)val=0x80;
   if(sawOldTalk&&!mm&&!talkdone){talkdone=f;printf("FOLLOWUP_TALK_PASSED f=%u phase=%u\n",f,phase);bank();}
   if(talkdone&&f==talkdone+30)position(player,-20,1086,-166,0);
   if(talkdone&&phase>=10)transformed=1;
   if(talkdone&&phase>=10&&mm&&f%25<2)val=0x80;
   if(transformed&&phase>=14&&phase<=28)need(shown==1,"triangle retained in transformation");
   if(transformed&&phase==0&&f>talkdone+200){bank();puts("COLLAPSE_QA_PASSED intro camera, followup talk and original transformation");CoreDoCommand(M64CMD_STOP,0,NULL);}
  }
  if(f%250==0){bank();printf("COLLAPSE_PROGRESS f=%u phase=%u text=%x msg=%u id=%u enabled=%u\n",f,phase,text,mm,id,enabled);}
 }
 if(buttons)buttons(val);
 if(f>=(unsigned)limit){puts("QA_FRAME_TIMEOUT");CoreDoCommand(M64CMD_STOP,0,NULL);exit(96);}
}
'''
body=body.replace('AUDIO_CONTEXT',hex(sy['gAudioCtx'])).replace('AUDIO_SPEC',hex(sy['gAudioSpecId']))
s=base[:a]+body+base[b:]
if case in ['title-loop','menu']:s=s.replace('/workspace/toolchain/RMG-060/glide-build/plugin/Release/mupen64plus-video-GLideN64.so','/tmp/malon-remix-v86/no_video.so')
runner=W/f'runner-{mode}-{case}';c=runner.with_suffix('.c');c.write_text(s);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
fixture=None
if case=='collapse':
 q=bytearray(Path('/workspace/wawario-bros/triangle.save').read_bytes());struct.pack_into('>III',q,0,0x517,0,0xffef);struct.pack_into('>i',q,0x1364,0);q[0x1409]=1;fixture=W/'collapse.save';fixture.write_bytes(q)
pcm=Path('/tmp')/f'v86-{mode}-{case}.pcm';vid=Path('/tmp')/f'v86-{mode}-{case}-silent.mp4';env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null');args=[str(runner),rom,'v84-'+mode+'-'+case+'-direct','8000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable'])]
if fixture:args.append(str(fixture))
with(W/f'{mode}-{case}.log').open('w')as log:r=subprocess.run(args,pass_fds=(romfd,),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1300)
assert r.returncode==0,(mode,case,r.returncode,(W/f'{mode}-{case}.log').read_text()[-1500:]);print('QA_FINISHED',mode,case,flush=True)

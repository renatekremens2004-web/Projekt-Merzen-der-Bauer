from pathlib import Path
import shutil
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');src=(W/'adjust_object_space.py').read_text();a=src.index("lines=['/* Room object lists");b=src.index("s=q.read_text()",a);generator=src[a:b].replace("(W/'object-groups.json').write_text(json.dumps(names));print('MEASURED_OBJECT_SPACE_RESERVATION_INSTALLED',names)",'')
generator=generator.replace("(O/'include/object_room_budget_v86.h').write_text(header)","target=O/'include/object_room_budget_v86.h'\nif not target.exists() or target.read_text()!=header:target.write_text(header)\n")
text="from pathlib import Path\nimport re,sys\nO=Path(__file__).resolve().parent.parent\nversion=sys.argv[1]if len(sys.argv)>1 else 'pal-1.0'\n"+generator.replace("extracted/pal-1.0/", "extracted/"+"'+version+'"+"/")
# Keep a normal f-string path expression for the scene directory.
text=text.replace("O/'extracted/'+version+'/assets/scenes/dungeons'/folder","O/f'extracted/{version}/assets/scenes/dungeons'/folder")
(O/'tools/build_object_room_budget_v86.py').write_text(text)
p=O/'Makefile';q=W/'original/Makefile'
if not q.exists():q.parent.mkdir(exist_ok=True);shutil.copy2(p,q)
s=q.read_text();s+='''\n# Recompute the audited room-model reservation whenever dungeon object lists change.\nROOM_BUDGET_INPUTS_V86 := $(wildcard extracted/$(VERSION)/assets/scenes/dungeons/ddan/*ObjectList.inc.c) $(wildcard extracted/$(VERSION)/assets/scenes/dungeons/HAKAdanCH/*ObjectList.inc.c)\ninclude/object_room_budget_v86.h: tools/build_object_room_budget_v86.py $(ROOM_BUDGET_INPUTS_V86)\n\t$(PYTHON) tools/build_object_room_budget_v86.py $(VERSION)\n''';p.write_text(s)
rel='src/code/z_actor.c';p=O/rel;q=W/'original'/rel;q.parent.mkdir(parents=True,exist_ok=True)
if not q.exists():shutil.copy2(p,q)
s=q.read_text();a='if (play->sceneId != SCENE_DODONGOS_CAVERN || play->roomCtx.curRoom.num != sPiepsPendingRoomV85) {';b='if (play->sceneId != SCENE_DODONGOS_CAVERN ||\n            (play->roomCtx.curRoom.num != sPiepsPendingRoomV85 &&\n             play->roomCtx.prevRoom.num != sPiepsPendingRoomV85)) {';assert a in s;s=s.replace(a,b);p.write_text(s)
print('BUILD_DEPENDENCY_AND_PENDING_ROOM_SWAP_FIX_READY')

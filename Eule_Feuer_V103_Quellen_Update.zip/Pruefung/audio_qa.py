from pathlib import Path
import os,sys,json,subprocess,struct,re
W=Path(__file__).resolve().parent;rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1]);logpath=W/f'qa-{mode}-fire-music.log'
if logpath.exists()and'FIRE_ORIGINAL_NATIVE_PASSED'in logpath.read_text():sys.exit()
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
video=Path('/workspace/pieps-v79/video_capture.c').read_text()if mode=='normal'else'static unsigned pending=0;static void capture_render(void){}\n'
body=r'''
static unsigned musicseen=0,chants=0,lastchants=0;
static void onframe(unsigned f){
 baseframe(f);if(f<380)return;findplay();if(!play||!player)return;
 unsigned scene=DebugMemRead16(play+0xa4),seq=AUDIO+0x3530,id=DebugMemRead8(seq+4),on=DebugMemRead8(seq)&128,font=DebugMemRead8(seq+5);
 need(scene==4,"native Fire Temple scene loaded");
 if(f>420&&id==42&&on){
  musicseen=1;need(font==10,"original sequence uses restored soundfont10");pending=1;
  unsigned notes=r32(AUDIO+0x352c),num=r32(AUDIO+0x2894);need(num>0&&num<=64,"native audio note budget valid");
  for(unsigned k=0;k<num;k++){
   unsigned n=notes+k*0xe0;if(!(DebugMemRead8(n+0xc0)&128)||DebugMemRead8(n+0x33)!=10)continue;
   unsigned t=r32(n+0xd0);if(t<0x80000000||t>=0x80400000)continue;
   unsigned s=r32(t);if(s<0x80000000||s>=0x80400000)continue;
   unsigned size=r32(s)&0xffffff;if(size==0x8caa)chants|=1;if(size==0x6a90)chants|=2;if(size==0xdc6e)chants|=4;
  }
  if(chants!=lastchants){printf("ORIGINAL_CHANT_ACTIVE f=%u mask=%u\n",f,chants);lastchants=chants;}
 }
 if(f<600)photo(330,240,1180,0,50,450);
 if(f%400==0)printf("FIRE_MUSIC f=%u seq=%u font=%u enabled=%u chants=%u\n",f,id,font,on,chants);
 if(f==600)bank();
 if(f>=END_FRAME){need(musicseen,"original fire theme plays");need(chants&6,"original vocal sample actually synthesized in game");bank();puts("FIRE_ORIGINAL_NATIVE_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(buttons)buttons(0);
}
'''.replace('AUDIO',hex(sy['gAudioCtx'])).replace('END_FRAME',str(3000 if mode=='normal'else 2200))
s=base[:a]+video+body+base[b:]
if mode=='normal':s=s.replace('if(video && pclose(video)!=0)return 96;','if(video){hold_frame_until(audioSamples());printf("VIDEO_CAPTURE first=%llu last=%llu rate=%u frames=%u\\n",(unsigned long long)firstAudio,(unsigned long long)lastAudio,audioRate(),encoded);}if(video && pclose(video)!=0)return 96;')
c=W/f'probe-{mode}-fire-music.c';c.write_text(s);exe=W/f'probe-{mode}-fire-music';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0x165,0,0);struct.pack_into('>i',q,0x1364,0);q[0x1409]=1;save=W/'fire-music.save';save.write_bytes(q)
pcm=W/f'{mode}-fire-music.pcm';vid=W/f'{mode}-fire-music-silent.mp4'
with logpath.open('w')as log:r=subprocess.run([str(exe),rom,f'fire-original-v103-direct-{mode}','3200','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH=str(pcm),PIEPS_VIDEO_PATH=str(vid)),stdout=log,stderr=subprocess.STDOUT,timeout=500)
log=logpath.read_text();assert r.returncode==0 and'FIRE_ORIGINAL_NATIVE_PASSED'in log,(r.returncode,log[-2500:])
if mode=='normal':
 first,last,rate,frames=map(int,re.search(r'VIDEO_CAPTURE first=(\d+) last=(\d+) rate=(\d+) frames=(\d+)',log).groups());out=W/'Feuertempel_Original_US10_Gesaenge_V103.mp4'
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(vid),'-f','s16le','-ar',str(rate),'-ac','2','-skip_initial_bytes',str(first*4),'-i',str(pcm),'-map','0:v','-map','1:a','-t',str(frames/50),'-c:v','copy','-c:a','aac','-b:a','192k','-movflags','+faststart',str(out)],check=True)
 (W/'fire-video-verification.json').write_text(json.dumps(dict(first=first,last=last,rate=rate,frames=frames,seconds=frames/50,native_audio=True),indent=2))
print('FIRE_ORIGINAL_NATIVE_QA_PASSED',mode,flush=True)

from pathlib import Path
import re,json,struct,subprocess,shutil
W=Path('/workspace/mystery-inc');O=Path('/workspace/oot-burns-pal')
def symbols(p):return {n:int(a,16)for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\s*$',p.read_text(),re.M)}
a=symbols(W/'baseline/build/pal-1.0/oot-pal-1.0.map');b=symbols(O/'build/pal-1.0/oot-pal-1.0.map');(W/'symbols.json').write_text(json.dumps(b));s=Path('/workspace/naboo/runner.c').read_text().replace('obj<0x195','obj<0x19a')
for n in ['gGameStateOverlayTable','sZeldaArena','gObjectTable']:s=re.sub('0x'+format(a[n],'x')+r'\b',hex(b[n]),s)
extra=r'''
  if(f%50==0)for(int type=7;type<=11;type++){
    uint32_t a=actor_type(0x173,type);
    if(a)printf("MYSTERY f=%u type=%d pos=(%.1f %.1f %.1f) floor=%.1f talk=%04x draw=%08x flags=%08x\n",f,type,rf(a+0x24),rf(a+0x28),rf(a+0x2c),rf(a+0x80),DebugMemRead16(a+0x10e),r32(a+0x134),r32(a+4));
  }
'''
s=s.replace('  if(f%50==0){\n   uint32_t fan=',extra+'  if(f%50==0){\n   uint32_t fan=');s=s.replace('  if(f%50==0){\n   uint32_t fan=',r'''  if(f%50==0)printf("MACHINE f=%u actor=%08x song=%x lesson=%x age=%u\n",f,actor_type(0x173,12),r32(savebase+0xa4)&(1<<17),DebugMemRead16(savebase+0xee0)&32,r32(savebase+4));
  if(f%50==0){
   uint32_t fan=''');(W/'runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
base=Path('/workspace/pepsiman-water/man-30.save').read_bytes()
cases=[('shaggy',0,(-530,-12,-1450),16384,1),('velma',1,(575,-720,-1220),-13500,1),('daphne',2,(-1740,0,-820),-32768,1),('scooby',6,(-220,0,-935),-32768,1),('fred',5,(380,0,-970),-16384,1),('adult-still',0,(-530,-12,-1450),16384,0)]
for name,room,pos,yaw,age in cases:
 b=bytearray(base);struct.pack_into('>III',b,0,0x98,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,0x98,room);b[0x1409]=1;struct.pack_into('>HH',b,0x2e,160,160);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);b[0x34]=1;struct.pack_into('>H',b,0x0c,0x8000)
 off=0xd4+8*0x1c;b[off:off+0x1c]=bytes(0x1c);struct.pack_into('>H',b,0x70,0x1111 if age else 0x1122);b[0x4a:0x54]=b[0x68:0x72];(W/(name+'.save')).write_bytes(b)
shutil.copyfile('/workspace/kenny/worst-still.save',W/'worst-still.save')
b=bytearray(Path('/workspace/kenny/dead.save').read_bytes());struct.pack_into('>fffh',b,0x1368,2990.,-543.,-1100.,0);(W/'dead.save').write_bytes(b)
s=Path('/workspace/naboo/run.py').read_text().replace('/workspace/naboo','/workspace/mystery-inc').replace("case='naboo-'","case='mystery-'");(W/'run.py').write_text(s)

# Native adult Guru-Guru sets quest bit17 and eventChkInf[6] bit5 together.
for name,age,song,lesson,night in [('van-before-still',1,False,False,False),('van-before-night-still',1,False,False,True),('van-after-still',1,True,True,False),('van-night-still',1,True,True,True),('van-adult-still',0,True,True,False)]:
 b=bytearray(base);struct.pack_into('>III',b,0,0xdb,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,-2440.,138.,1020.,15000,0xdff,0xdb,0);b[0x1409]=1;struct.pack_into('>HH',b,0x2e,160,160);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);b[0x34]=1;struct.pack_into('>H',b,0x0c,0 if night else 0x8000);struct.pack_into('>H',b,0x70,0x1111 if age else 0x1122);b[0x4a:0x54]=b[0x68:0x72]
 q=struct.unpack_from('>I',b,0xa4)[0];struct.pack_into('>I',b,0xa4,(q|(1<<17))if song else(q&~(1<<17)));e=struct.unpack_from('>H',b,0xee0)[0];struct.pack_into('>H',b,0xee0,e|32 if lesson else e&~32);(W/(name+'.save')).write_bytes(b)

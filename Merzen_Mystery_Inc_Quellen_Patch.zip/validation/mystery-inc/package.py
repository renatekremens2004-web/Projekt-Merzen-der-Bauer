from pathlib import Path
import json,hashlib,re,shutil,zipfile
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/mystery-inc');A=Path('/workspace/artifacts');D=Path('/workspace/bean-download-delivery')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v=json.loads((O/'build/pal-1.0/mystery-verification.json').read_text());h=v['rom_sha256'];assert h==sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64')==json.loads((W/'patch-verification.json').read_text())['target_sha256']
V=R/'validation/mystery-inc';P=R/'previews/mystery-inc';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True);logs={}
for topic in ['shaggy','velma','daphne','scooby','fred','dead','worst-still','adult-still','van-before-still','van-before-night-still','van-after-still','van-night-still','van-adult-still']:
 run='delivered';p=W/f'mystery-{topic}-{run}-direct-clip-on.log';s=p.read_text();assert h in s and 'completed: 0'in s and 'RAM=4194304'in s,p
 assert not any(x in s for x in ['OVERFLOW','GFX_POOL_CORRUPT','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 assert all(int(n)==0 for n in re.findall(r'HEAP f=\d+ failures=(\d+)',s)),p
 logs[topic]=s;shutil.copyfile(p,V/p.name)
for topic,ident in [('shaggy','71ba'),('velma','71bb'),('daphne','71bc'),('scooby','71bd'),('fred','71be'),('dead','71b9')]:assert f'id={ident}'in logs[topic] and f'id={ident}'in logs[topic]and re.search(rf'TEXT .*id={ident} .*mode=35',logs[topic]),topic
assert 'MYSTERY f='not in logs['adult-still']
assert 'deadFloor=-543.0'in logs['dead']
for topic in ['van-before-still','van-before-night-still','van-adult-still']:assert re.search(r'MACHINE f=200 actor=00000000',logs[topic]),topic
for topic in ['van-after-still','van-night-still']:assert re.search(r'MACHINE f=200 actor=(?!00000000)[0-9a-f]+ song=20000 lesson=[0-9a-f]+ age=1',logs[topic]),topic
heap=min(map(int,re.findall(r'largest=(\d+)','\n'.join(logs.values()))));bank=min(map(int,re.findall(r'OBJECT_BANK[^\n]*remaining=(\d+)','\n'.join(logs.values()))));assert heap>=16000
runtime=dict(rom_sha256=h,actual_ram_bytes=4194304,cases=list(logs),native_allocation_failures=0,minimum_largest_free_arena_bytes=heap,minimum_object_bank_free_bytes=bank,all_five_conversations_reached_final_manual_page=True,kenny_on_native_floor=-543.0,adult_mystery_guests_absent=True)
(W/'runtime-verification.json').write_text(json.dumps(runtime,indent=2)+'\n')
for n in ['prepare_runtime.py','runner.c','run.py','object_budget.py','object-budget.json','runtime-verification.json','verification.log','models.json','check_patch.js','patch-verification.json','package.py','selected-images.json']:shutil.copyfile(W/n,V/n)
shutil.copyfile(O/'build/pal-1.0/mystery-verification.json',V/'mystery-verification.json')
images=json.loads((W/'selected-images.json').read_text());photos=[]
for topic,indices in images.items():
 run='delivered';root=Path('/workspace/bean-rider')/f'screens-mystery-{topic}-{run}-direct-clip-on'
 for n,idx in enumerate(indices):
  source=root/f'the_legend_of_zelda-{idx:03d}.png';name=topic.title()+('_Dialog'if n else'_Ingame')+'.png';shutil.copyfile(source,P/name);photos.append(dict(file=name,source=str(source),rom_sha256=h,unaltered_emulator_image=True))
(P/'Aufnahmen.json').write_text(json.dumps(photos,indent=2)+'\n')
placements=[dict(name=k,room=r,position=p,height=ht,triangles=v['models'][k]['triangles'])for k,r,p,ht in [('shaggy',0,[-450,-12,-1450],94),('velma',1,[500,-720,-1200],76),('daphne',2,[-1740,0,-890],86),('scooby',6,[-220,0,-990],62),('fred',5,[300,0,-970],92)]]
(W/'placements.json').write_text(json.dumps(placements,indent=2)+'\n');shutil.copyfile(W/'placements.json',V/'placements.json')
dialogues=json.loads((R/'story/mystery_inc_de.json').read_text());text='\n\n'.join('**'+k+'**\n\n'+'\n\n'.join(e['pages'])for k,e in dialogues['messages'].items())
doc=f'''# Mystery Inc. im Brunnen und sichtbarer Kenny

Kumulativer Gesamtpatch auf unveränderte Europa/PAL 1.0. Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`, Ziel-SHA256 `{h}`. Alle bisherigen Änderungen einschließlich Naboo-Starfighter und bedingter Mystery Machine enthalten. BPS mit RomPatcher.js anwenden, normale Spielstände statt alter Emulator-Savestates laden. Deutsche Sprachfassung.

## Figuren und Standorte

Die fünf vom Nutzer gelieferten N64-Modelle aus Scooby-Doo: Classic Creep Capers bleiben in originaler Dreieckanzahl und ihren natürlichen Proportionen erhalten. Shaggy 414, Velma 342, Daphne 340, Scooby 358, Fred 349; zusammen 1.803 Dreiecke. Die bereits entspannten Originalposen bleiben erhalten. Kopf und Arme bewegen sich leicht, Scooby bewegt Kopf und Schwanz; vier eigene starre Transformationsgruppen, ausschließlich kleine Rotationen ohne Skalierungsanimation oder fremdes Skelett. Beim Sprechen wenden sich die Figuren sanft Link zu und gestikulieren etwas stärker. Kein Laufen vorgesehen. Native Beleuchtung, Nebel, Tiefentest und kleine Bodenschatten.

Jede Figur steht in einem anderen Raum. Shaggy im blutigen Nordgang von Raum 0, abseits des Einstiegskriechgangs; Velma im Keller Raum 1; Daphne am freien Ostrand des Sargraums 2; Fred auf dem festen vorderen Rand des Fallengrubenraums 5; Scooby am vorderen rechten Rand von Raum 6. Positionen und gleichmäßige Größen stehen in validation/mystery-inc/placements.json. Figuren nur als Kind in deutscher Sprache aktiv. Jeder Auftritt hat eine eigene nur im jeweiligen Raum geladene Objektdatei; beim Übergang können die beiden beteiligten Raumobjekte gleichzeitig geladen sein. Die ganze Gang wird nicht gemeinsam vorgehalten. Kollisionszylinder 12 Einheiten Radius, kein Kampf, keine Quest-Funktionen oder Besitzbedingungen.

Kenny liegt weiterhin nach Erhalt der Gleitstiefel im Sensen-/Silberrubinraum 6 des Schattentempels, jetzt gut sichtbar auf der Eingangsseite bei **2990/−542/−1020**, um 90 Grad gedreht. Tatsächlicher Boden −543, Körperbasis +1. Kein neuer Objekt-Slot im Schattentempel. Besitzbedingung, tote/lebende Variante und Navi-Kommentare bleiben unverändert. Die Sensenbahn, Rubine, Truhen, Türen, Raumverbindungen und ursprünglichen Gegner bleiben bestehen.

## Mystery Machine

Das gelieferte N64-Fahrzeug behält seine 456 Dreiecke und Texturen. Natürliche Proportionen: 150 Spieleinheiten lang, 64,1 breit, 95,66 hoch. Geparkt bei −2300/138/1130, parallel zum Zugang auf dem ebenen Randstreifen. Die vier Radpositionen liegen auf nativem Boden bei Y=138. Wario, Wache und der Durchgang bleiben frei. Reines statisches Dekoobjekt ohne Ansprache, Körper-/Gegnerkollision oder zusätzliche Objekt-ID. Daten im vorhandenen Kakariko-Raumsegment; der größere Raumpuffer wird mit 4 MiB geprüft.

Nur die beiden Kind-Actorlisten (Tag/Nacht) enthalten den Wagen. Zusätzlich fordert die Instanz LINK_IS_CHILD und QUEST_SONG_STORMS. Diesen dauerhaften Liedbesitz setzt Guru-Guru beim erfolgreichen Erlernen der Hymne des Sturms als Erwachsener. Das vorübergehende Windmühlenmerkmal EVENTCHKINF_65 wird nicht verwendet, da es beim Betreten von Kakariko zurückgesetzt wird. Keine neue Quest-/Zeitreisefunktion. Beim ersten Besuch unsichtbar, nach dem Lernen und Zurückreisen als Kind tags wie nachts sichtbar, als Erwachsener unsichtbar.

## Dialoge

Neue private IDs 71BA–71BE, normales Ansprechen und manueller A-Seitenwechsel, keine festen Lesezeiten. Alle bisherigen Dialoge in allen drei PAL-Sprachen als Quelle und kompiliert bytegleich.

{text}

## Prüfungen

Dreizehn gezielte Emulatorproben mit echten 4 MiB: alle fünf Auftritte mit natürlicher Ansprache bis zur letzten Textseite, Kenny am neuen Standort samt Navi-Kommentar, speicherkritischster Schattentempelraum 9 und Abwesenheit der Gang als Erwachsener; zusätzlich fünf Bedingungen der Mystery Machine (Kind vorher tags/nachts, Kind nachher tags/nachts, Erwachsener nachher). Für die Zustandsproben wird nur der normale Liedbesitz im Testspielstand gesetzt; die native Lied-Lernfunktion bleibt unverändert. Keine fehlgeschlagenen Speicherbelegungen, Grafikpufferüberläufe oder beschädigten GfxPool-Marken. Mindestreserve: größte freie zusammenhängende Arena-Fläche {heap:,} Byte; Objektpuffer {bank:,} Byte. Statischer Audit sämtlicher Brunnen- und Schattentempel-Raumlisten für beide Link-Alter, einschließlich Keep-/Link-Modellen und maximal 19 Slots. Der größte Objektbedarf bleibt Schattentempelraum 9 mit 969.840 von 1.019.904 Byte; der native Allokator bleibt unverändert. Brunnenraum 0 verwendet alle 19 Slots, überschreitet sie aber nicht. Keine neuen Modelle in Raum 4/Dead-Hand-Kampf. Kein vollständiger Durchlauf oder echter Hardwaretest.

1.517 komprimierte Segmente gegen den unkomprimierten Build und CIC-6105-Prüfsumme geprüft; 3.664 Kernsymbole unverändert bzw. ausschließlich echte Linker-Relokationen. Bestehende ElfMsg2-Sonderfunktionen unverändert, vier neue Gang-Funktionen, fünf auf Kakariko begrenzte Wagen-Helfer plus deren streng eingegrenzte Init/Update/Destroy-Verzweigungen. Fünf neue Objekt-IDs am Ende der Tabelle, keine Verschiebung bestehender IDs. Bestehende Gegner- und Spielerphysik unverändert. Alle 1.042 eigenen Texte passen in die nativen Textpuffer, die Folge-DMA-Zeiger aller neuen Texte sind für alle PAL-Sprachen gültig. BPS mit RomPatcher.js und aktiver Quellvalidierung angewandt: bytegleich zur geprüften ROM.

**Baufolge:** `tools/build_mystery_machine.py` als letzten Builder nach `build_mystery_inc.py`. Beispiel für die Gang: `python3 tools/build_mystery_inc.py /pfad/zur/oot-decomp` nach `build_naboo.py` (dieser nach `build_kenny.py`). Anschließend regulärer PAL-1.0-Bau und Kompression. Vorbereitete JSONs unter tools und Texturen unter models reichen für den normalen Bau. Optionaler Original-OBJ-Export: `python3 tools/export_mystery_inc.py WORK`, Nutzerarchive unter WORK/input/shaggy, velma, daphne, scooby, fred entpacken. Ausgangsdateien für die Builder unter tools/originals/mystery-inc im Paket enthalten. Der zusätzliche Wagen-Builder benötigt außerdem tools/originals/mystery-machine, ebenfalls enthalten. Quellenpaket enthält keine ROMs, Saves, Savestates, RAM-Abzüge oder ausführbare Programme. Bilder sind unveränderte Emulatoraufnahmen der geprüften Ziel-ROM.
'''
(R/'TESTING_MYSTERY_INC.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Mystery_Inc.bps';shutil.copyfile(patch,R/'patches'/patch.name);heading='# Mystery Inc. im Brunnen'
p=R/'README.md';previous=p.read_text();previous=previous.split('\n# ',1)[1]if previous.startswith(heading)and'\n# 'in previous else None;previous='# '+previous if previous is not None else p.read_text();p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Prüfung und Dialoge](TESTING_MYSTERY_INC.md) · [Bilder](previews/mystery-inc/)\n\nFünf getrennte Scooby-Doo-Auftritte im Brunnen; toter Kenny sichtbarer im Schattentempel; Mystery Machine erst nach der erwachsenen Hymne-des-Sturms-Lektion und ausschließlich als Kind. Alle bisherigen Änderungen enthalten. Letzter Builder build_mystery_machine.py nach build_mystery_inc.py; dieser nach build_naboo.py.\n\n'+previous)
archive=A/'Merzen_Mystery_Inc_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in['water-comic-heroes','ben-ice','jabba','bttf','kenny','xwing','mystery-inc','mystery-machine']and(p.suffix in['.c','.h']or rel.parts[-2:]==('spec','spec'))
  if not p.is_file()or(any(q in exclude for q in rel.parts)and not original)or(p.suffix.lower()not in suffixes and not original):continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='mystery-inc':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.o','.so','.st','.exe','.mp4','.glb'}for n in z.namelist());assert 'tools/originals/mystery-inc/spec/spec'in z.namelist()
instruction=A/'Anleitung_Mystery_Inc.txt';instruction.write_text('Kumulativer Gesamtpatch: Mystery Inc. im Brunnen und sichtbarer toter Kenny im Schattentempel. Alle bisherigen Änderungen enthalten, auch Naboo-Starfighter. Mystery Machine am Kakariko-Eingang: nur als Kind nach Erlernen der Hymne des Sturms als Erwachsener, tags und nachts.\n\nBPS mit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände laden; alte Emulator-Savestates vermeiden. Deutsche Sprachfassung.\n')
for p in [patch,archive,instruction]:shutil.copyfile(p,D/p.name)
G=D/'Mystery_Inc_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
files=[D/p.name for p in[patch,archive,instruction]];sums=D/'SHA256SUMS_Mystery_Inc.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files));files.append(sums)
p=D/'README.md';previous=p.read_text();previous=previous.split('\n# ',1)[1]if previous.startswith(heading)and'\n# 'in previous else None;previous='# '+previous if previous is not None else p.read_text();p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Bilder, Dialoge und Prüfung](Mystery_Inc_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nDie ganze Mystery-Inc.-Gang auf fünf Räume verteilt, entspannte eigene Posen und kleine Bewegungen; Kenny sichtbarer im Schattentempel; Mystery Machine erst nach der erwachsenen Hymne-des-Sturms-Lektion und ausschließlich als Kind. Alle bisherigen Änderungen enthalten. Auf unveränderte Vanilla PAL 1.0 anwenden. Dreizehn gezielte Proben mit 4 MiB, kein vollständiger Durchlauf.\n\n'+previous)
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=h,files=[p.name for p in files],runtime=runtime),indent=2)+'\n');print('Packaged Mystery Inc.',h,'source bytes',archive.stat().st_size)

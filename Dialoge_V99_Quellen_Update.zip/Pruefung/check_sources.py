from pathlib import Path
import sys,json,hashlib,subprocess
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path(__file__).resolve().parent
sys.path.insert(0,str(R/'tools'));from build_story import messages,controls,Layout
m=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());bodies={};pagecount=0
batches=[Path('/workspace/kokiri-dialogue-v99'),Path('/workspace/kokiri-dialogue-v99/batch2'),Path('/workspace/city-dialogue-v99')]
for batch in batches:
 bodies.update(json.loads((batch/'bodies.json').read_text()))
 report=json.loads((batch/'pages.json').read_text())
 for i,r in report.items():
  for ls in r['lines']:assert len(ls)<=4,(i,ls)
  pagecount+=len(r['lines'])
for i,b in bodies.items():assert m[i]['parts'][2][2]==b,('body mismatch',i)
# Check untouched German slots and all pre-existing other-language slots vs before first batch.
old=messages((batches[0]/'message_data.before.h').read_text())
for i,msg in old.items():
 for lang in [0,1,3]:assert msg['parts'][lang][2]==m[i]['parts'][lang][2],('language changed',i,lang)
 if i not in bodies:assert msg['parts'][2][2]==m[i]['parts'][2][2],('unexpected German change',i)
for i in ['70F5','709F','70F8','10BA','2043','7007']:
 assert controls(m[i]['parts'][2][2])==controls(old[i]['parts'][2][2]),('event/variable changed',i)
assert 'THREE_CHOICE' not in m['1038']['parts'][2][2]
assert 'TEXTID(0x105C)' not in m['105B']['parts'][2][2]
paths=['extracted/pal-1.0/text/message_data.h','src/overlays/actors/ovl_En_Ko/z_en_ko.c','src/overlays/actors/ovl_En_Ossan/z_en_ossan.c','src/overlays/actors/ovl_En_Hy/z_en_hy.c']
hashes=lambda:{p:hashlib.sha256((O/p).read_bytes()).hexdigest()for p in paths}
before=hashes();subprocess.run([sys.executable,str(R/'tools/build_dialogue_v94.py'),str(O)],check=True);assert hashes()==before,'helper not idempotent'
r=dict(changed_german_ids=sorted(bodies),count=len(bodies),reviewed_pages=pagecount,unchanged_other_languages=True,unchanged_other_german_ids=True,layout_max_lines=4,layout_width_px=210,native_terminal_controls_preserved=True,idempotent_helper=True,source_sha256=before)
(W/'source-verification.json').write_text(json.dumps(r,indent=2));print('SOURCE_VERIFIED',len(bodies),'messages',pagecount,'pages')

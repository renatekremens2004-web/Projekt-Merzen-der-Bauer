from pathlib import Path
import os,sys,json,subprocess,struct
W=Path(__file__).resolve().parent
rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1]);sy=json.loads((W/f'all-symbols-{mode}.json').read_text())
old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s')
base=base.replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned offered=0,displayed=0;
static void onframe(unsigned f){
 baseframe(f);if(f<380)return;findplay();if(!play||!player)return;
 unsigned npc=actor_type(NPC,TYPE),msg=play+0x20d8;
 if(npc){
  unsigned id=DebugMemRead16(npc+0x10e);
  if(id==EXPECTED)offered=1;
  if(f<650){float ang=(int16_t)DebugMemRead16(npc+0xb6)*(3.14159265f/32768.0f),x=rf(npc+0x24),y=rf(npc+0x28),z=rf(npc+0x2c);position(player,x+sinf(ang)*DIST,y,z+cosf(ang)*DIST,(int16_t)DebugMemRead16(npc+0xb6)+32768);photo(x+sinf(ang)*130,y+110,z+cosf(ang)*130,x,y+30,z);}
  if(f==500)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);if(f==500)printf("NPC npc=%x params=%x offered=%04x\n",npc,DebugMemRead16(npc+0x1c),id);
 }
 if(buttons)buttons((f>500&&f<850&&f%24<2)?0x80:0);
 if(DebugMemRead16(msg+0xe2f8)==EXPECTED&&DebugMemRead8(msg+0xe304))displayed=1;
 if(f==650)bank();
 if(f>750){bank();need(npc&&offered,"native actor selects approved dialogue");need(displayed,"approved dialogue opens through native interaction");puts("DIALOGUE_NATIVE_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
}
'''
cases=[('kokiri-tutorial',0xc9,0x163,11,0x1040,25),('kokiri-shop',0xc1,0x3d,-1,0x009e,80),('city-resident',0xb1,0x16e,11,0x7014,25),('bazaar-terri',0xb7,0x3d,-1,0x0127,80)]
for name,entr,npc,typ,expected,dist in cases:
 if (W/f'dialogue-qa-{mode}-{name}.log').exists() and 'DIALOGUE_NATIVE_PASSED' in (W/f'dialogue-qa-{mode}-{name}.log').read_text():continue
 text=body
 for k,v in [('EXPECTED',expected),('NPC',npc),('TYPE',typ),('DIST',dist)]:text=text.replace(k,str(v))
 c=W/f'probe-{mode}-{name}.c';c.write_text(base[:a]+text+base[b:]);exe=W/f'probe-{mode}-{name}'
 subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
 q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,entr,1,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,0,0,0,0,0xdff,entr,0);q[0x1409]=1
 # Fresh pre-story, day: isolate selectors from completed-debug-save flags.
 q[0xed4:0xf34]=bytes(0x60);struct.pack_into('>H',q,0xc,0x8000);struct.pack_into('>I',q,0xa4,0)
 if name=='city-resident':struct.pack_into('>H',q,0xef8+8*2,1<<11)
 save=W/f'{name}.save';save.write_bytes(q)
 with(W/f'dialogue-qa-{mode}-{name}.log').open('w')as log:
  r=subprocess.run([str(exe),rom,f'dialogue-v99-direct-{mode}-{name}','1200','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/tmp/dialogue-v99-test.pcm'),stdout=log,stderr=subprocess.STDOUT,timeout=220)
 assert r.returncode==0,(name,r.returncode,(W/f'dialogue-qa-{mode}-{name}.log').read_text()[-2200:])
 assert 'DIALOGUE_NATIVE_PASSED'in(W/f'dialogue-qa-{mode}-{name}.log').read_text()
 print('NATIVE_PASS',mode,name,flush=True)

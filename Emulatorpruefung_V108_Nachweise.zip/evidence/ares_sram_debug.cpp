#include <signal.h>
#include <unistd.h>
#include <cstring>
#include <n64/n64.hpp>
#include <cstdio>
#include <cstdlib>
using namespace ares;
namespace N=ares::Nintendo64;
struct Test : ares::Platform {
 std::shared_ptr<vfs::directory> sys=std::make_shared<vfs::directory>(),cart=std::make_shared<vfs::directory>();
 uint64_t audioSamples=0,nonzeroSamples=0;double audioPeak=0;
 unsigned frames=0,buttons=0;bool frame=false;
 auto audio(Node::Audio::Stream stream)->void override{while(stream->pending()){double b[2];unsigned n=stream->read(b);audioSamples++;for(unsigned i=0;i<n;i++){double a=std::abs(b[i]);if(a>0.00001)nonzeroSamples++;if(a>audioPeak)audioPeak=a;}}}
 auto pak(Node::Object o)->std::shared_ptr<vfs::directory>override{return o->name()=="Nintendo 64"?sys:cart;}
 auto event(Event e)->void override{if(e==Event::Frame){frames++;frame=true;}}
 auto video(Node::Video::Screen,const u32*d,u32 pitch,u32 w,u32 h)->void override{
  if(frames==299||frames==599){char p[160];sprintf(p,"/tmp/emulator-compat-v107/ares-%u.ppm",frames);FILE*f=fopen(p,"wb");fprintf(f,"P6\n%u %u\n255\n",w,h);for(unsigned y=0;y<h;y++)for(unsigned x=0;x<w;x++){u32 v=*(const u32*)((const char*)d+y*pitch+x*4);unsigned char rgb[]={static_cast<unsigned char>(v>>16),static_cast<unsigned char>(v>>8),static_cast<unsigned char>(v)};fwrite(rgb,3,1,f);}fclose(f);}
 }
 auto input(Node::Input::Input in)->void override{if(auto b=in->cast<Node::Input::Button>()){static unsigned calls=0;if(buttons&&calls++<10)printf("ARES_INPUT name=%s keys=%x\n",in->name().data(),buttons);std::string n=in->name().data();unsigned bit=n=="A"?0x80:n=="B"?0x40:n=="Start"?0x10:n=="Z"?0x20:n=="C-Left"?0x200:0;b->setValue((buttons&bit)!=0);}}
} test;

static bool done=false;
#define M64CMD_STOP 0
#define M64CMD_TAKE_NEXT_SCREENSHOT 1
static int CoreDoCommand(int cmd,int arg,void*ptr){if(cmd==0)done=true;return 0;}
static uint32_t DebugMemRead32(uint32_t a){return N::cpu.readDebug<N::Word>((int64_t)(int32_t)a);}
static uint16_t DebugMemRead16(uint32_t a){return N::cpu.readDebug<N::Half>((int64_t)(int32_t)a);}
static uint8_t DebugMemRead8(uint32_t a){return N::cpu.readDebug<N::Byte>((int64_t)(int32_t)a);}
static void DebugMemWrite32(uint32_t a,uint32_t v){N::cpu.writeDebug<N::Word>((int64_t)(int32_t)a,v);}
static void DebugMemWrite16(uint32_t a,uint16_t v){N::cpu.writeDebug<N::Half>((int64_t)(int32_t)a,v);}
static void DebugMemWrite8(uint32_t a,uint8_t v){N::cpu.writeDebug<N::Byte>((int64_t)(int32_t)a,v);}
static uint32_t savebase=0x80118450, overlays=0x800e6500;
static int limit=2400;static int memory_mb=4;
static const char* scenario;
static const char* snapshotfile;
static void (*buttons)(unsigned);
static unsigned actors[32],player;static int count;
static uint32_t mr32(uint32_t a){return DebugMemRead32(a);}
static float rf(uint32_t a){uint32_t x=mr32(a);float f;memcpy(&f,&x,4);return f;}
static void debugcb(void* ctx,int level,const char* message){static int bad=0;if(strstr(message,"UNKNOWN GBI COMMAND") || strstr(message,"Using Vertex outside buffer")){if(++bad>100)exit(98);}if(level<=2)fprintf(stderr,"EMU %d: %s\n",level,message);}
static void scan(void){
 count=0;
 for(uint32_t a=0x80120000;a<0x80400000-0x700;a+=4){
  unsigned id=DebugMemRead16(a);if(id==0 && mr32(a+0x138)==overlays && DebugMemRead8(a+2)==2 && mr32(a+0x130))player=a;if(id!=0xe8 && id!=0x2a && id!=0x17a && id!=0x52)continue;
  if(mr32(a+0x138)!=overlays+id*0x20 || !mr32(a+0x130))continue;
  int params=(int16_t)DebugMemRead16(a+0x1c);
  if(id==0xe8 && params>=100)continue;
  if(id==0x2a && (params>>8)!=3 && (params>>8)!=5 && (params>>8)!=7 && (params>>8)!=8 && (params>>8)!=9)continue;
  if(count<32)actors[count++]=a;
 }
}
static uint32_t play;
static uint32_t actor(int id){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=mr32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=mr32(a+0x124),n++)if(DebugMemRead16(a)==id && mr32(a+0x130))return a;
 return 0;
}
static uint32_t actor_type(int id,int type){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=mr32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=mr32(a+0x124),n++)if(DebugMemRead16(a)==id && mr32(a+0x130) && (type<0 || (DebugMemRead16(a+0x1c)&127)==type))return a;
 return 0;
}
static void findplay(void){
 if(play&&mr32(play+4)==0x8009f05c&&mr32(play+0x98)==1&&mr32(play+0x1c44)==player&&player&&mr32(player+0x130))return;
 play=0;player=0;
 for(unsigned p=0x80120000;p<0x803ed000;p+=4)if(mr32(p+4)==0x8009f05c&&mr32(p+0x98)==1&&DebugMemRead16(p+0xa4)<0x70){unsigned a=mr32(p+0x1c44);if(a>=0x80120000&&a<0x80400000&&DebugMemRead16(a)==0&&mr32(a+0x138)==overlays&&mr32(a+0x130)){play=p;player=a;printf("PLAY_VALID %x player=%x scene=%x room=%u\n",play,player,DebugMemRead16(play+0xa4),DebugMemRead8(play+0x11cbc));return;}}
}
static void wf(uint32_t a,float f){uint32_t v;memcpy(&v,&f,4);DebugMemWrite32(a,v);}
static void position(uint32_t a,float x,float y,float z,int facing){wf(a+0x24,x);wf(a+0x28,y);wf(a+0x2c,z);wf(a+0x100,x);wf(a+0x104,y);wf(a+0x108,z);DebugMemWrite16(a+0xb6,facing);DebugMemWrite16(a+0x32,facing);}
static void baseframe(unsigned f){
 alarm(30);
 if (snapshotfile && f == 300) {
   findplay();
   if (strstr(scenario,"export")) {
     FILE* snap=fopen(snapshotfile,"wb");if(!snap)exit(90);
     for(unsigned i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),snap);
     fclose(snap);printf("EXPORTED save=%08x entrance=%x age=%d mode=%d\n",savebase,mr32(savebase),mr32(savebase+4),mr32(savebase+0x135c));
     CoreDoCommand(M64CMD_STOP,0,NULL);return;
   }
   if(!play){fprintf(stderr,"No title PlayState found\n");exit(91);}
   printf("INJECT title scene=%x mode=%d save=%08x\n",DebugMemRead16(play+0xa4),mr32(savebase+0x135c),savebase);
   FILE* snap=fopen(snapshotfile,"rb");if(!snap)exit(92);
   for(unsigned i=0;i<0x1428;i++){int ch=fgetc(snap);if(ch<0)exit(93);DebugMemWrite8(savebase+i,ch);}fclose(snap);
   DebugMemWrite32(savebase+0x135c,0);
   DebugMemWrite8(play+0x11de8,mr32(savebase+4));
   DebugMemWrite16(savebase+0x1412,mr32(savebase+8)?mr32(savebase+8):0xffef);
   DebugMemWrite8(play+0x1d6c,0);
   if(strstr(scenario,"direct")) {
     uint32_t game=0x800f1930+3*0x30;
     if(mr32(game+0x2c)!=0x12518){fprintf(stderr,"Invalid Play gamestate entry\n");exit(97);}
     DebugMemWrite8(play+0x11de9,1);
     DebugMemWrite32(play+0xc,mr32(game+0x18));DebugMemWrite32(play+0x10,0x12518);DebugMemWrite32(play+0x98,0);
     printf("DIRECT Play_Init=%08x\n",mr32(game+0x18));
   }else{
     DebugMemWrite16(play+0x11e1a,mr32(savebase));
     DebugMemWrite8(play+0x11e5e,2);DebugMemWrite8(play+0x11e15,20);
   }
   printf("START entrance=%x age=%d cs=%x\n",mr32(savebase),mr32(savebase+4),mr32(savebase+8));
 }
}

static uint64_t (*audioSamples)(void);static unsigned (*audioRate)(void);
static FILE* video=NULL;
static void need(int ok,const char*why){if(!ok){printf("ASSERT_FAILED %s\n",why);exit(96);}}
static unsigned target(unsigned id,unsigned param){
 for(int cat=0;cat<12;cat++)for(unsigned p=mr32(play+0x1c34+cat*8),n=0;p>=0x80000000&&p<0x80400000&&n<200;p=mr32(p+0x124),n++)if(DebugMemRead16(p)==id&&DebugMemRead16(p+0x1c)==param&&mr32(p+0x130))return p;
 return 0;
}
static void bank(void){
 unsigned c=play+0x117a4,begin=mr32(c),end=mr32(c+4),last=begin,count=DebugMemRead8(c+8);
 for(unsigned i=0;i<count&&i<19;i++){unsigned p=c+12+i*0x44;int obj=(int16_t)DebugMemRead16(p);if(obj<0)obj=-obj;if(obj>0&&obj<=0x1b0){unsigned e=mr32(p+4)+mr32(0x800f9838+obj*8+4)-mr32(0x800f9838+obj*8);if(e>last)last=e;}}
 need(DebugMemRead16(0x8011d6c8)==0,"no rejected object loads");need(DebugMemRead16(0x8011a198)==0&&DebugMemRead16(0x8011a19a)==0,"all actor allocations succeed");for(unsigned q=0;q<3;q++){unsigned ctx=mr32(play),off=0x2a8+q*16;need(mr32(ctx+off+8)<=mr32(ctx+off+12),"graphics command and matrix buffers stay within bounds");}printf("BANK slots=%u used=%u free=%d RAM=%u\n",count,last-begin,(int)(end-last),mr32(0x80000318));need(count<=19&&last<=end,"object bank within budget");need(mr32(0x80000318)==4194304,"native 4 MiB");
}
static void photo(float x,float y,float z,float ax,float ay,float az){
 unsigned c=mr32(play+0x790+DebugMemRead16(play+0x7a0)*4);DebugMemWrite16(c+0x142,0x21);DebugMemWrite16(c+0x144,0);DebugMemWrite16(c+0x15e,1);DebugMemWrite16(c+0x14c,0);wf(c+0xfc,55);wf(c+0x5c,x);wf(c+0x60,y);wf(c+0x64,z);wf(c+0x74,x);wf(c+0x78,y);wf(c+0x7c,z);wf(c+0x50,ax);wf(c+0x54,ay);wf(c+0x58,az);
}






static void capture_render(void){}
static unsigned menu=0,started=0,selecting=0,laststate=999,ready=0,phase=0,mark=0,hash0=0,paused=0,scene_expected;
static unsigned hashmem(unsigned a,unsigned n){unsigned h=2166136261;for(unsigned i=0;i<n;i++)h=(h^DebugMemRead8(a+i))*16777619;return h;}
static unsigned colhash(void){unsigned h=mr32(play+0x7c0);need(h>=0x80000000&&h<0x80400000-44,"native scene collision loaded");unsigned v=mr32(h+0x10),p=mr32(h+0x18),nv=DebugMemRead16(h+12),np=DebugMemRead16(h+20);need(v>=0x80000000&&v+nv*6<=0x80400000&&p>=0x80000000&&p+np*16<=0x80400000,"collision pointers within 4 MiB");return hashmem(v,nv*6)^hashmem(p,np*16);}
static void onframe(unsigned f){
 alarm(60);unsigned v=0;if(f>=500&&!menu&&!started&&f%60==0)v=0x10;
 if(f>500&&!started){unsigned tab=0x800f1930+5*0x30,base=mr32(tab),vram=mr32(tab+12),destroy=mr32(tab+28);if(base&&!menu){unsigned fn=destroy>=base&&destroy<base+0x40000?destroy:destroy-vram+base;for(unsigned p=0x80120000;p<0x803e0000;p+=4)if(mr32(p+8)==fn&&mr32(p+0x98)==1){menu=p;printf("NATIVE_FILE_MENU %x\n",menu);break;}}
 if(menu&&mr32(menu+0x98)==1){unsigned mode=DebugMemRead16(menu+0x1ca3c),cfg=DebugMemRead16(menu+0x1ca3e),sel=DebugMemRead16(menu+0x1ca44),state=(mode<<16)|(cfg<<8)|sel;if(state!=laststate){printf("SRAM_FILE_STATE f=%u mode=%u cfg=%u sel=%u\n",f,mode,cfg,sel);laststate=state;}
 if(mode==0&&cfg==2&&f%12==0)v=DebugMemRead8(savebase+0x1409)==1?0x80:0x00500000;
 if(mode==1&&cfg==2&&f%24==0)v=0x80;
 if(mode==2){selecting=1;if(sel==3&&f%24==0)v=0x80;}
 need(cfg!=33,"native save fixture recognized");
 }else if(selecting){started=f;play=player=0;printf("NATIVE_EXISTING_SAVE_STARTED %u\n",f);}}
 if(started){findplay();if(play&&player){unsigned scene=DebugMemRead16(play+0xa4),mm=DebugMemRead8(play+0x20d8+0xe304),cs=DebugMemRead8(play+0x1d6c),st=DebugMemRead16(play+0x10934);
 if(f%500==0)printf("NATIVE_STATE ps=%u cs=%u mm=%u flags=%x\n",st,cs,mm,mr32(player+0x66c));if(mm&&f%16<3)v=0x80;
 if(ready||(!cs&&!mm)){if(!ready){ready=f;scene_expected=scene;bank();printf("CONTROL_RETURN scene=%x age=%u y=%.1f floor=%x\n",scene,mr32(savebase+4),rf(player+0x28),DebugMemRead16(player+0x88));}
 if(phase==0&&f>ready+60){hash0=colhash();v=0x10;phase=1;mark=f;}
 if(phase==1&&f>mark+50&&f%60<6)v=0x10;
 if(phase==1&&st==6){paused++;phase=2;mark=f;CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 if(phase==2&&f>=mark+20&&f<mark+28)v=0x10;
 if(phase==2&&st==0){phase=3;mark=f;}
 if(phase==3&&f>mark+50){bank();need(colhash()==hash0,"collision unchanged after inventory");need(scene==scene_expected,"scene remains stable after inventory");need(DebugMemRead16(player+0x88)!=0xffff,"standing on native floor after inventory");printf("COMPAT_SRAM_PASSED scene=%x age=%u pause=%u floor=%x y=%.1f\n",scene,mr32(savebase+4),paused,DebugMemRead16(player+0x88),rf(player+0x28));CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 }}if(f%500==0)printf("SRAM_PROGRESS f=%u started=%u ready=%u phase=%u\n",f,started,ready,phase);
 static unsigned held=0,until=0;if(v){held=v;until=f+3;}if(f<until)v=held;if(buttons)buttons(v);need(f<14000,"native save load and pause finish");
}
int main(int argc,char**argv){setbuf(stdout,0);platform=&test;for(auto name:{"pif.pal.rom","pif.ntsc.rom","pif.sm5.rom"})test.sys->append(name,file::read({"/tmp/emulator-compat-v107/ares148/mia/Firmware/Nintendo 64/",name}));test.cart->append("program.rom",file::read(argv[1]));test.cart->append("save.ram",file::read(argv[2]));test.cart->setAttribute("title","V108 compatibility");test.cart->setAttribute("region","PAL");test.cart->setAttribute("cic","CIC-NUS-7105");Node::System root;N::option("Enable GPU acceleration","true");N::option("Expansion Pak","false");N::option("Recompiler","true");if(!N::load(root,"[Nintendo] Nintendo 64 (PAL)"))return 2;auto p=root->find<Node::Port>("Cartridge Slot");p->allocate();p->connect();p=root->find<Node::Port>("Controller Port 1");p->allocate("Gamepad");p->connect();root->power(false);
 savebase=0x8011bba0;overlays=0x800e8aa0;buttons=[](unsigned b){test.buttons=b;};for(unsigned i=0;i<26000&&!done;i++){root->run();test.frames=i+1;onframe(i);}
 printf("ARES_AUDIO samples=%llu nonzero=%llu peak=%.6f\n",(unsigned long long)test.audioSamples,(unsigned long long)test.nonzeroSamples,test.audioPeak);root->unload();puts("ARES_NATIVE_TEST_DONE");return done?0:95;}

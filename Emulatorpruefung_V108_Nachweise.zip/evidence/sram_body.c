static void capture_render(void){}
static unsigned menu=0,started=0,selecting=0,laststate=999,ready=0,phase=0,mark=0,hash0=0,paused=0,scene_expected;
static unsigned hashmem(unsigned a,unsigned n){unsigned h=2166136261;for(unsigned i=0;i<n;i++)h=(h^DebugMemRead8(a+i))*16777619;return h;}
static unsigned colhash(void){unsigned h=r32(play+0x7c0);need(h>=0x80000000&&h<0x80400000-44,"native scene collision loaded");unsigned v=r32(h+0x10),p=r32(h+0x18),nv=DebugMemRead16(h+12),np=DebugMemRead16(h+20);need(v>=0x80000000&&v+nv*6<=0x80400000&&p>=0x80000000&&p+np*16<=0x80400000,"collision pointers within 4 MiB");return hashmem(v,nv*6)^hashmem(p,np*16);}
static void onframe(unsigned f){
 alarm(60);unsigned v=0;if(f>=500&&!menu&&!started&&f%60==0)v=0x10;
 if(f>500&&!started){unsigned tab=0x800f1890+5*0x30,base=r32(tab),vram=r32(tab+12),destroy=r32(tab+28);if(base&&!menu){unsigned fn=destroy>=base&&destroy<base+0x40000?destroy:destroy-vram+base;for(unsigned p=0x80120000;p<0x803e0000;p+=4)if(r32(p+8)==fn&&r32(p+0x98)==1){menu=p;printf("NATIVE_FILE_MENU %x\n",menu);break;}}
 if(menu&&r32(menu+0x98)==1){unsigned mode=DebugMemRead16(menu+0x1ca3c),cfg=DebugMemRead16(menu+0x1ca3e),sel=DebugMemRead16(menu+0x1ca44),state=(mode<<16)|(cfg<<8)|sel;if(state!=laststate){printf("SRAM_FILE_STATE f=%u mode=%u cfg=%u sel=%u\n",f,mode,cfg,sel);laststate=state;}
 if(mode==0&&cfg==2&&f%12==0)v=DebugMemRead8(savebase+0x1409)==1?0x80:0x00500000;
 if(mode==1&&cfg==2&&f%24==0)v=0x80;
 if(mode==2){selecting=1;if(sel==3&&f%24==0)v=0x80;}
 need(cfg!=33,"native save fixture recognized");
 }else if(selecting){started=f;play=player=0;printf("NATIVE_EXISTING_SAVE_STARTED %u\n",f);}}
 if(started){findplay();if(play&&player){unsigned scene=DebugMemRead16(play+0xa4),mm=DebugMemRead8(play+0x20d8+0xe304),cs=DebugMemRead8(play+0x1d6c),st=DebugMemRead16(play+0x10934);
 if(f%500==0)printf("NATIVE_STATE ps=%u cs=%u mm=%u flags=%x\n",st,cs,mm,r32(player+0x66c));if(mm&&f%16<3)v=0x80;
 if(ready||(!cs&&!mm)){if(!ready){ready=f;scene_expected=scene;bank();printf("CONTROL_RETURN scene=%x age=%u y=%.1f floor=%x\n",scene,r32(savebase+4),rf(player+0x28),DebugMemRead16(player+0x88));}
 if(phase==0&&f>ready+60){hash0=colhash();v=0x10;phase=1;mark=f;}
 if(phase==1&&f>mark+50&&f%60<6)v=0x10;
 if(phase==1&&st==6){paused++;phase=2;mark=f;CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 if(phase==2&&f>=mark+20&&f<mark+28)v=0x10;
 if(phase==2&&st==0){phase=3;mark=f;}
 if(phase==3&&f>mark+50){bank();need(colhash()==hash0,"collision unchanged after inventory");need(scene==scene_expected,"scene remains stable after inventory");need(DebugMemRead16(player+0x88)!=0xffff,"standing on native floor after inventory");printf("COMPAT_SRAM_PASSED scene=%x age=%u pause=%u floor=%x y=%.1f\n",scene,r32(savebase+4),paused,DebugMemRead16(player+0x88),rf(player+0x28));CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 }}if(f%500==0)printf("SRAM_PROGRESS f=%u started=%u ready=%u phase=%u\n",f,started,ready,phase);
 static unsigned held=0,until=0;if(v){held=v;until=f+3;}if(f<until)v=held;if(buttons)buttons(v);need(f<12000,"native save load and pause finish");
}

from pathlib import Path
import os,subprocess,concurrent.futures,json
W=Path(__file__).resolve().parent
def one(tag):
 log=W/('ares-critical-'+tag+'.log')
 with log.open('w')as f:r=subprocess.run([str(W/'ares_critical'),'/tmp/emulator-compat-v108/normal.z64',str(W/'native-01-1.sram'),'ares-room-'+tag,str(W/(tag+'.save'))],env=dict(os.environ,LP_NUM_THREADS='2',VK_ICD_FILENAMES=str(W/'lavapipe.json'),XDG_CACHE_HOME=str(W/'cache')),stdout=f,stderr=subprocess.STDOUT,timeout=420)
 text=log.read_text();result=dict(tag=tag,passed=r.returncode==0 and'COMPAT_SRAM_PASSED'in text,log=log.name,tail=text[-1400:]);print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:r=list(ex.map(one,['fire-darunia','well-organs']))
(W/'critical-results.json').write_text(json.dumps(r,indent=2))

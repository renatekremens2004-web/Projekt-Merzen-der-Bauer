from pathlib import Path
import os,subprocess,json,concurrent.futures,shutil,ctypes,hashlib
W=Path(__file__).resolve().parent;G=W/'squashfs-root/shared/lib/RMG/Plugin';base=dict(os.environ,DISPLAY=':99',XDG_DATA_HOME=str(W/'data'),XDG_CONFIG_HOME=str(W/'global-config'),XDG_CACHE_HOME=str(W/'cache'),MESA_SHADER_CACHE_DIR=str(W/'mesa'),CREDITS_AUDIO_PATH='/dev/null',COMPAT_CPU='2',LP_NUM_THREADS='2')
cases=[dict(tag='debug-dd',orig='native-01-1',mode='debug',core='rmg'),dict(tag='debug-fire',orig='native-04-0',mode='debug',core='rmg'),dict(tag='official260-dd',orig='native-01-1',mode='normal',core='official')]
def one(c):
 tag=c['tag'];config=W/('config-'+tag);config.mkdir(exist_ok=True);filename='THE LEGEND OF ZELDA-'+('A377B348'if c['mode']=='debug'else'F3596C87')+'.sra';data=next((W/('config-'+c['orig'])).glob('*.sra')).read_bytes();(config/filename).write_bytes(data)
 env=dict(base,LD_LIBRARY_PATH=str(W/('rmg-libs'if c['core']=='rmg'else'mupen260/mupen64plus-bundle-linux64-2.6.0')),COMPAT_RSP=str(G/'RSP/mupen64plus-rsp-hle.so'),COMPAT_GFX=str(G/'GFX/mupen64plus-video-GLideN64.so'))
 log=W/(tag+'.log');sy=json.load(open('/tmp/emulator-compat-v108/all-symbols-'+c['mode']+'.json'))
 try:
  with log.open('w')as f:r=subprocess.run([str(W/('sram-debug'if c['mode']=='debug'else'sram')),'/tmp/emulator-compat-v108/'+c['mode']+'.z64',tag,'12000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable'])],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=200)
  out=log.read_text();result=dict(c,passed=r.returncode==0 and'COMPAT_SRAM_PASSED'in out,returncode=r.returncode,log=log.name,tail=out[-1200:])
 except subprocess.TimeoutExpired:result=dict(c,passed=False,timeout=True,log=log.name)
 print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=1)as pool:r=list(pool.map(one,cases))
(W/'extra-results.json').write_text(json.dumps(r,indent=2))

#include <signal.h>
#include <unistd.h>
#include <cstring>
#include <n64/n64.hpp>
#include <cstdio>
#include <cstdlib>
using namespace ares;
namespace N=ares::Nintendo64;
struct Test : ares::Platform {
 std::shared_ptr<vfs::directory> sys=std::make_shared<vfs::directory>(),cart=std::make_shared<vfs::directory>();
 uint64_t audioSamples=0,nonzeroSamples=0;double audioPeak=0;
 unsigned frames=0,buttons=0;bool frame=false;
 auto audio(Node::Audio::Stream stream)->void override{while(stream->pending()){double b[2];unsigned n=stream->read(b);audioSamples++;for(unsigned i=0;i<n;i++){double a=std::abs(b[i]);if(a>0.00001)nonzeroSamples++;if(a>audioPeak)audioPeak=a;}}}
 auto pak(Node::Object o)->std::shared_ptr<vfs::directory>override{return o->name()=="Nintendo 64"?sys:cart;}
 auto event(Event e)->void override{if(e==Event::Frame){frames++;frame=true;}}
 auto video(Node::Video::Screen,const u32*d,u32 pitch,u32 w,u32 h)->void override{
  if(frames==299||frames==599){char p[160];sprintf(p,"/tmp/emulator-compat-v107/ares-%u.ppm",frames);FILE*f=fopen(p,"wb");fprintf(f,"P6\n%u %u\n255\n",w,h);for(unsigned y=0;y<h;y++)for(unsigned x=0;x<w;x++){u32 v=*(const u32*)((const char*)d+y*pitch+x*4);unsigned char rgb[]={static_cast<unsigned char>(v>>16),static_cast<unsigned char>(v>>8),static_cast<unsigned char>(v)};fwrite(rgb,3,1,f);}fclose(f);}
 }
 auto input(Node::Input::Input in)->void override{if(auto b=in->cast<Node::Input::Button>()){static unsigned calls=0;if(buttons&&calls++<10)printf("ARES_INPUT name=%s keys=%x\n",in->name().data(),buttons);std::string n=in->name().data();unsigned bit=n=="A"?0x80:n=="B"?0x40:n=="Start"?0x10:n=="Z"?0x20:n=="C-Left"?0x200:0;b->setValue((buttons&bit)!=0);}}
} test;

static bool compatDone=false;
#define M64CMD_STOP 0
#define M64CMD_TAKE_NEXT_SCREENSHOT 1
static int CoreDoCommand(int cmd,int arg,void*ptr){if(cmd==0)compatDone=true;return 0;}
static uint32_t DebugMemRead32(uint32_t a){return N::cpu.readDebug<N::Word>((int64_t)(int32_t)a);}
static uint16_t DebugMemRead16(uint32_t a){return N::cpu.readDebug<N::Half>((int64_t)(int32_t)a);}
static uint8_t DebugMemRead8(uint32_t a){return N::cpu.readDebug<N::Byte>((int64_t)(int32_t)a);}
static void DebugMemWrite32(uint32_t a,uint32_t v){N::cpu.writeDebug<N::Word>((int64_t)(int32_t)a,v);}
static void DebugMemWrite16(uint32_t a,uint16_t v){N::cpu.writeDebug<N::Half>((int64_t)(int32_t)a,v);}
static void DebugMemWrite8(uint32_t a,uint8_t v){N::cpu.writeDebug<N::Byte>((int64_t)(int32_t)a,v);}
static uint32_t savebase=0x80118450, overlays=0x800e6500;
static int limit=2400;static int memory_mb=4;
static const char* scenario;
static const char* snapshotfile;
static void (*buttons)(unsigned);
static unsigned actors[32],player;static int count;
static uint32_t mr32(uint32_t a){return DebugMemRead32(a);}
static float rf(uint32_t a){uint32_t x=mr32(a);float f;memcpy(&f,&x,4);return f;}
static void debugcb(void* ctx,int level,const char* message){static int bad=0;if(strstr(message,"UNKNOWN GBI COMMAND") || strstr(message,"Using Vertex outside buffer")){if(++bad>100)exit(98);}if(level<=2)fprintf(stderr,"EMU %d: %s\n",level,message);}
static void scan(void){
 count=0;
 for(uint32_t a=0x80120000;a<0x80400000-0x700;a+=4){
  unsigned id=DebugMemRead16(a);if(id==0 && mr32(a+0x138)==overlays && DebugMemRead8(a+2)==2 && mr32(a+0x130))player=a;if(id!=0xe8 && id!=0x2a && id!=0x17a && id!=0x52)continue;
  if(mr32(a+0x138)!=overlays+id*0x20 || !mr32(a+0x130))continue;
  int params=(int16_t)DebugMemRead16(a+0x1c);
  if(id==0xe8 && params>=100)continue;
  if(id==0x2a && (params>>8)!=3 && (params>>8)!=5 && (params>>8)!=7 && (params>>8)!=8 && (params>>8)!=9)continue;
  if(count<32)actors[count++]=a;
 }
}
static uint32_t play;
static uint32_t actor(int id){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=mr32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=mr32(a+0x124),n++)if(DebugMemRead16(a)==id && mr32(a+0x130))return a;
 return 0;
}
static uint32_t actor_type(int id,int type){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=mr32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=mr32(a+0x124),n++)if(DebugMemRead16(a)==id && mr32(a+0x130) && (type<0 || (DebugMemRead16(a+0x1c)&127)==type))return a;
 return 0;
}
static void findplay(void){
 if(play&&mr32(play+4)==0x8009f05c&&mr32(play+0x98)==1&&mr32(play+0x1c44)==player&&player&&mr32(player+0x130))return;
 play=0;player=0;
 for(unsigned p=0x80120000;p<0x803ed000;p+=4)if(mr32(p+4)==0x8009f05c&&mr32(p+0x98)==1&&DebugMemRead16(p+0xa4)<0x70){unsigned a=mr32(p+0x1c44);if(a>=0x80120000&&a<0x80400000&&DebugMemRead16(a)==0&&mr32(a+0x138)==overlays&&mr32(a+0x130)){play=p;player=a;printf("PLAY_VALID %x player=%x scene=%x room=%u\n",play,player,DebugMemRead16(play+0xa4),DebugMemRead8(play+0x11cbc));return;}}
}
static void wf(uint32_t a,float f){uint32_t v;memcpy(&v,&f,4);DebugMemWrite32(a,v);}
static void position(uint32_t a,float x,float y,float z,int facing){wf(a+0x24,x);wf(a+0x28,y);wf(a+0x2c,z);wf(a+0x100,x);wf(a+0x104,y);wf(a+0x108,z);DebugMemWrite16(a+0xb6,facing);DebugMemWrite16(a+0x32,facing);}
static void baseframe(unsigned f){alarm(60);}

static uint64_t (*audioSamples)(void);static unsigned (*audioRate)(void);
static FILE* video=NULL;
static void need(int ok,const char*why){if(!ok){printf("ASSERT_FAILED %s\n",why);exit(96);}}
static unsigned target(unsigned id,unsigned param){
 for(int cat=0;cat<12;cat++)for(unsigned p=mr32(play+0x1c34+cat*8),n=0;p>=0x80000000&&p<0x80400000&&n<200;p=mr32(p+0x124),n++)if(DebugMemRead16(p)==id&&DebugMemRead16(p+0x1c)==param&&mr32(p+0x130))return p;
 return 0;
}
static void bank(void){
 unsigned c=play+0x117a4,begin=mr32(c),end=mr32(c+4),last=begin,count=DebugMemRead8(c+8);
 for(unsigned i=0;i<count&&i<19;i++){unsigned p=c+12+i*0x44;int obj=(int16_t)DebugMemRead16(p);if(obj<0)obj=-obj;if(obj>0&&obj<=0x1b0){unsigned e=mr32(p+4)+mr32(0x800f9798+obj*8+4)-mr32(0x800f9798+obj*8);if(e>last)last=e;}}
 need(DebugMemRead16(0x8011d628)==0,"no rejected object loads");need(DebugMemRead16(0x8011a0f8)==0&&DebugMemRead16(0x8011a0fa)==0,"all actor allocations succeed");for(unsigned q=0;q<3;q++){unsigned ctx=mr32(play),off=0x2a8+q*16;need(mr32(ctx+off+8)<=mr32(ctx+off+12),"graphics command and matrix buffers stay within bounds");}printf("BANK slots=%u used=%u free=%d RAM=%u\n",count,last-begin,(int)(end-last),mr32(0x80000318));need(count<=19&&last<=end,"object bank within budget");need(mr32(0x80000318)==4194304,"native 4 MiB");
}
static void photo(float x,float y,float z,float ax,float ay,float az){
 unsigned c=mr32(play+0x790+DebugMemRead16(play+0x7a0)*4);DebugMemWrite16(c+0x142,0x21);DebugMemWrite16(c+0x144,0);DebugMemWrite16(c+0x15e,1);DebugMemWrite16(c+0x14c,0);wf(c+0xfc,55);wf(c+0x5c,x);wf(c+0x60,y);wf(c+0x64,z);wf(c+0x74,x);wf(c+0x78,y);wf(c+0x7c,z);wf(c+0x50,ax);wf(c+0x54,ay);wf(c+0x58,az);
}






static void capture_render(void){}
static unsigned menu=0,started=0,selecting=0,laststate=999,ready=0,phase=0,mark=0,hash0=0,paused=0,scene_expected;
static unsigned hashmem(unsigned a,unsigned n){unsigned h=2166136261;for(unsigned i=0;i<n;i++)h=(h^DebugMemRead8(a+i))*16777619;return h;}
static unsigned colhash(void){unsigned h=mr32(play+0x7c0);need(h>=0x80000000&&h<0x80400000-44,"native scene collision loaded");unsigned v=mr32(h+0x10),p=mr32(h+0x18),nv=DebugMemRead16(h+12),np=DebugMemRead16(h+20);need(v>=0x80000000&&v+nv*6<=0x80400000&&p>=0x80000000&&p+np*16<=0x80400000,"collision pointers within 4 MiB");return hashmem(v,nv*6)^hashmem(p,np*16);}
static void nativeframe(unsigned f){
 alarm(60);unsigned v=0;if(f>=500&&!menu&&!started&&f%60==0)v=0x10;
 if(f>500&&!started){unsigned tab=0x800f1890+5*0x30,base=mr32(tab),vram=mr32(tab+12),destroy=mr32(tab+28);if(base&&!menu){unsigned fn=destroy>=base&&destroy<base+0x40000?destroy:destroy-vram+base;for(unsigned p=0x80120000;p<0x803e0000;p+=4)if(mr32(p+8)==fn&&mr32(p+0x98)==1){menu=p;printf("NATIVE_FILE_MENU %x\n",menu);break;}}
 if(menu&&mr32(menu+0x98)==1){unsigned mode=DebugMemRead16(menu+0x1ca3c),cfg=DebugMemRead16(menu+0x1ca3e),sel=DebugMemRead16(menu+0x1ca44),state=(mode<<16)|(cfg<<8)|sel;if(state!=laststate){printf("SRAM_FILE_STATE f=%u mode=%u cfg=%u sel=%u\n",f,mode,cfg,sel);laststate=state;}
 if(mode==0&&cfg==2&&f%12==0)v=DebugMemRead8(savebase+0x1409)==1?0x80:0x00500000;
 if(mode==1&&cfg==2&&f%24==0)v=0x80;
 if(mode==2){selecting=1;if(sel==3&&f%24==0)v=0x80;}
 need(cfg!=33,"native save fixture recognized");
 }else if(selecting){started=f;play=player=0;printf("NATIVE_EXISTING_SAVE_STARTED %u\n",f);}}
 if(started){findplay();if(play&&player){unsigned scene=DebugMemRead16(play+0xa4),mm=DebugMemRead8(play+0x20d8+0xe304),cs=DebugMemRead8(play+0x1d6c),st=DebugMemRead16(play+0x10934);
 if(f%500==0)printf("NATIVE_STATE ps=%u cs=%u mm=%u flags=%x\n",st,cs,mm,mr32(player+0x66c));if(mm&&f%16<3)v=0x80;
 if(ready||(!cs&&!mm)){if(!ready){ready=f;scene_expected=scene;bank();printf("CONTROL_RETURN scene=%x age=%u y=%.1f floor=%x\n",scene,mr32(savebase+4),rf(player+0x28),DebugMemRead16(player+0x88));}
 if(phase==0&&f>ready+60){hash0=colhash();v=0x10;phase=1;mark=f;}
 if(phase==1&&f>mark+50&&f%60<6)v=0x10;
 if(phase==1&&st==6){paused++;phase=2;mark=f;CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 if(phase==2&&f>=mark+20&&f<mark+28)v=0x10;
 if(phase==2&&st==0){phase=3;mark=f;}
 if(phase==3&&f>mark+50){bank();need(colhash()==hash0,"collision unchanged after inventory");need(scene==scene_expected,"scene remains stable after inventory");need(DebugMemRead16(player+0x88)!=0xffff,"standing on native floor after inventory");printf("COMPAT_SRAM_PASSED scene=%x age=%u pause=%u floor=%x y=%.1f\n",scene,mr32(savebase+4),paused,DebugMemRead16(player+0x88),rf(player+0x28));CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 }}if(f%500==0)printf("SRAM_PROGRESS f=%u started=%u ready=%u phase=%u\n",f,started,ready,phase);
 static unsigned held=0,until=0;if(v){held=v;until=f+3;}if(f<until)v=held;if(buttons)buttons(v);need(f<14000,"native save load and pause finish");
}

static unsigned ticks=0,seen=0,help=0,rescued=0,music=0,finished=0;
static void cageframe(unsigned f){
 unsigned value=0,bird=0,msg=0,id=0;int farm=strstr(scenario,"farm")!=NULL,absent=strstr(scenario,"absent")!=NULL,visual=strstr(scenario,"visual")!=NULL;
 baseframe(f);if(f<340)return;findplay();if(!play||!player)return;msg=play+0x20d8;id=DebugMemRead16(msg+0xe2f8);bird=target(0x72,0x7501);
 if(bird&&mr32(bird+0x134))seen=1;
 if(farm){need(!target(0x173,0x3f8e),"Jimmy actor absent");if(f==430||f==650){bank();}if(f>750){puts("PIEPS_QA_PASSED Jimmy absent; bank in budget");CoreDoCommand(M64CMD_STOP,0,NULL);}return;}
 if(absent){need(!bird,"rescued bird absent on next entry");if(f==600)bank();if(f>650){puts("PIEPS_QA_PASSED bird absent after rescue");CoreDoCommand(M64CMD_STOP,0,NULL);}return;}
 if(id==0x7239)help=1;
 if((DebugMemRead8(0x80126e90+0x3534)==111)&&(DebugMemRead8(0x80126e90+0x3530)&0x80))music=1;
 if(bird&&DebugMemRead16(bird+0x18c)>=2&&!visual){
  float x=rf(bird+0x24),y=rf(bird+0x28),z=rf(bird+0x2c);position(player,x-40,y,z+48,26000);if(f==500)photo(x+65,y+42,z+95,x,y+20,z);
  if(f>650){
   for(unsigned p=mr32(play+0x1c34+5*8),n=0;p>=0x80000000&&p<0x80400000&&n<80;p=mr32(p+0x124),n++){
    if(DebugMemRead16(p)==0x25&&DebugMemRead16(p+0x3ec)==5&&mr32(p+0x130)&&mr32(p+0x3cc)<10){DebugMemWrite8(p+0xb0,20);DebugMemWrite8(p+0xb1,0);DebugMemWrite8(p+0x419,DebugMemRead8(p+0x419)|2);}
   }
   value=0;if(f%15<4)value|=0x80;
  }
 }
 if(f==365||f==385||f==420||f==500||f==620||f==950||f==1250){bank();printf("PIEPS f=%u bird=%x help=%u state=%u text=%x music=%u flag=%x\n",f,bird,help,bird?DebugMemRead16(bird+0x18c):0,id,music,DebugMemRead16(savebase+0xf30));}
 if(DebugMemRead16(savebase+0xf30)&0x400){rescued=1;if(!finished)finished=f;}
 if(f%200==0&&bird)printf("TALK f=%u playerstate=%x cs=%u talk=%x birdflag=%x dist=%.1f msgmode=%u lock=%u\n",f,mr32(player+0x66c),DebugMemRead8(player+0x434),mr32(player+0x684),mr32(bird+4),rf(bird+0x90),DebugMemRead8(msg+0xe304),DebugMemRead8(bird+0x10c));
 if(buttons)buttons(value);
 if(visual&&f>720){need(seen&&help&&bird&&DebugMemRead16(bird+0x18c)>=2,"bird intro and camera restore");puts("PIEPS_QA_PASSED native bird/cage/intro");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(!visual&&rescued&&f>finished+50){bank();need(seen&&help&&music,"rescue after combat with own theme");FILE* q=fopen("/tmp/emulator-compat-v107/ares-rescued-private.save","wb");need(q!=NULL,"save fixture");for(unsigned i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),q);fclose(q);puts("PIEPS_QA_PASSED rescue persisted");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(f>2500){puts("PIEPS_QA_TIMEOUT");exit(96);}
}

static unsigned seenBird=0,seenInhale=0,swallowed=0,seenDeath=0,seenTheme=0,bombBirth=0,done=0;
static unsigned lastAction=0,postTalk=0,postClosed=0;
static unsigned bossfunc(unsigned v){return mr32(overlays+0x27*0x20+0x10)+v-0x808a12c0;}
static void bossframe(unsigned f){
 unsigned value=0,boss=0,bird=0,action=0,bomb=0;int plain=strstr(scenario,"plain")!=NULL,cleared=strstr(scenario,"cleared")!=NULL;
 baseframe(f);if(f<340)return;findplay();if(!play||!player)return;
 boss=mr32(play+0x1c34+9*8);if(boss<0x80000000||boss>=0x80400000)boss=0;
 if(cleared){
  unsigned post=target(0x72,0x7503),msg=play+0x20d8;need(!boss,"already-cleared boss not respawned");
  if(f>430){need(post&&mr32(post+0x134),"friendly bird also present on cleared re-entry");position(player,rf(post+0x24)-25,rf(post+0xc)-12,rf(post+0x2c)+42,27000);if(f%18<4)value=0x80;}
  if(DebugMemRead16(msg+0xe2f8)==0x723b&&DebugMemRead8(msg+0xe304))postTalk=1;
  if(postTalk&&DebugMemRead16(post+0x18c)==2&&!DebugMemRead8(msg+0xe304))postClosed=1;
  if(buttons)buttons(value);
  if(f>700&&postClosed){bank();need(actor(0x5f)&&actor(0x5d),"native heart and warp after cleared entry");puts("PIEPS_QA_PASSED cleared entry: bird conversation723B, native heart/warp");CoreDoCommand(M64CMD_STOP,0,NULL);}if(f>1500)exit(96);return;
 }
 if(!boss){if(f%200==0){unsigned post=target(0x72,0x7503);printf("POST bird=%x state=%u text=%x mode=%u flags=%x xz=%.1f talk=%u closed=%u\n",post,post?DebugMemRead16(post+0x18c):0,DebugMemRead16(play+0x20d8+0xe2f8),DebugMemRead8(play+0x20d8+0xe304),post?mr32(post+4):0,post?rf(post+0x90):0,postTalk,postClosed);printf("NO_BOSS f=%u scene=%x room=%d player=%.0f,%.0f,%.0f lists=%x/%x\n",f,DebugMemRead16(play+0xa4),(int)(signed char)DebugMemRead8(play+0x11cbc),rf(player+0x24),rf(player+0x28),rf(player+0x2c),mr32(play+0x1c34+9*8),mr32(play+0x1d3c));bank();}if(f>900){puts("ASSERT_FAILED missing boss");exit(96);}return;}
 action=mr32(boss+0x180);bird=target(0x72,0x7502);bomb=actor(0x10);
 if(action!=lastAction){printf("BOSS f=%u action=%x state=%d timer=%d xyz=%.0f,%.0f,%.0f mouth=%.0f,%.0f,%.0f\n",f,action,DebugMemRead16(boss+0x18c),DebugMemRead16(boss+0x1ca),rf(boss+0x24),rf(boss+0x28),rf(boss+0x2c),rf(boss+0x40c),rf(boss+0x410),rf(boss+0x414));lastAction=action;}
 if(bird){if(!seenBird){bank();}seenBird=1;}
 if((DebugMemRead8(0x80126e90+0x3534)==111)&&(DebugMemRead8(0x80126e90+0x3530)&0x80))seenTheme=1;
 if(action==bossfunc(0x808a3950))seenInhale=1;
 if(action==bossfunc(0x808a338c)&&seenInhale)swallowed=1;
 if(action==bossfunc(0x808a5c40))seenDeath=1;
 if(!seenBird&&!seenDeath){
  if(f>600&&DebugMemRead8(play+0x1d6c)==0){
   float x=rf(boss+0x24),z=rf(boss+0x2c);double yaw=DebugMemRead16(boss+0xb6)*6.283185307179586/65536.;position(player,x+sin(yaw)*210,-1523.76f,z+cos(yaw)*210,(int)(DebugMemRead16(boss+0xb6)+32768));
   if(!bomb&&f%70<3){value=0x200;printf("THROW_ATTEMPT f=%u subcam=%d C=%u ammo=%u bg=%x\n",f,(int16_t)DebugMemRead16(boss+0x1a4),DebugMemRead8(savebase+0x69),DebugMemRead8(savebase+0x8e),DebugMemRead16(player+0x88));}
   if(bomb){if(!bombBirth)bombBirth=f;if(mr32(bomb+0x118)){if(f>bombBirth+15&&f%10<2)value=0x80;}else if(action==bossfunc(0x808a3950)){position(bomb,rf(boss+0x40c),rf(boss+0x410),rf(boss+0x414),0);wf(bomb+0x60,0);wf(bomb+0x6c,0);}}
   else bombBirth=0;
  }
 }
 if(plain&&swallowed&&f%30==0){need(!seenBird&&!seenDeath&&!seenTheme,"without rescue boss remains vanilla");bank();puts("PIEPS_QA_PASSED native bomb swallow without rescue");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(!plain&&seenDeath&&DebugMemRead16(boss+0x18c)==100){
  unsigned post=target(0x72,0x7503),msg=play+0x20d8;static unsigned waitingPost=0;if(!post||!mr32(post+0x134)){if(!waitingPost)waitingPost=f;need(f<waitingPost+180,"post-boss bird finishes native initialization");if(buttons)buttons(0);return;}
  if(f>done+30&&done){position(player,rf(post+0x24)-25,rf(post+0xc)-12,rf(post+0x2c)+42,27000);if(f%18<4)value=0x80;}
  if(DebugMemRead16(msg+0xe2f8)==0x723b&&DebugMemRead8(msg+0xe304))postTalk=1;
  if(postTalk&&DebugMemRead16(post+0x18c)==2&&!DebugMemRead8(msg+0xe304))postClosed=1;
  if(!done){bank();need(seenBird&&swallowed&&seenTheme&&!bird,"assisted bomb swallow and native death without lingering bird");need(actor(0x5f)&&actor(0x5d),"native heart container and exit warp");need(mr32(play+0x1d3c)&2,"native room clear flag");done=f;}
  if(f>done+100&&postClosed){need((DebugMemRead8(0x80126e90+0x3534)==111),"theme persists after boss clear");need(!(mr32(player+0x66c)&0x20000000),"player control restored");puts("PIEPS_QA_PASSED assisted boss; native heart, warp, clear, control, music; post-boss conversation723B completed");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(f%200==0){unsigned post=target(0x72,0x7503);printf("POST bird=%x state=%u text=%x mode=%u flags=%x xz=%.1f talk=%u closed=%u\n",post,post?DebugMemRead16(post+0x18c):0,DebugMemRead16(play+0x20d8+0xe2f8),DebugMemRead8(play+0x20d8+0xe304),post?mr32(post+4):0,post?rf(post+0x90):0,postTalk,postClosed);printf("BOSS_STATE cs=%u room=%u done=%u\n",DebugMemRead16(boss+0x18c),DebugMemRead8(play+0x11cbc),done);printf("TRACE f=%u boss=%x act=%x bird=%x bomb=%x par=%x inhale=%u swallow=%u death=%u theme=%u playerflags=%x\n",f,boss,action,bird,bomb,bomb?mr32(bomb+0x118):0,seenInhale,swallowed,seenDeath,seenTheme,mr32(player+0x66c));}
 if(buttons)buttons(value);if(f>4600){puts("PIEPS_QA_TIMEOUT boss");exit(96);}
}

static void piepsframe(unsigned f){if(strstr(scenario,"boss"))bossframe(f);else cageframe(f);}int main(int argc,char**argv){setbuf(stdout,0);platform=&test;for(auto name:{"pif.pal.rom","pif.ntsc.rom","pif.sm5.rom"})test.sys->append(name,file::read({"/tmp/emulator-compat-v107/ares148/mia/Firmware/Nintendo 64/",name}));test.cart->append("program.rom",file::read(argv[1]));test.cart->append("save.ram",file::read(argv[2]));test.cart->setAttribute("title","V108 compatibility");test.cart->setAttribute("region","PAL");test.cart->setAttribute("cic","CIC-NUS-7105");Node::System root;N::option("Enable GPU acceleration","true");N::option("Expansion Pak","false");N::option("Recompiler","true");if(!N::load(root,"[Nintendo] Nintendo 64 (PAL)"))return 2;auto p=root->find<Node::Port>("Cartridge Slot");p->allocate();p->connect();p=root->find<Node::Port>("Controller Port 1");p->allocate("Gamepad");p->connect();root->power(false);scenario=argc>3?argv[3]:"ares-pieps-rescue";snapshotfile=nullptr;bool injected=false;unsigned ageFrames=0;
 savebase=0x8011bb00;overlays=0x800e8a00;buttons=[](unsigned b){test.buttons=b;};for(unsigned i=0;i<26000&&!compatDone;i++){root->run();test.frames=i+1;
 if(!injected){nativeframe(i);if(laststate==0x20206){test.buttons=0;unsigned blocks=0;while((uint32_t)N::cpu.ipu.pc!=0x8009c900){if(N::cpu.instruction())N::cpu.synchronize();N::vi.refreshed=false;if(++blocks>200000000){puts("ARES_PLAY_BOUNDARY_TIMEOUT");return 98;}}
 const char* fixture=std::strstr(scenario,"boss")?"/tmp/pieps-recheck-v107/story-normal-boss-assisted-retry/boss-assisted.save":"/tmp/pieps-recheck-v107/story-normal-cage-rescue/cage-rescue.save";
 auto data=file::read(fixture);if(data.size()!=0x1428)return 97;for(unsigned j=0;j<data.size();j++)DebugMemWrite8(savebase+j,data[j]);play=player=0;injected=true;printf("ARES_FIXTURE_AT_NATIVE_PLAY_INIT pc=%llx blocks=%u fixture=%s\n",(unsigned long long)N::cpu.ipu.pc,blocks,fixture);}}
 else piepsframe(340+ageFrames++);}
 printf("ARES_AUDIO samples=%llu nonzero=%llu peak=%.6f\n",(unsigned long long)test.audioSamples,(unsigned long long)test.nonzeroSamples,test.audioPeak);root->unload();puts("ARES_NATIVE_TEST_DONE");return compatDone?0:95;}

from pathlib import Path
import os,subprocess,json,concurrent.futures,shutil,ctypes,hashlib
W=Path(__file__).resolve().parent;G=W/'squashfs-root/shared/lib/RMG/Plugin';cases=json.loads((W/'sram-cases.json').read_text());cases=[dict(c,backend='glide')for c in cases if c['scene']!=1]+[dict(cases[0],backend='angry'),dict(next(c for c in cases if c['scene']==8),backend='angry')]
base=dict(os.environ,DISPLAY=':99',XDG_DATA_HOME=str(W/'data'),XDG_CONFIG_HOME=str(W/'global-config'),XDG_CACHE_HOME=str(W/'cache'),MESA_SHADER_CACHE_DIR=str(W/'mesa'),CREDITS_AUDIO_PATH='/dev/null',LD_LIBRARY_PATH=str(W/'rmg-libs'),COMPAT_CPU='2',LP_NUM_THREADS='2')
def one(c):
 tag=c['tag']+'-'+c['backend'];config=W/('config-'+tag);config.mkdir(exist_ok=True)
 for p in (W/('config-'+c['tag'])).glob('*.sra'):shutil.copy(p,config/p.name)
 env=dict(base);env.update(COMPAT_RSP=str(G/('RSP/mupen64plus-rsp-cxd4.so'if c['backend']=='angry'else'RSP/mupen64plus-rsp-hle.so')),COMPAT_GFX=str(G/('GFX/mupen64plus-video-angrylion-plus.so'if c['backend']=='angry'else'GFX/mupen64plus-video-GLideN64.so')))
 log=W/('rmg090-'+tag+'.log')
 try:
  with log.open('w')as f:r=subprocess.run([str(W/'sram'),'/tmp/emulator-compat-v108/normal.z64',tag,'12000','4','0x8011bb00','0x800e8a00'],env=env,stdout=f,stderr=subprocess.STDOUT,timeout=240)
  txt=log.read_text();ok=r.returncode==0 and'COMPAT_SRAM_PASSED'in txt and f"scene={c['scene']:x} age={c['age']} pause=1"in txt
  result=dict(c,passed=ok,returncode=r.returncode,log=log.name,tail=txt[-1300:])
 except subprocess.TimeoutExpired:result=dict(c,passed=False,timeout=True,log=log.name)
 print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:r=list(pool.map(one,cases))
(W/'rmg-native-results.json').write_text(json.dumps(r,indent=2))

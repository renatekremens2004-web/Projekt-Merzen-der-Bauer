from pathlib import Path
import json,hashlib,re,shutil,zipfile
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/naboo');A=Path('/workspace/artifacts');D=Path('/workspace/bean-download-delivery')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
verify=json.loads((O/'build/pal-1.0/naboo-verification.json').read_text());h=verify['rom_sha256'];assert h==json.loads((W/'patch-verification.json').read_text())['target_sha256']
V=R/'validation/naboo';P=R/'previews/naboo';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True)
logs={}
for topic in ['view','worst-still','before','after']:
 p=W/f'naboo-{topic}-final-direct-clip-on.log';s=p.read_text();assert h in s and 'completed: 0'in s and 'RAM=4194304'in s,p
 assert not any(x in s for x in ['OVERFLOW','GFX_POOL_CORRUPT','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 assert all(int(n)==0 for n in re.findall(r'HEAP f=\d+ failures=(\d+)',s));logs[topic]=s;shutil.copyfile(p,V/p.name)
assert 'id=507b'in logs['before']and'id=507c'in logs['after']
heap=min(map(int,re.findall(r'largest=(\d+)',logs['worst-still'])));assert heap>=50000
runtime=dict(rom_sha256=h,actual_ram_bytes=4194304,native_allocation_failures=0,worst_room_largest_free_arena_bytes=heap,room_buffer_bytes=162672,previous_room_buffer_bytes=259680,cases=list(logs),dialogue_ids=['507B','507C'])
(W/'runtime-verification.json').write_text(json.dumps(runtime,indent=2)+'\n')
for n in ['prepare_runtime.py','runner.c','run.py','runtime-verification.json','verification.log','model.json','check_patch.js','patch-verification.json','package.py']:shutil.copyfile(W/n,V/n)
shutil.copyfile(O/'build/pal-1.0/naboo-verification.json',V/'naboo-verification.json')
root=Path('/workspace/bean-rider/screens-naboo-view-final-direct-clip-on');shutil.copyfile(root/'the_legend_of_zelda-002.png',P/'Naboo_Starfighter_Ingame.png')
# Select dialogue screenshot indices after visual review; source images stay unaltered.
for topic,idx in json.loads((W/'selected-images.json').read_text()).items():shutil.copyfile(Path('/workspace/bean-rider')/f'screens-naboo-{topic}-final-direct-clip-on'/f'the_legend_of_zelda-{idx:03d}.png',P/('Kakariko_'+topic+'.png'))
(P/'Aufnahmen.json').write_text(json.dumps(dict(rom_sha256=h,unaltered_emulator_images=True,model_frame=400,dialogue_frames=json.loads((W/'selected-images.json').read_text())),indent=2)+'\n')
doc=f'''# LEGO Naboo-Starfighter statt X-Wing

Kumulativer Gesamtpatch auf unveränderte Europa/PAL 1.0. Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`; Ziel-SHA256 `{h}`. Alle bisherigen Änderungen einschließlich Kenny und Stiefelkürzeln enthalten.

Der LEGO-X-Wing im Schattentempel wurde vollständig durch den vom Nutzer gelieferten LEGO-Naboo-Starfighter ersetzt. Gleicher Standort am Boden in Raum 0, keine zusätzliche Kollision, Actor- oder Objekt-ID. Der alte gXWingDL ist im fertigen Build nicht vorhanden. Native Raumgeometrie, Türen, Fallen, Wege, Licht, Nebel und Tiefentest bleiben erhalten.

Spielzeug mit natürlichen Proportionen: 36 Spieleinheiten lang, 19,24 breit und 5,47 hoch. Die importierten 116.755 Dreiecke wurden durch Vereinigung überlappender Bausteinschalen und anschließende Reduktion auf 1.400 Dreiecke reduziert. Gelb, Silber, dunkler Cockpitbereich und ursprüngliche Silhouette stammen aus den Materialfarben der Nutzerdatei. Keine Textur benötigt. Original-OBJ-SHA256: `52ea7c943a792ac9dcc908350e52bdb6d86dec95f8e5a3ab238ebf6cd27fb9a3`.

Kakariko-NPC, deutsche Nachrichten **507B und 507C**:

„Scheiße, ich hab' meinen Lego Naboo-Starfighter im Schattentempel liegen lassen!“

Zweite Seite bleibt: „Und die Bauanleitung ist natürlich auch noch drin!“

Manueller Seitenwechsel und Lesetempo unverändert. Beide Fortschrittsvarianten im Emulator durch natürliches Ansprechen getestet. Alle anderen bisherigen Dialoge in allen drei PAL-Sprachen als Quelle und kompiliert unverändert. Keine neuen Nachrichten-IDs.

Vier gezielte Emulatorproben mit echten 4 MiB RAM: Starfighter vor Ort, speicherkritischer Raum 9, Kakariko vor/nach Schattenamulett. Keine fehlgeschlagene native Speicherbelegung oder Grafikpufferfehler. Größte freie zusammenhängende Arena-Fläche im kritischen Raum mindestens {heap:,} Byte. Gemeinsamer Raumpuffer sinkt von 259.680 auf 162.672 Byte; Objektpuffer bleibt unverändert. Sämtliche 1.512 komprimierten Segmente und CIC-6105-Prüfsumme geprüft. 3.664 Kernsymbole unverändert bzw. ausschließlich durch Linker-Relokationen angepaßt. Nur deutsche Nachrichten 507B/C und Raum-0-Darstellung geändert. RomPatcher.js mit Quellvalidierung liefert exakt die geprüfte Ziel-ROM. Kein vollständiger Durchlauf oder Hardwaretest.

**Baufolge:** `tools/build_naboo.py` unbedingt als letzten Builder **nach build_kenny.py** ausführen; ältere Builder stellen Zwischenstände wieder her. Beispiel: `python3 tools/build_naboo.py /pfad/zur/oot-decomp`, dann regulär bauen und komprimieren. Vorbereitete `tools/naboo_source.json` reicht für diesen Bau. Optionaler Neu-Export des Nutzer-OBJ/MTL mit Blender und `tools/export_naboo.py <Arbeitsordner>`; Upload unter input/LEGO_NabooShip. Der Export benötigt die ursprünglichen Nutzerdateien. Nativer Raum-Ausgangszustand unter tools/originals/xwing im Quellenpaket enthalten.

Quellenpaket enthält keinen ROM, Spielstand, Savestate, RAM-Abzug oder ausführbares Programm. Bilder sind unveränderte echte Emulatoraufnahmen des Ziel-Builds.
'''
(R/'TESTING_NABOO.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Naboo_Starfighter.bps';shutil.copyfile(patch,R/'patches'/patch.name)
heading='# LEGO Naboo-Starfighter';p=R/'README.md';p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Prüfung](TESTING_NABOO.md) · [Bilder](previews/naboo/)\n\nErsetzt den LEGO-X-Wing im Schattentempel und paßt Kakariko 507B/507C an. Alle bisherigen Änderungen enthalten. Letzter Builder build_naboo.py nach build_kenny.py.\n\n'+p.read_text())
archive=A/'Merzen_Naboo_Starfighter_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in['water-comic-heroes','ben-ice','jabba','bttf','kenny','xwing']and(p.suffix in['.c','.h']or rel.parts[-2:]==('spec','spec'))
  if not p.is_file()or(any(q in exclude for q in rel.parts)and not original)or(p.suffix.lower()not in suffixes and not original):continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='naboo':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.o','.so','.st','.exe','.mp4','.glb'}for n in z.namelist());assert 'tools/originals/xwing/extracted/pal-1.0/assets/scenes/dungeons/HAKAdan/HAKAdan_room_0.c'in z.namelist()
instruction=A/'Anleitung_Naboo_Starfighter.txt';instruction.write_text('Kumulativer Gesamtpatch: Naboo-Starfighter ersetzt X-Wing, Kakariko-Text angepaßt. Alle bisherigen Änderungen enthalten.\n\nBPS mit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände laden; alte Emulator-Savestates vermeiden. Deutsche Sprachfassung.\n')
for p in [patch,archive,instruction]:shutil.copyfile(p,D/p.name)
G=D/'Naboo_Starfighter_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
files=[D/p.name for p in[patch,archive,instruction]];sums=D/'SHA256SUMS_Naboo_Starfighter.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files));files.append(sums)
p=D/'README.md';p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Bilder und Prüfung](Naboo_Starfighter_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nNaboo-Starfighter ersetzt den X-Wing im Schattentempel, zugehöriger Kakariko-Text angepaßt. Alle bisherigen Änderungen enthalten. Auf unveränderte Vanilla PAL 1.0 anwenden. Vier gezielte Proben mit 4 MiB, kein vollständiger Durchlauf.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=h,files=[p.name for p in files],runtime=runtime),indent=2)+'\n');print('Packaged Naboo',h,'source bytes',archive.stat().st_size)

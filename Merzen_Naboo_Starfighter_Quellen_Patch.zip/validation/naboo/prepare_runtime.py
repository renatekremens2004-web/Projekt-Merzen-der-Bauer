from pathlib import Path
import re,json,subprocess,shutil
W=Path('/workspace/naboo');O=Path('/workspace/oot-burns-pal')
def syms(p):return {n:int(a,16)for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\s*$',p.read_text(),re.M)}
a=syms(W/'baseline/build/pal-1.0/oot-pal-1.0.map');b=syms(O/'build/pal-1.0/oot-pal-1.0.map');(W/'symbols.json').write_text(json.dumps(b))
s=Path('/workspace/kenny/runner.c').read_text().replace('xwing-photo','view')
for n in ['gGameStateOverlayTable','sZeldaArena','gObjectTable']:s=re.sub('0x'+format(a[n],'x')+r'\b',hex(b[n]),s)
(W/'runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
for src,dst in [('kenny/xwing-photo.save','view.save'),('kenny/worst-still.save','worst-still.save'),('xwing/npc.save','before.save'),('xwing/npc-after.save','after.save')]:shutil.copyfile('/workspace/'+src,W/dst)
s=Path('/workspace/kenny/run.py').read_text().replace('/workspace/kenny','/workspace/naboo').replace("case='kenny-'","case='naboo-'")
(W/'run.py').write_text(s)

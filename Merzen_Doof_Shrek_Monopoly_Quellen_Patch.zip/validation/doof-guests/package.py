from pathlib import Path
import hashlib
import json
import re
import shutil
import zipfile

R = Path('/workspace/Projekt-Merzen-der-Bauer')
O = Path('/workspace/oot-burns-pal')
W = Path('/workspace/doof-guests')
D = Path('/workspace/bean-download-delivery')
A = Path('/workspace/artifacts')

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

v = json.loads((O / 'build/pal-1.0/doof-guests-verification.json').read_text())
h = v['rom_sha256']
assert h == sha(O / 'build/pal-1.0/oot-pal-1.0-compressed.z64')
assert h == json.loads((W / 'patch-verification.json').read_text())['target_sha256']
V = R / 'validation/doof-guests'
P = R / 'previews/doof-guests'
V.mkdir(parents=True, exist_ok=True)
P.mkdir(parents=True, exist_ok=True)
topics = ['doof-child', 'doof-adult', 'shrek', 'monopoly', 'shrek-adult-still', 'monopoly-child-still', 'doof-adult-night-still']
logs = {}
for topic in topics:
    case = 'doof-' + topic + '-hatless-direct-clip-on'
    p = W / (case + '.log')
    s = p.read_text()
    assert h in s and 'completed: 0' in s and 'RAM=4194304' in s, p
    assert not any(q in s for q in ['OVERFLOW', 'GFX_POOL_CORRUPT', 'UNKNOWN GBI COMMAND', 'Using Vertex outside buffer'])
    assert set(re.findall(r'HEAP .*failures=(\d+)', s)) == {'0'}, p
    assert all(x == '1234' and y == '5678' for x, y in re.findall(r'GFX_MAGIC .*head=(\w+) tail=(\w+)', s)), p
    logs[topic] = s
    shutil.copyfile(p, V / p.name)
for topic in ['doof-child', 'doof-adult']:
    s = logs[topic]
    assert 'NATIVE_FISHING_STARTED' in s and 'NATIVE_FISHING_ENDED' in s
    assert re.search(r'NATIVE_FISHING_STARTED .*rupees=79', s)
    assert re.search(r'NATIVE_FISHING_ENDED .*rupees=79', s)
assert 'id=71da' in logs['shrek'] and 'id=71db' in logs['monopoly']
assert set(re.findall(r'shrek=([0-9a-f]+)', logs['shrek-adult-still'])) == {'00000000'}
assert set(re.findall(r'monopoly=([0-9a-f]+)', logs['monopoly-child-still'])) == {'00000000'}
night_objects = re.findall(r'^DOOF_OBJECTS .*$', logs['doof-adult-night-still'], re.M)
assert night_objects and all(' 019e' in line and ' 019d' not in line for line in night_objects)
heap = min(map(int, re.findall(r'HEAP .*largest=(\d+)', '\n'.join(logs.values()))))
bank = min(map(int, re.findall(r'OBJECT_BANK.*remaining=(\d+)', '\n'.join(logs.values()))))
runtime = dict(
    rom_sha256=h, actual_ram_bytes=4194304, final_cases=topics,
    native_allocation_failures=0, minimum_largest_free_arena_bytes=heap,
    minimum_object_bank_free_bytes=bank, native_fishing_payment_start_and_quit_both_ages=True,
    german_cap_removed_and_theft_disabled=True,
    limitations='Targeted native-room probes with test saves, not a full playthrough or hardware test. Child test casts and reels but does not catch a fish. Rewards and record logic are source-differentially preserved, not earned end-to-end in these probes. No NPC or camera position is changed for screenshots; only the test player spawn is selected. No ROM, save, state or executable is distributed.'
)
(W / 'runtime-verification.json').write_text(json.dumps(runtime, indent=2) + '\n')
for name in ['prepare_runtime.py', 'runner.c', 'run.py', 'prepare_fishing.py', 'fishing-runner.c', 'run_fishing.py', 'runtime-verification.json', 'verification.log', 'check_patch.js', 'patch-verification.json', 'object_budget.py', 'object-budget.json', 'models.json', 'current_docs.py', 'package.py']:
    shutil.copyfile(W / name, V / name)
shutil.copyfile(O / 'build/pal-1.0/doof-guests-verification.json', V / 'doof-guests-verification.json')
images = [
    ('doof-child', 1, 'Doofenshmirtz_Kind_ohne_Muetze.png'),
    ('doof-adult', 1, 'Doofenshmirtz_Erwachsen_ohne_Muetze.png'),
    ('shrek', 0, 'Shrek_im_Wald.png'),
    ('shrek', 1, 'Shrek_Dialog.png'),
    ('monopoly', 0, 'Mr_Monopoly_im_Schloss.png'),
    ('monopoly', 1, 'Mr_Monopoly_Dialog.png'),
]
photos = []
for topic, index, name in images:
    case = 'doof-' + topic + '-hatless-direct-clip-on'
    src = Path('/workspace/bean-rider') / ('screens-' + case) / f'the_legend_of_zelda-{index:03d}.png'
    shutil.copyfile(src, P / name)
    photos.append(dict(file=name, source=str(src), rom_sha256=h, unaltered_emulator_image=True))
(P / 'Aufnahmen.json').write_text(json.dumps(photos, indent=2) + '\n')
doc = f'''# Doofenshmirtz, Shrek und Mr. Monopoly

Kumulativer Gesamtpatch für die unveränderte Europa/PAL-1.0-ROM. Original-MD5 `e040de91a74b61e3201db0e2323f768a`, Ziel-SHA256 `{h}`. Alle bisherigen Figuren, Räume und Dialoge enthalten. Deutsche Sprache wählen und BPS mit RomPatcher.js anwenden.

## Eingebaut

Der native Angelteich-Betreiber wird in der deutschen Kindheitszeit durch den normalen Dr. Heinz Doofenshmirtz ersetzt. Er erzählt von seiner Kindheit, dem Angelverbot, den Jauchegruben und dem Angelinator. Als Erwachsener begegnet man seiner ernsteren Augenklappen-Version mit düsteren Texten über Merz’ soziale und ökologische Politik. Zusammenhängende eigene Dialoge; Herkunft und Figurenstimme wurden anhand der in story/DOOFENSHMIRTZ_NOTIZEN.md verlinkten Quellen recherchiert. Keine vorgeblichen Serien-Zitate.

Auf ausdrücklichen Nutzerwunsch trägt Doofenshmirtz keine Angelmütze. Sein deutscher Haarzustand schaltet zugleich den alten Mützenklau ab, damit kein unsichtbares Zubehör am Haken landet. Bestehende Rekord-/Mützenbits in Spielständen werden nicht gelöscht. Englisch und Französisch behalten das native Anglermodell und das ursprüngliche Mützensystem.

Das eigentliche Angelspiel läuft weiterhin über denselben Fishing-Akteur: 20 Rubine, Fischbestand, Steuerung, Wiegen, Rekorde, Herzteil und goldene Schuppe behalten ihre ursprünglichen Regeln. Keine globale Minispiel-Umschreibung. Das altersabhängige Modell wird jeweils über den nativen Raumheader geladen; die andere Doof-Version liegt nicht zusätzlich im Objektpuffer.

Shrek steht als ansprechbarer NPC ausschließlich in der Kindheitszeit am trockenen Ufer in Raum 3 der Verlorenen Wälder. Er beschwert sich über Merz’ Pläne für seinen Wald. Mr. Monopoly steht als ansprechbarer NPC seitlich der Haupthalle in Merz’ letztem Schloß, ausschließlich als Erwachsener. Er verteidigt Kapitalismus und erklärt, weshalb die menschliche Gier auch einen besiegten Herrscher überlebt. Beide stehen außerhalb der Wege und Türen. Kleine Kopf- und Handbewegungen, entspannte Arme, eigene unverzerrte Proportionen und native Beleuchtung.

29 bestehende deutsche Nachrichten überarbeitet und 21 private Textplätze ergänzt; insgesamt 1.154 eigene Nachrichten. Die reservierten Mützenzeilen 4087/4097/40B2/71D0 sind in der deutschen Fassung nicht mehr regulär erreichbar. Feste Original-Lesezeiten, Antwortreihenfolgen, Ereignisse und dynamische Fischgewichte erhalten. [Aktive Dialoge](planning/Dialoge_Doof_Shrek_Monopoly.md).

## Modelle und Speicher

| Modell | Dreiecke | Höhe in Spieleinheiten | Objektbytes |
| --- | ---: | ---: | ---: |
| Doofenshmirtz | 374 | 78 | 23.600 |
| Augenklappen-Doof | 564 | 82 | 35.296 |
| Shrek | 442 | 86 | 15.584 |
| Mr. Monopoly | 900 | 64 | 29.248 |

Monopoly wurde von 1.415 auf 900 Dreiecke reduziert. Seine 400 oberen Kopf-/Gesichtsdreiecke bleiben unverändert, der Körper wurde vereinfacht. Ungültige Normalen und 36 UV-Ecken des gelieferten Augenklappen-Modells wurden repariert; die fehlende lambert1-Textur durch die Materialfarbe ersetzt. Alle Texturen höchstens 64×64 in CI4. Vier einfache starre Animationsgruppen je Figur, keine zusätzlichen globalen Animationspuffer.

Der native Objektpuffer bleibt 1.019.904 Byte groß. Berechnete Raumbelegung einschließlich Link und Grundobjekten: Kind-Angelteich 709.680 Byte / 6 Plätze; Erwachsenen-Angelteich 764.512 / 6; Shrek-Raum 799.200 / 15; Schloßhalle 831.680 / 9. Kein vergrößerter Speicherpool, kein vorausgesetztes Expansion Pak.

## Geprüft

PAL-Build und Kompression erfolgreich. 1.524 komprimierte Segmente, CIC-6105-Prüfsumme und 3.664 native Kernsymbole differential geprüft. Alle bisherigen Nachrichten außerhalb der 29 freigegebenen deutschen Änderungen bytegleich; neue private Tabellenplätze in allen drei Sprachen geprüft. Alle 1.154 eigenen Texte passen in die nativen Rohtext- und Zeilenpuffer, einschließlich langer Spielernamen und Fischgewicht. Bestehende Gäste-/Stiefelfunktionen erhalten. Native Raumgeometrie und alle übrigen Raumobjekte unverändert oder ausschließlich durch echte Linker-Relokationen verschoben.

Sieben gezielte Proben der finalen Ziel-ROM mit echten 4 MiB: Doofenshmirtz als Kind und Erwachsener jeweils vom Gespräch über die Abbuchung von 20 Rubinen und den nativen Angelstart bis zum normalen Aufhören; Shreks gesamtes Gespräch; Monopolys gesamtes Gespräch; Shrek als Erwachsener abwesend; Monopoly als Kind abwesend; richtige Augenklappen-Version auch nachts. Die Kindprobe wirft die Leine aus und holt sie ein. Es wurde dabei kein Fisch gefangen und keine Rekordbelohnung erspielt; deren Erhalt wird durch den Vergleich des unveränderten Spielcodes belegt. Keine fehlgeschlagenen Speicherbelegungen, Grafikpufferüberläufe oder beschädigten GfxPool-Marken. Kleinste gemessene zusammenhängende Arena-Reserve {heap:,} Byte, kleinste Objektpufferreserve {bank:,} Byte. Kein vollständiger Spieldurchlauf oder Hardwaretest.

Die Bilder stammen ausschließlich von der finalen Ziel-ROM und sind unveränderte Emulatorbilder. Produktions-NPCs und native Kameras wurden für die Bilder nicht versetzt. Eine seitliche Testansicht des Angelteichs zeigte schon im vorherigen Patch mit dem ursprünglichen Angler dieselbe schwarze Dreiecksfläche; die dünnen Linien an der Wand sind aufgehängte Angeln. Die verwendete normale Anspracheposition zeigt die saubere Ansicht. Das ist keine Aussage, daß sämtliche früher besprochenen schwarzen Flächen im gesamten Spiel untersucht oder behoben seien.

BPS mit RomPatcher.js und aktiver Quellvalidierung auf die Vanilla-ROM angewandt: Ergebnis bytegleich zur geprüften finalen ROM.

## Reproduzieren

Nach den bisherigen Modell-/Raum-Buildern zuletzt `build_desert_guests.py`, `build_gerudo_dialogue.py`, `build_twinrova_title.py`, dann `build_doof_guests.py` ausführen. Anschließend normaler PAL-1.0-Build und Kompression. Der optionale Modell-Reexport erfolgt über `blender -b --python tools/export_doof_guests.py -- ARBEITSVERZEICHNIS` mit den entpackten Quelldateien unter dessen input-Verzeichnis. Die fertigen Modell-JSONs und Texturen sind im Quellenpaket enthalten, deshalb benötigt der normale Build keinen erneuten Blender-Import.

Quellenpaket ohne ROM, Save, Savestate, ELF, RAM-Abzug oder ausführbare Dateien. Prüfproben verwenden eigene Testspielstände und direkte Raumeinstiege; sie ersetzen keinen normalen Durchlauf.
'''
(R / 'TESTING_DOOF_GUESTS.md').write_text(doc)
(P / 'Pruefbericht.md').write_text(doc.replace('(planning/', '(../../planning/'))
patch = A / 'Mr_Burns_Mr_Bean_DE_PAL10_Doof_Shrek_Monopoly.bps'
shutil.copyfile(patch, R / 'patches' / patch.name)
heading = '# Doofenshmirtz, Shrek und Mr. Monopoly'
p = R / 'README.md'
s = p.read_text()
prefix = heading + '\n\n[Gesamtpatch](patches/' + patch.name + ') · [Dialoge](planning/Dialoge_Doof_Shrek_Monopoly.md) · [Prüfung](TESTING_DOOF_GUESTS.md)\n\nAlle früheren Änderungen enthalten. Doofenshmirtz ersetzt den Angler in beiden Zeitlinien, ohne Mütze. Shrek im Kinderwald; Mr. Monopoly im letzten Schloß. Letzter Builder: build_doof_guests.py.\n\n'
if not s.startswith(heading):
    p.write_text(prefix + s)
archive = A / 'Merzen_Doof_Shrek_Monopoly_Quellen_Patch.zip'
suffixes = {'.md', '.py', '.json', '.c', '.h', '.txt', '.png', '.bps', '.fbx', '.js', '.cfg', '.jpeg', '.jpg', '.log', '.dae', '.obj', '.smd', '.mtl'}
exclude = {'.git', 'originals', 'downloads', 'build', 'baseroms', '__pycache__', '.codex', '.agents', '.aws'}
original_dirs = {'water-comic-heroes', 'ben-ice', 'jabba', 'bttf', 'kenny', 'xwing', 'mystery-inc', 'mystery-machine', 'desert-guests', 'gerudo-dialogue', 'twinrova-dialogue', 'doof-guests'}
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for p in sorted(R.rglob('*')):
        rel = p.relative_to(R)
        original = rel.parts[:3] == ('tools', 'originals', 'character_sizes') and p.suffix == '.c'
        original |= rel.parts[:3] == ('tools', 'originals', 'water_spirit_sages') and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c', 'gChamberOfSagesSealOpeningCs.csdata.inc.c']
        original |= len(rel.parts) >= 3 and rel.parts[:2] == ('tools', 'originals') and rel.parts[2] in original_dirs and (p.suffix in ['.c', '.h', '.png'] or rel.parts[-2:] == ('spec', 'spec'))
        if not p.is_file() or (any(q in exclude for q in rel.parts) and not original) or (p.suffix.lower() not in suffixes and not original):
            continue
        if rel.parts[0] == 'patches' and p.name != patch.name:
            continue
        if rel.parts[0] == 'previews' and len(rel.parts) > 1 and rel.parts[1] != 'doof-guests':
            continue
        with p.open('rb') as f:
            assert f.read(4) not in [bytes.fromhex(x) for x in ['80371240', '37804012', '40123780', '7f454c46']]
        z.write(p, rel)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any(Path(n).suffix.lower() in {'.z64', '.n64', '.v64', '.rom', '.bin', '.save', '.sav', '.sra', '.eep', '.fla', '.elf', '.o', '.so', '.st', '.exe', '.mp4', '.glb'} for n in z.namelist())
    assert 'tools/build_doof_guests.py' in z.namelist()
instruction = A / 'Anleitung_Doof_Shrek_Monopoly.txt'
instruction.write_text('Kumulativer Gesamtpatch mit sämtlichen bisherigen Änderungen. Neu: Dr. Doofenshmirtz statt Angler in beiden Zeitlinien (ohne Mütze), Shrek im Kinderwald und Mr. Monopoly in Merz’ Schloß.\n\nMit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden, nicht auf eine bereits gepatchte ROM. Original-MD5 e040de91a74b61e3201db0e2323f768a. Deutsche Sprache wählen. Normale Spielstände verwenden, alte Savestates nicht übernehmen. Ziel-SHA256 ' + h + '\n\nGezielte Szenenproben mit echten 4 MiB; kein vollständiger Spieldurchlauf oder Hardwaretest.\n')
for p in [patch, archive, instruction]:
    shutil.copyfile(p, D / p.name)
G = D / 'Doof_Shrek_Monopoly_Beispielbilder'
G.mkdir(exist_ok=True)
for p in P.iterdir():
    shutil.copyfile(p, G / p.name)
(G / 'Pruefbericht.md').write_text(doc.replace('(planning/', '(../'))
files = [D / p.name for p in [patch, archive, instruction]] + [D / 'Dialoge_Doof_Shrek_Monopoly.md']
sums = D / 'SHA256SUMS_Doof_Shrek_Monopoly.txt'
sums.write_text(''.join(sha(p) + '  ' + p.name + '\n' for p in files))
files.append(sums)
p = D / 'README.md'
s = p.read_text()
prefix = heading + '\n\n[Gesamtpatch](' + patch.name + '?raw=true) · [Dialoge](Dialoge_Doof_Shrek_Monopoly.md) · [Beispielbilder](Doof_Shrek_Monopoly_Beispielbilder/) · [Quellen](' + archive.name + '?raw=true)\n\nAlle früheren Änderungen enthalten. Doofenshmirtz ersetzt den Angler in beiden Zeitlinien, ohne Mütze. Shrek im Kinderwald; Mr. Monopoly im letzten Schloß. Auf unveränderte Vanilla PAL 1.0 anwenden. Sieben gezielte Szenenproben mit echten 4 MiB; kein vollständiger Spieldurchlauf.\n\n'
if not s.startswith(heading):
    p.write_text(prefix + s)
(W / 'package-manifest.json').write_text(json.dumps(dict(rom_sha256=h, files=[p.name for p in files], runtime=runtime), indent=2) + '\n')
print('Packaged', h, 'source archive', archive.stat().st_size)

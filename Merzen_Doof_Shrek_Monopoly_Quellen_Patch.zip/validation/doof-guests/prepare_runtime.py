from pathlib import Path
import re,json,struct,subprocess
W=Path('/workspace/doof-guests');O=Path('/workspace/oot-burns-pal')
def syms(p):
 d={}
 for a,n in re.findall(r'0x([0-9a-f]+)\s+([A-Za-z_]\w*)\b',p.read_text()):d.setdefault(n,int(a,16))
 return d
a=syms(Path('/workspace/intro-dialogue/baseline/build/pal-1.0/oot-pal-1.0.map'));b=syms(O/'build/pal-1.0/oot-pal-1.0.map');(W/'symbols.json').write_text(json.dumps(b))
s=Path('/workspace/desert-guests/runner.c').read_text()
for name in ['gGameStateOverlayTable','sZeldaArena','gObjectTable']:s=re.sub('0x'+format(a[name],'x')+r'\b',hex(b[name]),s)
s=s.replace('obj<0x19d','obj<0x1a1')
needle='  if(strstr(scenario,"still"))value=0;'
s=s.replace(needle,needle+r'''
  if(f%50==0){
   uint32_t shrek=actor_type(0x173,16),mono=actor_type(0x173,17),owner=actor_type(0xfe,1);
   printf("DOOF_GUEST f=%u shrek=%08x monopoly=%08x owner=%08x shrekFloor=%.1f monoFloor=%.1f ownerState=%d ownerY=%.1f rupees=%d highscore=%08x choice=%u\n",f,shrek,mono,owner,shrek?rf(shrek+0x80):0,mono?rf(mono+0x80):0,owner?(int16_t)DebugMemRead16(owner+0x14c):0,owner?rf(owner+0x28):0,(int16_t)DebugMemRead16(savebase+0x34),r32(savebase+0xec0),DebugMemRead8(m+0xe3e5));
   uint32_t ctx=play+0x117a4;printf("DOOF_OBJECTS f=%u",f);
   for(int i=0;i<DebugMemRead8(ctx+8)&&i<19;i++)printf(" %04x",DebugMemRead16(ctx+12+i*0x44));puts("");
  }
''');(W/'runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
base=Path('/workspace/desert-guests/desert-marty.save').read_bytes();cases={
'shrek':(0x11e,3,(1620,0,-850),16384,1,1200),
'monopoly':(0x467,1,(475,150,20),16384,0,1600),
'doof-child':(0x45f,0,(80,0,1190),14080,1,2900),
'doof-adult':(0x45f,0,(80,0,1190),14080,0,2900),
'doof-adult-first-still':(0x45f,0,(80,0,1190),14080,0,400),
'doof-adult-night-still':(0x45f,0,(80,0,1190),14080,0,350),
'shrek-adult-still':(0x11e,3,(1620,0,-850),16384,0,400),
'monopoly-child-still':(0x467,1,(475,150,20),16384,1,400)}
for name,(entrance,room,pos,yaw,age,limit)in cases.items():
 x=bytearray(base);struct.pack_into('>III',x,0,entrance,age,0);struct.pack_into('>I',x,0x1360,0);struct.pack_into('>I',x,0x1364,1);struct.pack_into('>fffhHhB',x,0x1368,*pos,yaw,0xdff,entrance,room);x[0x1409]=1;x[0x13e2:0x13e7]=bytes(5);x[0x137c:0x1384]=bytes(8);x[0x13fa:0x1402]=bytes(8);struct.pack_into('>HH',x,0x2e,0x60,0x60);struct.pack_into('>h',x,0x34,99);struct.pack_into('>I',x,0xec0,0x100 if name=='doof-adult'else 0)
 if name=='doof-adult-night-still':struct.pack_into('>H',x,0xc,0);struct.pack_into('>I',x,0x10,1)
 if age:struct.pack_into('>HH',x,0x70,0x1100,0);struct.pack_into('>H',x,0x9c,0x1100)
 (W/(name+'.save')).write_bytes(x)
(W/'limits.json').write_text(json.dumps({k:v[-1]for k,v in cases.items()}))
s=Path('/workspace/gerudo-dialogue/run.py').read_text().replace('/workspace/gerudo-dialogue','/workspace/doof-guests').replace("case='chapter-'","case='doof-'");s=s.replace('timeout=300','timeout=450');(W/'run.py').write_text(s)
print('Prepared eight native-room fixtures; no production NPC positions changed.')

from pathlib import Path
import subprocess,json
W=Path('/workspace/doof-guests');s=(W/'runner.c').read_text();needle='  if(f%50==0){\n   uint32_t shrek='
extra=r'''  if(DebugMemRead16(play+0xa4)==0x49 && !strstr(scenario,"still")){
   static unsigned began=0,ended=0;
   unsigned active=DebugMemRead8(play+0x10750);
   if(active && !began){began=f;printf("NATIVE_FISHING_STARTED f=%u rupees=%d\n",f,(int16_t)DebugMemRead16(savebase+0x34));}
   if(began && active){
    unsigned elapsed=f-began;
    if(elapsed<160){value=0;if(strstr(scenario,"child") && elapsed>=40 && elapsed<44)value=0x40;if(elapsed>=90 && elapsed<150)value=0x80;}
    if((id==0x4084 || id==0x71cd) && mode==0x35 && age>10){
     unsigned choice=DebugMemRead8(m+0xe3e5);value=choice<2 ? ((age%10)<2?0xc4000000:0) : ((age%20)<4?0x80:0);
    }
   }
   if(began && !active && !ended){ended=f;printf("NATIVE_FISHING_ENDED f=%u rupees=%d highscore=%08x\n",f,(int16_t)DebugMemRead16(savebase+0x34),r32(savebase+0xec0));}
   if(ended){value=0;if(f>ended+80)CoreDoCommand(M64CMD_STOP,0,NULL);}
   if(f%50==0)printf("FISHING_STATUS f=%u active=%u began=%u ended=%u flags=%08x\n",f,active,began,ended,r32(player+0x66c));
  }
'''
assert needle in s;s=s.replace(needle,extra+needle);(W/'fishing-runner.c').write_text(s);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'fishing-runner.c'),'-o',str(W/'fishing-runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
s=(W/'run.py').read_text().replace("W/'runner'","W/'fishing-runner'");(W/'run_fishing.py').write_text(s)
p=W/'limits.json';d=json.loads(p.read_text());d['doof-child']=3300;d['doof-adult']=3300;p.write_text(json.dumps(d))

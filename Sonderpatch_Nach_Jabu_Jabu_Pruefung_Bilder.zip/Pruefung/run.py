from pathlib import Path
import subprocess,json,os,sys
W=Path('/workspace/post-jabu-test');s=json.loads((W/'symbols.json').read_text());case,snapshot,frames=sys.argv[1:4]
cmd=[str(W/'runner'),'/workspace/post-jabu-test/special.z64',case,frames,'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable'])]
if snapshot!='none':cmd.append(str(W/(snapshot+'.save')))
with (W/(case+'.log')).open('w') as out:subprocess.run(cmd,env=dict(os.environ,DISPLAY=':99'),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=600)
print('Completed',case)

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os
W=Path('/workspace/post-jabu-test');O=Path('/workspace/oot-burns-pal')
def run(native):
 syms=json.loads((Path('/workspace/graphics-audit/native-symbols.json') if native else W/'symbols.json').read_text());case='guard-joke-'+('original' if native else 'special')+'-focus-direct-clip-on';rom=(O/'baseroms/pal-1.0/baserom.z64') if native else (W/'special.z64')
 with (W/(case+'.log')).open('w') as out:subprocess.run([str(W/'runner'),str(rom),case,'1000','4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/'guard.save')],env=dict(os.environ,DISPLAY=':99'),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(run,[True,False]))

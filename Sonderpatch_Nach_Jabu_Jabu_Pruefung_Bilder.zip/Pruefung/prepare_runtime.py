from pathlib import Path
import re,json
W=Path('/workspace/post-jabu-test');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable','FileSelect_Main']};(W/'symbols.json').write_text(json.dumps(syms));ofs=json.loads((W/'fs-offsets.json').read_text())
s=Path('/workspace/transition/runner.c').read_text();mark='static void onframe(unsigned f){'
helper='''static void freshframe(unsigned f){
 static uint32_t fs=0;static unsigned ticks=0,ready=0;unsigned value=0;
 uint32_t entry=overlays+0x8e10+5*0x30;
 uint32_t base=r32(entry),main=base?base+FILESELECT_MAIN-r32(entry+0xc):0;
 if(base && f%20==0){fs=0;for(uint32_t a=0x80120000;a<0x803d0000;a+=4)if(r32(a+4)==main && r32(a+0x98)==1){fs=a;break;}}
 if(!base)fs=0;
 if(fs){
  unsigned menu=DebugMemRead16(fs+FS_MENU),config=DebugMemRead16(fs+FS_CONFIG),select=DebugMemRead16(fs+FS_SELECT),ky=DebugMemRead16(fs+FS_KBDY);
  if(f%50==0)printf("FILEMENU f=%u fs=%08x menu=%u config=%u select=%u keyY=%u lang=%u\\n",f,fs,menu,config,select,ky,DebugMemRead8(savebase+0x1409));
  if(menu==1 && config==33){ticks++;if(ticks<5)value=0x80;else if(ticks>=30 && ticks<35)value=0x10;else if(ticks>60 && ticks%20<4)value=0x80;}
  else {ticks=0;if(f%30<4)value=0x80;}
 }else{
  if(f>250 && r32(savebase+0x135c)==1 && f%60<4)value=0x10;
  if(f%50==0)findplay();
  if(play && r32(savebase+0x135c)==0 && r32(savebase+0xa4)&0x1c0000){
   if(!ready){printf("FRESH_START f=%u scene=%x entrance=%x age=%u quest=%08x fled=%x ms=%x pos=(%.1f %.1f %.1f)\\n",f,DebugMemRead16(play+0xa4),r32(savebase),r32(savebase+4),r32(savebase+0xa4),DebugMemRead16(savebase+0xee4)&1,DebugMemRead16(savebase+0xedc)&0x20,rf(player+0x24),rf(player+0x28),rf(player+0x2c));FILE* out=fopen("/workspace/post-jabu-test/fresh.save","wb");for(int i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),out);fclose(out);}
   if(++ready==100){CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);printf("FRESH_BOOT_VERIFIED\\n");}
   if(ready>130)CoreDoCommand(M64CMD_STOP,0,NULL);
  }
 }
 if(f%200==0){printf("FRESH_FRAME %u mode=%u fs=%08x\\n",f,r32(savebase+0x135c),fs);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 if(buttons)buttons(value);if(f>=(unsigned)limit)CoreDoCommand(M64CMD_STOP,0,NULL);
}
'''
for a,b in {'FILESELECT_MAIN':syms['FileSelect_Main'],'FS_MENU':ofs['menuMode'],'FS_CONFIG':ofs['configMode'],'FS_SELECT':ofs['selectMode'],'FS_KBDY':ofs['kbdY']}.items():helper=helper.replace(a,hex(b))
s=s.replace(mark,helper+mark+'\n if(strstr(scenario,"freshboot")){alarm(30);freshframe(f);return;}')
s=s.replace('  if(f==300 && strstr(scenario,"navi"))', '  if(strstr(scenario,"natural-chase") && f>250 && f<450 && !(DebugMemRead16(savebase+0xee4)&1))value=0x40000000;\n  if(f==300 && strstr(scenario,"navi"))')
(W/'runner.c').write_text(s);print(syms)

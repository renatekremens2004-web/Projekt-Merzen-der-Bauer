#define M64P_CORE_PROTOTYPES
#include "m64p_common.h"
#include "m64p_frontend.h"
#include "m64p_config.h"
#include "m64p_debugger.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <execinfo.h>
#include <math.h>
static void crash(int n){void* b[40];int c=backtrace(b,40);backtrace_symbols_fd(b,c,2);_exit(128+n);}

static void alarmcb(int sig){(void)sig;uint32_t* c=DebugGetCPUDataPtr(M64P_CPU_REG_COP0);printf("CPU pc=%08x cause=%08x epc=%08x bad=%08x\n",*(uint32_t*)DebugGetCPUDataPtr(M64P_CPU_PC),c[13],c[14],c[8]);for(uint32_t t=DebugMemRead32(0x8000633c),n=0;t>=0x80000000 && t<0x80800000 && n<15;t=DebugMemRead32(t+12),n++){printf("THREAD %08x id=%u state=%u pc=%08x ra=%08x sp=%08x\n",t,DebugMemRead32(t+20),DebugMemRead16(t+16),DebugMemRead32(t+0x11c),DebugMemRead32(t+0x104),DebugMemRead32(t+0xf4));}FILE* d=fopen("/workspace/bean-rider/stalled-ram.bin","wb");for(uint32_t a=0x80000000;a<0x80400000;a+=4){uint32_t v=__builtin_bswap32(DebugMemRead32(a));fwrite(&v,4,1,d);}fclose(d);alarm(15);}
static uint32_t savebase=0x80118450, overlays=0x800e6500;
static int limit=2400;static int memory_mb=4;
static const char* scenario;
static const char* snapshotfile;
static void (*buttons)(unsigned);
static unsigned actors[32],player;static int count;
static uint32_t r32(uint32_t a){return DebugMemRead32(a);}
static float rf(uint32_t a){uint32_t x=r32(a);float f;memcpy(&f,&x,4);return f;}
static void debugcb(void* ctx,int level,const char* message){static int bad=0;if(strstr(message,"UNKNOWN GBI COMMAND") || strstr(message,"Using Vertex outside buffer")){if(++bad>100)exit(98);}if(level<=2)fprintf(stderr,"EMU %d: %s\n",level,message);}
static void scan(void){
 count=0;
 for(uint32_t a=0x80120000;a<0x80400000-0x700;a+=4){
  unsigned id=DebugMemRead16(a);if(id==0 && r32(a+0x138)==overlays && DebugMemRead8(a+2)==2 && r32(a+0x130))player=a;if(id!=0xe8 && id!=0x2a && id!=0x17a && id!=0x52)continue;
  if(r32(a+0x138)!=overlays+id*0x20 || !r32(a+0x130))continue;
  int params=(int16_t)DebugMemRead16(a+0x1c);
  if(id==0xe8 && params>=100)continue;
  if(id==0x2a && (params>>8)!=3 && (params>>8)!=5 && (params>>8)!=7 && (params>>8)!=8 && (params>>8)!=9)continue;
  if(count<32)actors[count++]=a;
 }
}
static uint32_t play;
static uint32_t actor(int id){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130))return a;
 return 0;
}
static uint32_t actor_type(int id,int type){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130) && (type<0 || (DebugMemRead16(a+0x1c)&127)==type))return a;
 return 0;
}
static void findplay(void){
 if(play && r32(play+0x1c44)==player && player && r32(player+0x130))return;
 play=0;player=0;scan();if(!player)return;
 for(uint32_t a=0x80120000;a<0x80400000;a+=4)if(r32(a)==player && a>0x80121c44 && r32(a-4)==1){uint32_t p=a-0x1c44;if(DebugMemRead16(p+0xa4)<0x70 && r32(p)>=0x80000000){play=p;break;}}
 if(play)printf("PLAY %08x player=%08x scene=%x\n",play,player,DebugMemRead16(play+0xa4));
}
static void wf(uint32_t a,float f){uint32_t v;memcpy(&v,&f,4);DebugMemWrite32(a,v);}
static void position(uint32_t a,float x,float y,float z,int facing){wf(a+0x24,x);wf(a+0x28,y);wf(a+0x2c,z);wf(a+0x100,x);wf(a+0x104,y);wf(a+0x108,z);DebugMemWrite16(a+0xb6,facing);DebugMemWrite16(a+0x32,facing);}
static void freshframe(unsigned f){
 static uint32_t fs=0;static unsigned ticks=0,ready=0;unsigned value=0;
 uint32_t entry=overlays+0x8e10+5*0x30;
 uint32_t base=r32(entry),main=base?base+0x80811b58-r32(entry+0xc):0;
 if(base && f%20==0){fs=0;for(uint32_t a=0x80120000;a<0x803d0000;a+=4)if(r32(a+4)==main && r32(a+0x98)==1){fs=a;break;}}
 if(!base)fs=0;
 if(fs){
  unsigned menu=DebugMemRead16(fs+0x1ca3c),config=DebugMemRead16(fs+0x1ca3e),select=DebugMemRead16(fs+0x1ca44),ky=DebugMemRead16(fs+0x1cad2);
  if(f%50==0)printf("FILEMENU f=%u fs=%08x menu=%u config=%u select=%u keyY=%u lang=%u\n",f,fs,menu,config,select,ky,DebugMemRead8(savebase+0x1409));
  if(menu==1 && config==33){ticks++;if(ticks<5)value=0x80;else if(ticks>=30 && ticks<35)value=0x10;else if(ticks>60 && ticks%20<4)value=0x80;}
  else {ticks=0;if(f%30<4)value=0x80;}
 }else{
  if(f>250 && r32(savebase+0x135c)==1 && f%60<4)value=0x10;
  if(f%50==0)findplay();
  if(play && r32(savebase+0x135c)==0 && r32(savebase+0xa4)&0x1c0000){
   if(!ready){printf("FRESH_START f=%u scene=%x entrance=%x age=%u quest=%08x fled=%x ms=%x pos=(%.1f %.1f %.1f)\n",f,DebugMemRead16(play+0xa4),r32(savebase),r32(savebase+4),r32(savebase+0xa4),DebugMemRead16(savebase+0xee4)&1,DebugMemRead16(savebase+0xedc)&0x20,rf(player+0x24),rf(player+0x28),rf(player+0x2c));FILE* out=fopen("/workspace/post-jabu-test/fresh.save","wb");for(int i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),out);fclose(out);}
   if(++ready==100){CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);printf("FRESH_BOOT_VERIFIED\n");}
   if(ready>130)CoreDoCommand(M64CMD_STOP,0,NULL);
  }
 }
 if(f%200==0){printf("FRESH_FRAME %u mode=%u fs=%08x\n",f,r32(savebase+0x135c),fs);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 if(buttons)buttons(value);if(f>=(unsigned)limit)CoreDoCommand(M64CMD_STOP,0,NULL);
}
static void onframe(unsigned f){
 if(strstr(scenario,"freshboot")){alarm(30);freshframe(f);return;}
 alarm(30);
 if (snapshotfile && f == 300) {
   findplay();
   if (strstr(scenario,"export")) {
     FILE* snap=fopen(snapshotfile,"wb");if(!snap)exit(90);
     for(unsigned i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),snap);
     fclose(snap);printf("EXPORTED save=%08x entrance=%x age=%d mode=%d\n",savebase,r32(savebase),r32(savebase+4),r32(savebase+0x135c));
     CoreDoCommand(M64CMD_STOP,0,NULL);return;
   }
   if(!play){fprintf(stderr,"No title PlayState found\n");exit(91);}
   printf("INJECT title scene=%x mode=%d save=%08x\n",DebugMemRead16(play+0xa4),r32(savebase+0x135c),savebase);
   FILE* snap=fopen(snapshotfile,"rb");if(!snap)exit(92);
   for(unsigned i=0;i<0x1428;i++){int ch=fgetc(snap);if(ch<0)exit(93);DebugMemWrite8(savebase+i,ch);}fclose(snap);
   DebugMemWrite32(savebase+0x135c,0);
   DebugMemWrite8(play+0x11de8,r32(savebase+4));
   DebugMemWrite16(savebase+0x1412,r32(savebase+8)?r32(savebase+8):0xffef);
   DebugMemWrite8(play+0x1d6c,0);
   if(strstr(scenario,"direct")) {
     uint32_t game=overlays+0x8e10+3*0x30;
     if(r32(game+0x2c)!=0x12518){fprintf(stderr,"Invalid Play gamestate entry\n");exit(97);}
     DebugMemWrite8(play+0x11de9,1);
     DebugMemWrite32(play+0xc,r32(game+0x18));DebugMemWrite32(play+0x10,0x12518);DebugMemWrite32(play+0x98,0);
     printf("DIRECT Play_Init=%08x\n",r32(game+0x18));
   }else{
     DebugMemWrite16(play+0x11e1a,r32(savebase));
     DebugMemWrite8(play+0x11e5e,2);DebugMemWrite8(play+0x11e15,20);
   }
   printf("START entrance=%x age=%d cs=%x\n",r32(savebase),r32(savebase+4),r32(savebase+8));
 }
 if(snapshotfile){if(f<500){if(f%50==0)findplay();return;}f-=500;}
 if(f%50==0)findplay();unsigned value=0;
 if(play){
  uint32_t m=play+0x20d8,im=actor(0xa9);
  uint32_t sq=actor(0x124);
  if(sq && f%100==0)printf("SQUID f=%u actor=%08x anim=%08x frame=%.2f action=%08x state=%d phase=%d grabbed=%d rupeesLeft=%d scaleFlag=%x rupees=%u\n",f,sq,r32(sq+0x144),rf(sq+0x154),r32(sq+0x2d0),DebugMemRead16(sq+0x2f8),DebugMemRead16(sq+0x2ec),DebugMemRead16(sq+0x2f4),DebugMemRead16(sq+0x2f6),(DebugMemRead16(savebase+0xeda)&0x100),DebugMemRead16(savebase+0x34));unsigned id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),pos=DebugMemRead16(m+0xe3ce),end=DebugMemRead8(m+0xe3e4);
  if(f%100==0 && strstr(scenario,"navi"))printf("NAVI_CHECK f=%u timer=%u text=%x focus=%08x\n",f,DebugMemRead16(savebase+0x38),DebugMemRead16(player+0x680),r32(player+0x654));
  if(f%100==0)printf("RACE f=%u state=%x rupees=%u\n",f,DebugMemRead16(savebase+0x13fa),DebugMemRead16(savebase+0x34));
  static unsigned key=0,age=0;unsigned k=id*1024+pos;
  if(k!=key || (mode!=7 && mode!=0x34 && mode!=0x35)){key=k;age=0;}else age++;
  if((mode==7 || mode==0x34 || mode==0x35) && age==8){printf("TEXT f=%u id=%04x pos=%u mode=%x len=%u\n",f,id,pos,mode,r32(m+0xe300));CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if((mode==7 || mode==0x34 || mode==0x35) && age==14){printf("PHOTO f=%u id=%04x pos=%u\n",f,id,pos);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f%100==0){
   printf("STATE f=%u scene=%x id=%04x msg=%x ocarinaMode=%x ocarinaAction=%x quest=%08x RAM=%u player=(%.1f %.1f %.1f)\n",f,DebugMemRead16(play+0xa4),id,mode,DebugMemRead16(m+0xe3ee),DebugMemRead16(m+0xe3f0),r32(savebase+0xa4),r32(0x80000318),rf(player+0x24),rf(player+0x28),rf(player+0x2c));
   if(im){unsigned pose=0;for(int i=0;i<51;i++)pose=pose*31+DebugMemRead16(im+0x180+i*2);printf("BEAN actor=%08x action=%u draw=%u alpha=%u anim=%08x frame=%.1f pose=%08x pos=(%.1f %.1f %.1f)\n",im,r32(im+0x250),r32(im+0x254),r32(im+0x25c),r32(im+0x144),rf(im+0x154),pose,rf(im+0x24),rf(im+0x28),rf(im+0x2c));}
   if(f>=300 && f+50<(unsigned)limit)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  }
  if(f%100==0){
   for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==0x2a && (DebugMemRead16(a+0x1c)>>8)==1)printf("RIDER actor=%08x params=%x pos=(%.1f %.1f %.1f) csFrame=%u\n",a,DebugMemRead16(a+0x1c),rf(a+0x24),rf(a+0x28),rf(a+0x2c),DebugMemRead16(play+0x1d74));
  }
  if(strstr(scenario,"ruby") && id==0x3006 && f%10==0)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  if(strstr(scenario,"horse") && f>=780 && f<=1350 && f%10==0)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  if(strstr(scenario,"flashback") && f>=300 && f<=900 && f%25==0)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  if(im && strstr(scenario,"hide-bean"))DebugMemWrite32(im+0x134,0);
  if(im && (r32(im+0x254)==2 || strstr(scenario,"seal"))){
   static unsigned lastalpha=999;unsigned alpha=r32(im+0x25c);
   if(alpha!=lastalpha){printf("FADE f=%u alpha=%u\n",f,alpha);lastalpha=alpha;if(alpha>0 && alpha<255)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  }
  if(f>300 && (mode==0 || age>12) && f%20<4)value=0x80;
  if(f>300 && mode==6 && f%10<2)value=0x80;
  if(sq && f%100==0){
    int ruCount=0;
    for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==0x131 && r32(a+0x130) && r32(a+0x118)==sq)ruCount++;
    printf("RUPPIES f=%u count=%d upgrades=%x\n",f,ruCount,r32(savebase+0xa0));
  }
  static int refused=0;
  if(id==0x013b)refused=1;
  if(strstr(scenario,"poor-deny") && !refused && id==0x4053 && mode==0x35 && age<=12)value=0xba000000;
  if(sq && DebugMemRead16(sq+0x2f8)==2 && mode==0)value=0;
  if(sq && (id==0x0136 || id==0x405d) && mode==0)value=0;
  if(sq && (strstr(scenario,"collect") || strstr(scenario,"assist")) && !strstr(scenario,"repeat") && (DebugMemRead16(savebase+0xeda)&0x100) && mode==0)value=0;
  if(sq && (strstr(scenario,"collect") || strstr(scenario,"assist")) && DebugMemRead16(sq+0x2f8)==2 && mode==0 && f%35==0){
    uint32_t ru=actor(0x131);
    if(ru){position(ru,rf(player+0x24),rf(player+0x28)+5,rf(player+0x2c),0);printf("COLLECT_ASSIST f=%u rupee=%08x\n",f,ru);}
  }
  if(sq && (strstr(scenario,"collect") || strstr(scenario,"assist")) && id==0x4055 && (mode==0x35 || mode==0)){
    int facing=DebugMemRead16(sq+0xb6);position(player,rf(sq+0x24)+sinf(facing*3.14159265f/32768)*45,rf(sq+0x28),rf(sq+0x2c)+cosf(facing*3.14159265f/32768)*45,facing+0x8000);
  }

  if(f==250 && strstr(scenario,"win-safe"))position(player,1107,0,-3740,0);
  if(strstr(scenario,"target") && f>=350 && f<450)value=0x20;
  if(f==300){
   uint32_t npc=0;
   if(strstr(scenario,"king-"))for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)printf("ACTIVE cat=%d id=%x ptr=%08x update=%08x\n",cat,DebugMemRead16(a),a,r32(a+0x130));
   if(strstr(scenario,"market-"))npc=actor_type(0x16e,atoi(strstr(scenario,"market-")+7));
   if(strstr(scenario,"mask"))npc=actor(0x3d);
   if(strstr(scenario,"bowling"))npc=actor(0x14b);
   if(strstr(scenario,"dying") || strstr(scenario,"guard-joke"))npc=actor(0x178);
   if(strstr(scenario,"king-"))npc=actor(0x164);
   if(strstr(scenario,"beans") && !strstr(scenario,"walk"))npc=actor(0x13e);
   if(strstr(scenario,"luigi") && !strstr(scenario,"gate"))npc=actor(0xcb);
   if(strstr(scenario,"gc-") || strstr(scenario,"dmt-")){
    int type=atoi(strchr(scenario,'-')+1);
    for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80400000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==0x1ae && (DebugMemRead16(a+0x1c)&31)==type)npc=a;
   }
   if(strstr(scenario,"kak-"))npc=actor(0x13c);
   if(strstr(scenario,"grave-"))npc=actor(0x16c);
   if(strstr(scenario,"boris-"))npc=actor(0x85);
   if(strstr(scenario,"wind-"))npc=actor(0x153);
   if(strstr(scenario,"zelda"))npc=actor(0x1d3);
   if(strstr(scenario,"owl-"))npc=actor_type(0x14d,0x4c);
   if(npc){
    int facing=DebugMemRead16(npc+0xb6);float distance=strstr(scenario,"wide")?70:45;
    if(strstr(scenario,"bowling") || strstr(scenario,"dying") || strstr(scenario,"guard-joke"))distance=65;
    if(strstr(scenario,"king-"))distance=300;
    if(strstr(scenario,"mask"))distance=90;
    if(strstr(scenario,"owl-"))distance=180;
    if(strstr(scenario,"king-")){
      position(player,rf(npc+0x08)+sinf(facing*3.14159265f/32768)*distance,rf(npc+0x0c),rf(npc+0x10)+cosf(facing*3.14159265f/32768)*distance,facing+0x8000);
    }else if(strstr(scenario,"prox")){
      int view=DebugMemRead16(player+0xb6);
      position(npc,rf(player+0x24)+sinf(view*3.14159265f/32768)*45,rf(player+0x28),rf(player+0x2c)+cosf(view*3.14159265f/32768)*45,view+0x8000);
      DebugMemWrite16(npc+0x110,20);
    }else{
    position(player,rf(npc+0x24)+sinf(facing*3.14159265f/32768)*distance,rf(npc+0x28),rf(npc+0x2c)+cosf(facing*3.14159265f/32768)*distance,facing+0x8000);
    }
    printf("TALK_TARGET actor=%08x id=%x params=%x pos=(%.1f %.1f %.1f)\n",npc,DebugMemRead16(npc),DebugMemRead16(npc+0x1c),rf(npc+0x24),rf(npc+0x28),rf(npc+0x2c));
   }
  }
  if(strstr(scenario,"pin") && mode==0 && f>=300 && f<850){uint32_t n=actor_type(0x16e,atoi(strstr(scenario,"market-")+7));if(n){position(n,-4,0,669.8,0);DebugMemWrite16(n+0x110,0);}}
  if(strstr(scenario,"natural-chase") && f>250 && f<450 && !(DebugMemRead16(savebase+0xee4)&1))value=0x40000000;
  if(f==300 && strstr(scenario,"navi"))DebugMemWrite16(savebase+0x38,650);
  if(f%100==0){uint32_t cam=r32(play+0x790+DebugMemRead16(play+0x7a0)*4);printf("CAM f=%u eye=(%.2f %.2f %.2f) at=(%.2f %.2f %.2f) fov=%.2f setting=%x mode=%x age=%u room=%u\n",f,rf(cam+0x5c),rf(cam+0x60),rf(cam+0x64),rf(cam+0x50),rf(cam+0x54),rf(cam+0x58),rf(cam+0xfc),DebugMemRead16(cam+0x142),DebugMemRead16(cam+0x144),r32(savebase+4),DebugMemRead8(play+0x11cbc));}
  if(f==300 && strstr(scenario,"beans-safe")) {position(player,-780,100,-250,0x6000);wf(player+0x5c,0);wf(player+0x60,0);wf(player+0x64,0);wf(player+0x68,0);}
  if(f%100==0 && strstr(scenario,"sword")){uint32_t sw=actor(0x6c);printf("SWORD f=%u actor=%08x pos=(%.1f %.1f %.1f) draw=%08x parent=%08x playerYaw=%x range=%08x\n",f,sw,sw?rf(sw+0x24):0,sw?rf(sw+0x28):0,sw?rf(sw+0x2c):0,sw?r32(sw+0x134):0,sw?r32(sw+0x118):0,DebugMemRead16(player+0xb6),r32(player+0x428));}
  if(f%100==0)printf("DEBUG cs=%u action=%u flags=%08x talk=%08x dist=%.1f yaw=%x\n",DebugMemRead8(play+0x1d6c),DebugMemRead8(player+0x434),r32(player+0x66c),r32(player+0x684),rf(player+0x688),DebugMemRead16(player+0xb6));
  if(f%100==0)printf("PROGRESS f=%u fled=%x master=%x navi_seen=%x guard_dead=%x cs=%u\n",f,DebugMemRead16(savebase+0xee4)&1,DebugMemRead16(savebase+0xedc)&0x20,DebugMemRead16(savebase+0xf30)&0x8000,DebugMemRead16(savebase+0xf04)&0x1000,DebugMemRead16(play+0x1d74));
  if(f==1400 && strstr(scenario,"navi-once"))DebugMemWrite16(savebase+0x38,650);
  if(strstr(scenario,"navi") && mode==0)value=0;
  if(strstr(scenario,"navi") && f>500 && mode==0 && f%60<8)value=0x800;
  if(strstr(scenario,"enemy-roast")){
    if(f==800){
      uint32_t enemy=r32(play+0x1c34+5*8);
      while(enemy && (DebugMemRead8(enemy+0x117)==0xff || !(r32(enemy+4)&1)))enemy=r32(enemy+0x124);
      if(enemy){int yaw=DebugMemRead16(player+0xb6);position(enemy,rf(player+0x24)+sinf(yaw*3.14159265f/32768)*80,rf(player+0x28)+20,rf(player+0x2c)+cosf(yaw*3.14159265f/32768)*80,yaw+0x8000);DebugMemWrite16(enemy+0x110,120);printf("ROAST_TARGET id=%x hint=%x\n",DebugMemRead16(enemy),DebugMemRead8(enemy+0x117)+0x600);}
    }
    if(f>820 && mode==0){value=0x20;if(f%60<8)value|=0x800;}
  }
  if(strstr(scenario,"barinade-roast") && (DebugMemRead16(savebase+0xee2)&0x40) && mode==0){value=0x20;if(f%60<8)value|=0x800;}
  if(strstr(scenario,"barinade") && f%100==0)printf("BOSS f=%u began=%x msg=%x mode=%x\n",f,(DebugMemRead16(savebase+0xee2)&0x40),id,mode);
  if(strstr(scenario,"lesson")){
   if(f==300 && im && !strstr(scenario,"nomove"))position(player,rf(im+0x24)-100,rf(im+0x28),rf(im+0x2c)+30,0x4000);
   static unsigned note=0,clock=0;static const unsigned song[]={0x200,0x800,0x100,0x200,0x800,0x100};
   if(mode==0x1b){
    value=0;if(clock%24<8 && note<6)value=song[note];
    clock++;if(clock%24==0)note++;
   }else{note=0;clock=0;}
   static unsigned lastmode=0;if(mode!=lastmode && (mode>=9 && mode<=0x1f)){printf("MUSIC f=%u mode=%x\n",f,mode);lastmode=mode;}
  }
 }
 if(strstr(scenario,"normal")){
  value=0;
  if(f>=350 && f%50<8 && r32(savebase+0x135c)==1)value=0x10;
  if(f>=300 && f%100==0){printf("BOOT f=%u RAM=%u gameMode=%u\n",f,r32(0x80000318),r32(savebase+0x135c));CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 }
 if(strstr(scenario,"focus") && f>300 && f<450)value=0x20;
 if(strstr(scenario,"focus") && f>350)value|=0x20;
 if(buttons)buttons(value);if(f>=(unsigned)limit)CoreDoCommand(M64CMD_STOP,0,NULL);
}
static void setting(const char* section,const char* key,m64p_type type,const void* value){m64p_handle h;ConfigOpenSection(section,&h);ConfigSetParameter(h,key,type,value);}
static void integer(const char* section,const char* key,int value){setting(section,key,M64TYPE_INT,&value);}
static void boolean(const char* section,const char* key,int value){setting(section,key,M64TYPE_BOOL,&value);}
int main(int argc,char** argv){signal(SIGSEGV,crash);
 if(argc<3)return 2;scenario=argv[2];if(strstr(scenario,"-us")){savebase=0x8011a5d0;overlays=0x800e8530;}if(argc>3)limit=atoi(argv[3]);if(argc>4)memory_mb=atoi(argv[4]);setbuf(stdout,NULL);
 if(argc>5)savebase=strtoul(argv[5],NULL,0);if(argc>6)overlays=strtoul(argv[6],NULL,0);
 if(argc>7)snapshotfile=argv[7];
 char config[512],shots[512];snprintf(config,sizeof(config),"/workspace/bean-rider/config-%s",scenario);snprintf(shots,sizeof(shots),"/workspace/bean-rider/screens-%s",scenario);mkdir(config,0700);mkdir(shots,0700);
 void* sdl=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_GLOBAL);int(*sdlinit)(unsigned)=dlsym(sdl,"SDL_Init");sdlinit(0x20|0x200);
 int r=CoreStartup(0x020001,config,"/workspace/toolchain/root/usr/share/games/mupen64plus",NULL,debugcb,NULL,NULL);if(r)return r;
 integer("Video-GLideN64","EnableCopyColorToRDRAM",1);
 boolean("Video-GLideN64","EnableClipping",strstr(scenario,"clip-on")!=NULL);
 boolean("Video-GLideN64","EnableCustomSettings",0);
 setting("Core","SharedDataPath",M64TYPE_STRING,"/workspace/toolchain/root/usr/share/games/mupen64plus");
 setting("Core","ScreenshotPath",M64TYPE_STRING,shots);setting("Core","SaveStatePath",M64TYPE_STRING,config);setting("Core","SaveSRAMPath",M64TYPE_STRING,config);
 boolean("Core","DisableExtraMem",memory_mb==4);integer("Core","R4300Emulator",memory_mb==4?1:2);boolean("Core","OnScreenDisplay",0);integer("Video-General","ScreenWidth",640);integer("Video-General","ScreenHeight",480);boolean("Video-General","Fullscreen",0);boolean("Video-General","VerticalSync",0);
 FILE* file=fopen(argv[1],"rb");if(!file)return 3;fseek(file,0,SEEK_END);long n=ftell(file);rewind(file);void* rom=malloc(n);if(fread(rom,1,n,file)!=(size_t)n)return 4;fclose(file);r=CoreDoCommand(M64CMD_ROM_OPEN,n,rom);if(r)return r;
 fprintf(stderr,"Core paths: %s | %s | %s\n",ConfigGetUserDataPath(),ConfigGetUserCachePath(),ConfigGetUserConfigPath());
 m64p_rom_settings rs;memset(&rs,0,sizeof(rs));r=CoreDoCommand(M64CMD_ROM_GET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 rs.disableextramem=memory_mb==4;r=CoreDoCommand(M64CMD_ROM_SET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 printf("Requested memory: %d MiB; disableextramem=%d\n",memory_mb,rs.disableextramem);
 const char* paths[]={"/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-rsp-hle.so","/workspace/toolchain/RMG-060/glide-build/plugin/Release/mupen64plus-video-GLideN64.so",NULL,"/workspace/bean-rider/test_input.so"};
 if(strstr(scenario,"mk2"))paths[1]="/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-video-glide64mk2.so";
 void* core=dlopen("libmupen64plus.so.2",RTLD_NOW|RTLD_GLOBAL);int order[]={1,2,3,0};
 for(int k=0;k<4;k++){int i=order[k];if(!paths[i])continue;void* plugin=dlopen(paths[i],RTLD_NOW|RTLD_LOCAL|RTLD_DEEPBIND);if(!plugin){puts(dlerror());return 5;}ptr_PluginStartup startup=dlsym(plugin,"PluginStartup");if((r=startup(core,NULL,debugcb)))return r;if((r=CoreAttachPlugin(i+1,plugin)))return r;if(i==3)buttons=dlsym(plugin,"TestSetButtons");}
 int speed=0;CoreDoCommand(M64CMD_CORE_STATE_SET,M64CORE_SPEED_LIMITER,&speed);CoreDoCommand(M64CMD_SET_FRAME_CALLBACK,0,onframe);signal(SIGALRM,alarmcb);alarm(15);r=CoreDoCommand(M64CMD_EXECUTE,0,NULL);
 printf("SCENARIO %s completed: %d\n",scenario,r);CoreDoCommand(M64CMD_ROM_CLOSE,0,NULL);CoreShutdown();return r;
}

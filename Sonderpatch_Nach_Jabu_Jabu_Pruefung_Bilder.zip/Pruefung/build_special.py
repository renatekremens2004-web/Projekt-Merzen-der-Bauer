from pathlib import Path
W=Path('/workspace/post-jabu-test');O=Path('/workspace/oot-burns-pal');p=O/'src/code/z_sram.c';s=(W/'production_z_sram.c').read_text()
marker='    gSaveContext.save.info.sceneFlags[SCENE_WATER_TEMPLE].swch = 0x40000000;';start=s.index('void Sram_InitNewSave(void)');end=s.index('\n}',start);assert marker in s[start:end]
setup='''
    /* Standalone post-Jabu test edition: only initialize NEW files at this milestone. */
    gSaveContext.save.info.playerData.savedSceneId = SCENE_ZORAS_FOUNTAIN;
    gSaveContext.save.info.playerData.healthCapacity = 0x60;
    gSaveContext.save.info.playerData.health = 0x60;
    gSaveContext.save.info.playerData.rupees = 99;
    gSaveContext.save.info.inventory.questItems = (1 << QUEST_KOKIRI_EMERALD) | (1 << QUEST_GORON_RUBY) |
        (1 << QUEST_ZORA_SAPPHIRE) | (1 << QUEST_SONG_LULLABY) | (1 << QUEST_SONG_SARIA);
    gSaveContext.save.info.inventory.equipment |= OWNED_EQUIP_FLAG(EQUIP_TYPE_SWORD, EQUIP_INV_SWORD_KOKIRI) |
        OWNED_EQUIP_FLAG(EQUIP_TYPE_SHIELD, EQUIP_INV_SHIELD_DEKU);
    gSaveContext.save.info.equips.equipment = (EQUIP_VALUE_SWORD_KOKIRI << (EQUIP_TYPE_SWORD * 4)) |
        (EQUIP_VALUE_SHIELD_DEKU << (EQUIP_TYPE_SHIELD * 4)) |
        (EQUIP_VALUE_TUNIC_KOKIRI << (EQUIP_TYPE_TUNIC * 4)) |
        (EQUIP_VALUE_BOOTS_KOKIRI << (EQUIP_TYPE_BOOTS * 4));
    gSaveContext.save.info.inventory.upgrades = (1 << gUpgradeShifts[UPG_BOMB_BAG]) |
        (1 << gUpgradeShifts[UPG_STRENGTH]) | (1 << gUpgradeShifts[UPG_SCALE]) |
        (1 << gUpgradeShifts[UPG_BULLET_BAG]) | (1 << gUpgradeShifts[UPG_DEKU_STICKS]) |
        (1 << gUpgradeShifts[UPG_DEKU_NUTS]);
    INV_CONTENT(ITEM_DEKU_STICK) = ITEM_DEKU_STICK;
    INV_CONTENT(ITEM_DEKU_NUT) = ITEM_DEKU_NUT;
    INV_CONTENT(ITEM_BOMB) = ITEM_BOMB;
    INV_CONTENT(ITEM_SLINGSHOT) = ITEM_SLINGSHOT;
    INV_CONTENT(ITEM_OCARINA_FAIRY) = ITEM_OCARINA_FAIRY;
    INV_CONTENT(ITEM_BOOMERANG) = ITEM_BOOMERANG;
    gSaveContext.save.info.inventory.items[SLOT_BOTTLE_1] = ITEM_BOTTLE_EMPTY;
    gSaveContext.save.info.inventory.items[SLOT_TRADE_CHILD] = ITEM_ZELDAS_LETTER;
    AMMO(ITEM_DEKU_STICK) = 10;
    AMMO(ITEM_DEKU_NUT) = 20;
    AMMO(ITEM_BOMB) = 20;
    AMMO(ITEM_SLINGSHOT) = 30;
    gSaveContext.save.info.equips.buttonItems[0] = ITEM_SWORD_KOKIRI;
    gSaveContext.save.info.equips.buttonItems[1] = ITEM_BOOMERANG;
    gSaveContext.save.info.equips.buttonItems[2] = ITEM_BOMB;
    gSaveContext.save.info.equips.buttonItems[3] = ITEM_OCARINA_FAIRY;
    gSaveContext.save.info.equips.cButtonSlots[0] = SLOT_BOOMERANG;
    gSaveContext.save.info.equips.cButtonSlots[1] = SLOT_BOMB;
    gSaveContext.save.info.equips.cButtonSlots[2] = SLOT_OCARINA;
    SET_EVENTCHKINF(EVENTCHKINF_09);
    SET_EVENTCHKINF(EVENTCHKINF_25);
    SET_EVENTCHKINF(EVENTCHKINF_37);
    SET_EVENTCHKINF(EVENTCHKINF_OBTAINED_ZELDAS_LETTER);
    SET_EVENTCHKINF(EVENTCHKINF_GAVE_LETTER_TO_KING_ZORA);
    SET_EVENTCHKINF(EVENTCHKINF_OBTAINED_SILVER_SCALE);
    SET_EVENTCHKINF(EVENTCHKINF_OPENED_JABU_JABU);
    /* ZELDA_FLED_CASTLE and OBTAINED_MASTER_SWORD remain clear. */
'''
s=s[:end]+setup+s[end:]
# Native Sram_InitSave overwrites the initial entrance after the inventory initializer.
a=s.index('void Sram_InitSave(');b=s.index('    for (offset = 0; offset < 8; offset++)',a);chunk=s[a:b];chunk=chunk.replace('ENTR_LINKS_HOUSE_0','ENTR_ZORAS_FOUNTAIN_0').replace('gSaveContext.save.cutsceneIndex = CS_INDEX_1;','gSaveContext.save.cutsceneIndex = CS_INDEX_NONE;');s=s[:a]+chunk+s[b:]
# Honour a NEW test file on its first opening. Later normal saves keep native reopen rules.
needle='    switch (gSaveContext.save.info.playerData.savedSceneId) {';assert s.count(needle)==1
s=s.replace(needle,needle+'''
        case SCENE_ZORAS_FOUNTAIN:
            if (LINK_IS_ADULT) {
                gSaveContext.save.entranceIndex = ENTR_TEMPLE_OF_TIME_7;
            } else {
                gSaveContext.save.entranceIndex = ENTR_ZORAS_FOUNTAIN_0;
            }
            break;
''')
p.write_text(s);print('Special edition: new-file inventory, fountain start, no intro; normal gameplay/rendering preserved')

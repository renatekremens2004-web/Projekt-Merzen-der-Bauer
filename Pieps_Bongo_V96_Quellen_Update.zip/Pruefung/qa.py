from pathlib import Path
import sys,json,re,subprocess,os,runpy,struct
W=Path(__file__).resolve().parent;rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1]);case=(W/'qa-case.txt').read_text().strip()
if case=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit()
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('obj<=0x1af','obj<=0x1b0')
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned triggered=0,flight=0,landed=0,complete=0,text=0,closed=0,stages=0;
static unsigned relocated(unsigned sym){unsigned p=overlays+0xe9*0x20;return sym-r32(p+8)+r32(p+0x10);}
static void heapreport(void){unsigned free=0,largest=0;for(unsigned n=r32(ARENA),k=0;n>=0x80000000&&n<0x80400000&&k<2000;n=r32(n+8),k++){if(DebugMemRead16(n+2)){unsigned z=r32(n+4);free+=z;if(z>largest)largest=z;}}printf("HEAP free=%u largest=%u\n",free,largest);need(largest>32768,"heap retains room for allocations");}
static void onframe(unsigned f){
 baseframe(f);if(f<350)return;findplay();if(!play||!player||DebugMemRead16(play+0xa4)!=0x18)return;
 unsigned head=target(0xe9,0xffff),bird=target(0x72,0x7504),after=target(0x72,0x7505),msg=play+0x20d8;
 if(f%100==0)printf("STATE f=%u head=%x action=%x bird=%x after=%x cs=%u\n",f,head,head?r32(head+0x180):0,bird,after,DebugMemRead8(play+0x1d6c));
 if(head&&!triggered&&DebugMemRead8(play+0x1d6c)==0&&f>500){
  unsigned victim=HAND?target(0xe9,0):head;need(victim,"hit victim loaded");
  DebugMemWrite8(victim+(HAND?0x3d5:0x6b5),DebugMemRead8(victim+(HAND?0x3d5:0x6b5))|2);DebugMemWrite8(victim+0xb0,2);DebugMemWrite8(victim+0xb1,1);
  triggered=f;printf("ACCEPTED_HIT hand=%u frame=%u\n",HAND,f);
 }
 if(bird){
  if(!flight){flight=f;bank();heapreport();printf("FLIGHT begins y=%.1f targetHead=%.1f,%.1f,%.1f\n",rf(bird+0x28),rf(head+0x38),rf(head+0x3c),rf(head+0x40));}
  need((r32(AUDIO+0x2894)>0),"audio engine remains active");
  if(f==flight+20||f==flight+55||f==flight+70){CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);stages++;need((DebugMemRead16(ACTIVESEQ+0x254)&255)==111,"Pieps theme plays");}
 }
 if(after){
  if(!landed){landed=f;bank();printf("AFTER_BIRD xyz=%.1f,%.1f,%.1f\n",rf(after+0x24),rf(after+0x28),rf(after+0x2c));}
  if(!head&&!complete){complete=f;need(actor(0x5d)&&actor(0x5f),"native warp and heart container present");bank();printf("NATIVE_REWARDS_PASSED frame=%u\n",f);}
  if(complete){
   if(f<complete+80)position(player,-300,0,270,-26000);
   if(f<complete+80)photo(-60,110,420,-340,25,220);
   unsigned v=closed?0:0x20;if(!closed&&f%24<2)v|=0x80;if(f==complete+400||f==complete+480)v=0x10;if(buttons)buttons(v);
   if(DebugMemRead16(msg+0xe2f8)==0x7240&&DebugMemRead8(msg+0xe304)){if(!text)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);text=1;}
   if(text&&!DebugMemRead8(msg+0xe304))closed=1;
   if(f>complete+600){need(text&&closed,"postfight conversation opens and closes");need(CLEARED||(flight&&stages==3),"bird entrance tested");need(rf(player+0x28)>-100,"player remains on arena floor after inventory");bank();printf("PIEPS_BONGO_PASSED hand=%u cleared=%u flight=%u clear=%u dialogue=%u\n",HAND,CLEARED,flight,complete,text);CoreDoCommand(M64CMD_STOP,0,NULL);}
  }
 }
 need(f<3400,"boss completion timeout");
}
'''
body=body.replace('HAND','1'if case=='hand'else'0').replace('CLEARED','1'if case=='cleared'else'0').replace('AUDIO',hex(sy['gAudioCtx'])).replace('ARENA',hex(sy['sZeldaArena'])).replace('ACTIVESEQ',hex(sy['gActiveSeqs']))
c=W/f'probe-{mode}.c';c.write_text(base[:a]+body+base[b:]);runner=Path('/tmp')/f'bongo-v96-{mode}'
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/proto-soldier-v68/soldier.save').read_bytes());struct.pack_into('>III',q,0,0x413,0,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,-50,1000,0,0,0xdff,0x413,1);q[0x1409]=1
struct.pack_into('>I',q,0xd4+0x18*0x1c+8,2 if case=='cleared'else 0);struct.pack_into('>H',q,0xed4+7*2,struct.unpack_from('>H',q,0xed4+7*2)[0]|128);struct.pack_into('>H',q,0x2e,0x140);struct.pack_into('>H',q,0x30,0x140)
save=W/f'{case}.save';save.write_bytes(q)
shots=Path('/tmp')/f'screens-bongo-v96-{mode}-{case}';shots.mkdir(exist_ok=True);link=Path('/workspace/bean-rider')/shots.name
if not link.exists():link.symlink_to(shots)
log=W/f'qa-{mode}-{case}.log'
with log.open('w')as out:r=subprocess.run([str(runner),rom,f'bongo-v96-direct-{mode}-{case}','3500','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=out,stderr=subprocess.STDOUT,timeout=600)
assert r.returncode==0,(r.returncode,log.read_text()[-2000:]);assert 'PIEPS_BONGO_PASSED'in log.read_text()

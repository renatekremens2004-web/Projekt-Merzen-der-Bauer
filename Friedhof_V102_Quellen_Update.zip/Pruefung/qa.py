from pathlib import Path
import json,sys,os,re,struct,subprocess,runpy
W=Path(__file__).resolve().parent;rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1])
if (W/'qa-case.txt').exists()and(W/'qa-case.txt').read_text().strip()=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit()
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned seen=0,done=0,forced=0,seenintro=0,research=0,lastid=0,noselected=0;
static unsigned overlayfn(unsigned sym){return r32(overlays+0xd*32+16)+sym-r32(overlays+0xd*32+8);}
static void onframe(unsigned f){
 baseframe(f);if(f<380)return;findplay();if(!play||!player)return;
 unsigned npc=actor(NPC),msg=play+0x20d8,id=DebugMemRead16(msg+0xe2f8),mode=DebugMemRead8(msg+0xe304),composer=COMPOSER;
 if(f%150==0)printf("STATE f=%u npc=%x id=%x mode=%x research=%u flags=%x\n",f,npc,id,mode,research,r32(play+0x1d28));
 if(npc){
  if(composer&&!forced&&f>=450){
   /* Dialogue-only fixture: use a loaded native Poe at the post-battle talk entry.
    * The production actor/ROM is untouched; spawning and fighting aren't tested. */
   DebugMemWrite32(npc+0x134,0);DebugMemWrite16(npc+0x1c,2);DebugMemWrite32(npc+0x130,overlayfn(UPDATE_DEAD));DebugMemWrite32(npc+0x190,overlayfn(SETUP_TALK));DebugMemWrite32(npc+4,(r32(npc+4)&~4)|1);wf(npc+0x6c,0);wf(npc+0x60,0);position(npc,rf(npc+0x24),rf(npc+0x80)+10,rf(npc+0x2c),0);DebugMemWrite32(play+0x1d28,r32(play+0x1d28)&~0xe00);forced=1;
  }
  if(!composer||forced){float ang=(int16_t)DebugMemRead16(npc+0xb6)*(3.14159265f/32768.0f),x=rf(npc+0x24),y=rf(npc+0x28),z=rf(npc+0x2c);if(composer)position(player,x+5,y-10,z+10,32768);else if(f<650)position(player,x+sinf(ang)*22,y,z+cosf(ang)*22,(int16_t)DebugMemRead16(npc+0xb6)+32768);if(f<700)photo(x+130,y+100,z+160,x,y+25,z);}
 }
 if(id==EXPECTED&&mode)seen=1;
 if(!composer&&id==NEXT&&mode)done=1;
 if(composer){
  if(id==0x500f&&mode)seenintro=1;
  if(id==0x5010&&mode&&lastid!=id)research++;
  if(id==0x5011&&research>=2){DebugMemWrite8(msg+0xe3e5,1);noselected=1;}
  if(id&&mode)lastid=id;
  if(forced&&!mode&&noselected&&(r32(play+0x1d28)&0x800)){need(seenintro&&research>=2,"composer introduction, linked research and native repeat choice");bank();puts("FRIEDHOF_NATIVE_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(buttons)buttons((f>500&&f%20<2&&(mode==0||mode==6||mode==7||mode==0x34||mode==0x35))?0x80:0);
 if(f==650)bank();
 if(!composer&&f>1100){bank();need(npc&&seen,"native graveyard NPC opens revised text");if(NEXT)need(done,"native Dampe digging choice remains reachable");puts("FRIEDHOF_NATIVE_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 need(f<2500,"graveyard dialogue completes");
}
'''
cases=[('boy',0x16c,0x2022,0,False,False),('boris',0x85,0x5018,0x5019,True,False)]
for case,npc,expected,nxt,night,composer in cases:
 if (W/f'qa-{mode}-{case}.log').exists()and'FRIEDHOF_NATIVE_PASSED'in(W/f'qa-{mode}-{case}.log').read_text():continue
 text=body
 for k,v in [('UPDATE_DEAD',sy['EnPoh_UpdateDead']),('SETUP_TALK',sy['EnPoh_Talk']),('COMPOSER',int(composer)),('EXPECTED',expected),('NEXT',nxt),('NPC',npc)]:text=text.replace(k,str(v))
 c=W/f'probe-{mode}-{case}.c';c.write_text(base[:a]+text+base[b:]);exe=W/f'probe-{mode}-{case}'
 subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
 q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0xe4,0 if composer else 1,0);struct.pack_into('>H',q,0xc,0xd000 if night else 0x8000);struct.pack_into('>I',q,0x10,int(night));q[0xed4:0xf34]=bytes(0x60);struct.pack_into('>I',q,0xa4,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,0,0,0,0,0xdff,0xe4,1);q[0x1409]=1;save=W/f'{case}.save';save.write_bytes(q)
 with(W/f'qa-{mode}-{case}.log').open('w')as log:r=subprocess.run([str(exe),rom,f'friedhof-v102-direct-{mode}-{case}','2700','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH=str(W/f'{mode}-{case}.pcm')),stdout=log,stderr=subprocess.STDOUT,timeout=350)
 log=(W/f'qa-{mode}-{case}.log').read_text();assert r.returncode==0 and'FRIEDHOF_NATIVE_PASSED'in log,(case,r.returncode,log[-2300:]);print('NATIVE_PASS',mode,case,flush=True)

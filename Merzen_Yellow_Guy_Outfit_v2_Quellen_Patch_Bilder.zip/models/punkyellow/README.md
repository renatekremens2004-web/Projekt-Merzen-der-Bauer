# punkyellow

Vom Nutzer bereitgestellte Vorlage: punk-yellow-guy-pilot.zip / rejected mupet.90obj.obj.

1.463 von 8.712 nichtdegenerierten Dreiecken, 74 Spieleinheiten hoch. MTL nicht mitgeliefert; Farbzuordnung aus yp.png rekonstruiert. 894 zusammengefallene Dreiecke entfernt. Zwei sparsame Pupillenscheiben ergänzen zusammen 16 Dreiecke.

Kleine CI4-Texturen, native Szenenbeleuchtung, Nebel und Tiefentest. Normalisierte Exportdaten: `tools/punkyellow_source.json`; diese und die lokalen Texturen reichen für `build_yellow_guy.py` aus. Die Blender-Konverter dienen der erneuten Aufbereitung der Nutzer-Uploads und erwarten den dort angegebenen Arbeitsordner.

Korrektur v2: Die ursprünglichen UVs der Kleidung werden verwendet. Die frühere Zuordnung zu einfarbigem Schwarz ließ Ärmel, Hautflächen und Aufnäher verschwinden. Der originale schwarze Stoff bekommt RGB 42/45/56 als dunklen Reflexionswert vor nativer Beleuchtung. Ein zusätzlicher kleiner Texturausschnitt erhält den PUNK-Aufnäher. Geometrie und Normalen unverändert.

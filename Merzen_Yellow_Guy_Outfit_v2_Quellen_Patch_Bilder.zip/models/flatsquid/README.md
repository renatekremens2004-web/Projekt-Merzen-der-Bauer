# Flacher Thaddäus auf Morphas festem Randboden

Vom Benutzer bereitgestellte Vorlage. 152,304 → 1,145 Dreiecke. Eigene Proportionen; Maße in Spieleinheiten: [83.44, 14.87, 105.0]. Native Beleuchtung, kleine CI4-Texturen, statisch ohne Physik oder Kollision.

Reproduzierbar mit tools/export_fundstuecke.py und tools/build_fundstuecke.py; letzterer folgt auf build_superhelden.py. Neue Nachrichten: 608A–608C.

# Chum Chum

Quelle: Nutzerarchiv `wii-nicktoons-mlb-characters-chum-chum.zip`, OBJ plus Originalatlas. 6.524 Quelldreiecke einschließlich optionaler Baseball-Ausrüstung und alternativer Hände. Verwendet: Body, LHand1, RHand1. Nach Reduktion 1.287 Dreiecke, ein 64×64-CI4-Atlas, vier eigene starre Matrixgruppen. 49 Spieleinheiten hoch, natürliche breite Cartoon-Proportionen, einheitlicher Maßstab. Keine Anpassung an Links oder eines anderen NPCs Knochenlängen.

Waldtempel-Raum 5 bei −1240/383/−1498, erwachsen/deutsch. Ein Körperkontakt-Zylinder, native Gesprächssteuerung und einfache eigene Stand-/Gesprächsbewegung. Keine Angriff-/Trefferkollision oder Questflags. Fanboy steht in Raum 3; die beiden Räume sind nicht benachbart. Keine zusätzlichen Objekt-Slots. Normale Beleuchtung und Nebel bleiben wirksam.

Keine neue Autor-/Lizenzangabe zum Upload behauptet. Dialog ist eigene Parodie nach Nutzeridee.

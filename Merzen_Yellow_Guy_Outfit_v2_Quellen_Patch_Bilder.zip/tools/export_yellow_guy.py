"""Reduce both supplied Yellow Guy models offline; own proportions and four rigid pose groups."""
import bpy,bmesh,json,math,sys,shutil
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);T=Matrix(((1,0,0),(0,0,1),(0,-1,0)))
def flat(d,name,rgb):
 im=bpy.data.images.new(name,width=8,height=8);im.pixels=[*(x/255 for x in rgb),1]*64;im.filepath_raw=str(d/(name+'.png'));im.file_format='PNG';im.save();return {'name':name,'texture':name+'.png','size':[8,8]}
for key,height in [('yellowguy',68),('punkyellow',74)]:
 normal=key=='yellowguy';bpy.ops.wm.open_mainfile(filepath=str(W/(('normal'if normal else'punk')+'-import.blend')),load_ui=False)
 D=R/'models'/key;D.mkdir(parents=True,exist_ok=True);objects=[o for o in bpy.context.scene.objects if o.type=='MESH'and o.name!='Plane.001'];original=0
 if normal:
  shutil.copyfile(W/'input/normal/textures/Albedo.png',D/'albedo.png')
  mats=[{'name':'albedo','texture':'albedo.png','size':[64,64]},flat(D,'black',[0,0,0]),flat(D,'white',[232,232,232]),flat(D,'blue',[13,0,231])]
  # Keep the wristwatch surface; the actual eyes are UV islands in the skin atlas.
  # Give those islands two small texture tiles so the original pupils survive CI4.
  eye_crops=[(0,0,384,256),(928,0,1312,256)]
  mats += [{'name':'eye'+str(i),'texture':'albedo.png','size':[64,64],'crop':list(box)}for i,box in enumerate(eye_crops)]
  o=objects[0];bpy.context.view_layer.objects.active=o;o.select_set(True)
  if o.data.shape_keys:o.shape_key_clear()
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='MATERIAL');bpy.ops.object.mode_set(mode='OBJECT');objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
 else:
  shutil.copyfile(W/'input/punk/textures/yp.png',D/'atlas.png')
  mats=[flat(D,n,c)for n,c in [('yellow',[255,218,13]),('orange',[255,163,0]),('white',[245,245,245]),('black',[9,9,11]),('pink',[225,77,182]),('silver',[142,142,145]),('mouth',[107,28,34])]]+[{'name':'atlas','texture':'atlas.png','size':[64,64]}]
  # Clothing uses its supplied UVs, including blue/green sleeves, bare skin and patches.
  # Pure black cannot show N64 lighting; retain a small dark textile reflectance.
  mats[7]['black_floor']=[42,45,56]
  mats.append({'name':'punk_patch','texture':'atlas.png','size':[64,64],'crop':[96,704,576,1024],'black_floor':[42,45,56]})
 points=[o.matrix_world@v.co for o in objects for v in o.data.vertices];bottom=min(p.z for p in points);top=max(p.z for p in points);scale=height*100/(top-bottom);center=Vector((0 if normal else 1.655,0,bottom))
 # Each part rotates around its own shoulder/neck, with unit scale throughout.
 source_piv=[Vector((0,0,0)),Vector((0,3.06,0)),Vector((-.65,2.85,-.25)),Vector((.65,2.85,-.25))]if normal else[Vector((0,0,0)),Vector((0,-.80-bottom,0)),Vector((-.65,-1.42-bottom,0)),Vector((.65,-1.42-bottom,0))]
 if normal:
  for p in source_piv[1:]:p.y-=bottom
 m={'bones':[{'name':n,'parent':-1,'position':[round(x*scale)for x in p]}for n,p in zip(['body','head','left_arm','right_arm'],source_piv)],'materials':mats,'vertices':[],'triangles':[]}
 for o in objects:
  bpy.context.view_layer.objects.active=o;o.select_set(True);me=o.data;me.calc_loop_triangles();original+=len(me.loop_triangles)
  for mod in list(o.modifiers):
   if mod.type=='MIRROR':bpy.ops.object.modifier_apply(modifier=mod.name)
   else:o.modifiers.remove(mod)
  me.transform(o.matrix_world);o.matrix_world=Matrix.Identity(4)
  bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);bm.to_mesh(me);bm.free()
  if normal:
   name=next(me.materials[p.material_index].name for p in me.polygons);ratio={'Material.004':.075,'Material.005':.085,'Material.006':1.,'Material.003':.08}[name]
  else:ratio={'Cube':.10,'Cube.004':.35,'Cube.006':.25,'Cube.008':.135,'Cube.010':.20,'Cube.011':1.,'Cube.013':.2,'Cube.014':.2,'Plane':.3,'Plane.002':.15,'Plane.003':.12}[o.name]
  if ratio<1:
   mod=o.modifiers.new('Compact N64 silhouette','DECIMATE');mod.ratio=ratio;bpy.ops.object.modifier_apply(modifier=mod.name)
  me.calc_loop_triangles();off=len(m['vertices']);rots=[];local=[]
  for v in me.vertices:
   p=T@(v.co-center);worldheight=p.y+bottom
   arm=(abs(p.x)>.8 and 2.4<worldheight<3.5)if normal else(o.name=='Cube.008' or(abs(p.x)>.65 and -2.55<worldheight<-.86))
   b=(2 if p.x<0 else 3)if arm else 1 if worldheight>(2.95 if normal else -1.0)else 0
   rot=Matrix.Rotation(math.radians(50*(1 if b==2 else -1)),3,'Z')if b>=2 else Matrix.Identity(3)
   local.append(p.copy())
   if b>=2:p=source_piv[b]+rot@(p-source_piv[b])
   m['vertices'].append({'bone':b,'position':[round(x*scale)for x in p]});rots.append(rot)
  for t in me.loop_triangles:
   name=me.materials[t.material_index].name
   if normal:mat={'Material.004':0,'Material.005':1,'Material.006':2,'Material.003':3}[name]
   else:
    mat={'Material.006':0,'Material':0,'Material.003':0,'Material.011':5,'Material.009':3,'Material.001':2,'Material.002':1,'Material.005':2,'Material.007':4,'Material.004':3,'Material.010':3,'Material.012':7,'Material.013':3,'Material.014':3,'Material.016':3,'Material.008':6,'Material.015':5}[name]
    if name=='Material.010'and abs(sum(local[vi].x for vi in t.vertices)/3)>1.95:mat=0
    if name in {'Material.009','Material.010','Material.012','Material.013','Material.014','Material.016','Material.015'}:mat=7
   uvs=[list(me.uv_layers.active.data[li].uv)if (normal and mat==0)or(not normal and mat==7)else[.5,.5]for li in t.loops]
   if normal and mat==0:
    for i,(x0,y0,x1,y1)in enumerate(eye_crops):
     if all(x0-.001<=u*2048<=x1+.001 and y0-.001<=(1-v)*2048<=y1+.001 for u,v in uvs):
      mat=4+i;uvs=[[(u*2048-x0)/(x1-x0),1-((1-v)*2048-y0)/(y1-y0)]for u,v in uvs];break
   if not normal and mat==7 and name=='Material.012':
    x0,y0,x1,y1=mats[8]['crop']
    if all(x0-.001<=u*1024<=x1+.001 and y0-.001<=(1-v)*1024<=y1+.001 for u,v in uvs):
     mat=8;uvs=[[(u*1024-x0)/(x1-x0),1-((1-v)*1024-y0)/(y1-y0)]for u,v in uvs]
   m['triangles'].append({'material':mat,'corners':[{'vertex':off+vi,'uv':uv,'normal':[round(x*127)for x in(rots[vi]@T@me.vertices[vi].normal).normalized()]}for vi,uv in zip(t.vertices,uvs)]})
 if not normal:
  # OBJ lacks its MTL; restore small dark pupils on the two existing white eyes.
  # Simple eight-triangle discs add only sixteen triangles, no extra texture.
  for x,z,y in [(1.775,.409,-.636),(1.489,.415,-.629)]:
   c=T@(Vector((x,y-.002,z))-center);off=len(m['vertices']);m['vertices'].append({'bone':1,'position':[round(v*scale)for v in c]})
   for i in range(8):
    p=c+Vector((math.cos(i*math.tau/8)*.055,math.sin(i*math.tau/8)*.055,0));m['vertices'].append({'bone':1,'position':[round(v*scale)for v in p]})
   for i in range(8):m['triangles'].append({'material':3,'corners':[{'vertex':j,'uv':[.5,.5],'normal':[0,0,127]}for j in [off,off+1+i,off+1+(i+1)%8]]})
 m.update(source_triangles=original,source='YellowGuy.fbx'if normal else'rejected mupet.90obj.obj',height_game_units=height,native_lighting=True,collapsed_source_mesh_removed=not normal)
 assert len(m['triangles'])<=1500,(key,len(m['triangles']))
 (R/f'tools/{key}_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');print(key,original,'->',len(m['triangles']),'triangles',flush=True)

/* Separate adult-only rooms; preserve all native guards, capture and escape logic. */
extern Gfx gWawarioDL[];
extern Gfx gWawaluigiDL[];
static s32 ElfMsg2_IsWawarioBros(Actor* actor, PlayState* play) {
    return actor->room == 0 &&
        ((play->sceneId == SCENE_GERUDOS_FORTRESS && actor->params == 0x3F7B) ||
         (play->sceneId == SCENE_GERUDO_VALLEY && actor->params == 0x3F7C));
}
static void ElfMsg2_DrawWawarioBros(Actor* actor, PlayState* play) {
    static Vec3f wawarioPivots[4] = { WAWARIO_PIVOTS };
    static Vec3f wawaluigiPivots[4] = { WAWALUIGI_PIVOTS };
    s32 orange = actor->params == 0x3F7B;
    Vec3f* pivots = orange ? wawarioPivots : wawaluigiPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (orange ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "wawario", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "wawario", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, orange ? gWawarioDL : gWawaluigiDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "wawario", 3);
}
static void ElfMsg2_InitWawarioBros(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 orange = actor->params == 0x3F7B;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = orange ? 0x608D : 0x608E;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 14);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 14;
    this->wallaceCollider.dim.height = orange ? 65 : 100;
    Actor_SetFocus(actor, orange ? 65 : 100);
    actor->draw = ElfMsg2_DrawWawarioBros;
}
static void ElfMsg2_UpdateWawarioBros(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 orange = actor->params == 0x3F7B;
    Actor_SetFocus(actor, orange ? 65 : 100);
    actor->textId = orange ? 0x608D : 0x608E;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

"""Split the supplied GLB by named parent, retaining each character's own proportions."""
import bpy,bmesh,json,math,sys
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1])
T=Matrix(((-1,0,0),(0,0,1),(0,1,0)))
for key,parent,height in [('wawario','Wawario',88),('wawaluigi','Wawaluigi',125)]:
 bpy.ops.wm.open_mainfile(filepath=str(W/'bros-import.blend'),load_ui=False)
 objects=[o for o in bpy.context.scene.objects if o.type=='MESH' and o.parent and o.parent.name==parent]
 assert len(objects)==(9 if key=='wawario'else 7)
 D=R/'models'/key;D.mkdir(parents=True,exist_ok=True)
 points=[o.matrix_world@v.co for o in objects for v in o.data.vertices]
 bottom=min(p.z for p in points);top=max(p.z for p in points);scale=height*100/(top-bottom)
 center=Vector((1 if key=='wawario'else -1,0,bottom))
 shoulder=.90 if key=='wawario'else 1.40
 piv=[Vector((0,0,0)),Vector((0,1.0 if key=='wawario'else 1.58,0)),Vector((.2,shoulder,0)),Vector((-.2,shoulder,0))]
 m={'bones':[{'name':name,'parent':-1,'position':[round(x*scale)for x in p]}for name,p in zip(['body','head','left_arm','right_arm'],piv)],'materials':[],'vertices':[],'triangles':[]}
 mids={};original=0
 for o in objects:
  for mat in o.data.materials:
   if mat.name in mids:continue
   img=next(n.image for n in mat.node_tree.nodes if n.type=='TEX_IMAGE'and n.image)
   name='material_'+str(len(mids));img.filepath_raw=str(D/(name+'.png'));img.file_format='PNG';img.save()
   mids[mat.name]=len(mids);size=8 if max(img.size)<=1 else 64
   m['materials'].append({'name':name,'texture':name+'.png','size':[size,size]})
  bpy.context.view_layer.objects.active=o;o.data=o.data.copy();me=o.data;me.calc_loop_triangles();original+=len(me.loop_triangles)
  for mod in list(o.modifiers):o.modifiers.remove(mod)
  me.transform(o.matrix_world);o.parent=None;o.matrix_world=Matrix.Identity(4)
  bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00001);bm.to_mesh(me);bm.free()
  head=o.name.startswith(('Head','Hat'));arm='Arm'in o.name or 'Hand'in o.name
  mod=o.modifiers.new('N64 compact mesh','DECIMATE');mod.ratio=.26 if head else .13;bpy.ops.object.modifier_apply(modifier=mod.name)
  b=1 if head else 2 if arm and o.name.startswith('Left')else 3 if arm else 0
  rot=Matrix.Rotation(math.radians((-40 if b==2 else 40)if key=='wawario'else(-55 if b==2 else 55)),3,'Z')if b>=2 else Matrix.Identity(3)
  off=len(m['vertices']);me.calc_loop_triangles()
  for v in me.vertices:
   p=T@(v.co-center)
   if b>=2:p=piv[b]+rot@(p-piv[b])
   m['vertices'].append({'bone':b,'position':[round(x*scale)for x in p]})
  for t in me.loop_triangles:
   m['triangles'].append({'material':mids[me.materials[t.material_index].name],'corners':[{'vertex':off+vi,'uv':list(me.uv_layers.active.data[li].uv),'normal':[round(x*127)for x in(rot@T@me.vertices[vi].normal).normalized()]}for vi,li in zip(t.vertices,t.loops)]})
 m.update(source='WawarioBros.glb/'+parent,source_triangles=original,height_game_units=height,native_lighting=True)
 (R/f'tools/{key}_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n')
 print(key,original,'->',len(m['triangles']),'triangles,',len(m['materials']),'materials',flush=True)

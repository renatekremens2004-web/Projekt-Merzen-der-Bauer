from pathlib import Path
import json,hashlib,re,shutil,zipfile
W=Path('/workspace/yellow-guy-v2');T=Path('/workspace/yellow-guy');R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts');P=R/'previews/yellow-guy-v2';V=R/'validation/yellow-guy-v2'
P.mkdir(parents=True,exist_ok=True);V.mkdir(parents=True,exist_ok=True)
sha=hashlib.sha256((O/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes()).hexdigest();report=json.loads((O/'build/pal-1.0/yellow-guy-verification.json').read_text());assert report['rom_sha256']==sha and report['outfit_revision']['changed_german_messages']==['608F'];assert json.loads((W/'patch-verification.json').read_text())['target_sha256']==sha
logs={};manifest=[]
for topic in ['normal','punk','punk-wide']:
 case='yellow-'+topic+'-outfit-v2-direct-clip-on';meta=json.loads((T/(case+'.json')).read_text());log=(T/(case+'.log')).read_text();assert meta['rom_sha256']==sha and 'RAM=4194304'in log and 'completed: 0'in log,topic
 assert not any(x in log for x in ['OBJECT_BANK_OVERFLOW','CAST_COLOAD_ERROR','UNKNOWN GBI COMMAND','Using Vertex outside buffer']),topic
 if topic!='punk-wide':assert log.count('id='+('608f'if topic=='normal'else'6073'))>=5
 logs[topic]=log
 for ext in ['.json','.log']:shutil.copyfile(T/(case+ext),V/(case+ext))
def photo(topic,index,dest):
 case='yellow-'+topic+'-outfit-v2-direct-clip-on';src=Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{index:03d}.png';shutil.copyfile(src,P/dest)
 shots=re.findall(r'PHOTO f=(\d+) kind=(\S+)',logs[topic]);manifest.append(dict(file=dest,case=case,frame=int(shots[index][0]),rom_sha256=sha,unedited_emulator_image=True))
photo('punk-wide',0,'Punk_Outfit_Ganzkoerper.png');photo('punk',1,'Punk_Outfit_Gespraech.png');photo('punk',4,'Punk_System.png');photo('normal',1,'Ohne_Selbstvorstellung.png')
(P/'Aufnahmen.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['package.py','check_patch.js','patch-verification.json','verification.log','export.log','uv_stats.py','uv.log']:shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/yellow-guy-verification.json',V/'yellow-guy-verification.json')
remaining=min(map(int,re.findall(r'OBJECT_BANK .*remaining=(\d+)',logs['punk'])))
doc=f'''# Yellow Guy: Outfit-Korrektur v2

Kumulativer Gesamtpatch auf unveränderte Europa/PAL-1.0-ROM, Original-MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{sha}`. Alle bisherigen Änderungen enthalten, weiterhin 1.013 eigene deutsche Nachrichten.

## Korrektur

Im vorigen Export waren mehrere UV-texturierte Körperteile pauschal schwarz eingefärbt. Dadurch gingen die farbigen Ärmel, gelben Hautflächen und Aufnäher verloren. Diese Flächen verwenden nun die ursprünglichen UV-Koordinaten und die mitgelieferte yp.png. Das Original-Outfit enthält auch weiterhin dunkle Jacke und Stiefel. Rein schwarze Texel der Kleidung bekommen vor der N64-Beleuchtung einen kleinen Reflexionswert RGB 42/45/56, damit Formen erkennbar bleiben. Ein eigener 64×64-Ausschnitt erhält den PUNK-Aufnäher. Der Kopf bleibt wie zuvor.

Keine neue Geometrie: weiterhin 1.463 Dreiecke, identische Positionen und Normalen, gleiche Höhe von 74 Einheiten, dieselben vier Bewegungsteile. Native Beleuchtung, Nebel und Tiefentest. Die Kleidung wird nicht selbstleuchtend. Der Raum vor Ganons Schloß wächst gegenüber v1 um 11.024 auf 134.816 Bytes. Keine zusätzlichen Akteure, Kollisionskörper, Objekt-Slots oder Matrizen. In der gemessenen Objektbank bleiben {remaining} Bytes frei; Raum-Puffer und Objektbank werden getrennt erfaßt.

608F beginnt jetzt „Oh. Hallo! Ich bin machen einen Ausflug. Nach ... hier. Hyrule.“ Die Selbstbenennung „Ich bin Yellow Guy“ ist entfernt. Der Punk stellt sich ebenfalls nicht mit diesem Namen vor. Alle anderen Dialoge, insbesondere Warios Kind-Zeitebene und seine Texte, bleiben gleich.

## Prüfung

Drei erfolgreiche Szenenproben auf genau dieser ROM mit Mupen64Plus/GLideN64 und tatsächlichen 4 MiB RAM: beide Gespräche vollständig lesen, schließen und wiederholen; dazu eine Ganzkörperansicht des Punks ohne Textkasten. Nur die lokale Spielerposition und der Fortschritt sind vorbereitet. NPC-Position, native Kamera und Beleuchtung werden nicht für die Bilder umgeschrieben. Keine beobachteten Abstürze, Objektbank-Überläufe oder fehlerhaften Grafikbefehle. Vor Ganons Schloß gilt die native feste Dämmerungszeit.

Alle 1.509 komprimierten Segmente mit dem vollständigen Neubau und die CIC-6105-Prüfsumme geprüft. 255 ursprüngliche Raum-Assets und 2.955 Kernfunktionen erhalten. Zusätzlich gegen die zuletzt veröffentlichte ROM mit SHA256 `3ccb86e313042254c168bd443f835b40a8095b6531641757d6599c6d94330676` geprüft: nur deutscher Text 608F geändert, alle anderen Nachrichten und Sprachen erhalten. Normales Yellow-Guy-Raumsegment und Wario-Raumsegment bytegenau identisch. Alle übrigen Segmente außerhalb der notwendigen ROM-Tabellen, deutschen Textdaten, Zeigertabellen und des Punk-Raums bleiben bytegleich oder enthalten ausschließlich echte MIPS-Linker-Relokationen. Punk-Geometrie, Normalen und Pivots ausdrücklich identisch. Alle 1.013 bearbeiteten Textpuffer erneut geprüft.

Die zehn Alters-/Sprach-/Tagesproben aus v1 bleiben in der Quellenhistorie als frühere Proben dokumentiert; sie werden nicht als erneut auf v2 ausgeführt ausgegeben. Ein vollständiger Durchlauf und echte N64-Hardware stehen weiterhin aus.

RomPatcher.js mit aktiver Quellvalidierung erzeugt aus Vanilla und BPS bytegenau die hier geprüfte Produktions-ROM. Nur Patch, Quellen, Prüfungen und unveränderte echte Emulatorbilder werden veröffentlicht; keine ROMs, Spielstände, Emulatorzustände oder ausführbaren Programme.
'''
(R/'TESTING_YELLOW_GUY_V2.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Yellow_Guy_Outfit_v2.bps';shutil.copyfile(patch,R/'patches'/patch.name)
instruction=A/'Anleitung_Yellow_Guy_Outfit_v2.txt';instruction.write_text('Yellow Guy: Outfit-Korrektur v2 — Gesamtpatch\n\nAuf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden, NICHT auf eine bereits gepatchte ROM. Original-MD5 e040de91a74b61e3201db0e2323f768a. Patcher: https://www.marcrobledo.com/RomPatcher.js/\n\nAlle bisherigen Änderungen enthalten. Punk-Outfit mit ursprünglichen Texturfarben und sichtbaren dunklen Stoffflächen. Keine Selbstvorstellung als Yellow Guy. Wario weiterhin ausschließlich im jungen Kakariko.\n\nDrei gezielte Emulatorproben mit 4 MiB bestanden; kompletter Durchlauf weiterhin ausstehend.\n')
heading='# Yellow Guy: Outfit-Korrektur v2';p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Neuer Gesamtpatch](patches/'+patch.name+') · [Prüfung](TESTING_YELLOW_GUY_V2.md) · [Echte Bilder](previews/yellow-guy-v2/)\n\nUrsprüngliche Texturfarben des Punk-Outfits wiederhergestellt; Selbstvorstellung entfernt. Alle bisherigen Änderungen enthalten.\n\n'+p.read_text())
images=A/'Yellow_Guy_Outfit_v2_Bilder.zip'
with zipfile.ZipFile(images,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.iterdir()):z.write(p,p.name)
archive=A/'Merzen_Yellow_Guy_Outfit_v2_Quellen_Patch_Bilder.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl','.mp4'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R)
  if not p.is_file()or any(x in exclude for x in rel.parts)or p.suffix.lower()not in suffixes:continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='yellow-guy-v2':continue
  with p.open('rb')as f:assert f.read(4)not in [bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and not any(Path(x).suffix.lower()in{'.rom','.z64','.n64','.v64','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st'}for x in z.namelist())
files=[patch,images,archive,instruction];sums=A/'SHA256SUMS_Yellow_Guy_Outfit_v2.txt';sums.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in files))
for p in files+[sums]:shutil.copyfile(p,D/p.name)
G=D/'Yellow_Guy_Outfit_v2_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
shutil.copyfile(R/'planning/YELLOW_GUY_WARIO_DIALOGE.md',D/'Yellow_Guy_Wario_Dialoge.md')
heading='# Merzen der Bauer: Yellow Guy Outfit v2';p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Aktueller BPS-Gesamtpatch]('+patch.name+'?raw=true) · [Neue Ingame-Bilder]('+images.name+'?raw=true) · [Quellen und Prüfungen]('+archive.name+'?raw=true)\n\nPunk-Outfit mit den ursprünglichen Texturfarben; Selbstvorstellung entfernt. Alle bisherigen Änderungen enthalten. Auf unveränderte Europa/PAL-1.0-ROM anwenden. Drei gezielte Szenenproben mit 4 MiB bestanden.\n\n![Punk-Outfit](Yellow_Guy_Outfit_v2_Beispielbilder/Punk_Outfit_Ganzkoerper.png)\n\n'+p.read_text())
print('Packaged outfit v2:',sha,'3 runtime cases, 4 genuine screenshots;',archive.stat().st_size,'source bytes')

import bpy,json
from pathlib import Path
bpy.ops.wm.open_mainfile(filepath='/workspace/yellow-guy/punk-import.blend',load_ui=False)
out=[]
for o in bpy.context.scene.objects:
 if o.type!='MESH' or o.name=='Plane.001':continue
 me=o.data;me.calc_loop_triangles()
 for t in me.loop_triangles:
  out.append(dict(obj=o.name,mat=me.materials[t.material_index].name,p=[list(o.matrix_world@me.vertices[v].co)for v in t.vertices],uv=[list(me.uv_layers.active.data[i].uv)for i in t.loops]))
Path('/workspace/yellow-guy-v2/uv.json').write_text(json.dumps(out))

from pathlib import Path
import json,shutil
R=Path('/workspace/Projekt-Merzen-der-Bauer');W=Path('/workspace/wawario-bros');O=Path('/workspace/oot-burns-pal')
shutil.copyfile(O/'build/pal-1.0/oot-pal-1.0-compressed.z64',W/'model-tested.z64');shutil.copyfile(O/'build/pal-1.0/oot-pal-1.0.map',W/'model-tested.map')
p=R/'story/hyrule_nachschlag_de.json';j=json.loads(p.read_text());del j['messages']['7025'];del j['messages']['7026'];p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'story/wawario_de.json';j=json.loads(p.read_text());j['messages'].update({
 '7025':{'pages':['Waluigi ist so ein seltsamer lila Typ.','Kennste den, Liebling?','Der ist kürzlich von der Schule geflogen, der Depp.','Aus dem wird doch eh nichts mehr!']},
 '7026':{'pages':['Dieser Waluigi...','Der trägt doch immer Lila, oder?','Ja, den kenn ich!','Von der Schule geflogen!','Aus dem wird doch eh nichts mehr, Schatz.']},
 '5089':{'pages':['Jetzt ist es schon sieben Jahre her, daß Waluigi von der Schule geflogen ist...','...und er hat immer noch nischts aus seinem Leben gemacht. Was ein Loser, meine Liebe!']},
 '508A':{'pages':['Waluigi? Dieser seltsame lila Typ?','Was ein Loser. Aus dem wird doch eh nichts mehr, Liebling!']},
 '505C':{'pages':['Hast Du diese seltsamen Kinder getroffen? Sie nennen sich Fanboy und Chum Chum.',"Halten sich für so 'ne Art Superhelden. Pah! Was Menschen nicht alles tun, um sich von der Arbeit zu drücken!"]},
 '507D':{'pages':['Glaubst Du, Goronen stehen auf Rock and Ball Torture?']},
 '5088':{'pages':['Hab letztens so ein Horrorkid-Ding getroffen.','Niedliches Kerlchen.','Tut keiner Fliege was zuleide.']}
});p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'story/wallace_de.json';j=json.loads(p.read_text());j['messages']['019A']['pages']=[
 'Oh, hi, lad! Wallace hier. Die Goronen sind ein prächtiges Völkchen. Steine zum Abendbrot! Da fehlt bloß der Käse.',
 'Ich erforsche, wie man das Klima auf dem Todesberg überlebt. Hier ist es heißer als in meinem Käsetoaster!',
 'Not macht erfinderisch! Ich tüftle an einem hitzefesten Gewand. Mein Wensleydale ist leider schon geschmolzen.',
 'Dann hat Friedrich Merz mit seinem Kohleabbau den Eingang verschüttet. Da hatten wir den Käse! Ein Fiasko.',
 'Jetzt sitze ich hier fest. Ich wollte die Goronen erforschen, nicht bei ihnen einziehen. Und der Gouda wird knapp, lad!'
];p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'story/feuertempel_wallace_de.json';j=json.loads(p.read_text());j['messages']['209E']['pages']=[
 'Oh, hi, lad! Wallace hier. Die Zelle ist von außen verriegelt. Da haben wir den Käse. Leider nur im übertragenen Sinne.',
 'Könntest Du den Schalter für die Zelle suchen? Ich muß hier raus, bevor aus meinem Gouda Fondue wird!'
];j['messages']['209D']['pages']=[
 'Oh, hi, lad! Wallace hier. Sieben Jahre hab ich hier geforscht. Jetzt kenne ich mehr heiße Ecken als Käsesorten!',
 'Seit Merz hier das Sagen hat, ist es ungemütlich. Wo gehobelt wird, fallen Späne. Bei dem Mann fällt gleich die ganze Hütte.',
 'Seine Leute nennen das Schichtarbeit. Ich nenne das: Ich sitze in einer Zelle. Nicht einmal eine Käseglocke ist so hermetisch!',
 'Vielleicht kannst Du etwas machen? Das ist kein Aufruf zur Sabotage. Ich will bloß wieder in Ruhe mein Käsebrot schmieren.',
 'Hier im Tempel liegt meine neueste Erfindung: der Wallace Hammer! Not macht erfinderisch. Merz macht leider vor allem Not.',
 'Der zerschlägt Gestein und Schalter. Für die Käserinde ist er etwas überdimensioniert. Man soll ja nicht mit Hämmern auf Gouda hauen.',
 'Du findest den Hammer weiter oben im Tempel. Ich geh schon mal. Erst die Arbeit, dann das Käsebrot. Danke, lad!'
];p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
p=R/'tools/verify_wawario.py';s=p.read_text().replace('len(edits)==1005','len(edits)==1010').replace("assert set(diff)==set(chapter),diff","assert set(diff)==set(chapter)|{'019A','209D','209E'},diff");p.write_text(s)

from pathlib import Path
import re,json,struct,subprocess
W=Path('/workspace/wawario-bros');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text()
syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
s=Path('/workspace/drei-fundstuecke/runner.c').read_text().replace('0x800ef7c0+3*0x30',hex(syms['gGameStateOverlayTable'])+'+3*0x30').replace('0x800f7488+obj*8',hex(syms['gObjectTable'])+'+obj*8')
s=s.replace('strstr(scenario,"triangle")?0x80:0x800','0x80')
s=s.replace('/workspace/drei-fundstuecke/ganon-free-play.st','/workspace/wawario-bros/ganon-free-play.st')
needle='  if(f%100==0){\n   uint32_t fan='
assert s.count(needle)==1
s=s.replace(needle,'''  if(f%100==0) {
   uint32_t wa=actor_type(0x173,0x7b),wal=actor_type(0x173,0x7c);
   printf("BROS f=%u orange=%08x blue=%08x orange_floor=%.1f blue_floor=%.1f\\n",f,wa,wal,wa?rf(wa+0x80):0,wal?rf(wal+0x80):0);
  }
'''+needle)
(W/'runner.c').write_text(s)
base=bytearray(Path('/workspace/pepsiman-water/man-30.save').read_bytes())
def fixture(name,ent,scene,room,pos,yaw=0,age=0,lang=1,night=False):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,room);b[0x1409]=lang;struct.pack_into('>HH',b,0x2e,320,320);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);b[0x34]=1;struct.pack_into('>H',b,0x0c,0 if night else 0x8000);off=0xd4+scene*0x1c;b[off:off+0x1c]=bytes(0x1c)
 struct.pack_into('>H',b,0x70,0x1122 if not age else 0x1111);b[0x4a:0x54]=b[0x68:0x72];(W/(name+'.save')).write_bytes(b)
for topic,ent,scene,pos,yaw in [('orange',0x3b4,0x5d,(245.,733.,-2945.),23000),('blue',0x117,0x5a,(-1305.,15.,-360.),-25000)]:
 for suffix,kw in [('',{}),('-night',{'night':True}),('-child',{'age':1}),('-english',{'lang':0})]:fixture(topic+suffix,ent,scene,0,pos,yaw,**kw)
fixture('triangle',0x517,0x4f,0,(970.,1086.,-186.),-16384)
fixture('critic',0x2fd,0x2a,0,(85.,0.,-90.),23000)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
s=Path('/workspace/drei-fundstuecke/run.py').read_text().replace('/workspace/drei-fundstuecke','/workspace/wawario-bros').replace("case='fund-' ","case='wawario-' ")
(W/'run.py').write_text(s)

from pathlib import Path
import hashlib,json,subprocess,os
W=Path('/workspace/wawario-bros');rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64');s=json.loads((W/'symbols.json').read_text())
for topic,fixture,runner,limit in [('triangle-angle-replay','triangle','angle_runner',700),('blue-english','blue-english','runner',350),('capture','capture','runner',650)]:
 case='wawario-'+topic+'-final-direct-clip-on'
 (W/(case+'.json')).write_text(json.dumps(dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),fixture=fixture,frame_limit=limit,prepared_player_and_progress_only=True,native_actor_positions=True,final_rom_own_state_replay='replay'in topic),indent=2)+'\n')
 with(W/(case+'.log')).open('w')as log:subprocess.run([str(W/runner),str(rom),case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(fixture+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)

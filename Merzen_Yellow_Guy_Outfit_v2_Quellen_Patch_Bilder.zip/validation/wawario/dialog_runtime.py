from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import re,json,struct,shutil,subprocess,hashlib,os
W=Path('/workspace/wawario-bros');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};assert syms==json.loads((W/'symbols.json').read_text())
base=bytearray((W/'orange.save').read_bytes())
def fixture(name,ent,scene,pos,yaw=0,age=0,night=False):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,0);struct.pack_into('>H',b,0x0c,0 if night else 0x8000);struct.pack_into('>I',b,0x10,int(night));struct.pack_into('>H',b,0x70,0x1111 if age else 0x1122);(W/(name+'.save')).write_bytes(b);return b
fixture('couple-child',0xb1,0x20,(132.,0.,42.),-32768,age=1)
fixture('couple-adult',0xdb,0x52,(1671.,539.,442.),-32768)
b=fixture('fanboy-comment',0x39c,0x37,(105.,0.,-64.));i=0xef8+(0x162>>4)*2;struct.pack_into('>H',b,i,struct.unpack_from('>H',b,i)[0]|(1<<(0x162&15)));(W/'fanboy-comment.save').write_bytes(b)
fixture('rock-ball',0x39c,0x37,(-35.,0.,-140.),-23000,night=True)
fixture('horrorkid',0x2fd,0x2a,(-90.,0.,-50.),-19000,night=True)
shutil.copyfile('/workspace/wallace/child.save',W/'wallace-child.save')
shutil.copyfile('/workspace/feuertempel-wallace/prison-locked.save',W/'wallace-locked.save')
# Run free_wallace_native.py separately for the freed branch: opening the switch before loading correctly despawns this native prisoner.
rom=O/'build/pal-1.0/oot-pal-1.0-compressed.z64'
def run(job):
 topic,limit=job;case='wawario-'+topic+'-dialog-final-direct-clip-on';meta=dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),fixture=topic,frame_limit=limit,prepared_player_and_progress_only=True,native_actor_positions=True)
 (W/(case+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
 with(W/(case+'.log')).open('w')as log:subprocess.run([str(W/'runner'),str(rom),case,str(limit),'4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,[('couple-child',900),('couple-adult',700),('fanboy-comment',500),('rock-ball',450),('horrorkid',500),('wallace-child',950),('wallace-locked',650)]))

from pathlib import Path
import subprocess,hashlib,json,os
W=Path('/workspace/wawario-bros');rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64');s=json.loads((W/'symbols.json').read_text());case='wawario-capture-hookshot-final-direct-clip-on'
(W/(case+'.json')).write_text(json.dumps(dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),fixture='capture-hookshot',frame_limit=500,prepared_player_and_progress_only=True,native_actor_positions=True,start_position=[-450,333,-1820],hookshot_owned=True),indent=2)+'\n')
with(W/(case+'.log')).open('w')as log:subprocess.run([str(W/'runner'),str(rom),case,'500','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/'capture-hookshot.save')],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
print('Completed',case,flush=True)

from pathlib import Path
import re,json,struct,subprocess,hashlib,os
W=Path('/workspace/wawario-bros');b=bytearray(Path('/workspace/feuertempel-wallace/prison-free.save').read_bytes());struct.pack_into('>I',b,0xd4+4*0x1c+4,0);struct.pack_into('>fffh',b,0x1368,2320.,2800.,900.,-5200);(W/'wallace-free-native.save').write_bytes(b)
s=(W/'runner.c').read_text();needle='  if(f%100==0){\n   uint32_t fan='
extra='''  if (strstr(scenario,"wallace-free-native") && mode==0) {
   static unsigned opened=0;
   float tx=2320.0f,tz=940.0f,dx,dz,dist;
   if ((r32(play+0x1d28)&8) && !opened) opened=f+1;
   value=0;
   if (opened && f>=opened+45) {tx=2212.0f;tz=1035.0f;value=0x20;if(f%50<4)value|=0x80;}
   dx=tx-rf(player+0x24);dz=tz-rf(player+0x2c);dist=sqrtf(dx*dx+dz*dz);
   if(f>150 && (!opened || f>=opened+45) && dist>10) {
    uint32_t cam=r32(play+0x790+DebugMemRead16(play+0x7a0)*4);float fx=rf(cam+0x50)-rf(cam+0x5c),fz=rf(cam+0x58)-rf(cam+0x64),len=sqrtf(fx*fx+fz*fz);
    if(len>1) {fx/=len;fz/=len;dx/=dist;dz/=dist;int x=roundf((dz*fx-dx*fz)*45),y=roundf((dx*fx+dz*fz)*45);value=((unsigned)(uint8_t)x<<16)|((unsigned)(uint8_t)y<<24);}
   }
  }
'''
assert s.count(needle)==1;s=s.replace(needle,extra+needle);(W/'free_runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'free_runner.c'),'-o',str(W/'free_runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64');syms=json.loads((W/'symbols.json').read_text());case='wawario-wallace-free-native-dialog-final-direct-clip-on'
(W/(case+'.json')).write_text(json.dumps(dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),fixture='wallace-free-native',frame_limit=1350,prepared_player_and_progress_only=True,native_actor_positions=True,native_floor_switch_activated_by_player=True),indent=2)+'\n')
with(W/(case+'.log')).open('w')as log:subprocess.run([str(W/'free_runner'),str(rom),case,'1350','4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/'wallace-free-native.save')],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
print('Completed',case,flush=True)

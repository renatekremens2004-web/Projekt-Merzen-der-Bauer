from pathlib import Path
import re,json,struct,subprocess
W=Path('/workspace/yellow-guy');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
s=Path('/workspace/wawario-bros/runner.c').read_text().replace('0x800ef7c0+3*0x30',hex(syms['gGameStateOverlayTable'])+'+3*0x30').replace('0x800f7488+obj*8',hex(syms['gObjectTable'])+'+obj*8')
a=s.index('  uint32_t ganon=');b=s.index('  if(f%100==0){\n   uint32_t fan=',a)
s=s[:a]+'''  if(f%100==0) {
   uint32_t yellow=actor_type(0x173,0x7d),punk=actor_type(0x173,0x7e),wario=actor_type(0x173,0x7f);
   printf("CAST f=%u yellow=%08x punk=%08x wario=%08x yellow_y=%.1f punk_y=%.1f wario_y=%.1f age=%u time=%x\\n",f,yellow,punk,wario,yellow?rf(yellow+0x28):0,punk?rf(punk+0x28):0,wario?rf(wario+0x28):0,r32(savebase+4),DebugMemRead16(savebase+0xc));
   if((yellow&&punk)||(yellow&&wario)||(punk&&wario)){fprintf(stderr,"CAST_COLOAD_ERROR\\n");exit(95);}
  }
'''+s[b:]
(W/'runner.c').write_text(s)
base=bytearray(Path('/workspace/pepsiman-water/man-30.save').read_bytes())
def fixture(name,ent,scene,pos,yaw=0,age=1,night=False,lang=1):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,0);b[0x1409]=lang;struct.pack_into('>HH',b,0x2e,160,160);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);b[0x34]=1;struct.pack_into('>H',b,0x0c,0 if night else 0x8000);struct.pack_into('>I',b,0x10,int(night));off=0xd4+scene*0x1c;b[off:off+0x1c]=bytes(0x1c);struct.pack_into('>H',b,0x70,0x1111 if age else 0x1122);b[0x4a:0x54]=b[0x68:0x72];(W/(name+'.save')).write_bytes(b)
for topic,ent,scene,pos,yaw,age in [('normal',0x138,0x5f,(-425.,1085.,3610.),-32768,1),('punk',0x138,0x64,(300.,1307.,1810.),-32768,0),('wario',0xdb,0x52,(-962.,80.,950.),16384,1)]:
 for suffix,kw in [('',{}),('-night',{'night':True}),('-english',{'lang':0})]:fixture(topic+suffix,ent,scene,pos,yaw,age=age,**kw)
fixture('wario-adult',0xdb,0x52,(-962.,80.,950.),16384,age=0)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
s=Path('/workspace/wawario-bros/run.py').read_text().replace('/workspace/wawario-bros','/workspace/yellow-guy').replace("case='wawario-' ","case='yellow-' ");(W/'run.py').write_text(s)

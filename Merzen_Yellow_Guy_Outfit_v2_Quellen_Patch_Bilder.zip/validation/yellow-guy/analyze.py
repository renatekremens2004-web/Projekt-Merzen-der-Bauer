import bpy,json
from pathlib import Path
W=Path('/workspace/yellow-guy');all={}
for key in ['normal','punk']:
 bpy.ops.wm.read_factory_settings(use_empty=True)
 if key=='normal':bpy.ops.import_scene.fbx(filepath=str(W/'input/normal/source/YellowGuy.fbx'))
 else:bpy.ops.wm.obj_import(filepath=str(next((W/'input/punk/nested').glob('*.obj'))),forward_axis='NEGATIVE_Z',up_axis='Y')
 r={'objects':[],'materials':[]}
 for o in bpy.context.scene.objects:
  q={'name':o.name,'type':o.type,'matrix':[list(v)for v in o.matrix_world],'parent':o.parent.name if o.parent else None,'modifiers':[(m.name,m.type)for m in o.modifiers]}
  if o.type=='MESH':
   m=o.data;m.calc_loop_triangles();points=[o.matrix_world@v.co for v in m.vertices];q.update(triangles=len(m.loop_triangles),vertices=len(m.vertices),bounds=[[min(p[k]for p in points),max(p[k]for p in points)]for k in range(3)],materials=[m.name for m in o.data.materials],uvs=[v.name for v in m.uv_layers])
   q['groups']={g.name:sum(any(k.group==g.index and k.weight>.1 for k in v.groups)for v in m.vertices)for g in o.vertex_groups}
  if o.type=='ARMATURE':q['bones']=[{'name':b.name,'head':list(o.matrix_world@b.head_local),'tail':list(o.matrix_world@b.tail_local)}for b in o.data.bones]
  r['objects'].append(q)
 for m in bpy.data.materials:r['materials'].append({'name':m.name,'images':[{'image':n.image.name,'path':n.image.filepath,'size':list(n.image.size)}for n in m.node_tree.nodes if n.type=='TEX_IMAGE'and n.image]if m.use_nodes else []})
 all[key]=r;bpy.ops.wm.save_as_mainfile(filepath=str(W/(key+'-import.blend')))
(W/'models.json').write_text(json.dumps(all,indent=2));print(json.dumps(all,indent=2))

import bpy,json
from pathlib import Path
bpy.ops.wm.open_mainfile(filepath='/workspace/yellow-guy/normal-import.blend',load_ui=False);o=next(o for o in bpy.context.scene.objects if o.type=='MESH');me=o.data;me.calc_loop_triangles();r=[]
for t in me.loop_triangles:
 ps=[o.matrix_world@me.vertices[i].co for i in t.vertices]
 if me.materials[t.material_index].name=='Material.004'and min(p.z for p in ps)>3.3:r.append({'p':[list(p)for p in ps],'uv':[list(me.uv_layers.active.data[i].uv)for i in t.loops]})
Path('/workspace/yellow-guy/face-uv.json').write_text(json.dumps(r))

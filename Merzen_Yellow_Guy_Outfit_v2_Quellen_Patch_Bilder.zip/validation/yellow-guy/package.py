from pathlib import Path
import json,re,hashlib,shutil,zipfile

W=Path('/workspace/yellow-guy');R=Path('/workspace/Projekt-Merzen-der-Bauer');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts');O=Path('/workspace/oot-burns-pal');P=R/'previews/yellow-guy';V=R/'validation/yellow-guy'
P.mkdir(parents=True,exist_ok=True);V.mkdir(parents=True,exist_ok=True)
sha=hashlib.sha256((O/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes()).hexdigest();report=json.loads((O/'build/pal-1.0/yellow-guy-verification.json').read_text());assert report['rom_sha256']==sha
patch_report=json.loads((W/'patch-verification.json').read_text());assert patch_report['target_sha256']==sha and patch_report['rompatcher_js_source_validation']
positive={'normal':'608f','punk':'6073','wario':'601c','normal-night':'608f','punk-night':'6073','wario-night':'601c'};negative=['wario-adult','normal-english','punk-english','wario-english'];logs={}
for topic in list(positive)+negative:
 case='yellow-'+topic+'-final-direct-clip-on';meta=json.loads((W/(case+'.json')).read_text());log=(W/(case+'.log')).read_text();assert meta['rom_sha256']==sha and 'RAM=4194304'in log and 'completed: 0'in log,topic
 assert not any(v in log for v in ['OBJECT_BANK_OVERFLOW','CAST_COLOAD_ERROR','UNKNOWN GBI COMMAND','Using Vertex outside buffer']),topic
 if topic in positive:
  assert 'id='+positive[topic] in log and log.count('id='+positive[topic])>=5,topic
  casts=re.findall(r'CAST f=\d+ yellow=([0-9a-f]+) punk=([0-9a-f]+) wario=([0-9a-f]+).*age=(\d+)',log);assert casts,topic
  expected={'normal':0,'punk':1,'wario':2}[topic.split('-')[0]]
  assert all(bool(int(c[expected],16))and sum(bool(int(x,16))for x in c[:3])==1 and int(c[3])==(0 if expected==1 else 1)for c in casts),topic
 else:
  assert re.search(r'CAST f=100 yellow=00000000 punk=00000000 wario=00000000',log),topic
  assert not re.search(r'TEXT .*id=(608f|6073|601c)',log),topic
 logs[topic]=log
 for ext in ['.json','.log']:shutil.copyfile(W/(case+ext),V/(case+ext))
for name in ['analyze.py','prepare_runtime.py','runner.c','run.py','check_patch.js','patch-verification.json','verification.log','export.log','export-wario.log','models.json','face_uv.py','face-uv.log','package.py']:
 shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/yellow-guy-verification.json',V/'yellow-guy-verification.json')
manifest=[]
def photo(topic,dest,page=None):
 case='yellow-'+topic+'-final-direct-clip-on';shots=[];last=None
 for line in logs[topic].splitlines():
  m=re.match(r'TEXT f=(\d+) id=([0-9a-f]+)',line)
  if m:last=int(m[2],16)
  m=re.match(r'PHOTO f=(\d+) kind=(\S+)',line)
  if m:shots.append((int(m[1]),last if m[2]=='text'else None))
 idx=0 if page is None else [i for i,x in enumerate(shots)if x[1]==int(positive[topic],16)][page]
 src=Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{idx:03d}.png';shutil.copyfile(src,P/dest)
 manifest.append(dict(file=dest,case=case,frame=shots[idx][0],message=None if shots[idx][1]is None else f'{shots[idx][1]:04X}',rom_sha256=sha,unedited_emulator_image=True))
photo('normal','Yellow_Guy_am_Schlossweg.png');photo('normal','Yellow_Guy_Gespraech.png',0);photo('normal','Yellow_Guy_Koenig.png',2)
photo('punk','Punk_Yellow_Guy_vor_Ganons_Schloss.png');photo('punk','Punk_Frimdrich_Merz.png',1);photo('punk','Punk_System.png',3)
photo('wario','Wario_im_jungen_Kakariko.png');photo('wario','Wario_Begruessung.png',0);photo('wario','Wario_sorgt_sich_um_Waluigi.png',3)
photo('normal-night','Yellow_Guy_Nacht.png',0);photo('wario-night','Wario_Nacht.png',0)
(P/'Aufnahmen.json').write_text(json.dumps(manifest,indent=2)+'\n')
remaining={topic:min(map(int,re.findall(r'OBJECT_BANK .*remaining=(\d+)',log)))for topic,log in logs.items()}
doc=f'''# Yellow Guy und Wario

Kumulativer BPS-Gesamtpatch auf die unveränderte Europa/PAL-1.0-ROM. Original-MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{sha}`. Alle bisherigen Änderungen enthalten; nun 1.013 eigene deutsche Nachrichten. ROM-Datei weiterhin 40 MiB; alle unten aufgeführten Emulatorproben mit tatsächlich 4 MiB N64-Arbeitsspeicher.

## Figuren und Orte

Normaler Yellow Guy steht im jungen Hyrule am Schloßweg direkt nach Verlassen des Marktes, bei −425/1085/3550. Punk Yellow Guy steht in der Zukunft vor Ganons Schloß bei 300/1315/1750. Wario steht ausschließlich im KIND-Kakariko bei −900/80/950. Die anfängliche Erwachsenen-Angabe wurde ausdrücklich korrigiert. Wario ist auch nachts ansprechbar; erwachsene Akteurslisten bleiben unverändert. Beide Schloßfiguren verwenden ebenfalls ihre passende Zeitebene, Ganons Zwischensequenzliste bleibt unverändert. Alle drei stehen seitlich auf nativen begehbaren Flächen, abseits von Toren, Türen und Rätselobjekten. Positionen werden nicht für Vorschaubilder verändert.

Eigene Modellproportionen und vier kleine starre Kopf-/Armtransformationen; kein fremdes Skelett und kein Strecken von Gliedmaßen. Native Beleuchtung, Nebel und Tiefentest. Normale, wiederholbare A-Gespräche ohne Quest-, Inventar- oder Geldänderungen. Nur Deutsch, normale manuelle Seiten. Feste Szenen- und Lesezeiten bleiben gleich. Die drei zuvor unbenutzten Textplätze 608F/6073/601C verwenden das Standardformat 0022. Alle vorherigen 1.010 bearbeiteten Nachrichten und sämtliche anderen Sprachen bleiben erhalten.

Normaler Yellow Guy: 17.326 auf 1.393 Dreiecke, 68 Einheiten hoch. Sein ursprüngliches FBX enthält Formschlüssel, die vor dem Zerlegen in Materialien entfernt werden, bei erhaltener Basisform. Eigene Armhaltung mit abgesenkten Armen. Die echten Augen liegen in der Hauttextur; zwei kleine 64×64-Ausschnitte erhalten die winzigen Originalpupillen. Die separate weiße Modellfläche gehört zur Armbanduhr. Punk: 8.712 brauchbare auf 1.463 Dreiecke, 74 Einheiten einschließlich Irokesenschnitt. 894 degenerierte Dreiecke ohne räumliche Ausdehnung entfernt. Im mitgelieferten OBJ fehlt die MTL; Farben aus dem gelieferten Atlas auf die passenden Teile verteilt. Zwei einfache Pupillen ergänzen zusammen 16 der 1.463 Dreiecke. Wario aus Mario Tennis bleibt vollständig mit seinen 460 Dreiecken erhalten, 82 Einheiten hoch. Keine Detailreduktion nötig.

## Speicher

Modelle in den drei jeweiligen Raumsegmenten; keine zusätzlichen Objekt-Slots. CI4, Texturen maximal 64×64; einfarbige Flächen 8×8. Die native Raum-Puffergröße wächst am Schloßweg von 53.696 auf 111.776 Bytes, vor Ganons Schloß von 80.624 auf 123.792 Bytes und in Kakariko von 40.672 auf 53.728 Bytes. Das vorhandene Elf-Msg2-Overlay wächst um 2.240 Bytes. Keine Vergrößerung der Akteursstruktur; vorhandener Zylinderbereich wird wiederverwendet und auch vor einer Alters-/Sprachentfernung korrekt initialisiert. Pro sichtbarer Figur vier Matrizen, 256 Bytes aus dem bestehenden Grafikpuffer. Kleine Gesprächskollision, keine Angriffs-/Trefferkollision und keine Raum-Clear-Bedingung. In den gemessenen positiven Tagesszenen bleiben in der nativen Objektbank mindestens {remaining['normal']:,} Bytes am Schloßweg, {remaining['punk']:,} vor Ganons Schloß und {remaining['wario']:,} in Kakariko frei.

## Prüfung

Zehn erfolgreiche Szenenproben auf genau der oben genannten Produktions-ROM mit Mupen64Plus/GLideN64 und 4 MiB: alle drei Figuren mit Tages- und Nachtspielstand (vor Ganons Schloß gilt die native feste Dämmerungszeit), zusätzlich Kakariko als Erwachsener ohne Wario sowie alle drei Orte auf Englisch ohne die privaten Ergänzungen. In den positiven Proben alle Textseiten gelesen, Gespräche geschlossen und wiederholt. Eigene NPC-Positionen und die native Gesprächskamera bleiben unverändert. Die lokalen Spielstands-Fixtures bereiten ausschließlich Spielerposition, Alter, Zeit, Sprache und Fortschritt vor. Keine ROM-Schnellstartänderung. Keine beobachteten Abstürze, Objektbanküberläufe oder fehlerhaften Grafikbefehle in diesen Proben. Die englischen Proben prüfen auch das sichere Entfernen nach Initialisierung.

Alle 1.509 komprimierten Segmente gegen den vollständigen Neubau geprüft; korrekte CIC-6105-Prüfsumme. 255 ursprüngliche Raum-Assets und native Akteurslisten-Präfixe anhand ihrer Originalbytes bzw. echter MIPS-Linker-Relokationen erhalten. Native Türen, Kollision, Raumgeometrie, Wachen und Questabläufe unverändert. 2.955 Kernfunktionen sowie bisherige private Helfer erhalten. Alle 1.013 bearbeiteten deutschen Textpuffer geprüft, einschließlich maximaler Länge des Spielernamens. Gegenüber dem vorherigen Gesamtpatch ändern sich genau die drei hier genannten deutschen Nachrichten. Vorherige Modelle, Boßmechaniken, Stiefelumschaltung, Kampfanpassungen, Weisen und Dialoge bleiben erhalten.

RomPatcher.js mit aktivierter Quellvalidierung erzeugt aus Vanilla und BPS bytegenau die geprüfte Produktions-ROM. Veröffentlicht werden Patch, Quellen, Prüfprotokolle und unveränderte Emulatorbilder. Keine ROMs, Spielstände, Emulatorzustände, RAM-Abbilder oder ausführbaren Programme.

Ein vollständiger normaler Spieldurchlauf und echte N64-Hardware sind weiterhin nicht geprüft. Die bestandenen Szenenproben decken die hier ergänzten Figuren und Alters-/Sprachgrenzen ab.
'''
(R/'TESTING_YELLOW_GUY_WARIO.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Yellow_Guy_Wario.bps';shutil.copyfile(patch,R/'patches'/patch.name)
instruction=A/'Anleitung_Yellow_Guy_Wario.txt';instruction.write_text('Yellow Guy und Wario — kumulativer Gesamtpatch\n\nIn https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Alle bisherigen Änderungen enthalten. Deutsch einstellen; normale PAL-Spielstände verwenden.\n\nKind: Yellow Guy am Schloßweg nach dem Markt; Wario in Kakariko, tags und nachts. Erwachsen: Punk Yellow Guy vor Ganons Schloß. Mit A ansprechen. Wario erscheint ausdrücklich NICHT als Erwachsener. Wawario/Wawaluigi bleiben wie bisher nur erwachsen.\n\n40 MiB ROM-Datei; weiterhin mit 4 MiB N64-RAM geprüft. Kein vollständiger Durchlauf oder Hardwaretest.\n')
heading='# Yellow Guy und Wario';p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Dialoge und Sprechweise](planning/YELLOW_GUY_WARIO_DIALOGE.md) · [Prüfung](TESTING_YELLOW_GUY_WARIO.md) · [Echte Bilder](previews/yellow-guy/)\n\nYellow Guy als Kind am Schloßweg, Punk in der Zukunft vor Ganons Schloß, Wario ausschließlich im jungen Kakariko. Alle bisherigen Änderungen enthalten; 1.013 eigene deutsche Nachrichten, 4 MiB RAM. `build_yellow_guy.py` folgt auf `build_wawario.py`.\n\n'+p.read_text())
images=A/'Yellow_Guy_Wario_Bilder.zip'
with zipfile.ZipFile(images,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.iterdir()):z.write(p,p.name)
archive=A/'Merzen_Yellow_Guy_Wario_Quellen_Patch_Bilder.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl','.mp4'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R)
  if not p.is_file()or any(x in exclude for x in rel.parts)or p.suffix.lower()not in suffixes:continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='yellow-guy':continue
  with p.open('rb')as f:assert f.read(4)not in [bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 assert not any(Path(x).suffix.lower()in{'.rom','.z64','.n64','.v64','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st'}for x in z.namelist())
files=[patch,images,archive,instruction];sums=A/'SHA256SUMS_Yellow_Guy_Wario.txt';sums.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in files))
for p in files+[sums]:shutil.copyfile(p,D/p.name)
G=D/'Yellow_Guy_Wario_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
shutil.copyfile(R/'planning/YELLOW_GUY_WARIO_DIALOGE.md',D/'Yellow_Guy_Wario_Dialoge.md')
heading='# Merzen der Bauer: Yellow Guy und Wario';p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Aktueller BPS-Gesamtpatch](Mr_Burns_Mr_Bean_DE_PAL10_Yellow_Guy_Wario.bps?raw=true) · [Echte Spielbilder](Yellow_Guy_Wario_Bilder.zip?raw=true) · [Quellen und Prüfungen](Merzen_Yellow_Guy_Wario_Quellen_Patch_Bilder.zip?raw=true)\n\n[Dialoge und Sprechweise](Yellow_Guy_Wario_Dialoge.md) · [Prüfbericht](Yellow_Guy_Wario_Beispielbilder/Pruefbericht.md)\n\nYellow Guy am jungen Schloßweg, Punk vor Ganons Schloß und Wario ausschließlich im jungen Kakariko. Alle bisherigen Änderungen enthalten. Auf unveränderte Europa/PAL-1.0-ROM anwenden. Zehn Szenenproben mit 4 MiB bestanden; vollständiger Durchlauf und Hardwaretest stehen aus.\n\n![Wario im jungen Kakariko](Yellow_Guy_Wario_Beispielbilder/Wario_Begruessung.png)\n\n'+p.read_text())
print('Packaged',len(logs),'final-ROM cases,',len(manifest),'unedited images;',archive.stat().st_size,'source bytes;',sha)

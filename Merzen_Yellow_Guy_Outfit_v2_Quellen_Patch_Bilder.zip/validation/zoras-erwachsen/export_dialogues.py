from pathlib import Path
import json,sys,re
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery');W=Path('/workspace/zoras-erwachsen');sys.path.insert(0,str(R/'tools'));import build_story as b
m=b.messages((O/'extracted/pal-1.0/text/message_data.h').read_text());edits=json.loads((R/'story/zoras_erwachsen_de.json').read_text())['messages']
def quote(i):return ['> '+re.sub(r'\s+',' ',b.plain(p)).strip()+'\n'for p in b.split_pages(m[i]['parts'][2][2])[0]]
out=['# Erwachsene Zoras und Eishöhle: eingebaute Dialoge','','Aus dem tatsächlich gebauten deutschen Textbestand. Alte Rechtschreibung. {name} ist der gewählte Spielername. Nur manuelle Seiten verlängert; native Lied-, Rüstungs- und Tauschsteuerung erhalten.','']
for i in edits:out+=['## '+i,'']+quote(i)
s='\n'.join(out)+'\n';(R/'planning/ZORAS_ERWACHSEN_DIALOGE_AKTUELL.md').write_text(s);(D/'Zoras_Erwachsen_Dialoge_Aktuell.md').write_text(s)
out=['# Navi: nach Feuertempel bis nach Wassertempel','','Aktueller Einbau einschließlich Deiner vier neuen Eishöhlen-/Wassertempeltexte. Gegnerbeschreibungen ausgenommen. Nicht alle Hinweise kommen automatisch oder in fester Reihenfolge; Fortschritt und Ortsauslöser entscheiden. Die Eisenstiefel steuern den Wechsel von 0152 auf 0153.','']
for i,title in [('0152','Feueramulett, Eisenstiefel fehlen'),('0153','Eisenstiefel vorhanden, Wasseramulett fehlt; Oberwelt'),('0180','Eishöhle: Silberrubin-Rätsel, Raum 3'),('0189','Eishöhle: blaues Feuer, Raum 9'),('0105','Wassertempel: Zeitblock, Raum 7; übergreifend geteilter Text'),('01AB','Wassertempel: Strudelgang, Raum 21; zwei Auslöser'),('0154','Wasseramulett vorhanden, Kakariko-Folgeereignis fehlt'),('015F','Allgemeiner Dungeon-Ersatztext; kein regelmäßiger automatischer Ruf')]:out+=['## '+i+' — '+title,'']+quote(i)
out+=['0189 enthält zuerst Navis falsche Behauptung, der König würde nach dem Wassertempel auftauen, anschließend ihren ausdrücklichen Widerruf. Der König muß weiterhin mit blauem Feuer aufgetaut werden.','']
s='\n'.join(out)+'\n';(R/'planning/NAVI_ZORA_EIS_WASSER_AKTUELL.md').write_text(s);(D/'Navi_Zora_Eis_Wasser_Aktuell.md').write_text(s)
print('Exported chapter and current Navi texts')

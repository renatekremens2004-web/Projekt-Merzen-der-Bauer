#include "play_state.h"
#include "player.h"
#include "save.h"
#include "stddef.h"
unsigned offsets[]={offsetof(PlayState,linkAgeOnLoad),offsetof(Player,currentTunic),offsetof(Player,currentBoots),offsetof(Player,prevBoots),offsetof(SaveContext,save.info.equips.equipment),offsetof(PlayState,pauseCtx.state),offsetof(PlayState,msgCtx.msgMode),offsetof(Player,exchangeItemId),offsetof(PlayState,gameOverCtx.state)};

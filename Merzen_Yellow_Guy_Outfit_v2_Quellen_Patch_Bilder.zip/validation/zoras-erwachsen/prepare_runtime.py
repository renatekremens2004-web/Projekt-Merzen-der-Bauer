from pathlib import Path
import json,re,struct
W=Path('/workspace/zoras-erwachsen');O=Path('/workspace/oot-burns-pal');base=bytearray(Path('/workspace/water-spirit-sages/water.save').read_bytes());mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
# Reuse the lean native-gameplay runner. No calls to message-start functions.
s=Path('/workspace/okto-water-temple/runner.c').read_text();a=s.index(' if(play){',s.index('if(f%50==0)findplay();unsigned value=0;'));z=s.index('\n if(buttons)buttons(value);',a)
body=r''' if(play){
  uint32_t m=play+0x20d8;unsigned id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),pos=DebugMemRead16(m+0xe3ce);
  static unsigned oldkey=0,age=0;unsigned key=id*1024+pos;
  if(key!=oldkey || (mode!=7 && mode!=0x34 && mode!=0x35)){oldkey=key;age=0;}else age++;
  if((mode==7 || mode==0x34 || mode==0x35) && age==8){printf("TEXT f=%u id=%04x pos=%u mode=%x len=%u\n",f,id,pos,mode,r32(m+0xe300));printf("PHOTO f=%u kind=text\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f>150 && mode==0 && f%30<4)value=0x80;
  else if(f>100 && (mode==6 || mode==7 || mode==0x34 || mode==0x35) && age>12 && f%20<4)value=0x80;
  if((strstr(scenario,"reunion") || strstr(scenario,"king")) && mode==0)value|=0x20;
  if(strstr(scenario,"reunion") && mode!=0 && !strstr(scenario,"english") && f%40<4)value|=4;
  if(strstr(scenario,"zora-adult-boots-")){
   value=0;
   if(strstr(scenario,"pause")){if(f>=180 && f<184)value=0x10;if(f>=280 && f<284)value=4;}
   else if((f>=180 && f<240)||(f>=300 && f<304)||(f>=360 && f<364)||(f>=420 && f<424))value=4;
   if(f==230 || f==340 || f==480){printf("PHOTO f=%u kind=boots\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
   if(f>=170 && f<=500 && f%10==0)printf("BOOTS f=%u sent=%x equip=%04x live=%u prev=%u pause=%u msg=%x y=%.2f floor=%.2f bg=%x\n",f,value,DebugMemRead16(savebase+0x70),DebugMemRead8(player+0x13f),DebugMemRead8(player+0x143),DebugMemRead16(play+0x10934),mode,rf(player+0x28),rf(player+128),DebugMemRead16(player+136));
  }
  if(strstr(scenario,"king-trade") && mode==0){static unsigned sent=0;value=0;if(f>=160 && f<164){value=0x200;sent=1;}}
  if(strstr(scenario,"navi-") && mode==0 && f>150 && f%60<4)value=0x800;
  if(f==100){printf("PHOTO f=%u kind=scene\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(strstr(scenario,"serenade")){
   static unsigned playback=0;unsigned action=DebugMemRead16(m+0xe3f0),om=DebugMemRead16(m+0xe3ee);
   if(mode==0)value=0;
   if(action==17 && om==1){if(!playback)playback=f;unsigned t=f-playback;static unsigned notes[]={0x80,0x400,0x100,0x100,0x200};if(t>=20 && t<100){unsigned k=(t-20)/16;value=((t-20)%16<4)?notes[k]:0;}}
   if(f%40<4)value|=4;
   if(f%100==0)printf("OCARINA f=%u action=%u mode=%u msg=%x\n",f,action,om,mode);
  }
  if(f%100==0){
   printf("GEAR f=%u equip=%04x tunic=%u boots=%u prev=%u pause=%u\n",f,DebugMemRead16(savebase+0x70),DebugMemRead8(player+0x13c),DebugMemRead8(player+0x13f),DebugMemRead8(player+0x143),DebugMemRead16(play+0x10934));
   uint32_t zo=actor_type(0x1ce,0x46),kz=actor(0x164);printf("ZORAS f=%u zo=%08x zo_floor=%.1f zo_pos=(%.1f %.1f %.1f) king=%08x quest=%08x owned=%04x inf13=%04x trade=%02x exchange=%02x\n",f,zo,zo?rf(zo+128):0,zo?rf(zo+0x24):0,zo?rf(zo+0x28):0,zo?rf(zo+0x2c):0,kz,r32(savebase+0xa4),DebugMemRead16(savebase+0x9c),DebugMemRead16(savebase+0xf1e),DebugMemRead8(savebase+0x8a),DebugMemRead8(player+0x03a0));
   uint32_t ctx=play+0x117a4,begin=r32(ctx),end=r32(ctx+4),last=begin;int entries=DebugMemRead8(ctx+8);
   for(int i=0;i<entries && i<19;i++){uint32_t slot=ctx+12+i*0x44;int obj=(int16_t)DebugMemRead16(slot);if(obj<0)obj=-obj;if(obj>0 && obj<0x192){uint32_t e=r32(slot+4)+r32(OBJECTTABLE+obj*8+4)-r32(OBJECTTABLE+obj*8);if(e>last)last=e;}}
   printf("OBJECT_BANK f=%u entries=%d used=%u capacity=%u remaining=%d\n",f,entries,last-begin,end-begin,(int)(end-last));if(last>end){fprintf(stderr,"OBJECT_BANK_OVERFLOW\n");exit(96);}
   printf("STATE f=%u scene=%x id=%04x msg=%x RAM=%u player=(%.1f %.1f %.1f)\n",f,DebugMemRead16(play+0xa4),id,mode,r32(0x80000318),rf(player+0x24),rf(player+0x28),rf(player+0x2c));
  }
 }
'''
s=s[:a]+body.replace('OBJECTTABLE',hex(syms['gObjectTable']))+s[z:];s=s.replace('0x800ef6a0',hex(syms['gGameStateOverlayTable']));(W/'runner.c').write_text(s)
def flag(b,off,value,on=True):
 p=off+(value>>4)*2;v=struct.unpack_from('>H',b,p)[0];struct.pack_into('>H',b,p,(v|(1<<(value&15)))if on else(v&~(1<<(value&15))))
def fixture(name,ent,room,pos,yaw=0,lang=1,water=False):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,0,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,room);b[0x1409]=lang;b[0x68]=0x3c;struct.pack_into('>H',b,0x70,0x1122);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);struct.pack_into('>HH',b,0x2e,160,160)
 q=struct.unpack_from('>I',b,0xa4)[0]|3|0x100;struct.pack_into('>I',b,0xa4,(q|4)if water else(q&~4));flag(b,0xed4,0x45);flag(b,0xed4,0x33);flag(b,0xef8,0x1cf);return b
for topic,lang in [('reunion',1),('reunion-english',0)]:
 b=fixture(topic,0x108,1,(-786.,14.,-431.),-32768,lang);struct.pack_into('>H',b,0x70,0x1322);struct.pack_into('>H',b,0x9c,struct.unpack_from('>H',b,0x9c)[0]|0x400);(W/(topic+'.save')).write_bytes(b)
for topic,water,done,owned in [('king-before',False,True,True),('king-after',True,True,True),('king-gift',False,False,False),('king-owned',False,False,True)]:
 b=fixture(topic,0x153,0,(623.,947.,-1500.),-32768,water=water);flag(b,0xef8,0x138);flag(b,0xef8,0x139,done);e=struct.unpack_from('>H',b,0x9c)[0];struct.pack_into('>H',b,0x9c,(e|0x400)if owned else(e&~0x400));b[0x8a]=0xff;struct.pack_into('>H',b,0x70,0x1322 if owned else 0x1122);(W/(topic+'.save')).write_bytes(b)
b=fixture('serenade',0x88,7,(-1005.,280.,1020.),-32768);flag(b,0xed4,0x52,False);struct.pack_into('>H',b,0x9c,struct.unpack_from('>H',b,0x9c)[0]|0x2000);(W/'serenade.save').write_bytes(b)
b=fixture('sun-sign',0x102,0,(-1805.,-1013.,969.),-8920,water=True);(W/'sun-sign.save').write_bytes(b)
for topic in ['boots-land','boots-no-owned','boots-child','boots-pause']:
 b=fixture(topic,0x108,1,(-786.,14.,-431.),-32768);struct.pack_into('>H',b,0x70,0x1322);e=struct.unpack_from('>H',b,0x9c)[0]|0x2400;struct.pack_into('>H',b,0x9c,(e&~0x2000)if topic=='boots-no-owned'else e)
 if topic=='boots-child':struct.pack_into('>I',b,4,1);struct.pack_into('>H',b,0x70,0x1111)
 (W/(topic+'.save')).write_bytes(b)
b=fixture('boots-water',0x10,0,(-195.,690.,810.),0);struct.pack_into('>H',b,0x70,0x1322);struct.pack_into('>H',b,0x9c,struct.unpack_from('>H',b,0x9c)[0]|0x2400);off=0xd4+5*0x1c;struct.pack_into('>I',b,off+4,(struct.unpack_from('>I',b,off+4)[0]&~(7<<28))|(1<<30));(W/'boots-water.save').write_bytes(b)
for topic,room,pos in [('navi-silver',3,(296.,9.,-4.)),('navi-fire',9,(603.,202.,-2468.))]:
 b=fixture(topic,0x88,room,pos,0);off=0xd4+9*0x1c;b[off:off+0x1c]=bytes(0x1c);(W/(topic+'.save')).write_bytes(b)
b=fixture('sun-sign',0x102,0,(-526.,-1216.,7259.),16384,water=True);(W/'sun-sign.save').write_bytes(b)
b=fixture('king-trade',0x153,0,(623.,947.,-1500.),-32768);flag(b,0xef8,0x138);flag(b,0xef8,0x139);b[0x8a]=0x34;b[0x69]=0x34;b[0x6c]=22;struct.pack_into('>H',b,0x70,0x1322);struct.pack_into('>H',b,0x9c,struct.unpack_from('>H',b,0x9c)[0]|0x400);(W/'king-trade.save').write_bytes(b)
# Keep current/adult equipment consistent across Play_Destroy age bookkeeping.
for p in W.glob('*.save'):
 b=bytearray(p.read_bytes());b[0x4a:0x54]=b[0x68:0x72];p.write_bytes(b)
print('Prepared native player/progress fixtures; no NPCs or cameras moved.')

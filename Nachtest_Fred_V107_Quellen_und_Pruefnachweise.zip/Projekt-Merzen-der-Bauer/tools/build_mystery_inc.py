"""Final builder after build_naboo.py: Mystery Inc. in five well rooms; visible corpse."""
from pathlib import Path
import sys,json,re
from n64_model import emit
from build_story import add_private_message,messages,Layout,rewrite,closing
def write(p,s):
 if not p.exists()or p.read_text()!=s:p.write_text(s)
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/mystery-inc'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
keys=['shaggy','velma','daphne','scooby','fred'];rooms=[0,1,2,6,5];poses=[[-450,-12,-1450],[500,-720,-1200],[-1740,0,-890],[-220,0,-990],[300,0,-970]];yaws=[-16384,0,0,0,0];models={}
D=O/'extracted/pal-1.0/assets/scenes/dungeons/HAKAdanCH';table='';spec=''
for i,(key,room,pos,yaw)in enumerate(zip(keys,rooms,poses,yaws)):
 m=json.loads((R/'tools'/f'{key}_source.json').read_text());models[key]=m;prefix=key.title();A=O/f'extracted/pal-1.0/assets/objects/object_{key}';A.mkdir(parents=True,exist_ok=True)
 code='#include "ultra64.h"\n#include "animation.h"\n#include "gfx.h"\n'
 code+=emit(m,R/'models'/key,prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');(A/f'object_{key}.c').write_text(code)
 table+=f'\n/* 0x{0x195+i:04X} */ DEFINE_OBJECT(object_{key}, OBJECT_{key.upper()})\n'
 spec+=f'\nbeginseg\n    name "object_{key}"\n    compress\n    romalign 0x1000\n    include "$(BUILD_DIR)/assets/objects/object_{key}/object_{key}.o"\n    number 6\nendseg\n'
 p=next(D.glob(f'HAKAdanCH_room_{room}_*ActorEntryList.inc.c'));s=original(p);count=s.count('ACTOR_');p.write_text(s+'    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, { 0, '+str(yaw)+', 0 }, 0x%04X }, /* Mystery Inc: '%(0x3f87+i)+key+' */\n')
 p=next(D.glob(f'HAKAdanCH_room_{room}_*ObjectList.inc.c'));s=original(p);nobjs=s.count('OBJECT_');p.write_text(s+'    OBJECT_'+key.upper()+', /* only this guest loaded in this room */\n')
 p=D/f'HAKAdanCH_room_{room}.h';s=original(p)
 for kind,old in [('ActorEntryList',count),('ObjectList',nobjs)]:s,n=re.subn(rf'(#define LENGTH_HAKAdanCH_room_{room}_\w+_{kind} ){old}\b',lambda m:m[1]+str(old+1),s);assert n==1
 p.write_text(s)
for rel,extra in [('include/tables/object_table.h',table),('spec/spec',spec)]:p=O/rel;write(p,original(p)+extra)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);helper=(R/'tools/mystery_inc_actor.inc.c').read_text().replace('MYSTERY_PIVOTS',','.join('{'+','.join('{'+','.join(map(str,b['position']))+'}'for b in models[key]['bones'])+'}'for key in keys));needle=(R/'tools/kenny_actor.inc.c').read_text().splitlines()[0];assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
for action in ['Init','Update']:
 needle=f'void ElfMsg2_{action}(Actor* thisx, PlayState* play) {{\n    ElfMsg2* this = (ElfMsg2*)thisx;';assert s.count(needle)==1;s=s.replace(needle,needle+f'\n    if (ElfMsg2_IsMysteryInc(thisx, play)) {{\n        ElfMsg2_{action}MysteryInc(this, play);\n        return;\n    }}')
s=s.replace('if (ElfMsg2_IsBttf(thisx, play) ||','if (ElfMsg2_IsMysteryInc(thisx, play) || ElfMsg2_IsBttf(thisx, play) ||');write(p,s)
# Same Kenny room/conditions, now on the clear entry-side floor before the scythe.
p=next((O/'extracted/pal-1.0/assets/scenes/dungeons/HAKAdan').glob('HAKAdan_room_6_*ActorEntryList.inc.c'));s=original(p);s,n=re.subn(r'\{ ACTOR_ELF_MSG2, \{ 3225, -542, -600 \}, \{ 0, 0, 1 \}, 0x3F86 \}', '{ ACTOR_ELF_MSG2, { 2990, -542, -1020 }, { 0, 16384, 1 }, 0x3F86 }',s);assert n==1;p.write_text(s)
dialogues={
 '71BA':['ZOINKS! Hier ist echt ne Menge Blut. Ich hatte gehofft, das ist KETCHUP!','Da vergeht einem echt der Appetit... Wobei, was rede ich denn DA!','Ein leckeres Sandwich wäre jetzt doch genau das Richtige. Hmm!'],
 '71BB':['JINKIES! Der Gestank hier unten ist unbeschreiblich ekelig. Es riecht nach Schwefel und Eisen.','Ob es wirklich so gut war, daß wir uns aufteilen? Ich hoffe, die anderen sind vorsichtig...'],
 '71BC':['JEEPERS! Hier unten sollte echt mal geputzt werden. Und das ist definitiv kein Platz für Kinder wie Dich!','Wo ist überhaupt Fred? Wobei, Velma dürfte mich natürlich auch gerne begleiten...','Mit ihr würde ich mich hier gleich viel wohler fühlen. Und das liegt nicht nur an ihrer Taschenlampe.'],
 '71BD':['Ruh-roh! Rer Brunnen ist riel zu gruselig! Wo ist Raggy?','Für einen Scooby-Snack würde ich ja bleiben... Zwei? Rein, lieber drei!','Scooby-Dooby-Doo! Aber jetzt bitte raus hier!'],
 '71BE':['FUCK! Hier unten gibt es echt eine Menge Fallen, und ich Idiot habe natürlich mein Notizbuch vergessen!','Wie schade. Blöder, blöder Fred! Was bin ich nur für ein Hornochse!']}
entries={ident:dict(new_message=True,insert_before='71B2',native_template='0022',reserve_text='Mystery Inc.',pages=pages)for ident,pages in dialogues.items()}
(R/'story/mystery_inc_de.json').write_text(json.dumps(dict(chapter='Mystery Inc. im Brunnen',orthography='de-vor-1996',messages=entries),ensure_ascii=False,indent=2)+'\n')
p=O/'extracted/pal-1.0/text/message_data.h';s=p.read_text();native=messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
for ident,entry in entries.items():
 s=add_private_message(s,ident,entry);a,b,_=messages(s)[ident]['parts'][2];body,_=rewrite(native['0022']['parts'][2][2],entry,Layout(O),ident);s=s[:a]+body+s[b:]
# Ensure a real next DMA pointer for the last private message in every language.
blocks=[]
for ident in entries:
 start=s.index('DEFINE_MESSAGE(0x'+ident+',');end=closing(s,start+len('DEFINE_MESSAGE('))+1
 while end<len(s)and s[end]=='\n':end+=1
 blocks.append(s[start:end]);s=s[:start]+s[end:]
at=s.index('DEFINE_MESSAGE(0x71B2,');s=s[:at]+''.join(blocks)+s[at:];p.write_text(s)
print('Mystery Inc: five rooms, five room-local objects, 1803 total triangles; dead Kenny moved into view.')

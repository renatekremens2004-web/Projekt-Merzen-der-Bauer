from pathlib import Path
import json, os, struct, subprocess

W=Path(__file__).resolve().parent;sy=json.loads((W/'all-symbols-normal.json').read_text())
base=(W/'guest-shaggy.c').read_text();a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
write=r'''
static void capture_render(void){}
static unsigned phase=0,mark=0;
static void onframe(unsigned f){
 baseframe(f);if(f==340){play=player=0;}if(f<380)return;findplay();if(!play||!player)return;
 unsigned st=DebugMemRead16(play+0x10934),sp=DebugMemRead16(play+0x1094c),v=0;
 if(!phase&&f>=450){v=0x10;mark=f;phase=1;}
 if(phase==1&&f%60<3)v=0x10;
 else if(phase==1&&st==6){mark=f;phase=2;}
 else if(phase==2&&f>=mark+12){v=0x40;mark=f;phase=3;}
 if(phase==3&&f<mark+3)v=0x40;
 else if(phase==3&&st==7&&sp==1){v=0x80;mark=f;phase=4;}
 if(phase==4&&f<mark+3)v=0x80;
 else if(phase==4&&st==7&&sp==4){printf("NATIVE_SAVE_WRITTEN f=%u\n",f);phase=5;mark=f;}
 else if(phase==5&&f>=mark+12){v=0x10;mark=f;phase=6;}
 if(phase==6&&f<mark+3)v=0x10;
 else if(phase==6&&!st){mark=f;phase=7;}
 else if(phase==7&&f>mark+35){bank();need(DebugMemRead16(savebase+0x34)==73,"native save keeps money");puts("NATIVE_SAVE_MENU_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(buttons)buttons(v);
 if(f%200==0)printf("SAVE_PROGRESS f=%u phase=%u pause=%u prompt=%u cs=%u msg=%x mm=%u flags=%x xyz=%.1f,%.1f,%.1f file=%u\n",f,phase,st,sp,DebugMemRead8(play+0x1d6c),DebugMemRead16(play+0x104d0),DebugMemRead8(play+0x103dc),r32(player+0x66c),rf(player+0x24),rf(player+0x28),rf(player+0x2c),r32(savebase+0x1354));
 need(f<2600,"native pause save completes");
}
'''
read=r'''
static void capture_render(void){}
static unsigned menu=0,started=0,selecting=0,laststate=999,ready=0,seen=0;
static void onframe(unsigned f){
 alarm(30);unsigned v=0;if(f>=500&&!menu&&!started&&f%60==0)v=0x10;
 if(f>500&&!started){unsigned tab=GAMETABLE+5*0x30,ram=r32(tab),vram=r32(tab+12),destroy=r32(tab+28);if(ram&&!menu){unsigned fn=destroy>=ram&&destroy<ram+0x40000?destroy:destroy-vram+ram;for(unsigned p=0x80120000;p<0x803e0000;p+=4)if(r32(p+8)==fn&&r32(p+0x98)==1){menu=p;printf("RELOAD_FILE_MENU %x\n",menu);break;}}
 if(menu&&r32(menu+0x98)==1){unsigned mode=DebugMemRead16(menu+0x1ca3c),cfg=DebugMemRead16(menu+0x1ca3e),sel=DebugMemRead16(menu+0x1ca44),state=(mode<<16)|(cfg<<8)|sel;
 if(state!=laststate){printf("RELOAD_FILE_STATE f=%u mode=%u cfg=%u sel=%u\n",f,mode,cfg,sel);laststate=state;}
 if(mode==0&&cfg==2&&f%12==0)v=DebugMemRead8(savebase+0x1409)==1?0x80:0x00500000;
 if(mode==1&&cfg==2&&f%24==0)v=0x80;
 if(mode==2){selecting=1;if(sel==3&&f%24==0)v=0x80;}
 need(cfg!=33,"existing save is recognized rather than requesting a new name");
 }else if(selecting){started=f;play=player=0;printf("NATIVE_EXISTING_SAVE_OPENED f=%u\n",f);}}
 if(started){findplay();if(play&&player){unsigned m=play+0x20d8,mm=DebugMemRead8(m+0xe304),cs=DebugMemRead8(play+0x1d6c);if(mm&&f%12<2)v=0x80;
 if(!cs&&!mm){if(!ready)ready=f;if(f>ready+60){bank();need(DebugMemRead16(savebase+0x34)==73,"rupees survive emulator restart and native file load");need(r32(savebase+0xa4)==0x40000,"quest inventory survives native file load");need((DebugMemRead16(savebase+0xf30)&0x6000)==0x6000,"light/shadow tunic ownership survives native file load");need(DebugMemRead16(savebase+0x2e)==0xa0,"health capacity survives native file load");printf("NATIVE_SRAM_RELOAD_PASSED scene=%x rupees=%u quest=%x custom=%x\n",DebugMemRead16(play+0xa4),DebugMemRead16(savebase+0x34),r32(savebase+0xa4),DebugMemRead16(savebase+0xf30));CoreDoCommand(M64CMD_STOP,0,NULL);}}
 }}if(f%300==0)printf("RELOAD_PROGRESS f=%u started=%u ready=%u\n",f,started,ready);if(buttons)buttons(v);need(f<6500,"existing native file reload completes");
}
'''
read=read.replace('GAMETABLE',hex(sy['gGameStateOverlayTable']))
matrix=json.loads(Path('/tmp/final-audit-v106/matrix.json').read_text());d=next(x for x in matrix if(x['scene'],x['room'],x['age'])==(0x52,0,1));q=bytearray.fromhex(d['save']);struct.pack_into('>i',q,0x1364,0);struct.pack_into('>I',q,0x1354,0);q[0x1c:0x22]=b'ZELDAZ';struct.pack_into('>HH',q,0x2e,0xa0,0xa0);struct.pack_into('>H',q,0x34,73);struct.pack_into('>I',q,0xa4,0x40000);struct.pack_into('>H',q,0xf30,0x6000);struct.pack_into('>H',q,0xed4,0x280);save=W/'sram.save';save.write_bytes(q)
results=[]
for name,body in [('write',write),('read',read)]:
 c=W/f'sram-final-{name}.c';c.write_text(base[:a]+body+base[b:]);exe=W/f'sram-final-{name}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
 args=[str(exe),str(W/'normal.z64'),'native-sram-v107-final-direct','7000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable'])]+([str(save)]if name=='write'else[])
 log=W/f'sram-final-{name}.log'
 with log.open('w')as out:r=subprocess.run(args,env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=out,stderr=subprocess.STDOUT,timeout=700)
 marker='NATIVE_SAVE_MENU_PASSED'if name=='write'else'NATIVE_SRAM_RELOAD_PASSED';ok=r.returncode==0 and marker in log.read_text();results.append(dict(case=name,passed=ok,log=log.name));(W/'save-reload-final-results.json').write_text(json.dumps(results,indent=2));print('SAVE_RELOAD',name,ok,flush=True);assert ok,log.read_text()[-2200:]

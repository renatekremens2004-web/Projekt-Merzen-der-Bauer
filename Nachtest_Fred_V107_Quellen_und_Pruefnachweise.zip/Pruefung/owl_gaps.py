from pathlib import Path
import concurrent.futures, json, os, re, struct, subprocess, time

W=Path(__file__).resolve().parent; O=Path('/workspace/oot-burns-pal')
sy=json.loads((W/'all-symbols-normal.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text())
base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:
 base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/owl-gap-stall.bin').replace('obj<=0x1af','obj<=0x1b0')
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned seen=0,finalseen=0,closed=0,choices=0,lastchoice=0,ride=0,depart=0,lastid=0,returnAt=0;
static void onframe(unsigned f){
 baseframe(f);if(f==340){play=0;player=0;}if(f<380)return;findplay();if(!play||!player)return;
 unsigned sc=DebugMemRead16(play+0xa4),g=target(0x14d,PARAM),m=play+0x20d8,id=DebugMemRead16(m+0xe2f8),mm=DebugMemRead8(m+0xe304),cs=DebugMemRead8(play+0x1d6c),v=0;
 if(id==FIRST&&mm)seen=1;if(id==FINAL&&mm)finalseen=1;
 if(mm&&lastid!=id){printf("OWL_TEXT f=%u id=%x len=%u\n",f,id,r32(m+0xe300));lastid=id;}
 unsigned choice=(id==0x10c2&&mm==0x35);if(choice&&!lastchoice)choices++;lastchoice=choice;if(choice)DebugMemWrite8(m+0xe3e5,choices>=2?1:0);
 need(r32(m+0xe300)<1280&&DebugMemRead16(m+0xe3d4)<=200,"owl text buffers fit");
 if(finalseen&&!mm&&!closed){closed=f;if(g)depart=r32(g+0x3fc);printf("OWL_CLOSED f=%u cs=%u action=%x\n",f,cs,depart);}
 if(CASEMODE==2&&closed&&sc==STARTSCENE&&!cs&&g&&f>closed+20&&!ride){position(player,rf(g+0x24),rf(g+0x28)-120,rf(g+0x2c)+15,32768);}
 if(CASEMODE==2&&closed&&cs){ride=1;}
 if(closed&&CASEMODE!=2&&f>closed+80){need(seen&&finalseen,"owl first and final messages shown");need(!cs,"owl returns native camera/control");if(CASEMODE!=1)need(!g||r32(g+0x3fc)!=depart,"owl departure advances");if(CASEMODE==3)need(choices>=2,"pre-Saria repeat and finish both tested");bank();puts("NEW_OWL_BRANCH_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(CASEMODE==2&&ride&&sc!=STARTSCENE&&!cs&&!mm){if(!returnAt)returnAt=f;if(f>returnAt+35){need(seen&&finalseen,"ride dialogue completes");bank();printf("NEW_OWL_RIDE_PASSED destination=%x\n",sc);CoreDoCommand(M64CMD_STOP,0,NULL);}}
 if(f>420&&f%12<2&&(mm==0||mm==6||mm==7||mm==0x34||mm==0x35))v=0x80;
 if(buttons)buttons(v);
 if(f%300==0){printf("OWL_GAP_PROGRESS f=%u scene=%x actor=%x msg=%x mode=%u cs=%u ride=%u closed=%u xyz=%.1f,%.1f,%.1f\n",f,sc,g,id,mm,cs,ride,closed,rf(player+0x24),rf(player+0x28),rf(player+0x2c));bank();}
 need(f<6500,"remaining owl route completes");
}
'''
matrix=json.loads(Path('/tmp/final-audit-v106/matrix.json').read_text())
cases=[
 ('kakariko-no-letter',0x51,0,0xff,(3276,390,1050),0x206c,0x206c,0,0,0),
 ('gerudo-route',0x51,0,0x13f,(-6270,-90,8659),0x206f,0x206f,0,0,0),
 ('lake-route',0x51,0,0x14b,(-4670,-620,13819),0x2071,0x2071,0,0,0),
 ('river-no-saria',0x54,0,0x1bf,(-1397,140,506),0x4002,0x4002,0,0,1),
 ('river-saria',0x54,0,0x1bf,(-1397,140,506),0x4017,0x4017,0,1<<14,1),
 ('river-both-songs',0x54,0,0x1bf,(-1397,140,506),0x4031,0x4031,0,(1<<14)|(1<<12),1),
 ('woods-pre-saria-repeat',0x5b,2,0x2c7,(955,0,-700),0x10c0,0x10c3,3,1<<12,0),
 ('mountain-no-magic',0x60,0,0x213,(-42,3227,-4329),0x3062,0x3062,1,0,0),
 ('mountain-with-magic-ride',0x60,0,0x213,(-42,3227,-4329),0x3063,0x3063,2,0,0),
 ('lake-first-ride',0x57,0,0x1ca,(-3080,-1105,6147),0x4003,0x4003,2,0,0),
 ('lake-repeat-ride',0x57,0,0x1ca,(-3080,-1105,6147),0x4004,0x4004,2,0,0),
 ('desert-last-advice',0x5c,0,0x29f,(-1456,691,505),0x6079,0x607a,0,0,0),
]
results=[]
def run(c):
 name,scene,room,param,xyz,first,final,mode,quest,letter=c
 d=next(x for x in matrix if (x['scene'],x['room'],x['age'])==(scene,room,1))
 q=bytearray.fromhex(d['save']);struct.pack_into('>I',q,0xa4,quest);struct.pack_into('>H',q,0xedc,letter);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,*xyz,32767,0xdff,d['entrance'],room)
 q[0x3a]=int('with-magic' in name)
 if name=='lake-repeat-ride':struct.pack_into('>H',q,0xf2a,0x20)
 src=body
 for k,v in [('CASEMODE',mode),('STARTSCENE',scene),('PARAM',param),('FIRST',first),('FINAL',final)]:src=src.replace(k,str(v))
 code=W/f'owl-{name}.c';code.write_text(base[:a]+src+base[b:]);exe=W/f'owl-{name}'
 subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(code),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
 save=W/f'owl-{name}.save';save.write_bytes(q);log=W/f'owl-{name}.log';t=time.monotonic()
 with log.open('w')as out:
  try:
   p=subprocess.run([str(exe),str(W/'normal.z64'),f'owl-gap-{name}-v107-direct','6800','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=out,stderr=subprocess.STDOUT,timeout=600)
   ok=p.returncode==0 and ('NEW_OWL_RIDE_PASSED' if mode==2 else 'NEW_OWL_BRANCH_PASSED')in log.read_text();error=None if ok else log.read_text()[-1800:]
  except Exception as e:ok=False;error=repr(e)
 results.append(dict(case=name,passed=ok,log=log.name,elapsed=round(time.monotonic()-t,1),error=error));(W/'owl-gap-results.json').write_text(json.dumps(results,indent=2));print('OWL_GAP',name,ok,error or'',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(run,cases))
assert len(results)==len(cases) and all(x['passed']for x in results)

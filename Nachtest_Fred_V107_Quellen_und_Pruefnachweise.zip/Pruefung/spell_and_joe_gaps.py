from pathlib import Path
import concurrent.futures, json, math, os, re, struct, subprocess

W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');sy=json.loads((W/'all-symbols-normal.json').read_text());base=(W/'guest-shaggy.c').read_text();a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned first=0,second=0,grant=0,stage=0,mark=0;
static void onframe(unsigned f){
 baseframe(f);if(f==340){play=player=0;}if(f<380)return;findplay();if(!play||!player)return;
 unsigned npc=target(NPC,PARAM),m=play+0x20d8,id=DebugMemRead16(m+0xe2f8),mm=DebugMemRead8(m+0xe304),v=0;
 if(npc&&f>=400){float dx=rf(npc+0x24)-rf(player+0x24),dz=rf(npc+0x2c)-rf(player+0x2c);int yaw=(int)(atan2f(dx,dz)*32768.0f/3.14159265f);if(!mm){DebugMemWrite16(player+0x82c,yaw);DebugMemWrite16(player+0xb6,yaw);}photo(rf(npc+0x24)+120,rf(npc+0x28)+100,rf(npc+0x2c)+160,rf(npc+0x24),rf(npc+0x28)+40,rf(npc+0x2c));}
 if(mm&&id==FIRST)first=1;if(mm&&id==SECOND)second=1;if(mm&&id==0x7233)grant=1;
 need(r32(m+0xe300)<1280&&DebugMemRead16(m+0xe3d4)<=200,"new stateful NPC text fits buffers");
 if(f>440&&stage==0&&f%12<2&&(mm==0||mm==6||mm==7||mm==0x34||mm==0x35))v=0x80;
 if(SPELL&&grant&&!mm&&!stage){need(DebugMemRead16(savebase+0xf30)&0x1000,"spell unlock is actually granted by the NPC");need(!(DebugMemRead16(savebase+0xf30)&0x800),"spell begins disabled");stage=1;mark=f;}
 if(SPELL&&stage==1&&f>=mark+12&&f<mark+15)v=2;
 if(SPELL&&stage==1&&f==mark+25){need(DebugMemRead16(savebase+0xf30)&0x800,"D-left enables freshly unlocked spell");stage=2;mark=f;}
 if(SPELL&&stage==2&&f>=mark+12&&f<mark+15)v=2;
 if(SPELL&&stage==2&&f==mark+25){need(!(DebugMemRead16(savebase+0xf30)&0x800),"D-left disables spell again");stage=3;}
 if(SPELL&&stage==3&&f%12<2&&(mm==0||mm==6||mm==7||mm==0x34||mm==0x35))v=0x80;
 if(first&&second&&!mm){if(!mark||stage<4){stage=4;mark=f;}if(f>mark+35){need(!SPELL||grant,"magic animation followup completed");bank();printf("STATEFUL_NPC_PASSED first=%x second=%x spell=%u\n",FIRST,SECOND,SPELL);CoreDoCommand(M64CMD_STOP,0,NULL);}}
 if(buttons)buttons(v);
 if(f%300==0)printf("STATEFUL_PROGRESS f=%u npc=%x msg=%x mode=%u first=%u second=%u grant=%u stage=%u custom=%x\n",f,npc,id,mm,first,second,grant,stage,DebugMemRead16(savebase+0xf30));
 need(f<3500,"stateful NPC first and repeat interaction finish");
}
'''
matrix=json.loads(Path('/tmp/final-audit-v106/matrix.json').read_text());results=[]
def run(spec):
 name,sc,room,age,npc,param,first,second,spell=spec;d=next(x for x in matrix if(x['scene'],x['room'],x['age'])==(sc,room,age));prefix=d['name'].split('-')[1]
 text=''.join(p.read_text()for p in (O/'extracted/pal-1.0/assets/scenes').rglob(f'{prefix}_room_{room}_*ActorEntryList.inc.c'));pat=rf'ACTOR_\w+\s*,\s*\{{\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\}}\s*,\s*\{{[^}}]+\}}\s*,\s*0x{param:04X}'
 mat=re.search(pat,text,re.I);assert mat,(name,param);x,y,z=map(int,mat.groups());q=bytearray.fromhex(d['save']);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,x,y+15,z+60,-32768,0xdff,d['entrance'],room);q[0xf30:0xf32]=b'\0\0'
 if not spell:struct.pack_into('>H',q,0x70,(struct.unpack_from('>H',q,0x70)[0]&~0xf00)|0x200)
 src=body
 for k,v in [('SPELL',spell),('NPC',npc),('PARAM',param),('FIRST',first),('SECOND',second)]:src=src.replace(k,str(v))
 c=W/f'stateful-{name}.c';c.write_text(base[:a]+src+base[b:]);exe=W/f'stateful-{name}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True);save=W/f'stateful-{name}.save';save.write_bytes(q);log=W/f'stateful-{name}.log'
 with log.open('w')as out:r=subprocess.run([str(exe),str(W/'normal.z64'),f'stateful-{name}-v107-direct','3700','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=out,stderr=subprocess.STDOUT,timeout=500)
 ok=r.returncode==0 and 'STATEFUL_NPC_PASSED'in log.read_text();results.append(dict(case=name,passed=ok,log=log.name));(W/'stateful-npc-results.json').write_text(json.dumps(results,indent=2));print('STATEFUL_NPC',name,ok,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as p:list(p.map(run,[('mint-spell',0x55,0,1,0x163,0x7e00,0x7231,0x7232,1),('joe-repeat',0x61,1,0,0x1ae,0x7f6e,0x7224,0x7225,0)]))
assert all(x['passed']for x in results)

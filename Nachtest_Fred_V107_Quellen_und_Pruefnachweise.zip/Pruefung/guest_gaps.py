from pathlib import Path
import concurrent.futures, json, os, re, struct, subprocess, time, math

W=Path(__file__).resolve().parent; O=Path('/workspace/oot-burns-pal')
sy=json.loads((W/'all-symbols-normal.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text())
base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/guest-gap-stall.bin').replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned seen=0,closed=0,lastid=0,quest=0,sw=0,cl=0,checked=0;
static void onframe(unsigned f){
 baseframe(f);if(f==340){play=0;player=0;}if(f<380)return;findplay();if(!play||!player)return;
 unsigned g=target(0x173,PARAM),m=play+0x20d8,id=DebugMemRead16(m+0xe2f8),mm=DebugMemRead8(m+0xe304),v=0;
 if(g&&!seen&&f>=400){float dx=rf(g+0x24)-rf(player+0x24),dz=rf(g+0x2c)-rf(player+0x2c);int yaw=(int)(atan2f(dx,dz)*32768.0f/3.14159265f);DebugMemWrite16(player+0x82c,yaw);DebugMemWrite16(player+0xb6,yaw);DebugMemWrite16(player+0x32,yaw);photo(rf(g+0x24)+100,rf(g+0x28)+90,rf(g+0x2c)+160,rf(g+0x24),rf(g+0x28)+30,rf(g+0x2c));}
 if(!checked&&f>=400){quest=r32(savebase+0xa4);sw=r32(play+0x1d28);cl=r32(play+0x1d3c);checked=1;}
 if(id==TEXT&&mm)seen=1;
 if(mm&&id!=lastid){lastid=id;printf("GUEST_TEXT f=%u id=%x size=%u\n",f,id,r32(m+0xe300));}
 need(r32(m+0xe300)<1280&&DebugMemRead16(m+0xe3d4)<=200,"guest text fits native buffers");
 if(seen&&!mm&&!closed){closed=f;}
 if(f>440&&!closed&&f%12<2&&(mm==0||mm==6||mm==7||mm==0x34||mm==0x35))v=0x80;
 if(mm==0x35&&DebugMemRead8(m+0xe3e6)==2)DebugMemWrite8(m+0xe3e5,1);
 if(buttons)buttons(v);
 if(closed&&f>closed+40){need(g&&r32(g+0x134),"guest model still live after conversation");need(!DebugMemRead8(play+0x1d6c),"guest conversation restores control");need(quest==r32(savebase+0xa4)&&sw==r32(play+0x1d28)&&cl==r32(play+0x1d3c),"decorative guest does not change quest or puzzle flags");bank();printf("NEW_GUEST_DIALOGUE_PASSED text=%x actor=%x\n",TEXT,g);CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(f%300==0)printf("GUEST_PROGRESS f=%u actor=%x id=%x mode=%u seen=%u xyz=%.1f,%.1f,%.1f\n",f,g,id,mm,seen,rf(player+0x24),rf(player+0x28),rf(player+0x2c));
 need(f<2600,"new guest conversation finishes");
}
'''
matrix=json.loads(Path('/tmp/final-audit-v106/matrix.json').read_text())
specs=[]
def add(n,sc,room,age,param,text):specs.append((n,sc,room,age,param,text))
for n,room,param,text in [('shaggy',0,0x3f87,0x71ba),('velma',1,0x3f88,0x71bb),('daphne',2,0x3f89,0x71bc),('scooby',6,0x3f8a,0x71bd),('fred',5,0x3f8b,0x71be)]:add(n,8,room,1,param,text)
for i,(sc,room,age)in enumerate([(0,1,1),(1,4,1),(2,2,1),(3,4,0),(4,17,0),(5,6,0),(7,7,0),(6,14,0),(13,16,0),(8,3,1),(9,8,0)]):add('starwalker-'+str(i),sc,room,age,0x7fb1+i,0x7216+i)
for i,n in enumerate(['kris','susie','ralsei']):add(n,1,2,1,0x7fbc+i,0x7221+i)
add('pingu',9,2,0,0x3f93,0x71de);add('crazy-frog',0x54,0,1,0x3f94,0x71df)
for i,(n,room)in enumerate([('skipper',0),('kowalski',1),('private',9),('rico',5)]):add(n,13,room,0,0x3f95+i,0x71e0+i)
for age in [1,0]:add('franky-'+str(age),0x63,0,age,0x3f9a,0x71e5 if age else 0x71e6)
add('mackey',0x2a,0,0,0x3f8f,0x71c5);add('moseby',0x57,0,0,0x7fab,0x7210);add('skeleton',7,21,0,0x7fac,0x7211)
results=[]
def run(c):
 name,scene,room,age,param,text=c;d=next(x for x in matrix if(x['scene'],x['room'],x['age'])==(scene,room,age));prefix=d['name'].split('-')[1]
 files=list((O/'extracted/pal-1.0/assets/scenes').rglob(f'{prefix}_room_{room}_*ActorEntryList.inc.c'));poss=[]
 for p in files:
  s=re.sub(r'//[^\n]*|/\*.*?\*/','',p.read_text(),flags=re.S if False else 0)
  for mat in re.finditer(r'ACTOR_ELF_MSG2\s*,\s*\{\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(-?\d+)\s*\}\s*,\s*\{[^}]+\}\s*,\s*0x([\da-fA-F]+)',s):
   if int(mat[4],16)==param:poss.append(tuple(map(int,mat.group(1,2,3))))
 assert poss,(name,files,param)
 x,y,z=poss[0];q=bytearray.fromhex(d['save']);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,x,y+1,z+65,-32768,0xdff,d['entrance'],room)
 q[0x1409]=1
 src=body.replace('PARAM',str(param)).replace('TEXT',str(text))
 code=W/f'guest-{name}.c';code.write_text(base[:a]+src+base[b:]);exe=W/f'guest-{name}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(code),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
 save=W/f'guest-{name}.save';save.write_bytes(q);log=W/f'guest-{name}.log';t=time.monotonic()
 with log.open('w')as out:
  try:
   p=subprocess.run([str(exe),str(W/'normal.z64'),f'guest-gap-{name}-v107-direct','2800','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=out,stderr=subprocess.STDOUT,timeout=400)
   ok=p.returncode==0 and 'NEW_GUEST_DIALOGUE_PASSED'in log.read_text();error=None if ok else log.read_text()[-1500:]
  except Exception as e:ok=False;error=repr(e)
 results.append(dict(case=name,passed=ok,scene=scene,room=room,age=age,param=param,text=text,log=log.name,elapsed=round(time.monotonic()-t,1),error=error));(W/'guest-gap-results.json').write_text(json.dumps(results,indent=2));print('NEW_GUEST',name,ok,error or'',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(run,specs))
assert len(results)==len(specs) and all(x['passed']for x in results)

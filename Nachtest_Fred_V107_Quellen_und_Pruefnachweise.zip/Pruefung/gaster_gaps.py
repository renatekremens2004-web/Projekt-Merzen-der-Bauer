from pathlib import Path
import json, os, re, struct, subprocess, math

W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');sy=json.loads((W/'all-symbols-normal.json').read_text())
base=(W/'guest-shaggy.c').read_text();a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
matrix=json.loads(Path('/tmp/final-audit-v106/matrix.json').read_text());folder=O/'extracted/pal-1.0/assets/scenes/dungeons/HAKAdan'
vs=[tuple(map(int,x))for x in re.findall(r'\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\}',next(folder.glob('*VtxList.inc.c')).read_text())]
polys=re.findall(r'COLPOLY_VTX\((\d+),[^)]*\).*?COLPOLY_VTX\((\d+),[^)]*\).*?COLPOLY_VTX\((\d+),[^)]*\).*?COLPOLY_SNORMAL\(([-.\d]+)\).*?COLPOLY_SNORMAL\(([-.\d]+)\).*?COLPOLY_SNORMAL\(([-.\d]+)\)',next(folder.glob('*PolyList.inc.c')).read_text(),re.S)
floors=[tuple(sum(vs[int(i)][k]for i in [a,b,c])/3 for k in range(3))for a,b,c,nx,ny,nz in polys if float(ny)>.6]
cases=[]
for room in [2,6,7,11]:
 d=next(x for x in matrix if(x['scene'],x['room'],x['age'])==(7,room,0));s=next(folder.glob(f'HAKAdan_room_{room}_*ActorEntryList.inc.c')).read_text();m=re.search(r'ACTOR_GASTER_V68\s*,\s*\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\}',s);xyz=tuple(map(int,m.groups()))
 viable=[v for v in floors if abs(v[1]-xyz[1])<55 and 105<math.hypot(v[0]-xyz[0],v[2]-xyz[2])<350]
 assert viable,(room,xyz)
 p=min(viable,key=lambda v:abs(math.hypot(v[0]-xyz[0],v[2]-xyz[2])-160))
 for repeat in range(4):
  q=bytearray.fromhex(d['save']);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,p[0],p[1]+10,p[2],0,0xdff,d['entrance'],room)
  cases.append(dict(name=f'gaster-room-{room}-try-{repeat}',scene=7,room=room,age=0,pause=0,save=q.hex()))
out=bytearray(struct.pack('>I',len(cases)))
for c in cases:out+=c['name'].encode().ljust(64,b'\0')+struct.pack('>HBBI',7,c['room'],0,0)+bytes.fromhex(c['save'])
(W/'gaster-batch.bin').write_bytes(out);(W/'gaster-first.save').write_bytes(bytes.fromhex(cases[0]['save']))
mb=Path('/tmp/final-audit-v106/matrix_body.c').read_text();cut=mb.index('static void onframe(unsigned f){');prefix=mb[:cut]
# Keep native room reloads and resource instrumentation; specialize the interaction.
body=r'''
static unsigned appeared=0,viewed=0,vanished=0,initialsw=0,initialclear=0;
static void onframe(unsigned f){
 baseframe(f);if(f==300){nextcase(f,0);return;}if(f<350)return;findplay();if(!play||!player)return;
 unsigned dt=f-epoch,g=target(0x1aa,0x7fdf);
 if(dt==50){appeared=viewed=vanished=0;initialsw=r32(play+0x1d28);initialclear=r32(play+0x1d3c);}
 if(dt<55)return;
 need(DebugMemRead16(play+0xa4)==7&&DebugMemRead8(play+0x11cbc)==exp_room,"correct shadow room");
 if(g){appeared=1;photo(rf(g+0x24)+70,rf(g+0x28)+70,rf(g+0x2c)+150,rf(g+0x24),rf(g+0x28)+30,rf(g+0x2c));if(DebugMemRead16(g+0x18))viewed=1;
  if(dt>=110&&viewed)position(player,rf(g+0x24),rf(g+0x28)+5,rf(g+0x2c)+25,32767);
 }else if(appeared)vanished=1;
 if(dt>=210){need(!appeared||(viewed&&vanished),"seen apparition vanishes after native proximity check");need(initialsw==r32(play+0x1d28)&&initialclear==r32(play+0x1d3c),"apparition does not alter puzzle flags");printf("GASTER_OBSERVATION room=%u appeared=%u viewed=%u vanished=%u\n",exp_room,appeared,viewed,vanished);finishcase(f,appeared?"gaster-vanished":"randomly-absent");}
}
'''
src=prefix+body
for k,v in [('GAMETABLE',sy['gGameStateOverlayTable']),('OBJECTS',sy['gObjectTable']),('DENIED_OBJECT',sy['gObjectBankDeniedV68']),('DENIED_OVERLAY',sy['gActorOverlayDeniedV68']),('DENIED_INSTANCE',sy['gActorInstanceDeniedV68']),('DENIED_LAST',sy['gActorLastDeniedV68'])]:src=src.replace(k,hex(v))
code=W/'gaster-gaps.c';code.write_text(base[:a]+src+base[b:]);exe=W/'gaster-gaps';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(code),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
log=W/'gaster-gaps.log'
with log.open('w')as f:r=subprocess.run([str(exe),str(W/'normal.z64'),'gaster-gaps-v107-direct','6000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(W/'gaster-first.save')],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null',BATCH_FILE=str(W/'gaster-batch.bin')),stdout=f,stderr=subprocess.STDOUT,timeout=800)
data=log.read_text();observations=[dict(room=int(ro),appeared=int(ap),viewed=int(vi),vanished=int(va))for ro,ap,vi,va in re.findall(r'GASTER_OBSERVATION room=(\d+) appeared=(\d+) viewed=(\d+) vanished=(\d+)',data)]
ok=r.returncode==0 and len(observations)==len(cases) and 'failures=0'in data and all(any(x['room']==room and x['vanished']for x in observations)for room in [2,6,7,11])
(W/'gaster-results.json').write_text(json.dumps(dict(passed=ok,observations=observations),indent=2));print('GASTER_GAPS_RESULT',ok,flush=True);assert ok

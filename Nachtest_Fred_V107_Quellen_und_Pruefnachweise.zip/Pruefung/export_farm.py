from pathlib import Path
import hashlib, json, re, sys

W = Path(__file__).resolve().parent
R = Path('/workspace/Projekt-Merzen-der-Bauer')
O = Path('/workspace/oot-burns-pal')
sys.path.insert(0, str(R / 'tools'))
from build_story import messages, split_pages, LEX, controls
source = O / 'extracted/pal-1.0/text/message_data.h'
raw = source.read_bytes()
m = messages(raw.decode())
story = json.loads((R / 'story/farm_mario_luigi_de.json').read_text())['messages']

def ids_for(actor):
    s = (O / f'src/overlays/actors/ovl_{actor}/z_{actor.lower()}.c').read_text()
    return sorted(set(x.upper() for x in re.findall(r'0x((?:20|70|71)[\da-fA-F]{2})', s)))

groups = [
    ('Malon als Kind – Begegnungen vor der Farm und auf der Farm', ids_for('En_Ma1')),
    ('Malon als Erwachsene – vor Eponas Befreiung', [i for i in ids_for('En_Ma2') if i != '2053']),
    ('Malon als Erwachsene – nach Eponas Befreiung und Hindernisrennen', ids_for('En_Ma3')),
    ('Luigi / ursprüngliche Ingo-Rolle – Kind, Erwachsene, Reiten und Rennen', ids_for('En_In')),
    ('Mario / ursprüngliche Talon-Rolle – Begegnungen, Super-Hühner und Milch', ids_for('En_Ta')),
    ('Kühe und Milch – gemeinsame Texte auch außerhalb der Farm', ids_for('En_Cow')),
    ('Franky die Heugabel – Kind und Erwachsener', ['71E5', '71E6']),
    ('Verbundener früherer Farm-Gast – Mr. Mackey, heute im Gästehaus von Kakariko', ['71C5']),
    ('Schilder der Farm', ['0315', '0316']),
]
covered = {i for _, ids in groups for i in ids}
remaining = sorted(set(story) - covered)
groups.append(('Weitere verbundene Farm-Texte – Waren, Wiederholungen und Erwähnungen außerhalb der Farm', remaining))

def readable(body):
    out = ''
    placeholders = {'NAME':'[Spielername]', 'TIME':'[Uhrzeit]', 'RACE_TIME':'[Rennzeit]', 'POINTS':'[Punkte]', 'TOKENS':'[Skulltula-Symbole]', 'MARATHON_TIME':'[Marathonzeit]'}
    for t in LEX.findall(body):
        if t.startswith('"'):
            out += json.loads(t)
        elif t in placeholders:
            out += placeholders[t]
        elif t.startswith('HIGHSCORE('):
            out += '[Bestwert: ' + t[10:-1] + ']'
        elif t in ['TWO_CHOICE', 'THREE_CHOICE']:
            out += '\n'
    return out

lines = ['# Sämtliche aktuellen Lon-Lon-Farm-Texte – V107', '',
    'Direkt aus dem eingebauten deutschen Spieltext exportiert. Enthalten sind beide Zeitlinien, Wiederholungen, Auswahlzweige, Rennen, Super-Hühner, Kühe, Milch, Schilder und Franky. Mr. Mackeys Text steht als verbundener früherer Farm-Text dabei; sein regulärer Auftritt ist inzwischen im Gästehaus von Kakariko. Verbundene Begegnungen mit Mario/Malon außerhalb der Farm stehen ebenfalls dabei. Die letzte Gruppe enthält zusätzlich gespeicherte Farm-Texte und Erwähnungen durch andere Personen; sie behauptet keinen Auftritt sämtlicher Einträge direkt auf der Farm.', '',
    'Maskenreaktionen bleiben wie in der bisherigen Gesamttextliste ausgeklammert. Jimmy Neutron ist entfernt; sein noch gespeicherter Alttext zählt hier nicht als Farm-Auftritt. 2053 gehört zum Mythenstein und wird von Malon nicht aufgerufen.', '',
    'Jede Seite entspricht einer Textbox-Seite. Bildschirmzeilen sind verbunden; Platzhalter wie Name und Rennzeit bleiben erkennbar. Wortlaut unverändert.', '']
records = []
for title, ids in groups:
    lines += ['## ' + title, '']
    for i in ids:
        assert i in m, i
        body = m[i]['parts'][2][2]
        ps, _ = split_pages(body)
        lines += ['### ' + i, '']
        for n, page in enumerate(ps, 1):
            text = readable(page)
            lines += ['**Seite ' + str(n) + '**', '']
            lines += (['> ' + ' '.join(x.split()) for x in text.splitlines() if x.strip()] if 'CHOICE' in page else ['> ' + ' '.join(text.split())]) + ['']
        follows = re.findall(r'TEXTID\(0x([\da-fA-F]+)\)', body)
        if follows:
            lines += ['Fortsetzung: ' + ', '.join(x.upper() for x in follows) + '.', '']
        records.append(dict(id=i, section=title, pages=[readable(p) for p in ps], controls=controls(body)))
assert set(story) <= {x['id'] for x in records}
assert source.read_bytes() == raw
stem = 'Dialogliste_Lon_Lon_Farm_V107_Aktuell'
for suffix in ['txt', 'md']:
    (W / (stem + '.' + suffix)).write_text('\n'.join(lines))
(W / (stem + '.json')).write_text(json.dumps(records, ensure_ascii=False, indent=2))
proof = dict(source_sha256=hashlib.sha256(raw).hexdigest(), unique_ids=len({x['id'] for x in records}), entries=len(records), pages=sum(len(x['pages']) for x in records), source_unchanged=True)
(W / 'farm-export-verification.json').write_text(json.dumps(proof, indent=2))
print(proof)

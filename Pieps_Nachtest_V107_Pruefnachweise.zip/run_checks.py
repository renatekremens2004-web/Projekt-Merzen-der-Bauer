from pathlib import Path
import concurrent.futures, hashlib, json, os, subprocess, sys, time

W=Path(__file__).resolve().parent
release=Path('/tmp/followup-v107')
jobs=[]
for mode in ['normal','debug']:
    for case in ['cage-child','cage-adult','boss-adult','cleared-adult']:
        jobs.append(('age',mode,case))
    jobs += [('story',mode,'cage-rescue'),('story',mode,'boss-assisted'),('bongo',mode,'head'),('walk',mode,'entry')]
jobs += [('story','normal','cage-absent'),('story','normal','boss-plain'),('story','normal','boss-cleared'),('bongo','normal','hand'),('bongo','normal','cleared')]
prior=json.loads((W/'results.json').read_text())if(W/'results.json').exists()else[]
results=[r for r in prior if r['passed']]
done={(r['family'],r['mode'],r['case'])for r in results}
expected=len(jobs)
jobs=[j for j in jobs if j not in done]

def prepare(family,mode,case):
    d=W/f'{family}-{mode}-{case}';d.mkdir(exist_ok=True)
    sy=(release/f'all-symbols-{mode}.json').read_text()
    (d/f'all-symbols-{mode}.json').write_text(sy)
    (d/f'symbols-{mode}.json').write_text(sy)
    if family=='age':
        source=Path('/tmp/final-audit-v106/legacy88')
        names=['pieps_age_qa.py','pieps_age_body.c']
    elif family=='story':
        source=Path('/workspace/pieps-v79');names=['qa.py','boss_body.c']
    elif family=='bongo':
        source=Path('/tmp/final-audit-v106/legacy97');names=['qa.py']
        (d/'qa-case.txt').write_text(case)
    else:
        source=Path('/tmp/final-audit-v106/legacy87');names=['walk-cage_qa.py','walk-combined.c']
    for name in names:
        s=(source/name).read_text()
        s=s.replace("a=s.index('static void capture_render(void){}')", "s=s.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/pieps-recheck-stall.bin').replace('obj<=0x1af','obj<=0x1b0');a=s.index('static void capture_render(void){}')")
        s=s.replace("a=base.index('static void capture_render(void){}')", "base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/pieps-recheck-stall.bin').replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}')")
        s=s.replace('/workspace/pieps-v79/rescued.save',str(d/'rescued.save'))
        s=s.replace("f'pieps-{mode}-{tag}'","f'pieps-recheck-{mode}-{tag}-direct'")
        s=s.replace("link=Path('/workspace/bean-rider')/shots.name", "link=Path('/tmp')/('pieps-recheck-link-'+mode+'-'+case)")
        # No shared output executable between the three Bongo scenarios.
        s=s.replace("f'pieps-hole-v97-{mode}'", "f'pieps-recheck-{mode}-{case}'")
        s=s.replace('pieps-age-v88-','pieps-recheck-age-').replace('pieps-hole-v97-direct-','pieps-recheck-bongo-direct-').replace('combined-v86-','pieps-recheck-walk-')
        (d/name).write_text(s)
    return d

def run(job):
    family,mode,case=job;d=prepare(*job);fd=os.open(release/(mode+'.z64'),os.O_RDONLY);rom='/proc/self/fd/'+str(fd)
    env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null')
    if family=='age':args=[sys.executable,str(d/'pieps_age_qa.py'),rom,mode,case]
    elif family=='story':
        args=[sys.executable,str(d/'qa.py'),rom,mode];env['PIEPS_TAGS']=case
    elif family=='bongo':args=[sys.executable,str(d/'qa.py'),rom,mode]
    else:args=[sys.executable,str(d/'walk-cage_qa.py'),rom,mode]
    log=W/f'{family}-{mode}-{case}.log';start=time.monotonic()
    with log.open('w')as out:
        try:
            p=subprocess.run(args,pass_fds=(fd,),env=env,stdout=out,stderr=subprocess.STDOUT,timeout=900)
            ok=p.returncode==0
            # Confirm the native assertion marker, rather than only the emulator exit code.
            marker={'age':'PIEPS_AGE_PASSED','story':'PIEPS_QA_PASSED','bongo':'PIEPS_BONGO_PASSED','walk':'COMBINED_DDAN_QA_PASSED'}[family]
            native=list(d.glob('*.log'));ok=ok and any(marker in f.read_text(errors='replace')for f in native+[log])
            error=None if ok else log.read_text()[-2400:]
        except Exception as e:ok=False;error=repr(e)
    os.close(fd)
    row=dict(family=family,mode=mode,case=case,passed=ok,elapsed=round(time.monotonic()-start,1),log=log.name,error=error)
    results.append(row);(W/'results.json').write_text(json.dumps(results,indent=2));print('PIEPS_RECHECK',family,mode,case,ok,row['elapsed'],error or'',flush=True)

with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:list(pool.map(run,jobs))
print('PIEPS_RECHECK_FINISHED',len(results),'failed',sum(not r['passed']for r in results),flush=True)
assert len(results)==expected and all(r['passed']for r in results)

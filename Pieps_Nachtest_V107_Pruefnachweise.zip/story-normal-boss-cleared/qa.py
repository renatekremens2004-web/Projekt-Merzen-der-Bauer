from pathlib import Path
import os,sys,json,re,subprocess,struct,concurrent.futures
W=Path(__file__).resolve().parent
if not os.environ.get('PIEPS_TAGS') and (W/'qa-tags.txt').exists():os.environ['PIEPS_TAGS']=(W/'qa-tags.txt').read_text().strip()
if os.environ.get('PIEPS_TAGS')=='publish':
 import runpy
 runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit(0)
O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];sy=json.loads((W/f'symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());s=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:s=s.replace(hex(old[n]),hex(sy[n]))
s=s.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/pieps-recheck-stall.bin').replace('obj<=0x1af','obj<=0x1b0');a=s.index('static void capture_render(void){}');b=s.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned ticks=0,seen=0,help=0,rescued=0,music=0,finished=0;
static void onframe(unsigned f){
 unsigned value=0,bird=0,msg=0,id=0;int farm=strstr(scenario,"farm")!=NULL,absent=strstr(scenario,"absent")!=NULL,visual=strstr(scenario,"visual")!=NULL;
 baseframe(f);if(f<340)return;findplay();if(!play||!player)return;msg=play+0x20d8;id=DebugMemRead16(msg+0xe2f8);bird=target(0x72,0x7501);
 if(bird&&r32(bird+0x134))seen=1;
 if(farm){need(!target(0x173,0x3f8e),"Jimmy actor absent");if(f==430||f==650){bank();}if(f>750){puts("PIEPS_QA_PASSED Jimmy absent; bank in budget");CoreDoCommand(M64CMD_STOP,0,NULL);}return;}
 if(absent){need(!bird,"rescued bird absent on next entry");if(f==600)bank();if(f>650){puts("PIEPS_QA_PASSED bird absent after rescue");CoreDoCommand(M64CMD_STOP,0,NULL);}return;}
 if(id==0x7239)help=1;
 if((DebugMemRead8(AUDIO_CONTEXT+0x3534)==111)&&(DebugMemRead8(AUDIO_CONTEXT+0x3530)&0x80))music=1;
 if(bird&&DebugMemRead16(bird+0x18c)>=2&&!visual){
  float x=rf(bird+0x24),y=rf(bird+0x28),z=rf(bird+0x2c);position(player,x-40,y,z+48,26000);if(f==500)photo(x+65,y+42,z+95,x,y+20,z);
  if(f>650){
   for(unsigned p=r32(play+0x1c34+5*8),n=0;p>=0x80000000&&p<0x80400000&&n<80;p=r32(p+0x124),n++){
    if(DebugMemRead16(p)==0x25&&DebugMemRead16(p+0x3ec)==5&&r32(p+0x130)&&r32(p+0x3cc)<10){DebugMemWrite8(p+0xb0,20);DebugMemWrite8(p+0xb1,0);DebugMemWrite8(p+0x419,DebugMemRead8(p+0x419)|2);}
   }
   value=0;if(f%15<2)value|=0x80;
  }
 }
 if(f==365||f==385||f==420||f==500||f==620||f==950||f==1250){bank();printf("PIEPS f=%u bird=%x help=%u state=%u text=%x music=%u flag=%x\n",f,bird,help,bird?DebugMemRead16(bird+0x18c):0,id,music,DebugMemRead16(savebase+0xf30));}
 if(DebugMemRead16(savebase+0xf30)&0x400){rescued=1;if(!finished)finished=f;}
 if(f%200==0&&bird)printf("TALK f=%u playerstate=%x cs=%u talk=%x birdflag=%x dist=%.1f msgmode=%u lock=%u\n",f,r32(player+0x66c),DebugMemRead8(player+0x434),r32(player+0x684),r32(bird+4),rf(bird+0x90),DebugMemRead8(msg+0xe304),DebugMemRead8(bird+0x10c));
 if(buttons)buttons(value);
 if(visual&&f>720){need(seen&&help&&bird&&DebugMemRead16(bird+0x18c)>=2,"bird intro and camera restore");puts("PIEPS_QA_PASSED native bird/cage/intro");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(!visual&&rescued&&f>finished+50){bank();need(seen&&help&&music,"rescue after combat with own theme");FILE* q=fopen("/tmp/pieps-recheck-v107/story-normal-boss-cleared/rescued.save","wb");need(q!=NULL,"save fixture");for(unsigned i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),q);fclose(q);puts("PIEPS_QA_PASSED rescue persisted");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(f>2500){puts("PIEPS_QA_TIMEOUT");exit(96);}
}
'''.replace('AUDIO_CONTEXT',hex(sy['gAudioCtx']))
cage_body=body
if 'boss' in os.environ.get('PIEPS_TAGS',''):
 body=(W/'boss_body.c').read_text()
 for macro,n in [('BOSS_VRAM','_ovl_Boss_DodongoSegmentStart'),('INHALE','BossDodongo_Inhale'),('EXPLODE','BossDodongo_Explode'),('DEATH','BossDodongo_DeathCutscene'),('AUDIO_CONTEXT','gAudioCtx')]: body=body.replace(macro,hex(sy[n]))
 body=cage_body.replace('static void onframe(', 'static void cageframe(')+body.replace('static void capture_render(void){}','').replace('static void onframe(', 'static void bossframe(')+'\nstatic void onframe(unsigned f){if(strstr(scenario,\"boss\"))bossframe(f);else cageframe(f);}'
if (W/'qa-record.txt').exists():
 body=body.replace('static void capture_render(void){}',(W/'video_capture.c').read_text()).replace('baseframe(f);if(f<340)return;', 'baseframe(f);if(f<340)return;if(getenv("PIEPS_VIDEO_PATH"))pending=1;')
 s=s.replace('if(video && pclose(video)!=0)return 96;', 'if(video){hold_frame_until(audioSamples());printf("PIEPS_VIDEO first=%llu last=%llu rate=%u frames=%u\\n",(unsigned long long)firstAudio,(unsigned long long)lastAudio,audioRate(),encoded);}if(video && pclose(video)!=0)return 96;')
q=W/f'qa-{mode}.c';q.write_text(s[:a]+body+s[b:]);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(q),'-o',str(W/f'qa-{mode}'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
text=(O/'include/tables/entrance_table.h').read_text()
def entry(name):return int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\('+name+r',',text)[1],16)
def fixture(tag,age=1,rescued=False,farm=False,night=False):
 q=bytearray(Path('/workspace/kokiri-speed-v66/child.save'if age else'/workspace/proto-soldier-v68/soldier.save').read_bytes());e=entry('ENTR_LON_LON_RANCH_0'if farm else'ENTR_DODONGOS_CAVERN_0');struct.pack_into('>III',q,0,e,age,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,0 if farm else 2920,0 if farm else 100,0 if farm else -2292,0,0xdff,e,0 if farm else 3);q[0x1409]=1;struct.pack_into('>H',q,0xc,0xc000 if night else 0x8000);v=struct.unpack_from('>H',q,0xf30)[0];struct.pack_into('>H',q,0xf30,(v|0x400)if rescued else(v&~0x400));struct.pack_into('>I',q,0xd4+0x1c+4,0);struct.pack_into('>I',q,0xd4+0x1c+8,0);(W/(tag+'.save')).write_bytes(q)
for tag,kwargs in [('cage-visual',{}),('cage-rescue',{}),('cage-absent',dict(rescued=True)),('farm-day',dict(age=0,farm=True)),('farm-night',dict(age=0,farm=True,night=True))]:fixture(tag,**kwargs)
for tag in ['boss-assisted','boss-plain','boss-cleared']:
 q=bytearray((W/'cage-absent.save').read_bytes()); e=entry('ENTR_DODONGOS_CAVERN_BOSS_0');struct.pack_into('>I',q,0,e);struct.pack_into('>fffhHhB',q,0x1368,-890,-1523.76,-2804,0,0xdff,e,1);struct.pack_into('>I',q,0xd4+0x12*0x1c+8,2 if tag=='boss-cleared' else 0);struct.pack_into('>H',q,0xed4+7*2,struct.unpack_from('>H',q,0xed4+7*2)[0]|2);q[0x69]=2;q[0x6c]=2;q[0x76]=2;q[0x8e]=30;struct.pack_into('>H',q,0x30,0x140);struct.pack_into('>H',q,0x2e,0x140)
 if tag=='boss-plain':struct.pack_into('>H',q,0xf30,struct.unpack_from('>H',q,0xf30)[0]&~0x400)
 (W/(tag+'.save')).write_bytes(q)
tags=os.environ.get('PIEPS_TAGS','cage-visual,cage-rescue,cage-absent,farm-day,farm-night').split(',')
def one(tag):
 env=os.environ.copy();env.update(DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null');logfile=W/f'{mode}-{tag}.log';fds=[int(rom.rsplit('/',1)[1])];record=(W/'qa-record.txt').exists()
 if record:
  pcm=os.memfd_create('pieps-audio');vid=os.memfd_create('pieps-video');fds +=[pcm,vid];env.update(CREDITS_AUDIO_PATH=f'/proc/self/fd/{pcm}',PIEPS_VIDEO_PATH=f'/proc/self/fd/{vid}')
 with logfile.open('w')as log:p=subprocess.run([str(W/f'qa-{mode}'),rom,f'pieps-recheck-{mode}-{tag}-direct','4900','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(W/(tag+'.save'))],pass_fds=tuple(fds),env=env,stdout=log,stderr=subprocess.STDOUT,timeout=500)
 out=logfile.read_text(errors='replace');r=dict(tag=tag,passed=p.returncode==0 and'PIEPS_QA_PASSED'in out,tail=out[-1700:]);print(r,flush=True)
 if record and r['passed']:
  first,last,rate,frames=map(int,re.search(r'PIEPS_VIDEO first=(\d+) last=(\d+) rate=(\d+) frames=(\d+)',out).groups());final=os.memfd_create('pieps-mp4');fds.append(final)
  subprocess.run(['ffmpeg','-y','-v','error','-i',f'/proc/self/fd/{vid}','-f','s16le','-ar',str(rate),'-ac','2','-ss',str(first/rate),'-i',f'/proc/self/fd/{pcm}','-map','0:v','-map','1:a','-t',str(frames/50),'-c:v','copy','-c:a','aac','-b:a','160k','-movflags','+faststart','-f','mp4',f'/proc/self/fd/{final}'],pass_fds=tuple(fds),check=True)
  os.lseek(final,0,0);data=os.read(final,os.fstat(final).st_size);import publish_ram_artifacts as pub
  try:report=pub.publish({f'Pieps_{tag}_V79.mp4':data},'Pieps V79: native 4 MiB scene demonstration with game music')
  finally:
   for path in pub.created:path.unlink()
   for n in pub.fds:os.close(n)
   pub.created.clear();pub.fds.clear()
  (W/f'video-{mode}-{tag}.json').write_text(json.dumps(report,indent=2));print('VIDEO_PUBLIC',report,flush=True)
 if record:
  for n in fds[1:]:os.close(n)
 return r
with concurrent.futures.ThreadPoolExecutor(max_workers=1)as pool:results=list(pool.map(one,tags))
(W/f'qa-results-{mode}.json').write_text(json.dumps(results,indent=2));assert all(r['passed']for r in results)

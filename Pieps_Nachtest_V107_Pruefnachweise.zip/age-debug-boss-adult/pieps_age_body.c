static void capture_render(void){}
static void onframe(unsigned f){
 static unsigned seen=0,help=0,exploded=0,death=0;unsigned v=0;
 int child=strstr(scenario,"-child-")!=NULL,cage=strstr(scenario,"-cage-")!=NULL,cleared=strstr(scenario,"-cleared-")!=NULL;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 need(DebugMemRead16(play+0xa4)==(cage?1:0x12),"correct cave/boss scene for age test");
 unsigned bird=actor(0x72),boss=actor(0x12),msg=play+0x20d8;
 if(cage){
  if(child){if(bird&&r32(bird+0x134))seen=1;if(DebugMemRead16(msg+0xe2f8)==0x7239)help=1;}
  else{need(!bird,"no adult bird/cage actor");need(!r32(overlays+0x72*0x20+0x10),"adult cage does not even load bird overlay");}
  if(f>720){bank();if(child)need(seen&&help&&bird&&DebugMemRead16(bird+0x18c)>=2,"child cage intro retained and camera released");puts("PIEPS_AGE_PASSED cage");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }else if(cleared){
  need(!bird,"no post-boss bird when adult revisits cleared arena");
  if(f>650){bank();need(!boss&&actor(0x5f)&&actor(0x5d),"native cleared arena heart/warp retained");puts("PIEPS_AGE_PASSED adult cleared arena");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }else{
  need(boss,"boss remains loaded");
  if(f==500){
   unsigned ram=r32(overlays+0x27*0x20+0x10);need(ram,"boss overlay is loaded");
   // Controlled explosion-phase fixture: exercise the age guard with the rescue flag already set.
   DebugMemWrite32(boss+0x180,ram+EXPLODE-BOSS_VRAM);DebugMemWrite16(boss+0x1da,0);exploded=1;
  }
  if(bird&&r32(bird+0x134))seen=1;
  if(r32(boss+0x180)==r32(overlays+0x27*0x20+0x10)+DEATH-BOSS_VRAM)death=1;
  if(!child)need(!bird,"adult explosion phase never starts Pieps flight or post-boss role");
  if(f>850){bank();need(exploded,"explosion-phase fixture exercised");if(child)need(seen&&death,"rescued child bird still flies in and starts native boss death");else need(!seen&&!death,"adult boss keeps ordinary explosion behavior despite rescue flag");puts("PIEPS_AGE_PASSED boss explosion age gate");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(f%150==0){bank();printf("PIEPS_AGE f=%u age=%u cage=%d cleared=%d bird=%x boss=%x seen=%u help=%u death=%u\n",f,r32(savebase+4),cage,cleared,bird,boss,seen,help,death);}
 if(buttons)buttons(v);
}

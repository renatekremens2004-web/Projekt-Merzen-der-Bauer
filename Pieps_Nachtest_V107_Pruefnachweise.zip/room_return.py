from pathlib import Path
import json, os, subprocess

W=Path(__file__).resolve().parent;d=W/'story-normal-cage-rescue';sy=json.loads((d/'symbols-normal.json').read_text())
s=(d/'qa-normal.c').read_text()
s=s.replace('static unsigned ticks=0,seen=0,help=0,rescued=0,music=0,finished=0;', 'static unsigned ticks=0,seen=0,help=0,rescued=0,music=0,finished=0,route=0,routeAt=0,routePaused=0;')
s=s.replace('if(bird&&DebugMemRead16(bird+0x18c)>=2&&!visual){','if(bird&&DebugMemRead16(bird+0x18c)>=2&&!visual&&!rescued){')
start=s.index(' if(!visual&&rescued&&f>finished+50){')
end=s.index('\n if(f>2500)',start)
body=r'''
 if(!visual&&rescued&&f>finished+50){
  unsigned room=DebugMemRead8(play+0x11cbc),ps=DebugMemRead16(play+0x10934);value=0;
  if(!route){need(seen&&help&&music,"native rescue completed before room cycle");need(r32(play+0x1d28)&32,"native Lizalfos battle switch set");route=1;routeAt=f;photo(3560,270,-1640,3560,140,-1200);}
  if(route==1){if(f<routeAt+30&&!DebugMemRead8(play+0x1d6c))position(player,3560,100,-1580,0);value=0x20|0x40000000;if(f%20<3)value|=0x80;if(room==1){route=2;routeAt=f;}}
  else if(route==2){if(f<routeAt+35)position(player,3560,110,-800,0);if(f>routeAt+110){need(!bird,"cage and bird unload after real room exit");need(!r32(overlays+0x72*0x20+0x10),"bird overlay unloaded after exit");need((DebugMemRead16(ACTIVESEQ+0x254)&255)!=111,"Pieps theme stops after leaving cage room");bank();puts("PIEPS_REAL_EXIT_PASSED");route=3;routeAt=f;photo(3560,270,-1010,3560,140,-1290);}}
  else if(route==3){if(f<routeAt+30&&!DebugMemRead8(play+0x1d6c))position(player,3560,100,-1070,-32768);value=0x20|0x40000000;if(f%20<3)value|=0x80;if(room==3){route=4;routeAt=f;value=0;}}
  else if(route==4&&f>routeAt+90){need(!bird,"rescued cage and bird stay absent on actual re-entry");need(DebugMemRead16(savebase+0xf30)&0x400,"native rescue flag persists through room exit/re-entry");need(r32(play+0x1d28)&32,"native battle completion remains set");value=0x10;route=5;routeAt=f;}
  else if(route==5){if(f<routeAt+3)value=0x10;if(ps==6){routePaused=1;route=6;routeAt=f;}}
  else if(route==6){if(f>=routeAt+15&&f<routeAt+18)value=0x10;if(!ps&&f>routeAt+25){need(routePaused,"inventory was actually opened");need(rf(player+0x28)>60,"player keeps the native floor after return and inventory");bank();printf("PIEPS_REAL_ROOM_RETURN_PASSED room=%u flag=%x\n",room,DebugMemRead16(savebase+0xf30));CoreDoCommand(M64CMD_STOP,0,NULL);}}
  if(f%150==0)printf("PIEPS_ROOM_ROUTE f=%u phase=%u room=%u bird=%x xyz=%.1f,%.1f,%.1f pause=%u\n",f,route,room,bird,rf(player+0x24),rf(player+0x28),rf(player+0x2c),ps);
  if(buttons)buttons(value);
 }
'''.replace('ACTIVESEQ',hex(sy['gActiveSeqs']))
s=s[:start]+body+s[end:];s=s.replace('if(f>2500)','if(f>5500)')
c=W/'room-return.c';c.write_text(s);exe=W/'room-return';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
log=W/'room-return.log'
with log.open('w')as out:r=subprocess.run([str(exe),'/tmp/followup-v107/normal.z64','pieps-real-room-return-v107-direct','5800','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(d/'cage-rescue.save')],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=out,stderr=subprocess.STDOUT,timeout=600)
ok=r.returncode==0 and 'PIEPS_REAL_ROOM_RETURN_PASSED'in log.read_text();(W/'room-return-results.json').write_text(json.dumps(dict(passed=ok,log=log.name),indent=2));print('REAL_ROOM_RETURN',ok,flush=True);assert ok,log.read_text()[-2200:]

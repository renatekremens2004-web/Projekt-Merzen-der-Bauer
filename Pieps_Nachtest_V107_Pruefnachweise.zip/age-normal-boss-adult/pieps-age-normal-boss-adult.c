#define M64P_CORE_PROTOTYPES
#include "m64p_common.h"
#include "m64p_frontend.h"
#include "m64p_config.h"
#include "m64p_debugger.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <execinfo.h>
#include <math.h>
static void crash(int n){void* b[40];int c=backtrace(b,40);backtrace_symbols_fd(b,c,2);_exit(128+n);}

static void alarmcb(int sig){(void)sig;uint32_t* c=DebugGetCPUDataPtr(M64P_CPU_REG_COP0);printf("CPU pc=%08x cause=%08x epc=%08x bad=%08x\n",*(uint32_t*)DebugGetCPUDataPtr(M64P_CPU_PC),c[13],c[14],c[8]);for(uint32_t t=DebugMemRead32(0x8000633c),n=0;t>=0x80000000 && t<0x80800000 && n<15;t=DebugMemRead32(t+12),n++){printf("THREAD %08x id=%u state=%u pc=%08x ra=%08x sp=%08x\n",t,DebugMemRead32(t+20),DebugMemRead16(t+16),DebugMemRead32(t+0x11c),DebugMemRead32(t+0x104),DebugMemRead32(t+0xf4));}FILE* d=fopen("/tmp/pieps-recheck-stall.bin","wb");for(uint32_t a=0x80000000;a<0x80400000;a+=4){uint32_t v=__builtin_bswap32(DebugMemRead32(a));fwrite(&v,4,1,d);}fclose(d);alarm(15);}
static uint32_t savebase=0x80118450, overlays=0x800e6500;
static int limit=2400;static int memory_mb=4;
static const char* scenario;
static const char* snapshotfile;
static void (*buttons)(unsigned);
static unsigned actors[32],player;static int count;
static uint32_t r32(uint32_t a){return DebugMemRead32(a);}
static float rf(uint32_t a){uint32_t x=r32(a);float f;memcpy(&f,&x,4);return f;}
static void debugcb(void* ctx,int level,const char* message){static int bad=0;if(strstr(message,"UNKNOWN GBI COMMAND") || strstr(message,"Using Vertex outside buffer")){if(++bad>100)exit(98);}if(level<=2)fprintf(stderr,"EMU %d: %s\n",level,message);}
static void scan(void){
 count=0;
 for(uint32_t a=0x80120000;a<0x80400000-0x700;a+=4){
  unsigned id=DebugMemRead16(a);if(id==0 && r32(a+0x138)==overlays && DebugMemRead8(a+2)==2 && r32(a+0x130))player=a;if(id!=0xe8 && id!=0x2a && id!=0x17a && id!=0x52)continue;
  if(r32(a+0x138)!=overlays+id*0x20 || !r32(a+0x130))continue;
  int params=(int16_t)DebugMemRead16(a+0x1c);
  if(id==0xe8 && params>=100)continue;
  if(id==0x2a && (params>>8)!=3 && (params>>8)!=5 && (params>>8)!=7 && (params>>8)!=8 && (params>>8)!=9)continue;
  if(count<32)actors[count++]=a;
 }
}
static uint32_t play;
static uint32_t actor(int id){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130))return a;
 return 0;
}
static uint32_t actor_type(int id,int type){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130) && (type<0 || (DebugMemRead16(a+0x1c)&127)==type))return a;
 return 0;
}
static void findplay(void){
 if(play && r32(play+0x1c44)==player && player && r32(player+0x130))return;
 play=0;player=0;scan();if(!player)return;
 for(uint32_t a=0x80120000;a<0x80400000;a+=4)if(r32(a)==player && a>0x80121c44 && r32(a-4)==1){uint32_t p=a-0x1c44;if(DebugMemRead16(p+0xa4)<0x70 && r32(p)>=0x80000000){play=p;break;}}
 if(play)printf("PLAY %08x player=%08x scene=%x\n",play,player,DebugMemRead16(play+0xa4));
}
static void wf(uint32_t a,float f){uint32_t v;memcpy(&v,&f,4);DebugMemWrite32(a,v);}
static void position(uint32_t a,float x,float y,float z,int facing){wf(a+0x24,x);wf(a+0x28,y);wf(a+0x2c,z);wf(a+0x100,x);wf(a+0x104,y);wf(a+0x108,z);DebugMemWrite16(a+0xb6,facing);DebugMemWrite16(a+0x32,facing);}
static void baseframe(unsigned f){
 alarm(30);
 if (snapshotfile && f == 300) {
   findplay();
   if (strstr(scenario,"export")) {
     FILE* snap=fopen(snapshotfile,"wb");if(!snap)exit(90);
     for(unsigned i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),snap);
     fclose(snap);printf("EXPORTED save=%08x entrance=%x age=%d mode=%d\n",savebase,r32(savebase),r32(savebase+4),r32(savebase+0x135c));
     CoreDoCommand(M64CMD_STOP,0,NULL);return;
   }
   if(!play){fprintf(stderr,"No title PlayState found\n");exit(91);}
   printf("INJECT title scene=%x mode=%d save=%08x\n",DebugMemRead16(play+0xa4),r32(savebase+0x135c),savebase);
   FILE* snap=fopen(snapshotfile,"rb");if(!snap)exit(92);
   for(unsigned i=0;i<0x1428;i++){int ch=fgetc(snap);if(ch<0)exit(93);DebugMemWrite8(savebase+i,ch);}fclose(snap);
   DebugMemWrite32(savebase+0x135c,0);
   DebugMemWrite8(play+0x11de8,r32(savebase+4));
   DebugMemWrite16(savebase+0x1412,r32(savebase+8)?r32(savebase+8):0xffef);
   DebugMemWrite8(play+0x1d6c,0);
   if(strstr(scenario,"direct")) {
     uint32_t game=0x800f1890+3*0x30;
     if(r32(game+0x2c)!=0x12518){fprintf(stderr,"Invalid Play gamestate entry\n");exit(97);}
     DebugMemWrite8(play+0x11de9,1);
     DebugMemWrite32(play+0xc,r32(game+0x18));DebugMemWrite32(play+0x10,0x12518);DebugMemWrite32(play+0x98,0);
     printf("DIRECT Play_Init=%08x\n",r32(game+0x18));
   }else{
     DebugMemWrite16(play+0x11e1a,r32(savebase));
     DebugMemWrite8(play+0x11e5e,2);DebugMemWrite8(play+0x11e15,20);
   }
   printf("START entrance=%x age=%d cs=%x\n",r32(savebase),r32(savebase+4),r32(savebase+8));
 }
}

static uint64_t (*audioSamples)(void);static unsigned (*audioRate)(void);
static FILE* video=NULL;
static void need(int ok,const char*why){if(!ok){printf("ASSERT_FAILED %s\n",why);exit(96);}}
static unsigned target(unsigned id,unsigned param){
 for(int cat=0;cat<12;cat++)for(unsigned p=r32(play+0x1c34+cat*8),n=0;p>=0x80000000&&p<0x80400000&&n<200;p=r32(p+0x124),n++)if(DebugMemRead16(p)==id&&DebugMemRead16(p+0x1c)==param&&r32(p+0x130))return p;
 return 0;
}
static void bank(void){
 unsigned c=play+0x117a4,begin=r32(c),end=r32(c+4),last=begin,count=DebugMemRead8(c+8);
 for(unsigned i=0;i<count&&i<19;i++){unsigned p=c+12+i*0x44;int obj=(int16_t)DebugMemRead16(p);if(obj<0)obj=-obj;if(obj>0&&obj<=0x1b0){unsigned e=r32(p+4)+r32(0x800f9798+obj*8+4)-r32(0x800f9798+obj*8);if(e>last)last=e;}}
 need(DebugMemRead16(0x8011d628)==0,"no rejected object loads");need(DebugMemRead16(0x8011a0f8)==0&&DebugMemRead16(0x8011a0fa)==0,"all actor allocations succeed");for(unsigned q=0;q<3;q++){unsigned ctx=r32(play),off=0x2a8+q*16;need(r32(ctx+off+8)<=r32(ctx+off+12),"graphics command and matrix buffers stay within bounds");}printf("BANK slots=%u used=%u free=%d RAM=%u\n",count,last-begin,(int)(end-last),r32(0x80000318));need(count<=19&&last<=end,"object bank within budget");need(r32(0x80000318)==4194304,"native 4 MiB");
}
static void photo(float x,float y,float z,float ax,float ay,float az){
 unsigned c=r32(play+0x790+DebugMemRead16(play+0x7a0)*4);DebugMemWrite16(c+0x142,0x21);DebugMemWrite16(c+0x144,0);DebugMemWrite16(c+0x15e,1);DebugMemWrite16(c+0x14c,0);wf(c+0xfc,55);wf(c+0x5c,x);wf(c+0x60,y);wf(c+0x64,z);wf(c+0x74,x);wf(c+0x78,y);wf(c+0x7c,z);wf(c+0x50,ax);wf(c+0x54,ay);wf(c+0x58,az);
}





static void capture_render(void){}
static void onframe(unsigned f){
 static unsigned seen=0,help=0,exploded=0,death=0;unsigned v=0;
 int child=strstr(scenario,"-child-")!=NULL,cage=strstr(scenario,"-cage-")!=NULL,cleared=strstr(scenario,"-cleared-")!=NULL;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 need(DebugMemRead16(play+0xa4)==(cage?1:0x12),"correct cave/boss scene for age test");
 unsigned bird=actor(0x72),boss=actor(0x12),msg=play+0x20d8;
 if(cage){
  if(child){if(bird&&r32(bird+0x134))seen=1;if(DebugMemRead16(msg+0xe2f8)==0x7239)help=1;}
  else{need(!bird,"no adult bird/cage actor");need(!r32(overlays+0x72*0x20+0x10),"adult cage does not even load bird overlay");}
  if(f>720){bank();if(child)need(seen&&help&&bird&&DebugMemRead16(bird+0x18c)>=2,"child cage intro retained and camera released");puts("PIEPS_AGE_PASSED cage");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }else if(cleared){
  need(!bird,"no post-boss bird when adult revisits cleared arena");
  if(f>650){bank();need(!boss&&actor(0x5f)&&actor(0x5d),"native cleared arena heart/warp retained");puts("PIEPS_AGE_PASSED adult cleared arena");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }else{
  need(boss,"boss remains loaded");
  if(f==500){
   unsigned ram=r32(overlays+0x27*0x20+0x10);need(ram,"boss overlay is loaded");
   // Controlled explosion-phase fixture: exercise the age guard with the rescue flag already set.
   DebugMemWrite32(boss+0x180,ram+0x808a338c-0x808a12c0);DebugMemWrite16(boss+0x1da,0);exploded=1;
  }
  if(bird&&r32(bird+0x134))seen=1;
  if(r32(boss+0x180)==r32(overlays+0x27*0x20+0x10)+0x808a5c40-0x808a12c0)death=1;
  if(!child)need(!bird,"adult explosion phase never starts Pieps flight or post-boss role");
  if(f>850){bank();need(exploded,"explosion-phase fixture exercised");if(child)need(seen&&death,"rescued child bird still flies in and starts native boss death");else need(!seen&&!death,"adult boss keeps ordinary explosion behavior despite rescue flag");puts("PIEPS_AGE_PASSED boss explosion age gate");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(f%150==0){bank();printf("PIEPS_AGE f=%u age=%u cage=%d cleared=%d bird=%x boss=%x seen=%u help=%u death=%u\n",f,r32(savebase+4),cage,cleared,bird,boss,seen,help,death);}
 if(buttons)buttons(v);
}
static void setting(const char* section,const char* key,m64p_type type,const void* value){m64p_handle h;ConfigOpenSection(section,&h);ConfigSetParameter(h,key,type,value);}
static void integer(const char* section,const char* key,int value){setting(section,key,M64TYPE_INT,&value);}
static void boolean(const char* section,const char* key,int value){setting(section,key,M64TYPE_BOOL,&value);}
int main(int argc,char** argv){signal(SIGSEGV,crash);
 if(argc<3)return 2;scenario=argv[2];if(strstr(scenario,"-us")){savebase=0x8011a5d0;overlays=0x800e8530;}if(argc>3)limit=atoi(argv[3]);if(argc>4)memory_mb=atoi(argv[4]);setbuf(stdout,NULL);
 if(argc>5)savebase=strtoul(argv[5],NULL,0);if(argc>6)overlays=strtoul(argv[6],NULL,0);
 if(argc>7)snapshotfile=argv[7];
 char config[512],shots[512];snprintf(config,sizeof(config),"/tmp/config-%s",scenario);snprintf(shots,sizeof(shots),"/tmp/screens-%s",scenario);mkdir(config,0700);mkdir(shots,0700);
 void* sdl=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_GLOBAL);int(*sdlinit)(unsigned)=dlsym(sdl,"SDL_Init");sdlinit(0x20|0x200);
 int r=CoreStartup(0x020001,config,"/workspace/toolchain/root/usr/share/games/mupen64plus",NULL,debugcb,NULL,NULL);if(r)return r;
 integer("Video-GLideN64","EnableCopyColorToRDRAM",1);
 boolean("Video-GLideN64","EnableClipping",1);
 boolean("Video-GLideN64","EnableCustomSettings",0);
 setting("Core","SharedDataPath",M64TYPE_STRING,"/workspace/toolchain/root/usr/share/games/mupen64plus");
 setting("Core","ScreenshotPath",M64TYPE_STRING,shots);setting("Core","SaveStatePath",M64TYPE_STRING,config);setting("Core","SaveSRAMPath",M64TYPE_STRING,config);
 boolean("Core","DisableExtraMem",memory_mb==4);integer("Core","R4300Emulator",memory_mb==4?1:2);boolean("Core","OnScreenDisplay",0);integer("Video-General","ScreenWidth",640);integer("Video-General","ScreenHeight",480);boolean("Video-General","Fullscreen",0);boolean("Video-General","VerticalSync",0);
 FILE* file=fopen(argv[1],"rb");if(!file)return 3;fseek(file,0,SEEK_END);long n=ftell(file);rewind(file);void* rom=malloc(n);if(fread(rom,1,n,file)!=(size_t)n)return 4;fclose(file);r=CoreDoCommand(M64CMD_ROM_OPEN,n,rom);if(r)return r;
 fprintf(stderr,"Core paths: %s | %s | %s\n",ConfigGetUserDataPath(),ConfigGetUserCachePath(),ConfigGetUserConfigPath());
 m64p_rom_settings rs;memset(&rs,0,sizeof(rs));r=CoreDoCommand(M64CMD_ROM_GET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 rs.disableextramem=memory_mb==4;r=CoreDoCommand(M64CMD_ROM_SET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 printf("Requested memory: %d MiB; disableextramem=%d\n",memory_mb,rs.disableextramem);
 const char* paths[]={"/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-rsp-hle.so","/workspace/toolchain/RMG-060/glide-build/plugin/Release/mupen64plus-video-GLideN64.so","/workspace/kakariko-parking-v50/capture_audio.so","/workspace/wallace-cheer/record_input.so"};
 if(strstr(scenario,"mk2"))paths[1]="/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-video-glide64mk2.so";
 void* core=dlopen("libmupen64plus.so.2",RTLD_NOW|RTLD_GLOBAL);int order[]={1,2,3,0};
 for(int k=0;k<4;k++){int i=order[k];if(!paths[i])continue;void* plugin=dlopen(paths[i],RTLD_NOW|RTLD_LOCAL|RTLD_DEEPBIND);if(!plugin){puts(dlerror());return 5;}ptr_PluginStartup startup=dlsym(plugin,"PluginStartup");if((r=startup(core,NULL,debugcb)))return r;if((r=CoreAttachPlugin(i+1,plugin)))return r;if(i==2){audioSamples=dlsym(plugin,"CaptureAudioSamples");audioRate=dlsym(plugin,"CaptureAudioRate");}if(i==3){buttons=dlsym(plugin,"TestSetButtons");void(*setCapture)(void(*)(void))=dlsym(plugin,"TestSetRenderCapture");if(!setCapture)return 95;setCapture(capture_render);}}
 int speed=0;CoreDoCommand(M64CMD_CORE_STATE_SET,M64CORE_SPEED_LIMITER,&speed);CoreDoCommand(M64CMD_SET_FRAME_CALLBACK,0,onframe);signal(SIGALRM,alarmcb);alarm(15);r=CoreDoCommand(M64CMD_EXECUTE,0,NULL);
 if(video && pclose(video)!=0)return 96;printf("SCENARIO %s completed: %d\n",scenario,r);CoreDoCommand(M64CMD_ROM_CLOSE,0,NULL);CoreShutdown();return r;
}

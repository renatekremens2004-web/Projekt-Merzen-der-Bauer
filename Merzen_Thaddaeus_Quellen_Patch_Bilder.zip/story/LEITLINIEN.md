# Kokiri-Kapitel: verbindlicher Stand

Der vollständige Textumbau erfolgt Gebiet für Gebiet. Dieses Kapitel umfaßt den Spielanfang, das Kokiri-Dorf und den Deku-Baum einschließlich der dortigen Tutorials und ersten Reaktionen auf den Tod des Baumes. Spätere Gebiete folgen getrennt.

- Alte Rechtschreibung vor 1996; Anrede Du/Dir/Dich/Dein.
- Der vom Spieler gewählte Name wird über das originale NAME-Steuerzeichen eingesetzt. Keine Festschreibung auf „Link“.
- Fiktive Hyrule-Satire: Mr. Burns verkörpert Friedrich Merz, der durch Geld und unsoziale Politik die Macht gewinnen will. Seine Herkunft ist noch nicht erklärt. Hyrule bleibt Hyrule.
- Friedrich Merz hat den Deku-Baum persönlich verflucht, nachdem dieser ihm den Kokiri-Smaragd verweigert hat. Der Fluch wird im Dungeon gebrochen; seine Folgen sind für den Baum bereits tödlich.
- Der Deku-Baum setzt seine Hoffnung auf den jungen Helden. Seine gemeinschaftlichen Vorstellungen werden mit wenigen leisen Anspielungen dargestellt, ohne politische Lehrrede.
- Navi ist bissig, ungeduldig und spöttisch. Ihre Hinweise bleiben sachlich brauchbar.
- Die Dorfbewohner behalten unterscheidbare Stimmen. Salia steht dem Helden nahe. Midos spätere Beschuldigung ist sein ungerechter Verdacht, keine Aussage des Erzählers über die tatsächliche Ursache.
- Kenntnisse berücksichtigen: Der Baum und Navi wissen mehr als die Dorfbewohner. Nicht jeder NPC kennt bereits Merz' Plan.
- Native Message-IDs, Folge-IDs, Ereignis-Markierungen, Auswahlreihenfolgen, Item-Übergaben, Preise, Questbedingungen, Controllerbelegung und Altersregeln erhalten.
- Textbreiten mit der PAL-Schrift und acht breiten Namenszeichen prüfen. Auswahlfelder an den nativen Cursor-Zeilen ausrichten. Zeitgesteuerte Textboxen behalten ihre Verzögerungs-/Ausblendwerte.
- Vor der Auslieferung echte Textboxen und funktionale Interaktionen im Emulator prüfen. Dem Nutzer ausgewählte Ingame-Beispiele zeigen; keine komplette Pointenliste im Chat oder auf der Download-Seite.

## Mr. Bean anstelle Impas

- Sämtliche Impa-Modelle verwenden Bean, einschließlich Reiterkopf, Weiser und Abspann-Varianten. Die übrigen Rollen und Questbedingungen bleiben erhalten.
- Andere Figuren beschreiben ihn als mutig, kompetent und vertrauenswürdig. Ihre benötigten Weg- und Questhinweise bleiben verständlich.
- Bean kommentiert das Geschehen knapp auf Englisch. Er darf mehr sagen als bloße Ausrufe; der Witz entsteht aus trockenen Bemerkungen, eigenwilligen Schlüssen und seiner unbeholfenen Art.
- In der Halle der Weisen spricht er ausführlicher. Er hat Zelda tatsächlich gerettet, nimmt Verantwortung an und hilft dem Helden bewußt. Er ist selbst ein Held auf seine komische Art.
- Seine englischen Texte sind eigene Formulierungen. Ungeprüfte Zeilen nicht als echte Mr.-Bean-Zitate kennzeichnen.
- Beim Wiegenlied tanzt er anstelle des Pfeifens. Lieddemonstration, Eingabe, Erwerb und Questfortsetzung bleiben original.
- Normale deutsche Sprachfassungs-Texte außerhalb dieses Rollenwechsels werden weiter Gebiet für Gebiet bearbeitet. Bean-Verweise dürfen bereits mehrere spätere Gebiete betreffen.

## Erweiterung: Stadt, Farm und Methusa

- Alte Rechtschreibung gilt auch für neue Alltagsgespräche. Stadtbewohner haben unterschiedliche Themen und berücksichtigen ihre nativen Erst-/Wiederholungsgespräche.
- Methusa (deutscher Name von Kaepora Gaebora) spricht nachdenklich, abwägend, mit Selbstkorrekturen und konkreter Wegweisung; sie identifiziert sich niemals als Robert Habeck.
- Der Maskenhändler spielt auffällig auf Majoras Maske und ein Waldportal an. Tatsächliche Leihmasken, Shopregeln und Belohnungen bleiben original.
- Navis Deku-Baum-Kommentar beginnt einen Running Gag. Keine Vorwegnahme von Dodongos Höhle oder Jabu-Jabu.
- Thaddäus ist vorläufig nur ein Gerücht aus Zoras Reich. Später soll er die erwachsene Ruto als Weiser des Wassers ersetzen. Junge Ruto bleibt als eigene Figur erhalten. Noch kein Modellaustausch in diesem Kapitel.
- Ein einzelner unbedeutender Bewohner mit Bart (Nachtdialog 7089) bricht den Ton mit einer ausgiebigen Schimpftirade.

## Goronen und Kakariko

- Merz' Kohleabbau ließ den Höhleneingang einstürzen. Dieser narrative Grund ersetzt die frühere Erklärung der Sperre, ohne die Höhlen-/Bombenregeln zu ändern.
- Darunia ist der Goronenführer in Ocarina of Time. Darmani ist hier nicht gemeint.
- Navis Hinweise äußern ihre Meinung zum jeweiligen Geschehen; notwendige Orientierung bleibt enthalten. Der Mund-Rückblick folgt erst nach erhaltenem Goronen-Opal.
- Explizite Nutzerpräferenz: Keine Lesezeiten für Pointen ändern. Statt dessen die Idee kürzen oder in einen vorhandenen normalen Dialog verlegen. Das gilt auch für spätere Kapitel.

## Mario und Luigi

Talon wird durchgängig als Mario, Basil als Luigi angesprochen, auch von anderen Figuren und auf Schildern. Hauptsprache Deutsch in alter Rechtschreibung; Mario hat „Mamma mia!“, „Wahoo!“ und „It's-a me!“, Luigi „Oh, yeah!“, „Luigi-Time!“ und „Let's-a go!“. Keine lautmalerisch verstümmelte deutsche Grammatik. Luigi deutet sämtliche früheren Bosheiten übermäßig positiv um; andere Figuren beschreiben seine aufdringliche Begeisterung. Preise, Auswahlreihenfolge, Rennzustände, Pferdebesitz und Torereignisse bleiben nativ. Zeitgesteuerte Seiten und Ausblendzeiten bleiben erhalten; für einen Witz wird der Text gekürzt, niemals die Szenenzeit verlängert.

## Thaddäus beim Tauchspiel

Nur der Tauchspiel-Leiter ist hier bereits Thaddäus. Er ist ein eingebildeter, genervter Künstler und Klarinettist; Merz ist für ihn ein Geizkragen, der Kunst nicht respektiert. Bei einer Niederlage nennt er den Spieler einen traurigen Clown. Seine privaten deutschen Texte 0136/0138/013B klonen die originalen Steuerzeichen ausschließlich in unbenutzte Textplätze; Schießbuden und andere Händler behalten ihre gemeinsam genutzten Texte. Einstiegspreis 20 Rubine, 50 Sekunden, fünf Rubine vor der Schuppe und zehn danach, native Belohnung und Speicherflags bleiben bestehen. Feste Lesezeiten niemals für einen Gag verlängern. Rutos spätere Ablösung wird erst in einer späteren Revision umgesetzt.

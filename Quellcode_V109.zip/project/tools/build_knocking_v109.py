"""Reapply reviewed V109 audio-only Shadow Temple knocking, idempotently."""
from pathlib import Path
import sys,xml.etree.ElementTree as E
R=Path(__file__).resolve().parent/'knocking_v109';O=Path(sys.argv[1]).resolve()
p=O/'extracted/pal-1.0/assets/audio/samplebanks/SampleBank_0.xml';r=E.parse(p).getroot()
for side in ['L','R']:
 name='KNOCKING_'+side;sample=next((x for x in r.findall('Sample')if x.get('Name')==name),None)
 if sample is None:sample=E.SubElement(r,'Sample',Name=name)
 sample.set('Path',str(R/f'Knocking_32000_{side}.aifc'))
E.indent(r);E.ElementTree(r).write(p,encoding='unicode')
p=O/'extracted/pal-1.0/assets/audio/soundfonts/Soundfont_24.xml';r=E.parse(p).getroot()
if not any(x.get('Name')=='KnockStream'for x in r.find('Envelopes')):
 env=E.SubElement(r.find('Envelopes'),'Envelope',Name='KnockStream',Release='255');E.SubElement(env,'Point',Delay='1',Arg='32700');E.SubElement(env,'Hang')
 for i,side in enumerate(['L','R'],9):
  E.SubElement(r.find('Samples'),'Sample',Name='KNOCKING_'+side);E.SubElement(r.find('Instruments'),'Instrument',ProgramNumber=str(i),Name='KNOCKING_'+side,Envelope='KnockStream',Sample='KNOCKING_'+side,SampleRate='32000',BaseNote='C4',Release='255')
E.indent(r);E.ElementTree(r).write(p,encoding='unicode')
p=O/'extracted/pal-1.0/assets/audio/sequences/seq_91.seq';s=p.read_text()
if '.channel KNOCK_CHAN'not in s:
 s=s.replace('initchan    0b111011111','initchan    0b100000111011111\n    ldchan 14, KNOCK_CHAN',1).replace('.endseq Sequence_91',(R/'channel.seq').read_text()+'\n.endseq Sequence_91');p.write_text(s)
p=O/'src/code/z_play.c';s=p.read_text()
if 'static void Play_UpdateShadowKnocking'not in s:
 s=s.replace('void Play_Update(PlayState* this) {',(R/'scheduler.c.inc').read_text()+'void Play_Update(PlayState* this) {',1).replace('    Play_UpdateGoronBombTempo(this);','    Play_UpdateGoronBombTempo(this);\n    Play_UpdateShadowKnocking(this);',1);p.write_text(s)

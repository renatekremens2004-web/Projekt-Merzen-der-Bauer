from pathlib import Path
import mido,collections,math,json,copy,xml.etree.ElementTree as ET,hashlib,sys
W=Path(__file__).resolve().parent;O=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/workspace/oot-burns-pal')
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/attachments/42ed36a9-054c-43a9-bb55-11c5f9238483/Komm,_süsser_Tod_-_Evangelion_(Complete).mid')
# Log malformed MIDI controller bytes before accepting mido's bounded 0..127 normalization.
import mido.midifiles.midifiles as mf
read=mf.read_message;repairs=[]
def bounded(f,status,peek,delta,clip=False):
 at=f.tell()
 try:return read(f,status,peek,delta,False)
 except (ValueError,OSError) as e:
  if 'data byte' not in str(e):raise
  repairs.append(dict(byte_offset=at,status=hex(status),error=str(e)));f.seek(at);return read(f,status,peek,delta,True)
mf.read_message=bounded
m=mido.MidiFile(p,clip=True);mf.read_message=read
tracks=[];tempos={0:76};source=[]
for ti,t in enumerate(m.tracks):
 now=0;on=collections.defaultdict(list);notes=[];volume=expression=127;pedal=False;held=[]
 def close(a,z,n,v,vol,expr):
  a=round(a*48/m.ticks_per_beat);z=max(a+1,round(z*48/m.ticks_per_beat))
  # Keep the written dynamic contour; controller volume influences attacks rather than exploding the MML.
  velocity=round(v*(.60+.40*vol/127)*(.65+.35*expr/127));notes.append([a,z,n,max(1,min(126,velocity))])
 for x in t:
  now+=x.time
  if x.type=='set_tempo':tempos[round(now*48/m.ticks_per_beat)]=max(1,min(255,round(mido.tempo2bpm(x.tempo))))
  elif x.type=='control_change':
   if x.control==7:volume=x.value
   if x.control==11:expression=x.value
   if x.control==64:
    new=x.value>=64
    if pedal and not new:
     for n,(a,v,vol,expr)in held:close(a,now,n,v,vol,expr)
     held=[]
    pedal=new
  elif x.type=='note_on'and x.velocity:on[x.channel,x.note].append((now,x.velocity,volume,expression))
  elif x.type=='note_off'or(x.type=='note_on'and not x.velocity):
   if on[x.channel,x.note]:
    a,v,vol,expr=on[x.channel,x.note].pop(0)
    if pedal and ti in(4,5):held.append((x.note,(a,v,vol,expr)))
    else:close(a,now,x.note,v,vol,expr)
 for n,(a,v,vol,expr)in held:close(a,now,n,v,vol,expr)
 for (ch,n),left in on.items():
  for a,v,vol,expr in left:close(a,now,n,v,vol,expr)
 tracks.append(sorted(notes));source.append(dict(track=ti,name=t.name,notes=len(notes)))
# A compact private bank assembled exclusively from original OoT samples.
fonts={i:ET.parse(O/f'extracted/pal-1.0/assets/audio/soundfonts/Soundfont_{i}.xml').getroot()for i in(3,9,13)}
font=ET.Element('Soundfont',Name='Soundfont_38',Index='38',Medium='MEDIUM_CART',CachePolicy='CACHE_LOAD_TEMPORARY',SampleBank='$(BUILD_DIR)/assets/audio/samplebanks/SampleBank_0.xml',Indirect='1');envs=ET.SubElement(font,'Envelopes');samples=ET.SubElement(font,'Samples');insts=ET.SubElement(font,'Instruments');sample_set=set()
def add_env(fi,name):
 new=f'F{fi}_{name}'
 if not any(e.get('Name')==new for e in envs):
  e=copy.deepcopy(fonts[fi].find(f'./Envelopes/Envelope[@Name="{name}"]'));e.set('Name',new);envs.append(e)
 return new
def add_samples(el):
 for key,value in el.attrib.items():
  if key.startswith('Sample') and value.startswith('SAMPLE_') and value not in sample_set:ET.SubElement(samples,'Sample',Name=value);sample_set.add(value)
for index,fi,program,name in [(0,13,0,'MALON'),(1,3,15,'PIANO'),(2,3,10,'STRINGS'),(3,13,2,'GUITAR'),(4,3,11,'LOW_STRINGS'),(5,3,14,'CHOIR'),(6,9,6,'ORGAN')]:
 e=copy.deepcopy(fonts[fi].find(f'./Instruments/Instrument[@ProgramNumber="{program}"]'));e.set('Name',name);e.set('ProgramNumber',str(index));e.set('Envelope',add_env(fi,e.get('Envelope')));insts.append(e);add_samples(e)
# Original drum mappings are retained.
drums=copy.deepcopy(fonts[3].find('Drums'))
for e in drums:e.set('Envelope',add_env(3,e.get('Envelope')));add_samples(e)
font.insert(2,drums);ET.indent(font,space='    ');(W/'Soundfont_38.xml').write_text(ET.tostring(font,encoding='unicode')+'\n')
roles=[('Malon — lead melody',[0],0,1,64,119,15,28),('Malon — quiet harmony',[1],0,1,73,63,11,26),('Grand piano — upper',[4],1,3,45,82,10,18),('Grand piano — left hand',[5],1,1,72,83,9,18),('Violins',[16,17],2,2,30,70,7,26),('Violas and cellos',[18,19],4,2,94,66,7,26),('Solo violin',[15],2,1,103,68,8,25),('Upper choir',[2],5,2,84,63,6,32),('Lower choir',[3],5,1,40,59,6,32),('Soft organ',[6],6,1,70,38,5,25),('Warm bass',[10],3,1,64,94,9,12),('Drums',[11],127,2,64,63,7,6)]
channels=[]
for name,indices,program,layers,pan,vol,priority,reverb in roles:
 ns=sorted(set(tuple(n)for ti in indices for n in tracks[ti]));groups=collections.defaultdict(list)
 for a,z,pitch,v in ns:
  if program==127:
   pitch=15 if pitch in(35,36)else 17 if pitch in(37,38,40)else 21 if pitch in(42,44,46)else 35
   z=min(z,a+(5 if pitch==35 else 3));v=min(114,round(v*.85))
  elif program==0:
   # Original melody register; retain Malon's native sample tuning and natural note envelope.
   z=max(a+1,z-1);v=min(117,round(v*1.06))
  elif program==1:z=max(a+1,z-2)
  elif program in(2,4,5,6):v=min(112,round(v*.94))
  groups[a].append([a,z,pitch,v])
 voices=[[]for _ in range(layers)];ends=[0]*layers;trimmed=0
 for a,group in sorted(groups.items()):
  # Keep a high melody and separated chord tones rather than duplicate orchestral unisons.
  bypitch={}
  for n in group:
   if n[2]not in bypitch or(n[3],n[1])>(bypitch[n[2]][3],bypitch[n[2]][1]):bypitch[n[2]]=n
  candidates=sorted(bypitch.values(),key=lambda n:(n[2],n[3]),reverse=True)
  if len(candidates)>layers:
   candidates=([candidates[0],candidates[-1]]if layers==2 else candidates[:layers])
  for n in sorted(candidates,key=lambda n:n[2]):
   free=[i for i,e in enumerate(ends)if e<=a]
   i=min(free,key=lambda i:ends[i])if free else min(range(layers),key=lambda i:ends[i])
   if ends[i]>a:
    old=voices[i][-1]
    if old[0]==a:continue
    old[1]=a;trimmed+=1
   voices[i].append(n);ends[i]=n[1]
 channels.append(dict(name=name,program=program,pan=pan,volume=vol,priority=priority,reverb=reverb,voices=voices,trimmed=trimmed))
# Listening excerpt: starts just before the first vocal and reaches the choir passage.
full_channels=copy.deepcopy(channels);(W/'full-arrangement-notes.json').write_text(json.dumps(full_channels,separators=(',',':')))
lo,hi=64*48,256*48
for c in channels:
 c['voices']=[[[max(a,lo)-lo,min(z,hi)-lo,p,v]for a,z,p,v in voice if a<hi and z>lo]for voice in c['voices']]
 c['voices']=[v for v in c['voices']if v]
channels=[c for c in channels if c['voices']]
tempos={0:76};end=hi-lo+96

lines=['/* Listening demo only. User-supplied Evangelion MIDI; original OoT/Malon samples. */','#include "aseq.h"','#include "Soundfont_38.h"','.startseq Sequence_98','.sequence MAIN','mutebhv 0x20','mutescale 50',f'initchan {2**len(channels)-1}','vol 65',f'tempo {tempos[0]}']
for i in range(len(channels)):lines.append(f'ldchan {i}, CH_{i}')
at=0
for tick,tempo in sorted(tempos.items()):
 if tick==0 or tick>=end:continue
 if tick>at:lines.append(f'delay {tick-at}')
 lines.append(f'tempo {tempo}');at=tick
lines +=[f'delay {end-at}','end']
for i,c in enumerate(channels):
 lines +=[f'.channel CH_{i}','noshort',f'vol {c["volume"]}',f'pan {c["pan"]}',f'notepri 0, {c["priority"]}',f'reverb {c["reverb"]}',f'instr {c["program"]}']
 for j in range(len(c['voices'])):lines.append(f'ldlayer {j}, L_{i}_{j}')
 lines +=[f'delay {end+48}','end']
 for j,voice in enumerate(c['voices']):
  lines.append(f'.layer L_{i}_{j}');at=0;shift=max(0,max(n[2]for n in voice)-84)if c['program']!=127 else 0
  if shift:lines.append(f'transpose {shift}')
  for ni,(a,z,pitch,vel)in enumerate(voice):
   if z<=a:continue
   if a>at:lines.append(f'ldelay {a-at}')
   pitch=pitch if c['program']==127 else pitch-21-shift;assert 0<=pitch<64,(i,pitch)
   nxt=voice[ni+1][0]if ni+1<len(voice)else z;gate=round(256*(nxt-z)/(nxt-a))if nxt>a else 0
   if 0<gate<255 and nxt-z<480:lines.append(f'notedvg {pitch}, {nxt-a}, {vel}, {gate}');at=nxt
   else:lines.append(f'notedv {pitch}, {z-a}, {vel}');at=z
  lines.append('end')
lines.append('.endseq Sequence_98');(W/'seq_98.seq').write_text('\n'.join(lines)+'\n')
ev=sorted([(n[0],1)for c in channels for v in c['voices']for n in v if n[1]>n[0]]+[(n[1],-1)for c in channels for v in c['voices']for n in v if n[1]>n[0]]);n=peak=0
for _,d in ev:n+=d;peak=max(peak,n)
assert peak<=18
seconds=0;at=0;prev=tempos[0]
for tick,tempo in sorted(tempos.items()):seconds+=(tick-at)/48*60/prev;at=tick;prev=tempo
seconds+=(end-at)/48*60/prev
report=dict(source=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),source_seconds=m.length,excerpt_source_beats=[64,256],native_seconds=seconds,native_end_tick=end,malon_sample='SAMPLE_0_118 / Soundfont_13 instrument 0',controller_repairs=repairs,peak_written_polyphony=peak,channels=[{k:v for k,v in c.items()if k!='voices'}|dict(layers=len(c['voices']),notes=sum(map(len,c['voices'])))for c in channels],tempos=tempos,source_tracks=source)
(W/'arrangement.json').write_text(json.dumps(report,indent=2,ensure_ascii=False));(W/'arrangement-notes.json').write_text(json.dumps(channels,separators=(',',':')));print(json.dumps({k:v for k,v in report.items()if k not in('source_tracks','channels','controller_repairs')},indent=2))

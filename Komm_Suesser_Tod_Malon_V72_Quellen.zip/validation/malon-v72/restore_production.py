from pathlib import Path
import time,re,json,hashlib,subprocess
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
while True:
 p=W/'capture-runtime.log'
 if p.exists()and re.search(r'MUSIC_PROGRESS[^\n]*voice=[1-9]\d*',p.read_text()):break
 time.sleep(.5)
report={}
for rel,sha in json.loads((W/'original-audio-sha256.json').read_text()).items():
 p=O/rel;p.write_bytes((W/'original-audio'/rel).read_bytes());report[rel]=hashlib.sha256(p.read_bytes()).hexdigest();assert report[rel]==sha
with(W/'restore-build.log').open('w')as log:
 subprocess.run(['make','-j4','VERSION=pal-1.0','COMPARE=0','PYTHON=/workspace/toolchain/venv/bin/python3','build/pal-1.0/segments/Audioseq.plf','build/pal-1.0/segments/Audiobank.plf','build/pal-1.0/segments/code.plf'],cwd=O,stdout=log,stderr=subprocess.STDOUT,check=True)
for n in ['code','ovl_En_Ko','ovl_Demo_Ec','ovl_En_Go2','spot00_room_0','spot20_room_0','spot18_room_1']:
 for ext in ['.plf','.map']:
  p=O/'build/pal-1.0/segments'/(n+ext)
  if p.exists():p.unlink()
report['production_sources_restored']=True;report['compiled_audio_restored']=True;(W/'production-restored.json').write_text(json.dumps(report,indent=2));print('PRODUCTION_AUDIO_RESTORED',flush=True)

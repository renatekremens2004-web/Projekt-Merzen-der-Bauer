"""Add six rigid limb groups to the supplied adult Wallace without changing any geometry."""
from pathlib import Path
import json
R=Path(__file__).resolve().parent

def rig():
 p=R/'wallace_adult_source.json';m=json.loads(p.read_text())
 if len(m['bones'])==10:
  assert m['leg_rig']['version']==1;return m
 assert len(m['bones'])==4 and m['height_game_units']==90
 for name,x,y in [('left_thigh',500,4200),('right_thigh',-500,4200),('left_shin',500,2400),('right_shin',-500,2400),('left_foot',500,600),('right_foot',-500,600)]:m['bones'].append(dict(name=name,parent=-1,position=[x,y,-100]))
 counts={}
 for v in m['vertices']:
  if v['bone']!=0:continue
  x,y,z=v['position']
  if y<4200:
   side=0 if x>=0 else 1
   v['bone']=(8 if y<900 else 6 if y<2400 else 4)+side
  counts[v['bone']]=counts.get(v['bone'],0)+1
 m['pivots']=[b['position']for b in m['bones']]
 m['leg_rig']=dict(version=1,geometry_positions_normals_uvs_triangles_unchanged=True,additional_matrix_bytes=384,hip_y=4200,knee_y=2400,ankle_y=600,walk_cycle_native_frames=16,vertices_by_body_group=counts)
 p.write_text(json.dumps(m,separators=(',',':'))+'\n');return m
if __name__=='__main__':print('Leg rig:',rig()['leg_rig'])

import bpy,json
from pathlib import Path
bpy.ops.wm.open_mainfile(filepath='/workspace/yellow-guy/punk-import.blend',load_ui=False)
o=bpy.data.objects['Cube.008'];m=o.data;m.calc_loop_triangles()
verts=[o.matrix_world@v.co for v in m.vertices];edges={i:set()for i in range(len(verts))}
for e in m.edges:a,b=e.vertices;edges[a].add(b);edges[b].add(a)
seen=set()
for i in edges:
 if i in seen:continue
 stack=[i];group=[];seen.add(i)
 while stack:
  q=stack.pop();group.append(q)
  for j in edges[q]-seen:seen.add(j);stack.append(j)
 ps=[verts[j]for j in group];print('COMP',len(ps),[[round(min(p[k]for p in ps),4),round(max(p[k]for p in ps),4)]for k in range(3)])
for x in [-.9,-.4,0,.5,1.,2.4,3.,3.5,4.]:
 ps=[p for p in verts if abs(p.x-x)<.12]
 if ps:print('SLICE',x,len(ps),[[round(min(p[k]for p in ps),4),round(max(p[k]for p in ps),4)]for k in [1,2]])
# Save a high-resolution reference of the supplied arm mesh with the whole character.
from mathutils import Vector
bpy.data.objects.remove(bpy.data.objects['Plane.001'],do_unlink=True)
im=bpy.data.images.load('/workspace/yellow-guy/input/punk/textures/yp.png')
mat=bpy.data.materials.new('supplied texture');mat.use_nodes=True;nt=mat.node_tree;n=nt.nodes.new('ShaderNodeTexImage');n.image=im;nt.links.new(n.outputs['Color'],nt.nodes.get('Principled BSDF').inputs['Base Color'])
for ob in bpy.context.scene.objects:
 if ob.type=='MESH':
  for j in range(len(ob.data.materials)):ob.data.materials[j]=mat
sc=bpy.context.scene;sc.render.engine='CYCLES';sc.cycles.samples=8;sc.cycles.use_denoising=False;sc.render.resolution_x=640;sc.render.resolution_y=640;sc.render.resolution_percentage=100
sc.world=bpy.data.worlds.new('studio');sc.world.color=(.25,.25,.25)
bpy.ops.object.camera_add(location=(1.65,-14,-1.7));cam=bpy.context.object;cam.rotation_euler=(Vector((1.65,0,-1.7))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO';cam.data.ortho_scale=7.;sc.camera=cam
bpy.ops.object.light_add(type='AREA',location=(1,-8,5));bpy.context.object.data.energy=1200;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=8
sc.render.filepath='/workspace/yellow-guy-arms/source.png';bpy.ops.render.render(write_still=True)

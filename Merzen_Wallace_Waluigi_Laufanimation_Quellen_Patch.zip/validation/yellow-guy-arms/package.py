from pathlib import Path
import json,hashlib,re,shutil,zipfile
W=Path('/workspace/yellow-guy-arms');T=Path('/workspace/yellow-guy');R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts');P=R/'previews/yellow-guy-arms';V=R/'validation/yellow-guy-arms'
P.mkdir(parents=True,exist_ok=True);V.mkdir(parents=True,exist_ok=True)
sha=hashlib.sha256((O/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes()).hexdigest();report=json.loads((O/'build/pal-1.0/yellow-guy-verification.json').read_text());assert report['rom_sha256']==sha and report['outfit_revision']['changed_german_messages']==[];assert json.loads((W/'patch-verification.json').read_text())['target_sha256']==sha
logs={};manifest=[]
for topic in ['punk','punk-wide']:
 case='yellow-'+topic+'-arms-release-direct-clip-on';meta=json.loads((T/(case+'.json')).read_text());log=(T/(case+'.log')).read_text();assert meta['rom_sha256']==sha and 'RAM=4194304'in log and 'completed: 0'in log,topic
 assert not any(x in log for x in ['OBJECT_BANK_OVERFLOW','CAST_COLOAD_ERROR','UNKNOWN GBI COMMAND','Using Vertex outside buffer']),topic
 if topic!='punk-wide':assert log.count('id='+('608f'if topic=='normal'else'6073'))>=5
 logs[topic]=log
 for ext in ['.json','.log']:shutil.copyfile(T/(case+ext),V/(case+ext))
def photo(topic,index,dest):
 case='yellow-'+topic+'-arms-release-direct-clip-on';src=Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{index:03d}.png';shutil.copyfile(src,P/dest)
 shots=re.findall(r'PHOTO f=(\d+) kind=(\S+)',logs[topic]);manifest.append(dict(file=dest,case=case,frame=int(shots[index][0]),rom_sha256=sha,unedited_emulator_image=True))
photo('punk-wide',0,'Punk_Outfit_Ganzkoerper.png');photo('punk',1,'Punk_Outfit_Gespraech.png');photo('punk',4,'Punk_System.png')
(P/'Aufnahmen.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['package.py','check_patch.js','patch-verification.json','verification.log','export.log','inspect.py','inspect.log']:shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/yellow-guy-verification.json',V/'yellow-guy-verification.json')
remaining=min(map(int,re.findall(r'OBJECT_BANK .*remaining=(\d+)',logs['punk'])))
doc=f'''# Punk: sichtbare Arme und korrekte Jacke, v3

Kumulativer Gesamtpatch auf unveränderte Europa/PAL-1.0-ROM. Original-MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{sha}`. Alle bisherigen Änderungen enthalten; weiterhin 1.013 bearbeitete deutsche Nachrichten.

## Ursache und Korrektur

Die Arme waren vorhanden, aber kaum sichtbar. Die Vorlage hat dünne Arme. Im Export kamen zwei Fehler hinzu: Cube.008 enthält sowohl die Jacke als auch beide Arme; die pauschale Armzuordnung drehte auch den Oberkörper mit. Außerdem verschob die Polygonreduktion UV-Koordinaten zwischen getrennten Farbinseln. Gelbe Haut landete dadurch in dunklen Bereichen des Atlas.

Nur echte Armflächen werden jetzt den Armbewegungen zugeordnet. Die Jacke bleibt am Oberkörper. Schulterpunkte liegen an den tatsächlichen Ansätzen; die Ruhehaltung senkt die Arme um 45 statt 50 Grad ab. Gelbe Unterarme und Hände bekommen dieselbe stabile Hautfarbe wie der Kopf. Blau und Grün der Jacke werden vor der UV-Vereinfachung gesichert. Native Beleuchtung, Nebel und Tiefentest bleiben erhalten. Keine selbstleuchtenden Arme, kein breites Strecken auf ein fremdes Skelett und keine Vergrößerung der Figur.

Die Arme werden vor der Vereinfachung vom Oberkörper getrennt und erhalten mehr vom vorhandenen Geometriebudget; kleine Zierdetails weniger. Insgesamt 1.464 statt 1.463 Dreiecke, also praktisch gleiches Gesamtbudget. Kopf und Gesicht bleiben erhalten. Gleiche Höhe von 74 Spieleinheiten, weiterhin vier eigene starre Bewegungsteile. Keine neuen Akteure, Kollisionskörper oder Objekt-Slots. Raum-Puffer vor Ganons Schloß jetzt {report['room_buffer_before_after']['ganon_tou'][1]} Bytes statt 134.816 in v2. In der gemessenen nativen Objektbank bleiben {remaining} Bytes frei; diese Bank ist getrennt vom Raum-Puffer.

## Prüfung

Zwei erfolgreiche Emulatorproben auf genau der oben genannten ROM mit Mupen64Plus/GLideN64 und echten 4 MiB: normales Gespräch komplett lesen, schließen und wiederholen sowie eine Ganzkörperansicht ohne Textkasten. Native Gesprächs- und Spielkamera. Für die zweite Ansicht wird nur Links Position im lokalen Spielstand vorbereitet; der NPC bleibt am tatsächlichen Spielort. Vor Ganons Schloß gilt die native feste Dämmerungsbeleuchtung. Keine beobachteten Abstürze, Objektbanküberläufe oder fehlerhaften Grafikbefehle.

Alle 1.509 komprimierten Segmente, CIC-6105-Prüfsumme und 1.013 Textpuffer geprüft. 255 native Raum-Assets und 2.955 Kernfunktionen erhalten. Gegen die zuletzt veröffentlichte v2-ROM mit SHA256 `afcbd5fde6a4ef3f69fc58eb7c4f48dd49f26899ea6e8a0cb15e3011aeb87556` geprüft: sämtliche Nachrichten in allen Sprachen gleich. Normales Yellow-Guy-Raumsegment und Wario-Raumsegment bytegenau identisch. Alle anderen Segmente außerhalb des Punk-Raums und der notwendigen Tabellen erhalten bzw. ausschließlich mit echten MIPS-Linker-Relokationen verändert. Beim Elf-Msg2-Overlay sind zusätzlich genau die aus den neuen Modelldaten abgeleiteten Schulter-Pivots geändert; übriger Inhalt auf Bytegleichheit bzw. echte Relokationen geprüft.

Die entfernte Selbstvorstellung bleibt entfernt. Wario bleibt ausschließlich im jungen Kakariko. Die zehn Alters-/Sprachproben aus v1 und die früheren v2-Proben bleiben historische Nachweise; sie wurden nicht erneut ausgeführt. Vollständiger Durchlauf und echte N64-Hardware stehen weiterhin aus.

RomPatcher.js mit aktiver Quellvalidierung erzeugt aus Vanilla und BPS bytegenau die geprüfte ROM. Veröffentlicht werden ausschließlich Patch, Quellen, Protokolle und unveränderte echte Emulatorbilder. Keine ROMs, Spielstände, Emulatorzustände oder ausführbaren Programme.
'''

(R/'TESTING_YELLOW_GUY_ARME.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Yellow_Guy_Arme_v3.bps';shutil.copyfile(patch,R/'patches'/patch.name)
instruction=A/'Anleitung_Yellow_Guy_Arme_v3.txt';instruction.write_text('Punk: Arme und Jacke korrigiert — Gesamtpatch\n\nAuf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden, NICHT auf eine bereits gepatchte ROM. Original-MD5 e040de91a74b61e3201db0e2323f768a. Patcher: https://www.marcrobledo.com/RomPatcher.js/\n\nAlle bisherigen Änderungen enthalten. Punk-Arme sichtbar, Schulterzuordnung und blaue Jacke korrigiert. Keine Selbstvorstellung als Yellow Guy. Wario weiterhin ausschließlich im jungen Kakariko.\n\nZwei gezielte Emulatorproben mit 4 MiB bestanden; kompletter Durchlauf weiterhin ausstehend.\n')
heading='# Punk: Arme und Jacke korrigiert';p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Neuer Gesamtpatch](patches/'+patch.name+') · [Prüfung](TESTING_YELLOW_GUY_ARME.md) · [Echte Bilder](previews/yellow-guy-arms/)\n\nArme und Jacke korrekt zugeordnet, gelbe Unterarme erhalten. Selbstvorstellung bleibt entfernt. Alle bisherigen Änderungen enthalten.\n\n'+p.read_text())
images=A/'Yellow_Guy_Arme_v3_Bilder.zip'
with zipfile.ZipFile(images,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.iterdir()):z.write(p,p.name)
archive=A/'Merzen_Yellow_Guy_Arme_v3_Quellen_Patch_Bilder.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl','.mp4'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R)
  if not p.is_file()or any(x in exclude for x in rel.parts)or p.suffix.lower()not in suffixes:continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='yellow-guy-arms':continue
  with p.open('rb')as f:assert f.read(4)not in [bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and not any(Path(x).suffix.lower()in{'.rom','.z64','.n64','.v64','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st'}for x in z.namelist())
files=[patch,images,archive,instruction];sums=A/'SHA256SUMS_Yellow_Guy_Arme_v3.txt';sums.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in files))
for p in files+[sums]:shutil.copyfile(p,D/p.name)
G=D/'Yellow_Guy_Arme_v3_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
shutil.copyfile(R/'planning/YELLOW_GUY_WARIO_DIALOGE.md',D/'Yellow_Guy_Wario_Dialoge.md')
heading='# Merzen der Bauer: Punk-Arme v3';p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Aktueller BPS-Gesamtpatch]('+patch.name+'?raw=true) · [Neue Ingame-Bilder]('+images.name+'?raw=true) · [Quellen und Prüfungen]('+archive.name+'?raw=true)\n\nArme und blaue Jacke korrigiert; Selbstvorstellung bleibt entfernt. Alle bisherigen Änderungen enthalten. Auf unveränderte Europa/PAL-1.0-ROM anwenden. Zwei gezielte Szenenproben mit 4 MiB bestanden.\n\n![Punk-Outfit](Yellow_Guy_Arme_v3_Beispielbilder/Punk_Outfit_Ganzkoerper.png)\n\n'+p.read_text())
print('Packaged arms v3:',sha,'2 runtime cases, 3 genuine screenshots;',archive.stat().st_size,'source bytes')

#!/usr/bin/env python3
"""Create the requested DEBUG editions from a user's unmodified PAL 1.0 ROM."""
import argparse
import hashlib
import json
from pathlib import Path
from struct import iter_unpack, pack, pack_into, unpack_from
import sys
from zlib import crc32

from mips import menu_program
from profiles import SAGES, forced_age, route, snapshot
from romio import PAL_MD5, Rom, align, apply_bps, canonical_rom, cic6105, repair_checksum

HERE = Path(__file__).resolve().parent
BASE_PATCH = 'Mr_Burns_Mr_Bean_DE_PAL10_DEBUG_SONDERVERSION_V112.bps'
SELECT_SLOT = 31
CODE_SLOT = 28
STAFF_SLOT = 24
SELECT_START = 0x808009C0
STAFF_CONTROL_ARGS = {
    0x05:1, 0x06:1, 0x07:2, 0x0C:1, 0x0E:1, 0x11:2, 0x12:2,
    0x13:1, 0x14:1, 0x15:3, 0x1E:1,
}


def find_unique(data, pattern, description, aligned=False):
    found = []
    at = data.find(pattern)
    while at >= 0:
        if not aligned or at % 4 == 0:
            found.append(at)
        at = data.find(pattern, at+1)
    if len(found) != 1:
        raise ValueError(f'{description} wurde nicht eindeutig gefunden.')
    return found[0]


def sign_extend(value):
    value &= 0xFFFF
    return value-0x10000 if value >= 0x8000 else value


def locate_save_address(body):
    """Identify gSaveContext in the native loader by its absolute MIPS references."""
    words = [word for (word,) in iter_unpack('>I', body)]
    scores = {}
    field_weights = {0:3, 4:3, 0x1354:15, 0x1364:5, 0x13E0:4, 0x13E1:4,
                     0x13E2:3, 0x13F4:4, 0x13F6:4, 0x1412:3}
    candidates = set()
    accesses = []
    for i, word in enumerate(words):
        op, rs, rt = word>>26, (word>>21)&31, (word>>16)&31
        if op != 15 or rs != 0 or word&0xFFFF not in (0x8011,0x8012):
            continue
        base = (word&0xFFFF)<<16
        for next_word in words[i+1:i+16]:
            no, ns, nt = next_word>>26, (next_word>>21)&31, (next_word>>16)&31
            if ns == rt:
                address = (base+sign_extend(next_word))&0xFFFFFFFF
                if no in (9,13) and nt:
                    if no == 13:
                        address = base | (next_word&0xFFFF)
                    if 0x8011B000 <= address < 0x8011D000:
                        candidates.add(address)
                if no in (32,33,35,36,37,40,41,43):
                    accesses.append(address)
                if no in (9,13,32,33,35,36,37) and nt == rt:
                    break
    for address in accesses:
        for field, weight in field_weights.items():
            base = address-field
            if 0x8011B000 <= base < 0x8011D000 and base%16 == 0:
                scores[base] = scores.get(base, 0)+weight
    for candidate in candidates:
        scores[candidate] = scores.get(candidate, 0)+10
    best = sorted(scores, key=scores.get, reverse=True)
    if not best or scores[best[0]] < 10 or len(best)>1 and scores[best[0]] == scores[best[1]]:
        raise ValueError('Die Speicheradresse von V112 konnte nicht sicher ermittelt werden.')
    return best[0]


def parse_overlay(overlay, mapped_end):
    hdr_len = unpack_from('>I',overlay,len(overlay)-4)[0]
    header_at = len(overlay)-hdr_len
    text, data, rodata, bss, count = unpack_from('>5I',overlay,header_at)
    if text+data+rodata != header_at or hdr_len < 24+count*4:
        raise ValueError('Die Struktur der Szenenauswahl entspricht nicht DEBUG-V112.')
    relocations = list(unpack_from('>'+'I'*count,overlay,header_at+20))
    if mapped_end < SELECT_START+len(overlay)+bss:
        raise ValueError('Der Adressbereich der Szenenauswahl ist zu klein.')
    return text, data, rodata, relocations


def expand_select(overlay, init, mapped_end, no_text):
    text, data, rodata, relocations = parse_overlay(overlay,mapped_end)
    credit_label = find_unique(overlay,b'Credits starten\0','Credits-Menüeintrag')
    entries_at = find_unique(overlay[text:text+data],pack('>I',SELECT_START+credit_label),
                             'Menüeinträge',aligned=True)+text
    credits = unpack_from('>3I',overlay,entries_at)
    native_load = unpack_from('>I',overlay,entries_at+16)[0]
    if not SELECT_START <= native_load < SELECT_START+text or native_load == credits[1]:
        raise ValueError('Unerwarteter Ladehelfer im DEBUG-Menü.')
    entries = []
    for at in range(entries_at,text+data-11,12):
        label, func, entrance = unpack_from('>3I',overlay,at)
        if not SELECT_START+text <= label < SELECT_START+text+data+rodata or not SELECT_START <= func < SELECT_START+text:
            break
        entries.append((label,func,entrance))
    if not 110 <= len(entries) <= 130:
        raise ValueError(f'Unerwartete Zahl der Ortsziele in DEBUG-V112 ({len(entries)}).')
    load_offset = native_load-SELECT_START
    subsequent_calls = [func-SELECT_START for _,func,_ in entries if func > native_load]
    end_load = min([x for x in subsequent_calls]+[load_offset+0x500,text])
    save_address = locate_save_address(overlay[load_offset:end_load])
    scenes = {int(k):v for k,v in json.loads((HERE/'entrances.json').read_text()).items()}

    # Preserve old BSS addresses in loaded, zero-initialized space. Existing
    # relocation records keep their text/data/rodata bases.
    body = bytearray(overlay[:text+data+rodata])
    body.extend(bytes(align(mapped_end-SELECT_START,16)-len(body)))
    # The special selector always loads profiles. Advertise its actual controls.
    for before,after in [(b'C-Links: Alle Items%s\0',b'Fortschritt: Auto\0'),
                         (b'C-Rechts: %s\0',b'Herzen/Items\0')]:
        if before in body:
            offset = body.find(before)
            body[offset:offset+len(before)] = after.ljust(len(before),b'\0')

    p = menu_program(len(body), init-SELECT_START, load_offset, save_address, len(entries)+6)
    new_load = SELECT_START+p.labels['load']
    new_init = SELECT_START+p.labels['init']
    code_start = len(body)
    body.extend(bytes(len(p.words)*4))

    def put_label(value):
        address = SELECT_START+len(body)
        body.extend(value.encode('ascii')+b'\0')
        return address

    if no_text:
        label,func,entrance = entries[0]
        entries[0] = (put_label('Credits ohne Text'),func,entrance)
    specs = [(label,new_load if func == native_load else func,entrance,None)
             for label,func,entrance in entries]
    for label,chapter,sage in SAGES:
        specs.append((put_label('Weise: '+label),new_load,0x6B,(chapter,sage)))
    body.extend(bytes(align(len(body),4)-len(body)))
    offsets = {'entries':len(body)}
    for label,func,entrance,sage in specs:
        for value in (label,func):
            local = len(body)-text-data
            relocations.append(0xC2000000|local)
            body.extend(pack('>I',value))
        body.extend(pack('>I',entrance))

    snapshots = bytearray()
    pool = {}
    def allocate(profile):
        if profile not in pool:
            pool[profile] = len(snapshots)
            snapshots.extend(profile)
        return pool[profile]

    offsets['route_table'] = len(body)
    for label,func,entrance,sage in specs:
        if sage is None:
            scene = scenes.get(entrance,'HYRULE_FIELD')
            adult = snapshot(route(scene,False),False)
            child = snapshot(route(scene,True),True)
            code = 0
            age = forced_age(scene)
        else:
            chapter,which = sage
            adult = child = snapshot(chapter,False,which)
            code = which+1
            age = 1
        body.extend(pack('>HHBB2x',allocate(adult),allocate(child),code,age))
    offsets['snapshots'] = len(body)
    body.extend(snapshots)
    body[code_start:code_start+len(p.words)*4] = p.build(offsets)
    body.extend(bytes(align(len(body),16)-len(body)))
    new_rodata = len(body)-text-data
    header = pack('>5I',text,data,new_rodata,0,len(relocations))
    reloc_data = b''.join(pack('>I',word) for word in relocations)
    tail_size = align(len(header)+len(reloc_data)+4,16)
    body.extend(header+reloc_data+bytes(tail_size-len(header)-len(reloc_data)-4)+pack('>I',tail_size))
    return body,new_init,dict(entries=len(specs),snapshot_count=len(pool),save_address=hex(save_address))


def blank_staff_text(data):
    """Replace printable glyphs and retain all original textbox control bytes."""
    out = bytearray(data)
    offset = replaced = 0
    while offset < len(out):
        value = out[offset]
        if value >= 0x20:
            if value != 0x20:
                out[offset] = 0x20
                replaced += 1
            offset += 1
        else:
            offset += 1+STAFF_CONTROL_ARGS.get(value,0)
    if not replaced or data.count(2) != out.count(2):
        raise ValueError('Die Credits-Texte konnten nicht sicher ausgeblendet werden.')
    return out,replaced


def build(debug_base, no_text):
    rom = Rom(debug_base)
    overlay = rom.read(SELECT_SLOT)
    code = bytearray(rom.read(CODE_SLOT))
    vs,ve,_,_ = rom.entries[SELECT_SLOT]
    table = find_unique(code,pack('>III',vs,ve,SELECT_START),'GameState-Tabelle',aligned=True)-4
    mapped_end,_,native_init = unpack_from('>III',code,table+0x10)
    if not SELECT_START < native_init < mapped_end:
        raise ValueError('Der Aufruf der Szenenauswahl konnte nicht erkannt werden.')
    new_overlay,new_init,summary = expand_select(overlay,native_init,mapped_end,no_text)
    new_start,new_end = rom.replace(SELECT_SLOT,new_overlay,grow=True)
    pack_into('>II',code,table+4,new_start,new_end)
    pack_into('>I',code,table+0x10,SELECT_START+len(new_overlay))
    pack_into('>I',code,table+0x18,new_init)
    rom.replace(CODE_SLOT,code)
    if no_text:
        silent,n = blank_staff_text(rom.read(STAFF_SLOT))
        rom.replace(STAFF_SLOT,silent,reuse=True)
        summary['hidden_credits_glyphs'] = n
    repair_checksum(rom.data)
    assert unpack_from('>II',rom.data,0x10) == cic6105(rom.data)
    summary['crc32'] = f'{crc32(rom.data):08x}'
    return rom.data,summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original',nargs='?',type=Path,help='Unveränderte deutsche PAL-1.0-ROM')
    parser.add_argument('--patch',type=Path,default=HERE/BASE_PATCH,help='Mitgelieferter DEBUG-V112-Basispatch')
    parser.add_argument('--ausgabe',type=Path,default=HERE/'Ausgabe')
    parser.add_argument('--nur',choices=['normal','ohne-text'])
    args = parser.parse_args(argv)
    if args.original is None:
        from tkinter import Tk, filedialog
        window = Tk()
        window.withdraw()
        filename = filedialog.askopenfilename(title='Unveränderte PAL-1.0-ROM auswählen',
                                              filetypes=[('N64 ROM','*.z64 *.n64 *.v64'),('Alle Dateien','*')])
        window.destroy()
        if not filename:
            return
        args.original=Path(filename)
    clean = canonical_rom(args.original.read_bytes())
    if hashlib.md5(clean).hexdigest() != PAL_MD5:
        raise ValueError('Diese Ausgabe braucht die unveränderte deutsche PAL-1.0-ROM.')
    print('DEBUG-V112 wird aus dem mitgelieferten Patch geladen.',flush=True)
    base = apply_bps(clean,args.patch.read_bytes())
    args.ausgabe.mkdir(parents=True,exist_ok=True)
    for silent in (False,True):
        mode = 'ohne-text' if silent else 'normal'
        if args.nur and args.nur != mode:
            continue
        output,summary = build(base,silent)
        name = 'Merzen_DEBUG_Fortschritt'+('_Credits_ohne_Text' if silent else '')+'.z64'
        dest = args.ausgabe/name
        if dest.exists():
            raise ValueError(f'{dest} existiert bereits. Wähle einen anderen Ausgabeordner.')
        part = dest.with_suffix('.part')
        part.write_bytes(output)
        part.rename(dest)
        print(dest,flush=True)
        print(json.dumps(summary,ensure_ascii=False),flush=True)


if __name__ == '__main__':
    try:
        main()
    except (ValueError,OSError) as error:
        sys.exit(f'Fehler: {error}')

"""Build the position-independent N64 map-select routines."""
from struct import pack

ZERO, V0, A0, A1, A2, T0, T1, T2, T3, T4, T5, S0, S1, S2, S3, S4, SP, RA = (
    0, 2, 4, 5, 6, 8, 9, 10, 11, 12, 13, 16, 17, 18, 19, 20, 29, 31
)


class Program:
    def __init__(self, start):
        self.start = start
        self.words = []
        self.labels = {}
        self.fixups = []

    @property
    def pc(self):
        return self.start + len(self.words)*4

    def label(self, name):
        assert name not in self.labels
        self.labels[name] = self.pc

    def emit(self, value):
        self.words.append(value)

    def imm(self, op, dest, source, value):
        self.emit((op << 26) | (source << 21) | (dest << 16) | (value & 0xFFFF))

    def addi(self, dest, source, offset):
        self.imm(9, dest, source, offset)

    def lui(self, dest, value):
        self.imm(15, dest, ZERO, value)

    def constant(self, dest, value):
        self.lui(dest, value >> 16)
        self.imm(13, dest, dest, value & 0xFFFF)

    def move(self, dest, source):
        self.addi(dest, source, 0)

    def addu(self, dest, left, right):
        self.emit(left << 21 | right << 16 | dest << 11 | 0x21)

    def shift(self, dest, source, bits):
        self.emit(source << 16 | dest << 11 | bits << 6)

    def lw(self, dest, source, offset):
        self.imm(35, dest, source, offset)

    def sw(self, dest, source, offset):
        self.imm(43, dest, source, offset)

    def lbu(self, dest, source, offset):
        self.imm(36, dest, source, offset)

    def lhu(self, dest, source, offset):
        self.imm(37, dest, source, offset)

    def sb(self, dest, source, offset):
        self.imm(40, dest, source, offset)

    def sh(self, dest, source, offset):
        self.imm(41, dest, source, offset)

    def branch(self, op, first, second, target, delay=0):
        self.fixups.append((len(self.words), target, self.pc+4, True))
        self.imm(op, second, first, 0)
        self.emit(delay)

    def bal(self, target, delay=0):
        self.branch(1, ZERO, 17, target, delay)

    def relative_address(self, dest, label):
        self.bal('anchor_'+label)
        self.label('anchor_'+label)
        self.fixups.append((len(self.words), label, self.pc, False))
        self.addi(dest, RA, 0)

    def push(self, registers):
        self.addi(SP, SP, -48)
        for i, register in enumerate(registers):
            self.sw(register, SP, 44-4*i)

    def pop(self, registers):
        for i, register in enumerate(registers):
            self.lw(register, SP, 44-4*i)
        self.emit(RA << 21 | 8)
        self.addi(SP, SP, 48)

    def build(self, labels):
        labels = {**self.labels, **labels}
        for index, target, base, branch in self.fixups:
            delta = (labels[target] if isinstance(target, str) else target)-base
            if branch:
                assert delta % 4 == 0
                delta //= 4
            assert -0x8000 <= delta < 0x8000, (target, delta)
            self.words[index] |= delta & 0xFFFF
        return pack('>'+'I'*len(self.words), *self.words)


def menu_program(start, native_init, native_load, save_address, count):
    from profiles import SNAPSHOT_SIZE
    p = Program(start)
    p.label('init')
    p.push((RA, S0))
    p.bal(native_init, (9 << 26) | (A0 << 21) | (S0 << 16))  # move s0,a0
    p.relative_address(T0, 'entries')
    p.sw(T0, S0, 0x1D4)
    p.addi(T0, ZERO, count)
    p.sw(T0, S0, 0x1D0)
    p.pop((RA, S0))

    p.label('load')
    registers = (RA, S0, S1, S2, S3, S4)
    p.push(registers)
    p.move(S0, A0)
    p.move(S1, A1)
    p.constant(S3, save_address)
    p.relative_address(S2, 'route_table')
    p.lw(T0, S0, 0x1D8)
    p.shift(T0, T0, 3)
    p.addu(S2, S2, T0)
    p.lbu(S4, S2, 4)  # 0 for gameplay, otherwise chamber cutscene number + 1.
    p.lbu(T2, S2, 5)  # 0: selected age, 1: adult, 2: child
    p.branch(4, T2, ZERO, 'native_load')
    p.addi(T2, T2, -1)
    p.sw(T2, S3, 4)
    p.label('native_load')
    p.move(A0, S0)
    p.bal(native_load, (9 << 26) | (S1 << 21) | (A1 << 16))  # move a1,s1

    # Native load has finished selecting the age and initializing the session.
    p.lw(T0, S3, 4)
    p.shift(T0, T0, 1)
    p.addu(T0, S2, T0)
    p.lhu(T0, T0, 0)
    p.relative_address(T1, 'snapshots')
    p.addu(S2, T0, T1)

    # Fresh scene and story flags. Ages and language remain those selected.
    p.addi(T0, S3, 0xD4)
    p.addi(T1, S3, 0x1354)
    p.label('erase_flags')
    p.sw(ZERO, T0, 0)
    p.addi(T0, T0, 4)
    p.branch(5, T0, T1, 'erase_flags')

    p.addi(T0, S3, 0x2E)
    p.addi(T1, S3, 0xD4)
    p.label('copy_inventory')
    p.lbu(T2, S2, 0)
    p.addi(S2, S2, 1)
    p.sb(T2, T0, 0)
    p.addi(T0, T0, 1)
    p.branch(5, T0, T1, 'copy_inventory')

    p.addi(T0, S3, 0xED4)
    p.addi(T1, S3, 0xEF0)
    p.label('copy_events')
    p.lbu(T2, S2, 0)
    p.addi(S2, S2, 1)
    p.sb(T2, T0, 0)
    p.addi(T0, T0, 1)
    p.branch(5, T0, T1, 'copy_events')
    p.lhu(T2, S2, 0)
    p.sh(T2, S3, 0xF30)
    p.addi(T2, ZERO, 0xFF)
    p.sw(T2, S3, 0x1354)  # temporary test session, no SRAM slot
    p.lbu(T0, S3, 0x33)
    p.sw(ZERO, S3, 0x13F0)
    p.sh(T0, S3, 0x13F4)
    p.sh(T0, S3, 0x13F6)
    p.sw(ZERO, S3, 0x13F8)
    p.sh(ZERO, S3, 0x13FC)
    p.sh(ZERO, S3, 0x13FE)
    p.sh(ZERO, S3, 0x1400)
    p.addi(T0, ZERO, -17)
    p.sh(T0, S3, 0x1412)  # NEXT_CS_INDEX_NONE
    p.sb(ZERO, S3, 0x1414)
    p.branch(4, S4, ZERO, 'done')
    p.addi(T0, S4, -1)
    p.sb(T0, S3, 0x1415)
    p.addi(T1, ZERO, 5)
    p.lui(T2, 0)
    p.imm(13, T2, T2, 0x8000) # Normal layer; resident sage actor starts the cutscene.
    p.branch(5, T0, T1, 'chamber_stage')
    p.imm(13, T2, ZERO, 0xFFF0) # Habeck uses the light cutscene header.
    p.label('chamber_stage')
    p.sw(T2, S3, 8)
    p.label('done')
    p.pop(registers)
    return p

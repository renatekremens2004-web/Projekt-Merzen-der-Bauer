@echo off
setlocal
pushd "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    py -3 bauen.py %*
    goto fertig
)
where python >nul 2>nul
if not errorlevel 1 (
    python bauen.py %*
    goto fertig
)
echo Python 3 wird zum Erstellen der beiden ROM-Dateien benoetigt.
echo https://www.python.org/downloads/
:fertig
popd
pause

"""Progress snapshots for the special map selector, in big-endian save format."""
from enum import IntEnum
from struct import pack_into


class Chapter(IntEnum):
    KOKIRI = 0
    DEKU = 1
    DEKU_BOSS = 2
    OUTSIDE = 3
    ZELDA = 4
    DODONGO = 5
    DODONGO_BOSS = 6
    ZORA = 7
    JABU = 8
    JABU_BOSS = 9
    TIME_DOOR = 10
    LIGHT_SAGE = 11
    ADULT = 12
    FOREST = 13
    FOREST_BOSS = 14
    FOREST_SAGE = 15
    FIRE = 16
    FIRE_BOSS = 17
    FIRE_SAGE = 18
    ICE = 19
    WATER = 20
    WATER_BOSS = 21
    WATER_SAGE = 22
    WELL = 23
    SHADOW = 24
    SHADOW_BOSS = 25
    SHADOW_SAGE = 26
    VALLEY = 27
    FORTRESS = 28
    WASTELAND = 29
    SPIRIT = 30
    SPIRIT_BOSS = 31
    SPIRIT_SAGE = 32
    CASTLE = 33
    TOWER = 34

C = Chapter
HEARTS = (3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 8, 8, 8,
          9, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11, 11, 12, 12, 13, 20, 20)

# Routes in the two timelines start at the point where the destination is
# normally visited. Re-entering an early place deliberately re-seeds its state.
DUNGEONS = {
    'DEKU_TREE': C.DEKU, 'DEKU_TREE_BOSS': C.DEKU_BOSS,
    'DODONGOS_CAVERN': C.DODONGO, 'DODONGOS_CAVERN_BOSS': C.DODONGO_BOSS,
    'JABU_JABU': C.JABU, 'JABU_JABU_BOSS': C.JABU_BOSS,
    'FOREST_TEMPLE': C.FOREST, 'FOREST_TEMPLE_BOSS': C.FOREST_BOSS,
    'FIRE_TEMPLE': C.FIRE, 'FIRE_TEMPLE_BOSS': C.FIRE_BOSS,
    'ICE_CAVERN': C.ICE,
    'WATER_TEMPLE': C.WATER, 'WATER_TEMPLE_BOSS': C.WATER_BOSS,
    'BOTTOM_OF_THE_WELL': C.WELL,
    'SHADOW_TEMPLE': C.SHADOW, 'SHADOW_TEMPLE_BOSS': C.SHADOW_BOSS,
    'SPIRIT_TEMPLE': C.SPIRIT, 'SPIRIT_TEMPLE_BOSS': C.SPIRIT_BOSS,
    'INSIDE_GANONS_CASTLE': C.CASTLE,
    'GANONS_TOWER': C.TOWER, 'GANONDORF_BOSS': C.TOWER, 'GANON_BOSS': C.TOWER,
    'GANONS_TOWER_COLLAPSE_INTERIOR': C.TOWER,
    'GANONS_TOWER_COLLAPSE_EXTERIOR': C.TOWER,
    'GANONS_TOWER_COLLAPSE_INNER': C.TOWER,
    'INSIDE_GANONS_CASTLE_COLLAPSE': C.TOWER,
}
CHILD_DUNGEONS = {C.DEKU, C.DEKU_BOSS, C.DODONGO, C.DODONGO_BOSS, C.JABU, C.JABU_BOSS, C.WELL}
BOTH_AGES = {'SPIRIT_TEMPLE'}

def forced_age(scene):
    if scene not in DUNGEONS or scene in BOTH_AGES:
        return 0
    # Encoded as engine age + 1. Zero keeps the user's age choice.
    return 2 if DUNGEONS[scene] in CHILD_DUNGEONS else 1

KOKIRI_SCENES = {'KOKIRI_FOREST', 'LINKS_HOUSE', 'MIDOS_HOUSE', 'SARIAS_HOUSE',
                 'KOKIRI_SHOP', 'KNOW_IT_ALL_BROS_HOUSE', 'TWINS_HOUSE'}
CHILD_ZELDA = {'CASTLE_COURTYARD_ZELDA', 'DEATH_MOUNTAIN_TRAIL', 'GORON_CITY',
               'GORON_SHOP', 'DEATH_MOUNTAIN_CRATER', 'KAKARIKO_VILLAGE',
               'WINDMILL_AND_DAMPES_GRAVE', 'BAZAAR', 'GRAVEYARD',
               'ROYAL_FAMILYS_TOMB', 'GRAVE_KEEPERS_HUT', 'IMPAS_HOUSE'}
ADULT_HUBS = {
    'GRAVEYARD': C.ADULT, 'WINDMILL_AND_DAMPES_GRAVE': C.ADULT,
    'KOKIRI_FOREST': C.FOREST, 'LOST_WOODS': C.FOREST, 'SACRED_FOREST_MEADOW': C.FOREST,
    'DEATH_MOUNTAIN_TRAIL': C.FIRE, 'DEATH_MOUNTAIN_CRATER': C.FIRE, 'GORON_CITY': C.FIRE,
    'GORON_SHOP': C.FIRE, 'ZORAS_RIVER': C.ICE, 'ZORAS_DOMAIN': C.ICE,
    'ZORAS_FOUNTAIN': C.ICE, 'ZORA_SHOP': C.WATER, 'LAKE_HYLIA': C.WATER,
    'LAKESIDE_LABORATORY': C.WATER, 'GERUDO_VALLEY': C.VALLEY,
    'GERUDOS_FORTRESS': C.FORTRESS, 'GERUDO_TRAINING_GROUND': C.WASTELAND,
    'HAUNTED_WASTELAND': C.WASTELAND, 'DESERT_COLOSSUS': C.SPIRIT,
    'OUTSIDE_GANONS_CASTLE': C.CASTLE, 'CHAMBER_OF_THE_SAGES': C.ADULT,
}


def route(scene, child):
    if scene in DUNGEONS:
        return DUNGEONS[scene]
    if not child:
        return ADULT_HUBS.get(scene, C.ADULT)
    if scene in KOKIRI_SCENES:
        return C.KOKIRI
    if scene in CHILD_ZELDA or 'KAKARIKO' in scene:
        return C.ZELDA
    if scene.startswith('ZORA') or scene in {'LAKE_HYLIA', 'LAKESIDE_LABORATORY', 'FISHING_POND'}:
        return C.ZORA
    if scene in {'TEMPLE_OF_TIME', 'CHAMBER_OF_THE_SAGES'}:
        return C.TIME_DOOR
    if scene in {'DESERT_COLOSSUS', 'HAUNTED_WASTELAND'}:
        return C.SPIRIT
    if scene in {'BOMBCHU_BOWLING_ALLEY', 'BOMBCHU_SHOP'}:
        return C.DODONGO_BOSS
    return C.OUTSIDE


# Item slot -> (first routable checkpoint, inventory value, starting ammo).
GRANTS = {
    0: (C.DEKU, 0x00, 10), 1: (C.DEKU, 0x01, 20), 2: (C.DODONGO_BOSS, 0x02, 20),
    3: (C.FOREST_BOSS, 0x03, 30), 4: (C.WATER_SAGE, 0x04, 0),
    5: (C.ZORA, 0x05, 0), 6: (C.DEKU_BOSS, 0x06, 30),
    7: (C.OUTSIDE, 0x07, 0), 8: (C.VALLEY, 0x09, 10),
    9: (C.FOREST, 0x0A, 0), 10: (C.CASTLE, 0x0C, 0),
    11: (C.ICE, 0x0D, 0), 12: (C.JABU_BOSS, 0x0E, 0),
    13: (C.SHADOW, 0x0F, 0), 14: (C.ZORA, 0x10, 3),
    15: (C.FIRE_BOSS, 0x11, 0), 16: (C.CASTLE, 0x12, 0),
    17: (C.SPIRIT, 0x13, 0),
}
QUEST_AT = {
    0: C.FOREST_SAGE, 1: C.FIRE_SAGE, 2: C.WATER_SAGE,
    3: C.SPIRIT_SAGE, 4: C.SHADOW_SAGE, 5: C.ADULT,
    6: C.FOREST, 7: C.FIRE, 8: C.WATER, 9: C.SPIRIT,
    10: C.WELL, 11: C.FOREST_SAGE, 12: C.ZELDA, 13: C.ZELDA, 14: C.DODONGO,
    15: C.DODONGO, 16: C.TIME_DOOR, 17: C.WELL,
    18: C.OUTSIDE, 19: C.ZORA, 20: C.TIME_DOOR, 21: C.CASTLE, 22: C.WASTELAND,
}
EVENTS_AT = {
    C.OUTSIDE: (0x04, 0x05, 0x09),
    C.ZELDA: (0x10, 0x12, 0x13, 0x14, 0x15, 0x16, 0x40),
    C.DODONGO: (0x20, 0x21),
    C.ZORA: (0x25, 0x38),
    C.JABU: (0x33, 0x3A),
    C.TIME_DOOR: (0x80,),
    C.LIGHT_SAGE: (0x45, 0x4B, 0x4F),
    C.FOREST: (0x18,),
    C.FIRE: (0x48,),
    C.ICE: (0x2C,),
    C.WELL: (0x67, 0x69, 0xB5),
    C.WASTELAND: (0x90, 0x91, 0x92, 0x93),
    C.CASTLE: (0x4D, 0xC4),
}
BOSS_DUNGEONS = {
    C.DEKU_BOSS: 0, C.DODONGO_BOSS: 1, C.JABU_BOSS: 2, C.FOREST_BOSS: 3,
    C.FIRE_BOSS: 4, C.WATER_BOSS: 5, C.SPIRIT_BOSS: 6, C.SHADOW_BOSS: 7,
}
SNAPSHOT_SIZE = 0xD4 - 0x2E + 28 + 4


def snapshot(chapter, child, sage=None):
    """Build the contiguous loadout + event words + mod flags for one menu entry."""
    c = C(chapter)
    save = bytearray(0xF32)
    items = [255] * 24
    ammo = [0] * 16
    for slot, (first, value, count) in GRANTS.items():
        if c >= first:
            items[slot] = value
            if slot < len(ammo):
                ammo[slot] = count
    if c >= C.TIME_DOOR:
        items[7] = 0x08
    if c >= C.WATER_BOSS:
        items[9] = 0x0B
    if c >= C.ZORA:
        items[18] = 0x14
    if c == C.ZORA:
        items[19] = 0x1B
    if c >= C.JABU:
        items[19] = 0x14
    if c >= C.FIRE:
        items[20] = 0x14
    if c >= C.CASTLE:
        items[21:23] = [0x14, 0x37]
        ammo[0:4] = [30, 40, 40, 50]
        ammo[6], ammo[8], ammo[14] = 50, 50, 10
    elif c >= C.ADULT:
        items[22] = 0x2D
    if c >= C.ZELDA:
        items[23] = 0x2B if c >= C.CASTLE else 0x23
    elif c == C.OUTSIDE:
        items[23] = 0x21

    caps = [int(c >= C.FOREST_BOSS), int(c >= C.DODONGO_BOSS),
            3 if c >= C.TOWER else 2 if c >= C.SPIRIT_BOSS else int(c >= C.DODONGO),
            2 if c >= C.CASTLE else int(c >= C.ZORA),
            2 if c >= C.CASTLE else int(c >= C.FIRE), int(c >= C.DEKU_BOSS),
            int(c >= C.DEKU), int(c >= C.DEKU)]
    if c >= C.CASTLE:
        caps[0], caps[1], caps[5], caps[6], caps[7] = [3] * 5
    upgrades = sum(v << shift for v, shift in zip(caps, (0, 3, 6, 9, 12, 14, 17, 20)))
    swords = int(c >= C.DEKU) | (2 if c >= C.LIGHT_SAGE or not child else 0)
    shields = (1 if c >= C.DEKU else 0) | (2 if c >= C.ZELDA or not child else 0)
    tunics = 1 | (2 if c >= C.FIRE else 0) | (4 if c >= C.WATER else 0)
    boots = 1 | (2 if c >= C.WATER else 0) | (4 if c >= C.SHADOW_BOSS else 0)
    if c >= C.CASTLE:
        swords |= 4
        save[0x3E] = 1
        pack_into('>H', save, 0x36, 8)
    if c >= C.SPIRIT_BOSS:
        shields |= 4
    pack_into('>H', save, 0x9C, swords | shields << 4 | tunics << 8 | boots << 12)

    # Grant the equipment without forcing the Iron Boots on at the entrance.
    def equips(at, use_child):
        sword = (1 if swords & 1 else 0) if use_child else (2 if swords & 2 else 0)
        shield = (1 if shields & 1 else 0) if use_child else (2 if shields & 2 else 0)
        tunic = 2 if not use_child and c in (C.FIRE, C.FIRE_BOSS) else 1
        linked = [6, 2, 7] if use_child else [9, 3, 7]
        if c in (C.JABU_BOSS, C.WELL):
            linked[0] = 12
        if c in (C.FIRE_BOSS,):
            linked[1] = 15
        if c >= C.SHADOW and c < C.CASTLE and not use_child:
            linked[1] = 13
        if c >= C.CASTLE and not use_child:
            linked[1] = 3
        save[at:at+4] = bytes([0x3A+sword if sword else 255] +
                                   [items[i] for i in linked])
        save[at+4:at+7] = bytes([i if items[i] != 255 else 255 for i in linked])
        pack_into('>H', save, at+8, 0x1000 | tunic << 8 | shield << 4 | sword)

    equips(0x40, True)
    equips(0x4A, False)
    equips(0x68, child)
    save[0x74:0x8C] = bytes(items)
    save[0x8C:0x9C] = bytes(ammo)
    quest = sum(1 << bit for bit, first in QUEST_AT.items() if c >= first)
    if sage is not None:
        # Let the cutscene itself award its own medallion.
        quest &= ~(1 << (5 if sage == 5 else sage))
    pack_into('>II', save, 0xA0, upgrades, quest)
    save[0xBC:0xCF] = b'\xFF' * 19
    if c in BOSS_DUNGEONS:
        save[0xA8+BOSS_DUNGEONS[c]] = 7
    if c in (C.TOWER,):
        save[0xA8+10] = 1  # Tower boss key, already earned after the trials.
    hearts = HEARTS[c] * 16
    pack_into('>HH', save, 0x2E, hearts, hearts)
    magic = 0x60 if c >= C.CASTLE else 0x30 if c >= C.ZORA else 0
    save[0x32:0x34] = bytes((magic//0x30, magic))
    save[0x3A] = int(magic != 0)
    save[0x3C] = int(magic == 0x60)
    if c >= C.TOWER:
        save[0x3D] = 1
        save[0xCF] = 20
    pack_into('>H', save, 0x34, 500 if c >= C.CASTLE else 80 if c >= C.ADULT else 30 if c else 0)
    if c >= C.CASTLE:
        pack_into('>H', save, 0xD0, 100)
    for first, flags in EVENTS_AT.items():
        if c >= first:
            for flag in flags:
                offset = 0xED4+(flag>>4)*2
                word = int.from_bytes(save[offset:offset+2], 'big') | 1 << (flag&15)
                pack_into('>H', save, offset, word)
    mod = (0x1000 if c >= C.OUTSIDE else 0) | (0x2000 if c >= C.ADULT else 0)
    mod |= 0x4000 if c >= C.SHADOW else 0
    # The current title/name, language and preferences are outside these spans.
    output = save[0x2E:0xD4] + save[0xED4:0xEF0] + mod.to_bytes(2, 'big') + b'\0\0'
    assert len(output) == SNAPSHOT_SIZE
    return bytes(output)


SAGES = [
    ('Habeck - Licht', C.LIGHT_SAGE, 5),
    ('Waldweise', C.FOREST_SAGE, 0),
    ('Wallace - Feuer', C.FIRE_SAGE, 1),
    ('Thaddaeus - Wasser', C.WATER_SAGE, 2),
    ('Mr. Bean - Schatten', C.SHADOW_SAGE, 4),
    ('Waluigi - Geist', C.SPIRIT_SAGE, 3),
]

# Linked native entry IDs map to scene names without loading any game data.
def entrance_scenes(source):
    import re
    return {
        int(number, 16): scene
        for number, scene in re.findall(
            r'/\* 0x([0-9A-Fa-f]+) \*/\s*DEFINE_ENTRANCE\([^,]+, SCENE_(\w+)', source
        )
    }

"""ROM formats used by the version builder. No game data is bundled here."""
import hashlib
from struct import pack, pack_into, unpack_from
from zlib import crc32

PAL_MD5 = 'e040de91a74b61e3201db0e2323f768a'
DMA_OFFSET = 0x7950


def canonical_rom(data):
    signature = data[:4]
    if signature == bytes.fromhex('80371240'):
        return data
    if signature == bytes.fromhex('37804012'):
        result = bytearray(data)
        result[0::2], result[1::2] = data[1::2], data[0::2]
        return bytes(result)
    if signature == bytes.fromhex('40123780'):
        result = bytearray(data)
        for i in range(4):
            result[i::4] = data[3-i::4]
        return bytes(result)
    raise ValueError('Die Eingabe ist keine N64-ROM.')


def apply_bps(original, patch):
    if patch[:4] != b'BPS1' or crc32(patch[:-4]) != unpack_from('<I', patch, len(patch)-4)[0]:
        raise ValueError('Die V112-BPS-Datei ist beschädigt.')
    cursor = 4

    def read_number():
        nonlocal cursor
        value, scale = 0, 1
        while cursor < len(patch)-12:
            byte = patch[cursor]
            cursor += 1
            value += (byte & 0x7F)*scale
            if byte & 0x80:
                return value
            scale <<= 7
            value += scale
        raise ValueError('Unvollständiger BPS-Befehl.')

    source_size, target_size, metadata_size = read_number(), read_number(), read_number()
    source_crc, target_crc = unpack_from('<II', patch, len(patch)-12)
    if source_size != len(original) or crc32(original) != source_crc:
        raise ValueError('Der V112-Patch passt nicht zu dieser Basis-ROM.')
    cursor += metadata_size
    out = bytearray()
    source = target = 0
    while len(out) < target_size:
        command = read_number()
        length = (command>>2)+1
        mode = command&3
        if mode == 0:
            out.extend(original[len(out):len(out)+length])
        elif mode == 1:
            out.extend(patch[cursor:cursor+length])
            cursor += length
        else:
            delta = read_number()
            relative = -(delta>>1) if delta&1 else delta>>1
            if mode == 2:
                source += relative
                out.extend(original[source:source+length])
                source += length
            else:
                target += relative
                pattern = out[target:len(out)]
                if not pattern or target < 0:
                    raise ValueError('BPS-Rückverweis außerhalb des Ziels.')
                repeat, remainder = divmod(length, len(pattern))
                out.extend(pattern*repeat+pattern[:remainder])
                target += length
    if len(out) != target_size or cursor != len(patch)-12 or crc32(out) != target_crc:
        raise ValueError('V112 konnte nicht fehlerfrei angewandt werden.')
    return out


def decode_yaz0(data):
    if data[:4] != b'Yaz0':
        raise ValueError('Ungültiger Yaz0-Dateikopf.')
    expected = unpack_from('>I', data, 4)[0]
    out = bytearray()
    cursor = 16
    while len(out) < expected:
        bits = data[cursor]
        cursor += 1
        for shift in range(7, -1, -1):
            if len(out) == expected:
                break
            if bits & 1 << shift:
                out.append(data[cursor])
                cursor += 1
                continue
            first, second = data[cursor:cursor+2]
            cursor += 2
            distance = ((first & 15) << 8 | second) + 1
            count = first >> 4
            if count:
                count += 2
            else:
                count = data[cursor]+18
                cursor += 1
            if distance > len(out) or len(out)+count > expected:
                raise ValueError('Yaz0-Rückverweis außerhalb des Ziels.')
            pattern = out[-distance:]
            repeat, rest = divmod(count, distance)
            out.extend(pattern*repeat+pattern[:rest])
    return out


class Rom:
    def __init__(self, data):
        self.data = bytearray(data)
        self.entries = []
        for i in range(2500):
            row = unpack_from('>4I', self.data, DMA_OFFSET+16*i)
            if row[1] == 0:
                break
            self.entries.append(row)
        if len(self.entries) < 700:
            raise ValueError('Unerwartete PAL-Dateitabelle.')
        self.physical_end = max(end if end else physical+vend-vstart
                                for vstart,vend,physical,end in self.entries
                                if physical != 0xFFFFFFFF)
        self.virtual_end = max(row[1] for row in self.entries)

    def read(self, slot):
        start, end, physical, physical_end = self.entries[slot]
        if physical == 0xFFFFFFFF:
            raise ValueError('Datei ist in der ROM deaktiviert.')
        data = self.data[physical:physical_end or physical+end-start]
        out = decode_yaz0(data) if physical_end else data
        if len(out) != end-start:
            raise ValueError('Dateigröße passt nicht zum DMA-Eintrag.')
        return out

    def replace(self, slot, data, grow=False, reuse=False):
        """Add an uncompressed copy, keeping old references for fixed-size files."""
        start, end, old_physical, old_end = self.entries[slot]
        if grow:
            start = align(self.virtual_end, 0x1000)
            end = start+len(data)
            self.virtual_end = end
        elif end-start != len(data):
            raise ValueError('Feste virtuelle Dateigröße wurde geändert.')
        if reuse and old_end == 0 and not grow:
            physical = old_physical
        else:
            physical = align(self.physical_end, 16)
            if physical+len(data) > len(self.data):
                raise ValueError('Zu wenig Platz am Ende der ROM.')
            self.physical_end = physical+len(data)
        self.data[physical:physical+len(data)] = data
        row = start, end, physical, 0
        self.entries[slot] = row
        pack_into('>4I', self.data, DMA_OFFSET+16*slot, *row)
        return start, end


def align(value, boundary):
    return (value+boundary-1)&-boundary


def cic6105(data):
    mask = 0xFFFFFFFF
    t1 = t2 = t3 = t4 = t5 = t6 = 0xDF26F436
    for offset in range(0x1000, 0x101000, 4):
        word = unpack_from('>I', data, offset)[0]
        new = (t6+word)&mask
        t4 = (t4+(new<t6))&mask
        t6 = new
        t3 ^= word
        shift = word&31
        rotated = ((word<<shift) | (word>>(32-shift))) & mask
        t5 = (t5+rotated)&mask
        t2 ^= rotated if t2>word else t6^word
        boot_word = unpack_from('>I', data, 0x750+(offset&0xFF))[0]
        t1 = (t1+(boot_word^word))&mask
    return t6^t4^t3, t5^t2^t1


def repair_checksum(data):
    pack_into('>II', data, 0x10, *cic6105(data))

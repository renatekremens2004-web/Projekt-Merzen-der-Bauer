# Wallace in der Erwachsenen-Zeit

Quelle: Nutzerarchiv wallace-freeman-hl2-but-ruined-by-mods.zip, darin source/wallace freeman.zip mit OBJ/MTL und Texturen. Wallace-Figur von Aardman; HEV-Anzug/Gordon-Freeman-Fanmodell aus Half-Life 2. Die Upload-Dateien enthalten keine gesonderte Lizenz-/Autorenangabe zum konkreten Fanmodell; keine zusätzliche Herkunft behauptet.

Die doppelt vorhandene überlappende Anzug-Oberfläche und alternative unsichtbare Lidvarianten wurden entfernt. Auf 2.269 Dreiecke reduziert. Vier eigene starre Teile: Körper, Kopf und beide Arme. Offline abgesenkte A-Pose-Arme, im Spiel ausschließlich kleine Kopf-/Armrotationen um feste eigene Achsen. Einheitliche Höhe 110 Spieleinheiten. Fünf CI4-Texturen zu je 64×64 (2.048 Bytes plus Palette), keine TMEM-Überbelegung. Native Beleuchtung, Nebel und Ein-/Ausblenden.

Im Feuertempel ersetzt Wallace genau den unteren Gefangenen im Felslabyrinth (Raum 5, Parameter 0D83, Zellschalter 3). Daten im Raumsegment, kein zusätzlicher Objekt-Slot. Native Zelle, Schlüsseltruhe, Fluchtpfad und Schalter bleiben erhalten. Das eigene Modell wird zusätzlich an object_du angehängt; Darunia bleibt für die Kindheit und seinen Feuertempelauftritt erhalten. DemoDu verwendet Wallace nur in deutschen Weisenrollen einschließlich Finale und Credits. Keine vergrößerten Actor-Instanzen.

Die Krabbelminen-Frau behält ihren Körper, ihre eigenen Knochenlängen und alle Animationen außerhalb der Sitzsequenz. Ihre drei Credits-Sitzanimationen sind neu angepaßt: Oberschenkel nach vorn, Unterschenkel fast senkrecht, Hände am Kragen, Oberkörper nur zwei Grad zurückgeneigt. Die lokale Sitzwurzel [-100,9400,300] berücksichtigt den nativen Positionsunterschied beider Actors und liegt auf Wallace' Schulter-/Rückenansatz hinter dem Kopf. Eigene Weisen-Nahaufnahmen vermeiden das Abschneiden des größeren Modells. Kamerazeiten und Story-Cues bleiben unverändert.

Neubau benötigt nur wallace_adult_source.json und PNGs. export_wallace_adult.py dokumentiert die einmalige Blender-Ableitung aus dem OBJ. Der Wallace aus Dodongos Höhle als Kind bleibt unverändert.


Aktuelle Größenkorrektur: 90 statt 110 Spieleinheiten, gleichmäßig skaliert. Dieselbe Geometrie und alle Texturen bleiben erhalten; eigener Kopf-/Arm-Drehpunkt ebenfalls skaliert. Gilt für Gefangenen, Feuerweisenrolle, Finale und Credits. Kind-Wallace unverändert.

"""Apply German chapter dialogue without changing message IDs or game logic."""
from pathlib import Path
import argparse
import ast
import json
import re

ROOT = Path(__file__).resolve().parent.parent
STRING = r'"(?:[^"\\]|\\.)*"'
LEX = re.compile(r'/\*.*?\*/|//[^\n]*|' + STRING + r'|\b[A-Z][A-Z_0-9]*\b(?:\([^()]*\))?', re.S)
ARG_MACRO = re.compile(r'(\w+)(?:\((.*)\))?$', re.S)
TERMINAL = {'TEXTID', 'EVENT', 'PERSISTENT', 'FADE', 'FADE2', 'OCARINA', 'AWAIT_BUTTON_PRESS'}
PRESERVED = TERMINAL | {'TWO_CHOICE', 'THREE_CHOICE', 'SFX', 'ITEM_ICON', 'BACKGROUND', 'BOX_BREAK_DELAYED', 'TIME'}


def closing(source, start):
    depth = 1
    i = start
    while depth:
        if source[i] == '"':
            i += 1
            while True:
                if source[i] == '\\':
                    i += 2
                elif source[i] == '"':
                    i += 1
                    break
                else:
                    i += 1
            continue
        if source[i:i + 2] == '/*':
            i = source.index('*/', i + 2) + 2
            continue
        depth += (source[i] == '(') - (source[i] == ')')
        i += 1
    return i - 1


def messages(source):
    starts = list(re.finditer(r'^DEFINE_MESSAGE\(0x([0-9a-fA-F]+),', source, re.M))
    out = {}
    for n, m in enumerate(starts):
        end = starts[n + 1].start() if n + 1 < len(starts) else len(source)
        block = source[m.start():end]
        parts = []
        for p in re.finditer(r'(?m)^MSG\(', block):
            a = m.start() + p.end()
            b = closing(source, a)
            parts.append((a, b, source[a:b]))
        assert len(parts) == 4, m[1]
        out[m[1].upper()] = {'parts': parts, 'header': block[:block.index('MSG(')]}
    return out


def tokens(body):
    return [m.group() for m in LEX.finditer(body) if not m.group().startswith(('"', '/',))]


def macro_name(token):
    return token.split('(')[0]


def controls(body):
    return [t for t in tokens(body) if macro_name(t) in PRESERVED]


def split_pages(body):
    separators = [m for m in LEX.finditer(body) if macro_name(m.group()) in {'BOX_BREAK', 'BOX_BREAK_DELAYED'}]
    pages = []
    start = 0
    for m in separators:
        pages.append(body[start:m.start()])
        start = m.end()
    pages.append(body[start:])
    return pages, [m.group() for m in separators]


def plain(body):
    out = ''
    for m in LEX.finditer(body):
        t = m.group()
        if t.startswith('"'):
            out += json.loads(t)
        elif t == 'NAME':
            out += '{name}'
        elif t == 'TIME':
            out += '{time}'
    return out


class Layout:
    def __init__(self, oot):
        source = (oot / 'src/code/z_message.c').read_text()
        array = re.search(r'f32 sFontWidths\[144\] = \{(.*?)\};', source, re.S)[1]
        array = re.sub(r'#if OOT_NTSC\n.*?#else\n(.*?)#endif', r'\1', array, flags=re.S)
        self.widths = [float(x) for x in re.findall(r'\b(\d+\.\d+)f', array)]
        assert len(self.widths) == 144
        cm = (oot / 'assets/text/charmap.nes.txt').read_text()
        self.charmap = ast.literal_eval(cm)

    def width(self, text):
        total = 0
        for token in re.findall(r'\{name\}|\{time\}|\[[^\]]+\]|.', text):
            if token == '{name}':
                # Eight wide letters: the longest legal custom player name.
                total += 8 * int(self.widths[ord('W') - 32] * .75)
            elif token == '{time}':
                total += 45
            elif token == ' ':
                total += 6  # MESSAGE_SPACE_WIDTH is not scaled.
            elif token in self.charmap:
                total += int(self.widths[self.charmap[token] - 32] * .75)
            else:
                assert 32 <= ord(token) < 128, 'Unsupported font character: ' + token
                total += int(self.widths[ord(token) - 32] * .75)
        return total

    def wrap(self, text, width):
        assert not re.search(r'\bLink\b', text), 'Use {name}, never a literal player name'
        assert not re.search(r'\b(dass|muss|musst|lässt|Schloss|Fluss)\b', text), 'Pre-1996 spelling required'
        lines = []
        for paragraph in text.split('\n'):
            line = ''
            for word in paragraph.split():
                assert self.width(word) <= width, ('word too wide', word)
                candidate = (line + ' ' + word).strip()
                if line and self.width(candidate) > width:
                    lines.append(line)
                    line = word
                else:
                    line = candidate
            lines.append(line)
        return lines


def c_text(text, color):
    pieces = []
    for s in re.split(r'(\{name\}|\{time\})', text):
        if s == '{name}':
            pieces.append('NAME')
        elif s == '{time}':
            pieces.append('TIME')
        elif s:
            pieces.append(json.dumps(s, ensure_ascii=False))
    return ' '.join(pieces) or '""'


def rewrite(body, entry, layout, ident):
    old_pages, separators = split_pages(body)
    pages = entry['pages']
    # More manually advanced pages are safe for ordinary conversations. Keep
    # original pages/controls in order and put the native terminal/choice page
    # last. Never alter the length or timing of cutscene-delayed messages.
    extra = len(pages) - len(old_pages)
    assert extra >= 0, (ident, 'cannot remove native pages')
    if extra:
        assert all(s == 'BOX_BREAK' for s in separators), (ident, 'timed pages')
        assert not any(macro_name(t) in {'FADE', 'FADE2', 'OCARINA'} for t in tokens(body)), (ident, 'timed message')
        filler = 'UNSKIPPABLE' if 'UNSKIPPABLE' in tokens(old_pages[-1]) else ''
        old_pages = old_pages[:-1] + [filler] * extra + old_pages[-1:]
        separators += ['BOX_BREAK'] * extra
    out = []
    report = []
    for i, (old, text) in enumerate(zip(old_pages, pages)):
        ts = tokens(old)
        prefix = [t for t in ts if macro_name(t) in {'SFX', 'ITEM_ICON', 'BACKGROUND'}]
        if 'UNSKIPPABLE' in ts:
            prefix.insert(0, 'UNSKIPPABLE')
        quick_shop = any(t == 'PERSISTENT' for t in ts) or entry.get('quick', False)
        if quick_shop:
            prefix.append('QUICKTEXT_ENABLE')
        kind = next((t for t in ts if t in {'TWO_CHOICE', 'THREE_CHOICE'}), None)
        choices = entry.get('choices', []) if kind else []
        if kind:
            assert len(choices) == (2 if kind == 'TWO_CHOICE' else 3), ident
        width = 166 if any(t.startswith('ITEM_ICON(') for t in ts) else 210
        lines = layout.wrap(text, width)
        assert len(lines) + len(choices) <= 4, (ident, i, 'too many lines', lines, choices)
        if choices:
            # Native choice-arrow Y coordinates assume the options occupy
            # the final two/three rows of a four-line textbox.
            lines += [''] * (4 - len(choices) - len(lines))
        assert all(layout.width(c) <= 190 for c in choices), ident
        color = entry.get('color', 'LIGHTBLUE' if re.match(r'\s*(?:UNSKIPPABLE\s+)?COLOR\(LIGHTBLUE\)', old) else 'DEFAULT')
        result = prefix + ['COLOR(' + color + ')', c_text('\n'.join(lines), color)]
        if kind:
            result += ['"\\n"', kind, 'COLOR(ADJUSTABLE)', c_text('\n'.join(choices), color), 'COLOR(DEFAULT)']
        if quick_shop:
            result.append('QUICKTEXT_DISABLE')
        result += [t for t in ts if macro_name(t) in TERMINAL]
        out.append(' '.join(result))
        report.append({'lines': len(lines) + len(choices), 'max_line_pixels': max(map(layout.width, lines), default=0)})
    new = '\n' + out[0] + ''.join('\n' + sep + '\n' + page for sep, page in zip(separators, out[1:])) + '\n'
    assert controls(new) == controls(body), (ident, 'functional control sequence changed', controls(body), controls(new))
    if 'NAME' in tokens(body):
        assert 'NAME' in tokens(new), (ident, 'lost player name')
    # The retail raw-message buffer is 1,280 bytes. Compiled lengths are
    # independently checked from linker symbols after building as well.
    visible = plain(new).replace('{name}', 'XXXXXXXX')
    estimated = len(visible) + 4 * len(tokens(new))
    assert estimated < 1280, (ident, 'message buffer budget', estimated)
    return new, report


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('oot', type=Path)
    ap.add_argument('--inspect', nargs='*')
    args = ap.parse_args()
    oot = args.oot.resolve()
    target = oot / 'extracted/pal-1.0/text/message_data.h'
    backup = ROOT / 'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h'
    if args.inspect is not None:
        source = backup.read_text() if backup.exists() else target.read_text()
        parsed = messages(source)
        for ident in args.inspect:
            ident = ident.removeprefix('0x').upper().zfill(4)
            body = parsed[ident]['parts'][2][2]
            print(ident, len(re.split(r'\bBOX_BREAK\b(?!_)', body)), controls(body))
            print(body)
        return
    backup.parent.mkdir(parents=True, exist_ok=True)
    if not backup.exists():
        backup.write_bytes(target.read_bytes())
    source = backup.read_text()
    parsed = messages(source)
    edits = {}
    for file in sorted((ROOT / 'story').glob('*.json')):
        chapter = json.loads(file.read_text())
        for ident, entry in chapter['messages'].items():
            assert ident not in edits, ('duplicate story ID', ident)
            edits[ident] = entry
    layout = Layout(oot)
    replacements = []
    report = {}
    errors = []
    for ident, entry in edits.items():
        try:
            a, b, body = parsed[ident]['parts'][2]
            new, pages = rewrite(body, entry, layout, ident)
            replacements.append((a, b, new))
            report[ident] = {'pages': pages, 'player_name_tokens': tokens(new).count('NAME')}
        except (AssertionError, KeyError) as exc:
            errors.append(str(exc))
    if errors:
        raise SystemExit('\n'.join(errors))
    result = source
    for a, b, new in sorted(replacements, reverse=True):
        result = result[:a] + new + result[b:]
    changed = messages(result)
    assert parsed.keys() == changed.keys()
    for ident, old in parsed.items():
        for language in [0, 1, 3]:
            assert old['parts'][language][2] == changed[ident]['parts'][language][2], (ident, language)
        if ident not in edits:
            assert old['parts'][2][2] == changed[ident]['parts'][2][2], ident
        assert old['header'] == changed[ident]['header'], ident
    target.write_text(result)
    # 015F is shared by other dungeon scripts. Reserve an unused text slot
    # for this German-only Deku remark and select it only in this dungeon.
    hint_path = oot / 'src/code/z_elf_message.c'
    hint_backup = ROOT / 'tools/originals/story/src/code/z_elf_message.c'
    hint_backup.parent.mkdir(parents=True, exist_ok=True)
    if not hint_backup.exists():
        hint_backup.write_bytes(hint_path.read_bytes())
    hint_source = hint_backup.read_text()
    hint_marker = 'u16 QuestHint_GetNaviTextId(PlayState* play) {\n'
    assert hint_source.count(hint_marker) == 1
    if '0134' in edits:
        hint_source = hint_source.replace(hint_marker, hint_marker + '''    /* A dedicated German aside; all other dungeon hints remain native. */
    if (gSaveContext.language == LANGUAGE_GER && play->sceneId == SCENE_DEKU_TREE) {
        return 0x0134;
    }
''')
    if '0135' in edits:
        marker = '        return QuestHint_GetTextIdFromScript(play->naviQuestHints);'
        assert hint_source.count(marker) == 1
        hint_source = hint_source.replace(marker, '''        u16 textId = QuestHint_GetTextIdFromScript(play->naviQuestHints);

        /* Only after Darunia has actually awarded the spiritual stone. */
        if (gSaveContext.language == LANGUAGE_GER && !LINK_IS_ADULT &&
            CHECK_QUEST_ITEM(QUEST_GORON_RUBY) && (textId == 0x0148 || textId == 0x0149)) {
            return 0x0135;
        }
        return textId;''')
    hint_path.write_text(hint_source)
    (oot / 'build/pal-1.0/story-layout.json').write_text(json.dumps(report, indent=2))
    print('Applied', len(edits), 'German dialogue messages; native IDs, quest controls and other language text preserved.')


if __name__ == '__main__':
    main()

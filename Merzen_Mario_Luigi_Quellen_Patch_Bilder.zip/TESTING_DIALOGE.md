# Dialoge und Beans Rückblende

## Umfang

83 neue beziehungsweise überarbeitete deutsche Nachrichten in `story/hyrule_stadt_de.json`; zusammen mit den erhaltenen Kokiri-/Bean-Kapiteln 265 Nachrichten. Die Textfassung verwendet alte Rechtschreibung, native Spielernamen und unveränderte Gesprächs-IDs. Gewöhnliche Gespräche dürfen zusätzliche manuell weitergeschaltete Seiten erhalten. Zeitgesteuerte Seiten, Folge-IDs, Ereignisse, Preise, Auswahlreihenfolgen und Übergaben bleiben erhalten. Der Generator prüft PAL-Schriftbreiten und die Optionen auf ihren nativen Cursorzeilen.

Enthalten sind verschiedene Stimmen der Stadtbewohner, Farmgespräche von Malon und Talon, die Bowling-Studentin, der Maskenhändler, Zeldas erste Audienz und Methusas wiederkehrende Gespräche. Die Politik ist eine fiktive Hyrule-Satire, mit Anspielungen auf Merz' frühere Tätigkeit bei BlackRock Deutschland, seine Ablehnung einer Vermögensteuer und seine Positionen zu Arbeitszeiten. Fiktive Folgen und die Bösewicht-Handlung sind keine Tatsachenbehauptungen über reale Vorgänge.

Navis neuer C-oben-Kommentar nutzt den unbenutzten Textplatz 0134. Nur `QuestHint_GetNaviTextId` erhält eine Abfrage für deutsche Sprache und den Deku-Baum. Der in anderen Dungeons benutzte Text 015F und deren Hinweise bleiben erhalten. Weitere Running-Gag-Fortsetzungen werden noch nicht eingebaut. Thaddäus wird nur als Gerücht erwähnt: Junge Ruto und erwachsene Ruto bleiben in dieser Fassung unverändert.

## Modell

Die stehende Geometrie und die Quelldaten `bean_bound.json` bleiben erhalten. Ausschließlich in der schwarzweißen Feld-Rückblende wählt der Impa-Zeichen-Callback eine zusätzliche Darstellung der Hose: 117 gespaltene Modellpunkte an Hüfte und Knien erhalten eine aus den originalen FBX-Gewichten vorberechnete Übergangskorrektur. Damit werden harte Übergänge der starren N64-Bindung abgefangen. Sattelpunkt, Knochenlängen, Bewegungsdaten, Schuhkorrektur, Texturen und Oberkörper bleiben erhalten. Die normalen Reitszenen verwenden weiterhin die stehende Basisgeometrie.

Das Modellobjekt benötigt nun 80.720 Bytes; zuvor 70.224 Bytes, Vanilla 74.288 Bytes. Es wird kein Expansion Pak vorausgesetzt. Die betroffenen Reitszenen werden mit realen 4 MB im Emulator geprüft. Nachbau der vorberechneten Übergänge: `python tools/prepare_riding_seams.py /pfad/zum/oot` mit NumPy, anschließend `build_bean.py`. Der normale Build benötigt nur die enthaltene JSON-Datei.

## Schwarze Flächen

Die beobachteten schwarzen Dreiecke in der Halle der Weisen sind im verwendeten GLideN64-/Mesa-Aufbau durch Software-Clipping reproduzierbar. Der Vergleich benutzt dieselbe Test-ROM und Kamera, bei beiden Läufen deaktivierte eigene Spielprofile, und ändert ausschließlich `EnableClipping`: eingeschaltet zeigt schwarze Dreiecke, ausgeschaltet zeichnet den Raum. Ein zusätzlicher Lauf ohne Beans Zeichenfunktion zeigte die Dreiecke ebenfalls. Die ROM erhält dafür keinen Eingriff in die Hallengeometrie oder Kamera.

Für die Cloud-Aufnahmen werden `Video-GLideN64.EnableClipping=False` und `EnableCustomSettings=False` gesetzt. Das ist eine Einstellung dieses Grafik-Plugins, keine im BPS gespeicherte Emulator-Konfiguration. Falls dieselben Dreiecke lokal auftreten, kann dieselbe Einstellung dort helfen. Andere Emulatoren und echte Hardware sind damit nicht pauschal beurteilt.

Beim Wiegenlied wird zusätzlich der diagonale Blick auf den ungebauten Hofrand vermieden. Nur Kamera-Punkte und Bildwinkel ändern sich; Noten, Szenenzeit, Dialoge, Eingabe und Questfortsetzung bleiben erhalten.

## Nachweise und Grenzen

`tools/verify_dialogue_revision.py` prüft gegen die Proportionsfassung (SHA256 `2245294cf6dcb23183a8aa34fae0d4b3270cc8ff6350836d7e2b2cfa7461cb16`): Kompression aller 1.509 Datenblöcke, unbeabsichtigte Segmentänderungen, Relokationen, Quelltextumfang, normalen Spielstart, Geometrie und kompilierte Textpuffer. Alle 265 Nachrichten passen in die Originalpuffer: größte Nachricht 704 Bytes bei 1.280 Bytes Platz; größte dekodierte Seite höchstens 119 Bytes bei 200 Bytes Platz.

Gezielte Laufzeittests sind von Test-ROMs mit normaler nativer Szenen-/Gesprächslogik aufgenommen. Controller-Tasten schalten die Texte und Liedeingabe weiter. Teststarts und Positionierung dienen nur den Aufnahmen und gehören nicht zum Patch. Es gibt keinen vollständigen Spieldurchlauf und keinen Hardware-Test. Nicht jedes der 83 Gespräche wird in jeder Questphase durchgespielt; strukturelle Prüfungen decken alle Nachrichten ab. Die beiden erfolglosen Eulen-Aufnahmeversuche per Teleport werden nicht als bestandene Gesprächsprüfung ausgegeben.

Ausgewählte unveränderte Ingame-PNGs und ihre Herkunft stehen unter `previews/dialoge-stadt/`. Die ROM selbst bleibt lokal. Der BPS-Patch wird mit RomPatcher.js samt Quell-Prüfsumme bytegenau gegen den Produktionsbuild geprüft.

# Mario und Luigi – Farmrevision

75 Nachrichten im Farmkapitel neu gefaßt, davon 63 zuvor unbearbeitete IDs; insgesamt 412 deutsche Nachrichten. Weitere Namensverweise in bestehenden Kapiteln vereinheitlicht. Überwiegend deutsche Sprache mit charakteristischen Mario-/Luigi-Ausrufen, alte Rechtschreibung. Der vormals negative Luigi wird selbst bei einer Niederlage und beim Abschließen des Tors überschwenglich positiv dargestellt. Figurenmodelle bleiben die vorhandenen Farmmodelle.

## Build und Patch

`tools/build_story.py` prüft Seitenzahl, Zeilenbreite, Auswahlzeilen und die nativen funktionalen Kontrollcodes einschließlich Ereignissen, Textverkettung, verzögerten Seiten und Ausblendzeiten. Fest vorgegebene Lesezeiten werden nicht verlängert. Keine alte deutsche Talon-/Basil-Nennung bleibt übrig.

`tools/verify_farm_revision.py` vergleicht gegen die vorherige Goronenfassung: 1509 ROM-Segmente geprüft, deutsche Textpuffer innerhalb der nativen Grenzen, korrekte PAL-ROM-Prüfsumme, normaler Spielstart. Farm-Aktorcode und Spielregeln unverändert; Bean-Modelldaten bleiben unverändert. Die generierten deutschen Texttabellen und notwendigen ROM-Adressen ändern sich.

Der neue BPS-Patch wird mit dem Code von RomPatcher.js und aktivierter Quellprüfung auf die unveränderte PAL-1.0-ROM angewandt und bytegenau mit dem Produktionsbuild verglichen. Original-MD5: `e040de91a74b61e3201db0e2323f768a`. Patch direkt auf Vanilla anwenden, nicht auf einen alten Mod-Patch.

## Ingame-Prüfung

Gezielte Szenenstarts in Mupen64Plus/GLideN64 mit 4 MB RAM. Eigene Test-ROMs setzen Alter, Tageszeit, Szeneneinstieg und Fortschritt gezielt; ein Controller-Helfer stellt den Spieler für Gespräche vor die Figur. Die Dialoge werden mit normalen Controller-Eingaben fortgesetzt. Für die Rennsieg- und Toraufnahmen wird direkt der jeweilige native Rennzustand geladen: Dies ist kein Nachweis eines vom Controller gewonnenen Rennens. Im ausgelieferten Patch gibt es diese Testeinstiege und Positionierungen nicht.

Szenarien: Marios Super-Hühner-Erklärung, Luigis Begrüßung und Reitangebot, erster Rennsieg, zweiter Rennsieg mit Torsequenz. Protokolle und beobachtete Nachrichten unter `validation/farm-mario-luigi/`, ausgewählte unbearbeitete Emulatorbilder unter `previews/farm-mario-luigi/`. Die Steuerung, Einsätze, Reitzeit und Eponas Befreiung bleiben durch unveränderten Farm-Aktorcode erhalten. Kein vollständiger Spieldurchlauf und keine Prüfung auf echter N64-Hardware.

Die Grafikprüfung verwendet GLideN64 ohne Software-Clipping und ohne automatische Spieleprofile; die Begründung steht im vorherigen Dialogprüfbericht. Screenshots sind echte Emulatoraufnahmen, keine nachgebauten Textkästen.

# Kokiri-Kapitel: verbindlicher Stand

Der vollständige Textumbau erfolgt Gebiet für Gebiet. Dieses Kapitel umfaßt den Spielanfang, das Kokiri-Dorf und den Deku-Baum einschließlich der dortigen Tutorials und ersten Reaktionen auf den Tod des Baumes. Spätere Gebiete folgen getrennt.

- Alte Rechtschreibung vor 1996; Anrede Du/Dir/Dich/Dein.
- Der vom Spieler gewählte Name wird über das originale NAME-Steuerzeichen eingesetzt. Keine Festschreibung auf „Link“.
- Fiktive Hyrule-Satire: Mr. Burns verkörpert Friedrich Merz, der durch Geld und unsoziale Politik die Macht gewinnen will. Seine Herkunft ist noch nicht erklärt. Hyrule bleibt Hyrule.
- Friedrich Merz hat den Deku-Baum persönlich verflucht, nachdem dieser ihm den Kokiri-Smaragd verweigert hat. Der Fluch wird im Dungeon gebrochen; seine Folgen sind für den Baum bereits tödlich.
- Der Deku-Baum setzt seine Hoffnung auf den jungen Helden. Seine gemeinschaftlichen Vorstellungen werden mit wenigen leisen Anspielungen dargestellt, ohne politische Lehrrede.
- Navi ist bissig, ungeduldig und spöttisch. Ihre Hinweise bleiben sachlich brauchbar.
- Die Dorfbewohner behalten unterscheidbare Stimmen. Salia steht dem Helden nahe. Midos spätere Beschuldigung ist sein ungerechter Verdacht, keine Aussage des Erzählers über die tatsächliche Ursache.
- Kenntnisse berücksichtigen: Der Baum und Navi wissen mehr als die Dorfbewohner. Nicht jeder NPC kennt bereits Merz' Plan.
- Native Message-IDs, Folge-IDs, Ereignis-Markierungen, Auswahlreihenfolgen, Item-Übergaben, Preise, Questbedingungen, Controllerbelegung und Altersregeln erhalten.
- Textbreiten mit der PAL-Schrift und acht breiten Namenszeichen prüfen. Auswahlfelder an den nativen Cursor-Zeilen ausrichten. Zeitgesteuerte Textboxen behalten ihre Verzögerungs-/Ausblendwerte.
- Vor der Auslieferung echte Textboxen und funktionale Interaktionen im Emulator prüfen. Dem Nutzer ausgewählte Ingame-Beispiele zeigen; keine komplette Pointenliste im Chat oder auf der Download-Seite.

## Mr. Bean anstelle Impas

- Sämtliche Impa-Modelle verwenden Bean, einschließlich Reiterkopf, Weiser und Abspann-Varianten. Die übrigen Rollen und Questbedingungen bleiben erhalten.
- Andere Figuren beschreiben ihn als mutig, kompetent und vertrauenswürdig. Ihre benötigten Weg- und Questhinweise bleiben verständlich.
- Bean kommentiert das Geschehen knapp auf Englisch. Er darf mehr sagen als bloße Ausrufe; der Witz entsteht aus trockenen Bemerkungen, eigenwilligen Schlüssen und seiner unbeholfenen Art.
- In der Halle der Weisen spricht er ausführlicher. Er hat Zelda tatsächlich gerettet, nimmt Verantwortung an und hilft dem Helden bewußt. Er ist selbst ein Held auf seine komische Art.
- Seine englischen Texte sind eigene Formulierungen. Ungeprüfte Zeilen nicht als echte Mr.-Bean-Zitate kennzeichnen.
- Beim Wiegenlied tanzt er anstelle des Pfeifens. Lieddemonstration, Eingabe, Erwerb und Questfortsetzung bleiben original.
- Normale deutsche Sprachfassungs-Texte außerhalb dieses Rollenwechsels werden weiter Gebiet für Gebiet bearbeitet. Bean-Verweise dürfen bereits mehrere spätere Gebiete betreffen.

## Erweiterung: Stadt, Farm und Methusa

- Alte Rechtschreibung gilt auch für neue Alltagsgespräche. Stadtbewohner haben unterschiedliche Themen und berücksichtigen ihre nativen Erst-/Wiederholungsgespräche.
- Methusa (deutscher Name von Kaepora Gaebora) spricht nachdenklich, abwägend, mit Selbstkorrekturen und konkreter Wegweisung; sie verrät ihre Identität erst bei der späteren Begegnung in der Halle der Weisen.
- Der Maskenhändler spielt auffällig auf Majoras Maske und ein Waldportal an. Tatsächliche Leihmasken, Shopregeln und Belohnungen bleiben original.
- Navis Deku-Baum-Kommentar beginnt einen Running Gag. Keine Vorwegnahme von Dodongos Höhle oder Jabu-Jabu.
- Thaddäus ist vorläufig nur ein Gerücht aus Zoras Reich. Später soll er die erwachsene Ruto als Weiser des Wassers ersetzen. Junge Ruto bleibt als eigene Figur erhalten. Noch kein Modellaustausch in diesem Kapitel.
- Ein einzelner unbedeutender Bewohner mit Bart (Nachtdialog 7089) bricht den Ton mit einer ausgiebigen Schimpftirade.

## Goronen und Kakariko

- Merz' Kohleabbau ließ den Höhleneingang einstürzen. Dieser narrative Grund ersetzt die frühere Erklärung der Sperre, ohne die Höhlen-/Bombenregeln zu ändern.
- Darunia ist der Goronenführer in Ocarina of Time. Darmani ist hier nicht gemeint.
- Navis Hinweise äußern ihre Meinung zum jeweiligen Geschehen; notwendige Orientierung bleibt enthalten. Der Mund-Rückblick folgt erst nach erhaltenem Goronen-Opal.
- Explizite Nutzerpräferenz: Keine Lesezeiten für Pointen ändern. Statt dessen die Idee kürzen oder in einen vorhandenen normalen Dialog verlegen. Das gilt auch für spätere Kapitel.

## Mario und Luigi

Talon wird durchgängig als Mario, Basil als Luigi angesprochen, auch von anderen Figuren und auf Schildern. Hauptsprache Deutsch in alter Rechtschreibung; Mario hat „Mamma mia!“, „Wahoo!“ und „It's-a me!“, Luigi „Oh, yeah!“, „Luigi-Time!“ und „Let's-a go!“. Keine lautmalerisch verstümmelte deutsche Grammatik. Luigi deutet sämtliche früheren Bosheiten übermäßig positiv um; andere Figuren beschreiben seine aufdringliche Begeisterung. Preise, Auswahlreihenfolge, Rennzustände, Pferdebesitz und Torereignisse bleiben nativ. Zeitgesteuerte Seiten und Ausblendzeiten bleiben erhalten; für einen Witz wird der Text gekürzt, niemals die Szenenzeit verlängert.

## Thaddäus beim Tauchspiel

Nur der Tauchspiel-Leiter ist hier bereits Thaddäus. Er ist ein eingebildeter, genervter Künstler und Klarinettist; Merz ist für ihn ein Geizkragen, der Kunst nicht respektiert. Bei einer Niederlage nennt er den Spieler einen traurigen Clown. Seine privaten deutschen Texte 0136/0138/013B klonen die originalen Steuerzeichen ausschließlich in unbenutzte Textplätze; Schießbuden und andere Händler behalten ihre gemeinsam genutzten Texte. Einstiegspreis 20 Rubine, 50 Sekunden, fünf Rubine vor der Schuppe und zehn danach, native Belohnung und Speicherflags bleiben bestehen. Feste Lesezeiten niemals für einen Gag verlängern. Rutos spätere Ablösung wird erst in einer späteren Revision umgesetzt.

## Zoras und Jabu-Jabu

König Zora ist ein ahnungsloser Herrscher, der Merz den Saphir für Klimaanlagen versprochen hat. Ruto flieht mit dem Stein vor dem Deal, versteckt sich in Jabu-Jabu und taucht nach der Übergabe unter. Ihr späterer Thronsaal-Auftritt entfällt nur in der deutschen Fassung nach erhaltenem Saphir; die übrigen jungen und erwachsenen Ruto-Auftritte bleiben. Der Wundererbsenhändler ist ein Merz verehrender Scalper; die native Preisleiter von 10 bis 100 Rubinen bleibt unverändert. Navis Zieltexte 0600 bis 065C sind durchgehend individuelle Beleidigungen und enthalten keine taktischen Anweisungen. Die harmlose, ratlose Frage „Vore? Was soll das sein?“ wird nicht sexuell ausgeführt.

Privattexte: 0130 ist der Laubkerl in Jabu-Jabu (Vorlage 10A0), 013C Barinades neue Begrüßung (002D), 013E die dortige Kartenmeldung (0066) und 013F Navis Nachspiel-Kommentar. Der bestehende Guidehinweis 014A reagiert auch schon auf eine mitgeführte Flaschenpost. 013F benötigt den tatsächlich erhaltenen Saphir und ist als Guidehinweis bis zu Zeldas Flucht verfügbar. Navis gewöhnliche Gelegenheiten und Abklingzeiten bleiben nativ. Barinades neue Box ist frei weiterklickbar; bestehende Text-, Titel- und Szenenzeiten werden nicht verlängert.

## Drei Steine, Flucht und Masterschwert

Merz nennt das Kind einen kleinen Pascha, fordert später die CDU-Stimme und rechtfertigt sein Handeln mit dessen Zukunft. Nach dem Schwertziehen sagt er, er habe Mr. Bean ermordet, Bean habe gut gekämpft und sei mit Ehre gestorben; Zelda sei entkommen. Diese neue Aussage wird nur in Merz' bestehender Rede 700A eingefügt. Ihre vier festen Seiten behalten BOX_BREAK_DELAYED(60/90/80) und FADE(50). Andere Bean-Auftritte werden hier nicht umgebaut.

Neue Stadtreaktionen verwenden die nativen Nach-Flucht-IDs 7044/7046–704B/704D/70EB. Der verschachtelte Jabu-/Maskenmiet-Gag gehört dem Mann mit alternativem Schnurrbart (Typ 12), die Volkshelden-Aussage dem alten Mann (Typ 7). Der sterbende Soldat ist nur im nativen Zeitfenster nach der Flucht und vor dem Masterschwert ansprechbar; Event-Markierung und Tod bleiben erhalten. Der Krugraum-Soldat bekommt tags und nachts denselben Zerstörungshumor.

Navi: Privattext 0120 mit nativen Guide-Steuerzeichen aus 0148. Nur deutsch, nur erwachsen und mit erhaltenem Masterschwert, nur über normale Guide-Gelegenheiten. Nach Gesprächsbeginn markiert der Navi-Akteur das reservierte freie Bit 0x1CF in infTable-Wort 28 als gehört; kein Eingriff in normale Hinweiszeiten. Nicht für andere Zwecke wiederverwenden. Alte Rechtschreibung; keine Verlängerung fester Lesezeiten.

## Robert Habeck in der Halle der Weisen

Rauru ist Robert Habeck, durch Merz vom Todesberg gestoßen und bereits tot. Die bisherige Methusa war seine solarbetriebene Geistereule. Er betont diesen Umstand umständlich. Hyrule-Zeitung, örtlich begrenzte Energieinseln, Merz' Sperren, Hallenmagie, Stasis von Held und Navi, mitwachsende Kleidung, Muskelerhalt, schimmelige Ausrüstung, die an exakt sieben Jahre gebundene Zeitreise und die betonfeste Zitadelle werden ausdrücklich erklärt. Die Aussage „Friedrich Merz erzählt“ in der Nutzeranweisung wird im Zusammenhang als Habecks Rede verstanden.

704F läuft über die freien Textplätze 0121 → 0122 → 0123 weiter. Jede Fortsetzung bleibt innerhalb des Textpuffers. Keine zusätzlichen Text-/Kameratimer; die vorhandene Cutscene wartet auf das manuelle Abschließen der Textkette. 7051 behält Ja/Nein und 7052 den Rücksprung auf 7051. Questhinweise, Lichtamulett, Rückkehr und spätere Freigabe der Zeitreise bleiben nativ.

Der Turmbewohner EnHy Typ 12 ist in Kakariko nur erwachsen vorhanden. Als erlaubter Ersatz fungiert der Dachbewohner En_Ani: 5050/5051 erzählen in der Kindheit tags/nachts vom beobachteten Sturz des Mannes im schwarzen Anzug. Seine Erwachsenen-, Masken- und Herzteil-Zweige bleiben unangetastet. 0124 bleibt Navis ursprünglicher Wüstenkoloss-Text und wird keinesfalls überschrieben.

## Nintendo 64 in Jabu-Jabus Innerem

Genau ein kleines Dekoobjekt auf der unteren Plattform von Raum 3, bei der ersten Wiederbegegnung mit Ruto nach dem Sturz. Gehäusebreite 10 Spieleinheiten, etwa ein Viertel der Körperhöhe von Kinder-Link; Controller, Kabel und Kassette mit einheitlichem Faktor. Der vorhandene Zelda-Aufkleber bleibt erhalten. Kein Riesenmodell.

Privater Text 0125 mit Vorlage 0148, hellblau: „Ein Nintendo 64 mit Zelda Ocarina of Time... Ich tu mal so, als hätte ich das nicht gesehen.“ Native Zielerfassung mit Z und Lesen mit C-Up über Elf_Msg2. Kein globales Überschreiben eines Gegnertextes. Keine Schalter-/Itemwirkung, wiederholt untersuchbar, andere Sprachen ohne diese neue Instanz. Bisherige Szenen und Habecks TEXTID-Kette unverändert erhalten.

LEGO X-Wing: kleines Spielzeug im Schattentempel, 24 Einheiten Spannweite; Mann im blauen Hemd im erwachsenen Kakariko bekommt 507B/507C. Dachbewohner unverändert. 599 Nachrichten insgesamt, beide vorhandenen manuellen Seiten bleiben erhalten.

Navi-Gegner-Roasts: direkt, konkret auf gegnerisches Verhalten bezogen und deutlich derber. Nicht jeder Text muß fluchen. Keine beliebigen Persönlichkeits-/Konzeptvergleiche; natürliche Wut, kurze Drohungen gegen die fiktiven Monster und Spott über ihre dummen Angriffe. Alle 93 Seitenzahlen und 599 Nachrichten insgesamt bleiben erhalten.

Zora-Gags: 402D/402E nach Jabu-Jabu verwenden jetzt die Nutzerideen Mido-Haß und den kurzen merkwürdigen Musikklang beim Verlassen der Höhle. Ersetzt werden nur meine allgemeinen Ruto-/Tierarzt-Zusätze. Eigene Ideen des Nutzers haben Vorrang. 599 Nachrichten insgesamt.

Texttempo: Die zuletzt ausdrücklich gewünschte Verdoppelung betrifft nur den Schriftaufbau gewöhnlicher deutscher Seiten; feste Lese-/Szenenzeiten bleiben nativ.

Hyrule-Stadt-Nachschlag: 27 vorher originale Nachrichten ersetzt; 7017 auf Wunsch um den Gesichts-Gag der En_Hy-Typ-1-Frau erweitert, ihren Farmwegweiser erhalten. 28 Änderungen dieser Revision, insgesamt 626. Alle anderen bisherigen Nutzertexte erhalten. En_Mu verwendet seinen nativen Fünferpool; Bettler- und Hundezustände behalten Item-/Belohnungsregeln. Keine Änderung der NPC-Sichtbarkeit oder Marktplatzkamera.

Alltagsgags: sechs neue Nutzerideen, neun vorher originale Textzustände (506A/B, 5077/78, 7002/03/06, 7120/21). Zimmerleute Typ 2/3, Hyrule-Nachtwachen, Schloßtorwache und zwei Ladenbesucher. Insgesamt 635; bisherige 626 eigene Texte erhalten. Native Zeit-/Zoll-/Torregeln erhalten.

NPC-Stimmen: Deku-Ball beim alten Mann, Bartwachs beim roten Schnurrbart und Zuständigkeitsfragen bei der Todesberg-Wache. Spinnenfamilie mit ratlosem Fluchdialog ohne das ausdrücklich zurückgenommene ‚fucking‘. Irrlichtsammler ist erzählerisch die frühere Krugraum-Wache; zerstörte Stadt als bitterer Rückbezug. Private deutsche Begrüßungen 0127/012C/012D für Basar/Tränke/Krabbelminen, 012E für Schießbuden. Originale Preise/Quests/Belohnungen und dynamische Zähler erhalten. 46 zusätzliche Einträge und Kokiri-Nachtrag 100A, insgesamt 681.


Eule/Tagesgags: alle 34 En_Owl-Textplätze samt TEXTID-Fortsetzungen haben eigene Dialoge; 33 Stimmen nochmals geschärft. Keine Identitätsenthüllung vor der Halle der Weisen, bestehende Kontrollsequenzen/Zeiten erhalten. Zitteraal-Gag nun ältere Marktfrau Typ 6 (7021/22/704A), Bean-Rettungsgag Mann im schwarzen Oberteil Typ 4 (7023/24/704B), beide tagsüber auch in Wiederholungen ohne Flasche erreichbar. Nachtwachen 7003 betonen ihren Nachtdienst. Kerngag aus bedingtem Flaschenkäufertext 700C entfernt; Handel/Preise erhalten. Merz nennt Bean bei jeder Erwähnung „Herr Bohne“ (2019/201E/700A), alle anderen Figuren bleiben bei Mr. Bean. Weiterhin 681.

Okto, der Oktorok: zusätzlicher friedlicher NPC rechts im Jabu-Jabu-Eingangsraum, Parameter 7F00. Dialog 00F8 klont den normalen 0022-Typ; Vorstellung, Vorurteils-Gag und Distanzierung vom großen Oktorok. Wiederholbar, ohne Quest/Bezahlung. Nur Okto ist NPC, kein Gegner, keine Angriffs- oder Trefferkollision, kein Raum-Clear-Gegner. Normale Gegner und großer Oktorok unverändert. Auch nach geräumtem Raum vorhanden. Vorherige 681 Texte erhalten, jetzt 682.

Platzkorrektur Okto: tatsächliche Wasseroberfläche in Raum 0, (140,-330,0), statt trockenem alten Standort. Nativer Wasserpegel und Wasserringe; vom trockenen Ufer ansprechbar, vor und nach Raum-Clear. Alle 682 Texte bytegleich erhalten.

Wald-Auftakt: gleicher entspannter Kokiri als Erwachsener 105F/1076; Boris erst vorgestern Treppe an Windmühle heruntergestürzt, behauptet langjährige Rennsportkarriere und Catchphrase Uga Paluga. Nicht rückwirkend bestätigen! Shiek alte Freundin mehrdeutig, mit Arbeits-/Rollen-/Glückshinweisen. Waldweise später Krabbelminen-Frau nach Modellimport; Phantom-Ganon später Amthor mit Smithers-Modell. Details planning/WALDKAPITEL.md. 695 eigene Nachrichten.

Mido Zukunft 1060/1061/1068: findet Spieler nach sieben Jahren weiter scheiße, dynamischer Name, Verabredung mit König Zora für mögliche Siegesfeier nach Merz-Niederlage. Native Liedprüfung/Wegfreigabe erhalten. Jetzt 698 eigene Nachrichten.

Waldweise: Krabbelminen-Frau erst nach Waldtempel enthüllen. Erwachsene Proportionen mit eigenem Skelett, später Siegel und Credits auf Darunias Schultern. Junge Salia bleibt. 706 eigene Nachrichten. Thaddäus als Wasserweiser und Nabooru-Ersatz weiterhin Zukunftspläne, vor jedem Modell neue Szenenspeicherprüfung.

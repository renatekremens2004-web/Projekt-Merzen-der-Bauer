# Figurenstimmen und Quellen

Dr. Heinz Doofenshmirtz: eigene deutsche Dialoge, keine vorgeblichen Serien-Zitate. Als Ausgangspunkt dienen seine ausschweifenden, mit Kränkungen aus der Kindheit begründeten Erfindungen, seine Monologe, die Namen auf „-inator“ und seine Feindschaft mit Perry. Gimmelshtump/Drusselstein sind Bestandteile seiner Serienherkunft. Die Angelverbote, Jauchegruben und der Angelinator sind die vom Nutzer gewünschte neue Hyrule-Geschichte.

Die erfolgreiche, gefährlichere Version aus der zweiten Dimension ist in der Filmhandlung ein tatsächlich herrschender Tyrann. Das gelieferte Augenklappen-Modell bildet hier den älteren Angelteich-Betreiber ab: ernste, zusammenhängende Texte über soziale Kälte, die Entlastung der Besitzenden, Arbeitsdruck und beschädigte Lebensräume. Die Hyrule-Ereignisse sind die eigene satirische Handlung des ROMhacks. Keine zusätzlichen Dimensionen oder neue Portal-Quest durch diesen Figurenwechsel.

Gelesene Quellen:

- [Dr. Doofenshmirtz – Charakter, Herkunft und Erfindungen](https://en.wikipedia.org/wiki/Heinz_Doofenshmirtz)
- [Across the 2nd Dimension – Rolle der gefährlicheren Parallelversion](https://en.wikipedia.org/wiki/Phineas_and_Ferb_the_Movie:_Across_the_2nd_Dimension)

Shrek spricht direkt, genervt und territorial. Er meint mit seinem Rauswurf zunächst Merz und erlaubt dem Kind zu bleiben. Sein feuchtes Waldstück soll einer Erschließung weichen. Er steht ausschließlich in der Kindheitszeit an der trockenen Uferseite des Waldraums mit dem Wasserbecken.

Mr. Monopoly verteidigt Gewinnanreiz, Investitionen, Eigentum und Wettbewerb. Danach trennt er einen besiegbaren Herrscher von der fortbestehenden menschlichen Gier und denkt am Ende bereits an Hotels im Schloß. Seine Worte sind seine Figurenmeinung innerhalb des Dialogs.

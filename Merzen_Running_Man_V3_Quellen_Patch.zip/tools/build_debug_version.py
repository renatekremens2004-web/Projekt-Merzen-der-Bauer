"""Optional FINAL builder for a separate PAL 1.0 debug edition; --restore removes it.

Keep DEBUG_FEATURES=0. Run after build_shadow_tunic.py, not in normal releases.
"""
from pathlib import Path
import argparse

R = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('oot', type=Path)
parser.add_argument('--restore', action='store_true')
args = parser.parse_args()
O = args.oot.resolve()
B = R / 'tools/originals/debug-version'
FILES = [
    'src/code/graph.c', 'src/code/z_sram.c',
    'src/overlays/gamestates/ovl_select/z_select.c',
    'src/overlays/misc/ovl_kaleido_scope/z_kaleido_scope.c',
    'src/overlays/misc/ovl_kaleido_scope/z_kaleido_debug.c',
]
for rel in FILES:
    p = B / rel
    if not p.exists():
        assert not args.restore
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes((O / rel).read_bytes())
    if args.restore:
        (O / rel).write_bytes(p.read_bytes())
if args.restore:
    print('Normal production sources restored; rebuild to produce a normal ROM.')
    raise SystemExit

def replace(s, old, new):
    assert s.count(old) == 1, old
    return s.replace(old, new)

def original(rel):
    return (B / rel).read_text()

rel = FILES[0]
s = original(rel)
needle = 'GameStateOverlay* Graph_GetNextGameState(GameState* gameState) {'
s = replace(s, needle, '/* Debug-edition session state; never stored in SRAM. */\ns32 gModDebugSaveReady = false;\n\n' + needle)
old = '''#if DEBUG_FEATURES
    if (gIsCtrlr2Valid && CHECK_BTN_ALL(gameState->input[0].press.button, BTN_Z) &&
        CHECK_BTN_ALL(gameState->input[0].cur.button, BTN_L | BTN_R)) {
        gSaveContext.gameMode = GAMEMODE_NORMAL;
        SET_NEXT_GAMESTATE(gameState, MapSelect_Init, MapSelectState);
        gameState->running = false;
    }

    if (gIsCtrlr2Valid && PreNmiBuff_IsResetting'''
new = '''/* Controller 1: hold L+R and press Z, in gameplay/title/file selection.
     * Do not interrupt an already scheduled state transition or the menu itself. */
    if (gameState->running &&
        ((gameState->destroy == Play_Destroy) || (gameState->destroy == FileSelect_Destroy)) &&
        CHECK_BTN_ALL(gameState->input[0].press.button, BTN_Z) &&
        CHECK_BTN_ALL(gameState->input[0].cur.button, BTN_L | BTN_R)) {
        if (gSaveContext.gameMode != GAMEMODE_NORMAL) {
            gModDebugSaveReady = false;
        } else if (gameState->destroy == Play_Destroy) {
            Play_SaveSceneFlags((PlayState*)gameState);
        }
        gSaveContext.gameMode = GAMEMODE_NORMAL;
        SET_NEXT_GAMESTATE(gameState, MapSelect_Init, MapSelectState);
        gameState->running = false;
    }

#if DEBUG_FEATURES
    if (gIsCtrlr2Valid && PreNmiBuff_IsResetting'''
s = replace(s, old, new)
(O / rel).write_text(s)

rel = FILES[1]
s = original(rel)
needle = '    gSaveContext.save.info.checksum.value = 0;'
# A title-started native debug save has no real SRAM slot (fileNum=0xFF).
pos = s.index('void Sram_WriteSave(')
assert needle in s[pos:]
s = s[:pos] + s[pos:].replace(needle, '    /* Temporary debug sessions have no SRAM slot. */\n    if (gSaveContext.fileNum == 0xFF) return;\n\n' + needle, 1)
(O / rel).write_text(s)

rel = FILES[2]
s = original(rel)
s = replace(s, '#include "sram.h"', '#include "sram.h"\n#include "interface.h"\n\nextern s32 gModDebugSaveReady;')
s = replace(s, 'extern s32 gModDebugSaveReady;', 'extern s32 gModDebugSaveReady;\n\n/* Translate this menu only; leave the engine-wide translation switch alone. */\n#undef T\n#define T(jp, en) en')
s = replace(s, '    if (gSaveContext.fileNum == 0xFF) {\n        Sram_InitDebugSave();',
'''    if (gSaveContext.fileNum == 0xFF && !gModDebugSaveReady) {
        Sram_InitDebugSave();
        gModDebugSaveReady = true;''')
needle = '    gSaveContext.buttonStatus[0] = gSaveContext.buttonStatus[1] = gSaveContext.buttonStatus[2] ='
s = replace(s, needle, '''    else if (gSaveContext.save.linkAge != this->unk_234) {
        s32 selectedAge = gSaveContext.save.linkAge;
        s32 i;
        ItemEquips* child = &gSaveContext.save.info.playerData.childEquips;
        /* A fresh adult debug session has never populated the child cache. */
        if (selectedAge == LINK_AGE_CHILD && child->buttonItems[0] == ITEM_NONE) {
            child->buttonItems[0] = ITEM_SWORD_KOKIRI;
            for (i = 1; i < 4; i++) {
                child->buttonItems[i] = ITEM_NONE;
                child->cButtonSlots[i - 1] = SLOT_NONE;
            }
            child->equipment = (EQUIP_VALUE_SWORD_KOKIRI << (EQUIP_TYPE_SWORD * 4)) |
                               (EQUIP_VALUE_TUNIC_KOKIRI << (EQUIP_TYPE_TUNIC * 4)) |
                               (EQUIP_VALUE_BOOTS_KOKIRI << (EQUIP_TYPE_BOOTS * 4));
            if (CHECK_OWNED_EQUIP_ALT(EQUIP_TYPE_SHIELD, EQUIP_INV_SHIELD_DEKU)) {
                child->equipment |= EQUIP_VALUE_SHIELD_DEKU << (EQUIP_TYPE_SHIELD * 4);
            }
        }
        /* The native swap routine expects the OLD age, like Play_Destroy. */
        gSaveContext.save.linkAge = this->unk_234;
        Inventory_SwapAgeEquipment();
        gSaveContext.save.linkAge = selectedAge;
    }
''' + needle)
s = replace(s, '    this->unk_234 = 0;', '    this->unk_234 = gSaveContext.save.linkAge; /* original age for loadout swap */')
s = replace(s, '    gSaveContext.save.linkAge = LINK_AGE_CHILD;\n}', '}')
s = replace(s, '''#if PLATFORM_N64
    { "64DD TEST  n64dd_SetDiskVersion(1)", (void*)func_80800AD0_unknown, 0 },
    { "64DD TEST2 n64dd_SetDiskVersion(0)", (void*)func_80800B08_unknown, 0 },
#endif''', '')
s = replace(s, '"ZELDA MAP SELECT"', '"MERZEN DEBUG"')
names = ['Hyrule-Feld', 'Kakariko', 'Friedhof', 'Zora-Fluss', 'Kokiri-Wald', 'Waldlichtung', 'Hylia-See', 'Zora-Reich', 'Zora-Quelle', 'Gerudo-Tal', 'Verlorene Waelder', 'Wuestenkoloss', 'Gerudo-Festung', 'Gespensterwueste', 'Schloss Hyrule', 'Todesberg-Pfad', 'Todeskrater', 'Goronia', 'Lon-Lon-Farm']
import re
for i, name in enumerate(names):
    s, n = re.subn(r'"\s*' + str(i + 1) + r':SPOT\d+"', '"%2d:%s"' % (i + 1, name), s)
    assert n == 1
s = replace(s, '''static const char* sAgeLabels[] = {
    T(GFXP_HIRAGANA "17(ﾜｶﾓﾉ)", "17(young)"),
    T(GFXP_HIRAGANA "5(ﾜｶｽｷﾞ)", "5(very young)"),
};''', 'static const char* sAgeLabels[] = { "Erwachsen", "Kind" };')
s = replace(s, '    GfxPrint_Printf(printer, "Age:%s", sAgeLabels[age]);', '    GfxPrint_Printf(printer, "B:%s", sAgeLabels[age]);')
s = replace(s, '    GfxPrint_Printf(printer, "OPT=%d", this->opt);', '    GfxPrint_Printf(printer, "A:Laden L:Seite");')
s = replace(s, '    GfxPrint_Printf(printer, "Stage:" GFXP_KATAKANA "%s", label);', '    GfxPrint_Printf(printer, "Z/R: %s", label);')
(O / rel).write_text(s)

rel = FILES[3]
s = replace(original(rel), '''#if DEBUG_FEATURES
        pauseCtx->debugState = PAUSE_DEBUG_STATE_INVENTORY_EDITOR_OPENING;
#endif''', '        pauseCtx->debugState = PAUSE_DEBUG_STATE_INVENTORY_EDITOR_OPENING;')
(O / rel).write_text(s)

rel = FILES[4]
# The dormant native editor wrapped upward to row 22, outside its 11-row table.
s = replace(original(rel), '            curRow = 22;', '            curRow = ARRAY_COUNT(sRowFirstSections) - 1;')
s = replace(s, '#include "z_kaleido_scope.h"', '#include "z_kaleido_scope.h"\n#include "array_count.h"')
s = replace(s, '#include "translation.h"', '#include "translation.h"\n#undef T\n#define T(jp, en) en')
# Keep labels short enough for the original fixed-width number columns.
for before, after in [('Rupee', 'Rub.'), ('Heart', 'HP'), ('Equipment', 'Upgr.'),
                      ('Sword', 'SW'), ('Shield', 'SH'), ('Seal', 'Weise'),
                      ('Spiritual Stone', 'Steine'), ('Ocarina', 'Lied'),
                      ('Collect', 'Extra'), ('Skulltula', 'Sk.'), ('Gold Token', 'HP')]:
    s = replace(s, '"' + before + '"', '"' + after + '"')
(O / rel).write_text(s)
print('Separate debug edition applied to five files; retail DEBUG_FEATURES stays 0.')

#ifndef SHADOW_TUNIC_H
#define SHADOW_TUNIC_H

/* Reserved mod infTable bit; 0x1CF remains Navi's separate heard flag.
 * No save structure, checksum range or existing inventory slot is extended.
 */
#define SHADOW_TUNIC_FLAG 0x1CE
#define SHADOW_TUNIC_OWNED() GET_INFTABLE(SHADOW_TUNIC_FLAG)
#define SHADOW_TUNIC_ACTIVE() \
    (SHADOW_TUNIC_OWNED() && CUR_EQUIP_VALUE(EQUIP_TYPE_TUNIC) == EQUIP_VALUE_TUNIC_KOKIRI)

#endif

from pathlib import Path
import re,json,subprocess,wave,hashlib
import numpy as np
W=Path('/workspace/goron-bomb-v23/audio-video');A=Path('/workspace/artifacts');s=(W/'record.log').read_text()
a=re.search(r'VIDEO_BEGIN f=(\d+) audio_samples=(\d+) rate=(\d+)',s);b=re.search(r'VIDEO_END f=(\d+) frames=(\d+) audio_samples=(\d+) rate=(\d+)',s);c=re.search(r'AUDIO_SWITCH f=(\d+) samples=(\d+)',s)
assert a and b and c and 'completed: 0' in s
f0,start,rate=map(int,a.groups());f1,count,end,rate1=map(int,b.groups());switch,switchsample=map(int,c.groups());assert rate==rate1 and count==f1-f0==700
raw=(W/'native.s16le').read_bytes()[start*4:end*4];audio=np.frombuffer(raw,dtype='<i2').reshape(-1,2).astype(np.float64)/32768
assert len(raw)==(end-start)*4
rms=np.sqrt(np.mean(audio**2));peak=np.max(np.abs(audio));assert .0005<rms<.5 and peak<=1,(rms,peak)
videoDuration=count*3/50;audioDuration=(end-start)/rate;assert abs(audioDuration-videoDuration)<.15,(audioDuration,videoDuration)
with wave.open(str(W/'native-trimmed.wav'),'wb')as w:w.setnchannels(2);w.setsampwidth(2);w.setframerate(rate);w.writeframes(raw)
t=(switch-f0)*3/50
(W/'title-slow.txt').write_text('Goronia vor dem Feuertempel: 30 % Musiktempo')
(W/'title-normal.txt').write_text('Vergleich: normales Musiktempo')
(W/'note.txt').write_text('Feuer-Amulett nur im Testspielstand gesetzt')
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
filters=[f"drawtext=fontfile={font}:expansion=none:textfile={W/'title-slow.txt'}:fontsize=16:fontcolor=white:box=1:boxcolor=black@0.75:boxborderw=6:x=(w-tw)/2:y=9:enable='lt(t,{t})'",f"drawtext=fontfile={font}:expansion=none:textfile={W/'title-normal.txt'}:fontsize=16:fontcolor=white:box=1:boxcolor=black@0.75:boxborderw=6:x=(w-tw)/2:y=9:enable='gte(t,{t})'",f"drawtext=fontfile={font}:expansion=none:textfile={W/'note.txt'}:fontsize=12:fontcolor=white:box=1:boxcolor=black@0.75:boxborderw=3:x=(w-tw)/2:y=31:enable='gte(t,{t})'"]
out=A/'Goronia_Bombe_V23_Test_mit_Ton.mp4'
subprocess.run(['ffmpeg','-y','-v','error','-i',str(W/'picture.mp4'),'-i',str(W/'native-trimmed.wav'),'-map','0:v:0','-map','1:a:0','-vf',','.join(filters),'-c:v','libx264','-preset','medium','-crf','18','-c:a','aac','-b:a','192k','-ar','48000','-af','apad','-t',str(videoDuration),'-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True)
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(out)],text=True));assert len(meta['streams'])==2 and any(x['codec_type']=='audio' for x in meta['streams']);assert abs(float(meta['format']['duration'])-videoDuration)<.1
proof={'file':out.name,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'rom_sha256':hashlib.sha256(Path('/workspace/goron-bomb-v23/normal/oot-pal-1.0-compressed.z64').read_bytes()).hexdigest(),'ram_bytes':4194304,'native_AI_DMA_PCM':True,'audio_rate':rate,'audio_rms':float(rms),'audio_peak':float(peak),'frames':count,'pal_fps':'50/3','video_seconds':videoDuration,'captured_audio_seconds':audioDuration,'normal_tempo_comparison_at_seconds':t,'fire_medallion_set_only_in_controlled_test_save':True,'audio_time_stretch_or_pitch_shift':False,'original_bomb_and_flower_positions':True,'streams':[{k:x[k]for k in ['codec_type','codec_name','sample_rate','channels','duration']if k in x}for x in meta['streams']]}
(W/'verification.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))

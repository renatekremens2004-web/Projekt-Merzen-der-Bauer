#include "m64p_plugin.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
static AUDIO_INFO info;
static FILE* out;
static uint64_t samples;
static unsigned rate;
EXPORT m64p_error CALL PluginStartup(m64p_dynlib_handle core, void* ctx, void (*cb)(void*,int,const char*)) {return M64ERR_SUCCESS;}
EXPORT m64p_error CALL PluginShutdown(void){if(out){fclose(out);out=NULL;}return M64ERR_SUCCESS;}
EXPORT m64p_error CALL PluginGetVersion(m64p_plugin_type* type,int* version,int* api,const char** name,int* caps){if(type)*type=M64PLUGIN_AUDIO;if(version)*version=0x10000;if(api)*api=0x020000;if(name)*name="Native AI PCM capture";if(caps)*caps=0;return M64ERR_SUCCESS;}
EXPORT int CALL InitiateAudio(AUDIO_INFO a){info=a;return 1;}
EXPORT int CALL RomOpen(void){out=fopen("/workspace/goron-bomb-v23/audio-video/native.s16le","wb");samples=0;return out!=NULL;}
EXPORT void CALL RomClosed(void){if(out){fclose(out);out=NULL;}}
EXPORT void CALL AiDacrateChanged(int system){unsigned clock=system==1?49656530u:system==2?48628316u:48681812u;rate=clock/(*info.AI_DACRATE_REG+1);printf("AUDIO_RATE system=%d dac=%u hz=%u sample=%llu\n",system,*info.AI_DACRATE_REG,rate,(unsigned long long)samples);}
EXPORT void CALL AiLenChanged(void){unsigned addr=*info.AI_DRAM_ADDR_REG&0xffffff,len=*info.AI_LEN_REG&0x3fff8;if(!out||addr+len>0x400000)return;for(unsigned i=0;i<len;i+=4){uint32_t w;__builtin_memcpy(&w,info.RDRAM+addr+i,4);int16_t pair[2]={(int16_t)(w>>16),(int16_t)w};fwrite(pair,4,1,out);}samples+=len/4;}
EXPORT void CALL ProcessAList(void){}
EXPORT void CALL SetSpeedFactor(int percent){}
EXPORT void CALL VolumeUp(void){}
EXPORT void CALL VolumeDown(void){}
EXPORT int CALL VolumeGetLevel(void){return 100;}
EXPORT void CALL VolumeSetLevel(int level){}
EXPORT void CALL VolumeMute(void){}
EXPORT const char* CALL VolumeGetString(void){return "100%";}
EXPORT uint64_t CaptureAudioSamples(void){return samples;}
EXPORT unsigned CaptureAudioRate(void){return rate;}

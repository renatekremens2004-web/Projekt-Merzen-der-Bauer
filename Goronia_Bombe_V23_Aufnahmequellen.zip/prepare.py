from pathlib import Path
W=Path('/workspace/goron-bomb-v23');V=W/'audio-video';s=(W/'runner.c').read_text();s=s.replace('static void onframe(unsigned f){','static void baseframe(unsigned f){')
a=s.index(' if(strstr(scenario,"navi")');b=s.index(' if(buttons)buttons(value);',a)
s=s[:a]+''' if(f>=80 && f<370){value=0x20;if(f==125)value|=0x800;if(f==220 || f==360)value|=0x80;}
 if(f==500){DebugMemWrite32(savebase+0xa4,r32(savebase+0xa4)|2);printf("COMPARISON_FIRE_MEDALLION_SET relative_frame=%u\\n",f);}
'''+s[b:]
a=s.index('static void setting(')
video='''static uint64_t (*audioSamples)(void);
static unsigned (*audioRate)(void);
static FILE* video;
static unsigned pending=0,total=0,stopQueued=0;
static void capture_render(void){
 static unsigned char pixels[640*480*3];
 if(!pending)return;
 if(CoreDoCommand(M64CMD_READ_SCREEN,0,pixels))exit(94);
 if(!video){video=popen("ffmpeg -y -v error -f rawvideo -pixel_format rgb24 -video_size 640x480 -framerate 50/3 -i - -an -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p /workspace/goron-bomb-v23/audio-video/picture.mp4 2>/workspace/goron-bomb-v23/audio-video/encoder.log","w");if(!video)exit(94);}
 for(int y=479;y>=0;y--)if(fwrite(pixels+y*640*3,1,640*3,video)!=640*3)exit(94);
 pending=0;total++;
}
static void onframe(unsigned f){
 baseframe(f);
 if(f<550)return;
 if(f==550)printf("VIDEO_BEGIN f=%u audio_samples=%llu rate=%u\\n",f,(unsigned long long)audioSamples(),audioRate());
 if(f==1000)printf("AUDIO_SWITCH f=%u samples=%llu\\n",f,(unsigned long long)audioSamples());
 if(f>=1250){if(!pending&&!stopQueued){printf("VIDEO_END f=%u frames=%u audio_samples=%llu rate=%u\\n",f,total,(unsigned long long)audioSamples(),audioRate());stopQueued=1;CoreDoCommand(M64CMD_STOP,0,NULL);}return;}
 if(pending)exit(94);pending=1;
}

'''
s=s[:a]+video+s[a:];s=s.replace('NULL,"/workspace/bean-rider/test_input.so"','"/workspace/goron-bomb-v23/audio-video/capture_audio.so","/workspace/wallace-cheer/record_input.so"')
s=s.replace('if(i==3)buttons=dlsym(plugin,"TestSetButtons");','if(i==2){audioSamples=dlsym(plugin,"CaptureAudioSamples");audioRate=dlsym(plugin,"CaptureAudioRate");}if(i==3){buttons=dlsym(plugin,"TestSetButtons");void(*setCapture)(void(*)(void))=dlsym(plugin,"TestSetRenderCapture");setCapture(capture_render);}')
s=s.replace('printf("SCENARIO %s completed: %d\\n",scenario,r);','if(video && pclose(video)!=0)return 96;printf("SCENARIO %s completed: %d\\n",scenario,r);')
(V/'runner.c').write_text(s)

"""Compact CI4 N64 geometry exporter. Rigid own-bone transforms, no runtime mesh stretching."""
from pathlib import Path
import math,itertools
from PIL import Image

def emit(m,modeldir,prefix,rigged=False):
 n=len(m['bones'])
 lines=['/* Supplied model: own proportions and unit-scale poses. */']
 def u64(name,data):
  data+=bytes((-len(data))%8);lines.append('static u64 '+name+'[]={');lines.extend('0x'+data[i:i+8].hex().upper()+',' for i in range(0,len(data),8));lines.append('};')
 def rgba16(c):
  r,g,b=c[:3];return ((r>>3)<<11)|((g>>3)<<6)|((b>>3)<<1)|int(len(c)<4 or c[3]>=128)
 texspec=[]
 for i,mat in enumerate(m['materials']):
  im=Image.open(modeldir/mat['texture']).convert('RGBA').resize(tuple(mat.get('size',(64,64))),Image.Resampling.LANCZOS)
  im=im.quantize(colors=16,method=Image.Quantize.FASTOCTREE,dither=Image.Dither.NONE);pal=im.getpalette('RGBA');pal+=([0]*(64-len(pal)));data=list(im.getdata());u64('gMODELPalette%d'%i,b''.join(rgba16(pal[j:j+4]).to_bytes(2,'big') for j in range(0,64,4)));u64('gMODELTex%d'%i,bytes((data[j]<<4)|data[j+1] for j in range(0,len(data),2)));texspec.append(im.size);im.save(modeldir/('n64_'+mat['name']+'.png'))
 
 vertices=[];commands=[]
 for mat,(w,h) in enumerate(texspec):
  commands+=['gsDPPipeSync(),','gsDPSetTextureLUT(G_TT_RGBA16),','gsDPLoadTLUT_pal16(0,gMODELPalette%d),'%mat,'gsDPLoadTextureBlock_4b(gMODELTex%d,G_IM_FMT_CI,%d,%d,0,G_TX_WRAP,G_TX_WRAP,%d,%d,G_TX_NOLOD,G_TX_NOLOD),'%(mat,w,h,round(math.log2(w)),round(math.log2(h)))]
  tris=[t for t in m['triangles'] if t['material']==mat]
  batches=[];local=[];lookup={};faces=[]
  for t in tris:
   corners=[]
   for c in t['corners']:
    v=m['vertices'][c['vertex']];data={'bone':v['bone'],'position':v['position'],'normal':c['normal'],'uv':[round(c['uv'][0]*w*32-16),round((1-c['uv'][1])*h*32-16)]};key=(data['bone'],*data['position'],*data['normal'],*data['uv']);corners.append((key,data))
   if len(set(lookup)|{k for k,v in corners})>32:
    batches.append((local,faces));local=[];lookup={};faces=[]
   face=[]
   for key,data in corners:
    if key not in lookup:lookup[key]=len(local);local.append(data)
    face.append(lookup[key])
   faces.append(face)
  if faces:batches.append((local,faces))
  for local,faces in batches:
   assert len(local)<=32
   order=sorted(range(len(local)),key=lambda j:local[j]['bone']);slots={v:i for i,v in enumerate(order)}
   for bone,itr in itertools.groupby(order,key=lambda j:local[j]['bone']):
    group=list(itr);off=len(vertices);vertices.extend(local[j] for j in group)
    if rigged:commands+=['gsSPMatrix((Mtx*)0x%08X,G_MTX_NOPUSH|G_MTX_LOAD|G_MTX_MODELVIEW),'%(0x0d000000+bone*64)]
    commands+=['gsSPVertex(&gMODELVertices[%d],%d,%d),'%(off,len(group),slots[group[0]])]
   for j in range(0,len(faces),2):
    if j+1<len(faces):commands+=['gsSP2Triangles(%d,%d,%d,0,%d,%d,%d,0),'%tuple(slots[k] for f in faces[j:j+2] for k in f)]
    else:commands+=['gsSP1Triangle(%d,%d,%d,0),'%tuple(slots[k] for k in faces[j])]
 lines+=['static Vtx gMODELVertices[]={']
 for v in vertices:
  assert all(-32768<=x<=32767 for x in v['position']+v['uv']);lines.append('{{{%d,%d,%d},0,{%d,%d},{%d,%d,%d,255}}},'%tuple(v['position']+v['uv']+[x&255 for x in v['normal']]))
 lines+=['};','static Gfx gMODELEmptyDL[]={gsSPEndDisplayList()};',('static Gfx gMODELBodyDL[]={' if rigged else 'Gfx gMODELDL[]={'),'gsDPPipeSync(),','gsDPSetCycleType(G_CYC_2CYCLE),','gsSPTexture(0xffff,0xffff,0,0,G_ON),','gsDPSetRenderMode(G_RM_FOG_SHADE_A,G_RM_AA_ZB_TEX_EDGE2),','gsSPClearGeometryMode(G_CULL_FRONT|G_CULL_BACK|G_TEXTURE_GEN|G_TEXTURE_GEN_LINEAR),','gsSPSetGeometryMode(G_LIGHTING|G_SHADE|G_SHADING_SMOOTH|G_ZBUFFER|G_FOG),','gsDPSetCombineLERP(TEXEL0,0,SHADE,0,0,0,0,TEXEL0,0,0,0,COMBINED,0,0,0,COMBINED),','gsDPSetPrimColor(0,0,255,255,255,255),','gsDPSetTextureFilter(G_TF_BILERP),']+commands+['gsSPEndDisplayList(),','};']
 for i,b in enumerate(m['bones']):
  children=[j for j,x in enumerate(m['bones']) if x['parent']==i];siblings=[j for j,x in enumerate(m['bones']) if x['parent']==b['parent']];sib=siblings[siblings.index(i)+1] if siblings.index(i)+1<len(siblings) else 255
  lines+=['static StandardLimb gMODELLimb%d={{%d,%d,%d},%d,%d,%s};'%tuple([i]+b['position']+[children[0] if children else 255,sib,'gMODELBodyDL' if i==n-1 else 'gMODELEmptyDL'])]
 if rigged:lines+=['static void* gMODELLimbs[]={'+','.join('&gMODELLimb%d'%i for i in range(n))+'};','FlexSkeletonHeader gMODELSkel={{gMODELLimbs,%d},%d};'%(n,n)]
 for label in m.get('animations',{}):
  name=label.title().replace('_','')
  frames=m['animations'][label];channels=[[p['root'][k] for p in frames] for k in range(3)]+[[p['rotation'][b][k] for p in frames] for b in range(n) for k in range(3)];constants=[]
  for ch in channels:
   if len(set(ch))==1 and ch[0]%65536 not in constants:constants.append(ch[0]%65536)
  data=list(constants);indices=[]
  for ch in channels:
   if len(set(ch))==1:indices.append(constants.index(ch[0]%65536))
   else:indices.append(len(data));data.extend(x%65536 for x in ch)
  lines+=['static s16 gMODEL%sFrames[]={%s};'%(name,','.join('0x%04X'%v for v in data)),'static JointIndex gMODEL%sJoints[]={'%name];lines+=['{%d,%d,%d},'%tuple(indices[i:i+3]) for i in range(0,len(indices),3)];lines+=['};','AnimationHeader gMODEL%sAnim={{%d},gMODEL%sFrames,gMODEL%sJoints,%d};'%(name,len(frames),name,name,len(constants))]
 return ('\n'.join(lines)+'\n').replace('gMODEL','g'+prefix)

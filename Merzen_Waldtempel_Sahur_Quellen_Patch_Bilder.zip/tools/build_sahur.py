"""Own fixed-proportion Sahur rig for the German adult Deku Sprout role."""
from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();A=O/'extracted/pal-1.0/assets/objects/object_dekujr';B=ROOT/'originals/sahur'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
from n64_model import emit
m=json.loads((ROOT/'sahur_source.json').read_text());assert len(m['bones'])==25
(A/'sahur_model.inc.c').write_text(emit(m,ROOT.parent/'models/sahur','Sahur',True))
p=A/'object_dekujr.c';p.write_text(original(p)+'\n#include "sahur_model.inc.c"\n');p=A/'object_dekujr.h';p.write_text('#include "animation.h"\n'+original(p)+'\nextern FlexSkeletonHeader gSahurSkel;\nextern AnimationHeader gSahurIdleAnim;\n')
p=O/'src/overlays/actors/ovl_Obj_Dekujr/z_obj_dekujr.h';s=original(p).replace('#include "actor.h"','#include "actor.h"\n#include "animation.h"');s=s.replace('} ObjDekujr; // size = 0x01A4','    /* German role only; original cue and dialogue state stays at native offsets. */\n    SkelAnime sahurSkelAnime;\n} ObjDekujr;');p.write_text(s)
p=O/'src/overlays/actors/ovl_Obj_Dekujr/z_obj_dekujr.c';s=original(p);needle='        Actor_SetScale(thisx, 0.4f);';assert s.count(needle)==1;s=s.replace(needle,needle+'''
        if (gSaveContext.language == LANGUAGE_GER) {
            SkelAnime_InitFlex(play, &this->sahurSkelAnime, &gSahurSkel, &gSahurIdleAnim, NULL, NULL, 0);
            Actor_SetScale(thisx, 0.01f);
            this->collider.dim.radius = 18;
            this->collider.dim.height = 54;
        }''');s=s.replace('void ObjDekujr_Destroy(Actor* thisx, PlayState* play) {\n}', '''void ObjDekujr_Destroy(Actor* thisx, PlayState* play) {
    ObjDekujr* this = (ObjDekujr*)thisx;
    if (this->sahurSkelAnime.skeleton != NULL) {
        SkelAnime_Free(&this->sahurSkelAnime, play);
    }
}''');needle='    Collider_UpdateCylinder(&this->actor, &this->collider);';s=s.replace(needle,'''    if (this->sahurSkelAnime.skeleton != NULL) {
        SkelAnime_Update(&this->sahurSkelAnime);
    }
'''+needle);s=s.replace('void ObjDekujr_Draw(Actor* thisx, PlayState* play) {','static void ObjDekujr_DrawNative(Actor* thisx, PlayState* play) {');s+='''
void ObjDekujr_Draw(Actor* thisx, PlayState* play) {
    ObjDekujr* this = (ObjDekujr*)thisx;
    if (this->sahurSkelAnime.skeleton == NULL) {
        ObjDekujr_DrawNative(thisx, play);
        return;
    }
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    SkelAnime_DrawFlexOpa(play, this->sahurSkelAnime.skeleton, this->sahurSkelAnime.jointTable,
                         this->sahurSkelAnime.dListCount, NULL, NULL, this);
}
''';p.write_text(s)
print('Sahur: 1436 triangles, 25 own rigid bones, 54-unit height, native rise/talk/progression unchanged.')

# Aktuelle Dialoge: nach Dodongo bis zum Master-Schwert

Stand: 21. Oktober 2026, eingebauter deutscher PAL-1.0-Stand V17. Dies ist eine reine Abschrift zum Durchgehen und Umschreiben. Die fünf zuletzt gewünschten Texte sind im Stand V17 enthalten; diese Abschrift zeigt den aktuellen Wortlaut.

Beginn: Darunias Auftritt nach König Dodongo. Ende: Merz’ kurze Rede unmittelbar nach dem Ziehen des Master-Schwerts (700A), noch vor dem Erwachen/Gespräch mit Robert Habeck in menschlicher Gestalt (704E).

Jede vierstellige Nummer ist eine Text-ID. Jede Seite und jede Auswahl bleibt einzeln erkennbar; [Spielername] ist dynamisch. Angezeigt wird der tatsächliche deutsche Wortlaut einschließlich vorhandener Originaltexte. Die Hauptgeschichte und ihre bedingten Alternativen stehen zuerst; frei erreichbare Nebenbegegnungen und Gegner-Zielerfassung folgen im Anhang. Diese Varianten werden nicht alle automatisch hintereinander abgespielt.

**Zum Bearbeiten:** Beispielsweise „401A, Seite 2 neu: …“ oder „013F ersetzen durch …“.

## Inhaltsübersicht

- 1. Nach König Dodongo – Darunia, Goronen-Opal und Umarmung
- 2. Todesberg-Gipfel – Goronen, Große Fee und Eule
- 3. Navi nach Dodongos Höhle und Salias frühe Rückmeldungen
- 4. Eule auf dem Weg und am Zora-Fluß
- 5. Zoras Reich – Bewohner, Prinzessin und König vor der Flaschenpost
- 6. Thaddäus – Tauchspiel, Schuppe und alle Spielausgänge
- 7. Flaschenpost, Navi und König Zora rückt beiseite
- 8. In Jabu-Jabu – Ruto begegnen, tragen und suchen
- 9. Navi – örtliche Hinweise in Jabu-Jabu
- 10. Ruto findet den Saphir – Plattform und großer Oktorok
- 11. Barinade – Begrüßung vor dem Kampf
- 12. Nach Barinade – Ruto, Zora-Saphir und Abschied
- 13. Nach Jabu-Jabu – König Zora, Bewohner, Navi und Salia
- 14. Flucht vor dem Schloß – Friedrich Merz spricht Link an
- 15. Okarina im Graben – Zelda und die Hymne der Zeit
- 16. Optionaler Abschied – sterbender Soldat in der Gasse
- 17. Zitadelle der Zeit – Inschrift und Navi vor dem Schwert
- 18. Nach dem Ziehen des Master-Schwerts – Merz, noch vor Habeck
- A. Wundererbsenverkäufer – sämtliche Preise, Ablehnung und Wiederholung
- B. Frösche am Zora-Fluß – normale Liedbelohnung
- C. Hylia-See als Kind – Eule, Forscher und normaler Doofenshmirtz
- D. Neue Begegnungen in Jabu-Jabu – Okto und Nintendo 64
- E. Deku-Händler in Jabu-Jabu und der besondere Kartentext
- F. Wichtige Fundtexte – Schuppe, Brief/Flasche, Bumerang, Kompaß und Fisch
- G. Stadtbewohner nach der Flucht – neue Reaktionen und Gerüchte
- H. Wache im Krughaus – Tages- und Nachttext
- I. Navi-Zielerfassung – Gegner dieses Abschnitts
- J. Gespeicherte Zusatzvariante – Ruto neben dem König
- K. Alte Zusatzzeile ohne nachgewiesenen Gesprächsaufruf

## 1. Nach König Dodongo – Darunia, Goronen-Opal und Umarmung

### 3023

Projekttext.

**Seite 1**

> Bruder, Du hast es geschafft! Du
> hast die Dodongos und das ganze
> andere Gesindel darin bezwungen.

**Seite 2**

> Merz hat uns Wohlstand versprochen,
> und dann ging hier alles nach hinten
> los. Wir hätten ihm nicht vertrauen
> sollen.

### 3048

Projekttext.
Native kurze Zwischenzeile der Darunia-Szene; bislang Originaltext.

**Seite 1**

> Dieses Abenteuer bietet Stoff für
> eine Legende. Ich nenne sie: Die
> Legende von [Spielername]!

**Seite 2**

> Ich bin immer noch völlig fassungslos.
> Hätten wir Merz weiter vertraut,
> wären schlimme Dinge passiert.

**Seite 3**

> Angeblich ging es ihm um Kohleabbau.
> Aber ich weiß, daß es ihm um viel,
> viel mehr als nur Kohle ging.

### 3004

Projekttext.

**Seite 1**

> Du bist absolut korrekt, Kleiner.
> Deswegen ernenne ich Dich hiermit
> zum Ehren-Goronen.

**Seite 2**

> Und jetzt nimm den Goronen-Opal.
> Aber bitte verlier ihn nicht.

### 0081

Projekttext.

**Seite 1**

> Der Goronen-Opal!
> Von den Goronen wurde Dir
> dieser Heilige Stein
> des Feuers übergeben!

**Seite 2**

> Verlier ihn bloß nicht!

### 3000

Projekttext.

**Seite 1**

> Nun sind wir Blutsbrüder. Zwei Heilige
> Steine hast Du, und den dritten
> bekommst Du von...

**Seite 2**

> Oh, ja. Dann mußt Du wohl mit König
> Zora reden. Ich kann den Typen nicht
> leiden.

### 3001

Projekttext.
Alternative nach dem Goronen-Opal, falls dieser ausnahmsweise der dritte Heilige Stein ist. Im normalen Verlauf zeigt die Szene 3000.

**Seite 1**

> Wie hast Du es geschafft, jetzt
> schon diesen Stein als dritten Stein
> zu bekommen? Das ist Sequence
> Breaking!

### 3068

Projekttext.

**Seite 1**

> Ich kann Dich übrigens noch an eine
> Freundin von mir verweisen.

**Seite 2**

> Sie hat vielleicht ein sehr schrilles
> Auftreten und ist sehr dezent
> bekleidet, aber sie hat mich bisher
> noch nie im Stich gelassen. Sie lebt

**Seite 3**

> auf dem Gipfel des Todesbergs.

**Seite 4**

> Freunde! Verabschiedet unseren
> Bruder VORSICHTIG. Er ist ein Kind.
> Ihr brecht ihm sonst noch die
> Knochen!

### 3005

Projekttext.
Zeitgesteuerte Textcodes: FADE(30). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> LEUTE! VORSICHT!

### 3006

Projekttext.
Zeitgesteuerte Textcodes: FADE(30). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> DAS IST EIN KIND, ALTER!

### 3027

Projekttext.

**Seite 1**

> Danke, Bruder! Wir können wieder
> Steine essen. Den Kohlenstaub darf
> Merz sich selbst auf den Teller
> kippen.

### 3067

Projekttext.

**Seite 1**

> Du hast den Roten Stein? Darf ich
> ein winziges Stück probieren?

**Seite 2**

> Nein? Schon gut. Bei Merz nennt man
> das offenbar geschütztes
> Privatvermögen.

### 301E

Projekttext.

**Seite 1**

> Hier ging es um weit mehr als nur
> Kohle. Merz war auch an radioaktivem
> Material interessiert. Sei vorsichtig.

### 301F

Projekttext.

**Seite 1**

> Dieser Merz führt etwas Böses im
> Schilde.

Text 0081 ist oben bereits vollständig enthalten.

## 2. Todesberg-Gipfel – Goronen, Große Fee und Eule

### 3064

Projekttext.

**Seite 1**

> Wenn ich am Strand schwimmen
> gehe, sterbe ich.

### 3065

Projekttext.

**Seite 1**

> Die Fee auf dem Gipfel hilft Dir
> bestimmt. Paß nur auf, der ganze
> Berg ist eine Todesfalle.

**Seite 2**

> Macht ja auch Sinn. Das Ding heißt
> ja auch Todesberg oder Todesgipfel
> oder so was.

### 00D7

Projekttext.

**Seite 1**

> Ah, [Spielername], ich sehe, mein
> bester Kunde Darunia schickt Dich.

**Seite 2**

> Mit Kunde meine ich, daß ich
> Aufträge von ihm annehme. Ich bin
> nämlich Video-Editor. Nicht das, was
> Du gedacht hast. Prostitution ist

**Seite 3**

> scheiße.

**Seite 4**

> Ich verleihe Dir mit meiner Macht
> eine neue Schwert-Technik. Sei
> bereit!

### 00DD

Projekttext.

**Seite 1**

> Du beherrschst die kraftvolle
> Wirbelattacke!

**Seite 2**

> Halte [B] gedrückt, um Dein
> Schwert aufzuladen. Laß [B]
> los, um einen energiegeladenen
> Rundumschlag auszuführen!

**Seite 3**

> Bewegst Du [Control-Pad] einmal im Kreis
> und drückst dann [B], kannst Du
> die Wirbelattacke sofort und ohne
> Wartezeit ausführen.

**Seite 4**

> Yo, rastet nicht zu sehr aus, bitte.

### 00DB

Projekttext.
Gemeinsame Heilungsnachricht bei erneutem Fee-Besuch.

**Seite 1**

> [Spielername], Du siehst ja schon
> wieder komplett dreckig aus. Keine
> Sorge, ich kann meine Magie
> benutzen.

### 00DA

Projekttext.
Gemeinsamer Große-Fee-Abschied.

**Seite 1**

> Paß auf, Du hast nur ein Leben.
> Schmeiß das bitte nicht weg.

### 3062

Projekttext.

**Seite 1**

> Der Gipfel, [Spielername]. Das ist
> eine Leistung. Ich will die
> Anstrengung dahinter gar nicht
> kleinreden.

**Seite 2**

> Die Wolken zeigen, wie es dem Berg
> geht. Weiß heißt Frieden. Das ist ein
> Indikator, keine dauerhafte Garantie.

**Seite 3**

> Mut hast Du bewiesen. Nun wäre es
> vernünftig, Unterstützung anzunehmen.
> Das ist keine Schwäche.

**Seite 4**

> Hier lebt die Mutter aller Feen. Such
> sie auf. Manche Investitionen in die
> eigene Zukunft bezahlt zum Glück
> jemand anders.

**Seite 5**

> Danach kann ich Dich zum Fuß des
> Berges bringen. Der Abstieg muß
> nicht dieselbe Belastung haben wie
> der Aufstieg.

### 3063

Projekttext.

**Seite 1**

> Die Fee hat Dir geholfen. Jetzt hast
> Du mehr Möglichkeiten. Das ist erst
> einmal ein Zugewinn an
> Handlungsspielraum.

**Seite 2**

> Energie muß verfügbar sein, wenn
> man sie braucht. Nur zu behaupten,
> man habe welche, hilft im Ernstfall
> wenig.

**Seite 3**

> Für den Flug zum Fuß des Berges
> halte Dich an meinen Krallen fest. Da
> möchte ich beim Sicherheitskonzept
> keine Interpretationsspielräume.

## 3. Navi nach Dodongos Höhle und Salias frühe Rückmeldungen

### 0135

Projekttext.
Natürlicher Navi-Storyruf nach dem Goronen-Opal. Er übersteuert in Deutsch 0148/0149. V10: bisherigen Höhlen-Rückblick behalten, nur Mund-im-Mund gestrichen; der neue Goronia-abgehakt-Satz folgt am Ende.

**Seite 1**

> Wir waren schon wieder in einem
> Mund! Dodongos Höhle lag in einem
> riesigen Gerippe.

**Seite 2**

> Und kurz vor dem Boß mußten wir
> auch noch durch einen gewaltigen
> Dodongo-Schädel.

**Seite 3**

> So, Goronia wäre damit auch
> abgehakt. Lief doch bis jetzt ganz
> gut, oder? Können wir jetzt
> aufhören?

### 0148

Projekttext.
Gespeicherter Grundzustand. Neuer Goronia-abgehakt-Wortlaut; derselbe Satz steht auch in der tatsächlich angebotenen 0135. Keine neue oder doppelte automatische Ansprache.

**Seite 1**

> So, Goronia wäre damit auch
> abgehakt. Lief doch bis jetzt ganz
> gut, oder? Können wir jetzt
> aufhören?

### 0149

Projekttext.
Neuer Blutmagie-/Salia-Besuch-Spruch, aber weiterhin gespeicherter Grundzustand: nach dem Opal in Deutsch durch 0135 ersetzt. Wird dort nicht zusätzlich angehängt.

**Seite 1**

> Salia hat uns mit dieser Blutmagie
> echt geholfen. Was sie wohl noch
> alles weiß?

**Seite 2**

> Laß sie aber nur im zwingenden
> Notfall besuchen. Ich hab keinen Bock,
> da jetzt hinzulatschen.

### 0162

Projekttext.
Salias Lied rufen: frühe Reaktion auf Darunias Tanz/Armband. Kann schon vor dem hier gesetzten Abschnitt vorkommen.

**Seite 1**

> Ja, es gibt in Hyrule sehr wenig
> Leute mit dieser Blutgruppe. Wer
> hätte gedacht, daß gerade Darunia die
> hat?

**Seite 2**

> Haben Goronen überhaupt Blut? Hast
> Du jemals einen Goronen bluten
> sehen, [Spielername]? Ich schon.

### 0163

Projekttext.
Salias Lied rufen: Hinweis auf den noch fehlenden Wasserstein.

**Seite 1**

> Okay, jetzt fehlt ja nur noch ein
> Stein. Das ist schon mal echt ganz
> gut, also super.

**Seite 2**

> Nur blöderweise mußt Du jetzt diesen
> nervigen Zora-König kennenlernen.
> Also, ja. Sagen wir mal so.

### 0164

Projekttext.
Ältere Zustandsvariante bei fehlendem Fortschritt; kein zusätzlicher Satz jedes Anrufs.

**Seite 1**

> Jetzt kommt der Heilige Stein des
> Feuers. Das hat mir der Deku-Baum
> letzte Woche erzählt.

## 4. Eule auf dem Weg und am Zora-Fluß

### 206F

Projekttext.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(40). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> [Spielername], mehrere Wege. Das
> ist erst einmal Freiheit. Und im
> zweiten Schritt eine ziemlich
> konkrete Entscheidung.

**Seite 2**

> Man merkt erst, wie wichtig Wasser
> ist, wenn es fehlt. Oder wenn jemand
> beschließt, daß es ein Luxusgut sein
> soll.

**Seite 3**

> Eine Brücke verbindet zwei Ufer.
> Politisch klingt das hervorragend.
> Baulich wäre ich schon froh, wenn sie
> einfach stehenbleibt.

**Seite 4**

> Man kann nicht jede Richtung
> gleichzeitig einschlagen. Außer
> rhetorisch. Aber davon kommst Du
> hier nicht weiter.

### 2070

Projekttext.

**Seite 1**

> Zuversicht heißt nicht, daß alles gut
> wird. Zuversicht heißt, daß es einen
> Unterschied macht, ob Du etwas tust.

### 4031

Projekttext.
Zora-Fluß-Eule, wenn Salias Lied UND Zeldas Wiegenlied bekannt sind; das ist bei normalem Fortschritt nach Dodongo die passende Variante.

**Seite 1**

> Ah, [Spielername]. Mehr Erfahrung,
> mehr Kraft. Wobei mehr Kraft allein
> die Frage nach dem Zugang noch
> nicht beantwortet.

**Seite 2**

> Vor Dir liegt Zoras Reich. Die Zoras
> schützen das Wasser. Das ist
> Daseinsvorsorge, wenn man so will.

**Seite 3**

> Sie lassen einen königlichen
> Abgesandten hinein. Berechtigtes
> Vertrauen braucht hier einen hörbaren
> Nachweis.

**Seite 4**

> Spiele vor dem Portal das Schlaflied
> der Königsfamilie. In diesem Fall ist
> Musik tatsächlich der Schlüssel. Ganz
> ohne Übertragung.

### 4017

Projekttext.
Alternative der Fluß-Eule: Salias Lied bekannt, Zeldas Wiegenlied noch nicht bekannt.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(40). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Ah, [Spielername]. Da bist Du ja.

**Seite 2**

> Du hast Fortschritte gemacht. Das
> ist sichtbar. Nun müssen daraus auch
> die richtigen nächsten Schritte folgen.

**Seite 3**

> Hast Du den Goronen-Opal? Dann
> möchte Zelda Dich sicher
> wiedersehen. Wir sollten Erfolge auch
> kommunizieren.

**Seite 4**

> Kurz durchatmen ist vernünftig.
> Dauerhaft stehenbleiben wäre
> hingegen keine tragfähige Strategie.

### 4002

Projekttext.
Alternative der Fluß-Eule: Salias Lied noch nicht bekannt.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(40). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> [Spielername], bevor Du
> weitergehst, eine Frage zur sozialen
> Lage.

**Seite 2**

> Wie geht es Salia? Besuch sie doch.
> Beziehungen sind keine Infrastruktur,
> die man einmal baut und dann nie
> mehr wartet.

## 5. Zoras Reich – Bewohner, Prinzessin und König vor der Flaschenpost

### 4006

Projekttext.

**Seite 1**

> Willkommen in Zoras Reich! Diese
> Höhle ist nur ein Teil davon. Unser
> Reich geht natürlich noch viel, viel
> weiter ins Wasser.

**Seite 2**

> Man kann sagen, der Großteil des
> Wassers ist eigentlich unser Reich.
> Mit Unterwasseranlagen und so was,
> ne?

### 4007

Projekttext.

**Seite 1**

> Wir können hervorragend tauchen.
> Leider können wir dadurch auch jede
> königliche Fehlentscheidung von unten
> betrachten.

**Seite 2**

> Thaddäus veranstaltet ein Tauchspiel.
> Seine Laune kann ohnehin nicht
> schlechter werden.

### 4008

Projekttext.
Erstansprache; Wiederholungs-ID: 4009.

**Seite 1**

> Ein Großteil des Wassers wird durch
> die Zora-Eier, die Zora-Balls des
> Königs gefiltert.

**Seite 2**

> Der sitzt da einfach. Guck Dir das
> mal an. Das ist seltsam.

### 4009

Projekttext.
Wiederholung bei erneutem Ansprechen nach 4008.

**Seite 1**

> Ruto ist noch sehr klein und
> trotzdem läuft sie freiwillig im
> Inneren von Jabu-Jabu herum.
> Seltsame Vorlieben.

**Seite 2**

> Keine Ahnung, ob den König das
> interessiert. Den juckt das irgendwie
> nicht, glaube ich.

### 400A

Projekttext.

**Seite 1**

> Ja, ich mag Rockmusik, die ist total
> cool, ich rock total gerne ab.
> Rock'n'Roll, Leute!

### 400B

Projekttext.
Wiederholung bei erneutem Ansprechen nach 402F.

**Seite 1**

> Noch einmal: Rock'n'Roll, Leute!

### 400C

Projekttext.

**Seite 1**

> Warst Du schon bei Jabu-Jabu?
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 400D

Projekttext.

**Seite 1**

> Wenn Du ihm einen Fisch anbietest,
> macht Jabu-Jabu den Mund auf. Ich
> sage nur, was passiert. Ich empfehle
> es ausdrücklich nicht.

### 400E

Projekttext.

**Seite 1**

> Das ist ein gigantischer Wal, und
> das, was Du über der
> Wasseroberfläche siehst, ist quasi
> nur sein Kopf.

**Seite 2**

> Sein noch viel gigantischerer
> Gigantenkörper ist unter dem Wasser
> verborgen. Das Ding ist wirklich
> riesig, da kannst Du mir vertrauen.

**Seite 3**

> So ein kleines Kind könnte sich da
> bestimmt stundenlang drin verirren.

### 400F

Projekttext.

**Seite 1**

> Ruto ist mit dem Saphir
> verschwunden. Der König sucht sie
> seit Stunden. Also... Er ruft ihren
> Namen, ohne aufzustehen.

### 4010

Projekttext.

**Seite 1**

> Hast Du etwas von Ruto gehört?
> Zeig es dem König. Möglichst
> schriftlich und mit wenigen
> schwierigen Wörtern.

### 4011

Projekttext.

**Seite 1**

> Der Fluß führt bis zum Hylia-See.
> Wenn Ruto untertauchen will, hat sie
> also reichlich Auswahl.

**Seite 2**

> Der König hat als Suchmaßnahme
> angeordnet, daß das Wasser kurz
> stehenbleiben soll. Wir warten noch
> auf die Durchführung.

### 4020

Projekttext.

**Seite 1**

> Sag mal, gibt es eigentlich
> Zora-Frauen? Ich sehe hier immer nur
> Zoras.

**Seite 2**

> Vielleicht lassen sie sich einfach
> schwer unterscheiden. Das wäre
> natürlich eine Erklärung.

**Seite 3**

> Warte mal. Bin ich selbst eine Frau?
> Ich muß mich kurz setzen.

### 4021

Projekttext.

**Seite 1**

> Irgendwo im See hat irgend jemand
> schon wieder seine Bierflasche
> reingeworfen. Diese Hylianer sind echt
> das Letzte.

### 402D

Projekttext.

**Seite 1**

> [Spielername], ich kenn' Mido.
> Richtiger Wichser. Der wollte mir
> erklären, wie man richtig schwimmt.
> MIR. Einem Zora.

### 402E

Projekttext.

**Seite 1**

> [Spielername], hast Du mal drauf
> geachtet, wie sau crazy die Musik für
> 'ne Sekunde klingt, wenn man Zoras
> Höhle verläßt?

### 402F

Projekttext.
Erstansprache; Wiederholungs-ID: 400B.

**Seite 1**

> Friedrich Merz und der König haben
> zusammen getagt. Sie haben einen
> Deal ausgehandelt, der uns
> Klimaanlagen verspricht.

**Seite 2**

> Damit sollen wir vor den
> katastrophalen Auswirkungen des
> Klimawandels in den nächsten sieben
> Jahren geschützt sein.

**Seite 3**

> Er hat ihm dafür unser wertvollstes
> Gut versprochen: die Zora-Trompete.
> Die wollte Merz nicht. Statt dessen
> bekommt er den Saphir.

### 401A

Projekttext.
König Zora als Kind vor dem Vorzeigen von Rutos Brief. V11: Nutzerkorrektur zu Stein gegen kühle Luft; nicht die erwachsene 4013.

**Seite 1**

> Friedrich Merz hat mir Klimaanlagen
> versprochen! Damit retten wir die
> Zoras vor dem Klimawandel. Ich bin
> ein Genie.

**Seite 2**

> Ein Stein gegen kühle, entspannende
> Luft. Ah, wie angenehm. Fast so
> angenehm wie das Wasser, das
> zwischen meinen Beinen durchläuft.

**Seite 3**

> Aber meine Tochter ist mit dem
> Stein abgehauen, und ich kann sie
> nicht finden. Die kommt bestimmt
> bald zurück und gibt ihn mir wieder.

**Seite 4**

> Die kriegt sich immer ein.

## 6. Thaddäus – Tauchspiel, Schuppe und alle Spielausgänge

### 4053

Projekttext.

**Seite 1**

> Was will denn irgendein Rotzbalg
> hier? Ich bin der große Thaddäus
> Quentin Tentakel, meines Zeichens
> Künstler. Leider bin ich von

**Seite 2**

> Kulturbanausen umgeben.

**Seite 3**

> Friedrich Merz vor allem. Der kann
> mit Kunst überhaupt nichts anfangen.
> Wenn der Hyrule übernimmt, Junge,
> dann werde ich mir keine einzige

**Seite 4**

> Klarinettenstunde mehr leisten
> können.

**Seite 5**

> Die ich sowieso nicht brauche, weil
> ich schon perfekt bin. Na ja, egal.
> Hier ist das Tauchspiel.

**Seite 6**

> Eine Runde kostet 20 Rubine. Na?
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4054

Projekttext.

**Seite 1**

> Wunderbar. Ein zahlender Störenfried.
> Welch seltener Glücksfall.

**Seite 2**

> Ich werfe fünf Rubine hinunter.
> Sammle sie alle ein, bevor die Zeit
> abläuft. Möglichst ohne Deine übliche
> Zirkusnummer.

**Seite 3**

> Komm danach zu mir zurück. Dann
> gibt es eine Belohnung.

### 405A

Projekttext.
Kurze Startanzeige des Tauchspiels: Let’s go!

**Seite 1**

> Let's go!

### 405B

Projekttext.

**Seite 1**

> Spring den Wasserfall hinab. Dort
> liegen die Rubine. Und hier oben liegt
> mir langsam Dein Anblick auf den
> Nerven.

### 4055

Projekttext.
Siegmeldung unten im Wasser; Belohnung oben abholen.

**Seite 1**

> Ah, Du hast gewonnen. Super. Na ja,
> ich gucke mal, was ich hier habe.
> Komm hoch, dann kriegst Du Deine
> Belohnung.

### 4056

Projekttext.
Eigentliche Übergabe der Schuppe; hier steht der neue Massenproduktions-Kommentar.

**Seite 1**

> Ja, ich habe hier etwas. Die Dinger
> sind massenproduziert. Habe eine
> ganze Sammlung von den
> Scheißdingern.

**Seite 2**

> Silberne Schuppen. Habe ich
> massenhaft bestellt. Hier, nimm eine.
> Damit kannst Du tiefer tauchen.

### 00CD

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Die Silberne Schuppe!
> Begib Dich ins Wasser und
> drücke [A]. Jetzt kannst Du
> tiefer tauchen als zuvor!

### 405C

Projekttext.

**Seite 1**

> Ah, Du schon wieder. Willst Du es
> nochmal ausprobieren? Die silberne
> Schuppe hast Du ja schon.

**Seite 2**

> Noch eine Runde für 20 Rubine?
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 405D

Projekttext.

**Seite 1**

> Schon wieder gewonnen.
> Hervorragend. Meine Begeisterung ist
> nur gerade in der Mittagspause.

### 0136

Projekttext.
Tauchspiel verloren.

**Seite 1**

> Junge, Du hast verloren, Du trauriger
> Clown.

**Seite 2**

> Aha, haha! Trauriger... Ha ha ha!
> Clown!

### 0138

Projekttext.
Zu wenige Rubine für das Tauchspiel.

**Seite 1**

> Nicht einmal 20 Rubine hast Du.
> Lächerlich. Such Dir einen Job, Alter.

### 013B

Projekttext.
Tauchspiel abgelehnt.

**Seite 1**

> Endlich eine Entscheidung mit
> künstlerischem Wert: Du läßt mich in
> Ruhe.

## 7. Flaschenpost, Navi und König Zora rückt beiseite

### 0099

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Eine Flasche!
> Fülle etwas hinein und nutze
> sie mit [C]... Oh! Da ist ja
> bereits etwas drin!

### 4005

Projekttext.

**Seite 1**

> In der Flasche steckt ein Brief. Er
> riecht nach Fisch. Überraschung.

**Seite 2**

> Ich verstecke mich im Inneren von
> Jabu-Jabu vor Friedrich Merz. Hier
> sucht er mich bestimmt nicht.

**Seite 3**

> Der würde sich niemals schmutzig
> machen. Und hier ist wirklich alles
> voller Schleim. Ein hervorragendes
> Versteck!

**Seite 4**

> Ruto. PS: Verrate meinem Vater
> nichts. Er hat meinen Saphir schon
> jemandem versprochen, ohne mich zu
> fragen.

### 014A

Projekttext.
Natürlicher Navi-Storyruf, solange Rutos Brief in einer Flasche steckt und der Zora-Saphir fehlt.

**Seite 1**

> Och nee, oder? Die ist jetzt nicht
> ernsthaft in diesem scheiß Fisch
> drin?

**Seite 2**

> Ich schwör, wenn wir da jetzt
> reinmüssen, dann raste ich aus! Wir
> waren schon im Baum und durch
> einen riesigen Schädel!

### 401B

Projekttext.
Brief vorgezeigt; König liest ihn und gibt den Durchgang frei.
Direkte native Fortsetzung: 401C.

**Seite 1**

> Was ist denn das? Wie, meine
> Tochter, meine Prinzessin ist einfach
> in diesem riesigen Fisch, unserem
> heiligen Jabu-Jabu? Scheiße.

**Seite 2**

> Hoffentlich wird sie nicht verdaut.

**Seite 3**

> Ich würde ja selbst reingehen, aber
> ich muß hier aufpassen. Kannst Du
> das vielleicht übernehmen? Dann
> werde ich mich auch erkenntlich

**Seite 4**

> zeigen. Wahrscheinlich.

**Seite 5**

> Wobei, so viel Geld habe ich aktuell
> nicht. Ich habe Friedrich Merz schon
> eine ganze Menge gegeben. Im
> Zora-Königreich sind harte Zeiten

**Seite 6**

> angebrochen.

**Seite 7**

> Warte, laß mich kurz meinen Arsch
> aus dem Weg schieben. Einen
> Moment.

**Seite 8**

> Die Flasche kannst Du übrigens
> wiederhaben. Nimm Deinen Müll
> wieder mit.

### 401C

Projekttext.
Wiederholungszustand nach dem Vorzeigen des Briefs, vor dem Zora-Saphir.

**Seite 1**

> Finde bitte Ruto. Und den Saphir.
> Sonst merkt Merz, daß ich ihm etwas
> verkauft habe, das ich gar nicht habe.

## 8. In Jabu-Jabu – Ruto begegnen, tragen und suchen

### 404B

Projekttext.

**Seite 1**

> Hey! Wer bist Du denn?

**Seite 2**

> Ich bin Ruto, Prinzessin der Zoras.
> Und ich möchte gerade nicht gefunden
> werden.

**Seite 3**

> Mein Vater hat Dich geschickt?
> Großartig. Ein königlicher Suchtrupp
> aus genau einem Kind.

**Seite 4**

> Er hat meinen Saphir Merz
> versprochen. Für Klimaanlagen! Der
> hat doch einen an der Flosse.

**Seite 5**

> Ja, die Flaschenpost ist von mir.
> Normalerweise ist es hier ein bißchen
> sicherer, aber scheinbar hat
> Jabu-Jabu einen Haufen Gegner

**Seite 6**

> gefressen.

**Seite 7**

> Mein Vater ist so ein Idiot. Ich kann
> nicht fassen, daß er unser ganzes
> Königreich in den feuchten Abgrund
> stoßen möchte. Er will, daß das ganze

**Seite 8**

> Königreich den Bach runtergeht.

**Seite 9**

> Deswegen werde ich diesen Stein nur
> über meine Leiche hergeben.

**Seite 10**

> Und jetzt laß mich in Ruhe.

### 404C

Projekttext.

**Seite 1**

> Warum schaust Du so? Es ist völlig
> normal, in einem riesigen Fisch
> herumzulaufen.

**Seite 2**

> Ich bin öfter hier. Andere Kinder
> spielen im Garten. Ich gehe eben
> durch einen Magen.

**Seite 3**

> Vore? Ich verstehe nicht. Was soll
> das sein?

**Seite 4**

> Heute ist es allerdings etwas
> unangenehm. Diese elektrischen
> Quallen gehörten früher nicht zur
> Einrichtung.

**Seite 5**

> Außerdem habe ich den Saphir
> verloren. Solange der hier liegt, gehe
> ich nirgendwohin.

**Seite 6**

> Wenn Du mir helfen willst, dann hilf.

### 404D

Projekttext.

**Seite 1**

> Du willst mir also helfen? Gut.

**Seite 2**

> Ich habe keinen Bock, versehentlich in
> Magensäure oder so einen Mist zu
> treten. Deswegen trag Du mich mal.
> Du hast Schuhe an.

**Seite 3**

> Und laß mich nicht irgendwo liegen.
> Ich bin eine Prinzessin, kein
> vergessener Einkaufsbeutel.

### 404E

Projekttext.

**Seite 1**

> Bist Du wahnsinnig? Ich hätte hier im
> Magen verdaut werden können! Ist
> das überhaupt der Magen?

**Seite 2**

> Ich schätze, wir sind hier in
> verschiedenen Teilen von Jabu-Jabu.
> Links und rechts hat das zum
> Beispiel, glaube ich, irgendwie mit den

**Seite 3**

> Kiemen zu tun. Diese grünen Räume
> wirst Du später noch sehen.

## 9. Navi – örtliche Hinweise in Jabu-Jabu

### 012F

Projekttext.
Örtlicher Navi-Hinweis: Jabu-Jabu, Raum 2.

**Seite 1**

> Hey, [Spielername], das erinnert
> mich an den Typen, der dieses
> Zora-Minispiel leitet. Mit dem
> Tauchen, weißt Du noch?

### 0131

Projekttext.
Örtlicher Navi-Hinweis: Jabu-Jabu, Raum 7.

**Seite 1**

> Guck mal, [Spielername], das ist
> wieder so ein Tentakel, aber diesmal
> in Rot.

### 0132

Projekttext.
Örtlicher Navi-Hinweis: Jabu-Jabu, Raum 7.

**Seite 1**

> Ich habe es vielleicht ein bißchen
> vergessen zu erwähnen,
> [Spielername], aber diese Dinger
> sind voller elektrischer Energie.

### 0133

Projekttext.
Örtlicher Navi-Hinweis: Jabu-Jabu, Raum 7.

**Seite 1**

> Mist, es wäre echt praktisch, wenn
> Du jetzt irgendwie schon, keine
> Ahnung, sieben Jahre älter wärst
> oder so. Für den Schalter bist Du zu

**Seite 2**

> leicht.

### 0137

Projekttext.
Örtlicher Navi-Hinweis: Jabu-Jabu, Raum 7.

**Seite 1**

> Okay, dieses Tentakel-Ding ist jetzt
> weg. War das ein Polyp? Oder war
> das etwas, das zu Jabu-Jabu
> dazugehört?

**Seite 2**

> Könnten wir hier drin ein bißchen
> aufpassen, okay?

### 0139

Projekttext.
Örtlicher Navi-Hinweis: Jabu-Jabu, Raum 5.

**Seite 1**

> Hey, ich glaube, das ist so eine Art
> Schalter. Also ein Teil von seinem
> Körper, der einen Reflex auslöst.

### 013A

Projekttext.
Örtlicher Navi-Hinweis: Jabu-Jabu, Raum 6.

**Seite 1**

> Hey, schau mal, was ist denn das?

## 10. Ruto findet den Saphir – Plattform und großer Oktorok

### 404F

Projekttext.

**Seite 1**

> Da ist der Saphir! Wirf mich sofort
> auf diese Plattform. Wird schon
> schiefgehen.

### 4050

Projekttext.

**Seite 1**

> Ruto hat ihren Heiligen Stein zurück.
> Zeit, aus Jabu-Jabus Arsch zu
> entkommen.

### 4051

Projekttext.

**Seite 1**

> Ich bin so froh, diesen Stein wieder
> zu haben. Der kommt von meiner
> Mutter. Sie ist leider schon sehr früh
> gestorben. Deswegen darf er niemals

**Seite 2**

> in die Hände von Friedrich Merz
> geraten.

**Seite 3**

> Ich bin zwar für eine
> Erbschaftssteuer, aber das heißt ja
> nicht, daß ich diesen Stein hergeben
> muß.

**Seite 4**

> Aber jetzt habe ich ihn wieder. Ich
> glaube, ich werde über das Meer
> verschwinden. Also los.

### 4052

Projekttext.

**Seite 1**

> Los, bringen wir uns hier raus. Ich
> habe für heute genug Anatomie
> gesehen.

### 4048

Projekttext.
Zeitgesteuerte Textcodes: FADE(60). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Igitt! Einer von diesen Oktoroks!
> Aber diesmal ein riesiger!

### 401E

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Ooooh neiiiin!

## 11. Barinade – Begrüßung vor dem Kampf

### 013C

Projekttext.

**Seite 1**

> Hey Leute, ich bin Barinade, wie
> geht's denn so? Ich bring Euch um.

## 12. Nach Barinade – Ruto, Zora-Saphir und Abschied

### 4022

Projekttext.

**Seite 1**

> Da bist Du ja! Wir haben es
> geschafft. Das war vielleicht ein
> Abenteuer sondergleichen.

**Seite 2**

> Das hat ehrlich gesagt echt Spaß
> gemacht, auch wenn wir fast verdaut
> wurden.

### 4023

Projekttext.

**Seite 1**

> Und mein Vater hat nichts davon
> erfahren. Der soll auch weiterhin im
> Dunkeln bleiben, okay?

### 4024

Projekttext.

**Seite 1**

> [Spielername]! [Spielername]!
> Komm mal her!

### 4025

Projekttext.
Antwort 1 wünscht den Heiligen Stein (4026), Antwort 2 einen witzigen Witz (4029). Beide führen unverändert über 4027 zur Übergabe.

**Seite 1**

> Ich hoffe ja echt, daß sich Jabu-Jabu
> von seinen internen Blutungen erholt.
> Aber ich denke, das wird schon
> wieder.

**Seite 2**

> Ich danke Dir vielmals. Du hast mir
> geholfen. Dafür hast Du einen Wunsch
> frei.

**Seite 3**

> Was möchtest Du?
>
> Ich möchte den Heiligen Stein!
> Einen witzigen Witz!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4026

Projekttext.
Direkte native Fortsetzung: 4027.

**Seite 1**

> Du meinst den Zora-Saphir, den mein
> Vater gegen Klimaanlagen tauschen
> wollte?

### 4029

Projekttext.
Direkte native Fortsetzung: 4027.

**Seite 1**

> Treffen sich zwei Zoras. Sagt der
> eine: Hi! Schreit der andere: WO?!

### 4027

Projekttext.

**Seite 1**

> Ja, jetzt werde ich wohl
> untertauchen müssen. Das ist dann
> wohl mein Schicksal. Aber ich opfere
> gerne die Beziehung zu meinem Vater,

**Seite 2**

> um dieses Reich zu retten.

**Seite 3**

> Wenn er merkt, daß Du ihn hast,
> rastet er völlig aus. Sag ihm einfach,
> ich komme gleich. Er glaubt das
> bestimmt.

**Seite 4**

> Hier. Der Zora-Saphir. Bring ihn in
> Sicherheit. Und wenn jemand fragt:
> Du hast mich nie gesehen!

### 0082

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Der Zora-Saphir!
> Von den Zoras wurde Dir
> dieser Heilige Stein
> des Wassers übergeben!

### 4034

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Bedingte Anzeige: zwei Heilige Steine. Bei normalem Ablauf mit Deku-Baum und Dodongo schon erledigt erscheint stattdessen 4035.

**Seite 1**

> Prinzessin Ruto hat Dir ihren
> wertvollsten Schatz gegeben!
> Du besitzt nun zwei Heilige Steine!
> Jetzt fehlt nur noch einer!

### 4035

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Bedingte Anzeige: nun alle drei Heiligen Steine vorhanden.

**Seite 1**

> Prinzessin Ruto hat Dir
> ihren wertvollsten Schatz gegeben!
> Nun besitzt Du die
> drei Heiligen Steine!

**Seite 2**

> Jetzt schnell zu Prinzessin Zelda!

### 4028

Projekttext.

**Seite 1**

> Verrate meinem Vater nichts. Der
> dreht sonst völlig durch.

## 13. Nach Jabu-Jabu – König Zora, Bewohner, Navi und Salia

### 402B

Projekttext.

**Seite 1**

> [Spielername], meine Tochter
> kommt bestimmt bald zurück. Nur
> noch wenige Minuten. Gleich ist es
> soweit. Bald.

### 4033

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Du hast Prinzessin Ruto gefunden!
> Jetzt wird Dir König Zora sicher
> den Heiligen Stein des Wassers
> geben...

**Seite 2**

> Oder etwa nicht?

### 013F

Projekttext.
Natürlicher Navi-Storyruf nach Erhalt des Zora-Saphirs und vor Zeldas Flucht. Er übersteuert dort den normalen Hinweis 014B.

**Seite 1**

> [Spielername], ich weiß, wir haben
> hier eine Mission und so. Aber
> glaubst Du ernsthaft, daß Jabu-Jabu
> das überleben wird?

**Seite 2**

> All die Gewalt und das
> Herumgespringe in seinem Inneren!
> Junge, hast Du den Endboß gesehen?

**Seite 3**

> Wir haben in Jabus Herz, oder was
> das auch immer war, alles komplett
> zerstört. Das Vieh ist dem Tod
> geweiht.

**Seite 4**

> Laß uns lieber verschwinden, bevor
> jemand fragt, wessen Idee das war.

### 014B

Projekttext.
Grundzustand für drei Steine; in der deutschen Phase vor der Flucht durch 013F übersteuert.

**Seite 1**

> Drei Heilige Steine. Zeldas Plan kann
> weitergehen. Ich hoffe sehr, daß
> diesmal jemand die möglichen Folgen
> mitbedacht hat.

### 0165

Projekttext.

**Seite 1**

> [Spielername], kann ja sein, daß
> das nur meine allgemeine Anxiety ist,
> aber ich habe das Gefühl, dieser Mr.
> Bean ist irgendwie in Gefahr.

## 14. Flucht vor dem Schloß – Friedrich Merz spricht Link an

### 2019

Projekttext.

**Seite 1**

> Sie ist fort! Und dieser Herr Bohne
> hält sich wohl für unentbehrlich!

### 201A

Projekttext.

**Seite 1**

> Du da! Kleiner Pascha!

### 201E

Projekttext.

**Seite 1**

> Wo sind Zelda und Herr Bohne hin?
> Hier wird nicht diskutiert. Antworte!

### 202F

Projekttext.

**Seite 1**

> Du stellst Dich mir in den Weg? Ich
> tue das alles für Deine Zukunft!

### 201B

Projekttext.

**Seite 1**

> Wenn Du erwachsen bist, wählst Du
> die CDU. Leistung muß sich
> schließlich lohnen!

### 201C

Projekttext.

**Seite 1**

> Du weißt wohl nicht, wer vor Dir
> steht! Friedrich Merz! Merk Dir
> diesen Namen.

### 201D

Projekttext.

**Seite 1**

> Ich werde dieses Land wieder nach
> vorne bringen. Für Deine Zukunft,
> kleiner Pascha!

## 15. Okarina im Graben – Zelda und die Hymne der Zeit

### 014C

Projekttext.

**Seite 1**

> Bean hat Zelda auf dem weißen Pferd
> gerettet. Endlich handelt ein
> Erwachsener! Im Wassergraben liegt
> noch etwas, das sie uns zuwarf.

### 003A

Projekttext.

**Seite 1**

> Die Okarina der Zeit! Ein
> Artefakt aus dem Besitz des
> Königs.

**Seite 2**

> Die Okarina der Salia
> brauchen wir dann wohl nicht
> mehr. Sie wurde gerade
> gelöscht.

### 2005

Projekttext.
Zeitgesteuerte Textcodes: FADE(60). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> [Spielername], hörst Du mich? Ich
> benutze meine Telepathie-Superkräfte.

### 2008

Projekttext.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(60), BOX_BREAK_DELAYED(60), BOX_BREAK_DELAYED(60), FADE(60). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> [Spielername], hör zu. Mr. Bean
> weiß, was er tut.

**Seite 2**

> Ich vertraue ihm voll und ganz.

**Seite 3**

> Er wird mich retten. Du mußt jetzt
> schleunigst zur Zitadelle der Zeit.

**Seite 4**

> Nimm die Okarina und lerne diese
> Melodie...

### 00D5

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Du hast die
> Hymne der Zeit
> erlernt!

### 2009

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Wohlan, [Spielername].
> Spiele diese Melodie in der
> Zitadelle der Zeit vor dem 
> Zeitaltar!

### 0166

Projekttext.

**Seite 1**

> Hey, [Spielername], die klingt jetzt
> aber wirklich viel besser als die
> Okarina der Salia. Das ist ja jetzt
> hier wirklich echte Qualität.

## 16. Optionaler Abschied – sterbender Soldat in der Gasse

### 7007

Projekttext.
Optionaler Soldat in der Seitengasse nach der Flucht und vor dem Zeitsprung.

**Seite 1**

> Du... aus dem Wald... hör mir zu. Das
> ist unfaßbar peinlich.

**Seite 2**

> Merz ist hinter Zelda und Mr. Bean
> her. Ich wollte ihn verfolgen.

**Seite 3**

> Dann bin ich gestolpert. Einfach so.
> Über meine eigenen Füße.

**Seite 4**

> Mit dem Schädel zuerst auf den
> Asphalt. Ich habe es richtig krachen
> gehört.

**Seite 5**

> Kein heldenhafter Zweikampf. Kein
> Hinterhalt. Ein beschissener Sturz.

**Seite 6**

> Zelda hat Dir etwas zugeworfen.
> Such es im Burggraben. Dann zur
> Zitadelle der Zeit.

**Seite 7**

> Schreib bitte... ich sei im Dienst
> gefallen. Das klingt... würdevoller...

### 7008

Projekttext.
Untersuchung/Wiederholung beim verstorbenen Soldaten.

**Seite 1**

> Er rührt sich nicht mehr. Sein letzter
> Gegner war der Asphalt.

## 17. Zitadelle der Zeit – Inschrift und Navi vor dem Schwert

### 7040

Projekttext.

**Seite 1**

> Hier sind drei perfekt geformte
> Vertiefungen für die drei Heiligen
> Steine und eine Inschrift...

**Seite 2**

> Jener mit den drei Heiligen Steinen
> nehme seine Okarina zur Hand
> und spiele hier die Hymne der Zeit.

**Seite 3**

> Seltsam, aber so steht
> es geschrieben...

### 014D

Projekttext.

**Seite 1**

> Alles klar, dann schauen wir mal,
> was wir hier hinter dieser Wand für
> Reichtümer haben. Mein Feenkörper
> ist bereit.

### 70E6

Projekttext.

**Seite 1**

> [Spielername], ich glaube, mich
> tritt ein Pferd!

### 70E7

Projekttext.
Zeitgesteuerte Textcodes: FADE(30). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Das Master-Schwert! Eine der
> stärksten Klingen im Land, heißt es.

### 70E8

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Navi beim ersten Anblick des Master-Schwerts, aus der nativen Schwert-Cutscene.

**Seite 1**

> Das Master-Schwert!

## 18. Nach dem Ziehen des Master-Schwerts – Merz, noch vor Habeck

### 700A

Projekttext.
Native kurze Merz/Ganondorf-Szene nach dem Ziehen des Schwerts. Dies ist der letzte Text dieser Arbeitsliste. Danach beginnt die Halle-der-Weisen-Sequenz mit 704E, die hier nicht enthalten ist.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(60), BOX_BREAK_DELAYED(90), BOX_BREAK_DELAYED(80), FADE(50). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Herr Bohne kämpfte gut. Wie zu
> erwarten.

**Seite 2**

> Er starb mit Ehre. Ich habe ihn
> ermordet.

**Seite 3**

> Zelda entkam. Doch letztendlich
> gewinnt immer...

**Seite 4**

> ...die politische Mitte!

## Nebenhandlungen, Zusatzvarianten und Zielerfassung

## A. Wundererbsenverkäufer – sämtliche Preise, Ablehnung und Wiederholung

### 405E

Projekttext.

**Seite 1**

> Ich habe den gesamten Vorrat
> aufgekauft. Jetzt bestimme ich den
> Preis. Friedrich Merz nennt das
> bestimmt Eigeninitiative.

**Seite 2**

> Eine Wundererbse: 10 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 405F

Projekttext.

**Seite 1**

> Nur noch ganz wenige! Die anderen
> neun liegen zwar neben mir, aber das
> ist mein strategischer Engpaß.

**Seite 2**

> Eine Wundererbse: 20 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4060

Projekttext.

**Seite 1**

> Die Nachfrage steigt. Sagt jedenfalls
> das Schild, das ich gerade selbst
> geschrieben habe.

**Seite 2**

> Eine Wundererbse: 30 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4061

Projekttext.

**Seite 1**

> Ein anderer Kunde wollte auch eine.
> Er existiert nur in meiner
> Verkaufsstrategie, aber Du solltest
> Dich trotzdem beeilen.

**Seite 2**

> Eine Wundererbse: 40 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4062

Projekttext.

**Seite 1**

> Friedrich Merz versteht Leute wie
> mich. Man muß aus der Knappheit der
> anderen eben etwas machen.

**Seite 2**

> Eine Wundererbse: 50 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4063

Projekttext.

**Seite 1**

> Limitierte Erbsen. Gleiche Pflanzen,
> neuer Preis. Du bezahlst für das
> Gefühl, zu spät dran zu sein.

**Seite 2**

> Eine Wundererbse: 60 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4064

Projekttext.

**Seite 1**

> Wer jetzt nicht kauft, ärgert sich
> morgen. Morgen ärgerst Du Dich
> allerdings auch über mich.

**Seite 2**

> Eine Wundererbse: 70 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4065

Projekttext.

**Seite 1**

> Ich nenne mich unabhängiger
> Wiederverkäufer. Scammer klingt
> immer so nach ehrlicher
> Tätigkeitsbeschreibung.

**Seite 2**

> Eine Wundererbse: 80 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4066

Projekttext.

**Seite 1**

> Friedrich Merz wäre stolz. Ich habe
> den Preis erhöht, ohne irgend etwas
> zu verbessern.

**Seite 2**

> Eine Wundererbse: 90 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4067

Projekttext.

**Seite 1**

> Letzte Chance! Diese eine Erbse
> kostet jetzt so viel wie ein kleiner
> Hausrat. Der Markt hat gesprochen.
> Ich bin der Markt.

**Seite 2**

> Eine Wundererbse: 100 Rubine.
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 4068

Projekttext.

**Seite 1**

> Dann eben nicht. Morgen erzähle ich
> trotzdem, daß alle Kunden begeistert
> waren.

### 4069

Projekttext.

**Seite 1**

> Zu wenig Geld. Friedrich Merz würde
> sagen: Dann mußt Du Dich eben mehr
> anstrengen. Ich würde sagen: Der
> Nächste bitte.

### 406A

Projekttext.

**Seite 1**

> Lege die Wundererbse auf [C] und
> pflanze sie in die weiche Erde. Keine
> Rückgabe, sobald Du sie angefaßt
> hast.

### 406B

Projekttext.

**Seite 1**

> Ausverkauft! Die Erbsen, die ich
> gerade esse, sind unverkäufliche
> Sammlerstücke. Wertanlage. Friedrich
> Merz versteht das.

### 406C

Projekttext.

**Seite 1**

> Such quadratische Stellen mit weicher
> Erde. Dort wachsen die Erbsen. Ob
> Dir die Reise den Preis wert war, ist
> leider Dein Geschäftsrisiko.

## B. Frösche am Zora-Fluß – normale Liedbelohnung

### 40A9

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Mein Freund, Du spielst die
> Okarina gut... Mmmh...!
> Eine nette Melodie... Wir sollten
> sie alle üben!

**Seite 2**

> Nimm dies hier als Lohn!
> Wenn Dir mal wieder eine feine
> Weise durch den Kopf schießt,
> komm vorbei und spiel sie vor!

## C. Hylia-See als Kind – Eule, Forscher und normaler Doofenshmirtz

### 2071

Projekttext.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(40). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Der Hylia-See. Klar und kühl. Das ist
> ein Zustand, den man erhalten muß.
> Keine unbegrenzte Ressource.

**Seite 2**

> Die Zoras hüten den Wassertempel
> auf dem Grund. Wasser ist hier also
> auch eine Frage der Infrastruktur.

**Seite 3**

> START, dann [Z] oder [R]: die Karte.
> Wir müssen die einzelnen Wege im
> Zusammenhang sehen.

**Seite 4**

> Besuchte Orte stehen darin. Das ist
> keine Prophezeiung. Das ist eine
> belastbare Datengrundlage.

### 2072

Projekttext.

**Seite 1**

> So. Jetzt geh. Ich kann Dir den Weg
> erklären. Gehen kann ich ihn nicht für
> Dich. Ich habe ja auch keine Schuhe.

### 4003

Projekttext.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(40). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Da bist Du. Der Weg hat gedauert.
> Das ist keine Kritik. Es ist erst
> einmal die Feststellung einer
> Wegstrecke.

**Seite 2**

> Die Karte hilft. Man kann das Ziel für
> richtig halten und sich bei der
> Umsetzung trotzdem verlaufen.

**Seite 3**

> [Spielername], der Hylia-See. Klar
> und kühl. Wer das erhalten will, muß
> mehr tun, als gelegentlich die
> Aussicht zu loben.

**Seite 4**

> Auf dem Grund liegt der
> Wassertempel. Die Zoras wachen
> darüber. Wasser hat eben auch eine
> institutionelle Seite.

**Seite 5**

> Die Zoras sind der Königsfamilie seit
> langem verbunden. Das schafft
> Vertrauen, aber auch Zuständigkeiten.

**Seite 6**

> Nur ein königlicher Abgesandter darf
> hinein. Du brauchst also einen
> Nachweis. Und zwar einen, den man
> hören kann.

**Seite 7**

> Ich fliege jetzt zum Schloß. Wenn Du
> mitwillst, halte Dich an meinen
> Krallen fest. Gemeinsame Mobilität.
> Sehr konkret.

### 4004

Projekttext.

**Seite 1**

> Ich fliege zum Schloß. Halte Dich an
> meinen Krallen fest, wenn Du
> mitwillst. Das ist ein Angebot, keine
> Verkehrswende für ganz Hyrule.

### 4018

Projekttext.

**Seite 1**

> Ich hab gehört, dieser Merz möchte
> uns das Budget kürzen? Der werte
> Herr soll das gerne versuchen. Das
> will ich sehen!

**Seite 2**

> Nur über meine Leiche! Boah, ich
> hoffe echt, daß ich noch sieben Jahre
> durchhalte. Ich bin halt echt schon
> mega alt, ne?

### 4032

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Wenn Du wieder mal vorbeikommst,
> bring mir doch ein Souvenir mit!

### 407B

Projekttext.
Normale kindliche Doofenshmirtz-Fassung am Angelteich; keine erwachsene Augenklappen-Fassung.

**Seite 1**

> Ah, ein Besucher! Dr. Heinz
> Doofenshmirtz, erfreut. Du fragst
> Dich sicher, warum ein

**Seite 2**

> Wissenschaftler einen Angelteich
> betreibt.

**Seite 3**

> Es begann in meiner Kindheit in
> Gimmelschtump. Die anderen Kinder
> durften angeln gehen, ich natürlich
> nicht.

**Seite 4**

> Wobei es bei uns ohnehin nur
> Jauchegruben gab. Also selbst wenn
> ich gedurft hätte, wäre das eine

**Seite 5**

> ziemlich traurige Angelegenheit
> gewesen.

**Seite 6**

> Deshalb habe ich den Angelinator
> erfunden! Er soll sämtliche Fische
> Hyrules in meinen Teich bringen!

**Seite 7**

> Oder zumindest eine große
> Ansammlung. Ich habe beim Antrag
> sämtliche Fische geschrieben, aber

**Seite 8**

> wir wollen jetzt nicht kleinlich
> werden.

**Seite 9**

> Und falls ein Schnabeltier auftaucht:
> Sag ihm, ich wäre gerade nicht da.

**Seite 10**

> Willst Du für 20 Rubine angeln?
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 408F

Projekttext.

**Seite 1**

> Warum ich unbedingt alle Fische in
> diesem Teich haben möchte?

**Seite 2**

> Weil man auf eine traurige Kindheit
> offenbar nur mit einem völlig
> überdimensionierten technischen
> Projekt reagieren kann.

### 4092

Projekttext.

**Seite 1**

> Komm ruhig wieder. In sieben Jahren
> habe ich hier bestimmt alles im Griff.
> Was soll denn groß passieren?

## D. Neue Begegnungen in Jabu-Jabu – Okto und Nintendo 64

### 00F8

Projekttext.

**Seite 1**

> Hola, Amigo! Ich bin Okto, der
> Oktorok.

**Seite 2**

> Was soll das, Muchacho? Nicht alle
> Oktoroks sind böse. Das ist ein
> Vorurteil. Mega rassistisch!

**Seite 3**

> Ja, gut. Hier in diesem "Dungeon"
> gibt's zwar einen riesigen bösen
> Oktorok. Ay, caramba!

**Seite 4**

> Aber das ist nicht meine Schuld,
> Compadre. Der läßt den ganzen Rest
> von uns total schlecht aussehen.

### 0125

Projekttext.

**Seite 1**

> Ein Nintendo 64 mit Zelda Ocarina of
> Time... Ich tu mal so, als hätte ich
> das nicht gesehen.

## E. Deku-Händler in Jabu-Jabu und der besondere Kartentext

### 0130

Projekttext.
Direkte native Fortsetzung: 10A3.

**Seite 1**

> Oh Mann ey! So einen Laden in
> einem Wal aufzumachen war wirklich
> eine absolut bekloppte Idee. Ich
> verstehe nicht, warum habe ich das

**Seite 2**

> überhaupt gemacht? Also wie konnte
> ich das nur tun?

**Seite 3**

> Na egal. Willst Du wenigstens was
> kaufen? Ich hab ein paar Deku-Nüsse:
> fünf Stück, 20 Rubine. Paßt Dir das?

### 10A3

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Laß uns ein Geschäft machen!
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 013E

Projekttext.

**Seite 1**

> Wieso liegt eine perfekte
> Karte von Jabu-Jabus
> Innereien in dieser magischen
> Schatztruhe?

**Seite 2**

> Ich glaube, das war Ruto.
> Würde Sinn machen, oder?

**Seite 3**

> Drücke START für die Karte.
> Mit dem [Control-Pad] wechselst Du das
> Stockwerk. Also... den
> jeweiligen Teil des Fisches.

## F. Wichtige Fundtexte – Schuppe, Brief/Flasche, Bumerang, Kompaß und Fisch

### 0035

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Der Bumerang!
> Im Gegenstands-Menü kannst
> Du ihn auf [C-Left], [C-Down] oder [C-Right]
> plazieren.

**Seite 2**

> Drücke [C], um Gegner
> zu treffen, die weiter
> entfernt sind!

### 0047

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Du besitzt jetzt einen Fisch!
> Lasse ihn mit [C] frei. Er sieht
> richtig frisch aus!

**Seite 2**

> Im Gegenstands-Menü kannst
> Du ihn auf [C-Left], [C-Down] oder [C-Right]
> plazieren.
> Mit [C] läßt Du ihn frei.

### 0048

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Die Wundererbse!
> Suche nach einer Stelle,
> um sie mit [C] einzupflanzen.
> Warte ab, was passiert!

**Seite 2**

> Im Gegenstands-Menü kannst
> Du sie auf [C-Left], [C-Down] oder [C-Right]
> plazieren und
> mit [C] einpflanzen.

### 0042

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Eine leere Flasche!
> Plaziere die Flasche auf [C],
> um sie einzusetzen.

### 0067

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Der Kompaß!
> Jetzt siehst Du auf Deiner
> Karte alle Schatztruhen
> dieses Labyrinths!

### 00AD

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Dins Feuerinferno!
> Dieser Feuerball entflammt die
> Umgebung! Du setzt diese
> Magie-Attacke mit [C] ein.

### 00AE

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Farores Donnersturm!
> Ein magischer Teleporter, den
> Du mit [C] einsetzt. Nutze
> ihn, wenn Gefahr droht!

**Seite 2**

> Mit dieser Magie legst Du
> einen Teleporterpunkt an.
> Rufst Du Farores Kraft erneut an,
> gelangst Du dorthin zurück.

**Seite 3**

> Du kannst den Teleporter
> aber auch wieder aufheben
> und anderswo setzen, wenn
> Du Farores Magie beschwörst.

### 00EC

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Dins Feuerinferno kannst Du nicht
> nur für Attacken nutzen.
> Du kannst damit auch manches in
> Brand setzen!

### 00ED

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Vergiß nicht: Farores Donnersturm
> kannst Du nur in einem Labyrinth
> einsetzen, in dem auch eine Karte
> versteckt ist. Alles klar?

## G. Stadtbewohner nach der Flucht – neue Reaktionen und Gerüchte

### 7044

Projekttext.

**Seite 1**

> Also, ich habe neulich in Lord
> Jabu-Jabu gechillt, und ich fand es
> schade,

**Seite 2**

> daß man dort nichts kaufen konnte,
> was ja gerade im Inneren eines
> riesigen Fisches

**Seite 3**

> mega praktisch gewesen wäre, weil
> ich bereit gewesen wäre, meine
> sämtlichen Rubine

**Seite 4**

> dort auszugeben, wenn da nur zufällig
> ein Händler gewesen wäre, aber den
> habe ich

**Seite 5**

> natürlich nicht gesehen, weshalb ich
> jetzt immer noch nicht weiß, wohin
> mit dem Geld,

**Seite 6**

> weshalb ich jetzt einfach irgendeine
> dieser Masken für tausend Jahre
> mieten will,

**Seite 7**

> und ich hoffe wirklich, daß das
> Maskengeschäft die nächsten Jahre
> dort stehen bleibt,

**Seite 8**

> weil sich sonst ja die ganze
> langfristige Mietplanung im nachhinein
> als ziemlich

**Seite 9**

> unpraktisch herausstellen würde, und
> gerade bei so einer Maske muß man
> vorausdenken.

### 7045

Projekttext.

**Seite 1**

> Man sieht mich nur von weiter weg,
> ansonsten würde auffallen, daß mein
> Gesicht nur grottenschlecht aufgemalt
> wurde.

### 7046

Projekttext.

**Seite 1**

> Dieser Friedrich Merz hat mich fast
> komplett mit seinem Pferd umgeritten.
> Ist der Typ wahnsinnig? Der soll sich
> mal eine Vollglatze schneiden. Was

**Seite 2**

> soll die Scheiße?

### 7047

Projekttext.

**Seite 1**

> Das war Friedrich Merz auf dem
> schwarzen Pferd. Kein Zweifel.

**Seite 2**

> Hyrule umkrempeln, aber an diesen
> drei Haaren festhalten. Warum? Mach
> doch einfach auf null!

### 7048

Projekttext.

**Seite 1**

> Zelda flieht, Merz dreht durch und
> alle haben Angst.

**Seite 2**

> Und trotzdem frage ich mich: Was
> soll diese Frisur? So wenig Haar
> kann doch keinen solchen Aufwand
> rechtfertigen.

### 7049

Projekttext.

**Seite 1**

> Er nennt uns weinerlich, während auf
> seinem Kopf noch drei Haare um ihren
> Arbeitsplatz kämpfen.

**Seite 2**

> Null Millimeter, Friedrich! Trau Dich!
> Das wäre endlich mal eine klare
> Entscheidung!

### 704A

Projekttext.

**Seite 1**

> Ich schmeiß Autobatterien in den
> Hylia-See, damit die Zitteraale genug
> Strom nachladen können.

### 704B

Projekttext.

**Seite 1**

> Mr. Bean war mein Rettungssanitäter,
> als ich 'ne Überdosis hatte.

**Seite 2**

> Mr. Bean ist der absolut ehrenvollste
> Ehrenmann unter den Ehrenmännern.

### 704D

Projekttext.

**Seite 1**

> Zelda ist in den besten Händen. Mr.
> Bean hat sie aus dem Schloß
> gerettet.

**Seite 2**

> Dieser Mann ist ein Volksheld! Der
> läßt sie niemals im Stich. Darauf
> kannst Du Dich verlassen.

### 70EB

Projekttext.

**Seite 1**

> Na, wie gefällt Dir das Abenteuer bis
> jetzt? Ich bin gespannt, wie es
> weitergeht.

## H. Wache im Krughaus – Tages- und Nachttext

### 7004

Projekttext.

**Seite 1**

> Wenn etwas kaputtgeht, finde ich das
> immer mega witzig. Wirklich immer.

**Seite 2**

> Krug fällt runter? Lustig. Stuhl bricht
> zusammen? Meisterwerk.

**Seite 3**

> Das ist mein gesamter Humor. Es
> gibt keine zweite Ebene. Ich bin
> vollkommen zufrieden.

**Seite 4**

> [A] hebt den Krug. Nochmal [A] wirft
> ihn. Und dann kommt die Pointe: Der
> Krug ist kaputt.

### 709A

Projekttext.

**Seite 1**

> Nachts ist es hier still. Leider geht
> dabei viel zu wenig kaputt.

**Seite 2**

> Tagsüber zerlegt so ein Waldkind die
> Krüge. Ich lache jedes einzelne Mal.

**Seite 3**

> Die Kollegen sagen, mein Humor sei
> eindimensional. Ich sage: KRRRACH!

**Seite 4**

> Siehst Du? Schon wieder lustig.
> Großartiges Gespräch.

## I. Navi-Zielerfassung – Gegner dieses Abschnitts

### 0606

Projekttext.

**Seite 1**

> Ein Zangengeiferer. Nimm Deine
> Zangen da weg, Du widerlicher
> Drecksack! Keiner will von Dir
> angefaßt werden.

### 0614

Projekttext.

**Seite 1**

> Barinade. Du hängst hier in Jabus
> Innereien und kackst alles mit Strom
> voll. Widerliches Drecksvieh.

### 0615

Projekttext.

**Seite 1**

> Ein Parasiten-Tentakel.
> [Spielername], hau das ab. Ich hab'
> keinen Bock, daß dieser glitschige
> Scheiß mich berührt.

### 0616

Projekttext.

**Seite 1**

> Eine Blubberblase. Die hält sich
> ernsthaft für ein Hindernis. Du bist
> LUFT. Verpiß Dich.

### 0617

Projekttext.

**Seite 1**

> Eine Zappelqualle. Pack Deinen Strom
> weg, Du glibberiges Arschloch. Ich
> will hier einfach nur vorbei!

### 0618

Projekttext.

**Seite 1**

> Eine große Zappelqualle. Ja, Du bist
> größer. Du bist aber immer noch
> derselbe beschissene Schleimklumpen.

### 0619

Projekttext.

**Seite 1**

> Ein Elektromanta. Liegt erst feige im
> Boden und springt uns dann ins
> Gesicht. Richtig dreckige Nummer.

### 0627

Projekttext.

**Seite 1**

> Mach die Fresse noch einmal auf! Ich
> brech' diese Scheißmuschel in der
> Mitte durch, ich schwör's Dir!

### 0642

Projekttext.

**Seite 1**

> Ein Oktorok. Der spuckt uns
> ernsthaft ins Gesicht. Schluck Deinen
> eigenen Dreck, Du widerliches
> Arschloch!

## J. Gespeicherte Zusatzvariante – Ruto neben dem König

### 402C

Projekttext.
Dieser Text liegt im Spiel vor. In der deutschen Fassung wird junge Ruto neben dem König nach dem Saphir jedoch entfernt; normalerweise dort nicht mehr ansprechbar.

**Seite 1**

> Ich bleibe erst einmal verschwunden.
> Mein Vater kann Merz ja statt des
> Saphirs einen hübschen Kiesel
> anbieten.

## K. Alte Zusatzzeile ohne nachgewiesenen Gesprächsaufruf

### 013D

Projekttext.
Frühere Zuordnung zu Ruto war falsch: gleichlautende Kameradaten sind keine Textreferenzen. Kein Gesprächsaufruf bei Ruto oder den Jabu-Hinweis-Akteuren nachgewiesen. Flaggen-Zeile entfernt; kein neuer Navi-Ruf.

**Seite 1**

> WAAAAS!?


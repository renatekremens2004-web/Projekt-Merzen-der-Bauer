from collections import Counter

def cost(line):
 if line.startswith('call '):return 3
 if line.startswith('notedvg '):return 4+(int(line.split(',')[1])>=128)
 if line.startswith('notedv '):return 3+(int(line.split(',')[1])>=128)
 if line.startswith('ldelay '):return 2+(int(line.split()[1])>=128)
 return 0

def compress(lines):
 definitions=[];blocked=set()
 for iteration in range(180):
  if sum(cost(x)for x in lines)+sum(sum(cost(x)for x in p)+1 for p in definitions)<12300:break
  counts=Counter()
  for length in (4,6,8,12,16):
   for at in range(len(lines)-length+1):
    p=tuple(lines[at:at+length])
    if all(x.startswith(('notedv ','notedvg ','ldelay '))for x in p):counts[p]+=1
  best=None;gain=0
  for p,n in counts.items():
   score=(sum(map(cost,p))-3)*(n-1)-4
   if p not in blocked and n>1 and score>gain:gain=score;best=p
  if best is None:break
  label=f'MOTIF_{len(definitions)}';n=len(best);out=[];at=0;actual=0
  while at<len(lines):
   if tuple(lines[at:at+n])==best:out.append('call '+label);at+=n;actual+=1
   else:out.append(lines[at]);at+=1
  if actual<2:blocked.add(best);continue
  definitions.append(best);lines=out
 for i,p in enumerate(definitions):lines +=[f'.layer MOTIF_{i}',*p,'end']
 return lines,len(definitions)

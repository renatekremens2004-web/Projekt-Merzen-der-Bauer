#ifndef DDAN_ROOM_8_H
#define DDAN_ROOM_8_H

#include "room.h"
#include "scene.h"
#include "tex_len.h"
#include "ultra64.h"

extern SceneCmd ddan_room_8[];
#define LENGTH_ddan_room_8_03000040_ObjectList 5
extern s16 ddan_room_8_03000040_ObjectList[LENGTH_ddan_room_8_03000040_ObjectList];
#define LENGTH_ddan_room_8_0300004C_ActorEntryList 7
extern ActorEntry ddan_room_8_0300004C_ActorEntryList[LENGTH_ddan_room_8_0300004C_ActorEntryList];
extern RoomShapeCullable ddan_room_8_030000D0_RoomShapeCullable;
#define LENGTH_ddan_room_8_030000D0_RoomShapeCullable_030000DC_CullableEntries 1
extern RoomShapeCullableEntry ddan_room_8_030000D0_RoomShapeCullable_030000DC_CullableEntries[LENGTH_ddan_room_8_030000D0_RoomShapeCullable_030000DC_CullableEntries];
extern u8 ddan_room_8_unaccounted_0000EC[];
extern Vtx ddan_room_8_030000D0_RoomShapeCullable_030000DC_CullableEntries_03002470_DL_030000F0_Vtx_fused_[];
extern Gfx ddan_room_8_030000D0_RoomShapeCullable_030000DC_CullableEntries_03002470_DL[880];
extern u8 ddan_room_8_unaccounted_003FF0[];
#define ddan_room_8_00004000_CITex_WIDTH 64
#define ddan_room_8_00004000_CITex_HEIGHT 32
extern u64 ddan_room_8_00004000_CITex[TEX_LEN(u64, ddan_room_8_00004000_CITex_WIDTH, ddan_room_8_00004000_CITex_HEIGHT, 8)];
#define ddan_room_8_00004800_CITex_WIDTH 32
#define ddan_room_8_00004800_CITex_HEIGHT 32
extern u64 ddan_room_8_00004800_CITex[TEX_LEN(u64, ddan_room_8_00004800_CITex_WIDTH, ddan_room_8_00004800_CITex_HEIGHT, 8)];
#define ddan_room_8_00004C00_CITex_WIDTH 32
#define ddan_room_8_00004C00_CITex_HEIGHT 32
extern u64 ddan_room_8_00004C00_CITex[TEX_LEN(u64, ddan_room_8_00004C00_CITex_WIDTH, ddan_room_8_00004C00_CITex_HEIGHT, 8)];
#define ddan_room_8_00005000_CITex_WIDTH 64
#define ddan_room_8_00005000_CITex_HEIGHT 32
extern u64 ddan_room_8_00005000_CITex[TEX_LEN(u64, ddan_room_8_00005000_CITex_WIDTH, ddan_room_8_00005000_CITex_HEIGHT, 8)];
#define ddan_room_8_00005800_CITex_WIDTH 32
#define ddan_room_8_00005800_CITex_HEIGHT 64
extern u64 ddan_room_8_00005800_CITex[TEX_LEN(u64, ddan_room_8_00005800_CITex_WIDTH, ddan_room_8_00005800_CITex_HEIGHT, 8)];
#define ddan_room_8_00006000_CITex_WIDTH 32
#define ddan_room_8_00006000_CITex_HEIGHT 64
extern u64 ddan_room_8_00006000_CITex[TEX_LEN(u64, ddan_room_8_00006000_CITex_WIDTH, ddan_room_8_00006000_CITex_HEIGHT, 8)];
#define ddan_room_8_00006800_CITex_WIDTH 32
#define ddan_room_8_00006800_CITex_HEIGHT 64
extern u64 ddan_room_8_00006800_CITex[TEX_LEN(u64, ddan_room_8_00006800_CITex_WIDTH, ddan_room_8_00006800_CITex_HEIGHT, 8)];
#define ddan_room_8_00007000_CITex_WIDTH 32
#define ddan_room_8_00007000_CITex_HEIGHT 64
extern u64 ddan_room_8_00007000_CITex[TEX_LEN(u64, ddan_room_8_00007000_CITex_WIDTH, ddan_room_8_00007000_CITex_HEIGHT, 8)];
#define ddan_room_8_00007800_CITex_WIDTH 64
#define ddan_room_8_00007800_CITex_HEIGHT 32
extern u64 ddan_room_8_00007800_CITex[TEX_LEN(u64, ddan_room_8_00007800_CITex_WIDTH, ddan_room_8_00007800_CITex_HEIGHT, 8)];
#define ddan_room_8_00008000_CITex_WIDTH 32
#define ddan_room_8_00008000_CITex_HEIGHT 64
extern u64 ddan_room_8_00008000_CITex[TEX_LEN(u64, ddan_room_8_00008000_CITex_WIDTH, ddan_room_8_00008000_CITex_HEIGHT, 8)];
#define ddan_room_8_00008800_CITex_WIDTH 32
#define ddan_room_8_00008800_CITex_HEIGHT 64
extern u64 ddan_room_8_00008800_CITex[TEX_LEN(u64, ddan_room_8_00008800_CITex_WIDTH, ddan_room_8_00008800_CITex_HEIGHT, 8)];
#define ddan_room_8_00009000_CITex_WIDTH 32
#define ddan_room_8_00009000_CITex_HEIGHT 32
extern u64 ddan_room_8_00009000_CITex[TEX_LEN(u64, ddan_room_8_00009000_CITex_WIDTH, ddan_room_8_00009000_CITex_HEIGHT, 8)];

#endif

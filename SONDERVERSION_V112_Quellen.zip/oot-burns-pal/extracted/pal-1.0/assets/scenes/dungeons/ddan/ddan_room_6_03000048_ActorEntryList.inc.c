    {
        ACTOR_EN_SHOPNUTS,
        {   1638,    411,  -1953 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 0
    {
        ACTOR_EN_SHOPNUTS,
        {   2045,    411,  -1962 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0003, // params
    }, // 1


    { ACTOR_ELF_MSG2, { 1770, 411, -1800 }, {0, 0, 0}, 0x7FBC },

    { ACTOR_ELF_MSG2, { 1840, 411, -1840 }, {0, 0, 0}, 0x7FBD },

    { ACTOR_ELF_MSG2, { 1910, 411, -1800 }, {0, 0, 0}, 0x7FBE },

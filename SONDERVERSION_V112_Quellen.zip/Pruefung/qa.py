from pathlib import Path
import sys,subprocess,os,json,struct,re,hashlib
W=Path(__file__).parent;O=Path('/workspace/oot-burns-pal');old=json.load(open('/workspace/yellow-poe-v70/symbols-normal.json'));base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
cases=[('wallace',1,1,0x3f9a,(1460,0,-350),0x019a),('kris',6,1,0x7fbc,(1770,411,-1800),0x7221),('susie',6,1,0x7fbd,(1840,411,-1840),0x7222),('ralsei',6,1,0x7fbe,(1910,411,-1800),0x7223),('old-stairs',2,1,0,(-1900,0,-1190),0),('adult-wallace',1,0,0,(1460,0,-350),0),('adult-trio',6,0,0,(1840,411,-1800),0),('bats-5',5,1,0,(-1960,531,-180),0),('bats-8',8,1,0,(1450,76,-3700),0),('bats-11',11,1,0,(2500,0,250),0),('shield',1,1,0,(1450,0,-320),0)]
if len(sys.argv)>1:cases=[c for c in cases if c[0]in sys.argv[1:]]
results=[x for x in json.loads((W/'qa-results.json').read_text())if x['case']not in {c[0]for c in cases}] if (W/'qa-results.json').exists() else []
for tag,room,age,param,pos,text in cases:
 mode='debug'if tag=='ralsei'else'normal';sy=json.load(open(W/f'all-symbols-{mode}.json'));s=base
 for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:s=s.replace(hex(old[n]),hex(sy[n]))
 s=re.sub(r'static void alarmcb\(int sig\).*?\nstatic uint32_t savebase=', 'static void alarmcb(int sig){puts("TIMEOUT");_exit(99);}\nstatic uint32_t savebase=',s,flags=re.S)
 a=s.index('static void capture_render(void){}');b=s.index('static void setting(',a)
 body=r'''
static void capture_render(void){}
static unsigned first=0,talked=0,menuOpened=0,phase=0,mark=0;static unsigned hashBefore=0;
static unsigned colhash(void){unsigned p=r32(play+0x7c0),h=2166136261u;for(unsigned i=0;i<0x2c;i++)h=(h^DebugMemRead8(p+i))*16777619u;return h;}
static unsigned countid(unsigned id){unsigned c=0;for(int cat=0;cat<12;cat++)for(unsigned p=r32(play+0x1c34+cat*8),n=0;p>=0x80000000&&p<0x80400000&&n<180;p=r32(p+0x124),n++)if(DebugMemRead16(p)==id&&r32(p+0x130))c++;return c;}
static void onframe(unsigned f){
 baseframe(f);if(f<400)return;findplay();if(!play||!player)return;
 if(DebugMemRead16(play+0xa4)!=1||DebugMemRead8(play+0x11cbc)!=ROOM)return;
 unsigned param=PARAM,g=param?target(0x173,param):0,v=0,mm=DebugMemRead8(play+0x20d8+0xe304),msg=DebugMemRead16(play+0x20d8+0xe2f8),st=DebugMemRead16(play+0x10934);
 if(!first){first=f;bank();hashBefore=colhash();printf("ROOM_READY room=%u age=%u target=%x\n",ROOM,r32(savebase+4),g);
 if(param){need(g&&r32(g+0x134),"new room NPC has draw callback");need(fabsf(rf(g+0x28)-Y)<2,"feet on selected floor");}
 if(ABSENT)need(!target(0x173,0x3f9a)&&!target(0x173,0x7fbc)&&!target(0x173,0x7fbd)&&!target(0x173,0x7fbe),"no duplicate/age-inappropriate guests");
 if(BATS>=0)need(countid(0x13)==BATS,"expected remaining Keese count");
 if(SHIELD){need(DebugMemRead8(player+0x13e)==1,"native Deku shield equipped");DebugMemWrite8(player+0xa50,1);for(int j=0;j<18;j++)DebugMemWrite8(player+0xa51+j,90);printf("NATIVE_BODY_FIRE_STARTED\n");}
 }
 if(param&&f<first+95){photo(X-120,Y+90,Z+150,X,Y+35,Z);}
 if(f==first+70)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
 if(param&&!talked&&!mm&&f>first+80){position(player,X,Y,STANDZ,STANDYAW);v=0;if(f%24<3)v|=0x80;}
 if(mm&&msg==TEXT){talked=1;if(f%24<3)v=0x80;}
 if(f>first+150&&(!param||(talked&&!mm))&&phase==0){v=0x10;phase=1;mark=f;}
 if(phase==1&&st==6){menuOpened=1;phase=2;mark=f;}
 if(phase==2&&f>=mark+20&&f<mark+24)v=0x10;
 if(phase==2&&st==0){phase=3;mark=f;}
 if(phase==3&&f>mark+50){bank();need(colhash()==hashBefore,"collision header unchanged after pause");need(DebugMemRead16(player+0x88)!=0xffff,"player standing on floor after pause");if(param)need(talked,"own dialogue opened");
 if(SHIELD){need(((DebugMemRead16(savebase+0x70)>>4)&15)==1,"shield still equipped after body fire");need(DebugMemRead16(savebase+0x9c)&16,"wooden shield retained in inventory");need(msg!=0x305f,"no burned-shield message");printf("SHIELD_FIRE_PASSED\n");}
 printf("SPECIAL_QA_PASSED TAG room=%u pause=%u talked=%u\n",ROOM,menuOpened,talked);CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(f%200==0)printf("PROGRESS f=%u phase=%u msg=%x mode=%u talked=%u dist=%.1f\n",f,phase,msg,mm,talked,g?hypotf(rf(player+0x24)-rf(g+0x24),rf(player+0x2c)-rf(g+0x2c)):0);if(buttons)buttons(v);need(f<2300,"test finishes");
}
'''
 body=body.replace('ROOM',str(room)).replace('PARAM',str(param)).replace('TEXT',str(text)).replace('ABSENT','1'if tag in ['old-stairs','adult-wallace','adult-trio']else'0').replace('BATS',str({5:1,8:1,11:2}.get(room,-1))).replace('SHIELD','1'if tag=='shield'else'0').replace('TAG',tag)
 body=body.replace('STANDZ',str(pos[2]-92 if tag=='susie' else pos[2]+42)).replace('STANDYAW','0' if tag=='susie' else '32767')
 for k,v in zip(['X','Y','Z'],pos):body=re.sub(r'\b'+k+r'\b',str(v),body)
 s=s[:a]+body+s[b:];s=s.replace('/workspace/bean-rider/config-%s',str(W/'config-%s')).replace('/workspace/bean-rider/screens-%s',str(W/'screens-%s')).replace('alarm(30)','alarm(120)').replace('alarm(15)','alarm(120)')
 c=W/(tag+'.c');c.write_text(s);runner=W/tag;subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
 q=bytearray(Path('/workspace/deltarune-trio-v52/guest-15.save').read_bytes());struct.pack_into('>III',q,0,4,age,0);struct.pack_into('>i',q,0x135c,0);struct.pack_into('>fffhHhB',q,0x1368,pos[0],pos[1],pos[2]-92 if tag=='susie' else pos[2]+42,0 if tag=='susie' else 0x8000-1,0xdff,4,room);q[0x1409]=1
 if tag=='shield':struct.pack_into('>H',q,0x70,0x1111);struct.pack_into('>H',q,0x9c,struct.unpack_from('>H',q,0x9c)[0]|17)
 save=W/(tag+'.save');save.write_bytes(q)
 with(W/(tag+'.log')).open('w')as f:r=subprocess.run([str(runner),str(W/(mode+'.z64')),tag+'-direct','2400','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=150)
 t=(W/(tag+'.log')).read_text();ok=r.returncode==0 and'SPECIAL_QA_PASSED'in t;print(tag,ok,t[-700:],flush=True);results.append(dict(case=tag,passed=ok,mode=mode,log=tag+'.log'));(W/'qa-results.json').write_text(json.dumps(results,indent=2));assert ok,(tag,t[-1800:])

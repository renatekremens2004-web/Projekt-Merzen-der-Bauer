from pathlib import Path
import sys,subprocess,json,os,struct,re
W=Path(__file__).parent;O=Path('/workspace/oot-burns-pal');old=json.load(open('/workspace/yellow-poe-v70/symbols-normal.json'));sy=json.load(open(W/'all-symbols-normal.json'));base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=re.sub(r'static void alarmcb\(int sig\).*?\nstatic uint32_t savebase=', 'static void alarmcb(int sig){_exit(99);}\nstatic uint32_t savebase=',base,flags=re.S)
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned ready=0,trigger=0;
static void onframe(unsigned f){baseframe(f);if(f<400)return;findplay();if(!play||!player||DebugMemRead16(play+0xa4)!=7)return;
 if(!ready){ready=f;bank();}
 if(f>ready+80&&!DebugMemRead16(COUNT))DebugMemWrite16(WAIT,1);
 if(DebugMemRead16(COUNT)&&!trigger){trigger=f;printf("AUDIO_TRIGGER f=%u sample=%llu rate=%u\n",f,(unsigned long long)audioSamples(),audioRate());}
 if(trigger&&f>trigger+650){bank();printf("AUDIO_QA_PASSED samples=%llu rate=%u\n",(unsigned long long)audioSamples(),audioRate());CoreDoCommand(M64CMD_STOP,0,NULL);}need(f<2300,"audio test ends");}
'''.replace('COUNT',hex(sy['gShadowKnockCountV109'])).replace('WAIT',hex(sy['gShadowKnockWaitV109']))
s=(base[:a]+body+base[b:]).replace('/workspace/bean-rider/config-%s',str(W/'config-%s')).replace('/workspace/bean-rider/screens-%s',str(W/'screens-%s')).replace('alarm(30)','alarm(120)').replace('alarm(15)','alarm(120)');(W/'audio-test.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'audio-test.c'),'-o',str(W/'audio-test'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/proto-soldier-v68/soldier.save').read_bytes());struct.pack_into('>III',q,0,0x37,0,0);struct.pack_into('>i',q,0x135c,0);struct.pack_into('>i',q,0x1364,0);q[0x1409]=1;(W/'audio.save').write_bytes(q)
for tag,rom in [('v111',Path('/tmp/ddan-visibility/normal.z64')),('special',W/'normal.z64')]:
 with(W/(tag+'-audio.log')).open('w')as f:r=subprocess.run([str(W/'audio-test'),str(rom),tag+'-audio-direct','2400','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(W/'audio.save')],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH=str(W/(tag+'.pcm'))),stdout=f,stderr=subprocess.STDOUT,timeout=150)
 assert r.returncode==0 and'AUDIO_QA_PASSED'in(W/(tag+'-audio.log')).read_text(),tag
 print('AUDIO_NATIVE_PASSED',tag,flush=True)

from pathlib import Path
import json,re,subprocess,struct,os
W=Path(__file__).parent;sy=json.load(open(W/'all-symbols-normal.json'));old=json.load(open('/workspace/yellow-poe-v70/symbols-normal.json'));s=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:s=s.replace(hex(old[n]),hex(sy[n]))
s=re.sub(r'static void alarmcb\(int sig\).*?\nstatic uint32_t savebase=', 'static void alarmcb(int sig){_exit(99);}\nstatic uint32_t savebase=',s,flags=re.S)
a=s.index('static void capture_render(void){}');b=s.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned stage=0,mark=400;
static void onframe(unsigned f){baseframe(f);if(f<400)return;findplay();if(!play||!player||DebugMemRead16(play+0xa4)!=1)return;
 unsigned room=DebugMemRead8(play+0x11cbc),w=target(0x173,0x3f9a);float x=1000;
 if(stage==0){x=1000+(f-mark)*4;if(x>1500)x=1500;if(room==1&&w){bank();printf("NATIVE_FIRST_ENTRY f=%u wallace=%x\n",f,w);stage=1;mark=f;}}
 if(stage==1){x=1500;if(f>mark+100)x=1500-(f-mark-100)*4;if(x<950)x=950;if(room==0){bank();printf("NATIVE_EXIT f=%u\n",f);stage=2;mark=f;}}
 if(stage==2){x=950;if(f>mark+100)x=950+(f-mark-100)*4;if(x>1500)x=1500;if(room==1&&w&&f>mark+200){bank();need(r32(w+0x134)!=0,"returning Wallace drawable");printf("NATIVE_REENTRY_PASSED f=%u\n",f);CoreDoCommand(M64CMD_STOP,0,NULL);}}
 position(player,x,0,-320,16384);if(f%200==0)printf("TRANSITION stage=%u room=%u x=%.1f\n",stage,room,x);need(f<2000,"room transitions finish");}
'''
s=(s[:a]+body+s[b:]).replace('/workspace/bean-rider/config-%s',str(W/'config-%s')).replace('/workspace/bean-rider/screens-%s',str(W/'screens-%s')).replace('alarm(30)','alarm(120)').replace('alarm(15)','alarm(120)');(W/'transition.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'transition.c'),'-o',str(W/'transition'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/deltarune-trio-v52/guest-15.save').read_bytes());struct.pack_into('>III',q,0,4,1,0);struct.pack_into('>i',q,0x135c,0);struct.pack_into('>fffhHhB',q,0x1368,1000,0,-320,16384,0xdff,4,0);q[0x1409]=1;(W/'transition.save').write_bytes(q)
with(W/'transition.log').open('w')as f:r=subprocess.run([str(W/'transition'),str(W/'normal.z64'),'transition-direct','2200','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(W/'transition.save')],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=150)
print(r.returncode,(W/'transition.log').read_text()[-1400:]);assert r.returncode==0 and'NATIVE_REENTRY_PASSED'in(W/'transition.log').read_text()

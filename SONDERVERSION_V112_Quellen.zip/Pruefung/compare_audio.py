from pathlib import Path
import struct,json,sys
sys.path.insert(0,'/workspace/oot-burns-pal/tools');import crunch64
W=Path(__file__).parent;old=Path('/tmp/ddan-visibility/normal.z64').read_bytes();new=(W/'normal.z64').read_bytes();dma=0x7950
def seg(r,i):
 vs,ve,ps,pe=struct.unpack_from('>IIII',r,dma+i*16);return bytes(r[ps:ps+ve-vs]if pe==0 else crunch64.yaz0.decompress(r[ps:pe]))
for i,name in [(3,'Audiobank'),(4,'Audioseq'),(5,'Audiotable')]:
 a,b=seg(old,i),seg(new,i);changes=[j for j,(x,y)in enumerate(zip(a,b))if x!=y];print(name,len(a),len(b),'changes',len(changes),'range',changes[:10],changes[-10:]);(W/(name+'-comparison.json')).write_text(json.dumps(dict(before_size=len(a),after_size=len(b),changed_bytes=len(changes),first_offsets=changes[:20]),indent=2))
 if i in [3,5]:assert a==b,(name,'unrequested sound change')

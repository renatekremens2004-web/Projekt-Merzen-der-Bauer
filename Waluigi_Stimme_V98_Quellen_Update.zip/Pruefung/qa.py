from pathlib import Path
import os,sys,json,re,subprocess,struct,runpy
W=Path(__file__).resolve().parent;rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1])
if(W/'qa-case.txt').exists()and(W/'qa-case.txt').read_text().strip()=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit()
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned seen[3],maxpos[3],notice=0,queued=0;
static unsigned lengths[]={LENNOTICE,LENAGONY,LENCRY};
static void sound(unsigned id){unsigned w=DebugMemRead8(REQWRITE),p=REQUESTS+w*24;DebugMemWrite16(p,id);DebugMemWrite32(p+4,DEFAULTPOS);DebugMemWrite8(p+8,4);DebugMemWrite32(p+12,DEFAULTSCALE);DebugMemWrite32(p+16,DEFAULTSCALE);DebugMemWrite32(p+20,DEFAULTREVERB);DebugMemWrite8(REQWRITE,(w+1)&255);printf("SFX_QUEUE %04x\n",id);}
static void onframe(unsigned f){
 baseframe(f);if(f<350)return;findplay();if(!play||!player||DebugMemRead16(play+0xa4)!=6)return;
 unsigned nb=actor(0xc3);
 if(nb&&f>400&&f<450)position(player,rf(nb+0x24)+40,rf(nb+0x28),rf(nb+0x2c)+20,0);
 if(seen[0]&&f<650)notice=1;
 if(f==650){sound(0x685b);queued|=1;}if(f==900){sound(0x685a);queued|=2;}
 unsigned notes=r32(AUDIO+0x352c),num=r32(AUDIO+0x2894);
 for(unsigned i=0;i<num&&i<100;i++){
  unsigned n=notes+i*0xe0;if(!(DebugMemRead8(n+0xc0)&128)||DebugMemRead8(n+0x33)!=0)continue;
  unsigned t=r32(n+0xd0);if(t<0x80000000||t>=0x80400000)continue;unsigned sample=r32(t);if(sample<0x80000000||sample>=0x80400000)continue;
  unsigned loop=r32(sample+8);if(loop<0x80000000||loop>=0x80400000)continue;unsigned end=r32(loop+4),pos=r32(n+0x18);
  for(unsigned k=0;k<3;k++)if(end>=lengths[k]&&end<=lengths[k]+32){if(!seen[k])printf("NEW_VOICE role=%u samples=%u tuning=%.5f\n",k,end,rf(t+4));seen[k]=1;if(pos>maxpos[k])maxpos[k]=pos;}
 }
 if(f==500||f==760||f==1040)bank();
 if(f>1200){
  need(nb&&notice,"Waluigi notices child Link naturally");need(queued==3,"other two original IDs requested");
  for(unsigned k=0;k<3;k++){printf("VOICE_COMPLETE role=%u expected=%u played=%u\n",k,lengths[k],maxpos[k]);need(seen[k]&&maxpos[k]>lengths[k]*.90f,"replacement sample plays through without early cutoff");}
  bank();puts("WALUIGI_VOICES_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);
 }
}
'''
meta=json.loads((W/'manifest.json').read_text());lens={x['role']:round(x['duration']*16000)for x in meta['clips']}
replace={'LENNOTICE':lens['notice'],'LENAGONY':lens['agony'],'LENCRY':lens['cry'],'AUDIO':sy['gAudioCtx'],'REQWRITE':sy['gSfxRequestWriteIndex'],'REQUESTS':sy['sSfxRequests'],'DEFAULTPOS':sy['gSfxDefaultPos'],'DEFAULTSCALE':sy['gSfxDefaultFreqAndVolScale'],'DEFAULTREVERB':sy['gSfxDefaultReverb']}
for k,v in replace.items():body=body.replace(k,str(v)if k.startswith('LEN')else hex(v))
c=W/f'probe-{mode}.c';c.write_text(base[:a]+body+base[b:]);runner=Path('/tmp')/f'waluigi-v98-{mode}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0x82,1,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,-100,-50,0,0,0xdff,0x82,0);q[0x1409]=1
v=struct.unpack_from('>H',q,0xed4+9*2)[0];struct.pack_into('>H',q,0xed4+9*2,v&~0x30);save=W/'child.save';save.write_bytes(q)
with(W/f'qa-{mode}.log').open('w')as out:r=subprocess.run([str(runner),rom,f'waluigi-v98-direct-{mode}','1600','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/tmp/waluigi-v98-'+mode+'.pcm'),stdout=out,stderr=subprocess.STDOUT,timeout=400)
assert r.returncode==0,(r.returncode,(W/f'qa-{mode}.log').read_text()[-2000:]);assert 'WALUIGI_VOICES_PASSED'in(W/f'qa-{mode}.log').read_text()

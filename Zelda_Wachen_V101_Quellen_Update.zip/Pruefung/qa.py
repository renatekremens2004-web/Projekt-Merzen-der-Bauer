from pathlib import Path
import sys,json,subprocess,os,re,struct,runpy
W=Path(__file__).resolve().parent;rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1])
if (W/'qa-case.txt').exists()and(W/'qa-case.txt').read_text().strip()=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit()
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned began=0,seenlegend=0,seenreturn=0,seenportal=0,prevpos=0,pages=0,maxcs=0,positions[8];
static void onframe(unsigned f){
 baseframe(f);if(f<305)return;findplay();if(!play||!player)return;
 unsigned scene=DebugMemRead16(play+0xa4),cs=DebugMemRead16(play+0x1d74),msg=play+0x20d8,id=DebugMemRead16(msg+0xe2f8),mode=DebugMemRead8(msg+0xe304),pos=DebugMemRead16(msg+0xe3ce);
 if(f%180==0)printf("STATE f=%u scene=%x cs=%u id=%04x mode=%x pos=%u pages=%u\n",f,scene,cs,id,mode,pos,pages);
 if(scene==0x47){
  if(!began){began=1;bank();}
  if(cs>maxcs)maxcs=cs;
  need(DebugMemRead8(AUDIO+0x3534)!=114,"Merz void music is not used in the goddess legend");
  if(id==0x7036&&(mode==6||mode==8)){
   seenlegend=1;
   if(pos&&pos!=prevpos){prevpos=pos;need(pages<8,"no duplicate or runaway legend pages");positions[pages++]=pos;printf("LEGEND_PAGE index=%u msgpos=%u cs=%u\n",pages,pos,cs);need(DebugMemRead16(msg+0xe3d4)<=200,"decoded legend page stays inside native200bytebuffer");CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  }
 }else if(began&&scene==0x4a){
  seenreturn=1;
  if(id==0x7037&&mode)seenportal=1;
  if(id==0x2076&&mode){
   need(seenlegend&&seenreturn&&seenportal,"legend returns to Zelda and resumes the portal dialogue");need(pages==6,"all six timed legend pages fully traversed");need(maxcs>=686,"cutscene reaches its native end-text frame");bank();puts("ZELDA_V101_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);
  }
 }
 if(buttons)buttons((scene==0x4a&&f%20<2&&(mode==6||mode==7||mode==0x34||mode==0x35))?0x80:0);
 need(f<3000,"legend and following Zelda dialogue finish");
}
'''.replace('AUDIO',hex(sy['gAudioCtx']))
c=W/f'probe-{mode}.c';c.write_text(base[:a]+body+base[b:]);exe=W/f'probe-{mode}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0xa0,1,0xfff7);q[0xed4:0xf34]=bytes(0x60);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,0,0,0,0,0xdff,0xa0,0);q[0x1409]=1;save=W/'legend.save';save.write_bytes(q)
with(W/f'qa-{mode}.log').open('w')as log:r=subprocess.run([str(exe),rom,f'zelda-v101-direct-{mode}','3300','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH=str(W/(mode+'.pcm'))),stdout=log,stderr=subprocess.STDOUT,timeout=400)
log=(W/f'qa-{mode}.log').read_text();assert r.returncode==0 and'ZELDA_V101_PASSED'in log,(r.returncode,log[-2500:]);print('NATIVE_ZELDA_DIALOGUE_VERIFIED',mode,flush=True)

from pathlib import Path
import hashlib, json, shutil, subprocess, zipfile
from PIL import Image

W=Path('/workspace/wallace-cheer'); R=Path('/workspace/Projekt-Merzen-der-Bauer'); O=Path('/workspace/oot-burns-pal'); D=Path('/workspace/bean-download-delivery'); A=Path('/workspace/artifacts')
P=R/'previews/wallace-cheer'; V=R/'validation/wallace-cheer'
P.mkdir(parents=True,exist_ok=True); V.mkdir(parents=True,exist_ok=True)
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
sha=digest(O/'build/pal-1.0/oot-pal-1.0-compressed.z64')
report=json.loads((O/'build/pal-1.0/wallace-cheer-verification.json').read_text())
patch_report=json.loads((W/'patch-verification.json').read_text())
assert sha==report['rom_sha256']==patch_report['target_sha256']
def check_video(p,frames):
    s=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height,nb_frames,avg_frame_rate','-of','json',str(p)],text=True))['streams'][0]
    assert (s['codec_name'],s['width'],s['height'],int(s['nb_frames']),s['avg_frame_rate'])==('h264',640,480,frames,'50/3')
records={}
for topic in ['wallace-free-native','credits']:
    name=topic+'-v1'; m=json.loads((W/(name+'.json')).read_text()); log=(W/(name+'.log')).read_text()
    assert m['rom_sha256']==sha and m['ram_bytes']==4194304 and 'completed: 0' in log
    assert not any(x in log for x in ['OBJECT_BANK_OVERFLOW','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
    assert digest(A/m['mp4'])==m['mp4_sha256']; check_video(A/m['mp4'],m['frames']); records[topic]=m
    for ext in ['.json','.log']: shutil.copyfile(W/(name+ext),V/(name+ext))
short=A/'Wallace_Froehlich_Kurz.mp4'; check_video(short,267)
excerpt=dict(file=short.name,source=records['wallace-free-native']['mp4'],source_relative_first_frame=883,frames=267,duration_seconds=16.02,continuous_excerpt=True,rom_sha256=sha,sha256=digest(short))
(V/'Kurzclip.json').write_text(json.dumps(excerpt,indent=2)+'\n')
for name in ['prepare_runtime.py','record.py','record_runner.c','record_input.c','verification.log','release-path-comparison.json','check_patch.js','patch-verification.json','package.py']:
    shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/wallace-cheer-verification.json',V/'wallace-cheer-verification.json')
shots=[]
for topic,index,name in [
    ('wallace-free-native',300,'Wallace_Gespraech.png'),
    ('wallace-free-native',1030,'Wallace_Gesten.png'),
    ('wallace-free-native',1040,'Wallace_Schritt_1.png'),
    ('wallace-free-native',1048,'Wallace_Schritt_2.png'),
    ('wallace-free-native',1065,'Wallace_Armbewegung.png'),
    ('credits',190,'Weisen_Credits.png'),('credits',390,'Schultersitz.png')]:
    m=records[topic]; ext='ppm' if topic=='wallace-free-native' else 'png'
    im=Image.open(Path(m['screenshot_folder'])/f'frame-{index:05d}.{ext}').convert('RGB'); im.save(P/name)
    assert im.tobytes()==Image.open(P/name).convert('RGB').tobytes()
    shots.append(dict(file=name,case=m['case'],frame=m['first_frame']+index,rom_sha256=sha,unaltered_emulator_image=True))
(P/'Aufnahmen.json').write_text(json.dumps(shots,ensure_ascii=False,indent=2)+'\n')

doc=f'''# Wallace: lebhaftere Befreiung

Kumulativer Gesamtpatch für unveränderte Europa/PAL 1.0, Original-MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{sha}`, weiterhin 40 MiB. Alle bisherigen Änderungen enthalten, insbesondere Wallaces Laufbewegung, der kleinere Weisen-Waluigi und die angepaßten Nahaufnahmen. Sämtliche Dialoge bleiben erhalten.

## Bewegung

Wallace gestikuliert mit Ober- und Unterarmen abwechselnd, nickt, neigt den Oberkörper leicht und wippt. Beim nativen Weggehen hebt er die Füße stärker an und federt mit. Zwei eigene Ellbogengruppen ergänzen die bisher zehn Gruppen. Bestehende Unterarmvertices werden nur neu zugeordnet; alle Positionen, Dreiecke, Normalen, UVs und Materialien bleiben unverändert. Weiterhin Höhe 90 und 2.269 Dreiecke. Unterarme erben die vollständige Schultertransformation, bevor sie sich am Ellbogen beugen. Keine Skalierung oder Scherung durch diese Pose.

Die Knie berücksichtigen das Wippen im Stand und die stärkere Bewegung beim Gehen. Die zweigliedrige inverse Kinematik hält den Standfuß am Boden und die Sohle waagerecht. Analytische Prüfung über 240 Gestenzeiten, 61 Fluchttimerwerte und beide Beine: erreichbare Fußziele ohne ideale Bodendurchdringung, maximale Rechenabweichung unter 1e-9 Modelleinheiten. Dies belegt die Sollgeometrie; tatsächliche N64-Matrizen verwenden die übliche begrenzte Genauigkeit.

Nur der Feuertempel-Gefangene erhält den Gestenparameter 1. Feuerweisenrolle, Finale und Credits verwenden 0: bisherige Posen und Schultersitz bleiben erhalten. Kind-Wallace unverändert.

## Ablauf und Speicher

Native Akteurssteuerung, Zelle, Bodenschalter, Weg, Geschwindigkeit, Zeiten, Kamera, Texte und Belohnung sind unverändert. Quellenvergleich: In EnGo2 und DemoDu ändert sich außerhalb der privaten Zeichnung ausschließlich das zusätzliche Aufrufargument. Laufzeitvergleich zum vorigen Patch: dieselben Zustandswechsel bei Frames 600, 1628, 1688 und 1689, gleiche Schalterbits und Akteurspositionen. Die Befreiung läuft über den echten Schalter und endet regulär.

Zwei zusätzliche 64-Byte-Matrizen pro Zeichnung, also 128 Bytes gegenüber der vorigen Laufkorrektur. Modellsegment und Feuertempelraum wachsen jeweils um 144 Bytes durch Matrix-/Vertexbefehle; die beiden Zeichenoverlays um jeweils 1.216 Bytes. Kein neuer Objekt-Slot, keine zusätzliche Geometrie, keine größere Akteursinstanz. Beide Szenen laufen mit tatsächlichen 4 MiB N64-RAM. Kein beobachteter Absturz, Objektpufferüberlauf oder ungültiger Grafikbefehl.

## Aufnahmen

| MP4 | Dauer | Bilder |
| --- | ---: | ---: |
| Wallace_Froehlich_Kurz.mp4 | 16,02 s | 267 |
| Wallace_Froehliche_Befreiung.mp4 | 69,00 s | 1150 |
| Wallace_Gesten_Weisen_Credits.mp4 | 38,82 s | 647 |

Echte fortlaufende Emulatorbilder aus demselben finalen Build: 640×480, H.264, PAL 50/3 Bilder/s, ohne Ton. Kurzclip ist ein zusammenhängender Ausschnitt aus den letzten 267 Bildern der vollständigen Befreiung. Vollclip enthält Gespräch und natives Weggehen. Credits zeigen erneut die gemeinsamen Weisen einschließlich Schultersitz und regulärem Szenenübergang. Lokale Ausgangsspielstände bereiten die Kapitel vor; anschließend Controller-Eingaben und native Spielsteuerung. Keine für die Aufnahme versetzten NPCs, umgeschalteten Fluchtzustände oder geänderten Kameras. Framefolge und MP4-Bildzahlen geprüft. PNGs verlustfrei aus denselben Quelldaten umgewandelt.

## Gesamtpatch

Alle 1.509 komprimierten Segmente und CIC-6105-Prüfsumme geprüft. Die drei Sprachsegmente sowie alle 1.013 eigenen Nachrichten bytegleich zur vorigen Fassung. Alle anderen Modelle und Kameras unverändert. Native Kern-/Questfunktionen trotz geänderter Linkadressen erhalten; vollständiger Bericht unter `validation/wallace-cheer/`. RomPatcher.js erzeugt mit eingeschalteter Quellprüfung aus Vanilla und BPS bytegenau die oben genannte Produktions-ROM.

Ein vollständiger normaler Durchlauf und echte N64-Hardware wurden in diesem Schritt nicht geprüft. Keine ROMs, Spielstände, Savestates, RAM-Abzüge oder ausführbaren Dateien veröffentlicht.

## Neubau

Am Ende der bestehenden Buildfolge `build_character_sizes.py`, dann `build_walk_followup.py`, dann **`build_wallace_cheer.py`** mit dem Decomp-Verzeichnis ausführen; anschließend normal bauen/komprimieren. Der letzte Schritt installiert die zwölfteilige Zeichnung und den zusätzlichen Gestenparameter. Vorbereitete Modelldaten und die unveränderten Sitzanimationen sind im Quellenpaket enthalten. `verify_wallace_cheer.py` benötigt die vorige Produktions-ROM mit Map/Modell-/Actorquellenschnappschüssen als lokale Vergleichsdaten. ROM-Vergleichsdaten werden nicht veröffentlicht.
'''
(R/'TESTING_WALLACE_GESTEN.md').write_text(doc); (P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Wallace_Gesten.bps'; shutil.copyfile(patch,R/'patches'/patch.name)
heading='# Wallace: mehr Gesten bei der Befreiung'
readme=R/'README.md'
if not readme.read_text().startswith(heading):
    readme.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Prüfbericht](TESTING_WALLACE_GESTEN.md) · [Echte Bilder](previews/wallace-cheer/)\n\nBewegliche Ellbogen, abwechselnde Armgesten, Kopfnicken und federnde Schritte. Eigene Proportionen und Höhe 90 erhalten; alle bisherigen Änderungen enthalten. Befreiung und gemeinsame Credits mit 4 MiB geprüft. Am Ende der Buildfolge `build_wallace_cheer.py` nach `build_walk_followup.py` ausführen. Drei MP4s liegen getrennt vom Quellenarchiv.\n\n'+readme.read_text())

archive=A/'Merzen_Wallace_Gesten_Quellen_Patch.zip'
suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'}
exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
    for p in sorted(R.rglob('*')):
        rel=p.relative_to(R)
        allowed_original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
        allowed_original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
        if not p.is_file()or(any(x in exclude for x in rel.parts)and not allowed_original)or p.suffix.lower()not in suffixes: continue
        if rel.parts[0]=='patches'and p.name!=patch.name: continue
        if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='wallace-cheer': continue
        with p.open('rb')as f: assert f.read(4)not in [bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
        z.write(p,rel)
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None
    assert not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st','.mp4'}for n in z.namelist())
instruction=A/'Anleitung_Wallace_Gesten.txt'
instruction.write_text('Gesamtpatch: Wallace gestikuliert bei der Befreiung und geht mit federnden Schritten.\n\nAuf die entpackte, unveränderte Europa/PAL-1.0-ROM anwenden, nicht auf eine bereits gepatchte Fassung. Original-MD5 e040de91a74b61e3201db0e2323f768a. Alle bisherigen Änderungen enthalten. https://www.marcrobledo.com/RomPatcher.js/\n\nNormale Spielstände verwenden. Alte Emulator-Savestates können vorherige Modelle/Overlays im RAM enthalten. MP4s aus diesem finalen Patch ohne Ton, mit tatsächlichen 4 MiB aufgenommen. Kurzclip: zusammenhängender Ausschnitt; vollständige Befreiung und gemeinsame Weisen-Credits separat.\n')
files=[patch,archive,instruction,short]+[A/m['mp4']for m in records.values()]
sums=A/'SHA256SUMS_Wallace_Gesten.txt'; sums.write_text(''.join(digest(p)+'  '+p.name+'\n'for p in files))
for p in files+[sums]: shutil.copyfile(p,D/p.name)
G=D/'Wallace_Gesten_Beispielbilder'; G.mkdir(exist_ok=True)
for p in P.iterdir(): shutil.copyfile(p,G/p.name)
readme=D/'README.md'
if not readme.read_text().startswith(heading):
    readme.write_text(heading+'\n\n[MP4: kurzer Eindruck](Wallace_Froehlich_Kurz.mp4?raw=true) · [Vollständige Befreiung](Wallace_Froehliche_Befreiung.mp4?raw=true) · [Gemeinsame Weisen-Credits](Wallace_Gesten_Weisen_Credits.mp4?raw=true)\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Quellen]('+archive.name+'?raw=true) · [Prüfbericht](Wallace_Gesten_Beispielbilder/Pruefbericht.md)\n\nWallace mit beweglichen Ellbogen, Armgesten, Kopfnicken und federnden Schritten. Alle bisherigen Änderungen enthalten. BPS auf unveränderte Vanilla Europa/PAL 1.0 anwenden. Videos ohne Ton; Befreiung und gemeinsame Credits mit 4 MiB geprüft.\n\n'+readme.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=sha,files=[p.name for p in files+[sums]],records=records,excerpt=excerpt),indent=2)+'\n')
print('Packaged',sha,'source ZIP bytes',archive.stat().st_size,'public files',len(files)+1)

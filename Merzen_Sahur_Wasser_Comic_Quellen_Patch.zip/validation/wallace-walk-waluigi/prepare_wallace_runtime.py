from pathlib import Path
import re,json,subprocess,shutil
W=Path('/workspace/wallace-walk-waluigi');O=Path('/workspace/oot-burns-pal')
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
plugin=Path('/workspace/bean-rider/test_input.c').read_text()+'''\nstatic void (*capture)(void);\nEXPORT void TestSetRenderCapture(void (*callback)(void)) { capture=callback; }\nEXPORT void CALL RenderCallback(void) { if(capture)capture(); }\n'''
(W/'record_input.c').write_text(plugin)
subprocess.run(['gcc','-O2','-shared','-fPIC','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'record_input.c'),'-o',str(W/'record_input.new.so')],check=True)
(W/'record_input.new.so').replace(W/'record_input.so')
s=Path('/workspace/wawario-bros/free_runner.c').read_text().replace('0x800ef7c0+3*0x30',hex(syms['gGameStateOverlayTable'])+'+3*0x30').replace('0x800f7488+obj*8',hex(syms['gObjectTable'])+'+obj*8')
s=s.replace('/workspace/bean-rider/test_input.so',str(W/'record_input.so'))
s=s.replace('signal(SIGSEGV,crash);','signal(SIGSEGV,crash);signal(SIGILL,crash);')
s=s.replace('static void onframe(unsigned f){','static void baseframe(unsigned f){')
s=re.sub(r'CoreDoCommand\(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL\);','/* frames captured continuously below */',s)
s=s.replace('if(buttons)buttons(value);','if(buttons)buttons(strstr(scenario,"credits") ? 0 : value);')
s=s.replace('#include <stdio.h>','#include <stdio.h>\n#include <dirent.h>')
idx=s.index('\nstatic void setting(')
wrapper=r'''
static unsigned capturePending=0,captureIndex=0;
static void capture_raw(unsigned frame) {
 static unsigned char* pixels=NULL;static int width=0,height=0;
 char dir[600],name[700];
 if(!pixels){
  int size=0;if(CoreDoCommand(M64CMD_CORE_STATE_QUERY,M64CORE_VIDEO_SIZE,&size))exit(94);
  width=(size>>16)&65535;height=size&65535;
  if(width!=640 || height!=480)exit(94);
  pixels=malloc(width*height*3);if(!pixels)exit(94);
 }
 if(CoreDoCommand(M64CMD_READ_SCREEN,0,pixels))exit(94);
 snprintf(dir,sizeof(dir),"/workspace/bean-rider/screens-%s/raw",scenario);mkdir(dir,0700);
 snprintf(name,sizeof(name),"%s/frame-%06u.ppm",dir,frame);
 FILE* out=fopen(name,"wb");if(!out)exit(94);fprintf(out,"P6\n%d %d\n255\n",width,height);
 for(int y=height-1;y>=0;y--)if(fwrite(pixels+y*width*3,1,width*3,out)!=(size_t)width*3)exit(94);
 fclose(out);
}
static void capture_render(void) {
 if(capturePending){capture_raw(captureIndex);capturePending=0;}
}
static void onframe(unsigned f) {
 static unsigned started=0,first=0,total=0,transition=0,endQueued=0,sawTalk=0,sawEscape=0,lastStage=999;
 baseframe(f);
 if(endQueued){if(!capturePending)CoreDoCommand(M64CMD_STOP,0,NULL);return;}
 if(f<305)return;
 findplay();if(!play)return;
 unsigned scene=DebugMemRead16(play+0xa4),credits=strstr(scenario,"credits")!=NULL;
 uint32_t go=actor_type(0x1ae,3);
 unsigned msg=DebugMemRead16(play+0x20d8+0xe2f8),state=go?DebugMemRead8(go+0x202):255;
 if(!started && ((credits && scene==0x60) || (!credits && f>=600 && scene==4))) {
  started=1;first=f;printf("VIDEO_START frame=%u scene=%x\n",f,scene);
 }
 if(!started)return;
 if(msg==0x209d)sawTalk=1;
 if(sawTalk && state>=2 && state<=4)sawEscape=1;
 if(!credits && state!=lastStage){printf("FREE_STAGE frame=%u state=%u go=%08x switch=%08x pos=(%.1f %.1f %.1f)\n",f,state,go,r32(play+0x1d28),go?rf(go+0x24):0,go?rf(go+0x28):0,go?rf(go+0x2c):0);lastStage=state;}
 if(!transition && ((credits && scene!=0x60) || (!credits && sawEscape && !go))) {
  transition=f;printf("VIDEO_TRANSITION frame=%u scene=%x count=%u sawTalk=%u sawEscape=%u\n",f,scene,total,sawTalk,sawEscape);
 }
 if(transition && f>transition+60){printf("VIDEO_END first=%u last_exclusive=%u frames=%u transition=%u\n",first,f,total,transition);endQueued=1;return;}
 if(credits && f%50==0){
  unsigned ids[]={0xa8,0xc9,0xd2,0xc3,0xa9};printf("FIVE_SAGES frame=%u scene=%x RAM=%u",f,scene,r32(0x80000318));for(int i=0;i<5;i++){unsigned a=actor(ids[i]);printf(" %x=%08x",ids[i],a);}printf("\n");
 }
 if(credits)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);else {if(capturePending)exit(94);captureIndex=total;capturePending=1;}total++;
}
'''
s=s[:idx]+wrapper+s[idx:]
s=s.replace('if(i==3)buttons=dlsym(plugin,"TestSetButtons");','if(i==3){buttons=dlsym(plugin,"TestSetButtons");void(*setCapture)(void(*)(void))=dlsym(plugin,"TestSetRenderCapture");if(!setCapture)return 95;setCapture(capture_render);}')
(W/'record_runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'record_runner.c'),'-o',str(W/'record_runner.new'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
(W/'record_runner.new').replace(W/'record_runner')
for src,dest in [('/workspace/wawario-bros/wallace-free-native.save','wallace-free-native.save'),('/workspace/feuertempel-wallace/credits.save','credits.save'),('/workspace/feuertempel-wallace/hall.save','hall.save'),('/workspace/wawario-bros/blue.save','blue.save'),('/workspace/wawario-bros/blue-child.save','blue-child.save')]:shutil.copyfile(src,W/dest)
# Current symbols for still/interaction probes, using the established latest harness.
s=Path('/workspace/yellow-guy/runner.c').read_text().replace('0x800ef7c0+3*0x30',hex(syms['gGameStateOverlayTable'])+'+3*0x30').replace('0x800f7488+obj*8',hex(syms['gObjectTable'])+'+obj*8');(W/'runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner.new'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
(W/'runner.new').replace(W/'runner')
print('Prepared current-symbol runners and local player/progress fixtures.')

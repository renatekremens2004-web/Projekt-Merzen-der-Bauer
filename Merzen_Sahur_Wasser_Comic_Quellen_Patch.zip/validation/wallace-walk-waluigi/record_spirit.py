from pathlib import Path
import sys,os,re,json,hashlib,subprocess
W=Path('/workspace/wallace-walk-waluigi');A=Path('/workspace/artifacts');rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64');topic=sys.argv[1];run=os.environ.get('RUN','v1');syms=json.loads((W/'symbols.json').read_text());case='new-sages-'+topic+'-motion-'+run+'-direct-clip-on'
names={'spirit-child':'Waluigi_01_Begegnung_Kind.mp4','kidnap':'Waluigi_02_Entfuehrung.mp4','knuckle-reveal':'Waluigi_03_Eisenprinz_Enthuellung.mp4','hall-spirit':'Waluigi_04_Halle_der_Weisen.mp4'};assert topic in names
folder=Path('/workspace/bean-rider')/('screens-'+case);assert not folder.exists(),case;sha=hashlib.sha256(rom.read_bytes()).hexdigest()
env=dict(os.environ,DISPLAY=':99',MESA_SHADER_CACHE_DIR=str(W/'mesa-fresh'))
with(W/(topic+'-'+run+'.log')).open('w')as log:subprocess.run([str(W/'spirit_runner'),str(rom),case,'6000','4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/(topic+'.save'))],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1200)
s=(W/(topic+'-'+run+'.log')).read_text();m=re.search(r'VIDEO_END first=(\d+) last_exclusive=(\d+) frames=(\d+) transition=(\d+)',s);assert m and 'completed: 0'in s
first,end,count,transition=map(int,m.groups());files=sorted((folder/'raw').glob('*.ppm'));assert len(files)==count==end-first
assert not any(x in s for x in ['OBJECT_BANK_OVERFLOW','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
assert 'RAM=4194304'in s and transition>first and 'nb=80'in s
name=names[topic];out=A/name
subprocess.run(['ffmpeg','-y','-v','error','-framerate','50/3','-start_number','0','-i',str(folder/'raw/frame-%06d.ppm'),'-frames:v',str(count),'-c:v','libx264','-threads','2','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True)
meta=dict(rom_sha256=sha,case=case,first_frame=first,last_frame_exclusive=end,frames=count,transition_frame=transition,pal_frames_per_second='50/3',duration_seconds=count*3/50,silent=True,continuous_native_gameplay=True,controller_only_after_local_start_fixture=True,native_actor_positions_and_camera=True,ram_bytes=4194304,raw_folder=str(folder/'raw'),mp4=name,mp4_sha256=hashlib.sha256(out.read_bytes()).hexdigest());(W/(topic+'-'+run+'.json')).write_text(json.dumps(meta,indent=2)+'\n');print('Recorded',topic,count,'frames',meta['duration_seconds'],'seconds',sha,flush=True)

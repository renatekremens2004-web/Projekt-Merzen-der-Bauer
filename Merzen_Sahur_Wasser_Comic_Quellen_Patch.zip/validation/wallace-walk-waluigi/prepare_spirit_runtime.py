from pathlib import Path
import re,json,subprocess,shutil
W=Path('/workspace/wallace-walk-waluigi');O=Path('/workspace/oot-burns-pal');syms=json.loads((W/'symbols.json').read_text())
s=Path('/workspace/water-spirit-sages/runner.c').read_text().replace('overlays+0x8e10+3*0x30',hex(syms['gGameStateOverlayTable'])+'+3*0x30').replace('0x800f7308+id*8',hex(syms['gObjectTable'])+'+id*8')
s=s.replace('/workspace/bean-rider/test_input.so',str(W/'record_input.so')).replace('signal(SIGSEGV,crash);','signal(SIGSEGV,crash);signal(SIGILL,crash);')
s=s.replace('static void onframe(unsigned f){','static void baseframe(unsigned f){');s=re.sub(r'CoreDoCommand\(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL\);','(void)0;',s)
s=s.replace('if(f>300 && (mode==0 || age>12)', 'if(f>(strstr(scenario,"spirit-child")?150:50) && (mode==0 || age>20)')
s=s.replace('if(f>300 && mode==6', 'if(f>(strstr(scenario,"spirit-child")?150:50) && mode==6')
s=s.replace('  if(f==300 && strstr(scenario,"navi"))', '  if(strstr(scenario,"spirit-child") && id==0x6020 && mode==0x35 && age>=2 && age<6)value=0xc0000000;\n  if(f==300 && strstr(scenario,"navi"))',1)
common=(W/'record_runner.c').read_text();a=common.index('static unsigned capturePending');b=common.index('static void onframe(',a);capture=common[a:b]
wrapper=r'''
static void onframe(unsigned f) {
 static unsigned started=0,first=0,total=0,endQueued=0,transition=0,sawActor=0,sawCs=0,sawLastText=0;
 static unsigned lastAction=999,lastMessage=999;
 baseframe(f);
 if(endQueued){if(!capturePending)CoreDoCommand(M64CMD_STOP,0,NULL);return;}
 if(f<305)return;
 findplay();if(!play)return;
 unsigned child=strstr(scenario,"spirit-child")!=NULL,kidnap=strstr(scenario,"kidnap")!=NULL,reveal=strstr(scenario,"knuckle-reveal")!=NULL;
 unsigned scene=DebugMemRead16(play+0xa4),nb=actor(0xc3),cs=DebugMemRead8(play+0x1d6c);
 unsigned id=DebugMemRead16(play+0x20d8+0xe2f8),mode=DebugMemRead8(play+0x20d8+0xe304);
 unsigned action=nb?r32(nb+0x238):999;
 if(!started && ((!child && ((kidnap && scene==0x5c)||(reveal && scene==0x17)||(!kidnap&&!reveal&&scene==0x44)))||(child && f>=550 && scene==6))) {
  started=1;first=f;printf("VIDEO_START frame=%u scene=%x RAM=%u\n",f,scene,r32(0x80000318));
 }
 if(!started)return;
 if(nb)sawActor=1;
 if(cs)sawCs=1;
 if(action!=lastAction||id!=lastMessage){printf("MOVIE_STATE f=%u scene=%x cs=%u nb=%08x action=%u id=%04x mode=%x\n",f,scene,cs,nb,action,id,mode);lastAction=action;lastMessage=id;}
 if((child && id==0x6025)||(kidnap && id==0x603e)||(reveal && id==0x6034)||(!child&&!kidnap&&!reveal&&id==0x6036))sawLastText=1;
 if(child && sawLastText && mode==0 && buttons)buttons(0);
 if(kidnap && sawLastText && !cs && buttons)buttons(0);
 if(!transition && sawLastText && ((child && mode==0)||(kidnap && !cs && mode==0)||(reveal && !cs && mode==0)||(!child&&!kidnap&&!reveal&&scene!=0x44))) {
  transition=f;printf("VIDEO_TRANSITION frame=%u scene=%x cs=%u sawActor=%u sawCs=%u lastText=%u\n",f,scene,cs,sawActor,sawCs,sawLastText);
 }
 if(transition && f>transition+(child?90:60)) {printf("VIDEO_END first=%u last_exclusive=%u frames=%u transition=%u\n",first,f,total,transition);endQueued=1;return;}
 if(capturePending)exit(94);captureIndex=total;capturePending=1;total++;
}
'''
idx=s.index('\nstatic void setting(');s=s[:idx]+capture+wrapper+s[idx:]
s=s.replace('if(i==3)buttons=dlsym(plugin,"TestSetButtons");','if(i==3){buttons=dlsym(plugin,"TestSetButtons");void(*setCapture)(void(*)(void))=dlsym(plugin,"TestSetRenderCapture");if(!setCapture)return 95;setCapture(capture_render);}')
(W/'spirit_runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'spirit_runner.c'),'-o',str(W/'spirit_runner.new'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True);(W/'spirit_runner.new').replace(W/'spirit_runner')
for name,src in [('spirit-child','spirit-child-quest'),('kidnap','kidnap'),('knuckle-reveal','knuckle-reveal'),('hall-spirit','hall-spirit')]:shutil.copyfile(Path('/workspace/water-spirit-sages')/(src+'.save'),W/(name+'.save'))
print('Prepared current-symbol native Spirit Temple movie fixtures; no actor/scene/camera relocation.')

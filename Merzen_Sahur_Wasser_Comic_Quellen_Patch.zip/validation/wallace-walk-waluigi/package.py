from pathlib import Path
import json,hashlib,shutil,zipfile,subprocess,re
from PIL import Image
W=Path('/workspace/wallace-walk-waluigi');R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts');P=R/'previews/wallace-walk-waluigi';V=R/'validation/wallace-walk-waluigi';P.mkdir(parents=True,exist_ok=True);V.mkdir(parents=True,exist_ok=True)
sha=hashlib.sha256((O/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes()).hexdigest();report=json.loads((O/'build/pal-1.0/walk-waluigi-verification.json').read_text());patch_report=json.loads((W/'patch-verification.json').read_text());assert sha==report['rom_sha256']==patch_report['target_sha256']
records={}
for topic,run in [('spirit-child','v2'),('kidnap','v2'),('knuckle-reveal','v2'),('hall-spirit','v2'),('wallace-free-native','v3'),('credits','v1')]:
 name=topic+'-'+run;meta=json.loads((W/(name+'.json')).read_text());log=(W/(name+'.log')).read_text();assert meta['rom_sha256']==sha and meta['ram_bytes']==4194304 and 'completed: 0'in log
 assert not any(x in log for x in ['OBJECT_BANK_OVERFLOW','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 out=A/meta['mp4'];assert hashlib.sha256(out.read_bytes()).hexdigest()==meta['mp4_sha256']
 stream=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height,nb_frames,avg_frame_rate','-of','json',str(out)],text=True))['streams'][0];assert stream['codec_name']=='h264'and stream['width']==640 and stream['height']==480 and int(stream['nb_frames'])==meta['frames'] and stream['avg_frame_rate']=='50/3'
 records[topic]=meta
 for ext in ['.json','.log']:shutil.copyfile(W/(name+ext),V/(name+ext))
 shutil.copyfile(out,D/out.name)
for n in ['export_shadow_texts.py','prepare_wallace_runtime.py','prepare_spirit_runtime.py','record_wallace.py','record_spirit.py','record_runner.c','spirit_runner.c','record_input.c','verification.log','waluigi_size_comparison.json','shadow-texts.json','release-path-comparison.json','check_patch.js','patch-verification.json','package.py']:
 shutil.copyfile(W/n,V/n)
shutil.copyfile(O/'build/pal-1.0/walk-waluigi-verification.json',V/'walk-waluigi-verification.json')
shots=[]
def photo(topic,index,name):
 m=records[topic]
 if topic in ['wallace-free-native','credits']:
  f=Path(m['screenshot_folder'])/f'frame-{index:05d}.{"ppm"if topic=="wallace-free-native"else"png"}'
 else:f=Path(m['raw_folder'])/f'frame-{index:06d}.ppm'
 im=Image.open(f).convert('RGB');im.save(P/name);assert im.tobytes()==Image.open(P/name).convert('RGB').tobytes();shots.append(dict(file=name,case=m['case'],frame=m['first_frame']+index,rom_sha256=sha,unaltered_emulator_image=True))
for topic,index,name in [('spirit-child',200,'Waluigi_Begegnung.png'),('kidnap',700,'Waluigi_Entfuehrung.png'),('knuckle-reveal',650,'Waluigi_Enthuellung.png'),('hall-spirit',1000,'Waluigi_Weiser.png'),('wallace-free-native',1040,'Wallace_Lauf_Schritt_1.png'),('wallace-free-native',1048,'Wallace_Lauf_Schritt_2.png'),('credits',190,'Weisen_Credits_neuer_Stand.png'),('credits',390,'Wallace_Schultersitz.png')]:photo(topic,index,name)
(P/'Aufnahmen.json').write_text(json.dumps(shots,ensure_ascii=False,indent=2)+'\n')
sizes=json.loads((W/'waluigi_size_comparison.json').read_text());functions=report['retained_native_functions']
rows='\n'.join('| '+records[t]['mp4']+' | '+f"{records[t]['duration_seconds']:.2f}"+' s | '+str(records[t]['frames'])+' |'for t in records)
doc=f'''# Wallace läuft; Weisen-Waluigi paßt zur ursprünglichen Größe

Kumulativer Gesamtpatch für die unveränderte Europa/PAL-1.0-ROM. Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`, Ziel-SHA256 `{sha}`. Weiterhin 40 MiB. Alle bisherigen Änderungen enthalten, einschließlich kleinerem blauen Wawaluigi, Punk-Armen und Triangle Guys ursprünglicher Begrüßung plus Triforce-Zusatz. Keine Dialoge in diesem Schritt geändert; die bereits vorab gelieferte Brunnen-/Schattentempel-Liste bleibt aktuell.

## Wallace

Der vorherige Ersatz hatte lediglich Körper, Kopf und zwei Arme. Seine Beine waren Teil des starren Körpers, während der native Goronen-Akteur bereits auf dem Fluchtweg bewegt wurde. Jetzt hat das gleiche Modell zehn starre Matrixgruppen: Körper, Kopf, beide Arme, beide Oberschenkel, beide Unterschenkel und beide Füße. Höhe weiterhin 90 Spieleinheiten, 2.269 Dreiecke. Alle Modellpositionen, Dreiecke, Normalen, UVs und Texturen erhalten. Nur die Zuordnung der bestehenden unteren Körpervertices zu den neuen Beinteilen ändert sich.

Eine sechzehn Frames lange Gehbewegung ist auf den nativen Fluchtablauf abgestimmt. Zweigliedrige inverse Kinematik läßt das Standbein am Boden stehen und hebt den anderen Fuß an; die Fußmatrix hält die Sohle waagerecht. Sanfter Beginn und Ausklang. Die Bewegung ist ausschließlich im vorhandenen Fluchtzustand 2 bei positiver Geschwindigkeit aktiv. Weisen- und Credits-Auftritte behalten ruhige Beine. Keine Änderung an AI, Bodenschalter, Zelltür, Gespräch, Fluchtweg, Geschwindigkeit, Zustandszeiten oder Belohnung. Die bereits angepaßte Fluchtkamera bleibt erhalten. Sechs weitere 64-Byte-Matrizen pro Zeichnung (384 Bytes); keine zusätzlichen Dreiecke oder Objekt-Slots. Objekt-/Raumdaten wachsen durch zusätzliche Matrixbefehle um je 672 Bytes, bleiben in den vorhandenen Puffern.

## Waluigi

Gemeint ist Waluigi als Ersatz für Naboru, nicht der blaue Wawaluigi am Gerudo-Zelt. Vergleich bei gleicher Standanimation und Akteursskalierung 0,01: Naboru etwa 65,47 Spieleinheiten, bisheriger Waluigi 97,51, neuer Waluigi 73,13. Gleichmäßiger Faktor 0,75 auf sämtliche Modellachsen, eigenen Knochenabstände und Animationswurzelpositionen. So bleibt er etwa 12 Prozent größer als Naboru, statt rund 49 Prozent. Eigene Proportionen bleiben erhalten. 420 Dreiecke, 14 eigene Knochen, Texturen, Normalen, UVs und alle 22 Naboru-Animationen plus die Iron-Knuckle-Enthüllung mit identischen Rotationen und Framezahlen. Das Objekt bleibt exakt 60.144 Bytes groß.

Der kleinere Waluigi gilt bei der Begegnung als Kind, der Entführung, der erwachsenen Enthüllung, dem Weisen-Auftritt, Finale und Credits. Nur die zuvor für das größere Modell korrigierten Nahaufnahmen werden passend neu gerahmt. Geändert sind ausschließlich Augen-/Zielkoordinaten: Halle (Gruppen 263/363/433), Enthüllung (65/85/140/222), spätere Siegelszene (110), Credits-Nahaufnahme (246). Alle Kamera-Zeiten, FOVs, Cutscene-Cues, Texte, Bewegungs- und Questbefehle bytegleich. Andere Kameragruppen bleiben erhalten. Blaue Wawaluigi-Figur, orange Wawario-Figur und normaler Wario unverändert.

## MP4-Nachweise

| Datei | Dauer | Bilder |
| --- | ---: | ---: |
{rows}

Alle sechs Videos sind fortlaufende echte Emulatoraufnahmen desselben oben angegebenen finalen Builds mit tatsächlichen 4 MiB N64-RAM. 640×480, H.264, PAL 50/3 Bilder pro Sekunde, ohne Ton. Keine ersetzten oder für die Vorschau versetzten NPCs/Kameras. Die Kamerakorrekturen sind Teil des spielbaren Patches. Lokale Ausgangsspielstände setzen die jeweiligen Kapitel voraus; danach normale Controller-Eingaben und native Szenen. Keine Akteurspositionen, Schalter, Belohnungen oder Animationszustände für diese Aufnahmen verändert. Beginn/Ende, vollständige gerenderte Framezahl, Reihenfolge und MP4-Framezahl geprüft. Lange Clips lesen jeden gerenderten Frame per nativer READ_SCREEN-API; keine 1.000-Screenshot-Grenze. Standbilder werden unverändert aus diesen Quelldaten in PNG umgewandelt. Kein Ton aufgenommen.

Die Kinderbegegnung enthält alle Gesprächsseiten bis zur Zusage und Waluigis anschließenden nativen Bewegung. Die Entführung endet nach dem regulären Szenenende, die Enthüllung nach der Konfrontation mit den Hexen, die Halle nach dem Amulett und der nativen Rückkehr. Wallace wird über den echten Bodenschalter befreit, liest seine Gesprächsseiten und läuft selbständig aus der Zelle. Die gemeinsamen Weisen-Credits enthalten auch die unverändert auf dem kleineren Wallace sitzende Krabbelminenfrau und den regulären Szenenübergang.

## Prüfung und Grenzen

Alle 1.509 komprimierten Segmente gegen den unkomprimierten Neubau und CIC-6105-Prüfsumme geprüft. Sämtliche deutschen, englischen und französischen Texte unverändert, einschließlich aller 1.013 eigenen Nachrichten. Native Kernfunktionen erhalten: {functions['code']}; Goronenfunktionen {functions['ovl_En_Go2']}; Feuerweisenfunktionen {functions['ovl_Demo_Du']}; Naboru-Funktionen {functions['ovl_En_Nb']}; Iron-Knuckle-Funktionen {functions['ovl_En_Ik']}; Waldweisenfunktionen {functions['ovl_Demo_Sa']}. Private Zeichnung ist erweitert; ursprüngliche Spielsteuerung bleibt erhalten. Geprüfte ideale Stand-/Schwungfuß-Geometrie ohne Bodendurchdringung, einschließlich der Überblendung. Vollständige Protokolle und Größenvergleich im Quellenpaket.

Kein beobachteter Absturz, Objektpufferüberlauf oder ungültiger Grafikbefehl in diesen Proben. Ein vollständiger normaler Durchlauf und echte N64-Hardware sind damit noch nicht geprüft. RomPatcher.js mit eingeschalteter Quellvalidierung erzeugt aus Vanilla und dem BPS bytegenau diese Produktions-ROM. Keine ROMs, Spielstände, Savestates, RAM-Abzüge oder ausführbaren Dateien veröffentlicht. MP4s liegen getrennt vom Quellenarchiv und zusätzlich gemeinsam im Video-ZIP.

Für weitere Builds `build_walk_followup.py` nach `build_character_sizes.py` ausführen. Die vorbereiteten eigenen Modelle und Kameradaten sind enthalten. Blender weiterhin mit `--python-exit-code 1` starten.
'''
(R/'TESTING_WALLACE_WALK_WALUIGI.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Wallace_Laufanimation_Waluigi.bps';shutil.copyfile(patch,R/'patches'/patch.name);shutil.copyfile(patch,D/patch.name)
videozip=A/'Waluigi_Szenen_Wallace_Videos.zip'
with zipfile.ZipFile(videozip,'w',zipfile.ZIP_STORED)as z:
 for m in records.values():z.write(A/m['mp4'],m['mp4'])
 z.writestr('Szenen.txt',rows+'\n\nAlle Videos ohne Ton. Reguläre Animationen, Controller-Eingaben und Cutscenes mit 4 MiB N64-RAM.\n')
heading='# Wallace läuft; Waluigi passend verkleinert';p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Prüfbericht](TESTING_WALLACE_WALK_WALUIGI.md) · [Brunnen und Schattentempel: aktuelle Texte](planning/BRUNNEN_SCHATTENTEMPEL_TEXTE_AKTUELL.md)\n\nWallace mit Hüft-, Knie- und Fußbewegung. Weisen-Waluigi gleichmäßig um 25 Prozent verkleinert, Nahaufnahmen angepaßt. `build_walk_followup.py` zuletzt nach `build_character_sizes.py` ausführen. MP4s werden getrennt veröffentlicht. Alle bisherigen Änderungen enthalten.\n\n'+p.read_text())
archive=A/'Merzen_Wallace_Waluigi_Laufanimation_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);allowed_original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  allowed_original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  if not p.is_file()or(any(x in exclude for x in rel.parts)and not allowed_original)or p.suffix.lower()not in suffixes:continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='wallace-walk-waluigi':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st','.mp4'}for n in z.namelist())
instruction=A/'Anleitung_Wallace_Laufanimation_Waluigi.txt';instruction.write_text('Gesamtpatch: Wallace mit Laufanimation; Weisen-Waluigi um 25 Prozent verkleinert.\n\nAuf die entpackte, unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Alle bisherigen Änderungen enthalten. https://www.marcrobledo.com/RomPatcher.js/\n\nNormale Spielstände verwenden. Alte Emulator-Savestates können die alten Modelle/Overlays im RAM enthalten. Die MP4s stammen aus diesem finalen Patch und sind ohne Ton, mit tatsächlichen 4 MiB aufgenommen.\n')
files=[patch,archive,videozip,instruction]+[A/m['mp4']for m in records.values()];sums=A/'SHA256SUMS_Wallace_Laufanimation_Waluigi.txt';sums.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in files))
for p in files+[sums]:shutil.copyfile(p,D/p.name)
G=D/'Wallace_Waluigi_Animation_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
heading='# Merzen: Wallace läuft und Waluigi paßt';p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Alle sechs MP4s als ZIP]('+videozip.name+'?raw=true) · [Brunnen/Schattentempel: 74 aktuelle Texte](Brunnen_Schattentempel_Texte_Aktuell.md)\n\n[Waluigi: Kind](Waluigi_01_Begegnung_Kind.mp4?raw=true) · [Entführung](Waluigi_02_Entfuehrung.mp4?raw=true) · [Enthüllung](Waluigi_03_Eisenprinz_Enthuellung.mp4?raw=true) · [Halle der Weisen](Waluigi_04_Halle_der_Weisen.mp4?raw=true) · [Wallace: Befreiung](Wallace_Laufanimation_Befreiung.mp4?raw=true) · [Gemeinsame Credits](Wallace_Waluigi_Weisen_Credits.mp4?raw=true)\n\n[Quellen]('+archive.name+'?raw=true) · [Prüfbericht](Wallace_Waluigi_Animation_Beispielbilder/Pruefbericht.md)\n\nWallace weiterhin Höhe 90, jetzt mit Hüft-/Knie-/Fußbewegung beim Weggehen. Weisen-Waluigi etwa 73 statt 98 in derselben Standpose (Original Naboru etwa 65); gleichmäßige Verkleinerung und passende Nahaufnahmen. Blauer Wawaluigi unverändert. Alle bisherigen Änderungen enthalten. Videos ohne Ton, 4 MiB geprüft.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=sha,files=[p.name for p in files+[sums]],records=records),indent=2)+'\n');print('Packaged',sha,'source bytes',archive.stat().st_size,'video ZIP bytes',videozip.stat().st_size)

Native 4-MiB-Prüfungen; siehe ../../TESTING_NPC_STIMMEN.md. Keine ROMs, Spielstände oder Emulator-Binaries enthalten.

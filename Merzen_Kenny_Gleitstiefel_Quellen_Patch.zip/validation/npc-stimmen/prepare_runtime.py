from pathlib import Path
import re,json,struct
W=Path('/workspace/npc-stimmen');O=Path('/workspace/oot-burns-pal');s=Path('/workspace/transition/runner.c').read_text()
block='''  if(f>=450 && f<550 && mode==0 && strstr(scenario,"npcvoice")) {
   uint32_t npc=0;float d=35;
   if(strstr(scenario,"bazaar") || strstr(scenario,"potion") || strstr(scenario,"bombshop")){npc=actor(0x3d);d=80;}
   if(strstr(scenario,"shoot")){npc=actor(0xc1);d=90;}
   if(strstr(scenario,"chest")){npc=actor(0x17c);d=70;}
   if(strstr(scenario,"granny")){npc=actor(0x149);d=70;}
   if(strstr(scenario,"spider")){npc=actor_type(0x188,0);d=55;}
   if(strstr(scenario,"reward"))npc=actor_type(0x189,1);
   if(strstr(scenario,"poes")){npc=actor(0x1b8);d=80;}
   if(strstr(scenario,"deku-ball"))npc=actor_type(0x16e,7);
   if(strstr(scenario,"wax"))npc=actor_type(0x16e,9);
   if(strstr(scenario,"jurisdiction"))npc=actor_type(0xb3,5);
   if(npc){int yaw=DebugMemRead16(npc+0xb6);position(player,rf(npc+0x24)+sinf(yaw*3.14159265f/32768)*d,rf(npc+0x28),rf(npc+0x2c)+cosf(yaw*3.14159265f/32768)*d,yaw+0x8000);if(f==450)printf("NATIVE_NPC f=%u id=%x params=%x position=(%.1f %.1f %.1f)\\n",f,DebugMemRead16(npc),DebugMemRead16(npc+0x1c),rf(npc+0x24),rf(npc+0x28),rf(npc+0x2c));}
  }
  if(f%100==0)printf("INVENTORY f=%u rupees=%u upgrades=%x bottle=%x tokens=%u rewardflags=%x choice=%u\\n",f,DebugMemRead16(savebase+0x34),r32(savebase+0xa0),DebugMemRead8(savebase+0x86),DebugMemRead16(savebase+0xd0),DebugMemRead16(savebase+0xee0),DebugMemRead8(m+0xe3e5));
'''
s=s.replace(' if(buttons)buttons(value);',' if(f>=440 && f<456)value &= ~0x20;\n if(buttons)buttons(value);')
s=s.replace('  if(f==300 && strstr(scenario,"navi"))',block+'  if(f==300 && strstr(scenario,"navi"))')
(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
cases=[('bazaar',0xb7,1,0x8000,(-30.,0.,70.)),('bazaar-en',0xb7,1,0x8000,(-30.,0.,70.)),('potion',0x388,1,0x8000,(0.,0.,70.)),('bombshop',0x390,1,0,(0.,0.,70.)),('shoot',0x3b,1,0x8000,(50.,0.,255.)),('chest',0x63,1,0,(50.,0.,114.)),('granny',0x72,0,0x8000,(-14.,-22.,154.)),('granny-buy',0x72,0,0x8000,(-14.,-22.,154.)),('spider',0x550,1,0x8000,(0.,0.,100.)),('reward',0x550,1,0x8000,(200.,0.,100.)),('poes',0x7e,0,0x8000,(-50.,0.,-100.)),('deku-ball',0xdb,0,0x8000,(-301.,80.,1257.)),('wax',0xdb,0,0x8000,(-909.,0.,555.)),('jurisdiction',0xdb,1,0x8000,(-30.,400.,-1200.))]
for topic,entr,age,time,pos in cases:
 b=bytearray(Path('/workspace/transition/market-pre.save').read_bytes());struct.pack_into('>I',b,0,entr);struct.pack_into('>I',b,4,age);struct.pack_into('>I',b,8,0);struct.pack_into('>H',b,0xc,time);struct.pack_into('>I',b,0x10,int(time==0));struct.pack_into('>H',b,0x141a,time);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,0,0xdff,entr,0);struct.pack_into('>H',b,0x34,150);b[0x1409]=int(not topic.endswith('-en'))
 # All test fixtures start with no Skulltula rewards; testing normal in-game flags.
 if topic=='reward':struct.pack_into('>H',b,0xd0,10);struct.pack_into('>I',b,0xa0,struct.unpack_from('>I',b,0xa0)[0]&~0x3000)
 if topic=='granny-buy':struct.pack_into('>H',b,0xef6,struct.unpack_from('>H',b,0xef6)[0]|1);b[0x86]=0x14;struct.pack_into('>I',b,0xa0,(struct.unpack_from('>I',b,0xa0)[0]&~0x3000)|0x1000)
 (W/(topic+'.save')).write_bytes(b)
(W/'cases.json').write_text(json.dumps([c[0] for c in cases]))

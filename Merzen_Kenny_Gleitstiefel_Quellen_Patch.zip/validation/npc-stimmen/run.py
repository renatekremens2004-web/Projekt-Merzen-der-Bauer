from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/npc-stimmen');s=json.loads((W/'symbols.json').read_text())
def run(name):
 case='npcvoice-'+name+os.environ.get('VOICE_SUFFIX','-v1')+'-focus-direct-clip-on';frames=2200 if name in ['poes','deku-ball','spider'] else 1400
 with (W/(case+'.log')).open('w') as out:subprocess.run([str(W/'runner'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(frames),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(name+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
jobs=json.loads((W/'cases.json').read_text());jobs=sys.argv[1:] or jobs
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,jobs))

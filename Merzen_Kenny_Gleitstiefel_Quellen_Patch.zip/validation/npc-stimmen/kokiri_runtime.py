from pathlib import Path
import struct,re,json,subprocess,os
from concurrent.futures import ThreadPoolExecutor
W=Path('/workspace/npc-stimmen');O=Path('/workspace/oot-burns-pal')
s=(W/'runner.c').read_text().replace('   if(strstr(scenario,"wax"))','   if(strstr(scenario,"kokiri"))npc=actor_type(0x163,4);\n   if(strstr(scenario,"wax"))');(W/'runner-kokiri.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner-kokiri.c'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-Wl,-rpath,/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm','-o',str(W/'runner-kokiri')],check=True)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols-final.json').write_text(json.dumps(syms))
for topic in ['kokiri-happy','kokiri-after']:
 b=bytearray(Path('/workspace/transition/market-pre.save').read_bytes());struct.pack_into('>I',b,0,0xee);struct.pack_into('>I',b,4,1);struct.pack_into('>I',b,8,0);struct.pack_into('>H',b,0xc,0x8000);struct.pack_into('>I',b,0x10,0);struct.pack_into('>H',b,0x141a,0x8000);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,669.,0.,570.,0,0xdff,0xee,0)
 struct.pack_into('>H',b,0xef8,struct.unpack_from('>H',b,0xef8)[0]|3)
 struct.pack_into('>I',b,0xa4,(struct.unpack_from('>I',b,0xa4)[0]&~0x1c0000)|(0x40000 if topic=='kokiri-after' else 0));struct.pack_into('>H',b,0xedc,struct.unpack_from('>H',b,0xedc)[0]&~1);struct.pack_into('>H',b,0xefc,struct.unpack_from('>H',b,0xefc)[0]&~0x10);(W/(topic+'.save')).write_bytes(b)
def run(topic):
 case='npcvoice-'+topic+('-v5' if topic=='kokiri-happy' else ('-v6' if topic=='wax' else '-v4'))+'-focus-direct-clip-on'
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/'runner-kokiri'),str(O/'build/pal-1.0/oot-pal-1.0-compressed.z64'),case,('2200' if topic=='deku-ball' else ('1400' if topic=='wax' else '1800')),'4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,['kokiri-happy','kokiri-after','deku-ball','wax','jurisdiction']))

from pathlib import Path
import sys,re,json
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery');sys.path.insert(0,str(R/'tools'));import build_story as b
m=b.messages((O/'extracted/pal-1.0/text/message_data.h').read_text());chapter=json.loads((R/'story/feuertempel_wallace_de.json').read_text())['messages']
out=['# Eingebaute Feuertempel- und Wallace-Dialoge','','Aus dem tatsächlich gebauten Textbestand. Alte Rechtschreibung; {name} setzt den gewählten Spielernamen ein. Absätze entsprechen Textseiten. Manuelle Seiten dürfen länger werden; native Steuerzeichen und feste Ausblendzeiten bleiben erhalten.','']
for ident in chapter:
 out+=['## '+ident,'']
 out+=['> '+re.sub(r'\s+',' ',b.plain(page)).strip()+'\n'for page in b.split_pages(m[ident]['parts'][2][2])[0]]
s='\n'.join(out)+'\n';(R/'planning/FEUERTEMPEL_WALLACE_DIALOGE_AKTUELL.md').write_text(s);(D/'Feuertempel_Wallace_Dialoge_Aktuell.md').write_text(s)
print('Exported',len(chapter),'built German messages')

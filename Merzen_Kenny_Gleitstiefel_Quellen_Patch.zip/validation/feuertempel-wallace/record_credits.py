"""Record uninterrupted native credits with no controller input and all five replacement sages."""
from pathlib import Path
import re,json,subprocess,os,hashlib
W=Path('/workspace/feuertempel-wallace');O=Path('/workspace/oot-burns-pal');s=(W/'runner.c').read_text();syms=json.loads((W/'symbols.json').read_text());case='fire-wallace-credits-video-v3-direct-clip-on'
s=s.replace('static void onframe(unsigned f){','static void baseframe(unsigned f){').replace('if(buttons)buttons(value);','if(buttons)buttons(0);')
s=re.sub(r'CoreDoCommand\(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL\);','/* no still shots in this recording */',s)
idx=s.index('\nstatic void setting(')
wrapper=r'''
static void onframe(unsigned f){
 static unsigned started=0,first=0,total=0,transition=0;
 baseframe(f);
 if(f<305)return;
 findplay();
 if(!play)return;
 unsigned scene=DebugMemRead16(play+0xa4);
 if(!started && scene==0x60){started=1;first=f;printf("VIDEO_START frame=%u scene=%x\n",f,scene);}
 if(!started)return;
 if(scene!=0x60 && !transition){transition=f;printf("VIDEO_TRANSITION frame=%u scene=%x count=%u\n",f,scene,total);}
 if(transition && f>transition+60){printf("VIDEO_END first=%u last_exclusive=%u frames=%u transition=%u\n",first,f,total,transition);CoreDoCommand(M64CMD_STOP,0,NULL);return;}
 if(f%50==0){
  unsigned ids[]={0xa8,0xc9,0xd2,0xc3,0xa9};printf("FIVE_SAGES frame=%u scene=%x RAM=%u",f,scene,r32(0x80000318));
  for(int i=0;i<5;i++){unsigned a=actor(ids[i]);printf(" %x=%08x",ids[i],a);}printf("\n");
 }
 CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);total++;
}
'''
s=s[:idx]+wrapper+s[idx:];(W/'runner-record.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner-record.c'),'-o',str(W/'runner-record'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
folder=Path('/workspace/bean-rider')/('screens-'+case);before=set(folder.glob('*.png'))if folder.exists()else set();rom=O/'build/pal-1.0/oot-pal-1.0-compressed.z64';sha=hashlib.sha256(rom.read_bytes()).hexdigest()
with (W/'credits-recording-v3.log').open('w')as log:subprocess.run([str(W/'runner-record'),str(rom),case,'1500','4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/'credits.save')],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
log=(W/'credits-recording-v3.log').read_text();match=re.search(r'VIDEO_END first=(\d+) last_exclusive=(\d+) frames=(\d+) transition=(\d+)',log);assert match and 'completed: 0' in log
first,end,count,transition=map(int,match.groups());frames=sorted(set(folder.glob('*.png'))-before);assert len(frames)==count and count==end-first and transition>first
indices=sorted(int(x.stem.rsplit('-',1)[1])for x in frames);assert indices==list(range(indices[0],indices[0]+count))
# All five native actor instances must coexist in the actual 4 MiB scene.
assert re.search(r'FIVE_SAGES.*scene=60 RAM=4194304 a8=80[0-9a-f]+ c9=80[0-9a-f]+ d2=80[0-9a-f]+ c3=80[0-9a-f]+ a9=80[0-9a-f]+',log)
out=Path('/workspace/artifacts/Wallace_Weise_Credits_v3.mp4');subprocess.run(['ffmpeg','-y','-v','error','-framerate','50/3','-start_number',str(indices[0]),'-i',str(folder/'the_legend_of_zelda-%03d.png'),'-frames:v',str(count),'-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True)
meta=dict(rom_sha256=sha,first_frame=first,last_frame_exclusive=end,frames=count,transition_frame=transition,pal_frames_per_second='50/3',duration_seconds=count*3/50,silent=True,continuous_unedited_native_gameplay=True,controller_input=False,native_actor_positions=True,ram_bytes=4194304,characters=['Wallace','Krabbelminen-Frau','Thaddäus','Waluigi','Mr. Bean'],screenshot_start_index=indices[0],screenshot_folder=str(folder),mp4_sha256=hashlib.sha256(out.read_bytes()).hexdigest())
(W/'credits-recording-v3.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print('Recorded',count,'frames;',meta['duration_seconds'],'seconds; native exit to next credits scene.')

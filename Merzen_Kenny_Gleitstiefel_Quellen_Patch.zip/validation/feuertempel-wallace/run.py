from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,hashlib,os,sys
W=Path('/workspace/feuertempel-wallace');syms=json.loads((W/'symbols.json').read_text());rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64')
def run(topic):
 case='fire-wallace-'+topic+os.environ.get('RUN','-v1')+'-direct-clip-on';limit=int(os.environ.get('FRAME_LIMIT',{'hall':2200,'credits':600,'sealing':800,'inn':800,'prison-free':1800,'prison-locked':400,'hall-english':1200,'prison-locked-english':400,'bolero':1800,'hammer':1000,'goron-bomb':4000,'goron-hit':3600}.get(topic,1000)));meta=dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),fixture=topic,limit=limit,prepared_player_and_progress_only=topic!="goron-hit",native_actor_positions=True,native_collision_hit_preparation=topic=="goron-hit")
 (W/(case+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
 with (W/(case+'.log')).open('w')as log:subprocess.run([str(W/'runner'),str(rom),case,str(limit),'4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=int(os.environ.get("WORKERS",2)))as pool:list(pool.map(run,sys.argv[1:]))

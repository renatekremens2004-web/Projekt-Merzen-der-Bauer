from pathlib import Path
import json,re,struct,shutil
W=Path('/workspace/feuertempel-wallace');O=Path('/workspace/oot-burns-pal');P=Path('/workspace/okto-water-temple');s=(P/'runner.c').read_text();mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};old=json.loads((P/'symbols.json').read_text())
for n in ['gObjectTable','gGameStateOverlayTable']:s=s.replace(hex(old[n]),hex(syms[n]))
a=s.index('   uint32_t n=actor_type(0xe,0x7f)');b=s.index('   uint32_t ctx=',a)
s=s[:a]+r'''   uint32_t du=actor(0xa8),go=actor_type(0x1ae,3),sa=actor(0xc9);
   printf("FIRE f=%u du=%08x du_type=%u du_draw=%u du_anim=%08x du_frame=%.1f go=%08x go_type=%x go_pos=(%.1f %.1f %.1f) go_state=%u sa=%08x sa_pos=(%.1f %.1f %.1f) switch=%08x tunic=%x owned=%x heat_timer=%u\n",f,du,du?DebugMemRead16(du+0x1c):0,du?r32(du+0x18c):0,du?r32(du+0x144):0,du?rf(du+0x154):0,go,go?DebugMemRead16(go+0x1c):0,go?rf(go+0x24):0,go?rf(go+0x28):0,go?rf(go+0x2c):0,go?DebugMemRead8(go+0x202):0,sa,sa?rf(sa+0x24):0,sa?rf(sa+0x28):0,sa?rf(sa+0x2c):0,r32(play+0x1d28),DebugMemRead16(savebase+0x70),DebugMemRead16(savebase+0x9c),DebugMemRead16(savebase+0x13cc));
''' +s[b:]
# Own model shots throughout the native scene. No camera/NPC movement in these cases.
marker='  if(f%100==0){'
extra=r'''  if(f==100 && strstr(scenario,"prison")){printf("PHOTO f=%u kind=scene\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if((strstr(scenario,"credits") || strstr(scenario,"sealing")) && f<=250 && f%25==0){printf("PHOTO f=%u kind=scene\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(strstr(scenario,"prison-free") && mode==0){
   uint32_t go=actor_type(0x1ae,3);
   if(f>=160 && f<184)value=0x40000020;
   if(f>=400 && go){float dx=rf(go+0x24)-rf(player+0x24),dz=rf(go+0x2c)-rf(player+0x2c);if(dx*dx+dz*dz>60*60)value=steer(dx,dz);else value|=0x20;}
  }
  if(strstr(scenario,"goron-bomb") || strstr(scenario,"goron-hit")){
   static unsigned stopped=0,dragonSeen=0;uint32_t go=actor_type(0x1ae,1);
   if(id==0x3031)stopped=1;
   if(id==0x3035)dragonSeen=1;
   if(strstr(scenario,"goron-hit") && f==150 && go){position(player,rf(go+0x24)+50,rf(go+0x28),rf(go+0x2c),-16384);DebugMemWrite8(go+0x1bd,DebugMemRead8(go+0x1bd)|2);printf("PREPARED_NATIVE_HIT f=%u go=%08x ac_offset=0x1bd player_start_near_native_goron=1\n",f,go);}
   if(!stopped && mode==0){value=0;if(!strstr(scenario,"goron-hit") && f>150 && f%130<4)value=0x400;if(!strstr(scenario,"goron-hit") && f>150 && f%130>=40 && f%130<44)value=0x80;}
   if(stopped && mode==0 && go){float dx=rf(go+0x24)-rf(player+0x24),dz=rf(go+0x2c)-rf(player+0x2c);if(dx*dx+dz*dz>60*60)value=steer(dx,dz);else value|=0x20;}
   if(dragonSeen && id==0x3034 && mode==0x35 && age>=2 && age<6)value=0xc0000000;
  }
  if(strstr(scenario,"hammer")){
   if(f==0){DebugMemWrite32(play+0x1d2c,r32(play+0x1d2c)|(1u<<26));printf("PREPARED_PUZZLE_PROGRESS f=0 temp_switch_58=1\n");}
   if(f==120){position(player,-2152.,4680.,352.,-8192);printf("PREPARED_PLAYER_START f=120 native_chest_unchanged=1\n");}
  }
  if(strstr(scenario,"bolero")){
   static unsigned playback=0;unsigned action=DebugMemRead16(m+0xe3f0),om=DebugMemRead16(m+0xe3ee);
   if(mode==0)value=0;
   if(action==16 && om==1){if(!playback)playback=f;unsigned t=f-playback;static unsigned notes[]={0x400,0x80,0x400,0x80,0x100,0x400,0x100,0x400};if(t>=20 && t<20+8*16){unsigned k=(t-20)/16;value=((t-20)%16<4)?notes[k]:0;}}
   if(f%100==0)printf("OCARINA f=%u action=%u mode=%u msg=%x\n",f,action,om,mode);
  }
'''
s=s.replace(marker,extra+marker,1);s=s.replace('static void onframe(unsigned f){','static unsigned steer(float dx,float dz){\n uint32_t cam=r32(play+0x790+DebugMemRead16(play+0x7a0)*4);float fx=rf(cam+0x50)-rf(cam+0x5c),fz=rf(cam+0x58)-rf(cam+0x64),c=sqrtf(fx*fx+fz*fz),d=sqrtf(dx*dx+dz*dz);\n if(c<1 || d<1)return 0;fx/=c;fz/=c;dx/=d;dz/=d;int x=(int)roundf((dx*fz-dz*fx)*60),y=(int)roundf((dx*fx+dz*fz)*60);return ((unsigned)(uint8_t)x<<16)|((unsigned)(uint8_t)y<<24);\n}\n'+'static void onframe(unsigned f){');(W/'runner.c').write_text(s);(W/'symbols.json').write_text(json.dumps(syms)+'\n')
base=bytearray(Path('/workspace/water-spirit-sages/water.save').read_bytes())
def fixture(name,ent,room,pos,yaw=0):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,0,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,room);b[0x1409]=1;b[0x68]=0x3c;struct.pack_into('>H',b,0x70,0x1222);struct.pack_into('>H',b,0x9c,struct.unpack_from('>H',b,0x9c)[0]|0x200);b[0x13e2:0x13e7]=bytes(5);struct.pack_into('>HH',b,0x2e,160,160);struct.pack_into('>H',b,0x38,0)
 if ent==0x165:struct.pack_into('>I',b,0xd4+4*0x1c+4,0)
 (W/(name+'.save')).write_bytes(b);return b
fixture('prison-locked',0x165,5,(2212.,2800.,1005.),0)
fixture('prison-free',0x165,5,(2320.,2800.,900.),-5200)
fixture('inn',0x2fd,0,(102.,0.,78.),22000)
b=fixture('bolero',0x147,1,(-684.,548.,-346.),0);struct.pack_into('>H',b,0xed4+5*2,struct.unpack_from('>H',b,0xed4+5*2)[0]&~2);(W/'bolero.save').write_bytes(b)
for topic,src in [('hall','/workspace/phantom-amthor/hall-darunia.save'),('credits','/workspace/water-spirit-sages/credits.save'),('sealing','/workspace/water-spirit-sages/sealing.save'),('darunia-child','/workspace/phantom-amthor/darunia-child.save')]:shutil.copyfile(src,W/(topic+'.save'))
# English uses native Darunia and the original Goron prisoner.
for name in ['hall','prison-locked']:
 b=bytearray((W/(name+'.save')).read_bytes());b[0x1409]=0;(W/(name+'-english.save')).write_bytes(b)
print('Prepared native positions and controller fixtures; symbols',syms)

b=fixture('hammer',0x165,13,(-2152.,4680.,352.),-8192);struct.pack_into('>I',b,0xd4+4*0x1c,0);b[0x74+15]=0xff;(W/'hammer.save').write_bytes(b)
b=fixture('goron-bomb',0x14d,3,(252.,397.,-355.),-32768);struct.pack_into('>H',b,0x70,0x1122);struct.pack_into('>H',b,0x9c,struct.unpack_from('>H',b,0x9c)[0]&~0x200);struct.pack_into('>I',b,0xa4,struct.unpack_from('>I',b,0xa4)[0]&~2);struct.pack_into('>H',b,0xef8+16*2,0);b[0x6a]=2;b[0x6d]=2;b[0x74+2]=2;b[0x8c+2]=40;struct.pack_into('>I',b,0xa0,struct.unpack_from('>I',b,0xa0)[0]|8);(W/'goron-bomb.save').write_bytes(b)

shutil.copyfile(W/'goron-bomb.save',W/'goron-hit.save')

# Kakariko guest-house beard NPC is present only at night.
b=bytearray((W/'inn.save').read_bytes());struct.pack_into('>H',b,0x0c,0);struct.pack_into('>I',b,0x10,1);(W/'inn.save').write_bytes(b)
# Native timed flame barrier already lowered by its own puzzle switch.
b=bytearray((W/'hammer.save').read_bytes());struct.pack_into('>I',b,0x137c,1<<26);struct.pack_into('>fffh',b,0x1368,-2211.,4680.,411.,24576);(W/'hammer.save').write_bytes(b)

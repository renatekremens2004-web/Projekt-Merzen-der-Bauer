from pathlib import Path
import re,json,struct,subprocess
W=Path('/workspace/okto-water-temple');O=Path('/workspace/oot-burns-pal');P=Path('/workspace/phantom-amthor')
s=(P/'runner.c').read_text();a=s.index(' if(play){',s.index('if(f%50==0)findplay();unsigned value=0;'));b=s.index('\n if(buttons)buttons(value);',a)
s=s[:a]+r''' if(play){
  uint32_t m=play+0x20d8;unsigned id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),pos=DebugMemRead16(m+0xe3ce);
  static unsigned oldkey=0,age=0;unsigned key=id*1024+pos;
  if(key!=oldkey || (mode!=7 && mode!=0x34 && mode!=0x35)){oldkey=key;age=0;}else age++;
  if((mode==7 || mode==0x34 || mode==0x35) && age==8){printf("TEXT f=%u id=%04x pos=%u mode=%x len=%u\n",f,id,pos,mode,r32(m+0xe300));printf("PHOTO f=%u kind=text\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f>150 && mode==0 && f%30<4)value=0x80;
  else if(f>100 && (mode==6 || mode==7 || mode==0x34 || mode==0x35) && age>12 && f%20<4)value=0x80;
  if(f%100==0){
   uint32_t n=actor_type(0xe,0x7f),col=r32(play+1984),water=col?r32(col+40):0;
   printf("OKTO f=%u ptr=%08x cat=%d AT=%u AC=%u pos=(%.1f %.1f %.1f) floor=%.1f water0=%d water2=%d player_bg=%x player_floor=%.1f\n",f,n,n?DebugMemRead8(n+2):-1,n?DebugMemRead8(n+880):0,n?DebugMemRead8(n+881):0,n?rf(n+0x24):0,n?rf(n+0x28):0,n?rf(n+0x2c):0,n?rf(n+128):0,water?(int16_t)DebugMemRead16(water+2):0,water?(int16_t)DebugMemRead16(water+34):0,DebugMemRead16(player+136),rf(player+128));
   uint32_t ctx=play+0x117a4,begin=r32(ctx),end=r32(ctx+4),last=begin;int entries=DebugMemRead8(ctx+8);
   for(int i=0;i<entries && i<19;i++){uint32_t slot=ctx+12+i*0x44;int obj=(int16_t)DebugMemRead16(slot);if(obj<0)obj=-obj;if(obj>0 && obj<0x192){uint32_t e=r32(slot+4)+r32(0x800f7368+obj*8+4)-r32(0x800f7368+obj*8);if(e>last)last=e;}}
   printf("OBJECT_BANK f=%u entries=%d used=%u capacity=%u remaining=%d\n",f,entries,last-begin,end-begin,(int)(end-last));if(last>end){fprintf(stderr,"OBJECT_BANK_OVERFLOW\n");exit(96);}
   printf("STATE f=%u scene=%x id=%04x msg=%x RAM=%u player=(%.1f %.1f %.1f)\n",f,DebugMemRead16(play+0xa4),id,mode,r32(0x80000318),rf(player+0x24),rf(player+0x28),rf(player+0x2c));
  }
 }
'''+s[b:]
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
s=s.replace('0x800ef6a0',hex(syms['gGameStateOverlayTable'])).replace('0x800f7368',hex(syms['gObjectTable']));(W/'runner.c').write_text(s)
for topic,flag,clear,lang in [('high',0x1e,False,1),('middle',0x1d,False,1),('low',0x1c,False,1),('cleared',0x1e,True,1),('english',0x1e,False,0)]:
 b=bytearray(Path('/workspace/water-spirit-sages/water.save').read_bytes());struct.pack_into('>III',b,0,0x10,0,0);struct.pack_into('>fffhHhB',b,0x1368,-195.,780.,725.,0,0xdff,0x10,0);b[0x1409]=lang;b[0x68]=0x3c;struct.pack_into('>H',b,0x70,0x1122);b[0x13e2:0x13e7]=bytes(5)
 off=0xd4+5*0x1c;v=struct.unpack_from('>I',b,off+4)[0];v=(v&~(7<<28))|(1<<flag);struct.pack_into('>I',b,off+4,v);struct.pack_into('>I',b,off+8,1 if clear else 0)
 (W/(topic+'.save')).write_bytes(b)
b=bytearray(Path('/workspace/okto-water/talk.save').read_bytes());struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,140.,-299.,82.9,-32768,0xdff,0x28,0);struct.pack_into('>I',b,0xd4+2*0x1c+8,1);(W/'jabu.save').write_bytes(b)
print('Runtime prepared: native player shore, low/middle/high water flags, cleared room, English, and Jabu.')

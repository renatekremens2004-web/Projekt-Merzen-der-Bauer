from pathlib import Path
import sys,re
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery');sys.path.insert(0,str(R/'tools'));import build_story as b
m=b.messages((O/'extracted/pal-1.0/text/message_data.h').read_text());out=['# Okto: eingebaute deutsche Dialoge','','Aus dem tatsächlich gebauten Textbestand. Absätze entsprechen manuell weitergeschalteten Textseiten.','']
for title,i in [('Jabu-Jabu: erste Begegnung','00F8'),('Wassertempel: Wiedersehen am festen Eingangsbecken','209C')]:
 out+=['## '+title+' — '+i,'']
 out+=['> '+re.sub(r'\s+',' ',b.plain(p)).strip()+'\n' for p in b.split_pages(m[i]['parts'][2][2])[0]]
s='\n'.join(out)+'\n';(D/'Okto_Wassertempel_Dialoge_Aktuell.md').write_text(s);(R/'planning/OKTO_WASSERTEMPEL_DIALOGE_AKTUELL.md').write_text(s)

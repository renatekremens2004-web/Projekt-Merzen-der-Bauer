from pathlib import Path
import json,hashlib,subprocess,os,sys
W=Path('/workspace/okto-water-temple');s=json.loads((W/'symbols.json').read_text());rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64')
for topic in sys.argv[1:]:
 limit={'high':1000,'low':400,'middle':400,'cleared':800,'jabu':800,'english':300}[topic];case='okto-water-temple-'+topic+os.environ.get('RUN','-v1')+'-direct-clip-on';(W/(case+'.json')).write_text(json.dumps(dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),fixture=topic,limit=limit,prepared_player_and_progress_only=True,native_actor_positions=True),indent=2)+'\n')
 with (W/(case+'.log')).open('w')as log:subprocess.run([str(W/'runner'),str(rom),case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)

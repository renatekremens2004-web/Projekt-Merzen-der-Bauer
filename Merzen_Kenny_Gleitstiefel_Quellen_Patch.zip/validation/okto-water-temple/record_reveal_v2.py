from pathlib import Path
import re,shutil,json,subprocess,os,hashlib
W=Path('/workspace/okto-water-temple');P=Path('/workspace/phantom-amthor');O=Path('/workspace/oot-burns-pal');B=O/'build/pal-1.0';rom=B/'oot-pal-1.0-compressed.z64'
s=(P/'runner.c').read_text().replace('CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);','')
s=s.replace(' if(buttons)buttons(value);',' if(f>=180 && f<850){CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}\n if(f%100==0 && play)printf("VIDEO_CLOCK callback=%u game_frame=%u\\n",f,r32(play+0x9c));\n if(buttons)buttons(value);')
(W/'runner-record.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner-record.c'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm','-o',str(W/'runner-record')],check=True)
case='okto-reveal-final-v2-direct-clip-on';symbols=json.loads((P/'symbols.json').read_text())
(W/'reveal-final-recording.json').write_text(json.dumps(dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),first_frame=180,last_frame_exclusive=850,pal_vi_rate=50,vi_per_game_frame=3,frames_per_second='50/3',silent=True,unedited_native_gameplay=True),indent=2)+'\n')
shots=Path('/workspace/bean-rider')/('screens-'+case);existing=set(shots.glob('*.png')) if shots.exists() else set()
with (W/'reveal-final-recording.log').open('w') as log:
 subprocess.run([str(W/'runner-record'),str(rom),case,'900','4',hex(symbols['gSaveContext']),hex(symbols['gActorOverlayTable']),str(P/'intro.save')],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
fresh=sorted(set(shots.glob('*.png'))-existing,key=lambda p:int(p.stem.rsplit('-',1)[1]));assert len(fresh)==670;start=int(fresh[0].stem.rsplit('-',1)[1]);assert int(fresh[-1].stem.rsplit('-',1)[1])==start+669
output=Path('/workspace/artifacts/Merz_zu_Amthor_Reveal_v2.mp4')
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-framerate','50/3','-start_number',str(start),'-i',str(shots/'the_legend_of_zelda-%03d.png'),'-frames:v','670','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(output)],check=True)
print('Recorded',output,output.stat().st_size,'bytes; 670 consecutive native PAL frames, 40.2 seconds, no audio.',flush=True)

from pathlib import Path
import json,hashlib,re,shutil,zipfile,sys
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/kenny');A=Path('/workspace/artifacts');D=Path('/workspace/bean-download-delivery')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
romsha=sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64');verify=json.loads((O/'build/pal-1.0/kenny-verification.json').read_text());check=json.loads((W/'patch-verification.json').read_text());assert romsha==verify['rom_sha256']==check['target_sha256']
V=R/'validation/kenny';P=R/'previews/kenny';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True)
cases=[('alive','final',550),('dead','final',550),('boots-still','final',650),('dead-before-still','final',350),('worst-still','final',350),('gain-still','final',450),('xwing-still','final',650)];logs={}
for topic,run,frames in cases:
 p=W/f'kenny-{topic}-{run}-direct-clip-on.log';s=p.read_text();assert romsha in s and 'completed: 0' in s and 'RAM=4194304' in s,p
 assert not any(x in s for x in ['OVERFLOW','GFX_POOL_CORRUPT','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 assert all(int(n)==0 for n in re.findall(r'HEAP f=\d+ failures=(\d+)',s)),p
 logs[topic]=s;shutil.copyfile(p,V/p.name)
assert 'id=71b8' in logs['alive'] and 'id=71b9' in logs['dead']
for line in logs['dead'].splitlines():
 if line.startswith('KENNY ')and not re.search(r'mode=0(?: |$)',line):assert 'equip=1122' in line
# Real controller inputs must update both native equipment and runtime boots.
for f,e,b in [(200,'3122',2),(300,'1122',0),(400,'2122',1),(500,'3122',2),(600,'2122',1)]:
 assert re.search(rf'KENNY f={f} .*equip={e} currentBoots={b} prevBoots={b}',logs['boots-still'])
# Holding Up before acquiring hover boots cannot equip them.
assert re.search(r'KENNY f=125 .*owned=3500 equip=1122',logs['alive'])
assert re.search(r'KENNY f=200 .*liveFlags=00000050.*liveDraw=00000000.*liveShadow=00000000',logs['boots-still'])
assert re.search(r'KENNY f=200 .*deadFlags=00000050',logs['dead-before-still'])
assert re.search(r'KENNY f=200 .*liveFlags=00040059',logs['gain-still']) and re.search(r'KENNY f=400 .*liveFlags=00000050',logs['gain-still'])
heap=min(map(int,re.findall(r'largest=(\d+)','\n'.join(logs.values()))));bank=min(map(int,re.findall(r'OBJECT_BANK[^\n]*remaining=(\d+)','\n'.join(logs.values()))));assert heap>=4096
runtime=dict(rom_sha256=romsha,actual_ram_bytes=4194304,cases=[dict(name=t,run=r,frames=f)for t,r,f in cases],native_allocation_failures=0,minimum_largest_arena_free=heap,minimum_object_bank_free=bank,hover_up_iron_down_toggles_verified=True,unowned_hover_ignored=True,ownership_change_test='Test runner simulates the persistent owned-hover-boots bit at frame 300; native item/chest code remains unchanged.',shared_object_bytes=next(x['after_bytes']for x in verify['intentional_segments']if x['segment']=='object_kenny'))
(W/'runtime-verification.json').write_text(json.dumps(runtime,indent=2)+'\n')
for name in ['prepare_runtime.py','runner.c','run.py','object_budget.py','object-budget.json','models.json','selected-images.json','xwing-storage.json','runtime-verification.json','verification.log','check_patch.js','patch-verification.json','package.py']:shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/kenny-verification.json',V/'kenny-verification.json')
photos=[]
for topic,index,name in [('alive',2,'Kenny_Am_Eingang.png'),('dead',0,'Kenny_Tot.png')]:
 case=f'kenny-{topic}-final-direct-clip-on';root=Path('/workspace/bean-rider')/('screens-'+case)
 p=root/f'the_legend_of_zelda-{index:03d}.png';shutil.copyfile(p,P/name);photos.append(dict(file=name,source=str(p),rom_sha256=romsha,unaltered_emulator_image=True))
 # Each TEXT event saves an additional genuine emulator frame.
 log=logs[topic];target='71b8'if topic=='alive'else'71b9';events=[]
 for line in log.splitlines():
  if line.startswith('TEXT '):events.append(('text',line))
  elif line.startswith('KENNY f='):
   f=int(re.search(r'f=(\d+)',line)[1])
   if f==100:events.append(('overview',line))
 # Select first frame containing the actual requested text by examining the
 # same ordered screenshot events used by the runner (f100, text, f200/400).
 # Explicit image index chosen after visual inspection, supplied below.
 idx=json.loads((W/'selected-images.json').read_text())[topic]
 p=root/f'the_legend_of_zelda-{idx:03d}.png';name='Navi_'+('Nuscheln'if topic=='alive'else'Kenny_Getoetet')+'.png';shutil.copyfile(p,P/name);photos.append(dict(file=name,source=str(p),rom_sha256=romsha,unaltered_emulator_image=True))
case='kenny-xwing-photo-final-direct-clip-on';src=Path('/workspace/bean-rider')/('screens-'+case)/'the_legend_of_zelda-005.png';shutil.copyfile(src,P/'XWing_Speicheroptimiert.png');photos.append(dict(file='XWing_Speicheroptimiert.png',source=str(src),rom_sha256=romsha,unaltered_emulator_image=True))
(P/'Aufnahmen.json').write_text(json.dumps(photos,indent=2)+'\n')
doc=f'''# Kenny und Gleitstiefel

Kumulativer Gesamtpatch auf unveränderte deutsche Europa/PAL 1.0, Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{romsha}`. Alle bisherigen Änderungen einschließlich Marty, Doc und DeLorean enthalten.

Kenny ist in beiden Formen ein anvisierbares Dekoobjekt mit normalem Navi-Kommentar. Keine Körper-/Kampf-Kollision und kein eigener NPC-Gesprächsablauf. Lebend in Raum 2, unmittelbar im Eingangskorridor (−285/−63/500), Höhe 48 Spieleinheiten. Kleine starre Pendelbewegung, natürliche Originalproportionen. Nach dem Besitz der Gleitstiefel wird dieser Auftritt sofort unsichtbar, nicht mehr anvisierbar und hat keine Kollision. Der tote Kenny liegt danach in Raum 6, am Rand des späteren Raums mit den Sicheln/silbernen Rubinen (3225/−542/−600). Sein Originalmodell wurde offline gleichmäßig skaliert und auf den Rücken gelegt; Länge 48. Keine neuen Türen, Fallen, Gegner, Schalter oder Fortschrittsbits verändert. Kenny liest nur das vorhandene Besitzbit der Gleitstiefel; An- und Ausziehen verändert es nicht. Auftritte nur als Erwachsener in der deutschen Sprachfassung. Crocker behält seinen bisherigen Auftritt.

Navi beim lebenden Kenny: **„Ich verstehe den Typen nicht, der nuschelt zu sehr.“** (71B8)

Navi beim toten Kenny: **„Ihr habt Kenny getötet, ihr Schweine!“** (71B9)

**Steuerkreuz oben** schaltet zwischen Gleitstiefeln und Kokiri-Stiefeln um. **Unten** bleibt für Eisenstiefel/Kokiri-Stiefel. Beide Kürzel funktionieren nur als Erwachsener nach dem Erhalt des jeweiligen Gegenstands. Sie verwenden die normale Inventar-/Ausrüstungsfunktion und die vorhandene Stiefelphysik. Keine Wiederholung beim Halten; während Pause, Texten, Zwischensequenzen, Übergängen und ausgeschlossenen Spielerzuständen blockiert. Ein direkter Wechsel zwischen Eisen- und Gleitstiefeln ist möglich.

## Speicher und gezielte Prüfungen

Die gelieferten South-Park-N64-Geometrien bleiben erhalten: 284 und 280 Dreiecke. Native Beleuchtung, Nebel und Tiefentest. Ein gemeinsames Modellobjekt mit {runtime['shared_object_bytes']:,} Byte und einem zusätzlichen Objekt-Slot ausschließlich in den beiden betroffenen Räumen. Die Raumsegmente enthalten nur je einen zusätzlichen Actor-Eintrag und eine Objekt-ID; die Modelldaten vergrößern nicht den doppelten Raumpuffer.

Der bisherige LEGO-X-Wing hatte 4.270 Dreiecke und erzeugte einen großen gemeinsamen Raumpuffer. Die überarbeitete Version hat 3.006 Dreiecke, unveränderten Standort, 24 Spieleinheiten Spannweite und dieselben Materialfarben. Seine Speicherersparnis steht auch in anderen Tempelräumen zur Verfügung. Die native Raumkollision und die Raumverbindungen bleiben erhalten. Der ursprüngliche Modellpuffer von 1.019.904 Byte bleibt unverändert. Audit aller 23 Raumlisten für beide Link-Alter einschließlich Keep-, Link- und Kenny-Modellen: größter Bedarf 969.840 Byte, somit 50.064 Byte Reserve. Eine neue Modell-ID/DMA-Datei wird am Ende angefügt, vorhandene IDs bleiben erhalten; die Händler-Platzhalter passen sich an den neuen OBJECT_ID_MAX an.

Sieben Emulatorproben mit tatsächlichen 4 MiB RAM: lebender Kenny samt Kommentar, toter Kenny samt Kommentar, Stiefelwechsel oben/unten einschließlich Halten, fehlender toter Kenny vor dem Erhalt, modellreichster Raum 9, Besitzwechsel ohne Neuladen, X-Wing im ursprünglichen Raum. Beim Besitzwechsel-Test setzt nur der Test-Runner das normale Inventarbit bei Frame 300; die echten Schatztruhen-/Item-Funktionen bleiben unverändert. Mindestreserve in diesen Proben: größte freie zusammenhängende Actor-Arena-Fläche {heap:,} Byte, Objektpuffer {bank:,} Byte. Null fehlgeschlagene native Belegungen, keine Grafikpufferüberläufe oder beschädigten GfxPool-Marken. Alters-/Sprachbeschränkung zusätzlich im Quelltext geprüft. Ein vollständiger Durchlauf und ein echter N64-Hardwaretest sind damit nicht ersetzt.

Alle {verify['compressed_segments_verified']:,} komprimierten Segmente gegen den Build und CIC-6105-Prüfsumme geprüft. {verify['native_core_symbols_verified']:,} ursprüngliche Kernsymbole unverändert oder ausschließlich durch echte Linker-Relokationen verschoben; keine Änderung am nativen Speicher-Zuteilungscode. Alle bisherigen Dialoge in allen drei PAL-Sprachen als Quelle und kompiliert bytegleich. Sämtliche 1.037 eigenen Nachrichten passen in die nativen Textpuffer. Neue Texte besitzen gültige Folge-DMA-Zeiger in allen Sprachen. BPS mit RomPatcher.js und aktiver Quellvalidierung angewandt: bytegleich zur geprüften ROM.

Letzter Builder: `tools/build_kenny.py` nach `build_bttf.py`. Stiefel-Helfer: `tools/quick_iron_boots.inc.c`, vom bestehenden `build_quick_iron_boots.py` eingebunden. Kenny-Export ohne Blender: `python3 tools/export_kenny.py <Arbeitsordner>`, Nutzerarchive unter input/alive und input/dead. Original-OBJ/MTL/PNG und Quellenhinweise unter models/kenny/source und models/kenny_dead/source; vorbereitete JSONs reichen für den normalen Bau. Kein ROM, Save, Savestate, RAM-Abzug oder ausführbares Programm im Quellenpaket.
'''
(R/'TESTING_KENNY.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
for key in ['kenny','kenny_dead']:(R/'models'/key/'README.md').write_text('South Park N64, Nutzer-Upload. OBJ unverändert in Dreieckanzahl; gleichmäßig skaliert, native Beleuchtung. Details und Quellennachweis in TESTING_KENNY.md und source/README.txt.\n')
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Kenny_Gleitstiefel.bps';shutil.copyfile(patch,R/'patches'/patch.name)
heading='# Kenny und Gleitstiefel';p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Prüfung](TESTING_KENNY.md) · [Bilder](previews/kenny/)\n\nZwei anvisierbare Kenny-Objekte, Zustandswechsel nach Besitz der Gleitstiefel. Oben: Gleitstiefel, unten: Eisenstiefel. Alle bisherigen Änderungen enthalten. Letzter Builder build_kenny.py nach build_bttf.py.\n\n'+p.read_text())
archive=A/'Merzen_Kenny_Gleitstiefel_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in['water-comic-heroes','ben-ice','jabba','bttf','kenny']and(p.suffix in['.c','.h']or rel.parts[-2:]==('spec','spec'))
  if not p.is_file()or(any(q in exclude for q in rel.parts)and not original)or(p.suffix.lower()not in suffixes and not original):continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='kenny':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.o','.so','.st','.exe','.mp4','.glb'}for n in z.namelist());assert 'tools/originals/kenny/spec/spec'in z.namelist()
instruction=A/'Anleitung_Kenny_Gleitstiefel.txt';instruction.write_text('Gesamtpatch mit allen bisherigen Änderungen, Kenny im Schattentempel und Gleitstiefeln auf Steuerkreuz oben; Eisenstiefel unten.\n\nBPS mit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände laden; alte Emulator-Savestates vermeiden. Deutsche Sprachfassung.\n')
for p in [patch,archive,instruction]:shutil.copyfile(p,D/p.name)
G=D/'Kenny_Gleitstiefel_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
files=[D/p.name for p in[patch,archive,instruction]];sums=D/'SHA256SUMS_Kenny_Gleitstiefel.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files));files.append(sums)
p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Bilder und Prüfung](Kenny_Gleitstiefel_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nKenny als anvisierbares Objekt: vor den Gleitstiefeln am Eingang, danach tot im späteren Tempel. Navi kommentiert beide Auftritte. Steuerkreuz oben: Gleitstiefel, unten: Eisenstiefel. Alle bisherigen Änderungen enthalten, auf unveränderte Vanilla PAL 1.0 anwenden. Gezielte Proben mit 4 MiB, kein vollständiger Durchlauf.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=romsha,files=[p.name for p in files],runtime=runtime),indent=2)+'\n');print('Packaged Kenny',romsha,'source bytes',archive.stat().st_size)

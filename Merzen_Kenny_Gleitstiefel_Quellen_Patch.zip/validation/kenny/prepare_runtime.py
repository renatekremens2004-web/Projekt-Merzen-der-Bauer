from pathlib import Path
import re,json,struct,subprocess
W=Path('/workspace/kenny');O=Path('/workspace/oot-burns-pal');B=W/'baseline'
def symbols(p):return {n:int(a,16)for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\s*$',p.read_text(),re.M)}
old=symbols(B/'build/pal-1.0/oot-pal-1.0.map');new=symbols(O/'build/pal-1.0/oot-pal-1.0.map');(W/'symbols.json').write_text(json.dumps(new))
s=Path('/workspace/back-to-future/runner.c').read_text().replace('obj<0x194','obj<0x195')
for n in ['gGameStateOverlayTable','sZeldaArena','gObjectTable']:
 s=re.sub('0x'+format(old[n],'x')+r'\b',hex(new[n]),s)
# Input via real controller plugin, no production actor or room edits.
extra=r'''
  if(strstr(scenario,"gain") && f==300){DebugMemWrite16(savebase+0x9c,DebugMemRead16(savebase+0x9c)|0x4000);printf("SIMULATED_OWNED_HOVER_BOOTS f=%u\n",f);}
  if((strstr(scenario,"dead") || strstr(scenario,"alive")) && !strstr(scenario,"before") && f>150 && mode==0){value=0x20;if(f%45<4)value|=0x800;}
  if(strstr(scenario,"alive") && f>=100 && f<130)value=8;
  if(strstr(scenario,"boots")){
   value=0;
   if(f>=150&&f<170)value=8;
   if(f>=250&&f<255)value=8;
   if(f>=350&&f<355)value=4;
   if(f>=450&&f<455)value=8;
   if(f>=550&&f<555)value=4;
  }
  if(strstr(scenario,"dead") && mode!=0 && f%80<4)value|=8;
  if(strstr(scenario,"xwing-photo")){value=0;if(f>=110&&f<114)value=0x800;if(f>=120&&f<140)value=0x00f20000;if(f>=140&&f<230)value=0xd8000000;if(f>=260&&f<430)value=0x28000000;}
  if(f%25==0){uint32_t live=actor_type(0x173,5),corpse=actor_type(0x173,6);
   printf("KENNY f=%u live=%08x dead=%08x liveFlags=%08x deadFlags=%08x owned=%04x equip=%04x currentBoots=%u prevBoots=%u mode=%x liveFloor=%.1f deadFloor=%.1f liveDraw=%08x deadDraw=%08x liveShadow=%08x\n",f,live,corpse,live?r32(live+4):0,corpse?r32(corpse+4):0,DebugMemRead16(savebase+0x9c),DebugMemRead16(savebase+0x70),DebugMemRead8(player+0x13f),DebugMemRead8(player+0x143),mode,live?rf(live+0x80):0,corpse?rf(corpse+0x80):0,live?r32(live+0x134):0,corpse?r32(corpse+0x134):0,live?r32(live+0xc0):0);
  }
'''
s=s.replace('  if(f%50==0){\n   uint32_t fan=',extra+'  if(f%50==0){\n   uint32_t fan=')
(W/'runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
base=Path('/workspace/pepsiman-water/man-30.save').read_bytes()
for name,room,pos,yaw,hover,age,lang in [('alive',2,(-240.,-63.,540.),-24576,False,0,1),('boots-still',2,(-254.,-63.,585.),-28672,True,0,1),('dead',6,(3225.,-543.,-660.),0,True,0,1),('dead-before-still',6,(3225.,-543.,-515.),-32768,False,0,1),('child-still',2,(-254.,-63.,585.),-28672,False,1,1),('english-still',2,(-254.,-63.,585.),-28672,False,0,0),('worst-still',9,(4678.,-1143.,2630.),-32768,True,0,1),('gain-still',2,(-254.,-63.,585.),-28672,False,0,1),('xwing-still',0,(-1690.,-63.,-280.),-20000,False,0,1)]:
 b=bytearray(base);struct.pack_into('>III',b,0,0x37,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,0x37,room);b[0x1409]=lang;struct.pack_into('>HH',b,0x2e,160,160);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);b[0x34]=1;struct.pack_into('>H',b,0x0c,0x8000)
 off=0xd4+7*0x1c;b[off:off+0x1c]=bytes(0x1c);struct.pack_into('>H',b,0x70,0x1122 if not age else 0x1111);b[0x4a:0x54]=b[0x68:0x72]
 owned=struct.unpack_from('>H',b,0x9c)[0];owned=(owned|0x3000)&~0x4000
 if hover:owned|=0x4000
 struct.pack_into('>H',b,0x9c,owned);(W/(name+'.save')).write_bytes(b)
print('Prepared Kenny states, age/language controls, owned/unowned and controller hotkeys.')

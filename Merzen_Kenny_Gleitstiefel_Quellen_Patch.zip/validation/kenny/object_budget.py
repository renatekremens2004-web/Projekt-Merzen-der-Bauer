from pathlib import Path
import json,re
O=Path('/workspace/oot-burns-pal');W=Path('/workspace/kenny');D=O/'extracted/pal-1.0/assets/scenes/dungeons/HAKAdan';s=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();sym={n:int(a,16)for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',s,re.M)};table=dict((obj,name)for name,obj in re.findall(r'DEFINE_OBJECT\((\w+), (\w+)\)',(O/'include/tables/object_table.h').read_text()))
def size(obj):
 n=table[obj];return sym['_'+n+'SegmentRomEnd']-sym['_'+n+'SegmentRomStart']
rows=[]
for age,link in [('adult','OBJECT_LINK_BOY'),('child','OBJECT_LINK_CHILD')]:
 persistent=['OBJECT_GAMEPLAY_KEEP','OBJECT_GAMEPLAY_DANGEON_KEEP',link]
 for p in D.glob('*ObjectList.inc.c'):
  objs=re.findall(r'\bOBJECT_\w+',p.read_text());total=sum((size(n)+15)//16*16 for n in persistent+objs);rows.append(dict(age=age,file=p.name,bytes=total,slots=len(persistent+objs),objects=persistent+objs))
report=dict(capacity_before=1000*1024-4096,capacity_after=1000*1024-4096,all_room_lists=rows,worst_case=max(rows,key=lambda r:r['bytes']))
(W/'object-budget.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['worst_case']));print('new margin',report['capacity_after']-report['worst_case']['bytes']);assert report['capacity_after']-report['worst_case']['bytes']>=16384

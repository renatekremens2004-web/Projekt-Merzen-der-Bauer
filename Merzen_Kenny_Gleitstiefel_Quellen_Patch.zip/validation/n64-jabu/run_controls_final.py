from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
W=Path('/workspace/n64-gag')
jobs=[('console-final-repeat-direct-clip-on','near-cleared',1700),('console-final-photo-side-direct-clip-on','side',900),('console-final-english-direct-clip-on','english',1000),('console-final-room0-direct-clip-on','room0',1000)]
def run(j):subprocess.run([sys.executable,str(W/'run.py'),*map(str,j)],check=True)
with ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(run,jobs))

from pathlib import Path
import json,re,struct
W=Path('/workspace/n64-gag');O=Path('/workspace/oot-burns-pal')
s=Path('/workspace/transition/runner.c').read_text()
s=s.replace('  if(f==300 && strstr(scenario,"navi"))', '''  if(strstr(scenario,"console")){
   uint32_t n=actor(0x173);
   if(f%100==0)printf("CONSOLE f=%u actor=%08x params=%x draw=%08x flags=%08x text=%04x focusActor=%08x switch=%08x room=%d pos=(%.2f %.2f %.2f) scale=%.4f\\n",f,n,n?DebugMemRead16(n+0x1c):0,n?r32(n+0x134):0,n?r32(n+4):0,n?DebugMemRead16(n+0x10e):0,r32(player+0x654),r32(play+0x1d28),n?(int8_t)DebugMemRead8(n+3):-1,n?rf(n+0x24):0,n?rf(n+0x28):0,n?rf(n+0x2c):0,n?rf(n+0x50):0);
   if(f==0 && strstr(scenario,"photo"))DebugMemWrite16(savebase+0x30,DebugMemRead16(savebase+0x2e));
   if(f>(strstr(scenario,"photo")?20:350) && mode==0){value=0x20;if(!strstr(scenario,"view") && f>(strstr(scenario,"photo")?60:500) && f%80<8)value|=0x800;}
  }
  if(f==300 && strstr(scenario,"navi"))''')
(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();d={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};assert d['gGameStateOverlayTable']-d['gActorOverlayTable']==0x8e10;(W/'symbols.json').write_text(json.dumps(d));print(d)
base=bytearray(Path('/workspace/transition/market-pre.save').read_bytes())
for name,lang,room,pos,yaw in [('near',1,3,(130.,-1113.,-3130.),-32768),('side',1,3,(190.,-1113.,-3180.),-16384),('english',0,3,(130.,-1113.,-3130.),-32768),('room0',1,0,(0.,0.,0.),0)]:
 b=bytearray(base);struct.pack_into('>I',b,0,0x28);struct.pack_into('>I',b,4,1);struct.pack_into('>I',b,8,0);struct.pack_into('>I',b,0x1360,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,0x28,room);struct.pack_into('>H',b,0x1412,0xffef);b[0x1414]=0;b[0x1409]=lang
 # Before receiving the Zora Sapphire. Native room actors and enemy activity remain enabled.
 q=struct.unpack_from('>I',b,0xa4)[0];struct.pack_into('>I',b,0xa4,q&~(1<<20));x=struct.unpack_from('>H',b,0xeda)[0];struct.pack_into('>H',b,0xeda,x&~(1<<7))
 (W/(name+'.save')).write_bytes(b)

b=bytearray((W/"near.save").read_bytes()); off=0xd4+2*0x1c+8
struct.pack_into(">I",b,off,struct.unpack_from(">I",b,off)[0]|8);struct.pack_into(">H",b,0x30,48)
(W/"near-cleared.save").write_bytes(b)

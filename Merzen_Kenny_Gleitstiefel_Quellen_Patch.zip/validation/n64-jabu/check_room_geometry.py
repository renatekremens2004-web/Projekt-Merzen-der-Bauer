from pathlib import Path
import sys,re,struct,csv,json,subprocess
O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer');sys.path.insert(0,str(R/'tools'));from verify_story import segment
names=[r['Name'] for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];index=names.index('bdan_room_3');_,_,old=segment(Path('/workspace/n64-gag/baseline.z64').read_bytes(),index);_,_,new=segment((O/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes(),index)
assert len(new)>len(old)+16,(len(old),len(new));insert=0xec;adjusted=(new[:insert]+new[insert+16:])[:len(old)]
elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(O/'build/pal-1.0/oot-pal-1.0.elf')],text=True);section=re.search(r"Relocation section '\.rel\.\.bdan_room_3'.*?(?=\nRelocation section|\Z)",elf,re.S)[0];rels={int(a,16):t for a,t in re.findall(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)',section)}
changes=[]
for off in range(0,len(old),4):
 a,b=struct.unpack_from('>I',old,off)[0],struct.unpack_from('>I',adjusted,off)[0]
 if a==b:continue
 if off==0x38:assert a==0x01080000 and b==0x01090000,(hex(a),hex(b));continue
 current=off+(16 if off>=insert else 0);assert rels.get(0x03000000+current)=='R_MIPS_32',(hex(off),hex(a),hex(b))
 assert a>>24==b>>24==3 and b==a+16,(hex(off),hex(a),hex(b));changes.append(off)
Path('/workspace/n64-gag/room-geometry-check.json').write_text(json.dumps({'old_room_bytes':len(old),'new_room_bytes':len(new),'inserted_actor_bytes':16,'actor_count_before':8,'actor_count_after':9,'relocated_pointers_checked':len(changes),'all_original_room_bytes_identical_except_count_and_relocations':True,'added_model_bytes':len(new)-len(old)-16},indent=2)+'\n');print('Original room geometry unchanged; one actor entry, appended model and',len(changes),'verified pointer relocations')

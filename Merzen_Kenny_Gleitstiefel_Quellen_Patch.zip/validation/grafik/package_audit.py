from pathlib import Path
import sys,re,json,hashlib,shutil
from PIL import Image
sys.path.insert(0,str(Path(__file__).parent));from select_shot import select
W=Path('/workspace/graphics-audit');R=Path('/workspace/Projekt-Merzen-der-Bauer');P=R/'previews/grafik';V=R/'validation/grafik';A=Path('/workspace/artifacts');O=Path('/workspace/oot-burns-pal');P.mkdir(exist_ok=True);V.mkdir(exist_ok=True)
choices=[
('Haendler_Original_Clipping_aus.png','audit-beans-walk-native',750,400),
('Haendler_Original_Clipping_an.png','audit-beans-walk-native-clip-on',550,400),
('Haendler_Patch_Clipping_an.png','audit-beans-walk-patch-clip-on',850,446),
('Halle_Patch_Clipping_aus.png','audit-sage-direct-patch-clip-off',850,700),
('Halle_Patch_Clipping_an.png','audit-sage-patch-clip-on',1150,700),
('Halle_Original_Clipping_an.png','audit-sage-native-clip-on',1150,700),
('Bowling_Original.png','audit-bowling-native-clip-on',650,451),
('Bowling_Patch.png','audit-bowling-patch-clip-on',650,549),
('Wiegenlied_Original.png','audit-lesson-fresh-nomove-direct-native-clip-on',2200,300),
('Wiegenlied_Patch.png','audit-lesson-fresh-nomove-direct-patch-clip-on',2200,300),
('Wiegenlied_Patch_Noten.png','audit-lesson-fresh-nomove-direct-patch-clip-on',2200,800),
('Wiegenlied_Original_Hofrand.png','audit-lesson-fresh-nomove-direct-native-clip-on',2200,1800),
('Wiegenlied_Patch_Hofrand.png','audit-lesson-fresh-nomove-direct-patch-clip-on',2200,1600),
('Navi_Original.png','audit-navi-direct-native-clip-on',1100,661),
('Navi_Patch.png','audit-navi-direct-patch-clip-on',1100,918)]
manifest={};cases={}
for name,case,limit,f in choices:
 log=(W/(case+'.log')).read_text();assert 'completed: 0' in log and 'UNKNOWN GBI' not in log and 'Using Vertex outside buffer' not in log,case
 src=select(case,limit,f);im=Image.open(src).convert('RGB');assert im.size==(640,480) and im.getbbox() is not None,case
 shutil.copyfile(src,P/name);config=Path('/workspace/bean-rider')/('config-'+case)/'mupen64plus.cfg';cfg=config.read_text();clipping=re.search(r'^EnableClipping = (True|False)$',cfg,re.M)[1]=='True'
 manifest[name]={'scenario':case,'frame':f,'source_screenshot':src.name,'sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'unedited':True,'software_clipping':clipping,'rom':'original' if 'native' in case else 'patch','test_start':'save context injected in emulator RAM; ROM file unchanged'}
 if 'beans' in case:manifest[name]['merchant_at_native_location']=True
 if case not in cases:
  assert set(re.findall(r'RAM=(\d+)',log))=={'4194304'},case
  cases[case]={'completed':True,'memory_bytes':4194304,'software_clipping':clipping,'observed_message_ids':sorted(set(re.findall(r'(?:TEXT f=\d+|STATE f=\d+ scene=\w+) id=(\w+)',log)))}
  shutil.copyfile(W/(case+'.log'),V/(case+'.log'));shutil.copyfile(config,V/(case+'.cfg'))
(P/'Aufnahmen.json').write_text(json.dumps(manifest,indent=2)+'\n')
def cam(case,f):return re.search(r'^CAM f='+str(f)+r' (.*) age=',(W/(case+'.log')).read_text(),re.M)[1]
comparisons=[('merchant clipping',('audit-beans-walk-native',400),('audit-beans-walk-native-clip-on',400)),('merchant original/patch',('audit-beans-walk-native-clip-on',400),('audit-beans-walk-patch-clip-on',400)),('hall clipping',('audit-sage-direct-patch-clip-off',700),('audit-sage-patch-clip-on',700)),('hall original/patch',('audit-sage-native-clip-on',700),('audit-sage-patch-clip-on',700)),('bowling original/patch',('audit-bowling-native-clip-on',500),('audit-bowling-patch-clip-on',500)),('courtyard final shot',('audit-lesson-fresh-nomove-direct-native-clip-on',1800),('audit-lesson-fresh-nomove-direct-patch-clip-on',1600))]
matched=[]
for label,a,b in comparisons:
 assert cam(*a)==cam(*b),(label,cam(*a),cam(*b));matched.append({'comparison':label,'cases':[a,b],'camera':cam(*a),'equal':True})
for v in ['native','patch']:
 log=(W/('audit-lesson-fresh-nomove-direct-'+v+'-clip-on.log')).read_text();assert 'mode=1b' in log and 'scene=51' in log and 'quest=00041000' in log
rom=O/'build/pal-1.0/oot-pal-1.0-compressed.z64';patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Zoras_Jabu_Navi.bps'
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='e211e8e908a2573578d93ce6e47f01ba82c4bc25729694dc72d74d6afc978ec1'
assert hashlib.sha256(patch.read_bytes()).hexdigest()=='3f66f32317d089f98893616840000a973014b890da339a0c264d43729e86c09a'
report={'date':'2026-10-19','production_rom_unchanged':True,'production_sha256':hashlib.sha256(rom.read_bytes()).hexdigest(),'bps_unchanged':True,'bps_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'valid_cases':cases,'camera_comparisons':matched,'lullaby_completed_original_and_patch':True,'scope':'Targeted 4 MiB scene checks, not a full playthrough or hardware validation.','excluded_attempts':['Initial adult-Link bowling capture: discarded for child-Link matching.','Initial lesson snapshot already had event 59 set: repeated with fresh event state.','Two Navi title-transition starts produced invalid graphics commands: aborted, repeated successfully through native Play_Init.','Glide64mk2 screenshot readback was black: not a valid visual comparison.']}
(V/'runtime-vergleich.json').write_text(json.dumps(report,indent=2)+'\n')
for name in ['runner.c','select_shot.py','package_audit.py']:shutil.copyfile(W/name,V/name)
name='Wundererbsen_Scalper.png';shutil.copyfile(P/'Haendler_Patch_Clipping_an.png',R/'previews/zoras-jabu'/name);m=R/'previews/zoras-jabu/Aufnahmen.json';d=json.loads(m.read_text());d[name]=dict(manifest['Haendler_Patch_Clipping_an.png'],message_id='405E');m.write_text(json.dumps(d,indent=2)+'\n')
print('Prepared',len(manifest),'unaltered screenshots;',len(cases),'valid cases;',len(matched),'equal-camera checks.')

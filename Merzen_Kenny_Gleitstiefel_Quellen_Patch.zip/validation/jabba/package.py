from pathlib import Path
import hashlib,json,re,shutil,zipfile,sys
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/jabba-field');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts');sys.path.insert(0,str(R/'tools'))
from build_story import messages,plain,split_pages
from PIL import Image
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
romsha=sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64');report=json.loads((O/'build/pal-1.0/jabba-verification.json').read_text());pr=json.loads((W/'patch-verification.json').read_text());assert report['rom_sha256']==pr['target_sha256']==romsha
V=R/'validation/jabba';P=R/'previews/jabba';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True);logs={}
for topic,run in [('day','object'),('stones-day','object'),('night','final'),('stones-night','final'),('adult','final'),('english','final'),('chase','final')]:
 p=W/f'jabba-{topic}-{run}-direct-clip-on.log';s=p.read_text();assert 'completed: 0'in s and 'RAM=4194304'in s and not any(x in s for x in ['OBJECT_BANK_OVERFLOW','HERO_COLOAD_ERROR','UNKNOWN GBI COMMAND','Using Vertex outside buffer']);logs[topic]=s;shutil.copyfile(p,V/p.name)
 assert all(int(x)==0 for x in re.findall(r'(?:HEAP|0x[0-9a-f]+) f=\d+ failures=(\d+)',s))
 active=topic in['day','night','stones-day','stones-night']
 if active:assert 'id=71b3'in s and re.search(r'JABBA[^\n]*actor=(?!00000000)[0-9a-f]{8}',s)and 'floor=0.0'in s
 else:assert not re.search(r'JABBA[^\n]*actor=(?!00000000)[0-9a-f]{8}',s)
photos=[]
def photo(topic,run,index,name):
 case=f'jabba-{topic}-{run}-direct-clip-on';source=Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{index:03d}.png';im=Image.open(source).convert('RGB');im.save(P/name);assert im.tobytes()==Image.open(P/name).convert('RGB').tobytes();photos.append(dict(file=name,source=str(source),case=case,rom_sha256=romsha,unaltered_emulator_image=True))
for index,name in [(0,'Jabba_im_Feld.png'),(3,'Jabba_Huttisch.png'),(4,'Jabba_Uebersetzung.png'),(5,'Jabba_Deal.png')]:photo('day','object',index,name)
photo('night','final',3,'Jabba_Nachts.png');(P/'Aufnahmen.json').write_text(json.dumps(photos,ensure_ascii=False,indent=2)+'\n')
for name in ['prepare_runtime.py','runtime_source.py','runner.c','run.py','verification.log','check_patch.js','patch-verification.json','package.py','inspection.json','reduction.json','native-code-hashes.json']:
 shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/jabba-verification.json',V/'jabba-verification.json')
runtime=dict(rom_sha256=romsha,ram_bytes=4194304,completed=list(logs),minimum_object_bank_remaining=min(int(x)for s in logs.values()for x in re.findall(r'remaining=(\d+)',s)),minimum_native_arena_largest_free=min(int(x)for s in logs.values()for x in re.findall(r'largest=(\d+)',s)),native_arena_allocation_failures=0,max_object_slots=max(int(x)for s in logs.values()for x in re.findall(r'OBJECT_BANK[^\n]*entries=(\d+)',s)),child_position=[-500,0,2400],native_cameras_and_actor_positions=True)
(V/'runtime-verification.json').write_text(json.dumps(runtime,indent=2)+'\n')
m=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());text=['# Jabba — Huttisch mit deutscher Übersetzung','','Hyrule-Feld, nur Kinder-Zeit, neben dem Weg Richtung Hyrule-Stadt. Wortlaut vom Nutzer einschließlich Großschreibung und „BAT“ übernommen. Erst der huttische Satz, danach die Übersetzung in Klammern; die längere Übersetzung bekommt wegen der vier Textzeilen eine eigene manuell bestätigte Seite.','']
for i,b in enumerate(split_pages(m['71B3']['parts'][2][2])[0],1):text+=['**Seite '+str(i)+'**','']+['> '+q for q in plain(b).strip().splitlines()]+['']
text='\n'.join(text);(R/'planning/JABBA_DIALOG.md').write_text(text);(D/'Jabba_Dialog.md').write_text(text)
doc=f'''# Jabba im Hyrule-Feld

Gesamtpatch gegen unveränderte Europa/PAL 1.0, Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`, Ziel-SHA256 `{romsha}`. Alle bisherigen Änderungen enthalten, weiterhin 40 MiB ROM und tatsächliche 4 MiB N64-RAM.

## Modell und Auftritt

Bereitgestellte GLB ohne Rig mit 493.466 Dreiecken auf 2.391 reduziert: Körper 2.200, getrennte Augen 95/96. Die erste direkte Vereinfachung zerhackte Kontur und UVs; finale Fassung verwendet eine geschlossene Oberfläche mit Voxeln 0,085 und anschließendem gleichmäßigen Dreiecksbudget. Diffuse Originalfarben vom unveränderten dichten Modell auf eigene Kopf-/Körperatlanten übertragen. Originale Augenpositionen und Augen-UVs erhalten. Drei CI4-Texturen je 64×64 mit 16 Farben, native Beleuchtung/Nebel/Tiefentest. Höhe 78, Breite etwa 163, Tiefe 92 Spieleinheiten; nur gleichmäßige Skalierung. Zwei eigene starre Gruppen mit sehr kleiner Kopfrotation, keine Animation durch nichtuniforme Gliedmaßenskalierung.

Jabba bei −500/0/2400 seitlich des Weges Richtung Hyrule-Stadt. Kollisionsradius 42, Höhe 76, normale OC-Körperkollision, kein Angriff oder Treffer, kein Weg-/Questschalter. Fest bleibender Körper/Schwanz, keine für Bilder versetzte Figur. Normales A-Gespräch und native Kamera. Nur Kind/deutsch.

Die zwei normalen Kinder-Listen im Feld entsprechen dem Fortschritt vor/nach den drei Steinen; die Spielzeit bestimmt dort weiter Tag und Nacht. Beide Listen erhalten genau einen NPC und ein Objekt. Erwachsene sowie alle Spezial-, Flucht- und Abspann-Listen bleiben erhalten. Deshalb auch nach den drei Steinen als Kind ansprechbar, ohne in die Fluchtsequenz hineinzuragen.

## Speicher

Die erste Ablage im Raum ließ den Akteur im Feld nicht erscheinen. Die finale Fassung registriert deshalb ein eigenes Objekt `object_jabba`, ID 0x0192, und hängt dessen komprimiertes DMA-Segment an das Ende. Alle bisherigen Objekt-IDs und DMA-Indizes bleiben erhalten. Modell nur in den beiden normalen Kinder-Objektlisten; keine zusätzliche Aufnahme in Zwischensequenzen. Originale Objektsegmente unverändert. Grafik bindet das eigene geladene Segment 6 und stellt es sowie Segment 13 anschließend wieder her.

Im reservierten Objektpuffer bleibt in den normalen Kinder-Proben mindestens 178.688 Byte frei. Maximal {runtime['max_object_slots']} von 19 Objekt-Slots belegt. Raumpuffer 86.608 Byte einschließlich der kleinen zusätzlichen Listen, statt der teuren Modellablage dort. In allen sieben Proben meldet die native Zelda-Arena null fehlgeschlagene Belegungen; größte freie zusammenhängende Arena-Fläche mindestens {runtime['minimum_native_arena_largest_free']:,} Byte. Fluchtprobe ebenfalls mit 4 MiB, ohne Jabba oder sein Objekt. Nicht mit ungenutztem Objektpuffer gleichzusetzen: Objektbank und Arena werden getrennt geprüft.

## Texte und Tabellen

Neue private ID 71B3 mit fünf manuell bestätigten Seiten; erst der vom Nutzer gelieferte huttische Satz, dann die deutsche Klammerübersetzung. Deutsche Großschreibung und „BAT“ wortgetreu. Kein Eingriff in Lesetempo oder feste Zeiten. Alle bisherigen Nachrichten in allen Sprachen sowohl als Quelle als auch kompiliert unverändert. Insgesamt 1.031 eigene Nachrichten; alle Roh-/Seitenpuffer geprüft.

Die neue Nachricht steht physisch vor der bisherigen letzten Nachricht 71B2. PAL liest die DMA-Länge aus dem nächsten Spracheintrag: Folgezeiger in Englisch, Deutsch und Französisch ausdrücklich geprüft, positive Länge unter 1.280 Byte. Kein nativer Dialogplatz zweckentfremdet. Neue englische/französische Reserveeinträge enthalten nur „Jabba.“ und sind wegen der Sprachprüfung nicht über diesen NPC zugänglich. Der Host-Builder `add_private_message` unterstützt dieselbe explizite Registrierung bei einem vollständigen Story-Neubau.

Alle 1.510 komprimierten Segmente gegen den unkomprimierten Build sowie CIC-6105-Prüfsumme geprüft. 3.664 native Kernfunktionen/Datensymbole bytegleich oder ausschließlich echte MIPS-Linker-Relokationen. Nachrichtentabellen und Objekttabelle um jeweils den einen neuen Eintrag ergänzt. Der Objektanzahlwert wächst auf 0x0193; beim Laden der Händler werden die bisherigen OBJECT_ID_MAX-Platzhalter konsistent von 0x0192 auf 0x0193 aktualisiert (16 geprüfte Wörter). Bestehende Objektumfangswerte und sämtliche Boß-/Charaktermodelle erhalten. Im Elf_Msg2-Overlay kommen vier private Helfer und die drei begrenzten Initialisierungs-/Update-/Zerstörungszweige hinzu; alle anderen Funktionen unverändert. Keine Änderungen an bestehenden Kern-Quelldateien oder an der Textsuchfunktion.

## Laufzeit und Lieferung

Sieben abgeschlossene Proben: Kind tags/nachts, jeweils vor/nach den drei Steinen; Erwachsener; englische Kinder-Fassung; native Fluchtsequenz. Vier Kinder-Gespräche geöffnet und durchgeblättert. Alle tatsächliche 4 MiB, keine beobachteten Grafikbefehlsfehler, Überläufe oder fehlgeschlagenen nativen Speicherbelegungen in diesen Proben. Bilder unveränderte Emulatoraufnahmen genau dieses Builds; lokale Spielstands-Fixtures bereiten nur Spieler/Fortschritt vor. Kein kompletter Durchlauf oder Hardwaretest in diesem Schritt.

RomPatcher.js mit aktiver Quellvalidierung erzeugt bytegenau die geprüfte ROM. BPS auf unveränderte Vanilla PAL 1.0 anwenden. Keine ROM, Spielstände, Savestates, RAM-Abzüge, ausführbare Dateien oder die dichte GLB veröffentlicht. Vorbereitete Modell-JSON/PNGs und Builder reichen zum Neubau.

Letzter Schritt nach `build_ben_ice.py`: `python3 tools/build_jabba.py <oot>`, danach normal bauen/komprimieren. Benötigte Quell-Snapshots einschließlich ursprünglicher Objekttabelle und Spec enthalten. Offline-Neuableitung mit Blender 4.3.2: `prepare_jabba_lowpoly.py`, `bake_jabba_colors.py`, `export_jabba.py`, jeweils mit `-- <arbeitsordner>` und entpacktem Nutzer-Upload unter `input/`. Die Vergleichsprüfung benötigt die private vorige ROM/ELF und Textobjekte; sie werden nicht mitgeliefert.
'''
(R/'TESTING_JABBA.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Jabba.bps';shutil.copyfile(patch,R/'patches'/patch.name);heading='# Jabba auf dem Weg zu Friedrich Merz'
p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Jabbas Dialog](planning/JABBA_DIALOG.md) · [Prüfung](TESTING_JABBA.md) · [Echte Bilder](previews/jabba/)\n\nJabba nur als Kind im Hyrule-Feld neben dem Weg Richtung Hyrule-Stadt. Erst Huttisch, dann deutsche Übersetzung in Klammern. 2.391 Dreiecke, eigenes Objekt nur für die Kinder-Listen. Alle bisherigen Änderungen enthalten. Neuer letzter Builder: `build_jabba.py`.\n\n'+p.read_text())
p=R/'story/LEITLINIEN.md';s=p.read_text();entry='\n\nJabba: 71B3, Kinder-Hyrule-Feld. Immer erst den vorgegebenen huttischen Satz, danach die deutsche Klammerübersetzung. Eigenes Objekt 0x0192 am Ende der DMA-Liste; nur normale Kinder-Listen vor/nach den drei Steinen, niemals Flucht-/Abspann-Listen. Eigene Proportionen und native Beleuchtung. build_jabba.py als letzten Builder nach build_ben_ice.py anwenden.\n'
if entry.strip()not in s:p.write_text(s+entry)
archive=A/'Merzen_Jabba_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in['water-comic-heroes','ben-ice','jabba']and(p.suffix in['.c','.h']or rel.parts[-2:]==('spec','spec'))
  if not p.is_file()or(any(q in exclude for q in rel.parts)and not original)or(p.suffix.lower()not in suffixes and not original):continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='jabba':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st','.mp4','.glb'}for n in z.namelist());assert 'tools/originals/jabba/spec/spec'in z.namelist()
instruction=A/'Anleitung_Jabba.txt';instruction.write_text('Kumulativer Gesamtpatch: Jabba im Hyrule-Feld der Kinder-Zeit, Huttisch mit deutscher Klammerübersetzung. Alle bisherigen Änderungen enthalten.\n\nMit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte, unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände benutzen; alte Emulator-Savestates können alte Modelle/Overlays enthalten. Tatsächliche 4 MiB geprüft.\n')
for p in[patch,archive,instruction]:shutil.copyfile(p,D/p.name)
G=D/'Jabba_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
files=[D/p.name for p in[patch,archive,instruction]]+[D/'Jabba_Dialog.md'];sums=D/'SHA256SUMS_Jabba.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files));files.append(sums)
p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Jabbas Dialog](Jabba_Dialog.md) · [Bilder und Prüfung](Jabba_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nJabba im Kinder-Hyrule-Feld neben dem Weg Richtung Stadt. Erst Huttisch, dann deutsche Übersetzung in Klammern. Tags/nachts, vor und nach den drei Steinen. 2.391 Dreiecke, eigenes Kinder-Objekt. Alle bisherigen Änderungen enthalten; BPS auf unveränderte Vanilla PAL 1.0 anwenden. 4 MiB geprüft.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=romsha,files=[p.name for p in files],runtime=runtime),indent=2)+'\n');print('Packaged',romsha,'source ZIP bytes',archive.stat().st_size)

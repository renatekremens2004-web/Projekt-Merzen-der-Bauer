from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
W=Path('/workspace/navi-roasts');jobs=[('native-roast-skull-direct-clip-on','skull',950),('native-roast-shell-direct-clip-on','shell',950),('native-roast-skull-english-direct-clip-on','skull-english',950)]
def run(j):subprocess.run([sys.executable,str(W/'run.py'),*map(str,j)],check=True)
with ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(run,jobs))

from pathlib import Path
import json,re,struct
W=Path('/workspace/navi-roasts');O=Path('/workspace/oot-burns-pal');s=Path('/workspace/n64-gag/runner.c').read_text();marker='  if(f==300 && strstr(scenario,"navi"))'
block='''  if(strstr(scenario,"native-roast")){
   uint32_t n=actor(strstr(scenario,"shell")?0xc5:0x37);
   if(f%100==0)printf("NATIVE_TARGET f=%u actor=%08x id=%x hint=%04x pos=(%.1f %.1f %.1f) focus=%08x lang=%u\\n",f,n,n?DebugMemRead16(n):0,n?DebugMemRead8(n+0x117)+0x600:0,n?rf(n+0x24):0,n?rf(n+0x28):0,n?rf(n+0x2c):0,r32(player+0x654),DebugMemRead8(savebase+0x1409));
   if(f>20 && mode==0){value=0x20;if(f>60 && f%80<8)value|=0x800;}
  }
''';s=s.replace(marker,block+marker);(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms));print(syms)
for name,entrance,room,age,lang,pos in [('skull',0,8,1,1,(-2684.,-760.,-570.)),('skull-english',0,8,1,0,(-2684.,-760.,-570.)),('shell',0x10,18,0,1,(1444.,0.,360.))]:
 b=bytearray(Path('/workspace/transition/market-pre.save').read_bytes());struct.pack_into('>I',b,0,entrance);struct.pack_into('>I',b,4,age);struct.pack_into('>I',b,8,0);b[0x1409]=lang
 struct.pack_into('>I',b,0x1360,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,-32768,0xdff,entrance,room);struct.pack_into('>H',b,0x1412,0xffef);b[0x1414]=0
 struct.pack_into('>H',b,0x2e,0xc0);struct.pack_into('>H',b,0x30,0xc0)
 if age==0:
  struct.pack_into('>H',b,0x70,0x2322);struct.pack_into('>H',b,0x9c,0x7fff);b[0x68]=0x3c;x=struct.unpack_from('>H',b,0xedc)[0];struct.pack_into('>H',b,0xedc,x|0x20)
 (W/(name+'.save')).write_bytes(b)

from pathlib import Path
import subprocess,json,os
W=Path('/workspace/mido-zukunft');s=json.loads((W/'symbols.json').read_text());case='mido-future-v1-direct-clip-on'
with (W/(case+'.log')).open('w') as log:subprocess.run(['/workspace/forest-dialogue/runner','/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,'1000','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/'mido.save')],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
print('Completed',case)

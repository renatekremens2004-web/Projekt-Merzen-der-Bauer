from pathlib import Path
import re,json,struct
W=Path('/workspace/mido-zukunft');R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal')
s=(R/'tools/verify_forest_opening.py').read_text().replace('3b1e1808f52f6484b3a76cd8aaa90feccc0bbbf825cd779f5a9e8031efe766ce','unused')
s=s.replace('508a8bf66f5775e4f88151723089abe713ce7d1b490a6964fed01640411bb168','3b1e1808f52f6484b3a76cd8aaa90feccc0bbbf825cd779f5a9e8031efe766ce').replace('len(edits)==695','len(edits)==698')
s=re.sub(r'assert changed_ids==\{[^\n]+\},\[hex\(x\) for x in changed_ids\]', 'assert changed_ids=={0x1060,0x1061,0x1068},[hex(x) for x in changed_ids]',s)
s=s.replace('Forest opening: Kokiri, Shiek and Boris; 695 edited messages','Adult Mido: seven-year grudge and victory party; 698 edited messages').replace('forest-opening-verification.json','mido-future-verification.json').replace('verify_forest_opening.py','verify_mido_future.py')
mp=(W/'baseline.map').read_text();bs={}
for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):bs.setdefault(n,int(a,16))
s=re.sub(r'old_symbols=\{[^\n]+\}', 'old_symbols='+repr({k:bs[k] for k in ['_codeSegmentStart','sNesMessageEntryTable','sGerMessageEntryTable','sFraMessageEntryTable']}),s)
(R/'tools/verify_mido_future.py').write_text(s)
s=Path('/workspace/forest-dialogue/check_controls.py').read_text();s=s[:s.index("assert 'RACE_TIME'")] if "assert 'RACE_TIME'" in s else s
s=s.replace('/workspace/forest-dialogue','/workspace/mido-zukunft').replace('len(report)==695','len(report)==698').replace('695 control','698 control');s += "\nassert report['1060']['controls']==['TEXTID(0x1061)']\n";(W/'check_controls.py').write_text(s)
s=Path('/workspace/forest-dialogue/check_patch.js').read_text().replace('/workspace/forest-dialogue','/workspace/mido-zukunft').replace('Wald_Auftakt.bps','Mido_Zukunft.bps');(W/'check_patch.js').write_text(s)
s=Path('/workspace/forest-dialogue/select_shot.py').read_text().replace('/workspace/forest-dialogue','/workspace/mido-zukunft');(W/'select_shot.py').write_text(s)
b=bytearray(Path('/workspace/forest-dialogue/house.save').read_bytes());struct.pack_into('>III',b,0,0x11e,0,0);struct.pack_into('>fffhHhB',b,0x1368,1599.,0.,-920.,-32768,0xdff,0x11e,3)
for base,x in [(0xed4,0x48),(0xed4,0x0a),(0xef8,0x15)]:
 o=base+2*(x>>4);struct.pack_into('>H',b,o,struct.unpack_from('>H',b,o)[0]&~(1<<(x&15)))
(W/'mido.save').write_bytes(b)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))

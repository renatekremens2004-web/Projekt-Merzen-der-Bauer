Neun native Szenarien; siehe ../../TESTING_EULE_TAGESDIALOGE.md. Keine ROMs, Saves oder Emulator-Binaries.

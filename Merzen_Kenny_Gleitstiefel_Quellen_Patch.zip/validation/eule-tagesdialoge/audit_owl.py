from pathlib import Path
import re,json,sys
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/oot-burns-pal');W=Path('/workspace/eule-tagesgags');sys.path.insert(0,str(R/'tools'));import build_story as b
native=b.messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text());current=b.messages((O/'extracted/pal-1.0/text/message_data.h').read_text());ed={i:(p.name,e) for p in (R/'story').glob('*.json') for i,e in json.loads(p.read_text())['messages'].items()};src=(O/'src/overlays/actors/ovl_En_Owl/z_en_owl.c').read_text();ids={i.upper() for i in re.findall(r'(?:Textbox\(play,|Talk\(this, play,|textId =|play, )\s*0x([0-9a-fA-F]{4})',src)}|{'4003','4004'}
while True:
 add={i.upper() for k in ids for i in re.findall(r'TEXTID\(0x([0-9a-fA-F]{4})\)',native[k]['parts'][2][2])}-ids
 if not add:break
 ids|=add
assert ids==set(json.loads((W/'owl-ids.json').read_text()))
report={}
for i in sorted(ids):
 assert i in ed,i
 old=native[i]['parts'][2][2];new=current[i]['parts'][2][2];assert b.controls(old)==b.controls(new),i
 assert all(word not in ' '.join(ed[i][1]['pages']) for word in ['Habeck','Geistereule','Rauru','Rauro']),i
 assert b.plain(new)!=b.plain(old),('still vanilla',i)
 report[i]={'chapter':ed[i][0],'own_dialogue':True,'native_controls_preserved':True,'pages':len(b.split_pages(new)[0]),'native_pages':len(b.split_pages(old)[0])}
# The shared EnHy actor routing itself remains native; neither target checks bottles.
p=O/'src/overlays/actors/ovl_En_Hy/z_en_hy.c';import subprocess
assert p.read_bytes()==subprocess.check_output(['git','-C',str(O),'show','HEAD:src/overlays/actors/ovl_En_Hy/z_en_hy.c'])
(W/'owl-audit.json').write_text(json.dumps(report,indent=2)+'\n');print('All',len(report),'owl entries own, with original controls and no identity spoiler; day-NPC routing native.')

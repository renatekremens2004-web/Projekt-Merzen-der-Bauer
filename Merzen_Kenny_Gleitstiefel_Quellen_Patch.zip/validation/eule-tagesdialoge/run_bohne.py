from pathlib import Path
import re,json,subprocess,os
W=Path('/workspace/eule-tagesgags');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols-final.json').write_text(json.dumps(syms));case='eulgag-bohne-sword-v1-direct-clip-on'
with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/'runner'),str(O/'build/pal-1.0/oot-pal-1.0-compressed.z64'),case,'2200','4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),'/workspace/transition/sword-near.save'],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
print('Completed',case,flush=True)

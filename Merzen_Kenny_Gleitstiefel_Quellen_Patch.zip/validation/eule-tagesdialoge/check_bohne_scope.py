from pathlib import Path
import sys,csv,re,json,hashlib,struct
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/eule-tagesgags');sys.path.insert(0,str(R/'tools'));from verify_story import segment
before=(W/'owl-version.z64').read_bytes();after=(O/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes();names=[r['Name'] for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={}
for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):syms.setdefault(n,int(a,16))
def messages(rom):
 _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'));base=syms['_codeSegmentStart'];p=syms['sNesMessageEntryTable']-base;ids=[]
 while True:
  i=struct.unpack_from('>H',code,p)[0];p+=8
  if i==0xffff:break
  if i!=0xfffc:ids.append(i)
 p=syms['sGerMessageEntryTable']-base;entries=[(i,struct.unpack_from('>I',code,p+4*k)[0]&0xffffff) for k,i in enumerate(ids)]
 return {i:data[a:entries[k+1][1] if k+1<len(entries) else len(data)].rstrip(b'\0') for k,(i,a) in enumerate(entries)}
a,b=messages(before),messages(after);changed={i for i in a if a[i]!=b[i]};assert changed=={0x2019,0x201E,0x700A},[hex(i) for i in changed]
segments_changed=[]
for k,n in enumerate(names):
 if segment(before,k)[2]!=segment(after,k)[2]:segments_changed.append(n)
assert set(segments_changed)<={'makerom','dmadata','code','ger_message_data_static'},segments_changed
r={'intermediate_runtime_rom_sha256':hashlib.sha256(before).hexdigest(),'production_rom_sha256':hashlib.sha256(after).hexdigest(),'changed_message_ids':['2019','201E','700A'],'changed_segments':segments_changed,'all_actor_overlays_byte_identical':True,'all_other_message_payloads_byte_identical':True,'reason':'User requested the nickname Herr Bohne in Merz speeches after owl/day validation; all other messages and actor overlays unchanged.'};(W/'bohne-scope-verification.json').write_text(json.dumps(r,indent=2)+'\n');print(r)

changes=json.loads((W/'changes.json').read_text())
for i in changes['bohne_ids']:
 pages=changes['after'][i]['pages'];assert any('Herr Bohne' in p for p in pages);assert not any('Bean' in p or 'Bone' in p for p in pages)

from pathlib import Path
import re,json,struct
W=Path('/workspace/eule-tagesgags');O=Path('/workspace/oot-burns-pal');s=Path('/workspace/transition/runner.c').read_text()
block='''  if(f>=450 && f<550 && mode==0 && strstr(scenario,"eulgag")) {
   uint32_t npc=0;float d=35;
   if(strstr(scenario,"fieldbird")){npc=actor_type(0x14d,0x4c);d=180;}
   if(strstr(scenario,"eels"))npc=actor_type(0x16e,6);
   if(strstr(scenario,"rescue"))npc=actor_type(0x16e,4);
   if(strstr(scenario,"nightwatch"))npc=actor_type(0x178,8);
   if(npc){int yaw=DebugMemRead16(npc+0xb6);position(player,rf(npc+0x24)+sinf(yaw*3.14159265f/32768)*d,rf(npc+0x28),rf(npc+0x2c)+cosf(yaw*3.14159265f/32768)*d,yaw+0x8000);if(f==450)printf("NATIVE_NPC f=%u id=%x params=%x position=(%.1f %.1f %.1f)\\n",f,DebugMemRead16(npc),DebugMemRead16(npc+0x1c),rf(npc+0x24),rf(npc+0x28),rf(npc+0x2c));}
  }
  if(f%100==0)printf("ELG_STATE f=%u fled=%x bottleSlots=%02x%02x%02x%02x choice=%u\\n",f,DebugMemRead16(savebase+0xee4)&1,DebugMemRead8(savebase+0x86),DebugMemRead8(savebase+0x87),DebugMemRead8(savebase+0x88),DebugMemRead8(savebase+0x89),DebugMemRead8(m+0xe3e5));
  /* Normal stick/A input: repeat the field/castle owl once, then leave. */
  if(strstr(scenario,"fieldbird") || strstr(scenario,"castlebird")){
   static unsigned previousChoice=0,choiceVisits=0;unsigned chosen=(id==0x2066 || id==0x206a) && mode==0x35;
   if(chosen && !previousChoice)choiceVisits++;previousChoice=chosen;
   if(chosen && choiceVisits>=2 && DebugMemRead8(m+0xe3e5)==0)value=0xba000000;
  }
'''
s=s.replace('  if(f==300 && strstr(scenario,"navi"))',block+'  if(f==300 && strstr(scenario,"navi"))');s=s.replace(' if(buttons)buttons(value);',' if(f>=440 && f<456)value &= ~0x20;\n if(buttons)buttons(value);');(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
cases=[('eels-before',0xb1,0x8000,(-135.,0.,-108.),False,1200),('rescue-before',0xb1,0x8000,(-110.,0.,-286.),False,1200),('eels-after',0xb1,0x8000,(-135.,0.,-108.),True,1200),('rescue-after',0xb1,0x8000,(-110.,0.,-286.),True,1200),('nightwatch',0xb1,0,(111.,0.,-475.),False,1200),('fieldbird',0xcd,0x8000,(4250.,200.,7720.),False,2400),('castlebird',0x138,0x8000,(-146.,1400.,3140.),False,2000),('riverbird',0xea,0x8000,(-1397.,100.,580.),False,1600)]
for name,entr,time,pos,post,frames in cases:
 b=bytearray(Path('/workspace/transition/market-post.save' if post else '/workspace/transition/market-pre.save').read_bytes());struct.pack_into('>I',b,0,entr);struct.pack_into('>I',b,4,1);struct.pack_into('>I',b,8,0);struct.pack_into('>H',b,0xc,time);struct.pack_into('>I',b,0x10,int(time==0));struct.pack_into('>H',b,0x141a,time);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,0,0xdff,entr,0);b[0x86:0x8a]=b'\xff'*4
 # Test both first/repeat conversations, without bottle or trade prerequisites.
 struct.pack_into('>H',b,0xf10,struct.unpack_from('>H',b,0xf10)[0]&~0x60)
 if name=='fieldbird':
  struct.pack_into('>I',b,0xa4,0x40000);struct.pack_into('>H',b,0xedc,struct.unpack_from('>H',b,0xedc)[0]&~1)
 if name=='riverbird':
  struct.pack_into('>H',b,0xeda,struct.unpack_from('>H',b,0xeda)[0]&~0x200);struct.pack_into('>I',b,0xa4,struct.unpack_from('>I',b,0xa4)[0]|(1<<20)|(1<<14))
 (W/(name+'.save')).write_bytes(b)
(W/'cases.json').write_text(json.dumps({c[0]:c[-1] for c in cases}))

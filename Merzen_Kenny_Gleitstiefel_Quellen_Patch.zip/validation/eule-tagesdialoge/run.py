from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/eule-tagesgags');s=json.loads((W/'symbols.json').read_text());cases=json.loads((W/'cases.json').read_text())
def run(name):
 case='eulgag-'+name+os.environ.get('EUL_RUN','-v1')+'-focus-direct-clip-on'
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/os.environ.get('EUL_RUNNER','runner')),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(cases[name]),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(name+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:] or cases))

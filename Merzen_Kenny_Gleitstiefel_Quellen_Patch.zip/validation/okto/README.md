Vier native 4-MiB-Szenarien; siehe ../../TESTING_OKTO.md. Keine ROMs, Saves oder Binaries.

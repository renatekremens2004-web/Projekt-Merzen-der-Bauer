from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/friendly-octorok');s=json.loads((W/'symbols.json').read_text())
def run(name):
 case='oktotest-'+name+os.environ.get('OKTO_RUN','-v1')+('-direct-clip-on' if name=='hostile' else '-focus-direct-clip-on');frames=2000 if name=='talk' else 1400
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/'runner'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(frames),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(name+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:] or ['talk','cleared','hostile','english']))

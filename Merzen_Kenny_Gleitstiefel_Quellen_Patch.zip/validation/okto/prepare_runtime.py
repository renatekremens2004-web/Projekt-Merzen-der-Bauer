from pathlib import Path
import re,struct,json
W=Path('/workspace/friendly-octorok');O=Path('/workspace/oot-burns-pal');s=Path('/workspace/transition/runner.c').read_text()
block='''  if(strstr(scenario,"oktotest") && f>=450 && f<550 && mode==0 && !strstr(scenario,"hostile")){
   uint32_t n=actor_type(0xe,0x7f);if(n){int yaw=DebugMemRead16(n+0xb6);position(player,rf(n+0x24)+sinf(yaw*3.14159265f/32768)*55,rf(n+0x28),rf(n+0x2c)+cosf(yaw*3.14159265f/32768)*55,yaw+0x8000);}
  }
  if(strstr(scenario,"hostile")){static uint32_t lastShot=0;uint32_t shot=actor_type(0xe,0x10);if(shot && shot!=lastShot)printf("NATIVE_SHOT f=%u ptr=%08x\\n",f,shot);lastShot=shot;}
  if(f%50==0 && strstr(scenario,"oktotest")){
   int enemies=0,shots=0;uint32_t n=actor_type(0xe,0x7f);
   for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),k=0;a>=0x80000000 && a<0x80800000 && k<100;a=r32(a+0x124),k++)if(DebugMemRead16(a)==0xe && r32(a+0x130)){if(DebugMemRead16(a+0x1c)==0)enemies++;if(DebugMemRead16(a+0x1c)==0x10)shots++;}
   printf("OKTO f=%u npc=%08x cat=%d flags=%x AT=%x AC=%x enemies=%d shots=%d hearts=%u pos=(%.1f %.1f %.1f) floor=%.1f\\n",f,n,n?DebugMemRead8(n+2):-1,n?r32(n+4):0,n?DebugMemRead8(n+0x370):0,n?DebugMemRead8(n+0x371):0,enemies,shots,DebugMemRead16(savebase+0x30),n?rf(n+0x24):0,n?rf(n+0x28):0,n?rf(n+0x2c):0,n?rf(n+0x80):0);
  }
'''
s=s.replace('  if(f==300 && strstr(scenario,"navi"))',block+'  if(f==300 && strstr(scenario,"navi"))');s=s.replace(' if(buttons)buttons(value);',' if(f>=440 && f<456)value &= ~0x20;\n if(strstr(scenario,"hostile"))value=0;\n if(strstr(scenario,"oktotest-talk") && f>=950 && play && DebugMemRead8(play+0x20d8+0xe304)==0){value=0x20;if(f%50<4)value|=0x40;}\n if(buttons)buttons(value);');(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
for name,pos in [('cleared',(100.,-200.,240.)),('talk',(100.,-200.,240.)),('hostile',(0.,-300.,-40.)),('english',(100.,-200.,240.))]:
 b=bytearray(Path('/workspace/transition/market-pre.save').read_bytes());struct.pack_into('>H',b,0x2e,0xa0);struct.pack_into('>H',b,0x30,0xa0);
 if name=='cleared':struct.pack_into('>I',b,0xd4+2*0x1c+8,struct.unpack_from('>I',b,0xd4+2*0x1c+8)[0]|1)
 struct.pack_into('>I',b,0,0x28);struct.pack_into('>I',b,4,1);struct.pack_into('>I',b,8,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,0,0xdff,0x28,0);b[0x1409]=0 if name=='english' else 1;(W/(name+'.save')).write_bytes(b)

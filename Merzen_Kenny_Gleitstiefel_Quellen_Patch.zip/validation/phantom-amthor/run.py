from pathlib import Path
import subprocess,os,json,hashlib,sys
W=Path('/workspace/phantom-amthor');s=json.loads((W/'symbols.json').read_text())
for topic in sys.argv[1:]:
 case='phantom-amthor-'+topic+os.environ.get('RUN','-v1')+'-direct-clip-on';limit=int(os.environ.get('FRAME_LIMIT',1700));rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64')
 (W/(case+'.json')).write_text(json.dumps(dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),limit=limit,fixture=topic,prepared_player_and_progress_only=not (topic.startswith("combat-") or topic=="death-sequence"),combat_assistance=["prepared third arrow-hit outcome", "prepared returned volleys and low health", "prepared arena player start and native controller inputs; see detailed log"] if topic.startswith("combat-") else []),indent=2)+'\n')
 with (W/(case+'.log')).open('w') as log:
  subprocess.run([str(W/'runner'),str(rom),case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)

from pathlib import Path
import json,shutil,sys,re
from select_shot import select
W=Path('/workspace/phantom-amthor');R=Path('/workspace/Projekt-Merzen-der-Bauer');P=R/'previews/phantom-amthor';P.mkdir(exist_ok=True)
# Only native in-game captures. No compositing, redrawn dialogue or image edits.
choices=[
 ('Burns_vor_Enthuellung.png','intro-final',300),
 ('Smithers_Schabernack.png','intro-final',498),
 ('Amthor_Bossname.png','intro-final',734),
 ('Bean_Genickbruch.png','hall-bean-final',536),
 ('Darunia_Chef.png','darunia-child-final',400),
 ('Darunia_Faehigkeiten.png','darunia-child-final',482),
 ('Darunia_Weiser.png','hall-darunia-final',481),
 ('Jabu_Dialog_am_Brunnen.png','market-ground-final',213),
 ('Deku_Baum_Letzter_Satz.png','deku-death-release',1904),
]
# Additional completed proof cases can append captures here once inspected.
extra=W/'additional-previews.json'
if extra.exists():choices+=json.loads(extra.read_text())
photos=[]
for name,short,frame in choices:
 case='phantom-amthor-'+short+'-direct-clip-on';src=select(case,frame);assert src.exists();shutil.copyfile(src,P/name)
 meta=json.loads((W/(case+'.json')).read_text());photos.append(dict(file=name,case=case,logical_frame=frame,**meta,native_actor_positions=True,unedited_emulator_png=True))
(P/'Aufnahmen.json').write_text(json.dumps(photos,ensure_ascii=False,indent=2)+'\n')
print('Copied',len(photos),'genuine captures.')

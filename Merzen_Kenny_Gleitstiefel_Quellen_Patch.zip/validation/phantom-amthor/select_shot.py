from pathlib import Path
import re,sys
W=Path('/workspace/phantom-amthor')
def select(case,frame):
 events=sorted(set(int(x) for x in re.findall(r'^PHOTO f=(\d+)',(W/(case+'.log')).read_text(),re.M)))
 return Path('/workspace/bean-rider')/('screens-'+case)/('the_legend_of_zelda-%03d.png'%events.index(frame))
if __name__=='__main__':print(select(sys.argv[1],int(sys.argv[2])))

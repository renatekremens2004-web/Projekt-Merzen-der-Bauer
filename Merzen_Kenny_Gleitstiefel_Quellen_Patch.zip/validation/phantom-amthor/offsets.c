#include "src/overlays/actors/ovl_Boss_Ganondrof/z_boss_ganondrof.h"
#include "src/overlays/actors/ovl_En_fHG/z_en_fhg.h"
#include "save.h"
#include "play_state.h"
#include "stddef.h"
unsigned offsets[]={
 offsetof(BossGanondrof,work),offsetof(BossGanondrof,flyMode),offsetof(BossGanondrof,deathState),offsetof(BossGanondrof,bodyCollider),offsetof(BossGanondrof,actionFunc),offsetof(EnfHG,amthorGreetingState),offsetof(EnfHG,cutsceneState),offsetof(EnfHG,timers),offsetof(EnfHG,bossGndSignal),sizeof(EnfHG),offsetof(SaveContext,save.info.infTable),offsetof(SaveContext,save.info.eventChkInf),offsetof(Actor,colChkInfo.health),offsetof(PlayState,actorCtx.titleCtx),offsetof(TitleCardContext,alpha),offsetof(EnfHG,actionFunc)};

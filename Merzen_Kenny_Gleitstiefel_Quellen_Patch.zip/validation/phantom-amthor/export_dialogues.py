from pathlib import Path
import re,sys,json
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery')
sys.path.insert(0,str(R/'tools'));import build_story as b
m=b.messages((O/'extracted/pal-1.0/text/message_data.h').read_text());out=['# Amthor, Bean, Darunia, Deku-Baum und Stadt: eingebaute Dialoge','','Aus der fertigen deutschen ROM-Fassung. Absätze entsprechen Textseiten; {Spielername} ist der gespeicherte Spielername. Bestehende feste Szenenzeiten sind unverändert.','']
groups=[('Philipp Amthor (Smithers)',['209B','061A','062B','108E']),('Mr Bean nach dem Schattentempel',['5022','5025','5026','502B']),('Darunia und seine besonderen Fähigkeiten',['301A','301B','301C','301D','301E','301F','3017','302F','3037','3039','303C','3045','3046','303D']),('Deku-Baum und Mido',['1091','1029','102A','1045']),('Hyrule-Stadt: Dialogtausch nach Zeldas Flucht',['7044','7046'])]
for title,ids in groups:
 out+=['## '+title,'']
 if ids==['7044','7046']:
  out+=['Der blau gekleidete Mann mit Schnurrbart nahe dem Brunnen erhält den langen Jabu-Jabu-Einkaufsdialog (7044). Der Mann auf der hohen Plattform erhält dafür 7046. Nur die deutsche Tages-/Nachtfassung nach Zeldas Flucht ist betroffen. NPC-Positionen, frühere Gespräche und Maskenreaktionen bleiben erhalten.','']
 for i in ids:
  raw=m[i]['parts'][2][2];out+=['### '+i,'']
  out+=['> '+re.sub(r'\s+',' ',b.plain(p).replace('{name}','{Spielername}')).strip()+'\n' for p in b.split_pages(raw)[0]]
  controls=[x for x in b.controls(raw) if x.startswith(('TEXTID','FADE'))]
  if controls:out+=['Native Steuerung: '+', '.join(controls),'']
s='\n'.join(out)+'\n';(D/'Amthor_Bean_Darunia_Deku_Dialoge_Aktuell.md').write_text(s);(R/'planning/AMTHOR_BEAN_DARUNIA_DEKU_DIALOGE_AKTUELL.md').write_text(s)
print('Exported',sum(len(x[1]) for x in groups),'actual built messages.')

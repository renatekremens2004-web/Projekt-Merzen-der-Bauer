from pathlib import Path
import sys,csv,hashlib,re,struct,json
W=Path('/workspace/phantom-amthor');R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');sys.path.insert(0,str(R/'tools'))
from verify_story import segment
B=O/'build/pal-1.0';a=(W/'before-deku.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();mp=(B/'oot-pal-1.0.map').read_text();sym={}
for n,k in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):sym.setdefault(k,int(n,16))
names=[r['Name'] for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())]
changed=[]
for i,n in enumerate(names):
 _,_,x=segment(a,i);_,_,y=segment(b,i)
 if x!=y:changed.append(n)
assert set(changed)=={'makerom','dmadata','code','ger_message_data_static'},changed
_,_,x=segment(a,names.index('code'));_,_,y=segment(b,names.index('code'));start=sym['sGerMessageEntryTable']-sym['_codeSegmentStart'];end=sym['sFraMessageEntryTable']-sym['_codeSegmentStart']
assert x[:start]==y[:start] and x[end:]==y[end:]
def texts(rom):
 _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'));p=sym['sNesMessageEntryTable']-sym['_codeSegmentStart'];ids=[]
 while True:
  i=struct.unpack_from('>H',code,p)[0];p+=8
  if i==0xffff:break
  if i!=0xfffc:ids.append(i)
 offsets=[struct.unpack_from('>I',code,start+4*j)[0]&0xffffff for j in range(len(ids))]+[len(data)]
 return {f'{i:04X}':data[offsets[j]:offsets[j+1]].rstrip(b'\0') for j,i in enumerate(ids)}
x=texts(a);y=texts(b);ids=[i for i in x if x[i]!=y[i]];assert set(ids)=={'1091','1029','102A','1045'},ids
# Also validate the last transcription correction against the already tested intermediary.
c=(W/'before-baum-correction.z64').read_bytes();z=texts(c);last=[i for i in z if z[i]!=y[i]];assert last==['1045'],last
for i,n in enumerate(names):
 if n not in ['makerom','dmadata','code','ger_message_data_static']:assert segment(c,i)[2]==segment(b,i)[2],n
_,_,cc=segment(c,names.index('code'));assert cc[:start]==segment(b,names.index('code'))[2][:start] and cc[end:]==segment(b,names.index('code'))[2][end:]
report=dict(before_sha256=hashlib.sha256(a).hexdigest(),after_sha256=hashlib.sha256(b).hexdigest(),changed_segments=changed,changed_messages=ids,other_texts_models_actor_code_and_scenes_byte_identical=True,code_changes_confined_to_german_text_offsets=True,intermediary_sha256=hashlib.sha256(c).hexdigest(),final_correction_changed_messages=last)
(W/'deku-last-delta.json').write_text(json.dumps(report,indent=2)+'\n');print(report)

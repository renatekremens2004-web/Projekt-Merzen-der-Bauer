from pathlib import Path
import struct,json,re
W=Path('/workspace/phantom-amthor')
def setflag(b,base,flag,value):
 o=base+2*(flag>>4);x=struct.unpack_from('>H',b,o)[0];struct.pack_into('>H',b,o,x|(1<<(flag&15)) if value else x&~(1<<(flag&15)))
b=bytearray(Path('/workspace/npc-stimmen/kokiri-after.save').read_bytes())
struct.pack_into('>III',b,0,0xee,1,0xfff2);struct.pack_into('>fffhHhB',b,0x1368,2857.,0.,-594.,0x560b,0xdff,0xee,1);b[0x1409]=1
(W/'deku-death.save').write_bytes(b)
b=bytearray(Path('/workspace/npc-stimmen/kokiri-after.save').read_bytes());struct.pack_into('>III',b,0,0xee,1,0);struct.pack_into('>fffhHhB',b,0x1368,1600.,0.,105.,-16384,0xdff,0xee,0);b[0x1409]=1
for flag in [0x1c,0x40]:setflag(b,0xed4,flag,False)
setflag(b,0xed4,0x04,True)
(W/'mido-after-death.save').write_bytes(b)
p=W/'runner.c';s=p.read_text();s=s.replace('strstr(scenario,"darunia-child")) && mode==0','strstr(scenario,"darunia-child") || strstr(scenario,"mido-after-death")) && mode==0')
p.write_text(s)
print('Added native Deku death cutscene and post-emerald Mido; player/progress preparation only.')

from pathlib import Path
import hashlib,json,re,shutil,zipfile
from PIL import Image

R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/jabba-face');A=Path('/workspace/artifacts');D=Path('/workspace/bean-download-delivery')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
romsha=sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64')
report=json.loads((W/'face-verification.json').read_text());patchcheck=json.loads((W/'patch-verification.json').read_text())
assert romsha==report['rom_sha256']==patchcheck['target_sha256']
V=R/'validation/jabba-face';P=R/'previews/jabba-face';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True)
runtime={}
for topic,limit in [('day',700),('stones-day',700),('night',500),('adult',500)]:
 p=W/f'jabba-{topic}-face-direct-clip-on.log';s=p.read_text()
 assert 'completed: 0' in s and 'RAM=4194304' in s,topic
 assert not any(x in s for x in ['OBJECT_BANK_OVERFLOW','HERO_COLOAD_ERROR','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 assert all(int(x)==0 for x in re.findall(r'HEAP f=\d+ failures=(\d+)',s))
 active=topic!='adult'
 assert bool(re.search(r'JABBA[^\n]*actor=(?!00000000)[0-9a-f]{8}',s))==active
 if active:
  assert all(f'pos={pos} mode=' in s for pos in [17,84,153,222,246]),topic
 runtime[topic]=dict(frames=limit,ram_bytes=4194304,jabba_present=active,native_arena_allocation_failures=0,object_bank_remaining=min(map(int,re.findall(r'remaining=(\d+)',s))),native_arena_largest_free=min(map(int,re.findall(r'largest=(\d+)',s))))
 shutil.copyfile(p,V/p.name)
(V/'runtime-verification.json').write_text(json.dumps(dict(rom_sha256=romsha,probes=runtime),indent=2)+'\n')
for f in ['prepare_runtime.py','runtime_source.py','runner.c','run.py','verification.log','face-verification.log','face-verification.json','check_patch.js','patch-verification.json','reduction.json','package.py']:
 shutil.copyfile(W/f,V/f)
shutil.copyfile(O/'build/pal-1.0/jabba-verification.json',V/'jabba-verification.json')
photos=[]
for src,name,hashval in [
 (D/'Jabba_Beispielbilder/Jabba_Deal.png','Jabba_Gesicht_Vorher.png',report['previous_sha256']),
 (Path('/workspace/bean-rider/screens-jabba-day-face-direct-clip-on/the_legend_of_zelda-005.png'),'Jabba_Gesicht_Nachher.png',romsha),
 (Path('/workspace/bean-rider/screens-jabba-day-face-direct-clip-on/the_legend_of_zelda-000.png'),'Jabba_Ganzkoerper_Nachher.png',romsha),
 (Path('/workspace/bean-rider/screens-jabba-stones-day-face-direct-clip-on/the_legend_of_zelda-004.png'),'Jabba_Nach_drei_Steinen.png',romsha)]:
 shutil.copyfile(src,P/name);assert Image.open(src).tobytes()==Image.open(P/name).tobytes()
 photos.append(dict(file=name,source=str(src),rom_sha256=hashval,unaltered_emulator_image=True))
(P/'Aufnahmen.json').write_text(json.dumps(photos,ensure_ascii=False,indent=2)+'\n')
doc=f'''# Jabba: Gesicht hat Vorrang

Gesamtpatch gegen unveränderte Europa/PAL 1.0. Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`, Ziel-SHA256 `{romsha}`. Alle bisherigen Änderungen enthalten, ROM weiterhin 40 MiB, Laufzeit mit tatsächlichen 4 MiB geprüft.

## Ergebnis

Gesichtsfront mit 1.111 Dreiecken und eigener durchgehender 64×64-CI4-Textur. Zuvor hatte der gesamte Kopf einschließlich Rückseite 511 Dreiecke und teilte sich seine Textur in viele kleine UV-Inseln. Beide Augen behalten ihre eigenen Netze, ursprünglichen Positionen und UVs (95/96 Dreiecke). Neue Aufteilung: Körper/Schwanz 859, Kopfrückseite 130, Gesichtsfront 1.111, Augen 191; insgesamt 2.291 statt 2.391 Dreiecke. Die feiner rekonstruierte Oberfläche (Voxel 0,04) wird mit vorrangigem Erhalt von Lidern, Nase, Lippen und Wangen vereinfacht. Körper und Schwanz erhalten weniger Geometrie.

Diffuse Originalfarben auf die vereinfachten Flächen gebacken. Das Gesicht nutzt eine kontinuierliche frontale Projektion über seine eigene volle Texturfläche, dazu milde lokale Kontaktverschattung aus der dichten Vorlage (Distanz 0,4, Mischung 0,65) für erkennbare Mund-/Lidfalten. Kein fest eingebranntes Richtungslicht; native Szenenbeleuchtung und Nebel bleiben aktiv. Vier nacheinander geladene kleine CI4-Texturen, je 64×64/16 Farben; keine Vergrößerung des Texturpuffers oder der Textur pro Ladevorgang. Uniforme Höhe 78 und zwei eigene starre Animationsgruppen erhalten. Keine vergrößerte Kamera, kein für Bilder versetzter NPC.

Das vollständige Objekt schrumpft von 93.712 auf 82.080 Byte, also 11.632 Byte weniger. Kein neuer Akteurs-/Objekt-Slot. In den geprüften Kinder-Abschnitten bleiben mindestens {min(x['object_bank_remaining']for n,x in runtime.items()if n!='adult'):,} Byte im Objektpuffer frei. Die native Zelda-Arena meldet null fehlgeschlagene Speicherbelegungen; größte freie zusammenhängende Fläche mindestens {min(x['native_arena_largest_free']for x in runtime.values()):,} Byte. Objektpuffer und Arena getrennt gemessen.

## Vergleich und Laufzeit

Gegen den zuletzt gelieferten Jabba-Build sind exakt fünf Segmente verändert: Jabbas eigenes Modellobjekt, dessen Umfang in der nativen Objekttabelle, der unveränderte Display-List-Verweis mit neuer Adresse und der zur Höhe passende Kopfdrehpunkt im Elf_Msg2-Overlay, DMA-Verzeichnis und ROM-Prüfsumme. Alle anderen Modell-/Szenensegmente und sämtliche bisherigen Texte sind bytegleich. Keine Änderungen an Dialoglogik, Größe, Standort, Kollisionsregeln oder Altersprüfung. Huttisch und deutsche Klammerübersetzung bleiben wortgetreu.

Zusätzliche Gesamtprüfung gegen die Fassung vor Jabba: alle 1.510 komprimierten Segmente gegen den unkomprimierten Build, CIC-6105-Prüfsumme, 3.664 native Kernfunktionen/Datensymbole und sämtliche 1.031 eigenen Nachrichten-/Seitenpuffer bestanden. Die neue Nachricht 71B3 behält ihren gültigen Folge-DMA-Zeiger.

Vier abgeschlossene gezielte Laufzeitproben mit dem neuen Modell: Kind tags vor den drei Steinen (700 Frames), Kind tags nach den drei Steinen (700), Kind nachts (500) und Erwachsener als Abwesenheitskontrolle (500). In allen drei Kinder-Proben alle fünf Dialogseiten geöffnet; keine beobachteten Grafikbefehlsfehler, Pufferüberläufe oder fehlgeschlagenen nativen Speicherbelegungen. Tests verwenden normale Eingaben und native Kamera; lokale Start-Fixtures richten nur Spieler/Fortschritt ein. Kein neuer vollständiger Spieldurchlauf oder Hardwaretest in diesem Schritt.

RomPatcher.js mit aktiver Quellvalidierung erzeugt bytegenau diese geprüfte Produktions-ROM. BPS ausschließlich auf die entpackte unveränderte Vanilla-PAL-1.0-ROM anwenden. Alte Emulator-Savestates können noch alte Objekte enthalten; normal gespeicherten Spielstand laden.

## Bilder

Unveränderte echte Emulatorbilder, gleiche Tages-Startposition und normale Gesprächskamera für Vorher/Nachher. `Jabba_Gesicht_Vorher.png` stammt aus der vorherigen ROM `{report['previous_sha256']}`, alle Nachher-Bilder aus der Ziel-ROM oben. Das neue Modell ist in der Spielansicht beurteilt worden, nicht anhand einer höher aufgelösten Blender-Vorschau.

![Vorher](Jabba_Gesicht_Vorher.png)

![Nachher](Jabba_Gesicht_Nachher.png)

## Quellen

Vorbereitete Modell-JSON/PNGs und aktuelle Builder enthalten. Letzter Schritt nach `build_ben_ice.py`: `python3 tools/build_jabba.py <oot>`, anschließend normal bauen/komprimieren. Blender-Neuableitung: `prepare_jabba_lowpoly.py`, `bake_jabba_colors.py`, `export_jabba.py`, jeweils `-- <arbeitsordner>` mit entpacktem Nutzer-Upload unter `input/`. Keine ROMs, Saves, Savestates, RAM-Abzüge, ausführbaren Dateien oder dichte GLB veröffentlicht. Vergleichsskripte benötigen die privaten vorherigen ROM/ELF-Dateien, die nicht mitgeliefert werden.
'''
(R/'TESTING_JABBA_GESICHT.md').write_text(doc.replace('](Jabba_','](previews/jabba-face/Jabba_'))
(P/'Pruefbericht.md').write_text(doc)
heading='# Jabba: mehr Gesicht'
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Jabba_Gesicht.bps';shutil.copyfile(patch,R/'patches'/patch.name)
p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Vorher/Nachher](previews/jabba-face/) · [Prüfung](TESTING_JABBA_GESICHT.md)\n\nGesicht mit eigener Textur und höherer Geometriedichte; Körper einfacher. 2.291 statt 2.391 Dreiecke, Objekt 11.632 Byte kleiner. Alle bisherigen Änderungen enthalten.\n\n'+p.read_text())
p=R/'story/LEITLINIEN.md';s=p.read_text();line='\nJabbas Gesicht hat Vorrang vor Körperdetails: eigene Gesichts-Texturfläche und mehr Geometrie an Lidern, Nase, Mund und Wangen; Bauch/Schwanz dafür vereinfachen, Gesamtbudget erhalten.\n'
if line.strip() not in s:p.write_text(s+line)
archive=A/'Merzen_Jabba_Gesicht_Quellen_Patch.zip'
suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'}
exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in['water-comic-heroes','ben-ice','jabba']and(p.suffix in['.c','.h']or rel.parts[-2:]==('spec','spec'))
  if not p.is_file()or(any(q in exclude for q in rel.parts)and not original)or(p.suffix.lower()not in suffixes and not original):continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='jabba-face':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 assert not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.o','.so','.exe','.st','.mp4','.glb'}for n in z.namelist())
 assert 'tools/originals/jabba/spec/spec'in z.namelist()
instruction=A/'Anleitung_Jabba_Gesicht.txt';instruction.write_text('Kumulativer Gesamtpatch mit Jabbas überarbeitetem Gesicht. Alle bisherigen Änderungen enthalten.\n\nMit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände laden, keine alten Emulator-Savestates. Tatsächliche 4 MiB geprüft.\n')
for p in[patch,archive,instruction]:shutil.copyfile(p,D/p.name)
G=D/'Jabba_Gesicht_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
files=[D/p.name for p in[patch,archive,instruction]]
sums=D/'SHA256SUMS_Jabba_Gesicht.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files));files.append(sums)
p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Neuer Gesamtpatch]('+patch.name+'?raw=true) · [Vorher/Nachher](Jabba_Gesicht_Beispielbilder/Pruefbericht.md) · [Quellen]('+archive.name+'?raw=true)\n\nGesichtsfront mit eigener Textur und 1.111 Dreiecken, einfacherer Körper. Insgesamt 2.291 statt 2.391 Dreiecke, Modellobjekt 11.632 Byte kleiner. Standort und Huttisch mit deutscher Klammerübersetzung erhalten. Alle bisherigen Änderungen enthalten; BPS auf unveränderte Vanilla PAL 1.0 anwenden. Vier gezielte Proben mit 4 MiB bestanden.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=romsha,files=[p.name for p in files],runtime=runtime),indent=2)+'\n')
print('Packaged face revision:',romsha,'source ZIP bytes',archive.stat().st_size)

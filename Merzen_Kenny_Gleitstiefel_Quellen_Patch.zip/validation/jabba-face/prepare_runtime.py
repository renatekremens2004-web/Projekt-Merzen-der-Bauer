from pathlib import Path
import json,struct,shutil
W=Path('/workspace/jabba-face')
s=Path('/workspace/sahur-dance/prepare_runtime.py').read_text().replace('/workspace/sahur-dance','/workspace/jabba-face')
s=s.replace('sprout=actor(0xd3),ruto=actor(0xd2);','sprout=actor(0xd3),ruto=actor(0xd2),jabba=actor_type(0x173,1);')
mp=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0.map').read_text();arena=int(__import__('re').search(r'0x([0-9a-f]+)\s+sZeldaArena\s*$',mp,__import__('re').M)[1],16)
extra='   printf("JABBA f=%u actor=%08x pos=(%.1f %.1f %.1f) floor=%.1f yaw=%x\\n",f,jabba,jabba?rf(jabba+0x24):0,jabba?rf(jabba+0x28):0,jabba?rf(jabba+0x2c):0,jabba?rf(jabba+0x80):0,jabba?DebugMemRead16(jabba+0xb6):0);\n   printf("SETUP f=%u lang=%u age=%u layer=%u night=%u actors=%u overlay=%08x\\n",f,DebugMemRead8(savebase+0x1409),r32(savebase+4),r32(savebase+0x1360),r32(savebase+0x10),DebugMemRead8(play+0x1c2c),r32(overlays+0x173*32+0x10));\n   uint32_t totalFree=0,largestFree=0;for(uint32_t n=r32(ARENA),count=0;n>=0x80000000&&n<0x80400000&&count<1000;n=r32(n+8),count++){if(DebugMemRead16(n+2)){uint32_t size=r32(n+4);totalFree+=size;if(size>largestFree)largestFree=size;}}\n   printf("HEAP f=%u failures=%u free=%u largest=%u\\n",f,DebugMemRead8(ARENA+12),totalFree,largestFree);\n'.replace('ARENA',hex(arena))
s=s.replace('   if(fan&&chum)',extra+'   if(fan&&chum)').replace('obj<0x192','obj<0x193')
(W/'runtime_source.py').write_text(s);exec(compile(s,str(W/'runtime_source.py'),'exec'))
for topic,age,lang,night in [('day',1,1,False),('night',1,1,True),('adult',0,1,False),('english',1,0,False),('stones-day',1,1,False),('stones-night',1,1,True)]:
 fixture(topic,0xcd,0x51,0,(-422.,0.,2322.),-8192,age=age,lang=lang)
 p=W/(topic+'.save');b=bytearray(p.read_bytes());struct.pack_into('>H',b,0x0c,0 if night else 0x8000);struct.pack_into('>I',b,0x10,int(night));
 if age and not topic.startswith('stones'):
  quest=struct.unpack_from('>I',b,0xa4)[0];struct.pack_into('>I',b,0xa4,(quest&~(7<<18))|(1<<18))
 p.write_bytes(b)
r=Path('/workspace/sahur-dance/run.py').read_text().replace('/workspace/sahur-dance','/workspace/jabba-face').replace("'sahur-comic-'","'jabba-'");(W/'run.py').write_text(r)
print('Jabba 4 MiB fixtures: native child day/night, adult and English controls.')

shutil.copyfile('/workspace/transition/chase.save',W/'chase.save')

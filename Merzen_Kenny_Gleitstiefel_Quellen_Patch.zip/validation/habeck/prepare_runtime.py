from pathlib import Path
import re,json,subprocess,struct
W=Path('/workspace/habeck');T=Path('/workspace/transition');O=Path('/workspace/oot-burns-pal')
s=(T/'runner.c').read_text().replace('  if(f%100==0)printf("PROGRESS', '''  if(f%100==0 && strstr(scenario,"rauru")){uint32_t r=actor(0xa6);printf("SAGE f=%u actor=%08x draw=%u alpha=%u light=%x textEnd=%u choice=%u\\n",f,r,r?r32(r+0x188):0,r?r32(r+0x190):0,r32(savebase+0xa4)&0x20,end,DebugMemRead8(m+0xe3e5));}
  if(f%100==0)printf("PROGRESS''')
# native actor id comes from actor table below; stable per build.
s=s.replace('actor(0xa6)','actor(0xa6)') if False else s
# Relocate the native roof owner only in the test, on the normal-dialogue side.
s=s.replace('  if(f==300 && strstr(scenario,"navi"))', '''  if(f==300 && strstr(scenario,"witness")){uint32_t n=actor(0x167);if(n){int yaw=DebugMemRead16(player+0xb6);position(n,rf(player+0x24)+sinf(yaw*3.14159265f/32768)*70,rf(player+0x28),rf(player+0x2c)+cosf(yaw*3.14159265f/32768)*70,yaw+0x7000);printf("ROOF_RELOCATED actor=%08x pos=(%.1f %.1f %.1f)\\n",n,rf(n+0x24),rf(n+0x28),rf(n+0x2c));}}
  if(f==300 && strstr(scenario,"navi"))''')
s=s.replace('  if(f%100==0)printf("PROGRESS', '''  static int heard_return=0;if(id==0x7054)heard_return=1;
  if(strstr(scenario,"rauru") && heard_return && mode==0 && DebugMemRead16(play+0xa4)==0x43 && r32(savebase+4)==0 && (r32(savebase+0xa4)&0x20)){printf("NATIVE_RETURN_COMPLETE f=%u light=20\\n",f);CoreDoCommand(M64CMD_STOP,0,NULL);}
  if(f%100==0)printf("PROGRESS''')
(W/'runner.c').write_text(s)
m=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();d={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',m,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};assert d['gGameStateOverlayTable']-d['gActorOverlayTable']==0x8e10;(W/'symbols.json').write_text(json.dumps(d))
(W/'sword.save').write_bytes((T/'sword-near.save').read_bytes())
for name,age,lang in [('witness-child',1,1),('witness-adult',0,1),('witness-english',1,0)]:
 b=bytearray((T/'market-pre.save').read_bytes());struct.pack_into('>I',b,0,0xdb);struct.pack_into('>I',b,4,age);b[0x1409]=lang
 if age==0:
  x=struct.unpack_from('>H',b,0xedc)[0];struct.pack_into('>H',b,0xedc,x|0x20)
 (W/(name+'.save')).write_bytes(b)
print(d)

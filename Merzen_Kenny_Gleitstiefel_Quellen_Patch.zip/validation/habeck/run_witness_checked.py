from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys,struct
W=Path('/workspace/habeck');b=bytearray((W/'witness-child.save').read_bytes());struct.pack_into('>H',b,0xc,0);(W/'witness-night.save').write_bytes(b)
jobs=[('roof-child-focus-direct-clip-on','witness-child',1300),('roof-adult-focus-direct-clip-on','witness-adult',1000),('roof-english-focus-direct-clip-on','witness-english',1000),('roof-night-focus-direct-clip-on','witness-night',1100)]
# "witness" enables the single native-roof placement; scenario name records conditions.
jobs=[('witness-final-'+a,b,c) for a,b,c in jobs]
def run(j):subprocess.run([sys.executable,str(W/'run.py'),*map(str,j)],check=True)
with ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(run,jobs))

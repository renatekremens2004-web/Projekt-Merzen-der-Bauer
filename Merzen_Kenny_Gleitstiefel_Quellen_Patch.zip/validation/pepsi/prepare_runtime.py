from pathlib import Path
import json,re,struct,subprocess
W=Path('/workspace/pepsiman-water');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
s=Path('/workspace/zoras-erwachsen/runner.c').read_text();a=s.index(' if(play){',s.index('if(f%50==0)findplay();unsigned value=0;'));z=s.index('\n if(buttons)buttons(value);',a)
body=r''' if(play){
  uint32_t m=play+0x20d8;unsigned id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),pos=DebugMemRead16(m+0xe3ce);
  static unsigned oldkey=0,age=0;unsigned key=id*1024+pos;
  if(key!=oldkey || (mode!=7 && mode!=0x34 && mode!=0x35)){oldkey=key;age=0;}else age++;
  if((mode==7 || mode==0x34 || mode==0x35) && age==8){printf("TEXT f=%u id=%04x pos=%u mode=%x len=%u\n",f,id,pos,mode,r32(m+0xe300));printf("PHOTO f=%u kind=text\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f==100){printf("PHOTO f=%u kind=scene\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f>150 && mode==0){
   if(strstr(scenario,"can")) {value=0x20;if(f%60<4)value|=0x800;}
   else if(!strstr(scenario,"walk")){value=0x20;if(f%30<4)value|=0x80;}
  }else if(f>100 && (mode==6 || mode==7 || mode==0x34 || mode==0x35) && age>15 && f%20<4)value=0x80;
  if(strstr(scenario,"walk") && f>150){
   /* Ordinary controller steering through the room-16 key door, with no actor/camera writes. */
   float dx=-1280-rf(player+0x24),dz=-2600-rf(player+0x2c);
   uint32_t cam=r32(play+0x790+DebugMemRead16(play+0x7a0)*4);float fx=rf(cam+0x50)-rf(cam+0x5c),fz=rf(cam+0x58)-rf(cam+0x64),c=sqrtf(fx*fx+fz*fz),d=sqrtf(dx*dx+dz*dz);
   value=0;if(c>1 && d>10){fx/=c;fz/=c;dx/=d;dz/=d;int x=roundf((dx*fz-dz*fx)*60),y=roundf((dx*fx+dz*fz)*60);value=((unsigned)(uint8_t)x<<16)|((unsigned)(uint8_t)y<<24);}if(f%25<4)value|=0x80;
  }
  if(f%100==0){
   uint32_t npc=actor_type(0x173,0x72);int cans=0;
   for(int cat=0;cat<12;cat++)for(uint32_t q=r32(play+0x1c34+cat*8),n=0;q>=0x80000000 && q<0x80400000 && n<100;q=r32(q+0x124),n++)if(DebugMemRead16(q)==0x173 && (DebugMemRead16(q+0x1c)==0x3f73 || DebugMemRead16(q+0x1c)==0x3f74) && r32(q+0x130))cans++;
   printf("PEPSI f=%u npc=%08x npc_pos=(%.1f %.1f %.1f) floor=%.1f cans=%d current=%d previous=%d flags=%08x\n",f,npc,npc?rf(npc+0x24):0,npc?rf(npc+0x28):0,npc?rf(npc+0x2c):0,npc?rf(npc+128):0,cans,(int8_t)DebugMemRead8(play+0x11cbc),(int8_t)DebugMemRead8(play+0x11cd0),r32(play+0x1d28));
   uint32_t ctx=play+0x117a4,begin=r32(ctx),end=r32(ctx+4),last=begin;int entries=DebugMemRead8(ctx+8);
   for(int i=0;i<entries && i<19;i++){uint32_t slot=ctx+12+i*0x44;int obj=(int16_t)DebugMemRead16(slot);if(obj<0)obj=-obj;if(obj>0 && obj<0x192){uint32_t e=r32(slot+4)+r32(OBJECTTABLE+obj*8+4)-r32(OBJECTTABLE+obj*8);if(e>last)last=e;}}
   printf("OBJECT_BANK f=%u entries=%d used=%u capacity=%u remaining=%d\n",f,entries,last-begin,end-begin,(int)(end-last));if(last>end){fprintf(stderr,"OBJECT_BANK_OVERFLOW\n");exit(96);}
   uint32_t rb=r32(play+0x11cbc+0x28),re=r32(play+0x11cbc+0x2c),cur=r32(play+0x11cbc+12),prev=r32(play+0x11cd0+12);
   printf("ROOM_BANK f=%u start=%08x end=%08x current=%08x previous=%08x capacity=%u\n",f,rb,re,cur,prev,re-rb);
   printf("STATE f=%u scene=%x id=%04x msg=%x RAM=%u player=(%.1f %.1f %.1f)\n",f,DebugMemRead16(play+0xa4),id,mode,r32(0x80000318),rf(player+0x24),rf(player+0x28),rf(player+0x2c));
  }
 }
'''
s=s[:a]+body.replace('OBJECTTABLE',hex(syms['gObjectTable']))+s[z:];s=s.replace('0x800ef6a0',hex(syms['gGameStateOverlayTable']));(W/'runner.c').write_text(s)
base=bytearray(Path('/workspace/zoras-erwachsen/boots-water.save').read_bytes())
def fixture(name,room,pos,yaw,level=30,lang=1):
 b=bytearray(base);struct.pack_into('>III',b,0,0x10,0,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,0x10,room);b[0x1409]=lang;b[0x137c:0x1384]=bytes(8);struct.pack_into('>HH',b,0x2e,160,160);off=0xd4+5*0x1c;b[off:off+0x1c]=bytes(0x1c);struct.pack_into('>I',b,off+4,1<<level);b[0x4a:0x54]=b[0x68:0x72];(W/(name+'.save')).write_bytes(b)
for level in [28,29,30]:fixture('man-'+str(level),16,(-1240.,108.,-2790.),16384,level)
fixture('man-english',16,(-1240.,108.,-2790.),16384,lang=0)
for name,room,pos,yaw in [('can7',7,(-3280.,1060.,-4025.),-21300),('can9',9,(-1215.,60.,-1540.),-16384),('can16',16,(-1335.,108.,-2820.),-16384),('crushed-can16',16,(-1325.,108.,-2990.),-16384),('can17',17,(1010.,780.,75.),16384),('can19',19,(1675.,780.,-55.),16384),('walk',16,(-1280.,108.,-2770.),0)]:fixture(name,room,pos,yaw)
# Room-16 door remains native and locked. The test player owns a key.
p=W/'walk.save';b=bytearray(p.read_bytes());b[0xc1]=5;p.write_bytes(b)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)

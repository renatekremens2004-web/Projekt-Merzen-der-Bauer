from pathlib import Path
import struct
W=Path('/workspace/pepsiman-water')
for topic in ['can9','can19']:
 b=bytearray((W/(topic+'.save')).read_bytes());room=9 if topic=='can9'else 19;off=0xd4+5*0x1c+8;struct.pack_into('>I',b,off,struct.unpack_from('>I',b,off)[0]|(1<<room));(W/(topic+'-cleared.save')).write_bytes(b)
b=bytearray((W/'can17.save').read_bytes());off=0xd4+5*0x1c+4;struct.pack_into('>I',b,off,struct.unpack_from('>I',b,off)[0]|(1<<16));(W/'can17-after-meeting.save').write_bytes(b)
for topic,src in [('legacy-wallace','/workspace/wallace/child.save'),('legacy-can-majora','/workspace/forest-temple/corridor.save'),('legacy-can-console','/workspace/n64-gag/near.save')]:
 b=bytearray(Path(src).read_bytes());b[0x4a:0x54]=b[0x68:0x72];(W/(topic+'.save')).write_bytes(b)

b=bytearray((W/'walk.save').read_bytes());b[0xc1]=5;(W/'walk-native.save').write_bytes(b)

b=bytearray(Path('/workspace/forest-temple/corridor-cleared.save').read_bytes());b[0x4a:0x54]=b[0x68:0x72];(W/'legacy-can-majora-cleared.save').write_bytes(b)

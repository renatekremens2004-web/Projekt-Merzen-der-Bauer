from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,hashlib,os,sys
W=Path('/workspace/pepsiman-water');s=json.loads((W/'symbols.json').read_text());rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64')
def run(topic):
 case='pepsi-'+topic+os.environ.get('RUN','-v1')+'-direct-clip-on';limit=int(os.environ.get('FRAME_LIMIT',650));meta=dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),fixture=topic,frame_limit=limit,prepared_player_and_progress_only=True,native_actor_positions=True)
 (W/(case+'.json')).write_text(json.dumps(meta,indent=2)+'\n')
 with(W/(case+'.log')).open('w')as log:subprocess.run([str(W/'runner'),str(rom),case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=min(2,int(os.environ.get('WORKERS',2))))as pool:list(pool.map(run,sys.argv[1:]))

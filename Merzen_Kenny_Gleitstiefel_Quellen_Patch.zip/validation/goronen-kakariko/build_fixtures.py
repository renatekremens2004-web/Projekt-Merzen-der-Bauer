from pathlib import Path
import subprocess,os,shutil,sys
O=Path('/workspace/oot-burns-pal');R=Path('/workspace/bean-rider/fixtures');p=O/'src/overlays/gamestates/ovl_opening/z_opening.c';base=subprocess.check_output(['git','-C',str(O),'show','HEAD:src/overlays/gamestates/ovl_opening/z_opening.c'],text=True)
variants={'gc':('ENTR_GORON_CITY_0','CS_INDEX_NONE',True),'dmt':('ENTR_DEATH_MOUNTAIN_TRAIL_0','CS_INDEX_NONE',True),'kak':('ENTR_KAKARIKO_VILLAGE_0','CS_INDEX_NONE',True),'grave':('ENTR_GRAVEYARD_0','CS_INDEX_NONE',True),'boris':('ENTR_GRAVEYARD_0','CS_INDEX_NONE',True),'wind':('ENTR_WINDMILL_AND_DAMPES_GRAVE_1','CS_INDEX_NONE',True),'navi-pre':('ENTR_HYRULE_FIELD_0','CS_INDEX_NONE',True),'navi-after':('ENTR_HYRULE_FIELD_0','CS_INDEX_NONE',True),'ruby':('ENTR_DEATH_MOUNTAIN_TRAIL_0','CS_INDEX_1',True)}
env=dict(os.environ,LD_LIBRARY_PATH='/workspace/toolchain/root/usr/lib/x86_64-linux-gnu');env['PATH']='/workspace/toolchain/bin:/workspace/toolchain/root/usr/bin:'+env['PATH'];cmd=['make','VERSION=pal-1.0','COMPARE=0','N_THREADS=4','VENV=/workspace/toolchain/venv','-j4']
try:
 for name,(entrance,cs,child) in variants.items():
  if len(sys.argv)>1 and name not in sys.argv[1:]:continue
  s=base.replace('#include "gfx.h"','#include "gfx.h"\n#include "item.h"\n#include "scene.h"\n#include "message.h"')
  a=s.index('{',s.index('void TitleSetup_SetupTitleScreen('));end=s.index('\n}',a)
  body=f'''
    gSaveContext.gameMode = GAMEMODE_NORMAL;
    this->state.running = false;
    gSaveContext.fileNum = 0;
    gSaveContext.save.linkAge = {'LINK_AGE_CHILD' if child else 'LINK_AGE_ADULT'};
    Sram_InitNewSave();
    gSaveContext.language = LANGUAGE_GER;
    gSaveContext.save.entranceIndex = {entrance};
    gSaveContext.save.cutsceneIndex = {cs};
    gSaveContext.sceneLayer = {('GET_CUTSCENE_LAYER('+cs+')') if cs!='CS_INDEX_NONE' else '0'};
    gSaveContext.save.dayTime = CLOCK_TIME({18 if name=='boris' else 12},30);
    gSaveContext.save.info.playerData.playerName[0] = FILENAME_UPPERCASE('L');
    gSaveContext.save.info.playerData.playerName[1] = FILENAME_UPPERCASE('U');
    gSaveContext.save.info.playerData.playerName[2] = FILENAME_UPPERCASE('K');
    gSaveContext.save.info.playerData.playerName[3] = FILENAME_UPPERCASE('A');
    gSaveContext.save.info.playerData.playerName[4] = FILENAME_UPPERCASE('S');
    gSaveContext.save.info.inventory.items[SLOT_OCARINA] = ITEM_OCARINA_FAIRY;
    gSaveContext.save.info.inventory.questItems |= (1 << QUEST_KOKIRI_EMERALD);
    {'SET_INFTABLE(INFTABLE_76);' if name=='mask' else ''}
    {'SET_EVENTCHKINF(EVENTCHKINF_25);' if name=='bowling' else ''}
    {'SET_EVENTCHKINF(EVENTCHKINF_TALON_RETURNED_FROM_CASTLE);' if name=='talon' else ''}
    gSaveContext.save.info.playerData.rupees = 99;
    {'gSaveContext.save.info.playerData.naviTimer = 650;' if name=='navi' else ''}
    {'SET_EVENTCHKINF(EVENTCHKINF_05); SET_EVENTCHKINF(EVENTCHKINF_09); SET_EVENTCHKINF(EVENTCHKINF_RECEIVED_WEIRD_EGG); SET_EVENTCHKINF(EVENTCHKINF_TALON_RETURNED_FROM_CASTLE); SET_EVENTCHKINF(EVENTCHKINF_OBTAINED_ZELDAS_LETTER); gSaveContext.save.info.inventory.questItems |= (1 << QUEST_SONG_SARIA); gSaveContext.save.info.inventory.upgrades |= (1 << 6); SET_EVENTCHKINF(EVENTCHKINF_25); gSaveContext.save.info.playerData.naviTimer = 650;' if name.startswith('navi-') else ''}
    {'gSaveContext.save.info.inventory.questItems |= (1 << QUEST_GORON_RUBY);' if name=='navi-after' else ''}
    {'gSaveContext.chamberCutsceneNum = CHAMBER_CS_SHADOW;' if name=='sage' else ''}
    SET_NEXT_GAMESTATE(&this->state, Play_Init, PlayState);'''
  p.write_text(s[:a+1]+body+s[end:])
  with (R/('build-'+name+'.log')).open('w') as log:subprocess.run(cmd,cwd=O,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  shutil.copyfile(O/'build/pal-1.0/oot-pal-1.0.z64',R/(name+'.z64'));print('Built',name,flush=True)
finally:
 p.write_text(base)
 with (R/'build-normal.log').open('w') as log:subprocess.run(cmd,cwd=O,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Normal opening restored.',flush=True)

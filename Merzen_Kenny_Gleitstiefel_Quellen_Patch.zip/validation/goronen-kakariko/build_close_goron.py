from pathlib import Path
import subprocess,shutil,os
O=Path('/workspace/oot-burns-pal');p=O/'extracted/pal-1.0/assets/scenes/overworld/spot18/spot18_scene_02000084_PlayerEntryList.inc.c';original=p.read_bytes();env=dict(os.environ)
cmd=['make','VERSION=pal-1.0','COMPARE=0','N_THREADS=4','VENV=/workspace/toolchain/venv','-j4']
try:
 s=original.decode();assert s.count('{     56,    600,   1104 }')==1
 p.write_text(s.replace('{     56,    600,   1104 }','{   -454,    116,    800 }'))
 subprocess.run(['python','/workspace/goronen/build_fixtures.py','gc'],check=True,env=env)
 shutil.copyfile('/workspace/bean-rider/fixtures/gc.z64','/workspace/bean-rider/fixtures/gc-atom.z64')
finally:
 p.write_bytes(original)
 subprocess.run(cmd,cwd=O,check=True,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.STDOUT)
# Recreate the ordinary Goron City fixture with its normal spawn.
subprocess.run(['python','/workspace/goronen/build_fixtures.py','gc'],check=True,env=env)

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/okto-water');s=json.loads((W/'symbols.json').read_text())
def run(name):
 case='waterokto-'+name+os.environ.get('WATER_RUN','-rerun')+('-focus-direct-clip-on' if name=='talk' else '-direct-clip-on')
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/'runner'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,'1800','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(name+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:] or ['talk','cleared']))

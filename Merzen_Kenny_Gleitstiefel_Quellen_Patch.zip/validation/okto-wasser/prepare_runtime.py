from pathlib import Path
import struct,re,json
W=Path('/workspace/okto-water');O=Path('/workspace/oot-burns-pal');s=Path('/workspace/friendly-octorok/runner.c').read_text();a=s.index('  if(strstr(scenario,"oktotest") && f>=450');z=s.index('  if(strstr(scenario,"hostile")){static',a);s=s[:a]+s[z:];s=s.replace('oktotest','waterokto');s=s.replace('   printf("OKTO f=', '   printf("BANK f=%u bg=%x y=%.1f z=%.1f floor=%.1f\\n",f,DebugMemRead16(player+0x88),rf(player+0x28),rf(player+0x2c),rf(player+0x80));\n   printf("OKTO f=');(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
for name in ['talk','cleared']:
 b=bytearray(Path('/workspace/friendly-octorok/'+name+'.save').read_bytes());struct.pack_into('>fffhHhB',b,0x1368,140.,-280.,90.,-32768,0xdff,0x28,0);(W/(name+'.save')).write_bytes(b)

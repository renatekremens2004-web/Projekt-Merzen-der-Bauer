#define M64P_CORE_PROTOTYPES
#include "m64p_common.h"
#include "m64p_frontend.h"
#include "m64p_config.h"
#include "m64p_debugger.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <execinfo.h>
static void crash(int n){void* b[40];int c=backtrace(b,40);backtrace_symbols_fd(b,c,2);_exit(128+n);}

static void alarmcb(int sig){(void)sig;uint32_t* c=DebugGetCPUDataPtr(M64P_CPU_REG_COP0);printf("CPU pc=%08x cause=%08x epc=%08x bad=%08x\n",*(uint32_t*)DebugGetCPUDataPtr(M64P_CPU_PC),c[13],c[14],c[8]);for(uint32_t t=DebugMemRead32(0x8000633c),n=0;t>=0x80000000 && t<0x80800000 && n<15;t=DebugMemRead32(t+12),n++){printf("THREAD %08x id=%u state=%u pc=%08x ra=%08x sp=%08x\n",t,DebugMemRead32(t+20),DebugMemRead16(t+16),DebugMemRead32(t+0x11c),DebugMemRead32(t+0x104),DebugMemRead32(t+0xf4));}FILE* d=fopen("/workspace/burns-refine/stalled-ram.bin","wb");for(uint32_t a=0x80000000;a<0x80400000;a+=4){uint32_t v=__builtin_bswap32(DebugMemRead32(a));fwrite(&v,4,1,d);}fclose(d);alarm(15);}
static uint32_t savebase=0x801183d0, overlays=0x800e6480;
static int limit=2400;static int memory_mb=4;
static const char* scenario;
static void (*buttons)(unsigned);
static unsigned actors[32],player;static int count;
static uint32_t r32(uint32_t a){return DebugMemRead32(a);}
static float rf(uint32_t a){uint32_t x=r32(a);float f;memcpy(&f,&x,4);return f;}
static void debugcb(void* ctx,int level,const char* message){if(level<=2)fprintf(stderr,"EMU %d: %s\n",level,message);}
static void scan(void){
 count=0;
 for(uint32_t a=0x80120000;a<0x80400000-0x700;a+=4){
  unsigned id=DebugMemRead16(a);if(id==0 && r32(a+0x138)==overlays && DebugMemRead8(a+2)==2 && r32(a+0x130))player=a;if(id!=0xe8 && id!=0x2a && id!=0x17a && id!=0x52)continue;
  if(r32(a+0x138)!=overlays+id*0x20 || !r32(a+0x130))continue;
  int params=(int16_t)DebugMemRead16(a+0x1c);
  if(id==0xe8 && params>=100)continue;
  if(id==0x2a && (params>>8)!=3 && (params>>8)!=5 && (params>>8)!=7 && (params>>8)!=8 && (params>>8)!=9)continue;
  if(count<32)actors[count++]=a;
 }
}
static uint32_t play;
static uint32_t actor(int id){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130))return a;
 return 0;
}
static void findplay(void){
 if(play && r32(play+0x1c44)==player && player && r32(player+0x130))return;
 play=0;player=0;scan();if(!player)return;
 for(uint32_t a=0x80120000;a<0x80400000;a+=4)if(r32(a)==player && a>0x80121c44 && r32(a-4)==1){uint32_t p=a-0x1c44;if(DebugMemRead16(p+0xa4)<0x70 && r32(p)>=0x80000000){play=p;break;}}
 if(play)printf("PLAY %08x player=%08x scene=%x\n",play,player,DebugMemRead16(play+0xa4));
}
static void wf(uint32_t a,float f){uint32_t v;memcpy(&v,&f,4);DebugMemWrite32(a,v);}
static void position(uint32_t a,float x,float y,float z,int facing){wf(a+0x24,x);wf(a+0x28,y);wf(a+0x2c,z);DebugMemWrite16(a+0xb6,facing);DebugMemWrite16(a+0x32,facing);}
static void onframe(unsigned f){
 alarm(30);
 if(f%50==0)findplay();
 unsigned value=0;
 if(play){
  uint32_t m=play+0x20d8;unsigned id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),pos=DebugMemRead16(m+0xe3ce),end=DebugMemRead8(m+0xe3e4),choice=DebugMemRead8(m+0xe3e5);
  static unsigned key=0,age=0;unsigned k=id*1024+pos;
  if(k!=key || (mode!=7 && mode!=0x34 && mode!=0x35)){key=k;age=0;}else age++;
  if((mode==7 || mode==0x34 || mode==0x35) && age==8){printf("TEXT frame=%u id=%04x pos=%u mode=%x end=%x choice=%u len=%u decoded=%u\n",f,id,pos,mode,end,choice,r32(m+0xe300),DebugMemRead16(m+0xe3d4));CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f%100==0){printf("STATE f=%u scene=%x id=%04x mode=%x end=%x choice=%u pos=%u RUPEES=%d OWN=%04x EQUIP=%04x items=",f,DebugMemRead16(play+0xa4),id,mode,end,choice,pos,(int16_t)DebugMemRead16(savebase+0x34),DebugMemRead16(savebase+0x9c),DebugMemRead16(savebase+0x70));for(int i=0;i<24;i++)printf("%02x",DebugMemRead8(savebase+0x74+i));printf(" player=%.1f,%.1f,%.1f mem=%u\n",rf(player+0x24),rf(player+0x28),rf(player+0x2c),r32(0x80000318));uint32_t sh=actor(0x3d);if(sh)printf("SHOP actor=%08x state=%u cursor=%u xyz=%.1f,%.1f,%.1f\n",sh,DebugMemRead16(sh+0x1ec),DebugMemRead8(sh+0x242),rf(sh+0x24),rf(sh+0x28),rf(sh+0x2c));}
  if(f>300 && (mode==0 || age>20) && f%50<8)value=0x80;
  if(strstr(scenario,"shop")){
   uint32_t sh=actor(0x3d);int state=sh?DebugMemRead16(sh+0x1ec):-1;
   if(state==2 && age>20)value=80u<<16;
   if(state==7 && age>20 && f%50<8)value=0x80;
   if(id==0x89 && mode==0x35 && strstr(scenario,"no")){
    if(choice==0)value=(uint32_t)(uint8_t)-80<<24;else if(age>40 && f%50<8)value=0x80;
   }
  }
  if(strstr(scenario,"mido") && f>=350 && f<365)position(player,1420,0,105,0x4000);
  if(strstr(scenario,"mido-gear") && f==300){DebugMemWrite16(savebase+0x9c,0x1111);DebugMemWrite16(savebase+0x70,0x1111);DebugMemWrite8(savebase+0x68,0x3b);}
  if(strstr(scenario,"tree-no") && mode==0x35 && end==0x10){
   if(choice==0)value=(uint32_t)(uint8_t)-80<<24;else if(age>40 && f%50<8)value=0x80;
  }
  if(strstr(scenario,"poor") && f==250)DebugMemWrite16(savebase+0x34,10);
  if(f%100==0){uint32_t md=actor(0x16d),tr=actor(0x3e);if(md)printf("MIDO actor=%08x text=%04x action=%08x xyz=%.1f,%.1f,%.1f\n",md,DebugMemRead16(md+0x10e),r32(md+0x180),rf(md+0x24),rf(md+0x28),rf(md+0x2c));if(tr)printf("TREE mouth=%.2f event0=%04x\n",rf(tr+0x158),DebugMemRead16(savebase+0xed4));}

  if(strstr(scenario,"wide") && f==250)for(int i=0;i<8;i++)DebugMemWrite8(savebase+0x24+i,'W'-'A'+10);

 }
 if(buttons)buttons(value);
 if(f>=(unsigned)limit)CoreDoCommand(M64CMD_STOP,0,NULL);
}
static void setting(const char* section,const char* key,m64p_type type,const void* value){m64p_handle h;ConfigOpenSection(section,&h);ConfigSetParameter(h,key,type,value);}
static void integer(const char* section,const char* key,int value){setting(section,key,M64TYPE_INT,&value);}
static void boolean(const char* section,const char* key,int value){setting(section,key,M64TYPE_BOOL,&value);}
int main(int argc,char** argv){signal(SIGSEGV,crash);
 if(argc<3)return 2;scenario=argv[2];if(strstr(scenario,"-us")){savebase=0x8011a5d0;overlays=0x800e8530;}if(argc>3)limit=atoi(argv[3]);if(argc>4)memory_mb=atoi(argv[4]);setbuf(stdout,NULL);
 char config[512],shots[512];snprintf(config,sizeof(config),"/workspace/burns-refine/config-%s",scenario);snprintf(shots,sizeof(shots),"/workspace/burns-refine/screens-%s",scenario);mkdir(config,0700);mkdir(shots,0700);
 void* sdl=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_GLOBAL);int(*sdlinit)(unsigned)=dlsym(sdl,"SDL_Init");sdlinit(0x20|0x200);
 int r=CoreStartup(0x020001,config,"/workspace/toolchain/root/usr/share/games/mupen64plus",NULL,debugcb,NULL,NULL);if(r)return r;
 setting("Core","SharedDataPath",M64TYPE_STRING,"/workspace/toolchain/root/usr/share/games/mupen64plus");
 setting("Core","ScreenshotPath",M64TYPE_STRING,shots);setting("Core","SaveStatePath",M64TYPE_STRING,config);setting("Core","SaveSRAMPath",M64TYPE_STRING,config);
 boolean("Core","DisableExtraMem",memory_mb==4);integer("Core","R4300Emulator",memory_mb==4?1:2);boolean("Core","OnScreenDisplay",0);integer("Video-General","ScreenWidth",640);integer("Video-General","ScreenHeight",480);boolean("Video-General","Fullscreen",0);boolean("Video-General","VerticalSync",0);
 FILE* file=fopen(argv[1],"rb");if(!file)return 3;fseek(file,0,SEEK_END);long n=ftell(file);rewind(file);void* rom=malloc(n);if(fread(rom,1,n,file)!=(size_t)n)return 4;fclose(file);r=CoreDoCommand(M64CMD_ROM_OPEN,n,rom);if(r)return r;
 fprintf(stderr,"Core paths: %s | %s | %s\n",ConfigGetUserDataPath(),ConfigGetUserCachePath(),ConfigGetUserConfigPath());
 m64p_rom_settings rs;memset(&rs,0,sizeof(rs));r=CoreDoCommand(M64CMD_ROM_GET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 rs.disableextramem=memory_mb==4;r=CoreDoCommand(M64CMD_ROM_SET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 printf("Requested memory: %d MiB; disableextramem=%d\n",memory_mb,rs.disableextramem);
 const char* paths[]={"/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-rsp-hle.so","/workspace/toolchain/RMG-060/glide-build/plugin/Release/mupen64plus-video-GLideN64.so",NULL,"/workspace/burns-build/test_input.so"};
 void* core=dlopen("libmupen64plus.so.2",RTLD_NOW|RTLD_GLOBAL);int order[]={1,2,3,0};
 for(int k=0;k<4;k++){int i=order[k];if(!paths[i])continue;void* plugin=dlopen(paths[i],RTLD_NOW|RTLD_LOCAL|RTLD_DEEPBIND);if(!plugin){puts(dlerror());return 5;}ptr_PluginStartup startup=dlsym(plugin,"PluginStartup");if((r=startup(core,NULL,debugcb)))return r;if((r=CoreAttachPlugin(i+1,plugin)))return r;if(i==3)buttons=dlsym(plugin,"TestSetButtons");}
 int speed=0;CoreDoCommand(M64CMD_CORE_STATE_SET,M64CORE_SPEED_LIMITER,&speed);CoreDoCommand(M64CMD_SET_FRAME_CALLBACK,0,onframe);signal(SIGALRM,alarmcb);alarm(15);r=CoreDoCommand(M64CMD_EXECUTE,0,NULL);
 printf("SCENARIO %s completed: %d\n",scenario,r);CoreDoCommand(M64CMD_ROM_CLOSE,0,NULL);CoreShutdown();return r;
}

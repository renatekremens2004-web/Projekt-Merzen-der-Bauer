from pathlib import Path
import subprocess,os,shutil,sys
OOT=Path('/workspace/oot-burns-pal'); ROOT=Path('/workspace/burns-story')
opening=OOT/'src/overlays/gamestates/ovl_opening/z_opening.c'
base=subprocess.check_output(['git','-C',str(OOT),'show','HEAD:src/overlays/gamestates/ovl_opening/z_opening.c'],text=True)
variants={'intro':('ENTR_LINKS_HOUSE_0','CS_INDEX_1'),'wake':('ENTR_LINKS_HOUSE_0','CS_INDEX_0'),'forest':('ENTR_KOKIRI_FOREST_0','CS_INDEX_NONE'),'shop':('ENTR_KOKIRI_SHOP_0','CS_INDEX_NONE'),'emerald':('ENTR_KOKIRI_FOREST_0','CS_INDEX_0'),'farewell':('ENTR_KOKIRI_FOREST_0','CS_INDEX_2'),'tree':('ENTR_KOKIRI_FOREST_1','CS_INDEX_NONE')}
env=dict(os.environ);env['PATH']='/workspace/toolchain/bin:/workspace/toolchain/root/usr/bin:'+env['PATH'];env['LD_LIBRARY_PATH']='/workspace/toolchain/root/usr/lib/x86_64-linux-gnu'
cmd=['make','VERSION=pal-1.0','COMPARE=0','N_THREADS=4','-j4']
try:
 for name,(entrance,cs) in variants.items():
  if len(sys.argv)>1 and name not in sys.argv[1:]:continue
  s=base.replace('#include "gfx.h"','#include "gfx.h"\n#include "item.h"\n#include "scene.h"\n#include "message.h"')
  a=s.index('{',s.index('void TitleSetup_SetupTitleScreen('));end=s.index('\n}',a)
  body=f'''
    gSaveContext.gameMode = GAMEMODE_NORMAL;
    this->state.running = false;
    gSaveContext.fileNum = 0;
    gSaveContext.save.linkAge = LINK_AGE_CHILD;
    Sram_InitNewSave();
    gSaveContext.language = LANGUAGE_GER;
    gSaveContext.save.entranceIndex = {entrance};
    gSaveContext.save.cutsceneIndex = {cs};
    gSaveContext.sceneLayer = {('GET_CUTSCENE_LAYER('+cs+')') if cs!='CS_INDEX_NONE' else '0'};
    gSaveContext.save.dayTime = CLOCK_TIME(12,0);
    gSaveContext.save.info.playerData.rupees = 99;
    gSaveContext.save.info.playerData.playerName[0] = FILENAME_UPPERCASE('L');
    gSaveContext.save.info.playerData.playerName[1] = FILENAME_UPPERCASE('U');
    gSaveContext.save.info.playerData.playerName[2] = FILENAME_UPPERCASE('K');
    gSaveContext.save.info.playerData.playerName[3] = FILENAME_UPPERCASE('A');
    gSaveContext.save.info.playerData.playerName[4] = FILENAME_UPPERCASE('S');
    {'SET_INFTABLE(INFTABLE_SARIA_GREETED_LINK);' if name!='intro' else ''}
    {('SET_EVENTCHKINF(EVENTCHKINF_07); SET_EVENTCHKINF(EVENTCHKINF_09); gSaveContext.save.info.inventory.questItems |= (1 << QUEST_KOKIRI_EMERALD);') if name in ['emerald','farewell'] else ''}
    SET_NEXT_GAMESTATE(&this->state, Play_Init, PlayState);'''
  opening.write_text(s[:a+1]+body+s[end:])
  with (ROOT/('build-'+name+'.log')).open('w') as log:subprocess.run(cmd,cwd=OOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  shutil.copyfile(OOT/'build/pal-1.0/oot-pal-1.0.z64',ROOT/(name+'.z64'))
  print('Built fixture:',name,flush=True)
finally:
 opening.write_text(base)
 with (ROOT/'build-normal-restored.log').open('w') as log:subprocess.run(cmd,cwd=OOT,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Normal opening restored.',flush=True)

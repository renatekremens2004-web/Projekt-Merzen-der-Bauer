# Nachweise zum Kokiri-Kapitel

`story-verification.json` stammt vom komprimierten normalen Download-Build. `story-layout.json` dokumentiert die erzeugten Seitenbreiten. Die Emulatorprotokolle zeigen native Text-IDs, Seitenpositionen, Auswahlindizes und Inventar-/Ausrüstungswerte. Sie enthalten keine ausgeschriebenen Dialoge.

Die Testwerkzeuge verwenden die lokalen Pfade dieser Cloud-Umgebung und müssen für eine andere Installation angepaßt werden. `build_fixtures.py` erzeugt ausschließlich Test-ROMs und stellt die originale Startfunktion in einem finally-Block wieder her. Die Fixtures gehören nicht zum Download. `post-gohma-smoke.log` prüft den Anfang der Nach-Gohma-Sequenz; `farewell-final.log` deren letzten Abschnitt bis zur Rückkehr ins Spiel.

Einige frühe Tests erfolgten vor der abschließenden Änderung der kurzen Navi-Begrüßung 0x107D. Diese wurde danach mit 4 MB erneut ausgeführt; die übrigen getesteten Dialogabläufe blieben erhalten. Siehe [TESTING.md](../../TESTING.md) für Voraussetzungen und Grenzen.

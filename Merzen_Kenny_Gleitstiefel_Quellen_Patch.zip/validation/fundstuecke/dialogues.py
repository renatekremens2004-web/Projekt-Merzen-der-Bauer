from pathlib import Path
import json
R=Path('/workspace/Projekt-Merzen-der-Bauer');doc='# Drei neue Begegnungen\n\n'
for key,e in json.loads((R/'story/fundstuecke_de.json').read_text())['messages'].items():doc+=f'## {key}\n\n'+ '\n\n'.join(p.replace('\n',' ')for p in e['pages'])+'\n\n'
(R/'planning/FUNDSTUECKE_DIALOGE.md').write_text(doc)

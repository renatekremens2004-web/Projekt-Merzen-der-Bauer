from pathlib import Path
import subprocess,os,json,re,statistics,hashlib
W=Path('/workspace/drei-fundstuecke');s=(W/'perf_runner.c').read_text()
s=s.replace(' if (snapshotfile && f == 300) {',''' if (snapshotfile && f == 300 && strstr(scenario,"replay")) {
   CoreDoCommand(M64CMD_STATE_LOAD,0,"/workspace/drei-fundstuecke/morpha-controlled.st");play=player=0;return;
 }
 if (snapshotfile && f == 300 && !strstr(scenario,"replay")) {''')
s=s.replace('  if(strstr(scenario,"perf")) {','''  if(strstr(scenario,"perf")) {
   if(f==350 && strstr(scenario,"seed"))CoreDoCommand(M64CMD_STATE_SAVE,1,"/workspace/drei-fundstuecke/morpha-controlled.st");
   if(f==0 && strstr(scenario,"hidden") && flat){DebugMemWrite32(flat+0x134,0);printf("DEBUG_RENDER_ONLY flat draw callback disabled; all actors, AI, physics and RNG preserved\\n");}
''')
s=s.replace('f==150 && strstr(scenario,"two")','f==150 && strstr(scenario,"two") && !strstr(scenario,"replay")')
(W/'controlled_perf_runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'controlled_perf_runner.c'),'-o',str(W/'controlled_perf_runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
syms=json.loads((W/'symbols.json').read_text());rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64');results=[]
for topic,limit in [('two-seed',365),('two-replay-hidden',1000),('two-replay-visible',1000)]:
 case='fund-controlled-perf-'+topic+'-direct-clip-on';log=W/(case+'.log')
 with log.open('w')as f:subprocess.run([str(W/'controlled_perf_runner'),str(rom),case,str(limit),'4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/'flat-battle.save')],env=dict(os.environ,DISPLAY=':99'),stdout=f,stderr=subprocess.STDOUT,check=True,timeout=600)
 text=log.read_text();assert 'RAM=4194304' in text and re.search(r'MORPHA_COUNT f=\d+ count=3',text)
 if 'seed'in topic:continue
 times=sorted(float(x)for x in re.findall(r'TIMING f=\d+ dt_ms=([\d.]+)',text));assert len(times)==600
 r=dict(case=case,log=log.name,samples=len(times),median_ms=statistics.median(times),p95_ms=times[int(.95*(len(times)-1))],same_saved_state=True,only_prop_rendering_toggled=True,rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest());results.append(r);print(json.dumps(r),flush=True);(W/'controlled-performance.json').write_text(json.dumps(results,indent=2)+'\n')
# Every sampled native combat state/position/HP must agree between the two replays.
def states(case):
 text=(W/(case+'.log')).read_text();return [l for l in text.splitlines()if (l.startswith('STATE f=')or l.startswith('MORPHA f=')or l.startswith('MORPHA_COUNT f='))and int(re.search('f=(\\d+)',l)[1])>=100]
assert states(results[0]['case'])==states(results[1]['case']),'Combat trajectories differed'
print('Exact same native combat trajectories confirmed',flush=True)

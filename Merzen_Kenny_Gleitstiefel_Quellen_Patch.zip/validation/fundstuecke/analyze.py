import bpy,json
from pathlib import Path
W=Path('/workspace/drei-fundstuecke');out=[]
for key in ['triangle','pregtest','flatsquid']:
 bpy.ops.wm.read_factory_settings(use_empty=True)
 src=next(p for p in (W/'input'/key/'source').iterdir() if p.suffix in ['.blend','.obj','.fbx'])
 if src.suffix=='.blend':bpy.ops.wm.open_mainfile(filepath=str(src),load_ui=False)
 elif src.suffix=='.obj':bpy.ops.wm.obj_import(filepath=str(src),forward_axis='NEGATIVE_Z',up_axis='Y')
 else:bpy.ops.import_scene.fbx(filepath=str(src))
 r={'key':key,'source':str(src),'meshes':[]}
 for o in bpy.context.scene.objects:
  if o.type!='MESH':continue
  me=o.data;me.calc_loop_triangles();pts=[o.matrix_world@v.co for v in me.vertices]
  r['meshes'].append({'name':o.name,'tris':len(me.loop_triangles),'verts':len(me.vertices),'scale':list(o.scale),'rotation':list(o.rotation_euler),'materials':[m.name for m in me.materials],'world_bounds':[[min(v[i]for v in pts),max(v[i]for v in pts)]for i in range(3)]})
 r['images']=[{'name':i.name,'size':list(i.size),'path':i.filepath,'packed':bool(i.packed_file)}for i in bpy.data.images];out.append(r)
 for m in bpy.data.materials:
  if m.use_nodes:r.setdefault('materials',[]).append({'name':m.name,'nodes':[{'type':n.type,'image':n.image.name if n.type=='TEX_IMAGE' and n.image else None} for n in m.node_tree.nodes]})
 bpy.ops.wm.save_as_mainfile(filepath=str(W/(key+'-import.blend')))
(W/'models.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))

"""Sequential same-fixture emulator comparisons, optional explicit second-phase stress fixture."""
from pathlib import Path
import subprocess,json,os,hashlib,re,statistics,time
W=Path('/workspace/drei-fundstuecke');O=Path('/workspace/oot-burns-pal');meta=json.loads((W/'symbols.json').read_text());baseline_map=(W/'baseline.map').read_text();old={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',baseline_map,re.M)[1],16)for n in meta}
roms={'before':W/'baseline.z64','after':O/'build/pal-1.0/oot-pal-1.0-compressed.z64'};result=[]
# Run comparisons without competing emulator processes.
def others_running():
 for p in Path('/proc').iterdir():
  if not p.name.isdigit():continue
  try:args=(p/'cmdline').read_bytes().split(b'\0')
  except OSError:continue
  if args and args[0]==b'/workspace/drei-fundstuecke/runner':return True
 return False
while others_running():time.sleep(1)
for phase in ['one','two']:
 for version in ['before','after']:
  run=sum(x['phase']==phase and x['version']==version for x in result)+1;case=f'fund-perf-{phase}-{version}-{run}-direct-clip-on';s=old if version=='before'else meta;rom=roms[version];log=W/(case+'.log')
  # The two builds currently share game-state/object-table symbols; assert this for our harness.
  assert all(old[n]==meta[n]for n in ['gGameStateOverlayTable','gObjectTable'])
  with log.open('w')as f:subprocess.run([str(W/'perf_runner'),str(rom),case,'1000','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/'flat-battle.save')],env=dict(os.environ,DISPLAY=':99'),stdout=f,stderr=subprocess.STDOUT,check=True,timeout=900)
  text=log.read_text();times=[float(v)for v in re.findall(r'TIMING f=\d+ dt_ms=([\d.]+)',text)];assert len(times)>500
  times.sort();r=dict(phase=phase,version=version,repetition=run,samples=len(times),median_ms=statistics.median(times),p95_ms=times[int(.95*(len(times)-1))],rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),explicit_hp_stress_fixture=phase=='two',true_4_mib='RAM=4194304'in text,log=log.name);result.append(r);print(json.dumps(r),flush=True);(W/'performance.json').write_text(json.dumps(result,indent=2)+'\n')

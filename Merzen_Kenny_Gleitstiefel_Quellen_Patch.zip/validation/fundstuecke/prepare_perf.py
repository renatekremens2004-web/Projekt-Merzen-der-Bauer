from pathlib import Path
import struct,subprocess
W=Path('/workspace/drei-fundstuecke');s=(W/'runner.c').read_text().replace('#include <math.h>','#include <math.h>\n#include <time.h>')
s=s.replace('static void onframe(unsigned f){','''static void onframe(unsigned f){
 static struct timespec last={0};struct timespec now;clock_gettime(CLOCK_MONOTONIC,&now);
 if(strstr(scenario,"perf") && f>900 && last.tv_sec)printf("TIMING f=%u dt_ms=%.6f\\n",f,(now.tv_sec-last.tv_sec)*1000.+(now.tv_nsec-last.tv_nsec)/1000000.);
 last=now;''')
s=s.replace('if((mode==7 || mode==0x34 || mode==0x35) && age==8)','if(!strstr(scenario,"perf") && (mode==7 || mode==0x34 || mode==0x35) && age==8)').replace('if(f==100){','if(!strstr(scenario,"perf") && f==100){')
s=s.replace('mo=actor(0xc4)','mo=actor_type(0xc4,0)')
needle='  if(f%100==0){'
s=s.replace(needle,'''  if(strstr(scenario,"perf")) {
   value=0;
   if(f==150 && strstr(scenario,"two") && mo){DebugMemWrite8(mo+0xaf,14);DebugMemWrite8(mo+0x145,3);printf("DEBUG_STRESS_SETUP Morpha HP14/hitCount3 set once for native two-tentacle phase\\n");}
   if(f%100==0 && mo){int nmo=0;for(int cat=0;cat<12;cat++)for(uint32_t q=r32(play+0x1c34+cat*8),n=0;q>=0x80000000 && q<0x80400000 && n<100;q=r32(q+0x124),n++)if(DebugMemRead16(q)==0xc4 && r32(q+0x130)){nmo++;printf("MORPHA_PART f=%u actor=%08x params=%d draw=%u state=%d\\n",f,q,(int16_t)DebugMemRead16(q+0x1c),DebugMemRead8(q+0x1c1),(int16_t)DebugMemRead16(q+0x148));}printf("MORPHA_COUNT f=%u count=%u\\n",f,nmo);}
   if(f%100==0 && mo)printf("MORPHA f=%u core=%08x hp=%u state=%d tent1=%08x tent2=%08x playerhp=%u\\n",f,mo,DebugMemRead8(mo+0xaf),(int16_t)DebugMemRead16(mo+0xf50),r32(mo+0x118),r32(mo+0x13c),DebugMemRead16(savebase+0x30));
  }
'''+needle)
(W/'perf_runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'perf_runner.c'),'-o',str(W/'perf_runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)

from pathlib import Path
import re,json,struct,subprocess
W=Path('/workspace/drei-fundstuecke');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
s=Path('/workspace/fanboy-chumchum/runner.c').read_text()
s=s.replace('0x800ef7c0+3*0x30',hex(syms['gGameStateOverlayTable'])+'+3*0x30');s=s.replace('0x800f7488+obj*8',hex(syms['gObjectTable'])+'+obj*8')
a=s.index('  if(f>150 && mode==0');z=s.index('  if(f%100==0){',a)
body=r'''  if(f>150 && mode==0) {
   value=0x20;if(f%50<4)value|=strstr(scenario,"triangle")?0x80:0x800;
  } else if(f>100 && (mode==6 || mode==7 || mode==0x34 || mode==0x35) && age>25 && f%25<4)value=0x80;
  uint32_t ganon=actor(0x17a),mo=actor(0xc4),tri=actor_type(0x173,0x78),test=actor_type(0x173,0x79),flat=actor_type(0x173,0x7a);
  if(f%100==0)printf("GAG f=%u tri=%08x test=%08x flat=%08x triy=%.1f ganon=%08x phase=%d subcam=%d action=%08x hp=%u morpha=%08x hp=%u focus=%08x flags=%08x\n",f,tri,test,flat,tri?rf(tri+0x28):0,ganon,ganon?(int16_t)DebugMemRead16(ganon+0x38c):-1,ganon?(int16_t)DebugMemRead16(ganon+0x38e):-9,ganon?r32(ganon+0x180):0,ganon?DebugMemRead8(ganon+0xaf):0,mo,mo?DebugMemRead8(mo+0xaf):0,r32(player+0x654),r32(player+0x66c));
  if(strstr(scenario,"triangle") && ganon && mode==0){
   unsigned phase=DebugMemRead16(ganon+0x38c);float tx=0,tz=0;int walk=0;
   if(phase==5){tx=-100;tz=-200;walk=1;value=0;}
   else if((phase>=28 || (phase==0 && f>1700)) && (int16_t)DebugMemRead16(ganon+0x38e)==0 && tri){tx=-735;tz=-550;walk=1;}
   if(walk){float dx=tx-rf(player+0x24),dz=tz-rf(player+0x2c),dist=sqrtf(dx*dx+dz*dz);if(dist<=95){value=f%50<4?0x80:0;}if(dist>15){uint32_t cam=r32(play+0x790+DebugMemRead16(play+0x7a0)*4);float fx=rf(cam+0x50)-rf(cam+0x5c),fz=rf(cam+0x58)-rf(cam+0x64),c=sqrtf(fx*fx+fz*fz);if(c>1){fx/=c;fz/=c;dx/=dist;dz/=dist;int x=roundf((dz*fx-dx*fz)*60),y=roundf((dx*fx+dz*fz)*60);value=((unsigned)(uint8_t)x<<16)|((unsigned)(uint8_t)y<<24);}}}
  }
'''
s=s[:a]+body+s[z:];(W/'runner.c').write_text(s)
base=bytearray(Path('/workspace/pepsiman-water/man-30.save').read_bytes())
def fixture(name,ent,scene,room,pos,yaw=0,age=0,lang=1,cleared=False):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,room);b[0x1409]=lang;struct.pack_into('>HH',b,0x2e,160,160);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);b[0x34]=1;struct.pack_into('>H',b,0x0c,0x8000);off=0xd4+scene*0x1c;b[off:off+0x1c]=bytes(0x1c)
 if cleared:struct.pack_into('>I',b,off+8,1<<room) # Morpha room1 clear
 struct.pack_into('>H',b,0x70,0x1122 if not age else 0x1111);b[0x4a:0x54]=b[0x68:0x72];(W/(name+'.save')).write_bytes(b)
fixture('pregtest',0x98,8,6,(-400.,0.,-1060.),-3000,age=1)
fixture('pregtest-cleared',0x98,8,6,(-400.,0.,-1060.),-3000,age=1,cleared=True)
fixture('pregtest-english',0x98,8,6,(-400.,0.,-1060.),-3000,age=1,lang=0)
fixture('flat',0x417,0x16,1,(600.,0.,510.),-10500)
fixture('flat-cleared',0x417,0x16,1,(600.,0.,510.),-10500,cleared=True)
fixture('triangle',0x517,0x4f,0,(970.,1086.,-186.),-16384)
b=bytearray((W/'flat.save').read_bytes());off=0xed4+7*2;struct.pack_into('>H',b,off,struct.unpack_from('>H',b,off)[0]|16);(W/'flat-battle.save').write_bytes(b)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
s=Path('/workspace/fanboy-chumchum/run.py').read_text().replace('/workspace/fanboy-chumchum','/workspace/drei-fundstuecke').replace("case='helden-'","case='fund-' ");(W/'run.py').write_text(s)
# Reconstruct the previous 997-text source from the compiled baseline's unused slots.
import sys
sys.path.insert(0,'/workspace/Projekt-Merzen-der-Bauer/tools');import build_story
current=(O/'extracted/pal-1.0/text/message_data.h').read_text();parsed=build_story.messages(current);orig=build_story.messages((Path('/workspace/Projekt-Merzen-der-Bauer/tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h')).read_text());replacements=[]
for i in ['608A','608B','608C']:
 a,b,_=parsed[i]['parts'][2];replacements.append((a,b,orig[i]['parts'][2][2]))
for a,b,v in sorted(replacements,reverse=True):current=current[:a]+v+current[b:]
(W/'baseline_message_data.h').write_text(current)

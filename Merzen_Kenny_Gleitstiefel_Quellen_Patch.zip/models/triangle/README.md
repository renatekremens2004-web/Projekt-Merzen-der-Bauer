# Triangle Guy im finalen Ganon-Kampf

Vom Benutzer bereitgestellte Vorlage. 13,646 → 904 Dreiecke. Eigene Proportionen; Maße in Spieleinheiten: [131.73, 88.0, 31.36]. Native Beleuchtung, kleine CI4-Texturen, statisch ohne Physik oder Kollision.

Reproduzierbar mit tools/export_fundstuecke.py und tools/build_fundstuecke.py; letzterer folgt auf build_superhelden.py. Neue Nachrichten: 608A–608C.

"""Verify a PAL story build against the unchanged German Burns v2 download.

Run with the OOT virtualenv (crunch64 and ipl3checksum installed) and the
MIPS binutils on PATH, after building and compressing the normal ROM.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import re
import struct
import subprocess
import zipfile

import crunch64
from ipl3checksum import CICKind, calculateChecksum

ROOT = Path(__file__).resolve().parent.parent
DMA = 0x7950
BASELINE_SHA = '67b4068e3afb857907ba9c4a6a08d4363b62a88a275637fc7bfb57697b7728c2'


def segment(rom, index):
    start, end, packed, packed_end = struct.unpack_from('>4I', rom, DMA + 16 * index)
    if packed == 0xFFFFFFFF or start == end:
        return start, end, None
    data = (rom[packed:packed + end - start] if packed_end == 0 else
            crunch64.yaz0.decompress(rom[packed:packed_end]))
    assert len(data) == end - start
    return start, end, data


def check_buffers(build, edits):
    nm = subprocess.check_output(['mips-linux-gnu-nm', '-S',
                                  str(build / 'assets/text/ger_message_data_static.o')], text=True)
    symbols = {m[3].upper(): (int(m[1], 16), int(m[2], 16)) for m in re.finditer(
        r'^([0-9a-f]+) ([0-9a-f]+) R _message_0x([0-9a-fA-F]+)_ger$', nm, re.M)}
    data = (build / 'assets/text/ger_message_data_static.o.bin').read_bytes()
    # Parameters consume bytes too. Counting them is a conservative upper
    # bound for the decoded page. NAME expands to at most eight glyphs.
    args = {5: 1, 6: 1, 7: 2, 12: 1, 14: 1, 17: 2, 18: 2, 19: 1, 20: 1, 21: 3, 30: 1}
    checks = {}
    for ident in edits:
        start, size = symbols[ident]
        raw = data[start:start + size]
        assert len(raw) == size and size < 1280, (ident, size)
        decoded, pages, i = 0, [], 0
        while i < len(raw):
            value = raw[i]
            extra = args.get(value, 0)
            if value in [2, 4, 12]:
                pages.append(decoded)
                decoded = 0
            else:
                decoded += 8 if value == 15 else 5 if value == 31 else 1 + extra
            i += 1 + extra
        assert pages and all(p < 200 for p in pages), (ident, pages)
        checks[ident] = {'raw_bytes': size, 'decoded_page_upper_bound': max(pages), 'pages': len(pages)}
    return {'changed_messages': len(checks), 'raw_buffer_bytes': 1280, 'decoded_buffer_bytes': 200,
            'largest_raw_message_bytes': max(c['raw_bytes'] for c in checks.values()),
            'largest_decoded_page_upper_bound': max(c['decoded_page_upper_bound'] for c in checks.values()),
            'all_within_buffers': True, 'messages': checks}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('oot', type=Path)
    args = ap.parse_args()
    oot = args.oot.resolve()
    build = oot / 'build/pal-1.0'
    plain = (build / 'oot-pal-1.0.z64').read_bytes()
    packed = (build / 'oot-pal-1.0-compressed.z64').read_bytes()
    with zipfile.ZipFile(ROOT / 'downloads/Mr_Burns_Ganondorf_DE_PAL10.zip') as archive:
        baseline = archive.read('Mr_Burns_Ganondorf_DE_PAL10.z64')
    assert hashlib.sha256(baseline).hexdigest() == BASELINE_SHA
    assert len(packed) == 33554432 and packed[0x3E:0x40] == b'P\0'
    crc = struct.unpack_from('>II', packed, 16)
    assert crc == calculateChecksum(packed, CICKind.CIC_X105)
    map_text = (build / 'oot-pal-1.0.map').read_text()

    def symbol(name):
        return int(re.search(r'0x([0-9a-f]+)\s+' + re.escape(name) + r'\b', map_text)[1], 16)

    names = [row['Name'] for row in csv.DictReader((oot / 'baseroms/pal-1.0/segments.csv').open())]
    changes, same, verified = [], [], 0
    code_before = code_after = None
    for index, name in enumerate(names):
        _, _, before = segment(baseline, index)
        start, end, unpacked = segment(packed, index)
        if unpacked is None:
            continue
        expected = plain[start:end]
        if name == 'makerom':
            assert unpacked[:16] == expected[:16] and unpacked[24:] == expected[24:]
        elif name != 'dmadata':
            assert unpacked == expected, ('compressed round trip', name)
            verified += 1
        lo, hi = [symbol('_' + name + 'SegmentRom' + s) for s in ['Start', 'End']]
        after = plain[lo:hi]
        if before == after:
            same.append(name)
        else:
            changes.append({'segment': name, 'before_bytes': len(before), 'after_bytes': len(after)})
        if name == 'code':
            code_before, code_after = before, after
    assert {c['segment'] for c in changes} <= {'makerom', 'dmadata', 'code', 'ger_message_data_static'}, changes
    size = symbol('_codeSegmentTextEnd') - symbol('_codeSegmentTextStart')
    assert code_before[:size] == code_after[:size]
    lo = symbol('sGerMessageEntryTable') - symbol('_codeSegmentTextStart')
    hi = symbol('sFraMessageEntryTable') - symbol('_codeSegmentTextStart')
    differences = [i for i, (a, b) in enumerate(zip(code_before, code_after)) if a != b]
    assert all(lo <= i < hi for i in differences)
    opening = 'src/overlays/gamestates/ovl_opening/z_opening.c'
    assert (oot / opening).read_bytes() == subprocess.check_output(['git', '-C', str(oot), 'show', 'HEAD:' + opening])
    edits = {}
    for chapter in sorted((ROOT / 'story').glob('*.json')):
        for ident, entry in json.loads(chapter.read_text())['messages'].items():
            assert ident not in edits
            edits[ident] = entry
    report = {'version': 'PAL 1.0, German Kokiri chapter', 'rom_bytes': len(packed),
              'rom_sha256': hashlib.sha256(packed).hexdigest(), 'crc': ['%08X' % c for c in crc],
              'compressed_segments_verified': verified, 'native_start_restored': True,
              'baseline_rom_sha256': BASELINE_SHA, 'changed_segments': changes,
              'unchanged_segment_count': len(same), 'unchanged_segments': same,
              'native_machine_code_identical': True, 'native_code_bytes': size,
              'core_changes_only_german_message_pointers': True,
              'text_buffers': check_buffers(build, edits)}
    (build / 'story-verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ['unchanged_segments', 'text_buffers']}, indent=2))
    print('Message buffers:', report['text_buffers']['changed_messages'], 'verified')


if __name__ == '__main__':
    main()

# Robert Habeck als Rauru

Aus dem vom Nutzer gelieferten Archiv rober-h.zip, darin source/habeck.zip/avatar/model.fbx. Keine nachgebaute Ersatzfigur. Die erzeugte Geometrie und Texturquellen sind enthalten; die unbearbeitete FBX bleibt beim Nutzer und ist zur normalen Kompilierung nicht nötig. Herkunft und Prüfsummen: provenance.json.

72835 Quelldreiecke werden auf 2341 reduziert. 24 Hauptgelenke aus dem ursprünglichen 73-Gelenk-Rig, feste eigene Gelenkabstände, dominante Gelenkgewichte und einheitliche Gesamtgröße von 68 Spiel-Einheiten. Finger-/Augen-Hilfsgelenke werden auf die Hand bzw. den Kopf zusammengeführt. Transparente Hornhaut und separate Wimpern entfallen. Augen und Gesicht sind statisch texturiert; die Körperhaltung atmet und nickt leicht. Die drei erzeugten Animationen behalten die nativen 27/30/30 Frames für Stehen, Händeheben und gehaltene Geste. Keine animierte Skalierung oder gestreckten Gliedmaßen.

Die 64×64-CI4-Texturen passen mit je 16 Farben in das N64-Texturgedächtnis. Oberflächennormalen, Szenenlicht, Nebel und Alpha des nativen Darstellungswechsels bleiben aktiv. Die native Figur, Kollisions-/Ereignislogik und Amulettübergabe werden weiter von En_Rl gesteuert. Ursprüngliche Rauru-Assets bleiben im Objekt; En_Rl verweist auf die neuen Ressourcen.

Optional neu exportieren: `blender -b --python tools/export_habeck_fbx.py -- /pfad/avatar/model.fbx`. Danach zuerst `python tools/build_story.py /pfad/oot`, dann `python tools/build_habeck.py /pfad/oot`. Der zweite Schritt ergänzt die drei ausdrücklich vorgesehenen TEXTID-Fortsetzungen und setzt voraus, daß die Texte zuvor frisch erzeugt wurden.

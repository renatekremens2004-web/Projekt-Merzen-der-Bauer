# Tripple T: Shuffling-Version

Quelle: Nutzerarchiv `tung-tung-tung-sahur-shuffling.zip`, darin `source/Shuffling (8).fbx` und `textures/shaded.png`. Keine zusätzliche Autor-/Lizenzangabe behauptet. Die ebenfalls zugängliche Not-AI-Vorlage hat 7.428 Dreiecke, 97 Knochen und eine Standanimation. Die Shuffling-Vorlage wurde wegen des ausdrucksstärkeren Gesichts und des vorhandenen Tanzes gewählt. Das große Roblox-Archiv überschritt die 32-MiB-Transfergrenze und konnte hier nicht untersucht werden.

35.818 auf 2.000 Dreiecke reduziert, 22 eigene Knochen statt 33 einschließlich zusammengefaßter Finger/Endknochen. Höhe weiterhin 60 Spieleinheiten, eigener gleichmäßiger Maßstab. Keine Anpassung an die Proportionen des Deku-Sprosses. Drei kleine CI4-Kacheln, darunter zwei Ausschnitte des Originalatlas für das Gesicht. Native Beleuchtung, Nebel und Tiefentest.

Die vorbereitete Tanzanimation enthält 96 aus den Quellframes 1–145 abgeleitete Posen plus zwölf Übergangsposen zum Schleifenanfang. Nur eigene Gelenkrotationen und die vertikale Wurzelbewegung; Wurzel X/Z bleiben null. Keine Skalierungs-/Scherkanäle. Ein Durchlauf dauert mit PAL 50/3 Aktualisierungen etwa 6,48 Sekunden. Finger und Stab folgen starr den eigenen Händen.

Während des nativen Auftauchens bleibt er in einer ruhigen Einzelpose. Erst bei ruhendem Cutscene-Kontext und beendetem Auftauchzustand wechselt er weich zum Tanz. Die originale Position, Blickrichtung, Auftauchbewegung, Kameras, Dialoge, Medaillon-/Altersbedingungen und Queststeuerung bleiben erhalten. Normale Gespräche sind während des Tanzes möglich. Kindheit und andere Sprachen verwenden weiterhin die native Darstellung beziehungsweise ihre ursprünglichen Spawnregeln.

Neubau: `build_sahur_shuffle.py <oot>` nach dem bisherigen Modell-/Kapitellauf ausführen. Vorbereitetes Modell: `tools/sahur_shuffle_source.json`. Für einen normalen Build ist Blender nicht erforderlich. Die einmalige Blender-Ableitung ist mit dem Exportskript im Prüfmaterial dokumentiert.

Ripped by Hell Inspector and uploaded under the submitter name Hawkodile.
https://www.vg-resource.com/user-39500.html

User-supplied Scooby-Doo: Classic Creep Capers N64 model, OBJ/MTL and textures. Original triangle count and authored pose preserved. Export: tools/export_mystery_inc.py.

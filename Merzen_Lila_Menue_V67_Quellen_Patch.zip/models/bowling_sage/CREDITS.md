# Bowling-Frau als Waldweise

Modell: Treasure Chest Shop Gal aus The Legend of Zelda: Majora’s Mask 3D, von Guy für The Models Resource extrahiert. DAE aus dem vom Nutzer bereitgestellten ZIP; 514 Originalpunkte, 986 Dreiecke vollständig erhalten.

Gestreifte OoT-3D-Hemdtextur: laut beigefügtem Readme von BrittanyOfKoppai extrahiert und im vom Nutzer bereitgestellten Bombchu-Bowling-Lady-Ship-of-Harkinian-Mod verwendet. Die PNG-Texturen wurden aus diesem O2R entnommen. Das Paket nennt im Readme keinen Namen seines Mod-Autors; Originalhinweise stehen unten.

Der O2R-Spielermod wird nicht installiert und Link wird nicht ersetzt. Nur seine Texturen und seine Teilzuordnung dienen als Importhilfe. Das N64-Skelett und seine sieben Stand-, Segens- und Sitzanimationen sind eigene Daten mit den Proportionen der Originalfigur. Modellhöhe 62 Spiel-Einheiten bei gleichmäßiger Skalierung.

Die normalen Salia-Assets bleiben vor dem angehängten neuen Modell erhalten; Einsatz in der deutschen Waldamulett-Enthüllung, in den späteren Siegel-/Prüfungsszenen und in den Credits auf Darunias Schultern. Junge Salia und ihr Brückenauftritt bleiben erhalten.

## Originalhinweise des Bowling-Mods

Bombchu Bowling Lady

This is a simple player mod that replaces Adult Link with the Bombchu Bowling Lady. This is also my first ever mod for Ship of Harkinian. I hope to learn and do more.

**Second Update:** No longer need two different o2r files. There's just one now for the mod. Originally, the textures were a separate o2r file.

**Small Update:** I included a version of my LttP Master Sword if you want to use it. This version excludes all back items from the model.

I also used amiosi's Adult Zelda Voice: Jun Mizusawa mod, which can be found here. https://gamebanana.com/sounds/90359

Credit goes to Guy, over at the Model Resource for ripping the model from Majora's Mask 3D (Both of her OoT models don't have legs). https://models.spriters-resource.com/3ds/thelegendofzeldamajorasmask3d/asset/303256/

Credit also goes to BrittanyOfKoppai on the Model Resource as well. I didn't use the model, but I did take her striped shirt OoT 3D texture to replace her solid pink sure on the MM3D model. https://models.spriters-resource.com/3ds/thelegendofzeldaocarinaoftime3d/asset/330387/

Special thanks to Peyton, and Thebes, their YouTube tutorials were used to make these. Special thanks to the helpful people in the SoH discord server as well for helping me figure out some stuff.

## Originalhinweise des DAE-Rips

Ripped by Guy

Legend of Zelda: Majora's Mask 3DS

For The Models Resource:
http://www.models-resource.com

Please note that some models have been slightly edited to restore them to a usable state (normally the eyes) due to the way they're exported from the ripping program.

Textures may be missing as well (ex: eyes blinking texture), as not all textures are exported from ripping program either.
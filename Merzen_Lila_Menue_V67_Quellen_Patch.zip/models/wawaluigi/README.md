# wawaluigi


Aktuelle Größenkorrektur: Blauer Wawaluigi beim Zelt 100 statt 125 Spieleinheiten, gleichmäßig in allen Achsen verkleinert. 1.251 Dreiecke und dieselben Texturen. Normaler Waluigi und orangefarbener Wawario bleiben unverändert.

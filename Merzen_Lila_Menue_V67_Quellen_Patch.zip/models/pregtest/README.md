# Schwangerschaftstest in der seitlichen Brunnenkammer

Vom Benutzer bereitgestellte Vorlage. 1,110 → 144 Dreiecke. Eigene Proportionen; Maße in Spieleinheiten: [14.0, 0.78, 1.88]. Native Beleuchtung, kleine CI4-Texturen, statisch ohne Physik oder Kollision.

Reproduzierbar mit tools/export_fundstuecke.py und tools/build_fundstuecke.py; letzterer folgt auf build_superhelden.py. Neue Nachrichten: 608A–608C.

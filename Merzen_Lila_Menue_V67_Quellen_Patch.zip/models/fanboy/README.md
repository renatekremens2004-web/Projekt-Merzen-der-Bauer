# Fanboy

Zusätzlicher Wassertempel-Auftritt: Raum 7 bei −3320/1060/−3970 auf einem festen trockenen Boden ohne überdeckende Wasserbox. Neuer Comic-Dialog 7068, nur erwachsen/deutsch. Eigenes Modell, Größe, Textur, vier Matrixgruppen und bisheriger Waldtempel-Auftritt bleiben unverändert. Chum Chum steht in Raum 19; die Räume werden nicht als direktes Paar geladen.

Quelle: Nutzerarchiv `fanboy-and-chum-chum-fanboy.zip`, OBJ plus mitgelieferte Texturen. Die Datei enthält 8.932 Dreiecke einschließlich Baseballkappe, Helm, Fanghandschuh, Schutzausrüstung und alternativen Handstellungen. Verwendet werden Body, Lhand und Rhand1. Nach Reduktion 1.463 Dreiecke, ein 64×64-CI4-Atlas, vier eigene starre Matrixgruppen. 78 Spieleinheiten hoch, einheitlicher Maßstab, Arme offline abgesenkt. Keine fremden Skelettlängen oder Streckung.

Kleine Kopf-/Armbewegung und Gesprächsgeste, native Szenenbeleuchtung/Nebel und Kreisschatten. Steht erwachsen/deutsch in Waldtempel-Raum 3, 1480/463/−1388. Collider nur für Körperkontakt; keine Angriffe oder Trefferannahme. Keine Quest-/Raum-Clear-Wirkung. Raum 5 mit Chum Chum ist nicht direkt verbunden und kann nicht zugleich als Nachbarraum geladen sein. Ein zusätzlicher Actor, keine Objekt-Slots. Die fertige JSON und PNG genügen für den N64-Bau; Blender wird nur zur Neuvorbereitung benötigt.

Keine zusätzliche Autorenschaft oder Lizenz zum gelieferten Fanmodell behauptet. Die Figur stammt aus Fanboy & Chum Chum; der Dialog ist eigene Parodie nach Nutzeridee.

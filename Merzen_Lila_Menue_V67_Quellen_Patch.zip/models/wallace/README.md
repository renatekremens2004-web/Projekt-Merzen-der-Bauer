# Wallace in Dodongos Höhle

Gewählt: Nutzerdatei wallace.zip, source/wallacerig.blend. 4.249 Quelldreiecke, vier kleine Originaltexturen (dreimal 64×64, einmal 16×16). Die alternative Datei wallace (2).zip hat 7.148 Dreiecke und größere Texturen. wallace (1).zip überschritt das Übertragungslimit von 32 MiB und konnte nicht untersucht werden.

N64-Fassung: 1.444 Dreiecke, vier CI4-Texturen, vier eigene starre Teile (Körper, Kopf, linker/rechter Arm). 90 Spieleinheiten hoch. T-Pose-Arme offline abgesenkt; im Spiel nur kleine Rotationen mit festen Achsen, ohne Strecken oder Scherung. Native Szenenbeleuchtung, Schatten und normale Gesprächsfunktion. Kein Aufwand für das mitgelieferte 212-Knochen-Controller-Rig im Spiel.

Die Blender-Datei enthält einen beschädigten optionalen Shape-Key-Verweis. Er wurde beim Offline-Lesen verworfen; Benutzer-Skripte aus der Datei wurden nicht ausgeführt. export_wallace.py dokumentiert die Ableitung; wallace_source.json sowie die vier PNGs genügen für den reproduzierbaren N64-Neubau ohne Blender. Keine neue Lizenzinformation in den Nutzerdateien festgestellt; keine Herkunft oder Autorenschaft ergänzt.

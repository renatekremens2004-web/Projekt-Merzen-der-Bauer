# Wallace in der Erwachsenen-Zeit

Quelle: Nutzerarchiv wallace-freeman-hl2-but-ruined-by-mods.zip, darin source/wallace freeman.zip mit OBJ/MTL und Texturen. Wallace-Figur von Aardman; HEV-Anzug/Gordon-Freeman-Fanmodell aus Half-Life 2. Die Upload-Dateien enthalten keine gesonderte Lizenz-/Autorenangabe zum konkreten Fanmodell; keine zusätzliche Herkunft behauptet.

Aktueller Stand: 90 Spieleinheiten hoch, 2.269 Dreiecke, zwölf eigene starre Matrixgruppen: Körper, Kopf, beide Oberarme, Unterarme, Oberschenkel, Unterschenkel und Füße. Die ursprüngliche Fassung hatte vier Gruppen und Höhe 110; die gleichmäßige Größenkorrektur und die nachträgliche Zuordnung der bestehenden Bein-/Unterarmvertices erhalten Geometrie, Normalen, UVs und Texturen. Fünf CI4-Texturen zu je 64×64 (2.048 Bytes plus Palette). Native Beleuchtung, Nebel und Ein-/Ausblenden.

Im Feuertempel ersetzt Wallace genau den unteren Gefangenen im Felslabyrinth (Raum 5, Parameter 0D83, Zellschalter 3). Daten im Raumsegment, kein zusätzlicher Objekt-Slot. Native Zelle, Schlüsseltruhe, Fluchtpfad und Schalter bleiben erhalten. Das eigene Modell wird zusätzlich an object_du angehängt; Darunia bleibt für die Kindheit und seinen Feuertempelauftritt erhalten. DemoDu verwendet Wallace nur in deutschen Weisenrollen einschließlich Finale und Credits. Keine vergrößerten Actor-Instanzen.

Die Krabbelminen-Frau behält ihren Körper, ihre eigenen Knochenlängen und alle Animationen außerhalb der Sitzsequenz. Ihre drei Credits-Sitzanimationen sind neu angepaßt: Oberschenkel nach vorn, Unterschenkel fast senkrecht, Hände am Kragen, Oberkörper nur zwei Grad zurückgeneigt. Die lokale Sitzwurzel [-100,9400,300] berücksichtigt den nativen Positionsunterschied beider Actors und liegt auf Wallace' Schulter-/Rückenansatz hinter dem Kopf. Eigene Weisen-Nahaufnahmen vermeiden das Abschneiden des größeren Modells. Kamerazeiten und Story-Cues bleiben unverändert.

Neubau benötigt nur wallace_adult_source.json und PNGs. export_wallace_adult.py dokumentiert die einmalige Blender-Ableitung aus dem OBJ. Der Wallace aus Dodongos Höhle als Kind bleibt unverändert.


Aktuelle Größenkorrektur: 90 statt 110 Spieleinheiten, gleichmäßig skaliert. Dieselbe Geometrie und alle Texturen bleiben erhalten; eigener Kopf-/Arm-Drehpunkt ebenfalls skaliert. Gilt für Gefangenen, Feuerweisenrolle, Finale und Credits. Kind-Wallace unverändert.


Laufkorrektur: Eine sechzehn Frames lange, zweigliedrige inverse Kinematik hält die Standsohle am Boden und hebt den Schwungfuß an. Sichtbar nur in Wallaces nativem Fluchtzustand 2; die Knie gleichen auch die kleine Höhenänderung durch das neue Körperwippen im Stand aus. Nur der Gefangene erhält lebhaftere Oberarm-/Ellbogengesten, Kopfnicken, Oberkörperneigung und federnde Schritte. Die Unterarme erben zuerst die vollständige Schulterbewegung, bevor sie sich am eigenen Ellbogen drehen. Zwei zusätzliche Matrizen gegenüber der vorigen Laufkorrektur kosten 128 Bytes je Zeichnung; keine neuen Dreiecke oder Objekt-Slots.

Die Feuerweisenrolle einschließlich Finale und Credits verwendet den Gestenparameter null. Dort bleiben die bisherigen Posen und der auf Wallace abgestimmte Schultersitz erhalten. Die neue Befreiung und die gemeinsamen Credits sind mit tatsächlichen 4 MiB aufgezeichnet. Native Zelle, Schlüsseltruhe, Fluchtpfad, Geschwindigkeit, Zustandszeiten, Kamera, Dialoge und Schalter bleiben unverändert.

Am Ende der bestehenden Buildfolge nacheinander `build_character_sizes.py`, `build_walk_followup.py` und **`build_wallace_cheer.py`** ausführen, jeweils mit dem Decomp-Verzeichnis als Argument. Der letzte Schritt installiert die zwölfteilige Zeichnung und deren zusätzlichen Gestenparameter. Kind-Wallace in Dodongos Höhle bleibt unverändert.

South Park N64, Nutzer-Upload. OBJ unverändert in Dreieckanzahl; gleichmäßig skaliert, native Beleuchtung. Details und Quellennachweis in TESTING_KENNY.md und source/README.txt.

# Phantom-Amthor-Köpfe

## Aktueller Burns-Kopf

**Mr. Burns von chicosantossaraiva**, Creative Commons Attribution 4.0: https://sketchfab.com/3d-models/mr-burns-ee4d3e31c49c4f79a6fc0b281fb4ca6c · https://creativecommons.org/licenses/by/4.0/ . Derselbe vom Nutzer bereitgestellte Charakter wie im bisherigen Merz-Modell; Ableitung aus `tools/adult_bound.json`. Nur Kopf, Hals und ursprüngliche Gesichtsgeometrie werden übernommen. Jackenflächen und der hintere weiße Kragen sind entfernt. Keine Bindung von Schulter-/Jackengeometrie an Phantom Ganons Kopf. Gleichmäßige Größenänderung, native Kopfrotation und Szenenbeleuchtung. 1.779 Dreiecke.

## Aktueller Smithers-Kopf

Vom Nutzer bereitgestelltes Archiv `mr-smithers-animated-simpsons.zip`, darin `Crazy Gesture.fbx`. Nur Kopf oberhalb von Hemd und Fliege; vollständige Gesichtsgeometrie statt vorheriger Polygonreduktion, 783 Dreiecke. Ursprüngliche Augen-/Brillengeometrie erhalten, Augen bis 64×64 CI4; graue Haar-/Brauenfarbe und scharfe eigene Farbpalette. Keine fremden Kampfanimationen.

Die vorbereiteten `phantom_*_source.json` enthalten die fertigen Köpfe. Der normale Bau benötigt nur diese Dateien und Texturen. Erneute Ableitung: zuerst `blender -b -t 2 -P tools/refine_smithers_fbx.py -- /pfad/Crazy_Gesture.fbx /tmp/smithers-head.json`, dann `python tools/refine_phantom_heads.py /tmp/smithers-head.json`. Burns wird dabei aus dem vorhandenen `adult_bound.json` übernommen. Die frühere OBJ-Ableitung in `export_phantom_heads.py` ist nur die historische erste Version und wird für diese Köpfe nicht verwendet.

Der Kopf des zusätzlich hochgeladenen Simpsons-Game-Modells (Rip von Hell Inspector, https://www.vg-resource.com/user-39500.html) wurde in der ersten Phantom-Fassung verwendet und ist jetzt ersetzt. Seine mitgelieferten PNGs bleiben ausschließlich als Quellreferenz vorhanden.

`amthor_bossname_de.png` ist die eigene deutsche Boss-Einblendung. Englisch und Französisch bleiben in der ursprünglichen Textur erhalten. Die Schrift wurde mit Open Sans Condensed Bold erzeugt; zum normalen Neubau genügt die mitgelieferte PNG.

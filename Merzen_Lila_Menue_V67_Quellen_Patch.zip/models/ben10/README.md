# Ben 10

Vom Nutzer bereitgestelltes FusionFall-Modell: 948 Ausgangsvertices, 1.753 Dreiecke. Alle Flächen, eigenen Proportionen und UVs erhalten. Keine gemeinsame Impa-/Zora-/Link-Skelettskalierung. Einheitliche Höhe 70 Spieleinheiten, vier starre eigene Gruppen für minimale Kopf-/Armbewegungen. Das OBJ enthält Glättungsgruppe 1, aber keine Normalen; deshalb flächengewichtete glatte Normalen aus den ursprünglichen indizierten Flächen berechnet. Opaque CI4-Atlas 64×64 mit 16 Farben, Beleuchtung/Nebel/Tiefentest der Szene.

Der Original-MTL-Eintrag `d 0` ist ein Exportartefakt. Im Spiel ist Ben vollständig opak, wie die unveränderte PNG-Vorlage. Freundlicher NPC mit A-Gespräch und OC-Körperkollision; keine Angriffe, Treffer oder Questflag-Änderungen. Nur Erwachsene/deutsche Sprache. JSON direkt baubar, OBJ und PNG für erneute Ableitung enthalten.

Offline: `python3 tools/export_ben10.py models/ben10/source/Ben.obj`; danach als letzten Kapitel-Builder `python3 tools/build_ben_ice.py /pfad/zum/oot` ausführen. Der bestehende Hauptbuild/Kompressor erzeugt die ROM; ROM und Basisspiel werden nicht veröffentlicht.

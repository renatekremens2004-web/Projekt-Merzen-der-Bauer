# yellowguy

Vom Nutzer bereitgestellte Vorlage: yellowguy-dont-hug-me-im-scared.zip / source/YellowGuy.fbx.

1.393 von 17.326 Dreiecken, 68 Spieleinheiten hoch. Vier eigene starre Gruppen; die beiden kleinen Pupillen bleiben durch Originalatlas-Ausschnitte in 64×64 erhalten. Originale Basismesh-Form vor Entfernen der Formschlüssel bewahrt.

Kleine CI4-Texturen, native Szenenbeleuchtung, Nebel und Tiefentest. Normalisierte Exportdaten: `tools/yellowguy_source.json`; diese und die lokalen Texturen reichen für `build_yellow_guy.py` aus. Die Blender-Konverter dienen der erneuten Aufbereitung der Nutzer-Uploads und erwarten den dort angegebenen Arbeitsordner.

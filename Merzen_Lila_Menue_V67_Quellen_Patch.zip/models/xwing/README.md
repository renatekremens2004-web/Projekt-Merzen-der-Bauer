Aktuelle Speicherfassung: Der X-Wing verwendet jetzt 3.006 statt 4.270 Dreiecke bei gleicher Spannweite und Position. Der gemeinsame Tempel-Raumpuffer sinkt dadurch von 331.440 auf etwa 259.680 Byte. Die folgenden Angaben dokumentieren die frühere Erstfassung; aktuelle Prüfung siehe TESTING_KENNY.md.

# LEGO X-Wing im Schattentempel

Geliefertes Modell aus lego-x-wing.zip, Collada mit rekursiven Studio-Teilinstanzen. 400 Teile ohne die winzigen erhabenen LEGO-Schriftzüge, 773930 Dreiecke vor Reduktion. Die Teile werden je Originalfarbe zusammengeführt, die doppelten Innenflächen durch eine kleine Voxel-Oberfläche entfernt und auf 4270 gültige Dreiecke reduziert. Farben und Gesamtproportionen bleiben erhalten. Der mitgelieferte Export besitzt ungebundene optionale Renderer-Namensräume; der Importer ergänzt nur deren XML-Deklarationen und führt keine Archivskripte aus.

Spannweite 24 Spieleinheiten, entsprechend einem LEGO-Spielzeug für Link. Alle Achsen erhalten denselben Faktor, keine Animation oder Verformung. Die Platzierungsmatrix verwendet exakt 1/128. Normalen und Materialfarben wirken mit dem nativen Szenenlicht und Nebel. Keine riesige Raumschiff-Skalierung.

In Raum 0 des Schattentempels, (-1750,-63,-300), als Dekoration ohne Collider. Das vorhandene opaque Raum-Displaylist-Ende verzweigt zur neuen Geometrie; anschließend wird die Matrix zurückgesetzt. Der Rest der alten Raumdatei sowie alle Actor-Listen und die Kollision bleiben erhalten. Andere Räume laden das Modell nicht.

Der Mann im blauen Hemd unten im erwachsenen Kakariko spricht die Nachrichten 507B/507C vor und nach dem Schattenamulett. Seine Position bleibt (-876,0,572). Nach dem gewünschten Satz folgt auf der vorhandenen zweiten Seite ein Bauanleitungs-Gag. Dachbewohner und dessen Dialoge bleiben erhalten.

Der Build benötigt tools/xwing_source.json und tools/build_xwing.py; die DAE ist dafür nicht erforderlich. Optional neu exportieren: blender -b --python tools/export_xwing.py -- /pfad/20210420_212054.dae. Zuerst build_story.py, anschließend build_habeck.py für die vorhandenen Textfortsetzungen, danach build_xwing.py.

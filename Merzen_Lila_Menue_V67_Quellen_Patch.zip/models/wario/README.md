# wario

Vom Nutzer bereitgestellte Vorlage: wario-mario-tennis-2.zip / wario/wario.obj.

460 von 460 Dreiecken, 82 Spieleinheiten hoch. Vollständiges N64-Originalmodell erhalten; nur vier eigene starre Kopf-/Armgruppen ergänzt.

Kleine CI4-Texturen, native Szenenbeleuchtung, Nebel und Tiefentest. Normalisierte Exportdaten: `tools/wario_source.json`; diese und die lokalen Texturen reichen für `build_yellow_guy.py` aus. Die Blender-Konverter dienen der erneuten Aufbereitung der Nutzer-Uploads und erwarten den dort angegebenen Arbeitsordner.

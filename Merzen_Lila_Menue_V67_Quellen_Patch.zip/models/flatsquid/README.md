# Flacher Thaddäus auf Morphas festem Randboden

Vom Benutzer bereitgestellte Vorlage. 152,304 → 1,145 Dreiecke. Eigene Proportionen; Maße in Spieleinheiten: [83.44, 14.87, 105.0]. Native Beleuchtung, kleine CI4-Texturen, statisch ohne Physik oder Kollision.

Reproduzierbar mit tools/export_fundstuecke.py und tools/build_fundstuecke.py; letzterer folgt auf build_superhelden.py. Neue Nachrichten: 608A–608C.

Weitere Reduktion: 1.145 auf 972 Dreiecke, rund 15 Prozent weniger. UVs und ursprünglicher Atlas bleiben erhalten; die Außenmaße ändern sich nur minimal. Weiterhin statisch ohne Physik, Angriffs- oder Körperkollision. Platzierung und Navi-Spruch unverändert, Morphas Akteur und Kampfsteuerung nicht angepaßt. `reduce_flat_squid.py` dokumentiert die einmalige Blender-Reduktion; `build_water_comic_heroes.py` installiert die vorbereitete schlankere Geometrie nach dem bisherigen Buildlauf.

# Waluigi aus Mario Party 3


Geistertempel-Größenkorrektur: alle Achsen, festen Knochenabstände und Animationswurzelpositionen gleichmäßig mit Faktor 0,75 skaliert. Quelle nun Höhe 6.600 Modelleinheiten statt 8.800; in der vergleichbaren nativen Standpose etwa 73,13 statt 97,51 Spieleinheiten (Naboru etwa 65,47). 420 Dreiecke, 14 eigene Knochen und sämtliche Rotationen/Framezahlen erhalten. Das ist der Weisen-Waluigi, nicht der blaue Wawaluigi beim Gerudo-Zelt. Die auf das zuvor größere Modell abgestimmten Nahaufnahmen sind an die neue Größe angepaßt; Cues und Szenendauer bleiben gleich.

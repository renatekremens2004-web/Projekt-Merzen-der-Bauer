# Nintendo 64 in Jabu-Jabu

Das vom Nutzer gelieferte Archiv nintendo-64.zip enthält source/model.zip/model/model.dae. Die vorhandene Ocarina-of-Time-Kassette, Konsole, Controller und Kabel bleiben erhalten. Aus 32062 Quelldreiecken werden 1376; die gelieferten Albedo-Texturen werden für die N64-Hardware auf je 64×64 CI4 mit 16 Farben umgesetzt. Normalen, Szenenlicht und Nebel wirken weiter.

Die Breite des eigentlichen Konsolengehäuses beträgt 1000 Modell-Einheiten bei gleichmäßiger Actor-Skalierung 0.01, also 10 Spieleinheiten. Das entspricht ungefähr einem Viertel der Körperhöhe von Kinder-Link. Controller und Kabel werden mit demselben Faktor skaliert. Es gibt keine animierte oder ungleichmäßige Skalierung. Der Ursprung liegt am Boden unter der Konsole.

Die Figur ist ein nativer Elf_Msg2-Prüfpunkt mit einer zusätzlichen Darstellung. Der Text wird über die vorhandenen Z-Ziel-/C-Up-Regeln geöffnet. world.rot.z=1 erlaubt wiederholtes Untersuchen; der Switch-Wert 3F bedeutet ohne Schalterflag. Das Objekt löst keine Itemvergabe aus und blockiert keine Laufwege. Es ist nur in der deutschen Mod sichtbar.

Die normale Kompilierung verwendet tools/n64_source.json und die enthaltenen Texturen; die ursprüngliche DAE ist dafür nicht nötig. Optional neu exportieren: `blender -b --python tools/export_n64_dae.py -- /pfad/model/model.dae`. Blender 4 besitzt hier keinen Collada-Importer; das Exportskript liest deswegen Positionen, Quellnormalen und UVs direkt aus der gelieferten Collada-Datei. Prüfsummen und Lage stehen in provenance.json.

Vor dem Build: zuerst tools/build_story.py, danach tools/build_habeck.py zum Erhalt der vorherigen Textfortsetzungen, danach tools/build_n64_gag.py auf die vorbereitete PAL-1.0-Dekompilation anwenden. Die beiden letzten Schritte ergänzen bzw. ersetzen nur ihre jeweils dokumentierten Dateien.

Die Modelldaten liegen nur in Jabu-Jabus Raum 3. Der gemeinsam verwendete Elf_Msg2-Overlay enthält nur den kleinen zusätzlichen Initialisierungs-/Darstellungszweig.

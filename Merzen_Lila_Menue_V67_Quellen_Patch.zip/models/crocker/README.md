# Mr. Crocker

Quelle: Nutzerarchiv `nicktoons-unite-ds-denzel-crocker.zip`, DS-OBJ mit Crocker.png (64×64) und Ear.png (16×16). Alle 205 Dreiecke erhalten. Die Vorlage hat kein verwendbares Skelett; zur Vorbereitung wurden vier eigene starre Gruppen für Körper, Kopf und Arme definiert. Arme offline um ihre tatsächlichen Schulterpunkte abgesenkt; im Spiel nur kleine Rotationen mit festen Abständen. 87 Spieleinheiten hoch und einheitlich skaliert. Native Szenenbeleuchtung und Nebel, CI4-Texturen.

Schattentempel-Raum 12 bei −5230/−1363/−1930, am festen äußeren Boden der Totenschädel-Topfkammer, außerhalb der Bombenblumen, Töpfe und Türwege. Wiederholbares normales Gespräch, keine Gegner-/Questfunktion und keine Trefferannahme. Ein Körperkontakt-Zylinder. Keine Objekt-Slots.

Nach drei Crocker-Seiten folgt eine letzte Seite in LIGHTBLUE: „Navi: Ich bin eine Fee, Du anämischer Nerd!“ Alles liegt in einer einzigen normalen Nachricht, 6089. Kein neuer Navi-Auslöser, keine Message_ContinueTextbox-Aufrufe, keine Timer-/Zwischensequenzenänderung und kein zusätzlicher Gesprächszustand. Spieler schaltet mit der üblichen Taste weiter und beendet normal.

Keine neue Autor- oder Lizenzinformation zum konkreten Upload behauptet. Figur aus Cosmo & Wanda / The Fairly OddParents; Dialog ist Parodie nach Nutzeridee.

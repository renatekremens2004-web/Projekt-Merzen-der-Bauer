# Chum Chum

Quelle: Nutzerarchiv `wii-nicktoons-mlb-characters-chum-chum.zip`, OBJ plus Originalatlas. 6.524 Quelldreiecke einschließlich optionaler Baseball-Ausrüstung und alternativer Hände. Verwendet: Body, LHand1, RHand1. Nach Reduktion 1.287 Dreiecke, ein 64×64-CI4-Atlas, vier eigene starre Matrixgruppen. 49 Spieleinheiten hoch, natürliche breite Cartoon-Proportionen, einheitlicher Maßstab. Keine Anpassung an Links oder eines anderen NPCs Knochenlängen.

Waldtempel-Raum 5 bei −1240/383/−1498, erwachsen/deutsch. Ein Körperkontakt-Zylinder, native Gesprächssteuerung und einfache eigene Stand-/Gesprächsbewegung. Keine Angriff-/Trefferkollision oder Questflags. Fanboy steht in Raum 3; die beiden Räume sind nicht benachbart. Keine zusätzlichen Objekt-Slots. Normale Beleuchtung und Nebel bleiben wirksam.

Keine neue Autor-/Lizenzangabe zum Upload behauptet. Dialog ist eigene Parodie nach Nutzeridee.

Aktuelle Augenkorrektur: 1.573 statt 1.287 Dreiecke. Die ursprünglichen 408 Augapfel-/Pupillendreiecke bleiben erhalten; die Pupillen liegen etwa 0,205 Spieleinheiten weiter vorn, damit sie nicht in den vereinfachten Augapfelflächen verschwinden. Größe 49, eigene Körper-/Armdrehpunkte und Originalatlas unverändert. Gilt im Waldtempel und beim zusätzlichen Comic-Auftritt im Wassertempel-Raum 19 auf dem festen Boden bei 1730/780/180. Dort liegt die Wasseroberfläche höchstens bei 765. Fanboy steht in einem anderen, nicht direkt verbundenen Raum. Keine neuen Objekt-Slots; neue Gesprächs-ID 7069 nur für diesen Wasserauftritt. Waldtempel-Dialog unverändert.

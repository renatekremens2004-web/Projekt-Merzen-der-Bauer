Teil des gemeinsamen jungen Schloß-Auftritts. Eigene Größe, native Beleuchtung. Quelle aus Nutzer-Upload; Export mit tools/export_bttf.py. Details in TESTING_BTTF.md.

# Pepsiman und Dosen

Aus den sieben bereitgestellten Pepsi-Archiven wurden die PS1-Figur, die PS1-Dose und die zerdrückte Dose gewählt. Pepsiman: 562 ursprüngliche Dreiecke, 16 starre Teilmeshes. Vollständige Arme offline am eigenen Schultergelenk abgesenkt; keine fremden Skelettlängen. Vier Matrixgruppen: Körper, Kopf, linker/rechter Arm. Im Spiel kleine feste Kopf-/Armrotationen und eine Gesprächsgeste. Einheitsmaßstab, keine Streckung. 95 Spieleinheiten hoch; natürliche Szenenbeleuchtung und Kreisschatten.

Textur: vier getrennt geladene 64×64-CI4-Kacheln aus dem mitgelieferten 256×256-Atlas. UV-Grenzen schneiden Flächen geometrisch unverändert auf, deshalb 707 N64-Dreiecke. Jede Textur beansprucht nur 2 KiB Texelspeicher plus Palette; zwei reservierte Rottöne bewahren das kleine Brustlogo. Die vier Kacheln liegen nicht gleichzeitig im TMEM.

PS1-Dose: von 220 auf 88 Dreiecke reduziert, 64×64-CI4-Etikett und 32×32-CI4-Deckel, 6,5 Spieleinheiten hoch. Das entspricht im Verhältnis zu Link einer kleinen Getränkedose. Zerdrückte Dose: von 608 auf 102 Dreiecke reduziert, 64×64 CI4, Breite 6,5 und Höhe 3,94 Spieleinheiten. Normale eigene Proportionen, Boden bei Y=0. Keine zusätzliche Feuchtigkeitstropfen-Geometrie, PBR-Karten, Physik oder Kollision.

Andere geprüfte Kandidaten: `pepsi-tin-with-texture.zip` insgesamt 6.662 Quelldreiecke; `pepsi.zip` 3.348; `pepsi-can.zip` 99.018 einschließlich vieler einzelner Tropfen. Die DAE-Datei aus `pepsi-can (1).zip` hat 608 Dreiecke; sie wurde als XML untersucht, aber nicht für den N64-Bau verwendet. Die kleineren Vorlagen ersparen unnötigen Umsetzungsaufwand.

Quellen: vom Nutzer bereitgestellte `ps1-pepsiman-the-running-hero-pepsim.zip`, `pepsi-ps1.zip`, `crushed-aluminum-pepsi-can.zip`. Keine zusätzliche Autorenschaft oder Lizenz behauptet. Die Marken/Figuren sind nicht unsere Schöpfung. Eigener Parodiedialog nach Nutzeridee.

Blender-Vorbereitung: `blender -b -t 2 --python tools/export_pepsi.py -- /pfad/zum/Arbeitsverzeichnis` mit den entpackten Uploads unter `input/pepsiman`, `input/ps1`, `input/crushed`. Die fertigen JSONs unter `tools/` und diese PNGs genügen für den normalen Bau ohne Blender. `build_pepsi.py` zuletzt nach den älteren Elf_Msg2-Generatoren ausführen; es bewahrt deren bestehende Funktionen.

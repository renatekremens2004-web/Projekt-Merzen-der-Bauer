"""Give the two eye-bearing UV islands their own TMEM-safe 64x64 tiles."""
from PIL import Image
import copy

def detailed(m,texdir):
 m=copy.deepcopy(m);im=Image.open(texdir/'tung_texture.jpg');w,h=im.size
 for label,rect in [('left',(0,0,.366,.365)),('right',(.354,0,.717,.365))]:
  u0,v0,u1,v1=rect;box=(int(u0*w),int((1-v1)*h),int(u1*w),h);name='face_'+label+'.png';im.crop(box).save(texdir/name);mat=len(m['materials']);m['materials'].append({'name':'face_'+label,'texture':name,'size':[64,64]});count=0
  # Remap only complete triangles inside one original UV island; no geometry splitting.
  for t in m['triangles']:
   if t['material']!=0:continue
   uv=[c['uv'] for c in t['corners']]
   if all(u0<=u<=u1 and v0<=v<=v1 for u,v in uv):
    t['material']=mat;count+=1
    for c in t['corners']:
     u,v=c['uv'];c['uv']=[(u*w-box[0])/(box[2]-box[0]),v*h/(box[3]-box[1])]
  assert count>30,(label,count)
 return m

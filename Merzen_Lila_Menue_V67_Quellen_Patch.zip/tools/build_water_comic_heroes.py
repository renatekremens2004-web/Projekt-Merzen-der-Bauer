"""Add separated dry-room comic encounters; update Chum eyes and one generic future remark."""
from pathlib import Path
import json,sys,re
from n64_model import emit
from build_story import Layout,messages,rewrite,controls,plain
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/water-comic-heroes';D=O/'extracted/pal-1.0/assets/scenes/dungeons/MIZUsin'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
for room,key,prefix,pos,yaw,param in [(7,'fanboy','WaterFanboy',[-3320,1060,-3970],16384,'0x3F75'),(19,'chumchum','WaterChumChum',[1730,780,180],-16384,'0x3F76')]:
 m=json.loads((R/f'tools/{key}_source.json').read_text());g=emit(m,R/'models'/key,prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');inc=key+'_water_model.inc.c';(D/inc).write_text(g)
 p=D/f'MIZUsin_room_{room}.c';p.write_text(original(p)+f'\n#include "{inc}"\n');p=next(D.glob(f'MIZUsin_room_{room}_*ActorEntryList.inc.c'));s=original(p);count=s.count('ACTOR_');s+='    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, { 0, '+str(yaw)+', 0 }, '+param+' }, /* friendly comic encounter on fixed dry floor */\n';p.write_text(s)
 p=D/f'MIZUsin_room_{room}.h';s,n=re.subn(rf'(#define LENGTH_MIZUsin_room_{room}_\w+_ActorEntryList ){count}\b',lambda m:m[1]+str(count+1),original(p));assert n==1;p.write_text(s)
# Only re-emit Chum's existing forest geometry. Fanboy's forest file stays exact.
m=json.loads((R/'tools/chumchum_source.json').read_text());g=emit(m,R/'models/chumchum','ChumChum',True).replace('static Gfx gChumChumBodyDL[]={','Gfx gChumChumDL[]={').replace('gChumChumBodyDL','gChumChumDL');(O/'extracted/pal-1.0/assets/scenes/dungeons/Bmori1/chumchum_model.inc.c').write_text(g)
# Re-emit only the flat model, leaving its placement, Navi trigger and boss alone.
m=json.loads((R/'tools/flatsquid_source.json').read_text());(O/'extracted/pal-1.0/assets/scenes/dungeons/MIZUsin_bs/flatsquid_model.inc.c').write_text(emit(m,R/'models/flatsquid','FlatSquid',False).replace('gFlatSquidBodyDL','gFlatSquidDL'))
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p)
s=s.replace('extern Gfx gFanboyDL[];','extern Gfx gFanboyDL[];\nextern Gfx gWaterFanboyDL[];\nextern Gfx gWaterChumChumDL[];')
old='''        (play->sceneId == SCENE_SHADOW_TEMPLE && actor->room == 12 && actor->params == 0x3F77);'''
new='''        (play->sceneId == SCENE_SHADOW_TEMPLE && actor->room == 12 && actor->params == 0x3F77) ||
        (play->sceneId == SCENE_WATER_TEMPLE &&
            ((actor->room == 7 && actor->params == 0x3F75) || (actor->room == 19 && actor->params == 0x3F76)));'''
assert s.count(old)==1;s=s.replace(old,new)
old='gSPDisplayList(POLY_OPA_DISP++, crocker ? gCrockerDL : fanboy ? gFanboyDL : gChumChumDL);'
new='gSPDisplayList(POLY_OPA_DISP++, crocker ? gCrockerDL : play->sceneId == SCENE_WATER_TEMPLE ? (fanboy ? gWaterFanboyDL : gWaterChumChumDL) : fanboy ? gFanboyDL : gChumChumDL);'
assert s.count(old)==1;s=s.replace(old,new)
old='actor->textId = crocker ? 0x6089 : fanboy ? 0x6087 : 0x6088;'
new='actor->textId = crocker ? 0x6089 : fanboy ? (play->sceneId == SCENE_WATER_TEMPLE ? 0x7068 : 0x6087) : (play->sceneId == SCENE_WATER_TEMPLE ? 0x7069 : 0x6088);'
assert s.count(old)==2;s=s.replace(old,new);p.write_text(s)
entries={
 '5085':{'pages':['Die Krabbelminen-Frau hat Zigaretten direkt neben den Krabbelminen geraucht.','Der ganze Laden ist dadurch komplett explodiert. Dabei ist sie gestorben.']},
 '7068':{'native_template':'0022','pages':["Hey, hey, hey! Chum Chum und ich sind jetzt auch hier! Helden kennen keine nassen Socken!","Ich hab Chum Chum einen Comic gegen die Langeweile mitgegeben. Meinen LIEBLINGSCOMIC!","Den feier ich richtig! Für meinen besten Kumpel gibt's nur das Beste! Der paßt bestimmt gut darauf auf."]},
 '7069':{'native_template':'0022','pages':["Fanboy hat mir seinen Lieblingscomic gegen die Langeweile mitgegeben!","Der ist mir im Wasser abgesoffen.","Jetzt kleben alle Seiten zusammen. Praktisch! So ist man viel schneller mit dem Lesen fertig!"]},
}
for p in (R/'story').glob('*.json'):
 if p.name=='water_comic_sahur_de.json':continue
 d=json.loads(p.read_text());changed=False
 assert not ({'7068','7069'}&set(d['messages'])),('reserved comic slot already used',p)
 for i in entries:
  if i in d['messages']:del d['messages'][i];changed=True
 if changed:p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
(R/'story/water_comic_sahur_de.json').write_text(json.dumps(dict(chapter='Comic im Wassertempel und Krabbelminen-Gerücht',orthography='de-vor-1996',messages=entries),ensure_ascii=False,indent=2)+'\n')
target=O/'extracted/pal-1.0/text/message_data.h';source=target.read_text();current=messages(source);native=messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text());layout=Layout(O);changes=[]
for i,e in entries.items():
 a,b,old=current[i]['parts'][2];template=native[e.get('native_template',i)]['parts'][2][2]
 if 'native_template'in e:assert plain(native[i]['parts'][2][2]).strip().upper()==i
 body,_=rewrite(template,e,layout,i);changes.append((a,b,body))
for a,b,body in sorted(changes,reverse=True):source=source[:a]+body+source[b:]
target.write_text(source)
print('Comic heroes: two separate dry rooms 7/19; original Fanboy unchanged. Chum eyes and smaller flat Squidward updated. Future NPC 5085 replaces generic windmill remark.')

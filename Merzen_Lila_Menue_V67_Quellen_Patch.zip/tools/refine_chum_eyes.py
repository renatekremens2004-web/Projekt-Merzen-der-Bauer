"""Preserve original eye surfaces/pupils and move pupils slightly forward to avoid depth fighting."""
import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent;src=Path(sys.argv[sys.argv.index('--')+1]);components=json.loads(Path(sys.argv[sys.argv.index('--')+2]).read_text())
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.obj_import(filepath=str(src),forward_axis='NEGATIVE_Z',up_axis='Y')
body=bpy.data.objects['Body'];eye_indices=set();pupil_indices=set()
for c in components:
 if c['triangles']==168 and c['bounds'][1][0]>5.7:eye_indices.update(c['indices'])
 if c['triangles']==36 and c['bounds'][1][0]>6:pupil_indices.update(c['indices']);eye_indices.update(c['indices'])
assert len(pupil_indices)==50 and len(eye_indices)==222
originals=[bpy.data.objects[n]for n in ['Body','LHand1','RHand1']];bottom=min(v.co.y for o in originals for v in o.data.vertices);top=max(v.co.y for o in originals for v in o.data.vertices);scale=4900/(top-bottom)
piv=[Vector((0,0,0)),Vector((0,4.9,0)),Vector((-2.4,4.0,0)),Vector((2.4,4.0,0))]
m=dict(bones=[dict(name=n,parent=-1,position=[round(p.x*scale),round((p.y-bottom)*scale),round(p.z*scale)])for n,p in zip(['body','head','left_arm','right_arm'],piv)],materials=[dict(name='chumchum',texture='chumchum.png',size=[64,64])],vertices=[],triangles=[])
parts=[]
for o in originals:
 for eyes in ([False,True]if o.name=='Body'else[False]):
  faces=[p for p in o.data.polygons if (set(p.vertices)<=eye_indices)==eyes]if o.name=='Body'else list(o.data.polygons)
  used=sorted({vi for p in faces for vi in p.vertices});lookup={v:i for i,v in enumerate(used)};coords=[]
  for vi in used:
   p=o.data.vertices[vi].co.copy()
   if o.name=='Body'and vi in pupil_indices:p.z+=.035
   coords.append(p)
  me=bpy.data.meshes.new(o.name+str(eyes));me.from_pydata(coords,[],[[lookup[vi]for vi in p.vertices]for p in faces]);me.update();uv=me.uv_layers.new()
  for p,old in zip(me.polygons,faces):
   for li,oli in zip(p.loop_indices,old.loop_indices):uv.data[li].uv=o.data.uv_layers.active.data[oli].uv
  part=bpy.data.objects.new(me.name,me);bpy.context.collection.objects.link(part);bpy.context.view_layer.objects.active=part
  if not eyes:
   mod=part.modifiers.new('N64 reduction','DECIMATE');mod.ratio=.30;bpy.ops.object.modifier_apply(modifier=mod.name)
  parts.append((part,o.name))
for o,source_name in parts:
 me=o.data;me.calc_loop_triangles();off=len(m['vertices']);rots=[]
 for v in me.vertices:
  p=v.co.copy();head=p.y>4.9;arm=2.7<p.y<4.9 and abs(p.x)>2.5;b=1 if head else(2 if p.x<0 else 3)if arm or source_name.lower().startswith(('lhand','rhand'))else 0;rot=Matrix.Identity(3)
  if b>=2:rot=Matrix.Rotation(math.radians(28*(1 if b==2 else -1)),3,'Z');p=piv[b]+rot@(p-piv[b])
  p.y-=bottom;m['vertices'].append(dict(bone=b,position=[round(x*scale)for x in p]));rots.append(rot)
 for t in me.loop_triangles:
  m['triangles'].append(dict(material=0,corners=[dict(vertex=off+vi,uv=list(me.uv_layers.active.data[li].uv),normal=[round(x*127)for x in(rots[vi]@me.vertices[vi].normal).normalized()])for vi,li in zip(t.vertices,t.loops)]))
m.update(height_game_units=49,source='User Chum Chum OBJ',native_lighting=True,eye_refinement=dict(preserved_original_eye_triangles=408,pupil_forward_source_units=.035,body_proportions_unchanged=True))
(R/'tools/chumchum_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');print('CHUM_EYES',len(m['triangles']),'triangles; 408 original eye triangles, pupils forward',.035*scale/100)

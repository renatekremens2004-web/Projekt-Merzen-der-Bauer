"""Names only. Preserve all other text, pages and control macros for later user-written dialogue."""
from pathlib import Path
import json,re,sys
import build_story as b
R=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();p=O/'extracted/pal-1.0/text/message_data.h';source=p.read_text();parsed=b.messages(source);edits=[];report={}
authored={i for path in (R.parent/'story').glob('*.json') for i in json.loads(path.read_text())['messages']}
for ident,msg in parsed.items():
 if ident in authored:continue
 a,z,old=msg['parts'][2];changes={}
 def replace(m):
  value=json.loads(m[0]);new=re.sub(r'\bNab(?:oo|o)ru\b','Waluigi',value)
  if ident in {'003D','4013','403E','4043','4045','4059'}:new=re.sub(r'\bRuto\b','Thaddäus',new)
  if new!=value:changes[value]=new;return json.dumps(new,ensure_ascii=False)
  return m[0]
 new=re.sub(b.STRING,replace,old)
 if new!=old:
  assert b.tokens(new)==b.tokens(old),ident
  edits.append((a,z,new));report[ident]=changes
for a,z,new in sorted(edits,reverse=True):source=source[:a]+new+source[z:]
p.write_text(source)
if report:
 manifest=R.parent/'planning/SAGE_NAMEN.json'
 previous=json.loads(manifest.read_text()) if manifest.exists() else {}
 previous.update(report);manifest.write_text(json.dumps(previous,ensure_ascii=False,indent=2)+'\n')
print('Names only:',len(report),'German messages; all native controls and other words unchanged.')

"""Last cumulative builder, after build_gerudo_dialogue.py/build_twinrova_title.py.
Native fishing gameplay, two age-specific owner meshes, two room-local NPCs.
"""
from pathlib import Path
import sys,json,re
from n64_model import emit
from build_story import messages,Layout,rewrite,add_private_message
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/doof-guests'
def original(p):
 q=B/p.relative_to(O);q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists():q.write_bytes(p.read_bytes())
 return q.read_text()
def write(p,s):
 if not p.exists()or p.read_text()!=s:p.write_text(s)
def pivots(m):return '{'+','.join('{'+','.join(map(str,b['position']))+'}'for b in m['bones'])+'}'
keys=['doof','doofevil','shrek','monopoly'];models={k:json.loads((R/'tools'/f'{k}_source.json').read_text())for k in keys};table='';spec=''
for i,key in enumerate(keys):
 prefix=key.title();D=O/f'extracted/pal-1.0/assets/objects/object_{key}';D.mkdir(parents=True,exist_ok=True);code='#include "ultra64.h"\n#include "animation.h"\n#include "gfx.h"\n'+emit(models[key],R/'models'/key,prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');write(D/f'object_{key}.c',code)
 table+=f'\n/* 0x{0x19D+i:04X} */ DEFINE_OBJECT(object_{key}, OBJECT_{key.upper()})\n';spec+=f'\nbeginseg\n    name "object_{key}"\n    compress\n    romalign 0x1000\n    include "$(BUILD_DIR)/assets/objects/object_{key}/object_{key}.o"\n    number 6\nendseg\n'
for rel,extra in [('include/tables/object_table.h',table),('spec/spec',spec)]:p=O/rel;write(p,original(p)+extra)
# Room headers use the native age selection: just one extra owner object at once.
D=O/'extracted/pal-1.0/assets/scenes/misc/turibori';p=D/'turibori_room_0.inc.c';cmd=original(p);assert 'ALTERNATE_HEADER'not in cmd;write(p,'    SCENE_CMD_ALTERNATE_HEADER_LIST(turibori_room_0_DoofHeaders),\n'+cmd)
p=D/'turibori_room_0_03000040_ObjectList.inc.c';objects=original(p);count=objects.count('OBJECT_');write(p,objects+'    OBJECT_DOOF, /* child-only owner */\n')
p=D/'turibori_room_0.h';h=original(p);h,n=re.subn(r'(#define LENGTH_turibori_room_0_03000040_ObjectList )'+str(count)+r'\b',lambda m:m[1]+str(count+1),h);assert n==1;write(p,h)
p=D/'turibori_room_0.c';s=original(p);needle='SceneCmd turibori_room_0[]';assert s.count(needle)==1;s=s.replace(needle,'extern SceneCmd turibori_room_0_DoofAdult[];\nextern SceneCmd* turibori_room_0_DoofHeaders[];\nextern s16 turibori_room_0_DoofAdultObjects['+str(count+1)+'];\n\n'+needle);s+='\ns16 turibori_room_0_DoofAdultObjects[]={\n'+objects+'    OBJECT_DOOFEVIL,\n};\nSceneCmd* turibori_room_0_DoofHeaders[]={NULL,turibori_room_0_DoofAdult,NULL};\nSceneCmd turibori_room_0_DoofAdult[]={\n'+cmd.replace('turibori_room_0_03000040_ObjectList','turibori_room_0_DoofAdultObjects')+'};\n';write(p,s)
# One native Fishing owner; only rendering and dialogue-ID presentation change.
p=O/'src/overlays/actors/ovl_Fishing/z_fishing.c';s=original(p);mapping=json.loads((R/'tools/doof_guest_text_map.json').read_text());ids=[k for k in mapping if len(k)==4];helper=(R/'tools/doof_owner.inc.c').read_text().replace('DOOF_NATIVE_IDS',','.join('0x'+k for k in ids)).replace('DOOF_ADULT_IDS',','.join('0x'+mapping[k]for k in ids)).replace('DOOF_PIVOTS',','.join(pivots(models[k])for k in keys[:2]));needle='static u16 sPondOwnerTextIds[]';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
needle='            if (Actor_TalkOfferAccepted(&this->actor, play)) {';a=s.index('void Fishing_HandleOwnerDialog(');b=s.index('static s16 sOwnerBlinkIndex[]',a);body=s[a:b];assert body.count(needle)==1;body=body.replace(needle,'            this->actor.textId = Fishing_DoofText(this->actor.textId);\n\n'+needle)
body=re.sub(r'Message_ContinueTextbox\(play, ([^;\n]+)\);',lambda m:'Message_ContinueTextbox(play, Fishing_DoofText('+m[1]+'));',body);body=re.sub(r'Message_StartTextbox\(play, (.*?), (.*?)\);',lambda m:'Message_StartTextbox(play, Fishing_DoofText('+m[1]+'), '+m[2]+');',body);s=s[:a]+body+s[b:]
a=s.index('void Fishing_UpdateOwner(Actor* thisx, PlayState* play2) {');b=s.index('s32 Fishing_OwnerOverrideLimbDraw(',a);body=s[a:b];body=re.sub(r'Message_StartTextbox\(play, (.*?), (.*?)\);',lambda m:'Message_StartTextbox(play, Fishing_DoofText('+m[1]+'), '+m[2]+');',body);s=s[:a]+body+s[b:]
needle='        sOwnerTheftTimer = 20;\n        play->specialEffects = sEffects;';assert s.count(needle)==1;s=s.replace(needle,'        /* Doof has his own hair. The old hat sidequest is unused in German. */\n        if (gSaveContext.language == LANGUAGE_GER) sOwnerHair = FS_OWNER_HAIR;\n\n'+needle)
old='''        SkelAnime_DrawFlexOpa(play, this->skelAnime.skeleton, this->skelAnime.jointTable, this->skelAnime.dListCount,
                              Fishing_OwnerOverrideLimbDraw, Fishing_OwnerPostLimbDraw, this);''';assert s.count(old)==1;s=s.replace(old,'''        if (!Fishing_DrawDoof(this, play)) {
'''+old+'''
        }''');write(p,s)
# Add the two guest actors only to their actual age/room header.
def append(sc,typ,room,afrag,ofrag,pos,param,obj):
 D=O/f'extracted/pal-1.0/assets/scenes/{typ}/{sc}';p=D/f'{sc}_room_{room}.h';h=original(p)
 for fragment,kind,value in [(afrag,'ActorEntryList','    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, { 0, -16384, 0 }, 0x%04X }, /* room-local guest */\n'%param),(ofrag,'ObjectList','    '+obj+',\n')]:
  p=next(D.glob(f'{sc}_room_{room}_*{fragment}_{kind}.inc.c'));s=original(p);n=s.count('ACTOR_'if kind=='ActorEntryList'else'OBJECT_');write(p,s+value);macro='LENGTH_'+p.name.replace('.inc.c','');h,k=re.subn(rf'(#define {macro} ){n}\b',lambda m:m[1]+str(n+1),h);assert k==1,p
 write(D/f'{sc}_room_{room}.h',h)
append('spot10','overworld',3,'03000070','03000058',[1700,0,-850],0x3F90,'OBJECT_SHREK')
append('ganontika','dungeons',1,'0300004C','03000040',[540,150,20],0x3F91,'OBJECT_MONOPOLY')
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);helper=(R/'tools/doof_guests_actor.inc.c').read_text().replace('DOOF_GUEST_PIVOTS',','.join(pivots(models[k])for k in keys[2:]));needle='/* Small own-proportion guests,';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
for action in ['Init','Update']:
 needle=f'void ElfMsg2_{action}(Actor* thisx, PlayState* play) {{\n    ElfMsg2* this = (ElfMsg2*)thisx;';assert s.count(needle)==1;s=s.replace(needle,needle+f'\n    if (ElfMsg2_IsDoofGuest(thisx, play)) {{\n        ElfMsg2_{action}DoofGuest(this, play);\n        return;\n    }}')
needle='if (ElfMsg2_IsDesertGuest(thisx, play) ||';assert s.count(needle)==1;s=s.replace(needle,'if (ElfMsg2_IsDoofGuest(thisx, play) || ElfMsg2_IsDesertGuest(thisx, play) ||');write(p,s)
# Refresh only the new chapter against its immutable cumulative baseline.
p=O/'extracted/pal-1.0/text/message_data.h';s=original(p);native=messages(s);entries=json.loads((R/'story/doof_guests_de.json').read_text())['messages'];layout=Layout(O)
for ident,e in entries.items():
 if e.get('new_message'):s=add_private_message(s,ident,e)
parsed=messages(s);replacement=[]
for ident,e in entries.items():
 a,b,body=parsed[ident]['parts'][2]
 if e.get('new_message'):body=native[e['native_template']]['parts'][2][2]
 new,_=rewrite(body,e,layout,ident);replacement.append((a,b,new))
for a,b,new in sorted(replacement,reverse=True):s=s[:a]+new+s[b:]
write(p,s);print('Doof: one age-specific mesh at a time, native fishing actor/rules; Shrek child Lost Woods 3; Monopoly adult castle hall 1. Updated',len(entries),'German texts.')

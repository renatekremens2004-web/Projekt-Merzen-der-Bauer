"""Verify supplied shuffling Sahur, eye correction, comic encounters and lighter flat Squidward."""
from pathlib import Path
import csv,hashlib,json,re,struct,subprocess,sys
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages,controls,tokens
from verify_bowling_sage_revision import function_bodies
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0'
base=W/'baseline';a=(base/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();unpacked=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='06d6ffb42399caf326d8d984abbc7d6d7ac6f5c1c9544d66ac9c734aa8a2350f'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
old=messages((base/'extracted/pal-1.0/text/message_data.h').read_text());new=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());changed=[]
for i in old:
 assert old[i]['header']==new[i]['header']
 for lang in [0,1,3]:assert old[i]['parts'][lang][2]==new[i]['parts'][lang][2],(i,lang)
 x=old[i]['parts'][2][2];y=new[i]['parts'][2][2]
 assert controls(x)==controls(y),(i,'native control')
 if 'NAME'in tokens(x):assert 'NAME'in tokens(y)
 if x!=y:changed.append(i)
assert set(changed)=={'403D','4040','706A','706B'}
edits={i:e for p in(R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};assert len(edits)==1030
buffers=check_buffers(B,edits)
# Only the existing superhero helper and two Zora guards change.
originals=R/'tools/originals/ben-ice'
for f,expected in [('src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c',{'ElfMsg2_IsSuperhero','ElfMsg2_DrawSuperhero','ElfMsg2_InitSuperhero','ElfMsg2_UpdateSuperhero'}),('src/overlays/actors/ovl_En_Zo/z_en_zo.c',{'EnZo_GetTextId','EnZo_Init'})]:
 oldf=function_bodies((originals/f).read_text());newf=function_bodies((O/f).read_text());assert set(newf)-set(oldf)==({'ElfMsg2_ChumFrozen'}if 'Elf_Msg2'in f else set());assert not(set(oldf)-set(newf));assert {k for k in oldf if oldf[k]!=newf[k]}==expected
for sc,room in [('men',3),('ice_doukutu',9),('ice_doukutu',11)]:
 D=O/f'extracted/pal-1.0/assets/scenes/dungeons/{sc}'
 p=next(p for p in D.glob(f'{sc}_room_{room}_0*ActorEntryList.inc.c')if 'AltHeaders'not in p.name);before=(originals/p.relative_to(O)).read_text();after=p.read_text();assert after.startswith(before)and after[len(before):].count('ACTOR_')==1
 # All alternate room setup files remain byte exact.
 for q in D.glob(f'{sc}_room_{room}_*AltHeaders*'):
  saved=originals/q.relative_to(O)
  assert not saved.exists(),('unexpected alternate mutation',q)
for key,n in [('ben10',1753),('fanboy',1463),('chumchum',1573),('flatsquid',972),('sahur_shuffle',2000)]:
 m=json.loads((R/f'tools/{key}_source.json').read_text());assert len(m['triangles'])==n
# New heroes have no attack/hit collision, floor positions are immutable and
# room-specific. No new actor updates, script flag writes or time controls.
source=(O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c').read_text();assert 'actor->home.rot.z == 1 && !Flags_GetSwitch(play, 0x1E)'in source and '0, 0, 0, 0x011E'in source
assert 'actor->params == 0x3F80'in source and 's32 ben = actor->params == 0x3F80'in source
D=O/'extracted/pal-1.0/assets/scenes/dungeons/ice_doukutu'
text=(D/'ice_doukutu_room_10.inc.c').read_text();before=(originals/'extracted/pal-1.0/assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10.inc.c').read_text();assert text.replace('    SCENE_CMD_ACTOR_LIST(1, gIceChumSpawns),\n','')==before
def syms(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
ns=syms(B/'oot-pal-1.0.map');rels={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 q=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if q:section=q[1];rels.setdefault(section,{})
 q=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if q and section:rels[section][int(q[1],16)]=(q[2],q[3])
names=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];intentional={'makerom','dmadata','ger_message_data_static','ovl_Elf_Msg2','ovl_En_Zo','men_room_3','ice_doukutu_room_9','ice_doukutu_room_10','ice_doukutu_room_11'};same=[];changedseg=[];linked=[];verified=0
for i,name in enumerate(names):
 _,_,x=segment(a,i);start,end,y=segment(b,i)
 if y is None:continue
 if name=='makerom':assert y[:16]==unpacked[start:start+16]and y[24:]==unpacked[start+24:end]
 elif name!='dmadata':assert y==unpacked[start:end],name;verified+=1
 if x==y:same.append(name);continue
 if name in intentional:changedseg.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)));continue
 assert len(x)==len(y),(name,'unexpected size')
 base=ns['_'+name+'SegmentStart'];words=sorted({j//4*4 for j,(p,q)in enumerate(zip(x,y))if p!=q})
 for off in words:
  addr=base+off
  if name=='code'and ns['sGerMessageEntryTable']<=addr<ns['sFraMessageEntryTable']:continue
  rel=rels.get(name,{}).get(addr);assert rel,(name,hex(addr),'unexplained difference');kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[off:off+2]==y[off:off+2]
  elif kind=='R_MIPS_26':assert x[off]>>2==y[off]>>2
  else:assert kind=='R_MIPS_32',kind
 linked.append(dict(segment=name,changed_words=len(words)))
assert verified==1509
assert all(name not in {x['segment']for x in changedseg+linked}for name in names if name.startswith('object_'))
assert all(name not in {x['segment']for x in changedseg}for name in names if name.startswith('ovl_Boss_'))
assert all(n in same for n in ['ovl_Obj_Dekujr','spot04_scene','spot04_room_1','MIZUsin_room_7','MIZUsin_room_19','Bmori1_room_3','Bmori1_room_5','MIZUsin_bs_room_1'])
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,changed_messages=changed,text_buffers=buffers,models=dict(ben_triangles=1753,fanboy_triangles=1463,chumchum_triangles=1573,ben_height=70,ice_hero_rooms=[9,10],native_zora_room=11),original_objects_bosses_sahur_and_other_models_unchanged=True,intentional_segments=changedseg,relocation_only_segments=linked,identical_segments=same)
(B/'ben-ice-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments;',len(edits),'custom messages. Only four new conversations; all existing models, bosses, native Ice puzzles and Sahur retained.')

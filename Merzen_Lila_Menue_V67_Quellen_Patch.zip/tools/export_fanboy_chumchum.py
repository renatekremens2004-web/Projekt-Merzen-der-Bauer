"""Offline reduction of supplied OBJ superheroes; native proportions, no baseball props or duplicate hands."""
import bpy,json,math,sys,shutil
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1])
for key,height,ratio,keep in [('fanboy',78,.23,['Body','Lhand','Rhand1']),('chumchum',49,.30,['Body','LHand1','RHand1'])]:
 D=R/'models'/key;D.mkdir(parents=True,exist_ok=True);src=next((W/'input'/key).rglob('*.obj'));bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.obj_import(filepath=str(src),forward_axis='NEGATIVE_Z',up_axis='Y')
 objects=[o for o in bpy.context.scene.objects if o.type=='MESH'and o.name in keep];assert len(objects)==3
 bottom=min(v.co.y for o in objects for v in o.data.vertices);top=max(v.co.y for o in objects for v in o.data.vertices);scale=height*100/(top-bottom)
 piv=[Vector((0,0,0)),Vector((0,8.7,0)),Vector((-1.65,7.1,0)),Vector((1.65,7.1,0))]if key=='fanboy'else[Vector((0,0,0)),Vector((0,4.9,0)),Vector((-2.4,4.0,0)),Vector((2.4,4.0,0))]
 m={'bones':[{'name':n,'parent':-1,'position':[round(p.x*scale),round((p.y-bottom)*scale),round(p.z*scale)]}for n,p in zip(['body','head','left_arm','right_arm'],piv)],'materials':[{'name':key,'texture':key+'.png','size':[64,64]}],'vertices':[],'triangles':[]}
 tex=next((W/'input'/key/'textures').glob('*128x128*.png'));shutil.copyfile(tex,D/(key+'.png'))
 for o in objects:
  bpy.context.view_layer.objects.active=o;mod=o.modifiers.new('N64 silhouette reduction','DECIMATE');mod.ratio=ratio;bpy.ops.object.modifier_apply(modifier=mod.name);me=o.data;me.calc_loop_triangles();offset=len(m['vertices']);rots=[]
  for v in me.vertices:
   p=v.co.copy();head=p.y>(8.9 if key=='fanboy'else 4.9);arm=(5.7<p.y<8.2 and abs(p.x)>1.65)if key=='fanboy'else(2.7<p.y<4.9 and abs(p.x)>2.5)
   b=1 if head else(2 if p.x<0 else 3)if arm or o.name.lower().startswith(('lhand','rhand'))else 0;rot=Matrix.Identity(3)
   if b>=2:rot=Matrix.Rotation(math.radians((48 if key=='fanboy'else 28)*(1 if b==2 else -1)),3,'Z');p=piv[b]+rot@(p-piv[b])
   p.y-=bottom;m['vertices'].append({'bone':b,'position':[round(x*scale)for x in p]});rots.append(rot)
  for t in me.loop_triangles:
   cs=[]
   for vi,li in zip(t.vertices,t.loops):
    normal=(rots[vi]@me.vertices[vi].normal).normalized();cs.append({'vertex':offset+vi,'uv':list(me.uv_layers.active.data[li].uv),'normal':[round(x*127)for x in normal]})
   m['triangles'].append({'material':0,'corners':cs})
 m.update(height_game_units=height,source=str(src.relative_to(W)),removed=['baseball cap','baseball helmet','baseball glove','alternate hands'],native_lighting=True)
 (R/f'tools/{key}_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');print(key,len(m['triangles']),'triangles; height',height)

"""Surface-union the dense supplied LEGO model, retaining source material colors.

Blender: -b --python tools/export_naboo.py -- <workdir>
Input: <workdir>/input/LEGO_NabooShip/LEGO_NabooShip.obj and .mtl.
"""
import bpy,bmesh,json,sys,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
from mathutils.bvhtree import BVHTree
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);src=next((W/'input').rglob('*.obj'))
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.obj_import(filepath=str(src))
objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];vertices=[];faces=[];face_materials=[];materials=[];mat_index={};kd={};name=None
for line in src.with_suffix('.mtl').read_text().splitlines():
 s=line.split()
 if s and s[0]=='newmtl':name=s[1]
 if s and s[0]=='Kd':kd[name]=list(map(float,s[1:4]))+[1.0]
for o in objects:
 me=o.data;me.calc_loop_triangles();off=len(vertices);vertices.extend([o.matrix_world@v.co for v in me.vertices])
 for mat in me.materials:
  if mat.name not in mat_index:mat_index[mat.name]=len(materials);materials.append(dict(name=mat.name,rgba=kd[mat.name]))
 for t in me.loop_triangles:faces.append([off+i for i in t.vertices]);face_materials.append(mat_index[me.materials[t.material_index].name])
tree=BVHTree.FromPolygons(vertices,faces,all_triangles=True)
for o in objects:bpy.data.objects.remove(o,do_unlink=True)
mesh=bpy.data.meshes.new('Naboo exterior');mesh.from_pydata(vertices,[],faces);mesh.update();o=bpy.data.objects.new('LEGO Naboo Starfighter',mesh);bpy.context.collection.objects.link(o);bpy.context.view_layer.objects.active=o;o.select_set(True)
# One exterior surface, rather than retaining hidden brick interiors and
# separately overlapping color shells. Materials are sampled after reduction.
remesh=o.modifiers.new('Exterior brick union','REMESH');remesh.mode='VOXEL';remesh.voxel_size=4.0;remesh.use_smooth_shade=False;remesh.use_remove_disconnected=False;bpy.ops.object.modifier_apply(modifier=remesh.name)
o.data.calc_loop_triangles();surface=len(o.data.loop_triangles);mod=o.modifiers.new('N64 toy silhouette','DECIMATE');mod.ratio=min(1,1400/surface);mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name)
me=o.data;me.calc_loop_triangles();T=Matrix(((1,0,0),(0,0,1),(0,-1,0)));points=[T@v.co for v in me.vertices];lo=Vector(tuple(min(p[i]for p in points)for i in range(3)));hi=Vector(tuple(max(p[i]for p in points)for i in range(3)));center=(lo+hi)/2;center.y=lo.y;scale=3600/(hi.z-lo.z)
out=dict(model='User-supplied LEGO Naboo Starfighter',source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),materials=materials,vertices=[[round(x*scale)for x in(p-center)]for p in points],triangles=[],game_dimensions=[round((hi[i]-lo[i])*scale/100,2)for i in range(3)],uniform_scale=True,native_lighting=True,source_triangles=len(faces),surface_triangles=surface)
for t in me.loop_triangles:
 p=sum((me.vertices[i].co for i in t.vertices),Vector())/3;near=tree.find_nearest(p);mat=face_materials[near[2]];normal=[round(x*127)for x in(T@t.normal).normalized()]
 a,b,c=[Vector(out['vertices'][i])for i in t.vertices]
 if (b-a).cross(c-a).length<.1:continue
 out['triangles'].append(dict(material=mat,corners=[dict(vertex=i,normal=normal)for i in t.vertices]))
assert len(out['triangles'])<=1600,len(out['triangles'])
(R/'tools/naboo_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n');report={k:out[k]for k in['source_sha256','source_triangles','surface_triangles','game_dimensions']};report['triangles']=len(out['triangles']);(W/'model.json').write_text(json.dumps(report,indent=2)+'\n');print(report,flush=True)
for mat in materials:
 m=bpy.data.materials.new(mat['name']);m.diffuse_color=mat['rgba'];me.materials.append(m)
for p in me.polygons:
 near=tree.find_nearest(p.center);p.material_index=face_materials[near[2]]
bpy.ops.wm.save_as_mainfile(filepath=str(W/'naboo-reduced.blend'))

"""Give selected German shopkeepers and shooting galleries private greetings.

Existing prices, menus and game states remain native. Apply after the other
source generators; all edits are idempotent and restore-normalizable.
"""
from pathlib import Path
import sys

SHOP = '''    /* Dedicated German voices; all prices and purchasing remain native. */
    if (gSaveContext.language == LANGUAGE_GER) {
        switch (this->actor.params) {
            case OSSAN_TYPE_BAZAAR:
                return 0x0127;
            case OSSAN_TYPE_MARKET_POTION:
            case OSSAN_TYPE_KAKARIKO_POTION:
                return 0x012C;
            case OSSAN_TYPE_BOMBCHUS:
                return 0x012D;
        }
    }

'''
SHOOT = '''/* Keep shared minigame messages unchanged outside German shooting galleries. */
static s16 EnSyatekiMan_GetPrivateText(s16 index) {
    s16 textId = sTextIds[index];

    if (gSaveContext.language == LANGUAGE_GER && textId == 0x2B) {
        return 0x012E;
    }
    return textId;
}

'''

def apply(oot):
    p=oot/'src/overlays/actors/ovl_En_Ossan/z_en_ossan.c';s=p.read_text()
    if SHOP not in s:
        marker='    return 0x9E;\n';assert s.count(marker)==1;s=s.replace(marker,SHOP+marker);p.write_text(s)
    p=oot/'src/overlays/actors/ovl_En_Syateki_Man/z_en_syateki_man.c';s=p.read_text()
    if SHOOT not in s:
        marker='void EnSyatekiMan_Init(Actor* thisx, PlayState* play) {';assert s.count(marker)==1
        s=s.replace(marker,SHOOT+marker);assert s.count('this->actor.textId = sTextIds[this->textIdx];')==3
        s=s.replace('this->actor.textId = sTextIds[this->textIdx];','this->actor.textId = EnSyatekiMan_GetPrivateText(this->textIdx);');p.write_text(s)
    print('Private German greetings: Bazaar 0127; potions 012C; Bombchus 012D; shooting intro 012E.')

if __name__=='__main__':apply(Path(sys.argv[1]).resolve())

"""Import supplied FusionFall Ben OBJ at native proportions; retain all 1753 faces."""
from pathlib import Path
import json,math,sys,shutil
R=Path(__file__).resolve().parent.parent;src=Path(sys.argv[1]);D=R/'models/ben10';D.mkdir(exist_ok=True,parents=True)
v=[];uv=[];normal=[];faces=[]
for l in src.read_text().splitlines():
 p=l.split()
 if not p:continue
 if p[0]=='v':v.append(list(map(float,p[1:])))
 elif p[0]=='vt':uv.append(list(map(float,p[1:])))
 elif p[0]=='vn':normal.append(list(map(float,p[1:])))
 elif p[0]=='f':faces.append([list(map(int,c.split('/')))for c in p[1:]])
bottom=min(p[1]for p in v);scale=7000/(max(p[1]for p in v)-bottom)
pivots=[[0,0,0],[0,3.5,0],[-.58,3.12,0],[.48,3.12,0]]
m=dict(bones=[dict(name=n,parent=-1,position=[round(p[0]*scale),round((p[1]-bottom)*scale),round(p[2]*scale)])for n,p in zip(['body','head','left_arm','right_arm'],pivots)],materials=[dict(name='ben10',texture='Body.png',size=[64,64])],vertices=[],triangles=[],height_game_units=70,source='PC - Cartoon Network Universe FusionFall - Ben',native_lighting=True,uniform_scale=True)
for x,y,z in v:
 b=1 if y>3.5 else (2 if x<-.5 else 3)if 1.55<y<3.5 and (x<-.5 or x>.49)else 0
 m['vertices'].append(dict(bone=b,position=[round(x*scale),round((y-bottom)*scale),round(z*scale)]))
# OBJ contains UVs and smooth group 1, but no vn records: derive smooth normals
# from the supplied indexed geometry without changing positions or topology.
normal=[[0.,0.,0.]for _ in v]
for f in faces:
 a,b,c=[v[x[0]-1]for x in f[:3]];u=[b[k]-a[k]for k in range(3)];w=[c[k]-a[k]for k in range(3)];n=[u[1]*w[2]-u[2]*w[1],u[2]*w[0]-u[0]*w[2],u[0]*w[1]-u[1]*w[0]]
 for vi,ti in f:
  for k in range(3):normal[vi-1][k]+=n[k]
for f in faces:
 for j in range(1,len(f)-1):
  cs=[]
  for vi,ti in [f[0],f[j],f[j+1]]:
   n=normal[vi-1];mag=math.sqrt(sum(x*x for x in n)) or 1;cs.append(dict(vertex=vi-1,uv=uv[ti-1],normal=[round(x/mag*127)for x in n]))
  m['triangles'].append(dict(material=0,corners=cs))
shutil.copyfile(src.parent/'Texture/Body.png',D/'Body.png')
(R/'tools/ben10_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n')
print('Ben:',len(m['triangles']),'triangles, original UV / derived smooth normals, height 70; pivots',m['bones'])

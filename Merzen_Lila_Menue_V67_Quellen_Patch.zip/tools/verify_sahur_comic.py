"""Verify supplied shuffling Sahur, eye correction, comic encounters and lighter flat Squidward."""
from pathlib import Path
import csv,hashlib,json,re,struct,subprocess,sys
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages,controls,tokens
from verify_bowling_sage_revision import function_bodies
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0'
a=(W/'baseline.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();unpacked=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='8d52174b6d576c16f24a94e5621479d89b0acd247c91ce6a47d8f25640268030'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
old=messages((W/'baseline_message_data.h').read_text());new=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());changed=[]
for i in old:
 assert old[i]['header']==new[i]['header']
 for lang in [0,1,3]:assert old[i]['parts'][lang][2]==new[i]['parts'][lang][2],(i,lang)
 x=old[i]['parts'][2][2];y=new[i]['parts'][2][2]
 assert controls(x)==controls(y),(i,'native control')
 if 'NAME'in tokens(x):assert 'NAME'in tokens(y)
 if x!=y:changed.append(i)
assert set(changed)=={'5085','7068','7069'}
edits={i:e for p in(R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};assert len(edits)==1026
buffers=check_buffers(B,edits)
# The old generic future windmill line was replaced; the user's other NPC gags,
# all recent Shadow chapter texts and every Sahur/Thaddaeus text are unchanged.
fan=(R/'tools/fanboy_source.json').read_bytes();assert fan==(W/'fanboy_before.json').read_bytes()
chum=json.loads((R/'tools/chumchum_source.json').read_text());cb=json.loads((W/'chumchum_before.json').read_text());assert chum['height_game_units']==49 and chum['bones']==cb['bones']and len(chum['triangles'])==1573
assert chum['eye_refinement']['preserved_original_eye_triangles']==408
flat=json.loads((R/'tools/flatsquid_source.json').read_text());fb=json.loads((W/'flatsquid_before.json').read_text());assert len(fb['triangles'])==1145 and len(flat['triangles'])==972 and flat['static']
assert flat['bones']==fb['bones']and flat['materials']==fb['materials']
for k in range(3):
 for fn in [min,max]:assert abs(fn(v['position'][k]for v in flat['vertices'])-fn(v['position'][k]for v in fb['vertices']))<100,('flat silhouette bounds',k)
m=json.loads((R/'tools/sahur_shuffle_source.json').read_text());n=len(m['bones']);assert n==22 and len(m['triangles'])==2000 and m['height']==6000
def walk(i):return [i]+[x for j,p in enumerate(m['bones'])if p['parent']==i for x in walk(j)]
assert walk(0)==list(range(n))
assert len(m['animations']['dance'])==108 and len(m['animations']['idle'])==1
assert len({json.dumps(f['rotation'])for f in m['animations']['dance']})>90
for frames in m['animations'].values():
 for f in frames:assert set(f)=={'root','rotation'}and f['root'][0]==f['root'][2]==0 and len(f['rotation'])==n
assert m['dance_metadata']['unit_scale_rotations']and m['dance_metadata']['root_xz_locked']
oldfunc=function_bodies((W/'sprout_before.c').read_text());source=(O/'src/overlays/actors/ovl_Obj_Dekujr/z_obj_dekujr.c').read_text();newfunc=function_bodies(source)
assert set(oldfunc)==set(newfunc)
assert {k for k in oldfunc if oldfunc[k]!=newfunc[k]}=={'ObjDekujr_Init','ObjDekujr_Update'}
assert oldfunc['ObjDekujr_Init'].replace('0.0111111111f','0.01f')==newfunc['ObjDekujr_Init']
assert (W/'sprout_before.h').read_bytes()==(O/'src/overlays/actors/ovl_Obj_Dekujr/z_obj_dekujr.h').read_bytes()
assert 'play->csCtx.state == CS_STATE_IDLE && this->unk_19B == 0'in source and 'this->sahurSkelAnime.animation != animation'in source
for k in ['ObjDekujr_ComeUp','ObjDekujr_GetCueStartPos','ObjDekujr_GetCueEndPos','ObjDekujr_Draw','ObjDekujr_DrawNative','ObjDekujr_Destroy']:assert oldfunc[k]==newfunc[k]
oldelf=function_bodies((W/'elf_before.c').read_text());newelf=function_bodies((O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c').read_text());assert set(oldelf)==set(newelf)
assert {k for k in oldelf if oldelf[k]!=newelf[k]}=={'ElfMsg2_IsSuperhero','ElfMsg2_DrawSuperhero','ElfMsg2_InitSuperhero','ElfMsg2_UpdateSuperhero'}
D=O/'extracted/pal-1.0/assets/scenes/dungeons/MIZUsin';BD=R/'tools/originals/water-comic-heroes/extracted/pal-1.0/assets/scenes/dungeons/MIZUsin'
for room,key in [(7,'fanboy'),(19,'chumchum')]:
 p=next(D.glob(f'MIZUsin_room_{room}_*ActorEntryList.inc.c'));before=(BD/p.name).read_text();after=p.read_text();assert after.startswith(before)and after[len(before):].count('ACTOR_ELF_MSG2')==1
 p=D/f'MIZUsin_room_{room}.c';assert p.read_text()==(BD/p.name).read_text()+f'\n#include "{key}_water_model.inc.c"\n'
water=(D/'MIZUsin_scene_02013CC4_WaterBoxes.inc.c').read_text()
boxes=[tuple(map(int,q))for q in re.findall(r'(-?\d+), // xMin\s+(-?\d+), // ySurface\s+(-?\d+), // zMin\s+(\d+), // xLength\s+(\d+), // zLength',water)]
cover=lambda x,z:[y for bx,y,bz,dx,dz in boxes if bx<=x<=bx+dx and bz<=z<=bz+dz]
assert not cover(-3320,-3970)and cover(1730,180)==[765]and 765<780<1060
transition=(D/'MIZUsin_scene_02000078_TransitionActorEntryList.inc.c').read_text();pairs=[set(map(int,x))for x in re.findall(r'\{\s*(\d+),\s*-?\d+\s*\},\s*\{\s*(\d+),\s*-?\d+\s*\}',transition)];assert {7,19}not in pairs
def syms(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
ns=syms(B/'oot-pal-1.0.map');rels={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 q=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if q:section=q[1];rels.setdefault(section,{})
 q=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if q and section:rels[section][int(q[1],16)]=(q[2],q[3])
names=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];intentional={'makerom','dmadata','ger_message_data_static','object_dekujr','ovl_Obj_Dekujr','ovl_Elf_Msg2','MIZUsin_room_7','MIZUsin_room_19','Bmori1_room_5','MIZUsin_bs_room_1'};same=[];changedseg=[];linked=[];verified=0
for i,name in enumerate(names):
 _,_,x=segment(a,i);start,end,y=segment(b,i)
 if y is None:continue
 if name=='makerom':assert y[:16]==unpacked[start:start+16]and y[24:]==unpacked[start+24:end]
 elif name!='dmadata':assert y==unpacked[start:end],name;verified+=1
 if name=='object_dekujr':assert x[:13584]==y[:13584]
 if x==y:same.append(name);continue
 if name in intentional:changedseg.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)));continue
 assert len(x)==len(y),(name,'unexpected size')
 base=ns['_'+name+'SegmentStart'];words=sorted({j//4*4 for j,(p,q)in enumerate(zip(x,y))if p!=q})
 for off in words:
  addr=base+off
  if name=='code'and ns['sGerMessageEntryTable']<=addr<ns['sFraMessageEntryTable']:continue
  rel=rels.get(name,{}).get(addr);assert rel,(name,hex(addr),'unexplained difference');kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[off:off+2]==y[off:off+2]
  elif kind=='R_MIPS_26':assert x[off]>>2==y[off]>>2
  else:assert kind=='R_MIPS_32',kind
 linked.append(dict(segment=name,changed_words=len(words)))
assert verified==1509 and 'Bmori1_room_3'in same and 'ovl_Boss_Mo'in same
assert all(name in same for name in names if name.startswith('object_')and name!='object_dekujr')
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,changed_messages=changed,text_buffers=buffers,fanboy_source_and_forest_room_unchanged=True,other_models_and_boss_logic_unchanged=True,sahur=dict(triangles=2000,bones=22,dance_frames=108,root_xz_locked=True,unit_scale_poses=True,native_rise_and_camera_unchanged=True),chumchum=dict(before_triangles=1287,after_triangles=1573,preserved_eye_triangles=408,height=49),flat_squid=dict(before_triangles=1145,after_triangles=972,static_no_collision=True),water_heroes=dict(rooms=[7,19],floors=[1060,780],highest_water_surface=765,separate_nonadjacent_rooms=True),intentional_segments=changedseg,relocation_only_segments=linked,identical_segments=same)
(B/'sahur-comic-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments;',len(edits),'custom messages; only 5085/7068/7069 changed. Sahur 2000/22, Chum 1573, flat Squidward 972; other models and native progress retained.')

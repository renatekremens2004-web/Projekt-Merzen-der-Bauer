"""Verify uniform size changes, native freeing/cutscene paths and complete dialogue retention."""
from pathlib import Path
import sys,json,csv,re,struct,hashlib,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages,tokens,controls,split_pages,plain as plain_text
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';a=(W/'baseline.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();plain=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='3789ff2805ff2c5b5e53c2f7bd44935c4c2cf01dca425a7610c61890f210e1f9'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
def syms(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
old=syms(W/'baseline.map');new=syms(B/'oot-pal-1.0.map');names=[x['Name']for x in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];relocs={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if m:section=m[1];relocs.setdefault(section,{})
 m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if m and section:relocs[section][int(m[1],16)]=(m[2],m[3])
def relocated(x,y,base,name):
 assert len(x)==len(y),(name,'length',len(x),len(y))
 changed=sorted({i//4*4 for i,(q,r)in enumerate(zip(x,y))if q!=r})
 for i in changed:
  rel=relocs.get(name,{}).get(base+i);assert rel,(name,hex(base+i),'unexplained difference');kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[i:i+2]==y[i:i+2]
  elif kind=='R_MIPS_26':assert x[i]>>2==y[i]>>2
  else:assert kind=='R_MIPS_32',kind
 return len(changed)
intentional={'makerom','dmadata','ovl_En_Go2','ovl_Demo_Du','object_du','HIDAN_room_5'};segments={};identical=[];changed=[];linked=[];verified=0
for i,name in enumerate(names):
 start,end,y=segment(b,i);_,_,x=segment(a,i)
 if y is None:continue
 segments[name]=(x,y)
 if name!='dmadata':
  if name=='makerom':assert y[:16]==plain[start:start+16]and y[24:]==plain[start+24:end]
  else:assert y==plain[start:end],name;verified+=1
 if x==y:identical.append(name)
 elif name in intentional:changed.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)))
 else:linked.append(dict(segment=name,changed_words=relocated(x,y,new['_'+name+'SegmentStart'],name)))
assert verified==1509


assert (W/'baseline_message_data.h').read_bytes()==(O/'extracted/pal-1.0/text/message_data.h').read_bytes()
for name in ['ger_message_data_static','nes_message_data_static','fra_message_data_static']:assert segments[name][0]==segments[name][1]
edits={i:e for p in(R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};assert len(edits)==1013;buffers=check_buffers(B,edits)
before=json.loads((W/'wallace_before.json').read_text());after=json.loads((R/'tools/wallace_adult_source.json').read_text())
assert before['height_game_units']==after['height_game_units']==90 and len(before['bones'])==10 and len(after['bones'])==12
assert before['bones']==after['bones'][:10] and before['triangles']==after['triangles'] and before['materials']==after['materials']
assert len(before['vertices'])==len(after['vertices'])
for v,u in zip(before['vertices'],after['vertices']):
 expected=dict(v)
 if v['bone']in[2,3]and v['position'][1]<4900:expected['bone']=10+(v['bone']-2)
 assert expected==u
assert {v['bone']for v in after['vertices']}==set(range(12))
# Only one visual argument was added to each actor. All behavior/camera code remains exact.
p=O/'src/overlays/actors/ovl_En_Go2/z_en_go2.c';expected=(W/'go2_before.c').read_text().replace('((60 - this->animTimer) & 15) * (3.14159265358979323846f / 8.0f));','((60 - this->animTimer) & 15) * (3.14159265358979323846f / 8.0f), 1.0f);');assert expected==p.read_text()
p=O/'src/overlays/actors/ovl_Demo_Du/z_demo_du.c';expected=(W/'du_before.c').read_text().replace('return WallaceAdult_Draw(&this->actor, play, gfx, gAdultWallaceDL, arm, head, 0.0f, 0.0f);','return WallaceAdult_Draw(&this->actor, play, gfx, gAdultWallaceDL, arm, head, 0.0f, 0.0f, 0.0f);');assert expected==p.read_text()
for overlay in ['En_Go2','Demo_Du']:assert (O/'src/overlays/actors'/('ovl_'+overlay)/'wallace_adult_draw.inc.c').read_bytes()==(R/'tools/wallace_adult_draw.inc.c').read_bytes()
functions=re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([Tt]) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'oot-pal-1.0.elf')],text=True),re.M);func_addrs={int(q[1],16)for line in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(B/'oot-pal-1.0.elf')],text=True).splitlines()if len(q:=line.split())>=8 and q[3]=='FUNC'}
retained={};checked=set();render_modified=[];allowed={'WallaceAdult_Draw','DemoDu_DrawWallace','EnGo2_DrawAdultWallace','EnGo2_Draw','DemoDu_Draw_01','DemoDu_Draw_02'}
for seg in ['code','ovl_En_Go2','ovl_Demo_Du','ovl_Demo_Sa','ovl_En_Nb','ovl_En_Ik']:
 x,y=segments[seg];count=0
 for addr,size,kind,name in functions:
  address=int(addr,16);length=int(size,16)
  if address not in func_addrs or name not in old:continue
  if not new['_'+seg+'SegmentStart']<=address<new['_'+seg+'SegmentEnd']or not old['_'+seg+'SegmentStart']<=old[name]<old['_'+seg+'SegmentEnd']:continue
  i=old[name]-old['_'+seg+'SegmentStart'];j=address-new['_'+seg+'SegmentStart']
  try:relocated(x[i:i+length],y[j:j+length],address,seg)
  except AssertionError:
   assert name in allowed,(seg,name,'unexpected edit');render_modified.append(dict(segment=seg,function=name));continue
  count+=1;checked.add(name)
 retained[seg]=count
for name in ['EnGo2_GoronFireGenericAction','EnGo2_GoronFireCamera','EnGo2_GoronFireClearCamera','EnGo2_Update','EnNb_Update','EnIk_UpdateEnemy','EnIk_UpdateCutscene','Inventory_ChangeEquipment','Player_SetBootData','CollisionCheck_GetSwordDamage','Room_RequestNewRoom']:assert name in checked,name
# Feet stay planted over the complete step cycle and the standing gesture cycle.
import math
floor_error=0;min_cos=1;max_drop=0
for frame in range(240):
 gesture=math.sin(frame*1000*math.pi/32768)
 for timer in range(0,61):
  blend=max(0,min(1,(60-timer)/4))*max(0,min(1,timer/4))if timer else 0;phase=((60-timer)&15)*math.pi/8
  drop=230*blend+(1-blend)*20*(1+gesture)+blend*90*(1-math.cos(2*phase));max_drop=max(max_drop,drop)
  for side in range(2):
   q=(phase+side*math.pi)%(2*math.pi)
   if q<math.pi:t=q/math.pi;z=1200*(1-2*t);lift=0
   else:t=(q-math.pi)/math.pi;z=-1200+2400*(t-math.sin(2*math.pi*t)/(2*math.pi));lift=math.sin(math.pi*t)*730
   z*=blend;lift*=blend;down=3600-drop-lift;cosine=(down*down+z*z-6480000)/6480000;assert -1<=cosine<=1;min_cos=min(min_cos,cosine)
   bend=math.acos(cosine);hip=math.atan2(-z,down)-bend/2;ankle_y=4200-1800*math.cos(hip)-1800*math.cos(hip+bend)-drop;floor_error=max(floor_error,abs(ankle_y-600-lift))
assert floor_error<.01
for name in ['object_nb','object_sa','ovl_Demo_Sa','ovl_En_Nb','ovl_En_Ik','spot16_scene','spot16_room_0','kenjyanoma_scene','jyasinboss_scene','jyasinzou_scene','HAKAdan_scene','HAKAdanCH_scene','spot09_room_0']:
 assert name in identical or any(v['segment']==name for v in linked),name
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,all_1013_custom_messages_and_all_other_text_unchanged=True,text_buffers=buffers,wallace=dict(height=90,triangles=len(after['triangles']),rigid_matrices=12,extra_matrix_bytes=128,only_existing_forearm_vertices_reassigned=True,geometry_normals_uvs_materials_unchanged=True,maximum_body_drop_game_units=max_drop/100,maximum_ideal_foot_error_model_units=floor_error,minimum_knee_cosine=min_cos),native_release_path_states_camera_timing_and_rewards_unchanged=True,sage_lively_argument_zero=True,all_other_models_and_cameras_unchanged=True,retained_native_functions=retained,modified_render_functions=render_modified,intentional_segments=changed,identical_segments=identical,relocated_segments=linked)
(B/'wallace-cheer-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments; all text/models/cameras outside Wallace retained;',retained,'native functions; ideal foot error',floor_error)

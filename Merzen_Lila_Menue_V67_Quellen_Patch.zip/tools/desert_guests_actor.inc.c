/* Small own-proportion guests, scoped to three adult rooms. */
extern Gfx gMeowthDL[];
extern Gfx gJimmyDL[];
extern Gfx gMackeyDL[];
static s32 ElfMsg2_IsDesertGuest(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_SPIRIT_TEMPLE && actor->room == 19 && actor->params == 0x3F8D) ||
        (play->sceneId == SCENE_LON_LON_RANCH && actor->room == 0 && actor->params == 0x3F8E) ||
        (play->sceneId == SCENE_KAKARIKO_CENTER_GUEST_HOUSE && actor->room == 0 && actor->params == 0x3F8F);
}
static void ElfMsg2_DrawDesertGuest(Actor* actor, PlayState* play) {
    static s16 objects[3] = { OBJECT_MEOWTH, OBJECT_JIMMY, OBJECT_MACKEY };
    static Gfx* lists[3] = { gMeowthDL, gJimmyDL, gMackeyDL };
    static Vec3f pivots[3][4] = { DESERT_GUEST_PIVOTS };
    s32 index = actor->params - 0x3F8D;
    s32 slot = Object_GetSlot(&play->objectCtx, objects[index]);
    s32 speaking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 360 + index * 9000));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 900));
    Mtx* matrices;
    s32 i;
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "desert_guests", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Vec3f* pivot = &pivots[index][i];
        Matrix_Push();
        Matrix_RotateZ(idle * 0.004f, MTXMODE_APPLY);
        Matrix_Translate(pivot->x, pivot->y, pivot->z, MTXMODE_APPLY);
        if (i == 1) {
            Matrix_RotateY(idle * 0.018f, MTXMODE_APPLY);
            Matrix_RotateX(speaking ? talk * 0.024f : idle * 0.008f, MTXMODE_APPLY);
        } else if (i >= 2) {
            Matrix_RotateZ((i == 2 ? 1 : -1) * (idle * 0.008f +
                (speaking ? talk * (index == 1 ? 0.045f : 0.03f) : 0)), MTXMODE_APPLY);
        }
        Matrix_Translate(-pivot->x, -pivot->y, -pivot->z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "desert_guests", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, lists[index]);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "desert_guests", 3);
}
static void ElfMsg2_InitDesertGuest(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 heights[3] = { 19, 40, 65 };
    static s16 radii[3] = { 7, 10, 13 };
    s32 index = actor->params - 0x3F8D;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) { Actor_Kill(actor); return; }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71C3 + index;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1600;
    actor->cullingVolumeScale = 120;
    actor->cullingVolumeDownward = 100;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, radii[index]);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = radii[index];
    this->wallaceCollider.dim.height = heights[index];
    Actor_SetFocus(actor, heights[index]);
    actor->draw = ElfMsg2_DrawDesertGuest;
}
static void ElfMsg2_UpdateDesertGuest(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 heights[3] = { 19, 40, 65 };
    s32 index = actor->params - 0x3F8D;
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1) actor->world.pos.y = actor->floorHeight;
    }
    Actor_SetFocus(actor, heights[index]);
    actor->textId = 0x71C3 + index;
    Math_SmoothStepToS(&actor->shape.rot.y,
        play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE ?
        actor->yawTowardsPlayer : actor->home.rot.y, 6, 0x300, 1);
    if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE &&
        !Player_InCsMode(play) && Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
        actor->xzDistToPlayer < 140 && fabsf(actor->yDistToPlayer) < 55) Actor_OfferTalk(actor, play, 125);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

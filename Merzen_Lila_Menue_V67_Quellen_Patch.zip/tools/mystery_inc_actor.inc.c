/* Five independently loaded N64 guests. No quest bits, combat or puzzle actions. */
extern Gfx gShaggyDL[];
extern Gfx gVelmaDL[];
extern Gfx gDaphneDL[];
extern Gfx gScoobyDL[];
extern Gfx gFredDL[];
static s32 ElfMsg2_IsMysteryInc(Actor* actor, PlayState* play) {
    static s8 rooms[5] = { 0, 1, 2, 6, 5 };
    s32 index = actor->params - 0x3F87;
    return play->sceneId == SCENE_BOTTOM_OF_THE_WELL && index >= 0 && index < 5 && actor->room == rooms[index];
}
static void ElfMsg2_DrawMysteryInc(Actor* actor, PlayState* play) {
    static s16 objects[5] = { OBJECT_SHAGGY, OBJECT_VELMA, OBJECT_DAPHNE, OBJECT_SCOOBY, OBJECT_FRED };
    static Gfx* lists[5] = { gShaggyDL, gVelmaDL, gDaphneDL, gScoobyDL, gFredDL };
    static Vec3f pivots[5][4] = { MYSTERY_PIVOTS };
    s32 index = actor->params - 0x3F87;
    s32 slot = Object_GetSlot(&play->objectCtx, objects[index]);
    s32 speaking = play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 350 + index * 6000));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 850));
    Mtx* matrices;
    s32 i;
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "mystery_inc", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Vec3f* pivot = &pivots[index][i];
        Matrix_Push();
        Matrix_Translate(pivot->x, pivot->y, pivot->z, MTXMODE_APPLY);
        if (i == 1) {
            Matrix_RotateY(idle * 0.015f, MTXMODE_APPLY);
            Matrix_RotateX(speaking ? talk * 0.018f : idle * 0.006f, MTXMODE_APPLY);
        } else if (index == 3 && i == 2) {
            Matrix_RotateY(idle * 0.09f, MTXMODE_APPLY);
        } else if (index != 3 && i >= 2) {
            /* At most 1.4 degrees: authored shoulder seams remain together. */
            Matrix_RotateZ((i == 2 ? 1 : -1) * (idle * 0.006f + (speaking ? talk * 0.018f : 0)), MTXMODE_APPLY);
        }
        Matrix_Translate(-pivot->x, -pivot->y, -pivot->z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "mystery_inc", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, lists[index]);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "mystery_inc", 3);
}
static void ElfMsg2_InitMysteryInc(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 heights[5] = { 86, 69, 78, 52, 83 };
    s32 index = actor->params - 0x3F87;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71BA + index;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1600;
    actor->cullingVolumeScale = 130;
    actor->cullingVolumeDownward = 100;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, index == 3 ? 14 : 12);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 12;
    this->wallaceCollider.dim.height = heights[index];
    Actor_SetFocus(actor, heights[index]);
    actor->draw = ElfMsg2_DrawMysteryInc;
}
static void ElfMsg2_UpdateMysteryInc(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    static f32 heights[5] = { 86, 69, 78, 52, 83 };
    s32 index = actor->params - 0x3F87;
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight;
    }
    Actor_SetFocus(actor, heights[index]);
    Math_SmoothStepToS(&actor->shape.rot.y, play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE ? actor->yawTowardsPlayer : actor->home.rot.y, 6, 0x400, 1);
    actor->textId = 0x71BA + index;
    if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE &&
        !Player_InCsMode(play) && Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
        actor->xzDistToPlayer < 140 && fabsf(actor->yDistToPlayer) < 55) {
        Actor_OfferTalk(actor, play, 125);
    }
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

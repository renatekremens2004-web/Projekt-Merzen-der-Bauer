"""DS Crocker: preserve all 205 triangles, add four small rigid pose groups offline."""
import bpy,json,sys,math,shutil
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);D=R/'models/crocker';D.mkdir(parents=True,exist_ok=True);src=next((W/'input/crocker').rglob('*.obj'));bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.obj_import(filepath=str(src),forward_axis='NEGATIVE_Z',up_axis='Y');o=next(o for o in bpy.context.scene.objects if o.type=='MESH');me=o.data;me.calc_loop_triangles();bottom=min(v.co.y for v in me.vertices);scale=8700/(max(v.co.y for v in me.vertices)-bottom);piv=[Vector((0,0,0)),Vector((0,1.90,0)),Vector((-.23,1.79,0)),Vector((.23,1.79,0))]
m={'bones':[{'name':n,'parent':-1,'position':[round(p.x*scale),round((p.y-bottom)*scale),round(p.z*scale)]}for n,p in zip(['body','head','left_arm','right_arm'],piv)],'materials':[{'name':'crocker','texture':'Crocker.png','size':[64,64]},{'name':'ear','texture':'Ear.png','size':[16,16]}],'vertices':[],'triangles':[]}
for name in ['Crocker.png','Ear.png']:shutil.copyfile(W/'input/crocker/textures'/name,D/name)
rots=[]
for v in me.vertices:
 p=v.co.copy();b=(2 if p.x<0 else 3)if abs(p.x)>.23 and 1.6<p.y<1.9 else 1 if p.y>1.9 else 0;rot=Matrix.Identity(3)
 if b>=2:rot=Matrix.Rotation(math.radians(55 if b==2 else -55),3,'Z');p=piv[b]+rot@(p-piv[b])
 p.y-=bottom;m['vertices'].append({'bone':b,'position':[round(x*scale)for x in p]});rots.append(rot)
for t in me.loop_triangles:m['triangles'].append({'material':t.material_index,'corners':[{'vertex':vi,'uv':list(me.uv_layers.active.data[li].uv),'normal':[round(x*127)for x in(rots[vi]@me.vertices[vi].normal).normalized()]}for vi,li in zip(t.vertices,t.loops)]})
m.update(source=str(src.relative_to(W)),height_game_units=87);(R/'tools/crocker_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');print('Crocker',len(m['triangles']),'triangles; own rigid pivots')

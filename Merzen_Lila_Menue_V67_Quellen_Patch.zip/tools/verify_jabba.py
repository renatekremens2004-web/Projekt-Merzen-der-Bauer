"""Differential PAL build checks: private child Jabba and a safe new message ID."""
from pathlib import Path
import csv,hashlib,json,re,struct,subprocess,sys
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages,controls,plain
from verify_bowling_sage_revision import function_bodies
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';base=W/'baseline'
a=(base/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();unpacked=(B/'oot-pal-1.0.z64').read_bytes();assert hashlib.sha256(a).hexdigest()=='eb84102abfe6293728c16766e1e9625fbeba6285050650b524df844f2a7adb61';assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
old=messages((base/'extracted/pal-1.0/text/message_data.h').read_text());new=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());assert set(new)-set(old)=={'71B3'}and not(set(old)-set(new))
for ident in old:assert old[ident]==new[ident]or(old[ident]['header']==new[ident]['header']and all(old[ident]['parts'][k][2]==new[ident]['parts'][k][2]for k in range(4))),ident
assert controls(new['71B3']['parts'][2][2])==[]
source=(O/'extracted/pal-1.0/text/message_data.h').read_text();assert source.index('DEFINE_MESSAGE(0x71B3,')<source.index('DEFINE_MESSAGE(0x71B2,')
edits={}
for p in(R/'story').glob('*.json'):
 for ident,e in json.loads(p.read_text())['messages'].items():assert ident not in edits;edits[ident]=e
assert len(edits)==1031;buffers=check_buffers(B,edits)
# Every pre-existing core source file is retained; only generated text tables grow.
for f,h in json.loads((W/'native-code-hashes.json').read_text()).items():assert hashlib.sha256((O/f).read_bytes()).hexdigest()==h,f
f='src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';of=function_bodies((base/f).read_text());nf=function_bodies((O/f).read_text());assert set(nf)-set(of)=={'ElfMsg2_IsJabba','ElfMsg2_DrawJabba','ElfMsg2_InitJabba','ElfMsg2_UpdateJabba'};assert {k for k in of if of[k]!=nf[k]}=={'ElfMsg2_Init','ElfMsg2_Update','ElfMsg2_Destroy'}
D=O/'extracted/pal-1.0/assets/scenes/overworld/spot00';originals=R/'tools/originals/jabba'
for p in originals.rglob('*.inc.c'):
 after=(O/p.relative_to(originals)).read_text();before=p.read_text();assert after.startswith(before)and after[len(before):].count('ACTOR_ELF_MSG2'if 'ActorEntryList'in p.name else 'OBJECT_JABBA')==1
p=D/'spot00_room_0.c';assert p.read_text()==(originals/p.relative_to(O)).read_text()
m=json.loads((R/'tools/jabba_source.json').read_text());assert len(m['bones'])==2 and m['height_game_units']==78 and len(m['triangles'])<=2600 and m['uniform_scale']
# Linker addresses/relocations explain unrelated segment changes.
def syms(path):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',path.read_text()):d.setdefault(n,int(x,16))
 return d
ns=syms(B/'oot-pal-1.0.map');os=syms(base/'build/pal-1.0/oot-pal-1.0.map');rels={};sec=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 q=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if q:sec=q[1];rels.setdefault(sec,{})
 q=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if q and sec:rels[sec][int(q[1],16)]=(q[2],q[3])
sentinel_words=[]
def linked_word(x,y,off,addr,name):
 if name=='ovl_En_Ossan' and all(p==q or (p==0x192 and q==0x193)for p,q in zip(struct.unpack_from('>HH',x,off),struct.unpack_from('>HH',y,off))):
  sentinel_words.append(hex(addr));return
 rel=rels.get(name,{}).get(addr);assert rel,(name,hex(addr),'unexplained difference');kind,target=rel
 if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[off:off+2]==y[off:off+2],(name,target)
 elif kind=='R_MIPS_26':assert x[off]>>2==y[off]>>2
 else:assert kind=='R_MIPS_32',kind
names=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];oldnames=names[:];names+=['object_jabba'];assert re.findall(r'DEFINE_DMA_ENTRY\((\w+),', (B/'dmadata_table_spec.h').read_text())==names;intentional={'object_jabba','makerom','dmadata','code','nes_message_data_static','ger_message_data_static','fra_message_data_static','ovl_Elf_Msg2','spot00_room_0'};same=[];changed=[];relocated=[];verified=0
for i,name in enumerate(names):
 x=segment(a,i)[2]if i<len(oldnames)else None;start,end,y=segment(b,i)
 if y is None:continue
 if name=='makerom':assert y[:16]==unpacked[start:start+16]and y[24:]==unpacked[start+24:end]
 elif name!='dmadata':assert y==unpacked[start:end],name;verified+=1
 if x==y:same.append(name);continue
 if name in intentional:changed.append(dict(segment=name,before_bytes=len(x)if x is not None else 0,after_bytes=len(y)));continue
 assert len(x)==len(y),(name,'size')
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(x,y))if p!=q}):linked_word(x,y,off,ns['_'+name+'SegmentStart']+off,name)
 relocated.append(name)
assert verified==1510 and all(n not in {q['segment']for q in changed}for n in names if (n.startswith('object_')and n!='object_jabba')or n.startswith('ovl_Boss_'))
# Code functions and named native data remain byte-identical apart from genuine
# linker relocations. This also checks unchanged gameplay amid larger tables.
def elf_symbols(path):
 d={}
 for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([tTdDrR]) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(path)],text=True),re.M):
  addr,size=int(addr,16),int(size,16)
  if size:d[name]=(addr,size,kind)
 return d
oldsy=elf_symbols(base/'oot-pal-1.0.elf');newsy=elf_symbols(B/'oot-pal-1.0.elf');ci=names.index('code');_,_,x=segment(a,ci);_,_,y=segment(b,ci);count=0;tables={'sNesMessageEntryTable','sGerMessageEntryTable','sFraMessageEntryTable','gObjectTable','gObjectTableSize'}
for name,(addr,size,kind)in oldsy.items():
 if name in tables or not(os['_codeSegmentStart']<=addr<os['_codeSegmentEnd']):continue
 na,nsize,nkind=newsy[name];assert size==nsize,(name,'size');xx=x[addr-os['_codeSegmentStart']:addr-os['_codeSegmentStart']+size];yy=y[na-ns['_codeSegmentStart']:na-ns['_codeSegmentStart']+size];assert len(xx)==len(yy)==size
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(xx,yy))if p!=q}):linked_word(xx,yy,off,na+off,'code')
 count+=1
# Validate language-table identity/positions, the added ID's following pointer,
# and every compiled original dialogue symbol in all existing PAL languages.
changed_ids=[]
for lang in ['nes','ger','fra']:
 p=B/f'assets/text/{lang}_message_data_static.o';q=W/f'baseline-{lang}.o'
 assert q.exists(),q
 before=elf_symbols(q);after=elf_symbols(p);rawold=(W/f'baseline-{lang}.bin').read_bytes();rawnew=(B/f'assets/text/{lang}_message_data_static.o.bin').read_bytes()
 for name,(addr,size,_)in before.items():
  na,nsize,_=after[name];assert size==nsize and rawold[addr:addr+size]==rawnew[na:na+size],(lang,name,'existing compiled text changed')
 assert len(after)==len(before)+1,(lang,'new private text count')
def data(name,isnew):
 sym=newsy[name]if isnew else oldsy[name];rom=y if isnew else x;start=ns['_codeSegmentStart']if isnew else os['_codeSegmentStart'];return rom[sym[0]-start:sym[0]-start+sym[1]]
oldentries=list(struct.iter_unpack('>HBBI',data('sNesMessageEntryTable',False)));entries=list(struct.iter_unpack('>HBBI',data('sNesMessageEntryTable',True)));idx=[e[0]for e in entries].index(0x71B3);assert entries[idx+1][0]==0x71B2
assert [(e[0],e[1],e[2])for e in oldentries]==[(e[0],e[1],e[2])for e in entries if e[0]!=0x71B3]
for lang,table in [('nes','sNesMessageEntryTable'),('ger','sGerMessageEntryTable'),('fra','sFraMessageEntryTable')]:
 ptr=entries[idx][3]if lang=='nes'else struct.unpack_from('>I',data(table,True),idx*4)[0];nxt=entries[idx+1][3]if lang=='nes'else struct.unpack_from('>I',data(table,True),(idx+1)*4)[0];assert 0<nxt-ptr<1280,(lang,'private message DMA bounds',nxt-ptr)
# Object ID 0x192 and DMA segment are appended; native object extents stay unchanged.
assert struct.unpack('>I',data('gObjectTableSize',False))[0]+1==struct.unpack('>I',data('gObjectTableSize',True))[0]==0x193
oldobj=list(struct.iter_unpack('>II',data('gObjectTable',False)));newobj=list(struct.iter_unpack('>II',data('gObjectTable',True)));assert len(newobj)==len(oldobj)+1==0x193
assert all(b-a==d-c for (a,b),(c,d)in zip(oldobj,newobj[:-1]))
assert newobj[-1]==(ns['_object_jabbaSegmentRomStart'],ns['_object_jabbaSegmentRomEnd'])
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,new_message='71B3',previous_messages_all_languages_source_and_compiled_unchanged=True,text_buffers=buffers,native_core_functions_and_data_symbols_verified=count,shop_object_max_sentinel_updates=sentinel_words,new_id_following_dma_pointer_valid=True,jabba=dict(triangles=len(m['triangles']),height=78,bones=2,child_day_night=True,dedicated_object_id=0x192,native_dma_indices_retained=True),intentional_segments=changed,relocation_only_segments=relocated,identical_segments=same)
(B/'jabba-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments,',count,'native core symbols,',len(edits),'custom messages. Existing multilingual texts unchanged; new private ID and next DMA pointer valid.')

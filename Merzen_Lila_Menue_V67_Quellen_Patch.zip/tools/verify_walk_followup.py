"""Verify uniform size changes, native freeing/cutscene paths and complete dialogue retention."""
from pathlib import Path
import sys,json,csv,re,struct,hashlib,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages,tokens,controls,split_pages,plain as plain_text
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';a=(W/'baseline.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();plain=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='d62d4b484265ce46806fb784e77eae31634049b03d7066762c0563684207320e'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
def syms(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
old=syms(W/'baseline.map');new=syms(B/'oot-pal-1.0.map');names=[x['Name']for x in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];relocs={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if m:section=m[1];relocs.setdefault(section,{})
 m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if m and section:relocs[section][int(m[1],16)]=(m[2],m[3])
def relocated(x,y,base,name):
 assert len(x)==len(y),(name,'length',len(x),len(y))
 changed=sorted({i//4*4 for i,(q,r)in enumerate(zip(x,y))if q!=r})
 for i in changed:
  rel=relocs.get(name,{}).get(base+i);assert rel,(name,hex(base+i),'unexplained difference');kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[i:i+2]==y[i:i+2]
  elif kind=='R_MIPS_26':assert x[i]>>2==y[i]>>2
  else:assert kind=='R_MIPS_32',kind
 return len(changed)
intentional={'makerom','dmadata','ovl_En_Go2','ovl_Demo_Du','object_du','object_nb','HIDAN_room_5','ovl_En_Nb','ovl_Demo_Sa','jyasinboss_scene','kenjyanoma_scene'};segments={};identical=[];changed=[];linked=[];verified=0
for i,name in enumerate(names):
 start,end,y=segment(b,i);_,_,x=segment(a,i)
 if y is None:continue
 segments[name]=(x,y)
 if name!='dmadata':
  if name=='makerom':assert y[:16]==plain[start:start+16]and y[24:]==plain[start+24:end]
  else:assert y==plain[start:end],name;verified+=1
 if x==y:identical.append(name)
 elif name in intentional:changed.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)))
 else:linked.append(dict(segment=name,changed_words=relocated(x,y,new['_'+name+'SegmentStart'],name)))
assert verified==1509

assert (W/'baseline_message_data.h').read_bytes()==(O/'extracted/pal-1.0/text/message_data.h').read_bytes()
for name in ['ger_message_data_static','nes_message_data_static','fra_message_data_static']:assert segments[name][0]==segments[name][1]
edits={i:e for p in(R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};assert len(edits)==1013;buffers=check_buffers(B,edits)
before=json.loads((W/'wallace_before.json').read_text());after=json.loads((R/'tools/wallace_adult_source.json').read_text())
assert after['height_game_units']==before['height_game_units']==90 and len(before['bones'])==4 and len(after['bones'])==10
assert before['materials']==after['materials'] and before['triangles']==after['triangles'] and before['bones']==after['bones'][:4]
assert len(before['vertices'])==len(after['vertices'])
for v,u in zip(before['vertices'],after['vertices']):
 expected=dict(v)
 if v['bone']==0 and v['position'][1]<4200:
  side=0 if v['position'][0]>=0 else 1;expected['bone']=(8 if v['position'][1]<900 else 6 if v['position'][1]<2400 else 4)+side
 assert expected==u
assert {v['bone']for v in after['vertices']}==set(range(10))
wallace_triangles=len(after['triangles'])
before=json.loads((W/'waluigi_before.json').read_text());after=json.loads((R/'tools/waluigi_sage_source.json').read_text());factor=.75
assert before['materials']==after['materials'] and before['triangles']==after['triangles'] and before['height']==8800 and after['height']==6600
for old_vertices,new_vertices in [(before['vertices'],after['vertices']),(before['bones'],after['bones'])]:
 assert len(old_vertices)==len(new_vertices)
 for v,u in zip(old_vertices,new_vertices):
  expected=dict(v)
  for key in ['position','source_world']:
   if key in v:expected[key]=[round(x*factor)for x in v[key]]
  assert expected==u
assert before['animations'].keys()==after['animations'].keys()
for name,frames in before['animations'].items():
 assert len(frames)==len(after['animations'][name])
 for v,u in zip(frames,after['animations'][name]):assert dict(v,root=[round(x*factor)for x in v['root']])==u
# Every actor/control function is identical, allowing only proper linker relocations.
functions=re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([Tt]) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'oot-pal-1.0.elf')],text=True),re.M)
func_addrs={int(q[1],16)for line in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(B/'oot-pal-1.0.elf')],text=True).splitlines()if len(q:=line.split())>=8 and q[3]=='FUNC'}
render_only={'WallaceAdult_Draw','DemoDu_DrawWallace','EnGo2_DrawAdultWallace','EnGo2_Draw','DemoDu_Draw_01','DemoDu_Draw_02'};retained={};modified=[];checked=set()
for seg in ['code','ovl_En_Go2','ovl_Demo_Du','ovl_En_Nb','ovl_En_Ik','ovl_Demo_Sa']:
 x,y=segments[seg];count=0
 for addr,size,kind,name in functions:
  address=int(addr,16);length=int(size,16)
  if address not in func_addrs or name not in old:continue
  if not new['_'+seg+'SegmentStart']<=address<new['_'+seg+'SegmentEnd']or not old['_'+seg+'SegmentStart']<=old[name]<old['_'+seg+'SegmentEnd']:continue
  i=old[name]-old['_'+seg+'SegmentStart'];j=address-new['_'+seg+'SegmentStart']
  try:relocated(x[i:i+length],y[j:j+length],address,seg)
  except AssertionError:
   assert name in render_only,(seg,name,'unexpected function edit');modified.append(dict(segment=seg,function=name));continue
  count+=1;checked.add(name)
 retained[seg]=count
for name in ['EnGo2_GoronFireGenericAction','EnGo2_GoronFireCamera','EnGo2_GoronFireClearCamera','EnGo2_Update','EnNb_Update','EnIk_UpdateEnemy','EnIk_UpdateCutscene','Inventory_ChangeEquipment','Player_SetBootData','CollisionCheck_GetSwordDamage','Room_RequestNewRoom']:assert name in checked,name
assert retained['code']>2900 and retained['ovl_En_Nb']>90
# Mathematical floor contact over both stance and swing, including start/finish blending.
import math
floor_errors=[];angles=[]
for timer in range(1,61):
 blend=max(0,min(1,(60-timer)/4))*max(0,min(1,timer/4));drop=230*blend;phase=((60-timer)&15)*math.pi/8
 for side in range(2):
  q=(phase+side*math.pi)%(2*math.pi)
  if q<math.pi:t=q/math.pi;z=1200*(1-2*t);lift=0
  else:t=(q-math.pi)/math.pi;z=-1200+2400*(t-math.sin(t*2*math.pi)/(2*math.pi));lift=math.sin(t*math.pi)*550
  z*=blend;lift*=blend;down=3600-drop-lift;cosine=max(-1,min(1,(down*down+z*z-6480000)/6480000));bend=math.atan2(math.sqrt(max(0,1-cosine*cosine)),cosine);hip=math.atan2(-z,down)-bend/2
  ankle_y=4200-1800*math.cos(hip)-1800*math.cos(hip+bend)-drop
  ankle_z=-100-1800*math.sin(hip)-1800*math.sin(hip+bend)
  floor_errors.append(abs(ankle_y-600-lift));assert abs(ankle_z+100-z)<.01;angles.append([hip,bend])
assert max(floor_errors)<.01
for name in ['ovl_En_Ik','spot16_scene','spot16_room_0','HAKAdan_scene','HAKAdanCH_scene','jyasinzou_scene','spot11_scene']:
 assert name in identical or any(v['segment']==name for v in linked),name
from fit_waluigi_cameras import POINT
strip_camera_positions=lambda t:POINT.sub(lambda q:q[1]+'X, Y, Z'+q[5],t)
for name,path in [('hall',O/'src/overlays/actors/ovl_En_Nb/sage_medallion_cameras.inc.c'),('reveal',O/'extracted/pal-1.0/assets/scenes/dungeons/jyasinboss/gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c'),('seal',O/'extracted/pal-1.0/assets/scenes/indoors/kenjyanoma/gChamberOfSagesSealOpeningCs.csdata.inc.c'),('credits',O/'src/overlays/actors/ovl_Demo_Sa/bowling_sage_cutscene_data.inc.c')]:
 assert strip_camera_positions((W/(name+'_camera_before.c')).read_text())==strip_camera_positions(path.read_text()), name
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,all_1013_custom_messages_and_all_other_languages_unchanged=True,text_buffers=buffers,wallace=dict(triangles=wallace_triangles,height=90,rigid_matrices=10,additional_matrix_bytes=384,model_positions_normals_uvs_triangles_unchanged=True,walk_only_in_native_escape_state_2=True,maximum_ideal_ankle_floor_error_model_units=max(floor_errors)),waluigi=dict(factor=.75,before_source_height=8800,after_source_height=6600,triangles=len(after['triangles']),own_bones=len(after['bones']),all_animation_frame_counts_and_rotations_preserved=True),native_cues_release_path_timings_and_quest_logic_unchanged=True,only_waluigi_closeup_camera_coordinates_fitted=True,retained_native_functions=retained,modified_render_functions=modified,intentional_segments=changed,identical_segments=identical,relocated_segments=linked)
(B/'walk-waluigi-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments;',retained,'functions retained; render changes',modified,'; all text unchanged; floor IK error',max(floor_errors))

/* Private Water Temple modes. Assets live in the native room segment, not object slots. */
extern Gfx gPepsimanDL[];
extern Gfx gPepsiCanRoom7DL[];
extern Gfx gPepsiCanRoom9DL[];
extern Gfx gPepsiCanRoom16DL[];
extern Gfx gPepsiCrushedRoom16DL[];
extern Gfx gPepsiCanRoom17DL[];
extern Gfx gPepsiCanRoom19DL[];

static s32 ElfMsg2_IsPepsiman(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_WATER_TEMPLE && actor->room == 16 && actor->params == 0x3F72;
}
static s32 ElfMsg2_IsPepsiCan(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_WATER_TEMPLE &&
        (actor->params == 0x3F73 || actor->params == 0x3F74) &&
        (actor->room == 7 || actor->room == 9 || actor->room == 16 || actor->room == 17 || actor->room == 19);
}
static void* ElfMsg2_PepsiRoom(Actor* actor, PlayState* play) {
    if (play->roomCtx.curRoom.num == actor->room) return play->roomCtx.curRoom.segment;
    if (play->roomCtx.prevRoom.num == actor->room) return play->roomCtx.prevRoom.segment;
    return NULL;
}
static void ElfMsg2_DrawPepsiman(Actor* actor, PlayState* play) {
    static Vec3f pivots[4] = { PEPSIMAN_PIVOTS };
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 430));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1100));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "pepsiman", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.035f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.025f : -0.025f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.07f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "pepsiman", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gPepsimanDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "pepsiman", 3);
}
static void ElfMsg2_DrawPepsiCan(Actor* actor, PlayState* play) {
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Gfx* dl = NULL;
    if (roomSegment == NULL) return;
    switch (actor->room) {
        case 7: dl = gPepsiCanRoom7DL; break;
        case 9: dl = gPepsiCanRoom9DL; break;
        case 16: dl = actor->params == 0x3F74 ? gPepsiCrushedRoom16DL : gPepsiCanRoom16DL; break;
        case 17: dl = gPepsiCanRoom17DL; break;
        case 19: dl = gPepsiCanRoom19DL; break;
    }
    if (dl == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "pepsi-can", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "pepsi-can", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, dl);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "pepsi-can", 3);
}
static void ElfMsg2_InitPepsiman(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x3072;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 17);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 14;
    this->wallaceCollider.dim.height = 94;
    Actor_SetFocus(actor, 82);
    actor->draw = ElfMsg2_DrawPepsiman;
}
static void ElfMsg2_UpdatePepsiman(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 82);
    actor->textId = 0x3072;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 115.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

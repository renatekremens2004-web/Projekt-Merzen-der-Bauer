"""Differential validation of the opening and age-aware Gerudo dialogue revision."""
from pathlib import Path
import csv,hashlib,json,re,struct,subprocess,sys
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages
from verify_bowling_sage_revision import function_bodies
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';base=Path('/workspace/intro-dialogue/baseline')
a=(base/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();unpacked=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='55d2d55989441ef99221df41a7fcc34429c303bbb6d61e91dfe8fb7444488066'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
old=messages((base/'extracted/pal-1.0/text/message_data.h').read_text());new=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());ids=set(json.loads(Path('/workspace/intro-dialogue/changed-ids.json').read_text()))|set(json.loads((W/'changed-ids.json').read_text()));assert set(new)-set(old)=={'71C6'}and not(set(old)-set(new))
from build_story import controls,split_pages,tokens
source_changed=set()
for ident in old:
 assert old[ident]['header']==new[ident]['header']
 for k in range(4):
  x=old[ident]['parts'][k][2];y=new[ident]['parts'][k][2]
  if x!=y:assert k==2;source_changed.add(ident)
  assert controls(x)==controls(y),(ident,'controls')
  if len(split_pages(x)[0])!=len(split_pages(y)[0]):assert ident in ids and all(q=='BOX_BREAK'for q in split_pages(x)[1])and not any(t.startswith('FADE')for t in tokens(x)),ident
assert source_changed==ids
edits={}
for p in(R/'story').glob('*.json'):
 for ident,e in json.loads(p.read_text())['messages'].items():assert ident not in edits;edits[ident]=e
buffers=check_buffers(B,edits);assert len(edits)==1104
for f,h in json.loads(Path('/workspace/back-to-future/native-code-hashes.json').read_text()).items():
 if f not in ['src/overlays/actors/ovl_En_Js/z_en_js.c','src/overlays/actors/ovl_Boss_Tw/z_boss_tw.c']:assert hashlib.sha256((O/f).read_bytes()).hexdigest()==h,f
rel=Path('src/overlays/actors/ovl_En_Js/z_en_js.c');original=(R/'tools/originals/gerudo-dialogue'/rel).read_text();actual=(O/rel).read_text();of=function_bodies(original);nf=function_bodies(actual);assert of.keys()==nf.keys()and{k for k in of if of[k]!=nf[k]}=={'func_80A88F64'}
rel=Path('src/overlays/actors/ovl_Boss_Tw/z_boss_tw.c');original=(R/'tools/originals/twinrova-dialogue'/rel).read_text();actual=(O/rel).read_text();of=function_bodies(original);nf=function_bodies(actual);assert of.keys()==nf.keys()and{k for k in of if of[k]!=nf[k]}=={'BossTw_TwinrovaIntroCS','BossTw_TwinrovaMergeCS'}
# Only presentation calls differ; no timing, actor animation or combat changes.
import re as _re
for fn in ['BossTw_TwinrovaIntroCS','BossTw_TwinrovaMergeCS']:
 def strip_titles(t):
  t=_re.sub(r'/\*.*?\*/','',t,flags=_re.S)
  t=_re.sub(r'if \(gSaveContext.language [!=]= LANGUAGE_GER\)\s*\{\s*TitleCard_InitBossName\(.*?;\s*\}', '', t, flags=_re.S)
  t=_re.sub(r'TitleCard_InitBossName\(.*?;', '', t, flags=_re.S)
  return ''.join(t.split())
 assert strip_titles(of[fn])==strip_titles(nf[fn]),fn
assert(O/'src/overlays/actors/ovl_player_actor/quick_iron_boots.inc.c').read_bytes()==(R/'tools/quick_iron_boots.inc.c').read_bytes()
# Linker relocations account for changed addresses in otherwise untouched assets.
def syms(path):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',path.read_text()):d.setdefault(n,int(x,16))
 return d
ns=syms(B/'oot-pal-1.0.map');os=syms(base/'build/pal-1.0/oot-pal-1.0.map');rels={};sec=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 q=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if q:sec=q[1];rels.setdefault(sec,{})
 q=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if q and sec:rels[sec][int(q[1],16)]=(q[2],q[3])
def linked_word(x,y,off,addr,name):
 
 rel=rels.get(name,{}).get(addr);assert rel,(name,hex(addr),'unexplained difference');kind,target=rel
 if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[off:off+2]==y[off:off+2],(name,target)
 elif kind=='R_MIPS_26':assert x[off]>>2==y[off]>>2
 else:assert kind=='R_MIPS_32',kind
names=re.findall(r'DEFINE_DMA_ENTRY\((\w+),',(B/'dmadata_table_spec.h').read_text());expected=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())]+['object_jabba','object_bttf','object_kenny','object_shaggy','object_velma','object_daphne','object_scooby','object_fred','object_meowth','object_jimmy','object_mackey'];assert names==expected
intentional={'makerom','dmadata','code','nes_message_data_static','ger_message_data_static','fra_message_data_static','ovl_En_Js','ovl_Boss_Tw','object_tw'};same=[];changed=[];relocated=[];verified=0
for i,name in enumerate(names):
 x=segment(a,i)[2];start,end,y=segment(b,i)
 if y is None:continue
 if name=='makerom':assert y[:16]==unpacked[start:start+16] and y[24:]==unpacked[start+24:end]
 elif name!='dmadata':assert y==unpacked[start:end],name;verified+=1
 if x==y:same.append(name);continue
 if name in intentional:changed.append(dict(segment=name,before_bytes=len(x)if x is not None else 0,after_bytes=len(y)));continue
 assert len(x)==len(y),(name,'size')
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(x,y))if p!=q}):linked_word(x,y,off,ns['_'+name+'SegmentStart']+off,name)
 relocated.append(name)
assert verified==1520
# Every existing compiled message in every language retains exactly its bytes.
def elf_symbols(path):
 d={}
 for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([tTdDrR]) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(path)],text=True),re.M):
  addr,size=int(addr,16),int(size,16)
  if size:d[name]=(addr,size,kind)
 return d
def text_symbols(path):return syms(path)
os=syms(base/'build/pal-1.0/oot-pal-1.0.map')
def compiled(rom,symbols,lang):
 code=segment(rom,names.index('code'))[2];raw=segment(rom,names.index(lang+'_message_data_static'))[2];cb=symbols['_codeSegmentStart'];nt=symbols['sNesMessageEntryTable']-cb;table=symbols[{'nes':'sNesMessageEntryTable','ger':'sGerMessageEntryTable','fra':'sFraMessageEntryTable'}[lang]]-cb;rows=[];i=0
 while True:
  ident=struct.unpack_from('>H',code,nt+i*8)[0]
  if ident==0xffff:break
  if ident not in[0xfffc,0xfffd]:rows.append((f'{ident:04X}',struct.unpack_from('>I',code,(nt+i*8+4)if lang=='nes'else table+i*4)[0]&0xffffff))
  i+=1
 return{ident:raw[p:(rows[j+1][1]if j+1<len(rows)else len(raw))].rstrip(b'\x00')for j,(ident,p)in enumerate(rows)}
for lang in ['nes','ger','fra']:
 xx=compiled(a,os,lang);yy=compiled(b,ns,lang);assert yy.keys()-xx.keys()=={'71C6'}and not(xx.keys()-yy.keys());actual_ids={k for k in xx if xx[k]!=yy[k]};assert actual_ids==(ids if lang=='ger'else set()),(lang,actual_ids)
oldsy=elf_symbols(base/'build/pal-1.0/oot-pal-1.0.elf');newsy=elf_symbols(B/'oot-pal-1.0.elf');_,_,x=segment(a,names.index('code'));_,_,y=segment(b,names.index('code'));count=0;tables={'sNesMessageEntryTable','sGerMessageEntryTable','sFraMessageEntryTable','gObjectTable','gObjectTableSize'}
for name,(addr,size,kind)in oldsy.items():
 if name in tables or not(os['_codeSegmentStart']<=addr<os['_codeSegmentEnd']):continue
 na,nsize,_=newsy[name];assert size==nsize,(name,'size');xx=x[addr-os['_codeSegmentStart']:addr-os['_codeSegmentStart']+size];yy=y[na-ns['_codeSegmentStart']:na-ns['_codeSegmentStart']+size];assert len(xx)==len(yy)==size
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(xx,yy))if p!=q}):linked_word(xx,yy,off,na+off,'code')
 count+=1
# All other Twinrova object data retain bytes or their real linker relocation.
_,_,ox=segment(a,names.index('object_tw'));_,_,ny=segment(b,names.index('object_tw'));object_symbols=0
section=re.search(r'\[\s*(\d+)\] \.\.object_tw\s',subprocess.check_output(['mips-linux-gnu-readelf','-SW',str(B/'oot-pal-1.0.elf')],text=True))[1]
object_names={line.split()[-1]for line in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(B/'oot-pal-1.0.elf')],text=True).splitlines()if len(line.split())==8 and line.split()[6]==section}
for name,(addr,size,kind)in oldsy.items():
 if name not in object_names:continue
 na,nsize,_=newsy[name]
 if name=='gTwinrovaTitleCardTex':assert size==15360 and nsize==24576;continue
 assert size==nsize,(name,'object size');xx=ox[addr-os['_object_twSegmentStart']:addr-os['_object_twSegmentStart']+size];yy=ny[na-ns['_object_twSegmentStart']:na-ns['_object_twSegmentStart']+size]
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(xx,yy))if p!=q}):linked_word(xx,yy,off,na+off,'object_tw')
 object_symbols+=1
# English/French glyphs and their on-screen placement remain native. German
# dimensions obey the unchanged two-load TMEM renderer and its u8 fields.
from PIL import Image
orig=Image.open(R/'tools/originals/twinrova-dialogue/extracted/pal-1.0/assets/objects/object_tw/gTwinrovaTitleCardTex.ia8.png').convert('LA');title=Image.open(O/'extracted/pal-1.0/assets/objects/object_tw/gTwinrovaTitleCardTex.ia8.png').convert('LA');assert title.size==(128,192)
assert orig.crop((0,0,128,40)).tobytes()==title.crop((0,12,128,52)).tobytes()
assert orig.crop((0,80,128,120)).tobytes()==title.crop((0,140,128,180)).tobytes()
meta=json.loads((R/'textures/twinrova-title/title.json').read_text());assert meta['epithet']==edits['605A']['pages'][1]and meta['width']*meta['height']==8192 and 4096%meta['width']==0
# Check private text DMA bounds, including the language tables' following pointer.
def data(name):addr,size,_=newsy[name];return y[addr-ns['_codeSegmentStart']:addr-ns['_codeSegmentStart']+size]
entries=list(struct.iter_unpack('>HBBI',data('sNesMessageEntryTable')))
for ident,nextid in [(0x71C5,0x71C6),(0x71C6,0x71B2)]:
 idx=[e[0]for e in entries].index(ident);assert entries[idx+1][0]==nextid
 for lang,table in [('nes','sNesMessageEntryTable'),('ger','sGerMessageEntryTable'),('fra','sFraMessageEntryTable')]:
  ptr=entries[idx][3]if lang=='nes'else struct.unpack_from('>I',data(table),idx*4)[0];nxt=entries[idx+1][3]if lang=='nes'else struct.unpack_from('>I',data(table),(idx+1)*4)[0];assert 0<nxt-ptr<1280
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),compressed_segments_verified=verified,native_core_symbols_verified=count,changed_german_ids=sorted(ids),added_german_ids=['71C6'],all_other_messages_all_languages_preserved=True,native_controls_and_fixed_times_preserved=True,actor_changes=['Child-only German carpet offer selection; native price, item, timers and choices unchanged.','Twinrova: German title at native fusion wink; native combat and cutscene timers unchanged.'],twinrova_unchanged_object_symbols=object_symbols,twinrova_title=meta,text_buffers=buffers,intentional_segments=changed,relocation_only_segments=relocated,identical_segments=same)
(B/'gerudo-dialogue-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments,',count,'native core symbols,',len(ids),'revised messages, one new age-specific message;',len(edits),'custom messages within buffers.')

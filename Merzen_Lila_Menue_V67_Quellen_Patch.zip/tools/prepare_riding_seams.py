"""Bake source-weighted trouser seams for Bean's close-up riding pose only.

The N64 model uses rigid skinning. At bent hips/knees the supplied FBX needs
its original blended weights, otherwise single triangles bridge hard joints.
Bake that correction in each vertex's existing bone space. Animation, source
segment lengths and the regular model remain untouched.
"""
import argparse,json,re
from pathlib import Path
import numpy as np
from rebind_bean import rotation_between
R=Path(__file__).resolve().parent

def rotation(v):
 x,y,z=np.array(v)*np.pi/32768;cx,cy,cz=np.cos([x,y,z]);sx,sy,sz=np.sin([x,y,z])
 return np.array([[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]])

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('oot',type=Path);args=ap.parse_args()
 m=json.loads((R/'bean_bound.json').read_text());src=json.loads((R/'bean_source.json').read_text())
 a=args.oot/'extracted/pal-1.0/assets/objects/object_opening_demo1';name='object_opening_demo1_Anim_002574';header=(a/(name+'.inc.c')).read_text()
 frame_symbol=re.search(r'(\w+), // frameData',header)[1];joint_symbol=re.search(r'(\w+), // jointIndices',header)[1]
 data=[int(x,16) for x in re.findall(r'-?0x[0-9A-Fa-f]+',(a/(frame_symbol+'.inc.c')).read_text())];data=[x-65536 if x>=32768 else x for x in data]
 inds=[int(x,0) for x in re.findall(r'0x[0-9A-Fa-f]+|\b\d+\b',re.sub(r'//[^\n]*','',(a/(joint_symbol+'.inc.c')).read_text()))]
 j=[[data[i] for i in inds[n:n+3]] for n in range(0,len(inds),3)];mat=[]
 for i,b in enumerate(m['bones']):
  t=np.eye(4);t[:3,:3]=rotation(j[i+1]);t[:3,3]=j[0] if i==0 else b['p'];mat.append(t if b['parent'] is None else mat[b['parent']]@t)
 names={'Hips':'Pelvis','LeftUpLeg':'LeftThigh','LeftLeg':'LeftShin','LeftFoot':'LeftFoot','LeftToeBase':'LeftFoot','LeftToe_End':'LeftFoot','RightUpLeg':'RightThigh','RightLeg':'RightShin','RightFoot':'RightFoot','RightToeBase':'RightFoot','RightToe_End':'RightFoot'}
 bone_sources={'Pelvis':'Hips','LeftThigh':'LeftUpLeg','LeftShin':'LeftLeg','LeftFoot':'LeftFoot','RightThigh':'RightUpLeg','RightShin':'RightLeg','RightFoot':'RightFoot'}
 transforms={}
 for dest,source in bone_sources.items():
  b=m['target'][dest];ref=np.array(m['bones'][b]['matrix'])[:3,:3]
  direction=np.array(src['bones'][source]['tail'])-np.array(src['bones'][source]['head'])
  pose=np.eye(3) if dest=='Pelvis' or dest.endswith('Foot') else rotation_between(direction,ref[:,0])
  local=ref.T@pose;anchor=np.array(src['bones'][source]['head'])*m['scale']
  t=np.eye(4);t[:3,:3]=local;t[:3,3]=-local@anchor;transforms[dest]=mat[b]@t
 corrections={}
 for i,v in enumerate(m['vertices']):
  if not 1<=v['bone']<=7:continue
  original=src['vertices'][v['source_vertex']];weights={}
  for name,w in original['weights']:
   if name in names:weights[names[name]]=weights.get(names[name],0)+w
  weights={k:w for k,w in weights.items() if w>.025}
  if len(weights)<2 or any(k.endswith('Foot') for k in weights):continue
  total=sum(weights.values());p=np.array(original['position']+[1.0]);p[:3]*=m['scale']
  point=sum(transforms[k]@p*w/total for k,w in weights.items());local=np.linalg.inv(mat[v['bone']])@point
  # Convert the existing local normal back through its source mapping.
  own=next(k for k in bone_sources if m['target'][k]==v['bone'])
  source_normal=np.linalg.inv(transforms[own][:3,:3])@mat[v['bone']][:3,:3]@np.array(v['normal'],float)
  normal=sum(transforms[k][:3,:3]@source_normal*w/total for k,w in weights.items());normal=mat[v['bone']][:3,:3].T@normal;normal=normal/np.linalg.norm(normal)*127
  corrections[str(i)]={'position':np.rint(local[:3]).astype(int).tolist(),'normal':np.rint(normal).astype(int).tolist()}
 (R/'bean_riding_seams.json').write_text(json.dumps({'reference_animation':name,'reference_frame':0,'scope':'Hyrule Field flashback only','vertices':corrections},separators=(',',':'))+'\n')
 print('Baked',len(corrections),'weighted hip/knee seam vertices; no whole-body scaling or standing edits.')
if __name__=='__main__':main()

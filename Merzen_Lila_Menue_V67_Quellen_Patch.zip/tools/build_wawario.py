"""Adult-only Wawario brothers in the fortress jail and outside the valley tent."""
from pathlib import Path
import json,re,sys
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/wawario'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
models={k:json.loads((R/f'tools/{k}_source.json').read_text())for k in ['wawario','wawaluigi']}
for key,prefix,scene,pos,yaw,param,lists in [
 ('wawario','Wawario','spot12',[300,733,-2980],-10000,'0x3F7B',[('0035C',30),('0059C',31)]),
 ('wawaluigi','Wawaluigi','spot09',[-1350,15,-400],8192,'0x3F7C',[('00558',51)])]:
 d=O/'extracted/pal-1.0/assets/scenes/overworld'/scene
 inc=key+'_model.inc.c';g=emit(models[key],R/'models'/key,prefix,rigged=True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');(d/inc).write_text(g)
 p=d/f'{scene}_room_0.c';p.write_text(original(p)+f'\n#include "{inc}"\n')
 p=d/f'{scene}_room_0.h';h=original(p)
 for addr,count in lists:
  p=next(d.glob(f'{scene}_room_0_*AltHeaders*{addr}_ActorEntryList.inc.c'));s=original(p);assert s.count('ACTOR_')==count
  p.write_text(s+'    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, { 0, '+str(yaw)+', 0 }, '+param+' }, /* adult friendly '+key+' */\n')
  h,n=re.subn(r'(#define LENGTH_'+re.escape(p.stem.replace('.inc',''))+r' )'+str(count)+r'\b',lambda m:m[1]+str(count+1),h);assert n==1
 (d/f'{scene}_room_0.h').write_text(h)
# Regenerate only Triangle Guy's corrected model; no boss, placement or actor-list edits.
d=O/'extracted/pal-1.0/assets/scenes/dungeons/ganon_demo';m=json.loads((R/'tools/triangle_source.json').read_text());(d/'triangle_model.inc.c').write_text(emit(m,R/'models/triangle','TriangleGuy').replace('gTriangleGuyBodyDL','gTriangleGuyDL'))
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);helper=(R/'tools/wawario_actor.inc.c').read_text()
for key in models:helper=helper.replace(key.upper()+'_PIVOTS',', '.join('{'+','.join(map(str,b['position']))+'}'for b in models[key]['bones']))
needle='void ElfMsg2_Init(Actor* thisx, PlayState* play) {';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
for action in ['Init','Update']:
 needle=f'    if (ElfMsg2_IsSuperhero(thisx, play)) {{\n        ElfMsg2_{action}Superhero';assert s.count(needle)==1
 s=s.replace(needle,f'    if (ElfMsg2_IsWawarioBros(thisx, play)) {{\n        ElfMsg2_{action}WawarioBros(this, play);\n        return;\n    }}\n'+needle)
needle='ElfMsg2_IsPepsiman(thisx, play) || ElfMsg2_IsSuperhero(thisx, play))';assert s.count(needle)==1;s=s.replace(needle,needle[:-1]+' || ElfMsg2_IsWawarioBros(thisx, play))');p.write_text(s)
print('Adult headers only; 4 own pose matrices/NPC; Triangle Guy mirrors retained.')

"""Apply the size follow-up after build_yellow_guy.py without replaying older gameplay patches."""
from pathlib import Path
import sys,json,re,subprocess
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/character_sizes'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
wa=json.loads((R/'tools/wawaluigi_source.json').read_text());wallace=json.loads((R/'tools/wallace_adult_source.json').read_text())
assert wa['height_game_units']==100 and wallace['height_game_units']==90
for m,directory,prefix,name in [(wa,'assets/scenes/overworld/spot09','Wawaluigi','wawaluigi_model.inc.c'),(wallace,'assets/objects/object_du','AdultWallace','wallace_adult_model.inc.c'),(wallace,'assets/scenes/dungeons/HIDAN','PrisonWallace','wallace_adult_model.inc.c')]:
 key='wawaluigi'if prefix=='Wawaluigi'else'wallace-adult'
 code=emit(m,R/'models'/key,prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL')
 (O/'extracted/pal-1.0'/directory/name).write_text(code)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p)
values=', '.join('{'+','.join(map(str,b['position']))+'}'for b in wa['bones'])
s,n=re.subn(r'(static Vec3f wawaluigiPivots\[4\] = \{).*?(\};)',lambda q:q[1]+' '+values+' '+q[2],s,count=1);assert n==1
s=s.replace('orange ? 65 : 100','orange ? 65 : 80');p.write_text(s)
p=O/'src/overlays/actors/ovl_En_Go2/z_en_go2.c';s=original(p)
needle='''        Actor_SetFocus(&this->actor, 99.0f);
        this->collider.dim.height = 105;
        this->collider.dim.radius = 18;'''
replacement='''        Actor_SetFocus(&this->actor, 81.0f);
        this->collider.dim.height = 86;
        this->collider.dim.radius = 15;'''
assert needle in s or replacement in s;s=s.replace(needle,replacement);p.write_text(s)
camera='''    this->subCamAt.z = this->actor.world.pos.z;
    Play_SetCameraAtEye(play, this->subCamId, &this->subCamAt, &this->subCamEye);'''
fitted='''    this->subCamAt.z = this->actor.world.pos.z;
    if (EnGo2_IsAdultWallace(this, play)) {
        this->subCamEye.x = this->actor.world.pos.x + (this->subCamEye.x - this->actor.world.pos.x) * 1.9f;
        this->subCamEye.z = this->actor.world.pos.z + (this->subCamEye.z - this->actor.world.pos.z) * 1.9f;
        this->subCamEye.y = this->actor.world.pos.y + 40.0f;
        this->subCamAt.y = this->actor.world.pos.y + 48.0f;
    }
    Play_SetCameraAtEye(play, this->subCamId, &this->subCamAt, &this->subCamEye);'''
assert s.count(camera)==1;s=s.replace(camera,fitted);p.write_text(s)
for overlay in ['ovl_En_Go2','ovl_Demo_Du']:
 (O/'src/overlays/actors'/overlay/'wallace_adult_draw.inc.c').write_bytes((R/'tools/wallace_adult_draw.inc.c').read_bytes())
subprocess.run([sys.executable,str(R/'tools/build_bowling_sage.py'),str(O),'--model-only'],check=True)
print('Wawaluigi 100; adult Wallace 90; attention/collider and seated sage adjusted; existing gameplay hooks retained.')

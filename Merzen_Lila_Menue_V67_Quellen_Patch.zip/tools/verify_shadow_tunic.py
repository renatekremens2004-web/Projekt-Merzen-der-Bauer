"""Differentially verify the cumulative Schattengewand build.

Run with the activated PAL toolchain:
  python tools/verify_shadow_tunic.py OOT /workspace/shadow-tunic
The baseline is the published, hatless Doof/Shrek/Monopoly build.
"""
from pathlib import Path
import csv
import hashlib
import json
import re
import struct
import subprocess
import sys

from ipl3checksum import CICKind, calculateChecksum
from build_story import messages, controls
from verify_story import segment, check_buffers
from verify_bowling_sage_revision import function_bodies

R = Path(__file__).resolve().parent.parent
O = Path(sys.argv[1]).resolve()
W = Path(sys.argv[2]).resolve()
B = O / 'build/pal-1.0'
base = W / 'baseline'
originals = R / 'tools/originals/shadow-tunic'
before = (base / 'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes()
after = (B / 'oot-pal-1.0-compressed.z64').read_bytes()
unpacked = (B / 'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(before).hexdigest() == '89b941e2ca53f5d06d18987a53c82d2b369b26d120a35672a4f19e4bddde1ad9'
assert len(after) == 41943040
assert struct.unpack_from('>II', after, 16) == calculateChecksum(after, CICKind.CIC_X105)

# No previously existing message changes in any language.
chapter = json.loads((R / 'story/shadow_tunic_de.json').read_text())['messages']
assert set(chapter) == {'71DC'}
old_messages = messages((base / 'extracted/pal-1.0/text/message_data.h').read_text())
new_messages = messages((O / 'extracted/pal-1.0/text/message_data.h').read_text())
assert new_messages.keys() - old_messages.keys() == {'71DC'}
assert not old_messages.keys() - new_messages.keys()
for ident, old in old_messages.items():
    assert old['header'] == new_messages[ident]['header'], ident
    assert [p[2] for p in old['parts']] == [p[2] for p in new_messages[ident]['parts']], ident
assert controls('ITEM_ICON(ITEM_TUNIC_KOKIRI) ' + old_messages['0052']['parts'][2][2]) == controls(new_messages['71DC']['parts'][2][2])
edits = {k: e for p in (R / 'story').glob('*.json')
         for k, e in json.loads(p.read_text())['messages'].items()}
assert len(edits) == 1155
buffers = check_buffers(B, edits)

def norm(s):
    return ''.join(s.split())

source_counts = {}
def verify_source(rel, changes):
    old = function_bodies((originals / rel).read_text())
    new = function_bodies((O / rel).read_text())
    assert old.keys() == new.keys(), (rel, new.keys() - old.keys(), old.keys() - new.keys())
    assert {k for k in old if norm(old[k]) != norm(new[k])} == set(changes), rel
    for name in old:
        actual = norm(new[name])
        for item in changes.get(name, []):
            replacement, original = item[:2]
            expected_count = item[2] if len(item) == 3 else 1
            replacement = norm(replacement)
            assert actual.count(replacement) == expected_count, (rel, name, replacement)
            actual = actual.replace(replacement, norm(original))
        assert actual == norm(old[name]), (rel, name, 'unexplained source change')
    source_counts[rel] = len(old)

verify_source('src/code/z_parameter.c', {'Health_ChangeBy': [
    ('(gSaveContext.save.info.playerData.isDoubleDefenseAcquired || SHADOW_TUNIC_ACTIVE())',
     'gSaveContext.save.info.playerData.isDoubleDefenseAcquired'),
]})
verify_source('src/code/z_player_lib.c', {'Player_DrawImpl': [
    ('''{
        static Color_RGB8 shadowColor = { 20, 20, 20 };
        color = tunic == PLAYER_TUNIC_KOKIRI && SHADOW_TUNIC_OWNED() ? &shadowColor : &sTunicColors[tunic];
    }''', 'color = &sTunicColors[tunic];'),
]})
verify_source('src/code/z_draw.c', {})
verify_source('src/code/z_message.c', {'Message_LoadItemIcon': [
    ('''if (itemId == ITEM_TUNIC_KOKIRI && SHADOW_TUNIC_OWNED()) {
            ShadowTunic_RecolorIcon(msgCtx->textboxSegment + MESSAGE_STATIC_TEX_SIZE);
        }''', ''),
]})
verify_source('src/overlays/misc/ovl_kaleido_scope/z_kaleido_scope.c', {'KaleidoScope_Update': [
    ('''if (SHADOW_TUNIC_OWNED()) {
                ShadowTunic_RecolorIcon((u8*)pauseCtx->iconItemSegment + ITEM_TUNIC_KOKIRI * ITEM_ICON_SIZE);
            }''', '', 2),
]})
verify_source('src/overlays/actors/ovl_player_actor/z_player.c', {
    'Player_ActionHandler_2': [
        ('''((Item_CheckObtainability(giEntry->itemId) == ITEM_NONE) ||
                     (this->getItemId == -GI_SHADOW_TUNIC))''',
         '(Item_CheckObtainability(giEntry->itemId) == ITEM_NONE)'),
    ],
    'func_8084DFF4': [
        ('this->getItemId == GI_SHADOW_TUNIC ? 0x71DC : giEntry->textId', 'giEntry->textId'),
        ('if (this->getItemId == GI_SHADOW_TUNIC) Player_ReceiveShadowTunic(play, this);', ''),
    ],
})
verify_source('src/overlays/actors/ovl_En_Box/z_en_box.c', {'EnBox_Init': [
    ('''if (play->sceneId == SCENE_BOTTOM_OF_THE_WELL && thisx->params == 0x0FC0 &&
        gSaveContext.language != LANGUAGE_GER) {
        this->dyna.bgId = BG_ACTOR_MAX;
        Actor_Kill(thisx);
        return;
    }''', ''),
]})
assert (O / 'include/shadow_tunic.h').read_bytes() == (R / 'tools/shadow_tunic.h').read_bytes()
for rel in ['src/code/shadow_tunic_icon.inc.c', 'src/overlays/misc/ovl_kaleido_scope/shadow_tunic_icon.inc.c']:
    assert (O / rel).read_bytes() == (R / 'tools/shadow_tunic_icon.inc.c').read_bytes()
assert (O / 'src/overlays/actors/ovl_player_actor/shadow_tunic_player.inc.c').read_bytes() == (R / 'tools/shadow_tunic_player.inc.c').read_bytes()
assert (O / 'src/overlays/actors/ovl_player_actor/quick_iron_boots.inc.c').read_bytes() == (R / 'tools/quick_iron_boots.inc.c').read_bytes()
item_header = (O / 'include/item.h').read_text()
item_header = item_header.replace('    /* 0x7E */ GI_SHADOW_TUNIC,\n    /* 0x7F */ GI_MAX', '    /* 0x7E */ GI_MAX')
item_header = item_header.replace('    /* 0x75 */ GID_SHADOW_TUNIC,\n    /* 0x76 */ GID_MAX', '    /* 0x75 */ GID_MAX')
assert item_header == (originals / 'include/item.h').read_text()

def syms(path):
    d = {}
    for a, name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b', path.read_text()):
        d.setdefault(name, int(a, 16))
    return d

def elf_symbols(path):
    d = {}
    output = subprocess.check_output(['mips-linux-gnu-nm', '-S', str(path)], text=True)
    for addr, size, kind, name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([tTdDrR]) (\S+)$', output, re.M):
        addr, size = int(addr, 16), int(size, 16)
        if size:
            d[name] = (addr, size, kind)
    return d

old_map = syms(base / 'build/pal-1.0/oot-pal-1.0.map')
new_map = syms(B / 'oot-pal-1.0.map')
old_sy = elf_symbols(base / 'build/pal-1.0/oot-pal-1.0.elf')
new_sy = elf_symbols(B / 'oot-pal-1.0.elf')
section_numbers = {number: name for number, name in re.findall(
    r'\[\s*(\d+)\] \.\.(\w+)\s',
    subprocess.check_output(['mips-linux-gnu-readelf', '-SW', str(base / 'build/pal-1.0/oot-pal-1.0.elf')], text=True))}
symbol_sections = {fields[-1]: section_numbers.get(fields[6])
                   for line in subprocess.check_output(['mips-linux-gnu-readelf', '-sW', str(base / 'build/pal-1.0/oot-pal-1.0.elf')], text=True).splitlines()
                   if len(fields := line.split()) == 8}
rels = {}
section = None
for line in subprocess.check_output(['mips-linux-gnu-readelf', '-rW', str(B / 'oot-pal-1.0.elf')], text=True).splitlines():
    match = re.match(r"Relocation section '\.rel\.\.([^']+)'", line)
    if match:
        section = match[1]
        rels.setdefault(section, {})
    match = re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)', line)
    if match and section:
        rels[section][int(match[1], 16)] = (match[2], match[3])

bound_changes = []
bound_sections = {'code', 'ovl_player_actor', 'ovl_En_Elf', 'ovl_En_Fish', 'ovl_En_Insect', 'ovl_En_Ice_Hono'}
def linked_word(x, y, offset, address, name):
    assert offset + 4 <= len(x) and offset + 4 <= len(y), (name, offset)
    old_word, new_word = struct.unpack_from('>I', x, offset)[0], struct.unpack_from('>I', y, offset)[0]
    if (name in bound_sections and old_word >> 16 == new_word >> 16 and
            old_word & 0xFFFF == 0x7E and new_word & 0xFFFF == 0x7F and
            old_word >> 26 in {9, 10, 11}):
        bound_changes.append(dict(section=name, address=hex(address), before=hex(old_word), after=hex(new_word)))
        return
    relocation = rels.get(name, {}).get(address)
    assert relocation, (name, hex(address), hex(old_word), hex(new_word), 'unexplained difference')
    kind, target = relocation
    if kind in ['R_MIPS_HI16', 'R_MIPS_LO16', 'R_MIPS_16']:
        assert x[offset:offset + 2] == y[offset:offset + 2], (name, target)
    elif kind == 'R_MIPS_26':
        assert x[offset] >> 2 == y[offset] >> 2
    else:
        assert kind == 'R_MIPS_32', kind

names = re.findall(r'DEFINE_DMA_ENTRY\((\w+),', (B / 'dmadata_table_spec.h').read_text())
expected = [r['Name'] for r in csv.DictReader((O / 'baseroms/pal-1.0/segments.csv').open())] + [
    'object_jabba', 'object_bttf', 'object_kenny', 'object_shaggy', 'object_velma', 'object_daphne',
    'object_scooby', 'object_fred', 'object_meowth', 'object_jimmy', 'object_mackey',
    'object_doof', 'object_doofevil', 'object_shrek', 'object_monopoly',
]
assert names == expected
intentional = {'makerom', 'dmadata', 'code', 'nes_message_data_static', 'ger_message_data_static',
               'fra_message_data_static', 'ovl_player_actor', 'ovl_En_Box', 'ovl_kaleido_scope',
               'HAKAdanCH_room_3', 'object_gi_clothes'}
same, changed, relocated = [], [], []
verified = 0
old_sections, new_sections = {}, {}
for i, name in enumerate(names):
    x = segment(before, i)[2]
    start, end, y = segment(after, i)
    old_sections[name], new_sections[name] = x, y
    if y is None:
        continue
    if name == 'makerom':
        assert y[:16] == unpacked[start:start + 16] and y[24:] == unpacked[start + 24:end]
    elif name != 'dmadata':
        assert y == unpacked[start:end], name
        verified += 1
    if x == y:
        same.append(name)
        continue
    if name in intentional:
        changed.append(dict(segment=name, before_bytes=len(x), after_bytes=len(y)))
        continue
    assert len(x) == len(y), (name, 'size')
    for off in sorted({j // 4 * 4 for j, (p, q) in enumerate(zip(x, y)) if p != q}):
        linked_word(x, y, off, new_map['_' + name + 'SegmentStart'] + off, name)
    relocated.append(name)
assert verified == 1524

# Compare every old native symbol, allowing only the source-audited functions/tables.
counts = {}
def section_symbols(name, allowed):
    x, y = old_sections[name], new_sections[name]
    count = 0
    lo, hi = old_map['_' + name + 'SegmentStart'], old_map['_' + name + 'SegmentEnd']
    for symbol, (addr, size, kind) in old_sy.items():
        if symbol in allowed or symbol_sections.get(symbol) != name or not lo <= addr < hi:
            continue
        na, nsize, _ = new_sy[symbol]
        assert size == nsize, (name, symbol, 'size')
        xx = x[addr - lo:addr - lo + size]
        yy = y[na - new_map['_' + name + 'SegmentStart']:na - new_map['_' + name + 'SegmentStart'] + size]
        assert len(xx) == len(yy) == size, (name, symbol, 'bounds')
        for off in sorted({j // 4 * 4 for j, (p, q) in enumerate(zip(xx, yy)) if p != q}):
            linked_word(xx, yy, off, na + off, name)
        count += 1
    counts[name] = count

section_symbols('code', {'Health_ChangeBy', 'Player_DrawImpl', 'Message_LoadItemIcon', 'sDrawItemTable',
                         'sNesMessageEntryTable', 'sGerMessageEntryTable', 'sFraMessageEntryTable'})
section_symbols('ovl_player_actor', {'Player_ActionHandler_2', 'func_8084DFF4', 'sGetItemTable'})
section_symbols('ovl_En_Box', {'EnBox_Init'})
section_symbols('ovl_kaleido_scope', {'KaleidoScope_Update'})
section_symbols('object_gi_clothes', set())
section_symbols('HAKAdanCH_room_3', {'HAKAdanCH_room_3', 'HAKAdanCH_room_3_0300004C_ActorEntryList'})

def symbol_data(symbol, old=False, section='code'):
    symbols, mapping, sections = (old_sy, old_map, old_sections) if old else (new_sy, new_map, new_sections)
    addr, size, _ = symbols[symbol]
    offset = addr - mapping['_' + section + 'SegmentStart']
    return sections[section][offset:offset + size]

# IDO omits this static table's local symbol. Its unique first two native
# entries identify it without depending on a guessed link address.
# GI_BOMBS_5, GI_DEKU_NUTS_5; each is the original six-byte GetItemEntry.
get_prefix = bytes.fromhex('8e59e03200ce8c0cee3400bb')
assert old_sections['ovl_player_actor'].count(get_prefix) == 1
assert new_sections['ovl_player_actor'].count(get_prefix) == 1
old_get_offset = old_sections['ovl_player_actor'].index(get_prefix)
new_get_offset = new_sections['ovl_player_actor'].index(get_prefix)
old_get = old_sections['ovl_player_actor'][old_get_offset:old_get_offset + 125 * 6]
new_get = new_sections['ovl_player_actor'][new_get_offset:new_get_offset + 126 * 6]
assert new_get[:-6] == old_get
assert struct.unpack('>BBBBH', new_get[-6:]) == (0x41, 0x80, 0x76, 0x52, 0xF2)
old_draw = symbol_data('sDrawItemTable', True)
new_draw = symbol_data('sDrawItemTable')
assert len(new_draw) == len(old_draw) + 36
for off in sorted({j // 4 * 4 for j, (p, q) in enumerate(zip(old_draw, new_draw)) if p != q}):
    linked_word(old_draw, new_draw, off, new_sy['sDrawItemTable'][0] + off, 'code')
assert len(new_sections['object_gi_clothes']) - len(old_sections['object_gi_clothes']) == 64
old_actors = symbol_data('HAKAdanCH_room_3_0300004C_ActorEntryList', True, 'HAKAdanCH_room_3')
new_actors = symbol_data('HAKAdanCH_room_3_0300004C_ActorEntryList', False, 'HAKAdanCH_room_3')
assert new_actors[:-16] == old_actors
assert struct.unpack('>HhhhhhhH', new_actors[-16:]) == (0xA, 880, 0, -1230, 0, -32768, 0, 0xFC0)

def compiled(rom_sections, symbols, lang):
    code, raw = rom_sections['code'], rom_sections[lang + '_message_data_static']
    cb = symbols['_codeSegmentStart']
    nt = symbols['sNesMessageEntryTable'] - cb
    table = symbols[{'nes': 'sNesMessageEntryTable', 'ger': 'sGerMessageEntryTable', 'fra': 'sFraMessageEntryTable'}[lang]] - cb
    rows, index = [], 0
    while True:
        ident = struct.unpack_from('>H', code, nt + index * 8)[0]
        if ident == 0xFFFF:
            break
        if ident not in {0xFFFC, 0xFFFD}:
            ptr = struct.unpack_from('>I', code, (nt + index * 8 + 4) if lang == 'nes' else table + index * 4)[0]
            rows.append((f'{ident:04X}', ptr & 0xFFFFFF))
        index += 1
    return {ident: raw[p:(rows[j + 1][1] if j + 1 < len(rows) else len(raw))].rstrip(b'\0')
            for j, (ident, p) in enumerate(rows)}

for language in ['nes', 'ger', 'fra']:
    x, y = compiled(old_sections, old_map, language), compiled(new_sections, new_map, language)
    assert y.keys() - x.keys() == {'71DC'} and not x.keys() - y.keys(), language
    assert all(x[k] == y[k] for k in x), language

message_entries = list(struct.iter_unpack('>HBBI', symbol_data('sNesMessageEntryTable')))
for ident, next_id in [(0x71DB, 0x71DC), (0x71DC, 0x71B2)]:
    idx = [e[0] for e in message_entries].index(ident)
    assert message_entries[idx + 1][0] == next_id
    for language, table in [('nes', 'sNesMessageEntryTable'), ('ger', 'sGerMessageEntryTable'), ('fra', 'sFraMessageEntryTable')]:
        ptr = message_entries[idx][3] if language == 'nes' else struct.unpack_from('>I', symbol_data(table), idx * 4)[0]
        nxt = message_entries[idx + 1][3] if language == 'nes' else struct.unpack_from('>I', symbol_data(table), (idx + 1) * 4)[0]
        assert 0 < nxt - ptr < 1280, (ident, language)

assert {b['section'] for b in bound_changes} >= {'code', 'ovl_En_Elf', 'ovl_En_Fish', 'ovl_En_Insect', 'ovl_En_Ice_Hono'}
report = dict(
    rom_sha256=hashlib.sha256(after).hexdigest(), baseline_sha256=hashlib.sha256(before).hexdigest(),
    compressed_segments_verified=verified, unchanged_native_symbols_verified=counts,
    source_functions_verified=source_counts, gi_max_bound_changes=bound_changes,
    all_existing_messages_all_languages_byte_identical=True, added_ids=['71DC'],
    text_buffers=buffers, native_chest_and_get_item_tables_extended_without_replacing_entries=True,
    save_structure_unchanged_and_free_flag_1ce_used=True,
    only_equipped_shadow_kokiri_tunic_halves_ordinary_damage=True, native_double_defense_not_stacked=True,
    quick_boots_and_all_existing_custom_guests_preserved=True,
    native_tunic_palettes_and_original_goron_zora_item_materials_preserved=True,
    object_gi_clothes_extra_bytes=64, no_new_object_slots_or_models=True,
    intentional_segments=changed, relocation_or_gi_bound_only_segments=relocated, identical_segments=same,
)
(B / 'shadow-tunic-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print('Verified', verified, 'segments,', sum(counts.values()), 'old native symbols, all 1,155 text buffers; new native chest/GI and Kokiri-only protection isolated.')

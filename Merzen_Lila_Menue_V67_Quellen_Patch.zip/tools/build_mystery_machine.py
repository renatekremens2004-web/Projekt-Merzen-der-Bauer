"""Final builder after build_mystery_inc.py: child Kakariko van after adult song lesson."""
from pathlib import Path
import json,re,sys
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/mystery-machine'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
D=O/'extracted/pal-1.0/assets/scenes/overworld/spot01';m=json.loads((R/'tools/mysterymachine_source.json').read_text());(D/'mystery_machine_model.inc.c').write_text(emit(m,R/'models/mysterymachine','MysteryMachine').replace('gMysteryMachineBodyDL','gMysteryMachineDL'))
p=D/'spot01_room_0.c';p.write_text(original(p)+'\n#include "mystery_machine_model.inc.c"\n');p=D/'spot01_room_0.h';h=original(p)
for fragment in ['03000084','03000C98']:
 p=next(D.glob(f'spot01_room_0_*{fragment}_ActorEntryList.inc.c'));s=original(p);n=s.count('ACTOR_');p.write_text(s+'    { ACTOR_ELF_MSG2, { -2300, 138, 1130 }, { 0, 16384, 0 }, 0x3F8C }, /* parked after adult Song of Storms lesson */\n');macro='LENGTH_'+p.name.replace('.inc.c','');h,k=re.subn(rf'(#define {macro} ){n}\b',lambda q:q[1]+str(n+1),h);assert k==1
(D/'spot01_room_0.h').write_text(h)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);needle='/* Five independently loaded N64 guests.';assert s.count(needle)==1;s=s.replace(needle,(R/'tools/mystery_machine_actor.inc.c').read_text()+'\n'+needle)
for action in ['Init','Update']:
 needle=f'void ElfMsg2_{action}(Actor* thisx, PlayState* play) {{\n    ElfMsg2* this = (ElfMsg2*)thisx;';assert s.count(needle)==1;s=s.replace(needle,needle+f'\n    if (ElfMsg2_IsMysteryMachine(thisx, play)) {{\n        ElfMsg2_{action}MysteryMachine(this, play);\n        return;\n    }}')
p.write_text(s);print('Mystery Machine:',len(m['triangles']),'triangles,',m['dimensions_game_units'],'units; child day/night only, permanent Song of Storms ownership; no extra object slot.')

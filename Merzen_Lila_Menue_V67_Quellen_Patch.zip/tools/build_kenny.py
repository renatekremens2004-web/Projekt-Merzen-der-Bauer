"""Last builder after build_bttf.py: two lightweight room-local Kenny states."""
from pathlib import Path
import json,re,sys,subprocess
from n64_model import emit
from build_story import add_private_message,messages,Layout,rewrite,closing
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/kenny'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
def write_if_changed(p,text):
 if not p.exists() or p.read_text()!=text:p.write_text(text)
D=O/'extracted/pal-1.0/assets/scenes/dungeons/HAKAdan'
A=O/'extracted/pal-1.0/assets/objects/object_kenny';A.mkdir(parents=True,exist_ok=True)
code='#include "ultra64.h"\n#include "animation.h"\n#include "gfx.h"\n'
for key,prefix,room,pos,param in [('kenny','Kenny',2,[-285,-63,500],'0x3F85'),('kenny_dead','KennyDead',6,[3225,-542,-600],'0x3F86')]:
 model=json.loads((R/'tools'/f'{key}_source.json').read_text());code+=emit(model,R/'models'/key,prefix).replace('g'+prefix+'BodyDL','g'+prefix+'DL')
 # The room buffer is a double buffer. Keep model bytes in the already
 # reserved object bank instead of enlarging both room-buffer halves.
 p=D/f'HAKAdan_room_{room}.c';p.write_text(original(p))
 p=next(D.glob(f'HAKAdan_room_{room}_*ActorEntryList.inc.c'));s=original(p);count=s.count('ACTOR_');p.write_text(s+'    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, { 0, 0, 1 }, '+param+' }, /* '+key+' */\n')
 p=D/f'HAKAdan_room_{room}.h';s=original(p);s,n=re.subn(rf'(#define LENGTH_HAKAdan_room_{room}_\w+_ActorEntryList ){count}\b',lambda m:m[1]+str(count+1),s,count=1);assert n==1
 objlist=next(D.glob(f'HAKAdan_room_{room}_*ObjectList.inc.c'));obj=original(objlist);objects=obj.count('OBJECT_');objlist.write_text(obj+'    OBJECT_KENNY, /* shared low-poly alive/dead models */\n')
 s,n=re.subn(rf'(#define LENGTH_HAKAdan_room_{room}_\w+_ObjectList ){objects}\b',lambda m:m[1]+str(objects+1),s,count=1);assert n==1;p.write_text(s)
(A/'object_kenny.c').write_text(code)
p=O/'include/tables/object_table.h';write_if_changed(p,original(p)+'\n/* 0x0194 */ DEFINE_OBJECT(object_kenny, OBJECT_KENNY)\n')
p=O/'spec/spec';write_if_changed(p,original(p)+'\nbeginseg\n    name "object_kenny"\n    compress\n    romalign 0x1000\n    include "$(BUILD_DIR)/assets/objects/object_kenny/object_kenny.o"\n    number 6\nendseg\n')
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);needle='/* Private child-castle tableau:';assert s.count(needle)==1;s=s.replace(needle,(R/'tools/kenny_actor.inc.c').read_text()+'\n'+needle)
for action in ['Init','Update']:
 needle=f'void ElfMsg2_{action}(Actor* thisx, PlayState* play) {{\n    ElfMsg2* this = (ElfMsg2*)thisx;';assert s.count(needle)==1;s=s.replace(needle,needle+f'\n    if (ElfMsg2_IsKenny(thisx, play)) {{\n        ElfMsg2_{action}Kenny(this, play);\n        return;\n    }}')
p.write_text(s)
# Reducing the over-detailed 24-unit LEGO decoration restores room-buffer
# reserve throughout the temple. Keep the native object allocator unchanged.
p=O/'src/code/z_scene.c';write_if_changed(p,original(p))
subprocess.run([sys.executable,str(R/'tools/build_xwing.py'),str(O)],check=True)
entries={'71B8':dict(new_message=True,insert_before='71B2',native_template='0022',reserve_text='Mmph.',color='LIGHTBLUE',pages=['Ich verstehe den Typen nicht, der nuschelt zu sehr.']), '71B9':dict(new_message=True,insert_before='71B2',native_template='0022',reserve_text='Kenny.',color='LIGHTBLUE',pages=['Ihr habt Kenny getötet, ihr Schweine!'])}
(R/'story/kenny_de.json').write_text(json.dumps(dict(chapter='Kenny im Schattentempel',orthography='de-vor-1996',messages=entries),ensure_ascii=False,indent=2)+'\n')
p=O/'extracted/pal-1.0/text/message_data.h';s=p.read_text();native=messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
for ident,entry in entries.items():
 s=add_private_message(s,ident,entry);a,b,_=messages(s)[ident]['parts'][2];body,_=rewrite(native[entry['native_template']]['parts'][2][2],entry,Layout(O),ident);s=s[:a]+body+s[b:]
order=['71B7','71B8','71B9','71B2']
if [s.index('DEFINE_MESSAGE(0x'+i+',')for i in order]!=sorted(s.index('DEFINE_MESSAGE(0x'+i+',')for i in order):
 blocks=[]
 for ident in entries:
  start=s.index('DEFINE_MESSAGE(0x'+ident+',');end=closing(s,start+len('DEFINE_MESSAGE('))+1
  while end<len(s)and s[end]=='\n':end+=1
  blocks.append(s[start:end]);s=s[:start]+s[end:]
 at=s.index('DEFINE_MESSAGE(0x71B2,');s=s[:at]+''.join(blocks)+s[at:]
p.write_text(s)
print('Kenny: 284 + 280 triangles; one shared object slot in two rooms; native owned-hover-boots condition.')

/* Two room-local appearances. Only read the native owned-hover-boots bit. */
extern Gfx gKennyDL[];
extern Gfx gKennyDeadDL[];
static s32 ElfMsg2_IsKenny(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_SHADOW_TEMPLE &&
        ((actor->room == 2 && actor->params == 0x3F85) ||
         (actor->room == 6 && actor->params == 0x3F86));
}
static s32 ElfMsg2_KennyVisible(Actor* actor) {
    s32 boots = CHECK_OWNED_EQUIP(EQUIP_TYPE_BOOTS, EQUIP_INV_BOOTS_HOVER) != 0;
    return actor->params == 0x3F86 ? boots : !boots;
}
static void ElfMsg2_DrawKenny(Actor* actor, PlayState* play) {
    s32 slot = Object_GetSlot(&play->objectCtx, OBJECT_KENNY);
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot) || !ElfMsg2_KennyVisible(actor)) return;
    OPEN_DISPS(play->state.gfxCtx, "kenny", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    if (actor->params == 0x3F85) {
        /* Small rigid idle sway, no foreign skeleton or scaling animation. */
        Matrix_RotateZ(Math_SinS((s16)(play->gameplayFrames * 400)) * 0.008f, MTXMODE_APPLY);
    }
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "kenny", 2);
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPDisplayList(POLY_OPA_DISP++, actor->params == 0x3F86 ? gKennyDeadDL : gKennyDL);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    CLOSE_DISPS(play->state.gfxCtx, "kenny", 3);
}
static void ElfMsg2_InitKenny(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 dead = actor->params == 0x3F86;
    if (!LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_PROP);
    actor->flags = ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = dead ? 0x71B9 : 0x71B8;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    actor->shape.rot.x = actor->shape.rot.z = 0;
    ActorShape_Init(&actor->shape, 0, NULL, 14);
    Actor_SetFocus(actor, dead ? 12 : 40);
    actor->draw = ElfMsg2_DrawKenny;
    ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
}
static void ElfMsg2_UpdateKenny(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 dead = actor->params == 0x3F86;
    s32 visible = ElfMsg2_KennyVisible(actor);
    actor->draw = visible ? ElfMsg2_DrawKenny : NULL;
    actor->shape.shadowDraw = visible && !dead ? ActorShadow_DrawCircle : NULL;
    if (!visible) {
        actor->flags &= ~(ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_TALK_WITH_C_UP);
        return;
    }
    actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_TALK_WITH_C_UP;
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight + (dead ? 1.0f : 0.0f);
    }
    Actor_SetFocus(actor, dead ? 12 : 40);
    this->actionFunc(this, play);
}

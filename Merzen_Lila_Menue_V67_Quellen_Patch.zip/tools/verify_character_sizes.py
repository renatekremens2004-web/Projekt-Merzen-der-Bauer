"""Verify uniform size changes, native freeing/cutscene paths and complete dialogue retention."""
from pathlib import Path
import sys,json,csv,re,struct,hashlib,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages,tokens,controls,split_pages,plain as plain_text
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';a=(W/'baseline.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();plain=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='d47361adcee8709b8dd2a1a4ce794a8dcc9808e2946a0fabd09883219bb4e7a4'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
def syms(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
old=syms(W/'baseline.map');new=syms(B/'oot-pal-1.0.map');names=[x['Name']for x in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];relocs={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if m:section=m[1];relocs.setdefault(section,{})
 m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if m and section:relocs[section][int(m[1],16)]=(m[2],m[3])
def relocated(x,y,base,name):
 assert len(x)==len(y),(name,'length',len(x),len(y))
 changed=sorted({i//4*4 for i,(q,r)in enumerate(zip(x,y))if q!=r})
 for i in changed:
  rel=relocs.get(name,{}).get(base+i);assert rel,(name,hex(base+i),'unexplained difference');kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[i:i+2]==y[i:i+2]
  elif kind=='R_MIPS_26':assert x[i]>>2==y[i]>>2
  else:assert kind=='R_MIPS_32',kind
 return len(changed)
intentional={'makerom','dmadata','ovl_Elf_Msg2','ovl_En_Go2','ovl_Demo_Du','object_du','object_sa','spot09_room_0','HIDAN_room_5','ger_message_data_static'};segments={};identical=[];changed=[];linked=[];verified=0
for i,name in enumerate(names):
 start,end,y=segment(b,i);_,_,x=segment(a,i)
 if y is None:continue
 segments[name]=(x,y)
 if name!='dmadata':
  if name=='makerom':assert y[:16]==plain[start:start+16]and y[24:]==plain[start+24:end]
  else:assert y==plain[start:end],name;verified+=1
 if x==y:identical.append(name)
 elif name in intentional:changed.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)))
 else:linked.append(dict(segment=name,changed_words=relocated(x,y,new['_'+name+'SegmentStart'],name)))
assert verified==1509
# Triangle Guy 608A is the sole changed message, with a native dynamic player-name token.
old_messages=messages((W/'baseline_message_data.h').read_text()); current_messages=messages((O/'extracted/pal-1.0/text/message_data.h').read_text()); assert old_messages.keys()==current_messages.keys()
text_diff=[]
for ident, previous in old_messages.items():
 current=current_messages[ident];assert previous['header']==current['header']
 for language in range(4):
  if previous['parts'][language][2]!=current['parts'][language][2]:text_diff.append((ident,language))
assert text_diff==[('608A',2)],text_diff
triangle=current_messages['608A']['parts'][2][2]
assert plain_text(split_pages(triangle)[0][0])==plain_text(old_messages['608A']['parts'][2][2]), 'Original Triangle Guy greeting must be retained as first page'
assert controls(old_messages['608A']['parts'][2][2])==controls(triangle)
assert tokens(triangle).count('NAME')==1 and tokens(triangle).count('BOX_BREAK')==3
assert 'Ich bin das Triforce des Mutes' in plain_text(triangle) and 'Aber ich bin nicht käuflich!' in plain_text(triangle)
for name in ['nes_message_data_static','fra_message_data_static']:assert segments[name][0]==segments[name][1],name
edits={i:e for p in(R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};buffers=check_buffers(B,edits);assert len(edits)==1013
# Same geometry, normals, UVs, materials and vertex grouping; only uniform positions change.
models={}
for key,height,previous in [('wawaluigi',100,125),('wallace_adult',90,110)]:
 before=json.loads((W/(key+'_source.json')).read_text());after=json.loads((R/'tools'/(key+'_source.json')).read_text());factor=height/previous
 assert before['triangles']==after['triangles']and before['materials']==after['materials']
 assert len(before['vertices'])==len(after['vertices'])and len(before['bones'])==len(after['bones'])
 for field in ['vertices','bones']:
  for v,u in zip(before[field],after[field]):
   expected=dict(v);expected['position']=[round(x*factor)for x in v['position']];assert expected==u,(key,field)
 assert after['height_game_units']==height
 models[key]=dict(before_height=previous,after_height=height,uniform_factor=factor,triangles=len(after['triangles']))
for key in ['wallace_source','wawario_source']:assert (W/(key+'.json')).read_bytes()==(R/'tools'/(key+'.json')).read_bytes()
before=json.loads((W/'bowling_sage_source.json').read_text());after=json.loads((R/'tools/bowling_sage_source.json').read_text())
for key in before.keys()-{'animations','credits'}:assert before[key]==after[key],key
assert before['animations'].keys()==after['animations'].keys()
for label,frames in before['animations'].items():
 if label not in ['sit_idle','sit_down','sit_up']:assert frames==after['animations'][label],label;continue
 assert len(frames)==len(after['animations'][label])
 for v,u in zip(frames,after['animations'][label]):
  assert u['root']==after['credits']['root_model_units']and len(v['rotation'])==len(u['rotation'])
  for j,(r,t)in enumerate(zip(v['rotation'],u['rotation'])):
   if j not in [1,2,4,5]:assert r==t,(label,j)
# Only the three dimensions/focus values and blue NPC pivots change in current actor source.
base=R/'tools/originals/character_sizes/src/overlays/actors'
p=O/'src/overlays/actors/ovl_En_Go2/z_en_go2.c';s=(base/'ovl_En_Go2/z_en_go2.c').read_text();s=s.replace('Actor_SetFocus(&this->actor, 99.0f)','Actor_SetFocus(&this->actor, 81.0f)').replace('this->collider.dim.height = 105','this->collider.dim.height = 86').replace('this->collider.dim.radius = 18','this->collider.dim.radius = 15')
camera='    this->subCamAt.z = this->actor.world.pos.z;\n    Play_SetCameraAtEye(play, this->subCamId, &this->subCamAt, &this->subCamEye);'
fitted='    this->subCamAt.z = this->actor.world.pos.z;\n    if (EnGo2_IsAdultWallace(this, play)) {\n        this->subCamEye.x = this->actor.world.pos.x + (this->subCamEye.x - this->actor.world.pos.x) * 1.9f;\n        this->subCamEye.z = this->actor.world.pos.z + (this->subCamEye.z - this->actor.world.pos.z) * 1.9f;\n        this->subCamEye.y = this->actor.world.pos.y + 40.0f;\n        this->subCamAt.y = this->actor.world.pos.y + 48.0f;\n    }\n    Play_SetCameraAtEye(play, this->subCamId, &this->subCamAt, &this->subCamEye);'
assert s.count(camera)==1;assert s.replace(camera,fitted)==p.read_text()
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=(base/'ovl_Elf_Msg2/z_elf_msg2.c').read_text();m=json.loads((R/'tools/wawaluigi_source.json').read_text());values=', '.join('{'+','.join(map(str,v['position']))+'}'for v in m['bones']);s,n=re.subn(r'(static Vec3f wawaluigiPivots\[4\] = \{).*?(\};)',lambda q:q[1]+' '+values+' '+q[2],s,count=1);assert n==1;assert s.replace('orange ? 65 : 100','orange ? 65 : 80')==p.read_text()
# Native code and release, cell, item, equipment and credits control functions are retained.
functions=re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([Tt]) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'oot-pal-1.0.elf')],text=True),re.M);func_addrs={int(q[1],16)for line in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(B/'oot-pal-1.0.elf')],text=True).splitlines()if len(q:=line.split())>=8 and q[3]=='FUNC'}
checked=set();retained={}
for seg in ['code','ovl_En_Go2','ovl_Demo_Du','ovl_Demo_Sa','ovl_Elf_Msg2']:
 x,y=segments[seg];count=0
 for addr,size,kind,name in functions:
  address=int(addr,16);length=int(size,16)
  if address not in func_addrs or name not in old or name in ['EnGo2_Update','EnGo2_GoronFireCamera','ElfMsg2_Init','ElfMsg2_Update']:continue
  if not new['_'+seg+'SegmentStart']<=address<new['_'+seg+'SegmentEnd']or not old['_'+seg+'SegmentStart']<=old[name]<old['_'+seg+'SegmentEnd']:continue
  i=old[name]-old['_'+seg+'SegmentStart'];j=address-new['_'+seg+'SegmentStart'];relocated(x[i:i+length],y[j:j+length],address,seg);count+=1;checked.add(name)
 retained[seg]=count
for name in ['EnGo2_GoronFireGenericAction','EnGo2_GoronFireClearCamera','EnGo2_UpdateTalkStateGoronFireGeneric','Inventory_ChangeEquipment','Player_SetBootData','Player_SetEquipmentData','Room_RequestNewRoom','CollisionCheck_GetSwordDamage','Actor_ApplyDamage']:assert name in checked,name
assert retained['code']>2900 and retained['ovl_En_Go2']>80
# All native room/object symbols preceding the appended imported models are retained.
assets={}
for seg,obj,prefixes in [('spot09_room_0','assets/scenes/overworld/spot09/spot09_room_0.o',['gWawaluigi']),('HIDAN_room_5','assets/scenes/dungeons/HIDAN/HIDAN_room_5.o',['gPrisonWallace']),('object_du','assets/objects/object_du/object_du.o',['gAdultWallace']),('object_sa','assets/objects/object_sa/object_sa.o',['gBowlingSage'])]:
 x,y=segments[seg];n=0
 for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) (\w) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/obj)],text=True),re.M):
  if name not in old or name not in new or any(name.startswith(p)for p in prefixes):continue
  i=old[name]-old['_'+seg+'SegmentStart'];j=new[name]-new['_'+seg+'SegmentStart'];length=int(size,16)
  if not 0<=i<len(x)or not 0<=j<len(y):continue
  relocated(x[i:i+length],y[j:j+length],new[name],seg);n+=1
 assets[seg]=n
for name in ['ovl_Demo_Sa','spot16_scene','spot16_room_0','kenjyanoma_scene','spot12_room_0','spot15_room_0','ganon_tou_room_0','object_zo','ovl_Boss_Ganon2','ovl_Boss_Mo','ovl_Boss_Ganondrof']:
 assert name in identical or any(v['segment']==name for v in linked),name
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,edited_message_count=len(edits),only_changed_message="608A German",all_other_messages_all_languages_retained=True,triangle_player_name_token=True,triangle_original_greeting_retained_as_first_page=True,private_wallace_escape_camera_fitted=True,text_buffers=buffers,models=models,only_sitting_animations_refitted=True,bowling_sage_body_bones_and_other_animations_unchanged=True,native_credits_cameras_cues_and_timing_unchanged=True,original_cell_switch_path_and_rewards_retained=True,native_functions_retained=retained,native_assets_retained=assets,intentional_segments=changed,identical_segments=identical,relocated_segments=linked,seat=after['credits'])
(B/'character-sizes-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments;',retained,'native functions;',assets,'native assets; all',len(edits),'dialogues checked; only Triangle Guy 608A extended.')

"""Verify owl/day dialogue and Merz nickname against the published 681-message revision.

Usage: python tools/verify_eule_tagesgags.py OOT PREVIOUS_BEAN_ROM.z64
Run in the OOT Python environment, with MIPS binutils on PATH.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import re
import struct
import subprocess
from ipl3checksum import CICKind, calculateChecksum
from verify_story import segment, check_buffers

ROOT = Path(__file__).resolve().parent.parent
BASE_SHA = '9d486686e7cd4a38e782eaa6b484c14f486d994b3741be05b444bfe9369664f0'


def function_bodies(source):
    clean = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:[^"\\]|\\.)*"',
                   lambda m: ' ' * len(m[0]), source, flags=re.S)
    out = {}
    for match in re.finditer(r'(?m)^[\w *]+\s+(\w+)\([^;{}]*\)\s*\{', clean):
        if match[1].isupper():
            continue
        depth, end = 1, match.end()
        while depth:
            depth += (clean[end] == '{') - (clean[end] == '}')
            end += 1
        out[match[1]] = clean[match.start():end]
    return out


def geometry():
    model = json.loads((ROOT/'tools/bean_bound.json').read_text())
    source = json.loads((ROOT/'tools/bean_source.json').read_text())
    assert len(model['triangles']) == len(source['triangles']) == 1258
    assert len(model['bones']) == 16 and len(model['palette']) == 15
    assert len(model['texture']) == 128*128 and len(model['texture_palette']) == 256*3
    pairs, maximum_error = set(), 0
    for triangle in model['triangles']:
        assert len(triangle) == 3 and all(0 <= i < len(model['vertices']) for i in triangle)
        for a,b in zip(triangle,triangle[1:]+triangle[:1]):
            pairs.add(tuple(sorted((a,b))))
    for vertex in model['vertices']:
        assert vertex['bone'] in model['palette']
        assert all(-32768 <= v < 32768 for v in vertex['position']+vertex['uv'])
        assert abs(math.sqrt(sum(n*n for n in vertex['normal']))-127) <= 1
    edges = 0
    for a,b in pairs:
        va,vb = model['vertices'][a],model['vertices'][b]
        if va['bone'] != vb['bone']:
            continue
        sa,sb = (source['vertices'][v['source_vertex']]['position'] for v in [va,vb])
        expected = math.dist(sa,sb)*model['scale']
        actual = math.dist(va['position'],vb['position'])
        error = abs(actual-expected)
        assert error < 1.74, (a,b,error)
        maximum_error=max(maximum_error,error)
        edges += 1
    assert edges > 1000
    return {'source_triangles':1258,'output_triangles':1258,'uniform_scale':model['scale'],
            'rigid_edges_checked':edges,'maximum_edge_quantization_error':maximum_error,
            'normalized_lighting_normals':True,'native_limb_count':16,'native_matrix_count':15}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('oot',type=Path)
    ap.add_argument('baseline',type=Path)
    args=ap.parse_args()
    oot=args.oot.resolve();build=oot/'build/pal-1.0'
    old=args.baseline.read_bytes();packed=(build/'oot-pal-1.0-compressed.z64').read_bytes()
    plain=(build/'oot-pal-1.0.z64').read_bytes()
    assert hashlib.sha256(old).hexdigest()==BASE_SHA
    assert len(packed)==33554432 and packed[0x3e:0x40]==b'P\0'
    assert struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
    mp=(build/'oot-pal-1.0.map').read_text()
    symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):
        symbols.setdefault(name,int(address,16))
    def sym(name):
        return symbols[name]
    elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(build/'oot-pal-1.0.elf')],text=True)
    rels={};current=None
    for line in elf.splitlines():
        header=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
        if header:
            current=header[1];rels.setdefault(current,{})
        entry=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
        if current and entry:
            rels[current][int(entry[1],16)]=(entry[2],entry[3])
    intentional={'makerom','dmadata','code','ger_message_data_static'}
    identical=[];relocated=[];changed=[];verified=0;object_bytes=None
    names=[r['Name'] for r in csv.DictReader((oot/'baseroms/pal-1.0/segments.csv').open())]
    for index,name in enumerate(names):
        _,_,before=segment(old,index)
        start,end,unpacked=segment(packed,index)
        if unpacked is None:
            continue
        expected=plain[start:end]
        if name=='makerom':
            assert unpacked[:16]==expected[:16] and unpacked[24:]==expected[24:]
        elif name!='dmadata':
            assert unpacked==expected,('compression',name)
            verified+=1
        lo,hi=[sym('_'+name+'SegmentRom'+suffix) for suffix in ['Start','End']]
        after=plain[lo:hi]
        if name=='object_im':
            object_bytes=len(after)
            assert len(after)<=86016,('object memory budget exceeded',len(after))
        if before==after:
            identical.append(name);continue
        if name in intentional:
            changed.append({'segment':name,'before_bytes':len(before),'after_bytes':len(after)});continue
        assert len(before)==len(after),('unexpected size change',name,len(before),len(after))
        origin=sym('_'+name+'SegmentStart')
        differences=sorted({i//4*4 for i,(x,y) in enumerate(zip(before,after)) if x!=y})
        for offset in differences:
            rel=rels.get(name,{}).get(origin+offset)
            assert rel,('unexplained changed word',name,hex(origin+offset))
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[offset:offset+2]==after[offset:offset+2],(name,rel)
            elif kind=='R_MIPS_26':
                assert before[offset]>>2==after[offset]>>2,(name,rel)
            else:
                assert kind=='R_MIPS_32',(name,rel)
        relocated.append({'segment':name,'relocated_words':len(differences)})
    assert verified==1509
    assert {'object_zo','object_im','object_rl','bdan_room_3','spot01_room_0'}<=set(identical)
    opening='src/overlays/gamestates/ovl_opening/z_opening.c'
    assert (oot/opening).read_bytes()==subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+opening])
    rel='src/overlays/actors/ovl_Demo_Im/z_demo_im.c'
    vanilla=function_bodies(subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+rel],text=True))
    actual=function_bodies((oot/rel).read_text())
    assert vanilla.keys()==actual.keys()
    function_changes={k for k in vanilla if vanilla[k]!=actual[k]}
    assert function_changes=={'func_80985EF4','DemoIm_DrawSolid','DemoIm_DrawTranslucent'},function_changes
    allowed={rel,'src/code/z_sram.c','src/overlays/actors/ovl_En_Ganon_Mant/z_en_ganon_mant.c',
             'src/overlays/actors/ovl_En_Viewer/z_en_viewer.c','src/code/z_elf_message.c','src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.c','src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.h','src/code/z_message.c','src/overlays/actors/ovl_En_Dns/z_en_dns.c','src/overlays/actors/ovl_Boss_Va/z_boss_va.c','src/overlays/actors/ovl_En_Ru1/z_en_ru1.c','src/overlays/actors/ovl_En_Elf/z_en_elf.c','src/overlays/actors/ovl_En_Rl/z_en_rl.c','src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c','src/overlays/actors/ovl_En_Ossan/z_en_ossan.c','src/overlays/actors/ovl_En_Syateki_Man/z_en_syateki_man.c'}
    source_changes=set(subprocess.check_output(['git','-C',str(oot),'diff','--name-only','HEAD','--','src','include'],text=True).splitlines())
    assert source_changes<=allowed,source_changes
    edits={}
    for chapter in sorted((ROOT/'story').glob('*.json')):
        for ident,entry in json.loads(chapter.read_text())['messages'].items():
            assert ident not in edits;edits[ident]=entry
    assert len(edits)==681
    for path, backup, expected in [
        ('src/code/z_elf_message.c', ROOT/'tools/originals/story/src/code/z_elf_message.c', {'QuestHint_GetNaviTextId'}),
        ('src/overlays/actors/ovl_En_Viewer/z_en_viewer.c', ROOT/'tools/originals/bean/src/overlays/actors/ovl_En_Viewer/z_en_viewer.c', {'EnViewer_ImpaOverrideLimbDraw'})]:
        before_functions=function_bodies(backup.read_text());after_functions=function_bodies((oot/path).read_text())
        assert before_functions.keys()==after_functions.keys()
        assert {k for k in before_functions if before_functions[k]!=after_functions[k]}==expected
    rel='src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.c'
    original=(ROOT/'tools/originals/squid'/rel).read_text()
    actual=(oot/rel).read_text()
    normalized=actual.replace('&gSquidSkel','&gZoraSkel').replace('&gSquidIdleAnim','&gZoraIdleAnim').replace('&gSquidThrowAnim','&gZoraThrowRupeesAnim').replace('this->morphTable, 28)','this->morphTable, 20)')
    normalized=normalized.replace('(gSaveContext.language == LANGUAGE_GER ? 0x0138 : 0x85)','0x85').replace('(gSaveContext.language == LANGUAGE_GER ? 0x013B : 0x2D)','0x2D').replace('(gSaveContext.language == LANGUAGE_GER) ? 0x0136 : 0x71AD','0x71AD')
    original_functions=function_bodies(original);actual_functions=function_bodies(normalized)
    assert original_functions.keys()==actual_functions.keys()
    assert {k for k in original_functions if original_functions[k]!=actual_functions[k]}=={'EnDivingGame_Init','EnDivingGame_OverrideLimbDraw'}
    rp='src/overlays/actors/ovl_En_Ex_Ruppy/z_en_ex_ruppy.c'
    assert (oot/rp).read_bytes()==subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+rp])
    path = 'src/overlays/actors/ovl_En_Elf/z_en_elf.c'
    before_functions = function_bodies((ROOT/'tools/originals/transition'/path).read_text())
    after_functions = function_bodies((oot/path).read_text())
    assert before_functions.keys() == after_functions.keys()
    assert {k for k in before_functions if before_functions[k] != after_functions[k]} == {'func_80A053F0'}
    # Rauru's cue/medallion/fade routines are byte-identical source after undoing only asset names.
    rel='src/overlays/actors/ovl_En_Rl/z_en_rl.c'
    normalized=(oot/rel).read_text()
    for new,old in [('gHabeckSkel','object_rl_Skel_007B38'),('gHabeckIdleAnim','object_rl_Anim_000A3C'),('gHabeckRaiseAnim','object_rl_Anim_00040C'),('gHabeckHoldAnim','object_rl_Anim_000830')]:normalized=normalized.replace(new,old)
    assert normalized==(ROOT/'tools/originals/habeck'/rel).read_text()
    rel='src/overlays/actors/ovl_En_Hy/z_en_hy.c'
    assert (oot/rel).read_text()==(ROOT/'tools/originals/habeck'/rel).read_text()
    model=json.loads((ROOT/'tools/habeck_source.json').read_text());assert len(model['bones'])==24 and len(model['triangles'])==2341
    assert {k:len(v) for k,v in model['animations'].items()}=={'idle':27,'raise':30,'hold':30}
    for frames in model['animations'].values():
        for frame in frames:assert len(frame['rotation'])==24 and len(frame['root'])==3
    for triangle in model['triangles']:
        for c in triangle['corners']:assert abs(math.sqrt(sum(x*x for x in c['normal']))-127)<1.1
    assert sym('_object_rlSegmentRomEnd')-sym('_object_rlSegmentRomStart')<300000
    rel='src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c'
    before_functions=function_bodies((ROOT/'tools/originals/n64'/rel).read_text());after_functions=function_bodies((oot/rel).read_text())
    assert set(after_functions)-set(before_functions)=={'ElfMsg2_DrawNintendo64'}
    assert {k for k in before_functions if before_functions[k]!=after_functions[k]}=={'ElfMsg2_Init'}
    console=json.loads((ROOT/'tools/n64_source.json').read_text());assert len(console['triangles'])==1376
    assert console['console_width_model_units']==1000 and console['actor_uniform_scale']==0.01
    material=next(i for i,x in enumerate(console['materials']) if x['name']=='console_good_main_mat')
    body={c['vertex'] for t in console['triangles'] if t['material']==material for c in t['corners']}
    assert max(console['vertices'][i][0] for i in body)-min(console['vertices'][i][0] for i in body)==1000

    for t in console['triangles']:
        for c in t['corners']:assert abs(math.sqrt(sum(x*x for x in c['normal']))-127)<1.1
    for p in console['vertices']:assert len(p)==3 and all(-32768<=x<=32767 for x in p)
    assert sym('_ovl_Elf_Msg2SegmentRomEnd')-sym('_ovl_Elf_Msg2SegmentRomStart')<4096
    room=oot/'extracted/pal-1.0/assets/scenes/dungeons/bdan/bdan_room_3_0300006C_ActorEntryList.inc.c'
    native=(ROOT/'tools/originals/n64'/room.relative_to(oot)).read_text();actual=room.read_text()
    assert actual.startswith(native) and actual[len(native):].count('ACTOR_ELF_MSG2')==1 and actual.count('ACTOR_')==9
    seams=json.loads((ROOT/'tools/bean_riding_seams.json').read_text())['vertices']
    assert len(seams)==117
    for vertex in seams.values():
        assert all(-32768<=x<32768 for x in vertex['position'])
        assert abs(math.sqrt(sum(n*n for n in vertex['normal']))-127)<1
    assert 'HAKAdan_room_0' in identical
    # Read the actual ROM language tables, rather than trusting generated JSON alone.
    # Symbols from the SHA256-pinned published baseline ELF.
    old_symbols={'_codeSegmentStart': 2147555040, 'sNesMessageEntryTable': 2148568012, 'sGerMessageEntryTable': 2148584948, 'sFraMessageEntryTable': 2148593412}
    def german_messages(rom,tab,code_base):
        _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'))
        off=tab-code_base;entries=[]
        # PAL German table contains only pointers; IDs/order come from NES entries.
        ids=[];nes=(old_symbols if rom==args.baseline.read_bytes() else symbols)['sNesMessageEntryTable']-code_base
        while True:
            ident=struct.unpack_from('>H',code,nes)[0]
            if ident==0xffff:break
            if ident!=0xfffc:ids.append(ident)
            nes+=8
        for i,ident in enumerate(ids):entries.append((ident,struct.unpack_from('>I',code,off+4*i)[0]&0xffffff))
        result={}
        for i,(ident,start) in enumerate(entries):
            end=entries[i+1][1] if i+1<len(entries) else len(data)
            result[ident]=data[start:end].rstrip(bytes([0]))
        return result
    _,_,before_code=segment(args.baseline.read_bytes(),names.index('code'))
    _,_,after_code=segment(packed,names.index('code'))
    table_start=old_symbols['sGerMessageEntryTable']-old_symbols['_codeSegmentStart']
    table_end=old_symbols['sFraMessageEntryTable']-old_symbols['_codeSegmentStart']
    assert len(before_code)==len(after_code)
    # Longer German text crosses a ROM segment alignment boundary. Native
    # references to subsequent segments consequently move too. Every such
    # word must be a linker relocation; instructions/opcodes remain native.
    code_relocations = []
    baseline_map=(args.baseline.parent/'baseline.map').read_text()
    baseline_symbols={name:int(address,16) for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',baseline_map)}
    for offset in range(0, len(before_code), 4):
        if table_start <= offset < table_end or before_code[offset:offset+4] == after_code[offset:offset+4]:
            continue
        address = old_symbols['_codeSegmentStart'] + offset
        rel = rels.get('code', {}).get(address)
        assert rel, ('unexpected code change', hex(address))
        kind, target = rel
        assert 'SegmentRom' in target or ((re.fullmatch(r'_ovl_\w+Segment(?:Start|End|BssEnd)',target) or target.endswith('_Profile')) and sym('gEffectSsOverlayTable') <= address < sym('gGameStateOverlayTable')+6*0x30), ('unexpected relocation target', hex(address), rel)
        if kind in ['R_MIPS_HI16', 'R_MIPS_LO16', 'R_MIPS_16']:
            assert before_code[offset:offset+2] == after_code[offset:offset+2]
        else:
            assert kind == 'R_MIPS_32', rel
            assert (struct.unpack_from('>I',before_code,offset)[0]-baseline_symbols[target])&0xffffffff == (struct.unpack_from('>I',after_code,offset)[0]-sym(target))&0xffffffff, ('relocation addend changed',target)
        code_relocations.append({'address':hex(address),'type':kind,'target':target})

    # Undo only our exact actor-specific language routing; all native actor
    # game logic and default-language paths must remain source-identical.
    from build_npc_stimmen import SHOP, SHOOT
    for actor in ['En_Ossan','En_Syateki_Man']:
        rel='src/overlays/actors/ovl_'+actor+'/z_'+actor.lower()+'.c'
        source=(oot/rel).read_text()
        if actor=='En_Ossan':
            assert source.count(SHOP)==1
            source=source.replace(SHOP,'')
        else:
            assert source.count(SHOOT)==1
            source=source.replace(SHOOT,'').replace('EnSyatekiMan_GetPrivateText(this->textIdx)','sTextIds[this->textIdx]')
        native=subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+rel],text=True)
        assert source==native,actor

    old_rom=args.baseline.read_bytes()
    before_text=german_messages(old_rom,old_symbols['sGerMessageEntryTable'],old_symbols['_codeSegmentStart'])
    after_text=german_messages(packed,sym('sGerMessageEntryTable'),sym('_codeSegmentStart'))
    changed_ids={i for i in before_text if before_text[i]!=after_text[i]}
    assert hashlib.sha256((oot/'src/code/z_sram.c').read_bytes()).hexdigest() == '68c37daf0aca944a3425d13c6201111d96433d7be851349462294168ef1d8d0b'
    from build_text_speed import HELPER, NEW
    assert HELPER in (oot/'src/code/z_message.c').read_text() and NEW in (oot/'src/code/z_message.c').read_text()
    assert changed_ids=={16386, 28675, 16387, 16388, 28682, 28684, 16407, 8217, 8222, 28705, 28706, 28707, 28708, 16433, 4288, 4289, 4290, 4291, 4292, 4293, 4294, 4295, 28746, 28747, 12386, 12387, 8292, 8293, 8295, 8296, 8297, 8298, 8299, 8300, 28909, 8301, 8302, 8303, 8304, 8305, 8306, 24697, 24698, 24699, 24700},[hex(x) for x in changed_ids]
    report={'version':'German PAL 1.0; Individual NPC voices; 34 owl entries audited; 33 rewritten; daylight gags and Merz nickname Herr Bohne; 681 edited messages',
            'rom_sha256':hashlib.sha256(packed).hexdigest(),'rom_bytes':len(packed),
            'baseline_sha256':BASE_SHA,'compressed_segments_verified':verified,
            'identical_segments':identical,'relocated_segments':relocated,'intentional_changes':changed,
            'code_segment_rom_relocations':code_relocations,'native_minigame_rules_preserved':True,'normal_start_preserved':True,
            'impa_modified_functions':sorted(function_changes),'object_bytes':object_bytes,
            'changed_german_message_ids':[hex(x) for x in sorted(changed_ids)],'unchanged_german_messages':len(before_text)-len(changed_ids),'object_memory_budget_bytes':86016,'original_object_bytes':74288,'riding_seam_vertices':117,'geometry':geometry(),'text_buffers':check_buffers(build,edits)}
    output=build/'eule-tagesgags-verification.json'
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['identical_segments','relocated_segments','text_buffers']},indent=2))


if __name__=='__main__':
    main()

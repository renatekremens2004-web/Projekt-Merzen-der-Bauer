"""Blender importer for the uploaded Studio Collada LEGO model (no external scripts)."""
from pathlib import Path
import bpy,bmesh,sys,json,re,hashlib,xml.etree.ElementTree as E
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent.parent;src=Path(sys.argv[sys.argv.index('--')+1]);s=src.read_text()
# Studio exports optional renderer metadata with undeclared namespace prefixes.
for prefix in set(re.findall(r'<\/?([\w]+):',s)):
 if 'xmlns:'+prefix+'=' not in s:s=s.replace('<COLLADA ','<COLLADA xmlns:'+prefix+'="urn:studio:'+prefix+'" ',1)
r=E.fromstring(s);ns={'c':r.tag.split('}')[0][1:]};bpy.ops.wm.read_factory_settings(use_empty=True)
nodes={x.attrib['id']:x for x in r.findall('c:library_nodes/c:node',ns)};geos={};effects={}
for e in r.findall('c:library_effects/c:effect',ns):effects[e.attrib['id']]=list(map(float,e.find('.//c:diffuse/c:color',ns).text.split()))
materials={}
for m in r.findall('c:library_materials/c:material',ns):materials[m.attrib['id']]={'name':m.attrib['name'],'rgba':effects[m.find('c:instance_effect',ns).attrib['url'][1:]]}
for g in r.findall('c:library_geometries/c:geometry',ns):
 if g.attrib['id']=='logo-lego':continue # Microscopic raised lettering, not the stud geometry.
 mesh=g.find('c:mesh',ns);arrays={}
 for a in mesh.findall('c:source',ns):
  v=list(map(float,a.find('c:float_array',ns).text.split()));stride=int(a.find('c:technique_common/c:accessor',ns).attrib['stride']);arrays[a.attrib['id']]=[v[i:i+stride] for i in range(0,len(v),stride)]
 posid=mesh.find('c:vertices/c:input',ns).attrib['source'][1:];faces=[]
 for t in mesh.findall('c:triangles',ns):
  inputs=t.findall('c:input',ns);stride=max(int(i.attrib['offset']) for i in inputs)+1;off=int(next(i for i in inputs if i.attrib['semantic']=='VERTEX').attrib['offset']);v=list(map(int,t.find('c:p',ns).text.split()));indices=v[off::stride];faces += [indices[i:i+3] for i in range(0,len(indices),3)]
 geos[g.attrib['id']]=(arrays[posid],faces)
groups={};source_count=0;instances=0

def walk(node,parent):
 global source_count,instances
 ma=node.find('c:matrix',ns);world=parent @ (Matrix([list(map(float,ma.text.split()))[i:i+4] for i in range(0,16,4)]) if ma is not None else Matrix.Identity(4))
 for inst in node.findall('c:instance_geometry',ns):
  name=inst.attrib['url'][1:]
  if name=='logo-lego':continue
  pos,faces=geos[name];mid=inst.find('.//c:instance_material',ns).attrib['target'][1:];mat=materials[mid];key=tuple(mat['rgba']);group=groups.setdefault(key,{'name':mat['name'],'v':[],'f':[]});base=len(group['v']);group['v'] += [list(world @ Vector(v[:3])) for v in pos];reverse=world.to_3x3().determinant()<0
  group['f'] += [[base+i for i in (list(reversed(f)) if reverse else f)] for f in faces];source_count+=len(faces);instances+=1
 for child in node.findall('c:instance_node',ns):walk(nodes[child.attrib['url'][1:]],world)
 for child in node.findall('c:node',ns):walk(child,world)
walk(r.find('c:library_visual_scenes/c:visual_scene/c:node',ns),Matrix.Identity(4))
print('Imported',instances,'parts,',source_count,'triangles excluding tiny lettering',flush=True)
objects=[]
for rgba,g in groups.items():
 mesh=bpy.data.meshes.new(g['name']);mesh.from_pydata(g['v'],[],g['f']);mesh.update();obj=bpy.data.objects.new(g['name'],mesh);bpy.context.collection.objects.link(obj);mat=bpy.data.materials.new(g['name']);mat.diffuse_color=rgba;mesh.materials.append(mat)
 bpy.context.view_layer.objects.active=obj
 # Union microscopic coplanar/interior detail before polygon reduction.
 mod=obj.modifiers.new('LEGO solid surface','REMESH');mod.mode='VOXEL';mod.voxel_size=3.0;mod.use_smooth_shade=False;bpy.ops.object.modifier_apply(modifier=mod.name);objects.append(obj)
 print(g['name'],'surface',len(obj.data.polygons),flush=True)
voxel_tris=sum(len(p.vertices)-2 for obj in objects for p in obj.data.polygons)
for obj in objects:
 bpy.context.view_layer.objects.active=obj;mod=obj.modifiers.new('N64 silhouette','DECIMATE');mod.ratio=min(1,3500/voxel_tris);mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name)
 print(obj.name,'final',len(obj.data.polygons),flush=True)
points=[v.co for o in objects for v in o.data.vertices];lo=[min(v[i] for v in points) for i in range(3)];hi=[max(v[i] for v in points) for i in range(3)];scale=2400/(hi[0]-lo[0]);center=Vector(((lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2))
out={'model':'User-supplied LEGO X-Wing 6212','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_triangles_without_lettering':source_count,'source_instances_without_lettering':instances,'game_width':24,'uniform_actor_scale':0.01,'source_scale':scale,'source_bounds':[lo,hi],'materials':[],'vertices':[],'triangles':[]}
for obj in objects:
 mi=len(out['materials']);out['materials'].append({'name':obj.name,'rgba':list(obj.data.materials[0].diffuse_color)});base=len(out['vertices']);mesh=obj.data;mesh.calc_loop_triangles()
 out['vertices'] += [[round(x) for x in (v.co-center)*scale] for v in mesh.vertices]
 for t in mesh.loop_triangles:
  normal=[round(x*127) for x in t.normal.normalized()]
  vp=[Vector(out['vertices'][base+i]) for i in t.vertices]
  if t.normal.length<.01 or (vp[1]-vp[0]).cross(vp[2]-vp[0]).length==0:continue
  out['triangles'].append({'material':mi,'corners':[{'vertex':base+i,'normal':normal} for i in t.vertices]})
(R/'tools/xwing_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n');print('Final',len(out['triangles']),'triangles; dimensions',[round((hi[i]-lo[i])*scale*.01,2) for i in range(3)],flush=True)
bpy.ops.wm.save_as_mainfile(filepath='/workspace/xwing/reduced.blend')

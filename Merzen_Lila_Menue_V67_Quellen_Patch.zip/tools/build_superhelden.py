"""Append isolated Forest Temple NPCs; halve Dark Link HP; native one-hit Master Sword damage."""
from pathlib import Path
import json,sys,re
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();D=O/'extracted/pal-1.0/assets/scenes/dungeons/Bmori1';B=R/'tools/originals/superhelden'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
models={k:json.loads((R/f'tools/{k}_source.json').read_text())for k in ['fanboy','chumchum','crocker']}
entries={3:('fanboy','Fanboy',[1480,463,-1388],-32768,'0x3F75'),5:('chumchum','ChumChum',[-1240,383,-1498],0,'0x3F76'),12:('crocker','Crocker',[-5230,-1363,-1930],0,'0x3F77')}
for room,(key,prefix,pos,yaw,param)in entries.items():
 d=O/'extracted/pal-1.0/assets/scenes/dungeons'/('HAKAdan'if key=='crocker'else 'Bmori1');scene='HAKAdan'if key=='crocker'else 'Bmori1'
 g=emit(models[key],R/'models'/key,prefix,rigged=True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');inc=key+'_model.inc.c';(d/inc).write_text(g)
 p=d/f'{scene}_room_{room}.c';p.write_text(original(p)+f'\n#include "{inc}"\n');p=next(d.glob(f'{scene}_room_{room}_*ActorEntryList.inc.c'));s=original(p);count=s.count('ACTOR_');assert count==(12 if room==12 else 5);s+='    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, { 0, '+str(yaw)+', 0 }, '+param+' }, /* optional friendly superhero */\n';p.write_text(s)
 p=d/f'{scene}_room_{room}.h';s=original(p);s,n=re.subn(rf'(#define LENGTH_{scene}_room_{room}_\w+_ActorEntryList ){count}\b',lambda m:m[1]+str(count+1),s);assert n==1;p.write_text(s)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);helper=(R/'tools/superhelden_actor.inc.c').read_text()
for key in models:helper=helper.replace(key.upper()+'_PIVOTS',', '.join('{'+','.join(map(str,b['position']))+'}'for b in models[key]['bones']))
needle='void ElfMsg2_Init(Actor* thisx, PlayState* play) {';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
needle='    if (ElfMsg2_IsPepsiman(thisx, play)) {\n        ElfMsg2_InitPepsiman';assert s.count(needle)==1;s=s.replace(needle,'    if (ElfMsg2_IsSuperhero(thisx, play)) {\n        ElfMsg2_InitSuperhero(this, play);\n        return;\n    }\n'+needle)
needle='ElfMsg2_IsWallace(thisx, play) || ElfMsg2_IsPepsiman(thisx, play))';assert s.count(needle)==1;s=s.replace(needle,needle[:-1]+' || ElfMsg2_IsSuperhero(thisx, play))')
needle='    if (ElfMsg2_IsPepsiman(thisx, play)) {\n        ElfMsg2_UpdatePepsiman';assert s.count(needle)==1;s=s.replace(needle,'    if (ElfMsg2_IsSuperhero(thisx, play)) {\n        ElfMsg2_UpdateSuperhero(this, play);\n        return;\n    }\n'+needle);p.write_text(s)
# Only Dark Link's spawn HP changes. AI, damage dealt and native death/room-clear actions stay intact.
p=O/'src/overlays/actors/ovl_En_Torch2/z_en_torch2.c';s=original(p);old='this->actor.colChkInfo.health = gSaveContext.save.info.playerData.healthCapacity >> 3;';assert s.count(old)==1;p.write_text(s.replace(old,old.replace('>> 3','>> 4')))
# One accepted Master Sword hit from the real player (or his charged-spin actor) is lethal
# to ordinary enemy actors. Preserve native immunity/reaction and every boss damage path.
p=O/'include/collision_check.h';s=original(p);needle='u8 CollisionCheck_GetSwordDamage(s32 dmgFlags);';assert s.count(needle)==1;new=s.replace(needle,'s32 CollisionCheck_IsPlayerMasterSwordHit(ColliderElement* elem);\n'+needle)
if p.read_text()!=new:p.write_text(new)
p=O/'src/code/z_collision_check.c';s=original(p);needle='void CollisionCheck_ApplyDamage(UNUSED PlayState* play';assert s.count(needle)==1
helper='''s32 CollisionCheck_IsPlayerMasterSwordHit(ColliderElement* elem) {
    Actor* attacker;
    if (elem == NULL || elem->acHit == NULL || elem->acHitElem == NULL) return false;
    attacker = elem->acHit->actor;
    return attacker != NULL && (attacker->id == ACTOR_PLAYER || attacker->id == ACTOR_EN_M_THUNDER) &&
           (elem->acHitElem->atDmgInfo.dmgFlags & (DMG_SLASH_MASTER | DMG_SPIN_MASTER | DMG_JUMP_MASTER));
}

''';s=s.replace(needle,helper+needle)
old='''    if (!(col->acFlags & AC_HARD)) {
        col->actor->colChkInfo.damage += damage;
    }
}''';new='''    if (!(col->acFlags & AC_HARD)) {
        if (damage > 0.0f && col->actor->category == ACTORCAT_ENEMY && col->actor->colChkInfo.health != 0 &&
            !(col->actor->id == ACTOR_EN_IK && (col->actor->params & 0xFF) == 0) &&
            CollisionCheck_IsPlayerMasterSwordHit(elem)) {
            /* Assign remaining HP, avoiding u8 overflow from multiple collider elements. */
            col->actor->colChkInfo.damage = col->actor->colChkInfo.health;
        } else {
            col->actor->colChkInfo.damage += damage;
        }
    }
}''';assert s.count(old)==1;p.write_text(s.replace(old,new))
# Big Deku Babas otherwise force one remaining HP during a recovery animation.
p=O/'src/overlays/actors/ovl_En_Dekubaba/z_en_dekubaba.c';s=original(p);needle='''            if (this->actionFunc != EnDekubaba_Vulnerable) {''';assert s.count(needle)==1;s=s.replace(needle,'''            if (this->actor.colChkInfo.damage != 0 &&
                CollisionCheck_IsPlayerMasterSwordHit(&this->collider.elements[0].base)) {
                newHealth = 0;
                EnDekubaba_SetupDieDropStick(this);
            } else if (this->actionFunc != EnDekubaba_Vulnerable) {''');p.write_text(s)
# Flare Dancer cores use three parent health phases; finish natively on a sword core hit.
p=O/'src/overlays/actors/ovl_En_Fw/z_en_fw.c';s=original(p);needle='if (this->actor.parent->colChkInfo.health <= 8) {';assert s.count(needle)==1;p.write_text(s.replace(needle,'if (this->actor.parent->colChkInfo.health <= 8 || CollisionCheck_IsPlayerMasterSwordHit(elem)) {'))
print('Superheroes:',{k:len(m['triangles'])for k,m in models.items()},'; isolated rooms3/5. Dark Link HP /2; accepted player Master Sword hits lethal to normal enemies.')

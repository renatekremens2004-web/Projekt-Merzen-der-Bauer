"""Install the German adult Navi aside's persistent read marker."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
oot = Path(sys.argv[1]).resolve()
path = oot / 'src/overlays/actors/ovl_En_Elf/z_en_elf.c'
backup = ROOT / 'originals/transition' / path.relative_to(oot)
backup.parent.mkdir(parents=True, exist_ok=True)
if not backup.exists():
    backup.write_bytes(path.read_bytes())
source = backup.read_text()
marker = '''            gSaveContext.save.info.playerData.naviTimer = 3001;
        }
'''
assert source.count(marker) == 1
source = source.replace(marker, marker + '''
        /* 0x1CF is reserved for this mod in unused infTable word 28. */
        if (gSaveContext.language == LANGUAGE_GER && thisx->textId == 0x0120) {
            SET_INFTABLE(0x1CF);
        }
''')
path.write_text(source)
print('Adult Navi aside read marker installed; native availability and timers retained.')

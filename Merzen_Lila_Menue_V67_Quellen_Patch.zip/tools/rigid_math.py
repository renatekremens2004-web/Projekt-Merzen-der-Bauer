import numpy as np,math

def rot(a):
 x,y,z=np.array(a)*math.pi/32768;cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
 return np.array([[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]])
def angles(r):
 y=math.asin(float(np.clip(-r[2,0],-1,1)));x=math.atan2(r[2,1],r[2,2]);z=math.atan2(r[1,0],r[0,0]);return [round(v*32768/math.pi)%65536 for v in [x,y,z]]
def fk(bones,frame):
 out=[]
 for i,b in enumerate(bones):
  m=np.eye(4);m[:3,:3]=rot(frame['rotation'][i]);m[:3,3]=frame['root'] if i==0 else b['position'];out.append(out[b['parent']]@m if b['parent']>=0 else m)
 return out

def points(vertices,world):
 return np.array([world[v[0]][:3,:3]@v[1:4]+world[v[0]][:3,3] for v in vertices])
def basis(v,forward):
 x=np.array(v,dtype=float);x/=np.linalg.norm(x);y=np.cross(forward,x)
 if np.linalg.norm(y)<.01:y=np.cross([0,1,0],x)
 y/=np.linalg.norm(y);z=np.cross(x,y);return np.stack([x,y,z],axis=1)

"""German Wallace prisoner/sage roles. Native cells, rewards, cues and controls remain native."""
from pathlib import Path
import sys,json,re
from PIL import Image,ImageFont,ImageDraw
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/fire_wallace'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
m=json.loads((R/'tools/wallace_adult_source.json').read_text());D=R/'models/wallace-adult'
for root,prefix in [(O/'extracted/pal-1.0/assets/objects/object_du','AdultWallace'),(O/'extracted/pal-1.0/assets/scenes/dungeons/HIDAN','PrisonWallace')]:
 code=emit(m,D,prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL')
 (root/'wallace_adult_model.inc.c').write_text(code)
 name='object_du' if prefix=='AdultWallace' else 'HIDAN_room_5'
 p=root/(name+'.c');p.write_text(original(p)+'\n#include "wallace_adult_model.inc.c"\n')
 if prefix=='AdultWallace':
  p=root/'object_du.h';p.write_text(original(p)+'\nextern Gfx gAdultWallaceDL[];\n')
# Match only this native cell instance. Native freeing, switch, path and key are retained.
p=O/'src/overlays/actors/ovl_En_Go2/z_en_go2.c';s=original(p)
helper='''static s32 EnGo2_IsAdultWallace(EnGo2* this, PlayState* play) {
    return play->sceneId == SCENE_FIRE_TEMPLE && gSaveContext.language == LANGUAGE_GER && LINK_IS_ADULT &&
           this->actor.room == 5 && this->actor.params == 0x0D83;
}
extern Gfx gPrisonWallaceDL[];
#include "wallace_adult_draw.inc.c"

static void EnGo2_DrawAdultWallace(EnGo2* this, PlayState* play) {
    void* segment = play->roomCtx.curRoom.num == this->actor.room ? play->roomCtx.curRoom.segment : play->roomCtx.prevRoom.segment;
    if (segment == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "wallace prisoner", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    gSPSegment(POLY_OPA_DISP++, 0x03, segment);
    gSPSegment(POLY_OPA_DISP++, 0x0C, ACTOR_SETUP_OPA_DL);
    gDPSetEnvColor(POLY_OPA_DISP++, 0, 0, 0, 255);
    POLY_OPA_DISP = WallaceAdult_Draw(&this->actor, play, POLY_OPA_DISP, gPrisonWallaceDL, 0.0f, 0.0f);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "wallace prisoner", 2);
}

'''
marker='u16 EnGo2_GoronFireGenericGetTextId(EnGo2* this) {';assert s.count(marker)==1;s=s.replace(marker,helper+marker+'\n    if (EnGo2_IsAdultWallace(this, play)) return 0x209D;')
s=s.replace('EnGo2_GoronFireGenericGetTextId(EnGo2* this)', 'EnGo2_GoronFireGenericGetTextId(EnGo2* this, PlayState* play)').replace('EnGo2_GoronFireGenericGetTextId(this)', 'EnGo2_GoronFireGenericGetTextId(this, play)')
needle='''    } else {
        return 0x3051;
    }
}''';assert s.count(needle)==1;s=s.replace(needle,'''    } else {
        return EnGo2_IsAdultWallace(this, play) ? 0x209E : 0x3051;
    }
}''')
needle='void EnGo2_Draw(Actor* thisx, PlayState* play) {\n    EnGo2* this = (EnGo2*)thisx;';assert s.count(needle)==1
# C89 declarations must remain before statements.
needle2='    EnGo2_UpdateEffects(this);';assert s.count(needle2)==1;s=s.replace(needle2,'''    if (EnGo2_IsAdultWallace(this, play)) {
        EnGo2_DrawAdultWallace(this, play);
        return;
    }

'''+needle2)
# Set focus after the native state update; retained switch/path behavior still decides release.
needle='void EnGo2_Update(Actor* thisx, PlayState* play) {';start=s.index(needle);end=s.index('\n}',start)
s=s[:end]+'''
    if (EnGo2_IsAdultWallace(this, play)) {
        Actor_SetFocus(&this->actor, 99.0f);
        this->collider.dim.height = 105;
        this->collider.dim.radius = 18;
    }
'''+s[end:];p.write_text(s);(p.parent/'wallace_adult_draw.inc.c').write_bytes((R/'tools/wallace_adult_draw.inc.c').read_bytes())
# Private medallion camera framing only; keep original cues/text/timing commands byte-for-byte.
def camera_transform(text,starts,anchor,factor,dy):
 mode=None;start=None;out=[]
 point=re.compile(r'(CS_CAM_POINT\([^\n]*?CS_FLOAT\([^)]*\),\s*)(-?\d+),\s*(-?\d+),\s*(-?\d+)(,\s*0x[0-9A-Fa-f]+\),)')
 for line in text.splitlines(True):
  h=re.search(r'CS_CAM_(EYE|AT)_SPLINE\((\d+),',line)
  if h:mode=h[1];start=int(h[2])
  elif re.search(r'^\s*CS_\w+\(',line) and 'CS_CAM_POINT(' not in line:mode=None
  q=point.search(line)
  if q and mode and start in starts:
   x,y,z=map(int,q.group(2,3,4));pos=[round(anchor[0]+(x-anchor[0])*factor),y+dy,round(anchor[2]+(z-anchor[2])*factor)]
   line=line[:q.start()]+q[1]+', '.join(map(str,pos))+q[5]+line[q.end():]
  out.append(line)
 return ''.join(out)
csroot=O/'src/overlays/actors/ovl_Demo_Du'
cs=(csroot/'z_demo_du_cutscene_data.inc.c').read_text()
cs=camera_transform(cs,{263,333},(98,6,-169),2.0,35)
cs=camera_transform(cs,{443},(98,6,-169),1.5,20)
cs=cs.replace('gFireMedallionCs','gWallaceFireMedallionCs')
(csroot/'wallace_fire_camera.inc.c').write_text(cs)
# Same fire-sage closeup in the final seal-opening montage.
p=O/'extracted/pal-1.0/assets/scenes/indoors/kenjyanoma/gChamberOfSagesSealOpeningCs.csdata.inc.c'
p.write_text(camera_transform(original(p),{80},(98,6,-169),1.8,35))

# Darunia's pre-sage appearances use the original model; only DemoDu sage roles use Wallace.
p=O/'src/overlays/actors/ovl_Demo_Du/z_demo_du.c';s=original(p).replace('#include \"gfx.h\"','#include \"gfx.h\"\n#include \"sys_matrix.h\"')
helper='''static s32 DemoDu_IsWallace(DemoDu* this) {
    return gSaveContext.language == LANGUAGE_GER && this->actor.params != DEMO_DU_CS_GORONS_RUBY;
}
#include "wallace_adult_draw.inc.c"
static Gfx* DemoDu_DrawWallace(DemoDu* this, PlayState* play, Gfx* gfx) {
    f32 arm = 0.0f;
    f32 head = 0.0f;
    if (this->skelAnime.animation == &gDaruniaItemGiveAnim)
        arm = CLAMP(this->skelAnime.curFrame / 24.0f, 0.0f, 1.0f) * 1.8f;
    else if (this->skelAnime.animation == &gDaruniaItemGiveIdleAnim) arm = 1.8f;
    else if (this->actor.params == DEMO_DU_CS_CHAMBER_AFTER_GANON) arm = 1.1f;
    else if (this->actor.params == DEMO_DU_CS_CREDITS) {
        arm = 0.35f;
        if (this->skelAnime.animation == &gDaruniaLookingUpToSariaAnim) head = -0.16f;
    }
    return WallaceAdult_Draw(&this->actor, play, gfx, gAdultWallaceDL, arm, head);
}

'''
marker='// Similar to DemoDu_Draw_01, but this uses POLY_XLU_DISP.';assert s.count(marker)==1;s=s.replace(marker,helper+marker)
needle='''    POLY_XLU_DISP = SkelAnime_DrawFlex(play, skelAnime->skeleton, skelAnime->jointTable, skelAnime->dListCount, 0, 0, 0,
                                       POLY_XLU_DISP);''';assert s.count(needle)==1;s=s.replace(needle,'''    if (DemoDu_IsWallace(this)) POLY_XLU_DISP = DemoDu_DrawWallace(this, play, POLY_XLU_DISP);
    else {
'''+needle+'\n    }')
needle='    SkelAnime_DrawFlexOpa(play, skelAnime->skeleton, skelAnime->jointTable, skelAnime->dListCount, NULL, NULL, this);';assert s.count(needle)==1;s=s.replace(needle,'''    if (DemoDu_IsWallace(this)) POLY_OPA_DISP = DemoDu_DrawWallace(this, play, POLY_OPA_DISP);
    else {
'''+needle+'\n    }');s=s.replace('#include \"z_demo_du_cutscene_data.inc.c\"','#include \"z_demo_du_cutscene_data.inc.c\"\n#include \"wallace_fire_camera.inc.c\"\nstatic s32 DemoDu_IsWallace(DemoDu* this);')
s=s.replace('play->csCtx.script = gFireMedallionCs;', 'play->csCtx.script = DemoDu_IsWallace(this) ? gWallaceFireMedallionCs : gFireMedallionCs;')
p.write_text(s);(p.parent/'wallace_adult_draw.inc.c').write_bytes((R/'tools/wallace_adult_draw.inc.c').read_bytes())
# Orange HEV-inspired fabric; equipment IDs, heat checks and item icon remain native.
p=O/'src/code/z_player_lib.c';s=original(p);needle='{ 100, 20, 0 },  // PLAYER_TUNIC_GORON';assert s.count(needle)==1;p.write_text(s.replace(needle,'{ 200, 75, 0 },  // PLAYER_TUNIC_GORON: Wallace orange'))
# A new German pause label, same dimensions/format as the original item-name slot.
p=O/'extracted/pal-1.0/assets/textures/item_name_static/gMegatonHammerItemNameGERTex.ia4.png';b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
if not b.exists():b.write_bytes(p.read_bytes())
w,h=Image.open(p).size;im=Image.new('RGBA',(w,h),(0,0,0,0));font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13);draw=ImageDraw.Draw(im);label='Wallace Hammer';box=draw.textbbox((0,0),label,font=font);draw.text(((w-(box[2]-box[0]))//2,-box[1]+(h-(box[3]-box[1]))//2),label,font=font,fill=(255,255,255,255));im.save(p);im.save(D/'Wallace_Hammer_Name.png')
print('Fire Wallace:',len(m['triangles']),'triangles; native prisoner room 5 switch 3; own sage visual with native events; orange tunic; German pause label.')

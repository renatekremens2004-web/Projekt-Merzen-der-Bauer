/* Two isolated Forest Temple NPC rooms; never a connected room pair. */
extern Gfx gFanboyDL[];
extern Gfx gChumChumDL[];
extern Gfx gCrockerDL[];
static s32 ElfMsg2_IsSuperhero(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_FOREST_TEMPLE &&
        ((actor->room == 3 && actor->params == 0x3F75) || (actor->room == 5 && actor->params == 0x3F76))) ||
        (play->sceneId == SCENE_SHADOW_TEMPLE && actor->room == 12 && actor->params == 0x3F77);
}
static void ElfMsg2_DrawSuperhero(Actor* actor, PlayState* play) {
    static Vec3f fanboyPivots[4] = { FANBOY_PIVOTS };
    static Vec3f chumPivots[4] = { CHUMCHUM_PIVOTS };
    static Vec3f crockerPivots[4] = { CROCKER_PIVOTS };
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Vec3f* pivots = crocker ? crockerPivots : fanboy ? fanboyPivots : chumPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (fanboy ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "superhelden", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "superhelden", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, crocker ? gCrockerDL : fanboy ? gFanboyDL : gChumChumDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "superhelden", 3);
}
static void ElfMsg2_InitSuperhero(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = crocker ? 0x6089 : fanboy ? 0x6087 : 0x6088;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, crocker ? 16 : fanboy ? 15 : 18);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = crocker ? 13 : fanboy ? 13 : 18;
    this->wallaceCollider.dim.height = crocker ? 86 : fanboy ? 76 : 47;
    Actor_SetFocus(actor, crocker ? 75 : fanboy ? 66 : 40);
    actor->draw = ElfMsg2_DrawSuperhero;
}
static void ElfMsg2_UpdateSuperhero(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Actor_SetFocus(actor, crocker ? 75 : fanboy ? 66 : 40);
    actor->textId = crocker ? 0x6089 : fanboy ? 0x6087 : 0x6088;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

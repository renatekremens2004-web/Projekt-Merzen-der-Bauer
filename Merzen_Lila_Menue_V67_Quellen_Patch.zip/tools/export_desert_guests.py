"""User-supplied SMD/OBJ models at native NPC-relative sizes; own small rigid groups.
python3 tools/export_desert_guests.py WORK (input/meowth, jimmy, mackey).
"""
from pathlib import Path
import json,hashlib,math,shutil,sys
from PIL import Image
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[1]);report={}
def rotate(v,angle):
 c,s=math.cos(angle),math.sin(angle);return[c*v[0]-s*v[1],s*v[0]+c*v[1],v[2]]
for key,height in [('meowth',24),('jimmy',47),('mackey',74)]:
 root=W/'input'/key;src=next(root.rglob('*.smd'if key=='meowth'else'*.obj'));faces=[];textures={}
 if key=='meowth':
  lines=src.read_text().split('triangles\n')[1].splitlines()
  for i in range(0,len(lines)-1,4):
   tex=lines[i];textures[tex]=tex;cs=[]
   for line in lines[i+1:i+4]:
    q=line.split();b=int(q[0]);v=list(map(float,q[1:4]));n=list(map(float,q[4:7]));cs.append(dict(p=[v[0],v[2],-v[1]],n=[n[0],n[2],-n[1]],uv=list(map(float,q[7:9])),joint=b))
   faces.append((tex,cs))
 else:
  vs=[];uvs=[];ns=[];mat=None
  for l in src.with_suffix('.mtl').read_text().splitlines():
   if l.startswith('newmtl '):mat=l.split(maxsplit=1)[1]
   if l.startswith('map_Kd '):textures[mat]=l.split(maxsplit=1)[1].replace('\\','/').split('/')[-1]
  for l in src.read_text().splitlines():
   q=l.split()
   if not q:continue
   if q[0]=='v':vs.append(list(map(float,q[1:4])))
   elif q[0]=='vn':ns.append(list(map(float,q[1:4])))
   elif q[0]=='vt':uvs.append(list(map(float,q[1:3])))
   elif q[0]=='usemtl':mat=q[1]
   elif q[0]=='f':
    cs=[[int(x)-1 if x else None for x in c.split('/')]for c in q[1:]]
    for j in range(1,len(cs)-1):
     f=[cs[0],cs[j],cs[j+1]];a,b,c=[vs[q[0]]for q in f];ab=[b[k]-a[k]for k in range(3)];ac=[c[k]-a[k]for k in range(3)];normal=[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]]
     faces.append((mat,[dict(p=vs[q[0]],uv=uvs[q[1]],n=ns[q[2]]if len(q)>2 and q[2]is not None else normal,joint=-1)for q in f]))
 points=[c['p']for _,cs in faces for c in cs];lo=[min(p[k]for p in points)for k in range(3)];hi=[max(p[k]for p in points)for k in range(3)];scale=height*100/(hi[1]-lo[1]);cx=(lo[0]+hi[0])/2;center=[cx,lo[1],0]
 if key=='meowth':pivots=[[0,0,0],[0,.96,0],[-.2,.76,0],[.2,.76,0]]
 elif key=='jimmy':pivots=[[0,0,0],[0,1.16,0],[-.19,1.01,0],[.19,1.01,0]]
 else:pivots=[[0,0,0],[0,55,0],[-8,51,0],[8,51,0]]
 def to_int(v):return[round((v[k]-center[k])*scale)for k in range(3)]
 D=R/'models'/key;D.mkdir(parents=True,exist_ok=True);mats=[];mapping={}
 for mat,_ in faces:
  tex=textures[mat]
  if tex in mapping:continue
  p=next(p for p in root.rglob('*')if p.name.lower()==tex.lower());shutil.copyfile(p,D/tex);size=Image.open(p).size;mapping[tex]=len(mats);mats.append(dict(name=tex.split('.')[0],texture=tex,size=[min(64,2**round(math.log2(x)))for x in size]))
 if key=='jimmy':face_mat=len(mats);mats.append(dict(name='face_close',texture='jimycarl.png',size=[64,64],crop=[128,0,256,128]))
 m=dict(bones=[dict(name=n,parent=-1 if i==0 else 0,position=to_int(p)if i else[0,0,0])for i,(n,p)in enumerate(zip(['body','head','left_arm','right_arm'],pivots))],materials=mats,vertices=[],triangles=[],native_lighting=True,uniform_scale=True,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),height_game_units=height);lookup={}
 for mat,cs in faces:
  corners=[];idx=mapping[textures[mat]];close=key=='jimmy'and all(.5<=c['uv'][0]<=1 and .5<=c['uv'][1]<=1 for c in cs)
  if close:idx=face_mat
  for c in cs:
   p=c['p'][:];n=c['n'][:];bone=0
   if key=='meowth':
    if c['joint']>=37:bone=1
    elif 23<=c['joint']<=29:bone=2
    elif 30<=c['joint']<=36:bone=3
   elif key=='jimmy':
    if p[1]>1.18:bone=1
    elif abs(p[0])>.22 and .45<p[1]<1.15:bone=2 if p[0]<cx else 3
   else:
    if p[1]>55 or mat in['MrMkyEyes','MrMkyHair','MrMkyMth']:bone=1
    elif abs(p[0])>8 and 20<p[1]<55:bone=2 if p[0]<cx else 3
   if bone>=2:
    angle=math.radians((60 if key in['meowth','jimmy']else 75)*(1 if bone==2 else-1));v=rotate([p[k]-pivots[bone][k]for k in range(3)],angle);p=[pivots[bone][k]+v[k]for k in range(3)];n=rotate(n,angle)
   pos=to_int(p);k=(bone,*pos)
   if k not in lookup:lookup[k]=len(m['vertices']);m['vertices'].append(dict(bone=bone,position=pos))
   norm=max(1e-9,math.sqrt(sum(x*x for x in n)));uv=c['uv'];uv=[(uv[0]-.5)*2,(uv[1]-.5)*2]if close else uv;corners.append(dict(vertex=lookup[k],uv=uv,normal=[round(x/norm*127)for x in n]))
  m['triangles'].append(dict(material=idx,corners=corners))
 (R/'tools'/f'{key}_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');report[key]=dict(triangles=len(faces),height=height,rigid_groups=4,source_sha256=m['source_sha256']);print(key,report[key])
 S=D/'source';S.mkdir(exist_ok=True);shutil.copyfile(src,S/src.name)
 if src.suffix=='.obj':shutil.copyfile(src.with_suffix('.mtl'),S/src.with_suffix('.mtl').name)
 (S/'README.txt').write_text('User upload; Meowth: Pokemon Stadium 2 (N64), Jimmy Neutron: Boy Genius (PC), Mr. Mackey: South Park (N64). Original triangle count retained; own uniform scale and offline arm repose. Textures one directory above. Export: tools/export_desert_guests.py.\n')
(W/'models.json').write_text(json.dumps(report,indent=2)+'\n')

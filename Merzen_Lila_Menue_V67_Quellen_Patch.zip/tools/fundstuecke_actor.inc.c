#include "player.h"
/* Room-local flavor: no boss changes, collision, object slots, save flags or forced text. */
extern Gfx gTriangleGuyDL[];
extern Gfx gPregtestDL[];
extern Gfx gFlatSquidDL[];
static s32 ElfMsg2_IsTriangleGuy(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_GANON_BOSS && actor->room == 0 && actor->params == 0x3F78;
}
static s32 ElfMsg2_IsFundstueck(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_BOTTOM_OF_THE_WELL && actor->room == 6 && actor->params == 0x3F79) ||
           (play->sceneId == SCENE_WATER_TEMPLE_BOSS && actor->room == 1 && actor->params == 0x3F7A);
}
static void ElfMsg2_DrawFundstueck(Actor* actor, PlayState* play) {
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Gfx* dl = actor->params == 0x3F78 ? gTriangleGuyDL : actor->params == 0x3F79 ? gPregtestDL : gFlatSquidDL;
    if (roomSegment == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "fundstuecke", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "fundstuecke", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, dl);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "fundstuecke", 3);
}
static void ElfMsg2_InitTriangleGuy(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_0;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x608A;
    Actor_SetScale(actor, 0.01f);
    Actor_SetFocus(actor, 65);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 17);
    actor->draw = ElfMsg2_DrawFundstueck;
}
static void ElfMsg2_UpdateTriangleGuy(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 65);
    if (Actor_TalkOfferAccepted(actor, play) ||
        (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)) return;
    /* Native talking freezes bosses. Offer only in free play, never during a boss cinematic. */
    if (play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play)) {
        actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED;
        if (Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
            actor->xzDistToPlayer < 105.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
            Actor_OfferTalk(actor, play, 100.0f);
        }
    } else {
        actor->flags &= ~ACTOR_FLAG_ATTENTION_ENABLED;
    }
}

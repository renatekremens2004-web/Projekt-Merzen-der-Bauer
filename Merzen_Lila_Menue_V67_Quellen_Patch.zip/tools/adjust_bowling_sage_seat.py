"""Apply the corrected shoulder seat to the existing own rig; no body rescaling."""
from pathlib import Path
import json
p=Path(__file__).with_name('bowling_sage_source.json');m=json.loads(p.read_text())
root=m['credits']['root_model_units']
for label in ['sit_idle','sit_down','sit_up']:
    for frame in m['animations'][label]:frame['root']=list(root)
p.write_text(json.dumps(m,separators=(',',':'))+'\n')

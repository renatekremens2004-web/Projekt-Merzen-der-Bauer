from pathlib import Path
from PIL import Image
import json,math
R=Path(__file__).resolve().parent.parent;p=R/'tools/pepsiman_source.json';m=json.loads(p.read_text());
if len(m['materials'])!=1:raise SystemExit('Atlas already tiled')
src=Image.open(R/'models/pepsi/pepsiman.png').convert('RGBA');vout=[];tout=[];mats=[]
def clip(poly,axis,bound,keep):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ain=(a['uv'][axis]-bound)*keep>=-1e-9;bin=(b['uv'][axis]-bound)*keep>=-1e-9
  if ain:out.append(a)
  if ain!=bin:
   f=(bound-a['uv'][axis])/(b['uv'][axis]-a['uv'][axis]);c={'bone':a['bone']}
   for k in ['position','normal','uv']:c[k]=[x+(y-x)*f for x,y in zip(a[k],b[k])]
   out.append(c)
 return out
for y in range(2):
 for x in range(2):
  mi=len(mats);name=f'pepsiman_{x}_{y}';src.crop((x*128,(1-y)*128,(x+1)*128,(2-y)*128)).save(R/f'models/pepsi/{name}.png');mats.append({'name':name,'texture':name+'.png','size':[64,64]})
  for tri in m['triangles']:
   poly=[dict(m['vertices'][c['vertex']],uv=c['uv'],normal=c['normal'])for c in tri['corners']]
   for ax,lo in [(0,x*.5),(1,y*.5)]:
    poly=clip(poly,ax,lo,1)
    if poly:poly=clip(poly,ax,lo+.5,-1)
   if len(poly)<3:continue
   for k in range(1,len(poly)-1):
    cs=[]
    for c in [poly[0],poly[k],poly[k+1]]:
     vi=len(vout);vout.append({'bone':c['bone'],'position':[round(z)for z in c['position']]});n=c['normal'];norm=math.sqrt(sum(z*z for z in n))or 1
     cs.append({'vertex':vi,'uv':[(c['uv'][0]-x*.5)*2,(c['uv'][1]-y*.5)*2],'normal':[round(z/norm*127)for z in n]})
    a,b,c=[vout[z['vertex']]['position']for z in cs];cross=[(b[(i+1)%3]-a[(i+1)%3])*(c[(i+2)%3]-a[(i+2)%3])-(b[(i+2)%3]-a[(i+2)%3])*(c[(i+1)%3]-a[(i+1)%3])for i in range(3)]
    if sum(z*z for z in cross)>1:tout.append({'material':mi,'corners':cs})
m['materials']=mats;m['vertices']=vout;m['triangles']=tout;m['texture_note']='Four independent 64x64 CI4 atlas tiles, each within TMEM; preserves red chest badge.';p.write_text(json.dumps(m,separators=(',',':'))+'\n');print('Tiled atlas:',len(tout),'triangles')

# The badge is tiny. Reserve two palette entries so CI4 quantization cannot discard its red.
p=R/'models/pepsi/pepsiman_1_0.png';im=Image.open(p).convert('RGB').resize((64,64),Image.Resampling.LANCZOS);q=im.quantize(colors=14,method=Image.Quantize.MEDIANCUT);palette=q.getpalette()[:42]+[240,20,35,155,10,25];pal=Image.new('P',(1,1));pal.putpalette(palette+[0]*(768-len(palette)));im.quantize(palette=pal,dither=Image.Dither.NONE).save(p)

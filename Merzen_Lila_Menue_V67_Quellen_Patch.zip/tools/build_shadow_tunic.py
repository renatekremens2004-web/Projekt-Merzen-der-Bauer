"""Last cumulative builder: native Well chest and persistent Kokiri-tunic upgrade."""
from pathlib import Path
import json
import re
import sys
from build_story import Layout, add_private_message, messages, rewrite

R = Path(__file__).resolve().parent.parent
O = Path(sys.argv[1]).resolve()
B = R / 'tools/originals/shadow-tunic'

def original(rel):
    p = O / rel
    q = B / rel
    q.parent.mkdir(parents=True, exist_ok=True)
    if not q.exists():
        q.write_bytes(p.read_bytes())
    return q.read_text()

def write(rel, s):
    p = O / rel
    if not p.exists() or p.read_text() != s:
        p.write_text(s)

def replace(s, before, after):
    assert s.count(before) == 1, before
    return s.replace(before, after)

write('include/shadow_tunic.h', (R / 'tools/shadow_tunic.h').read_text())
rel = 'include/item.h'
s = original(rel)
s = replace(s, '    /* 0x7E */ GI_MAX', '    /* 0x7E */ GI_SHADOW_TUNIC,\n    /* 0x7F */ GI_MAX')
s = replace(s, '    /* 0x75 */ GID_MAX', '    /* 0x75 */ GID_SHADOW_TUNIC,\n    /* 0x76 */ GID_MAX')
write(rel, s)

rel = 'src/overlays/actors/ovl_player_actor/z_player.c'
s = original(rel)
s = '#include "shadow_tunic.h"\n' + s
tail = '    // GI_TEXT_0\n    GET_ITEM_NONE,\n};'
s = replace(s, tail, tail[:-3] + '\n    // GI_SHADOW_TUNIC: no duplicate-item conversion, own black model.\n    GET_ITEM(ITEM_TUNIC_KOKIRI, OBJECT_GI_CLOTHES, GID_SHADOW_TUNIC, 0x52, 0x80, CHEST_ANIM_LONG),\n};')
needle = 's32 Player_ActionHandler_2(Player* this, PlayState* play) {'
a = s.index(needle)
b = s.index('\nvoid ', a)
body = s[a:b]
needle = '''                if ((giEntry->itemId != ITEM_NONE) && (giEntry->gi >= 0) &&
                    (Item_CheckObtainability(giEntry->itemId) == ITEM_NONE)) {'''
body = replace(body, needle, '''                if ((giEntry->itemId != ITEM_NONE) && (giEntry->gi >= 0) &&
                    ((Item_CheckObtainability(giEntry->itemId) == ITEM_NONE) ||
                     (this->getItemId == -GI_SHADOW_TUNIC))) {''')
s = s[:a] + body + s[b:]
needle = 's32 func_8084DFF4(PlayState* play, Player* this) {'
s = replace(s, needle, '#include "shadow_tunic_player.inc.c"\n\n' + needle)
a = s.index(needle)
b = s.index('\nvoid ', a)
body = s[a:b]
body = replace(body, '        Message_StartTextbox(play, giEntry->textId, &this->actor);',
               '        Message_StartTextbox(play, this->getItemId == GI_SHADOW_TUNIC ? 0x71DC : giEntry->textId, &this->actor);')
body = replace(body, '        Item_Give(play, giEntry->itemId);',
               '        Item_Give(play, giEntry->itemId);\n        if (this->getItemId == GI_SHADOW_TUNIC) Player_ReceiveShadowTunic(play, this);')
s = s[:a] + body + s[b:]
write(rel, s)
write('src/overlays/actors/ovl_player_actor/shadow_tunic_player.inc.c', (R / 'tools/shadow_tunic_player.inc.c').read_text())

rel = 'src/code/z_parameter.c'
s = '#include "shadow_tunic.h"\n' + original(rel)
s = replace(s, 'gSaveContext.save.info.playerData.isDoubleDefenseAcquired && (amount < 0)',
            '(gSaveContext.save.info.playerData.isDoubleDefenseAcquired || SHADOW_TUNIC_ACTIVE()) && (amount < 0)')
write(rel, s)

rel = 'src/code/z_player_lib.c'
s = '#include "shadow_tunic.h"\n' + original(rel)
s = replace(s, '    color = &sTunicColors[tunic];', '''    /* Local Link rendering: do not recolor the shared Gerudo palette. */
    {
        static Color_RGB8 shadowColor = { 20, 20, 20 };
        color = tunic == PLAYER_TUNIC_KOKIRI && SHADOW_TUNIC_OWNED() ? &shadowColor : &sTunicColors[tunic];
    }''')
write(rel, s)

# Darken the existing icon buffers only after acquisition. No larger pools.
rel = 'src/code/z_message.c'
s = '#include "shadow_tunic.h"\n' + original(rel)
needle = 'void Message_LoadItemIcon(PlayState* play, u16 itemId, s16 y) {'
s = replace(s, needle, '#include "shadow_tunic_icon.inc.c"\n\n' + needle)
needle = '                         "../z_message_PAL.c", 1473);'
s = replace(s, needle, needle + '''
        if (itemId == ITEM_TUNIC_KOKIRI && SHADOW_TUNIC_OWNED()) {
            ShadowTunic_RecolorIcon(msgCtx->textboxSegment + MESSAGE_STATIC_TEX_SIZE);
        }''')
write(rel, s)
write('src/code/shadow_tunic_icon.inc.c', (R / 'tools/shadow_tunic_icon.inc.c').read_text())
rel = 'src/overlays/misc/ovl_kaleido_scope/z_kaleido_scope.c'
s = '#include "shadow_tunic.h"\n' + original(rel)
needle = 'void KaleidoScope_Update(PlayState* play) {'
s = replace(s, needle, '#include "shadow_tunic_icon.inc.c"\n\n' + needle)
for line in [3662, 4356]:
    needle = '                             "../z_kaleido_scope_PAL.c", ' + str(line) + ');'
    s = replace(s, needle, needle + '''
            if (SHADOW_TUNIC_OWNED()) {
                ShadowTunic_RecolorIcon((u8*)pauseCtx->iconItemSegment + ITEM_TUNIC_KOKIRI * ITEM_ICON_SIZE);
            }''')
write(rel, s)
write('src/overlays/misc/ovl_kaleido_scope/shadow_tunic_icon.inc.c', (R / 'tools/shadow_tunic_icon.inc.c').read_text())

rel = 'extracted/pal-1.0/assets/objects/object_gi_clothes/object_gi_clothes.c'
s = original(rel) + '''
/* Separate reward materials: original Goron/Zora materials stay unchanged. */
Gfx gGiShadowCollarColorDL[] = {
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 55, 55, 55, 255),
    gsDPSetEnvColor(12, 12, 12, 255),
    gsSPEndDisplayList(),
};
Gfx gGiShadowTunicColorDL[] = {
    gsDPPipeSync(),
    gsDPSetPrimColor(0, 0, 40, 40, 40, 255),
    gsDPSetEnvColor(8, 8, 8, 255),
    gsSPEndDisplayList(),
};
'''
write(rel, s)
rel = 'extracted/pal-1.0/assets/objects/object_gi_clothes/object_gi_clothes.h'
s = replace(original(rel), '\n#endif', '\nextern Gfx gGiShadowCollarColorDL[];\nextern Gfx gGiShadowTunicColorDL[];\n\n#endif')
write(rel, s)
rel = 'src/code/z_draw.c'
s = original(rel)
needle = '    // GID_SKULL_TOKEN_2\n    { GetItem_DrawSkullToken, { gSkulltulaTokenDL, gSkulltulaTokenFlameDL } },\n};'
s = replace(s, needle, needle[:-3] + '\n    // GID_SHADOW_TUNIC\n    { GetItem_DrawOpa1023, { gGiTunicCollarDL, gGiShadowCollarColorDL, gGiShadowTunicColorDL, gGiTunicDL } },\n};')
write(rel, s)

# A genuine native chest in the Beamos/Keese/pit room, on verified solid floor.
root = 'extracted/pal-1.0/assets/scenes/dungeons/HAKAdanCH/'
rel = root + 'HAKAdanCH_room_3_0300004C_ActorEntryList.inc.c'
s = original(rel)
count = s.count('ACTOR_')
s += '''    {
        ACTOR_EN_BOX,
        { 880, 0, -1230 },
        { 0, -32768, 0 },
        0x0FC0, /* big chest, GI_SHADOW_TUNIC 0x7E, unused treasure flag 0 */
    },
'''
write(rel, s)
rel = root + 'HAKAdanCH_room_3.h'
s = original(rel)
s, n = re.subn(r'(#define LENGTH_HAKAdanCH_room_3_0300004C_ActorEntryList )' + str(count) + r'\b', lambda m: m[1] + str(count + 1), s)
assert n == 1
write(rel, s)

# Only the German mod adds this chest. Other native chests are byte-for-byte logic.
rel = 'src/overlays/actors/ovl_En_Box/z_en_box.c'
s = original(rel)
needle = '    animFrameStart = 0.0f;'
s = replace(s, needle, '''    if (play->sceneId == SCENE_BOTTOM_OF_THE_WELL && thisx->params == 0x0FC0 &&
        gSaveContext.language != LANGUAGE_GER) {
        this->dyna.bgId = BG_ACTOR_MAX;
        Actor_Kill(thisx);
        return;
    }

''' + needle)
write(rel, s)

rel = 'extracted/pal-1.0/text/message_data.h'
s = original(rel)
native = messages(s)
entries = json.loads((R / 'story/shadow_tunic_de.json').read_text())['messages']
for ident, e in entries.items():
    s = add_private_message(s, ident, e)
layout = Layout(O)
parsed = messages(s)
for ident, e in entries.items():
    a, b, _ = parsed[ident]['parts'][2]
    template = 'ITEM_ICON(ITEM_TUNIC_KOKIRI) ' + native[e['native_template']]['parts'][2][2]
    body, _ = rewrite(template, e, layout, ident)
    s = s[:a] + body + s[b:]
write(rel, s)
print('Schattengewand: Well room3 native chest, own GI126/GID117, save bit1CE, Kokiri-only half damage, local black rendering.')

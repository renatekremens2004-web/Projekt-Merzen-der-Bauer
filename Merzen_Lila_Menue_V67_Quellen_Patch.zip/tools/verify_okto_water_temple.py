"""Validate the Okto reunion revision against the published Phantom-Amthor ROM."""
from pathlib import Path
import sys,csv,re,json,hashlib,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as story
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';a=(W/'baseline.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();plain=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='2258268d6d19086683b429c9bf804309b364511c208d7126df307537d32988ef'
assert len(b)==33554432 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
def symbols(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
old=symbols(W/'baseline.map');new=symbols(B/'oot-pal-1.0.map');names=[x['Name']for x in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];relocs={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if m:section=m[1];relocs.setdefault(section,{})
 m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if m and section:relocs[section][int(m[1],16)]=(m[2],m[3])
def relocated(x,y,base,name):
 assert len(x)==len(y),(name,'length',len(x),len(y))
 changes=sorted({j//4*4 for j,(q,r)in enumerate(zip(x,y))if q!=r})
 for j in changes:
  rel=relocs.get(name,{}).get(base+j);assert rel,(name,hex(base+j),'unexplained change')
  kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[j:j+2]==y[j:j+2]
  elif kind=='R_MIPS_26':assert x[j]>>2==y[j]>>2
  else:assert kind=='R_MIPS_32',kind
 return len(changes)
intentional={'makerom','dmadata','ger_message_data_static','code','ovl_En_Okuta','MIZUsin_room_0','object_gnd','ovl_Boss_Ganondrof'};segments={};changed=[];identical=[];relocated_segments=[];verified=0
for i,name in enumerate(names):
 start,end,y=segment(b,i);_,_,x=segment(a,i)
 if y is None:continue
 segments[name]=(x,y)
 if name!='dmadata':
  if name=='makerom':assert y[:16]==plain[start:start+16] and y[24:]==plain[start+24:end]
  else:assert y==plain[start:end],name;verified+=1
 if x==y:identical.append(name)
 elif name in intentional:changed.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)))
 else:relocated_segments.append(dict(segment=name,changed_words=relocated(x,y,new['_'+name+'SegmentStart'],name)))
assert verified==1509
# Check every retained native code function except the small spawn guard extension.
x,y=segments['code'];retained=0
nm=subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'oot-pal-1.0.elf')],text=True)
for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([Tt]) (\S+)$',nm,re.M):
 address=int(addr,16);n=int(size,16)
 if name=='Actor_Spawn' or name not in old or not new['_codeSegmentStart']<=address<new['_codeSegmentEnd'] or not old['_codeSegmentStart']<=old[name]<old['_codeSegmentEnd']:continue
 relocated(x[old[name]-old['_codeSegmentStart']:old[name]-old['_codeSegmentStart']+n],y[address-new['_codeSegmentStart']:address-new['_codeSegmentStart']+n],address,'code');retained+=1
assert retained>1000,retained
# Every retained original Phantom asset and combat function remains equivalent.
xg,yg=segments['object_gnd'];native_assets=0
nmobj=subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'assets/objects/object_gnd/object_gnd.o')],text=True)
for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) (\w) (\S+)$',nmobj,re.M):
 if name.startswith('gAmthor') or name in ['gPhantomGanonFaceDL','object_gnd_0080F8_DL'] or name not in old or name not in new:continue
 i=old[name]-old['_object_gndSegmentStart'];j=new[name]-new['_object_gndSegmentStart'];n=int(size,16)
 if 0<=i<len(xg) and 0<=j<len(yg):relocated(xg[i:i+n],yg[j:j+n],new[name],'object_gnd');native_assets+=1
assert native_assets>100
xb,yb=segments['ovl_Boss_Ganondrof'];combat_functions=0
for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([Tt]) (\S+)$',nm,re.M):
 if not name.startswith('BossGanondrof_') or name=='BossGanondrof_ClearAmthorHeadPixels' or name not in old:continue
 i=old[name]-old['_ovl_Boss_GanondrofSegmentStart'];j=int(addr,16)-new['_ovl_Boss_GanondrofSegmentStart'];n=int(size,16)
 if 0<=i<len(xb) and 0<=j<len(yb):relocated(xb[i:i+n],yb[j:j+n],int(addr,16),'ovl_Boss_Ganondrof');combat_functions+=1
assert combat_functions>20

# Retain all original room graphics, vertices, textures and culling geometry.
room_native=0;xr,yr=segments['MIZUsin_room_0'];nmroom=subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'assets/scenes/dungeons/MIZUsin/MIZUsin_room_0.o')],text=True)
for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) (\w) (\S+)$',nmroom,re.M):
 if name in ['MIZUsin_room_0','MIZUsin_room_0_03000058_ActorEntryList','MIZUsin_room_0_03000040_ObjectList'] or name not in old or name not in new:continue
 i=old[name]-0x03000000;j=new[name]-0x03000000;n=int(size,16)
 if 0<=i<len(xr) and 0<=j<len(yr):relocated(xr[i:i+n],yr[j:j+n],new[name],'MIZUsin_room_0');room_native+=1
assert room_native>50

# Raw message tables, not only source text.
def messages(rom,syms):
 _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'));base=syms['_codeSegmentStart'];p=syms['sNesMessageEntryTable']-base;ids=[]
 while True:
  ident=struct.unpack_from('>H',code,p)[0];p+=8
  if ident==65535:break
  if ident!=65532:ids.append(ident)
 table=syms['sGerMessageEntryTable']-base;off=[struct.unpack_from('>I',code,table+4*j)[0]&0xffffff for j in range(len(ids))]+[len(data)]
 return {f'{ident:04X}':data[off[j]:off[j+1]].rstrip(b'\0')for j,ident in enumerate(ids)}
ma=messages(a,old);mb=messages(b,new);diff=[i for i in ma if ma[i]!=mb[i]];assert set(diff)=={'00F8','209C'},diff
before=story.messages((W/'baseline_message_data.h').read_text());after=story.messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
for i,v in after.items():
 for lang in [0,1,3]:assert v['parts'][lang][2]==before[i]['parts'][lang][2],(i,lang)
 assert v['header']==before[i]['header'],i
 assert story.controls(v['parts'][2][2])==story.controls(before['0022'if i=='209C'else i]['parts'][2][2]),i
assert ma['00F9']==mb['00F9'] # Preserve the unrelated Big Poe item message.
# Source guard is the only core logic difference; native Octorok branches unchanged.
import build_friendly_octorok as okto
assert (W/'baseline_z_actor.c').read_text().replace(okto.LEGACY_CORE_NEW,okto.CORE_NEW)==(O/'src/code/z_actor.c').read_text()
assert (W/'baseline_z_en_okuta.c').read_text().replace(okto.LEGACY_INIT,okto.INIT).replace(okto.LEGACY_HELPER,okto.HELPER)==(O/'src/overlays/actors/ovl_En_Okuta/z_en_okuta.c').read_text()
water=(O/'src/overlays/actors/ovl_Bg_Mizu_Water/z_bg_mizu_water.c').read_text();indices=[int(v)for v in re.search(r'sWaterBoxIndices\[\] = \{([^}]+)',water)[1].split(',')];assert 0 not in indices
# Existing room entries retain their exact bytes and order; append one actor/object.
x,y=segments['MIZUsin_room_0'];base=0x03000000
for name,added in [('MIZUsin_room_0_03000058_ActorEntryList',16),('MIZUsin_room_0_03000040_ObjectList',2)]:
 count=28 if added==16 else 12;size=count*(16 if added==16 else 2);i=old[name]-base;j=new[name]-base;assert x[i:i+size]==y[j:j+size]
 if added==16:assert struct.unpack_from('>HhhhHHHh',y,j+size)==(14,-195,800,810,0,32768,0,32512)
 else:assert struct.unpack_from('>H',y,j+size)[0]==0x0007 # OBJECT_OKUTA
edits={i:e for p in (R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};buffers=check_buffers(B,edits);assert len(edits)==963
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,changed_german_messages=diff,story_count=len(edits),text_buffers=buffers,intentional_segments=changed,identical_segments=identical,relocated_segments=relocated_segments,retained_native_code_functions_verified=retained,retained_native_phantom_assets=native_assets,retained_entrance_room_assets=room_native,retained_native_combat_functions=combat_functions,native_enemy_branches_preserved=True,water_controller_indices=indices,fixed_entrance_water_box=0,all_other_models_unchanged=True,burns_and_smithers_refined=True,all_other_scene_geometry_and_collision_preserved=True)
(B/'okto-water-temple-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified 1509 segments, two German messages,',retained,'native code functions, 963 text buffers; other models unchanged, both Phantom heads refined.')

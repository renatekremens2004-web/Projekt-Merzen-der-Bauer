"""Differential validation of two Doof owners and two room-local guests."""
from pathlib import Path
import csv,hashlib,json,re,struct,subprocess,sys
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages,controls,split_pages,tokens,closing
from verify_bowling_sage_revision import function_bodies
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';base=W/'baseline';originals=R/'tools/originals/doof-guests'
a=(base/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();unpacked=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='fde57f9b350f35331cae236444ae15eb1802ca20f7b6a368368325aca781d2eb'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
entries=json.loads((R/'story/doof_guests_de.json').read_text())['messages'];ids={k for k,e in entries.items()if not e.get('new_message')};added=set(entries)-ids
old=messages((base/'extracted/pal-1.0/text/message_data.h').read_text());new=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());assert set(new)-set(old)==added and not(set(old)-set(new))
actual=set()
for ident in old:
 assert old[ident]['header']==new[ident]['header']
 for i in range(4):
  x=old[ident]['parts'][i][2];y=new[ident]['parts'][i][2]
  if x!=y:assert i==2 and ident in ids;actual.add(ident)
  assert controls(x)==controls(y),(ident,'controls')
  if len(split_pages(x)[0])!=len(split_pages(y)[0]):assert ident in ids and all(q=='BOX_BREAK'for q in split_pages(x)[1])and not any(t.startswith('FADE')for t in tokens(x))
assert actual==ids
for ident in added:
 x=old[entries[ident]['native_template']]['parts'][2][2];y=new[ident]['parts'][2][2];assert controls(x)==controls(y),(ident,'private controls')
edits={k:e for p in(R/'story').glob('*.json')for k,e in json.loads(p.read_text())['messages'].items()};assert len(edits)==1154;buffers=check_buffers(B,edits)
def norm(s):return ''.join(s.split())
def unwrap(s):
 while 'Fishing_DoofText('in s:
  a=s.index('Fishing_DoofText(');begin=a+len('Fishing_DoofText(');end=closing(s,begin);s=s[:a]+s[begin:end]+s[end+1:]
 return s
rel=Path('src/overlays/actors/ovl_Fishing/z_fishing.c');of=function_bodies((originals/rel).read_text());nf=function_bodies((O/rel).read_text());assert nf.keys()-of.keys()=={'Fishing_DoofText','Fishing_DrawDoof'};assert{k for k in of if of[k]!=nf[k]}=={'Fishing_Init','Fishing_HandleOwnerDialog','Fishing_UpdateOwner','Fishing_DrawOwner'}
for name in of:
 body=nf[name]
 body=body.replace('this->actor.textId = Fishing_DoofText(this->actor.textId);','')
 body=body.replace('if (gSaveContext.language == LANGUAGE_GER) sOwnerHair = FS_OWNER_HAIR;','')
 body=unwrap(body)
 body=re.sub(r'if\s*\(!Fishing_DrawDoof\(this, play\)\)\s*\{\s*(SkelAnime_DrawFlexOpa\(.*?;\s*)\}',r'\1',body,flags=re.S)
 assert norm(of[name])==norm(body),(name,'fishing gameplay changed')
rel=Path('src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c');of=function_bodies((originals/rel).read_text());nf=function_bodies((O/rel).read_text());assert nf.keys()-of.keys()=={'ElfMsg2_IsDoofGuest','ElfMsg2_DrawDoofGuest','ElfMsg2_InitDoofGuest','ElfMsg2_UpdateDoofGuest'};assert{k for k in of if of[k]!=nf[k]}=={'ElfMsg2_Init','ElfMsg2_Update','ElfMsg2_Destroy'}
for name in of:
 body=re.sub(r'if\s*\(ElfMsg2_IsDoofGuest\(thisx, play\)\)\s*\{[^}]+\}','',nf[name]);body=body.replace('ElfMsg2_IsDoofGuest(thisx, play) || ','');assert norm(of[name])==norm(body),(name,'existing guest changed')
assert(O/'src/overlays/actors/ovl_player_actor/quick_iron_boots.inc.c').read_bytes()==(R/'tools/quick_iron_boots.inc.c').read_bytes()
# Linker relocations account for changed addresses in otherwise untouched assets.
def syms(path):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',path.read_text()):d.setdefault(n,int(x,16))
 return d
ns=syms(B/'oot-pal-1.0.map');os=syms(base/'build/pal-1.0/oot-pal-1.0.map');rels={};sec=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 q=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if q:sec=q[1];rels.setdefault(sec,{})
 q=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if q and sec:rels[sec][int(q[1],16)]=(q[2],q[3])
def linked_word(x,y,off,addr,name):
 
 if name=='ovl_En_Ossan'and all(p==q or(p==0x19d and q==0x1a1)for p,q in zip(struct.unpack_from('>HH',x,off),struct.unpack_from('>HH',y,off))):return
 rel=rels.get(name,{}).get(addr);assert rel,(name,hex(addr),'unexplained difference');kind,target=rel
 if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[off:off+2]==y[off:off+2],(name,target)
 elif kind=='R_MIPS_26':assert x[off]>>2==y[off]>>2
 else:assert kind=='R_MIPS_32',kind
names=re.findall(r'DEFINE_DMA_ENTRY\((\w+),',(B/'dmadata_table_spec.h').read_text());expected=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())]+['object_jabba','object_bttf','object_kenny','object_shaggy','object_velma','object_daphne','object_scooby','object_fred','object_meowth','object_jimmy','object_mackey','object_doof','object_doofevil','object_shrek','object_monopoly'];assert names==expected
intentional={'makerom','dmadata','code','nes_message_data_static','ger_message_data_static','fra_message_data_static','ovl_Fishing','ovl_Elf_Msg2','turibori_room_0','spot10_room_3','ganontika_room_1','object_doof','object_doofevil','object_shrek','object_monopoly'};same=[];changed=[];relocated=[];verified=0
for i,name in enumerate(names):
 x=segment(a,i)[2]if i<len(names)-4 else None;start,end,y=segment(b,i)
 if y is None:continue
 if name=='makerom':assert y[:16]==unpacked[start:start+16] and y[24:]==unpacked[start+24:end]
 elif name!='dmadata':assert y==unpacked[start:end],name;verified+=1
 if x==y:same.append(name);continue
 if name in intentional:changed.append(dict(segment=name,before_bytes=len(x)if x is not None else 0,after_bytes=len(y)));continue
 assert len(x)==len(y),(name,'size')
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(x,y))if p!=q}):linked_word(x,y,off,ns['_'+name+'SegmentStart']+off,name)
 relocated.append(name)
assert verified==1524
# Every existing compiled message in every language retains exactly its bytes.
def elf_symbols(path):
 d={}
 for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([tTdDrR]) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(path)],text=True),re.M):
  addr,size=int(addr,16),int(size,16)
  if size:d[name]=(addr,size,kind)
 return d
def text_symbols(path):return syms(path)
os=syms(base/'build/pal-1.0/oot-pal-1.0.map')
def compiled(rom,symbols,lang):
 code=segment(rom,names.index('code'))[2];raw=segment(rom,names.index(lang+'_message_data_static'))[2];cb=symbols['_codeSegmentStart'];nt=symbols['sNesMessageEntryTable']-cb;table=symbols[{'nes':'sNesMessageEntryTable','ger':'sGerMessageEntryTable','fra':'sFraMessageEntryTable'}[lang]]-cb;rows=[];i=0
 while True:
  ident=struct.unpack_from('>H',code,nt+i*8)[0]
  if ident==0xffff:break
  if ident not in[0xfffc,0xfffd]:rows.append((f'{ident:04X}',struct.unpack_from('>I',code,(nt+i*8+4)if lang=='nes'else table+i*4)[0]&0xffffff))
  i+=1
 return{ident:raw[p:(rows[j+1][1]if j+1<len(rows)else len(raw))].rstrip(b'\x00')for j,(ident,p)in enumerate(rows)}
for lang in ['nes','ger','fra']:
 xx=compiled(a,os,lang);yy=compiled(b,ns,lang);assert yy.keys()-xx.keys()==added and not(xx.keys()-yy.keys());actual_ids={k for k in xx if xx[k]!=yy[k]};assert actual_ids==(ids if lang=='ger'else set()),(lang,actual_ids)
oldsy=elf_symbols(base/'build/pal-1.0/oot-pal-1.0.elf');newsy=elf_symbols(B/'oot-pal-1.0.elf');_,_,x=segment(a,names.index('code'));_,_,y=segment(b,names.index('code'));count=0;tables={'sNesMessageEntryTable','sGerMessageEntryTable','sFraMessageEntryTable','gObjectTable','gObjectTableSize'}
for name,(addr,size,kind)in oldsy.items():
 if name in tables or not(os['_codeSegmentStart']<=addr<os['_codeSegmentEnd']):continue
 na,nsize,_=newsy[name];assert size==nsize,(name,'size');xx=x[addr-os['_codeSegmentStart']:addr-os['_codeSegmentStart']+size];yy=y[na-ns['_codeSegmentStart']:na-ns['_codeSegmentStart']+size];assert len(xx)==len(yy)==size
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(xx,yy))if p!=q}):linked_word(xx,yy,off,na+off,'code')
 count+=1
# Native room geometry and existing actor/object entries remain intact.
section_names={num:name for num,name in re.findall(r'\[\s*(\d+)\] \.\.(\w+)\s',subprocess.check_output(['mips-linux-gnu-readelf','-SW',str(B/'oot-pal-1.0.elf')],text=True))};symbol_sections={line.split()[-1]:section_names.get(line.split()[6])for line in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(B/'oot-pal-1.0.elf')],text=True).splitlines()if len(line.split())==8}
room_checks={}
for room,allowed in {'turibori_room_0':{'turibori_room_0','turibori_room_0_03000040_ObjectList'},'spot10_room_3':{'spot10_room_3','spot10_room_3_03000070_ActorEntryList','spot10_room_3_03000058_ObjectList'},'ganontika_room_1':{'ganontika_room_1','ganontika_room_1_0300004C_ActorEntryList','ganontika_room_1_03000040_ObjectList'}}.items():
 _,_,xx=segment(a,names.index(room));_,_,yy=segment(b,names.index(room));n=0
 for name,(addr,size,kind)in oldsy.items():
  if symbol_sections.get(name)!=room or name in allowed:continue
  na,nsz,_=newsy[name];assert size==nsz,(name,'size');before=xx[addr-os['_'+room+'SegmentStart']:addr-os['_'+room+'SegmentStart']+size];after=yy[na-ns['_'+room+'SegmentStart']:na-ns['_'+room+'SegmentStart']+size]
  for off in sorted({i//4*4 for i,(u,v)in enumerate(zip(before,after))if u!=v}):linked_word(before,after,off,na+off,room)
  n+=1
 room_checks[room]=n
# Check private text DMA bounds, including the language tables' following pointer.
def data(name):addr,size,_=newsy[name];return y[addr-ns['_codeSegmentStart']:addr-ns['_codeSegmentStart']+size]
entries=list(struct.iter_unpack('>HBBI',data('sNesMessageEntryTable')))
for ident,nextid in [(i,i+1)for i in range(0x71c6,0x71db)]+[(0x71db,0x71b2)]:
 idx=[e[0]for e in entries].index(ident);assert entries[idx+1][0]==nextid
 for lang,table in [('nes','sNesMessageEntryTable'),('ger','sGerMessageEntryTable'),('fra','sFraMessageEntryTable')]:
  ptr=entries[idx][3]if lang=='nes'else struct.unpack_from('>I',data(table),idx*4)[0];nxt=entries[idx+1][3]if lang=='nes'else struct.unpack_from('>I',data(table),(idx+1)*4)[0];assert 0<nxt-ptr<1280
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),compressed_segments_verified=verified,native_core_symbols_verified=count,changed_german_ids=sorted(ids),added_ids=sorted(added),all_other_messages_all_languages_preserved=True,native_controls_fixed_times_and_fish_weight_tokens_preserved=True,all_native_fishing_gameplay_preserved_except_german_hat_sidequest_dialogue_ids_and_owner_drawing=True,existing_custom_guest_functions_unchanged=True,native_room_symbols_verified=room_checks,text_buffers=buffers,intentional_segments=changed,relocation_only_segments=relocated,identical_segments=same)
(B/'doof-guests-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments,',count,'core symbols,',len(ids),'existing messages and',len(added),'private messages; native fishing gameplay preserved.')

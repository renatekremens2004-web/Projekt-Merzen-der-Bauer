"""Convert supplied PS1 Pepsiman and two cans to compact N64 model JSON. Blender conversion only."""
import bpy,json,sys,math,shutil
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);D=R/'models/pepsi';D.mkdir(parents=True,exist_ok=True)
def fresh(path):
 bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.obj_import(filepath=str(path),forward_axis='NEGATIVE_Z',up_axis='Y');return[o for o in bpy.context.scene.objects if o.type=='MESH']
def base(bones):return {'bones':[{'name':n,'parent':-1,'position':p}for n,p in bones],'materials':[],'vertices':[],'triangles':[]}
def mesh(out,o,transform,matmap):
 me=o.data;me.calc_loop_triangles();offset=len(out['vertices']);norm=[]
 for v in me.vertices:
  p,n,b=transform(v.co,v.normal,o);out['vertices'].append({'bone':b,'position':[round(c)for c in p]});norm.append(n)
 for t in me.loop_triangles:
  out['triangles'].append({'material':matmap[t.material_index],'corners':[{'vertex':offset+vi,'uv':list(me.uv_layers.active.data[li].uv),'normal':[round(c*127)for c in norm[vi]]}for vi,li in zip(t.vertices,t.loops)]})
# The source is a segmented T pose. Lower complete arm parts uniformly at the shoulders.
objects=fresh(next((W/'input/pepsiman/source').rglob('*.obj')));bottom=min(v.co.y for o in objects for v in o.data.vertices);top=max(v.co.y for o in objects for v in o.data.vertices);scale=9500/(top-bottom)
piv=[Vector((0,0,0)),Vector((0,38,0)),Vector((-24,31,-6)),Vector((24,31,-6))]
model=base([(n,[round(p.x*scale),round((p.y-bottom)*scale),round(p.z*scale)])for n,p in zip(['body','head','left_arm','right_arm'],piv)])
model['materials']=[{'name':'pepsiman','texture':'pepsiman.png','size':[64,64]}];shutil.copyfile(W/'input/pepsiman/textures/Pepsiman.png',D/'pepsiman.png')
def man(p,n,o):
 idx=int(o.name.split('.')[1].split('_')[0]);b=1 if idx==0 else 2 if idx in [2,7,16]else 3 if idx in[8,9,11]else 0;p=p.copy();rot=Matrix.Identity(3)
 if b>=2:rot=Matrix.Rotation(math.radians(65 if b==2 else -65),3,'Z');p=piv[b]+rot@(p-piv[b])
 p.y-=bottom;return p*scale,(rot@n).normalized(),b
for o in objects:mesh(model,o,man,{0:0})
model.update(height_game_units=95,source='ps1-pepsiman-the-running-hero-pepsim.zip');(R/'tools/pepsiman_source.json').write_text(json.dumps(model,separators=(',',':'))+'\n')
# Keep a low-resolution can, plus a crushed variant; remove microscopic rim detail.
for name,key,target in [('can','ps1',.40),('crushed','crushed',.17)]:
 objects=fresh(next((W/f'input/{key}/source').rglob('*.obj')));out=base([('static',[0,0,0])])
 if key=='ps1':
  out['materials']=[{'name':'label','texture':'can_label.png','size':[64,64]},{'name':'lid','texture':'can_lid.png','size':[32,32]}]
  shutil.copyfile(W/'input/ps1/textures/pepsi_zad_ps1.png',D/'can_label.png');shutil.copyfile(W/'input/ps1/textures/pepsi_verh.jpeg',D/'can_lid.png')
 else:
  out['materials']=[{'name':'crushed','texture':'crushed.png','size':[64,64]}];shutil.copyfile(W/'input/crushed/textures/Pepsi_can_Crushed_Aluminum_Pepsi_can_BaseC.png',D/'crushed.png')
 for o in objects:
  bpy.context.view_layer.objects.active=o;mod=o.modifiers.new('N64 can reduction','DECIMATE');mod.ratio=target;bpy.ops.object.modifier_apply(modifier=mod.name)
 vs=[v.co for o in objects for v in o.data.vertices];center=Vector(((min(v.x for v in vs)+max(v.x for v in vs))/2,min(v.y for v in vs),(min(v.z for v in vs)+max(v.z for v in vs))/2));s=(650/(max(v.y for v in vs)-center.y))if key=='ps1'else(650/(max(v.x for v in vs)-min(v.x for v in vs)))
 for o in objects:mesh(out,o,lambda p,n,o:((p-center)*s,n.normalized(),0),{i:i if key=='ps1'else 0 for i in range(len(o.data.materials))})
 out.update(source=key,height_game_units=round((max(v.y for v in vs)-center.y)*s/100,2));(R/f'tools/pepsi_{name}_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
 print(name,len(out['triangles']),'triangles',out['height_game_units'],'high')
print('Pepsiman',len(model['triangles']),'triangles',model['height_game_units'],'high')

__import__('runpy').run_path(str(R/'tools/tile_pepsiman_texture.py'))

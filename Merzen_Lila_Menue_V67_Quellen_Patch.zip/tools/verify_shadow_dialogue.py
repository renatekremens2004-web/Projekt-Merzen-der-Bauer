"""Check the dialogue-only release against the previous Wallace gesture build."""
from pathlib import Path
import csv, hashlib, json, re, struct, subprocess, sys
from ipl3checksum import CICKind, calculateChecksum
from verify_story import segment, check_buffers
from build_story import messages, controls, tokens, plain, split_pages

R=Path(__file__).resolve().parent.parent; O=Path(sys.argv[1]).resolve(); W=Path(sys.argv[2]).resolve(); B=O/'build/pal-1.0'
before=(W/'baseline.z64').read_bytes(); after=(B/'oot-pal-1.0-compressed.z64').read_bytes(); unpacked=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(before).hexdigest()=='85b2e36dea8fa9bd3fd33a4d012581c4ecfc5219fe4e0607dcebcba5b5a5e339'
assert len(after)==41943040 and struct.unpack_from('>II',after,16)==calculateChecksum(after,CICKind.CIC_X105)
old=messages((W/'baseline_message_data.h').read_text()); new=messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
expected=set(json.loads((R/'story/schatten_brunnen_de.json').read_text())['messages']); changed=set()
assert old.keys()==new.keys()
for ident in old:
    assert old[ident]['header']==new[ident]['header']
    for lang in [0,1,3]: assert old[ident]['parts'][lang][2]==new[ident]['parts'][lang][2],(ident,lang)
    a=old[ident]['parts'][2][2]; b=new[ident]['parts'][2][2]
    assert controls(a)==controls(b),(ident,'functional controls')
    if 'NAME'in tokens(a): assert 'NAME'in tokens(b),(ident,'player name')
    if a!=b: changed.add(ident)
assert changed==expected and len(changed)==19
assert old['0191']['parts'][2][2]==new['0191']['parts'][2][2]
assert (W/'baseline_z_elf_message.c').read_bytes()==(O/'src/code/z_elf_message.c').read_bytes()
edits={}
for p in sorted((R/'story').glob('*.json')):
    for ident,e in json.loads(p.read_text())['messages'].items():
        assert ident not in edits; edits[ident]=e
assert len(edits)==1024
buffers=check_buffers(B,edits)
def syms(p):
    d={}
    for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()): d.setdefault(n,int(x,16))
    return d
oldsyms=syms(W/'baseline.map'); newsyms=syms(B/'oot-pal-1.0.map')
relocs={}; section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
    m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
    if m: section=m[1]; relocs.setdefault(section,{})
    m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
    if m and section: relocs[section][int(m[1],16)]=(m[2],m[3])
same=[]; relocated=[]; intentional=[]; verified=0
names=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())]
for i,name in enumerate(names):
    _,_,a=segment(before,i); start,end,b=segment(after,i)
    if b is None: continue
    if name=='makerom': assert b[:16]==unpacked[start:start+16]and b[24:]==unpacked[start+24:end]
    elif name!='dmadata': assert b==unpacked[start:end],name; verified+=1
    if a==b: same.append(name); continue
    if name in ['makerom','dmadata','ger_message_data_static']:
        intentional.append(dict(segment=name,before_bytes=len(a),after_bytes=len(b))); continue
    assert len(a)==len(b),(name,'unexpected segment growth')
    base=newsyms['_'+name+'SegmentStart']; words=sorted({j//4*4 for j,(x,y)in enumerate(zip(a,b))if x!=y})
    for offset in words:
        address=base+offset
        if name=='code'and newsyms['sGerMessageEntryTable']<=address<newsyms['sFraMessageEntryTable']: continue
        rel=relocs.get(name,{}).get(address); assert rel,(name,hex(address),'unexplained difference')
        kind,target=rel
        if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']: assert a[offset:offset+2]==b[offset:offset+2]
        elif kind=='R_MIPS_26': assert a[offset]>>2==b[offset]>>2
        else: assert kind=='R_MIPS_32',kind
    relocated.append(dict(segment=name,changed_words=len(words)))
assert verified==1509
# All native machine code, models and cutscene data are retained. The only
# changed segments besides German text/header/DMA are genuinely linked pointers.
report=dict(rom_sha256=hashlib.sha256(after).hexdigest(),baseline_sha256=hashlib.sha256(before).hexdigest(),rom_bytes=len(after),crc=['%08X'%x for x in struct.unpack_from('>II',after,16)],changed_messages=sorted(changed),unchanged_0191=True,other_languages_unchanged=True,all_other_messages_unchanged=True,functional_controls_and_player_names_retained=True,native_hint_logic_unchanged=True,compressed_segments_verified=verified,text_buffers=buffers,intentional_segments=intentional,relocation_only_segments=relocated,identical_segments=same)
(B/'shadow-dialogue-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print('Verified',len(changed),'new chapter messages;',len(edits),'custom messages total;',verified,'segments; all other dialogue, models, actor logic and cutscenes retained.')
print('Largest raw message',buffers['largest_raw_message_bytes'],'of 1280; new Sheik speech',buffers['messages']['5031'])

"""Convert user Wallace Freeman OBJ to own rigid body/head/arms; Blender only for conversion."""
import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent;src=Path(sys.argv[sys.argv.index('--')+1]);D=R/'models/wallace-adult';D.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.obj_import(filepath=str(src/'wallace freeman.obj'),forward_axis='NEGATIVE_Z',up_axis='Y')
# OBJ coordinates are already N64 X/Y-up/Z-forward. Ignore importer axis conversion.
objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];out={'bones':[{'name':x,'parent':-1,'position':[0,0,0]} for x in ['body','head','left_arm','right_arm']],'materials':[],'vertices':[],'triangles':[],'actor_setup':True}
pivots=[Vector((0,0,0)),Vector((0,60,0)),Vector((7,59,0)),Vector((-7,59,0))];scale=9000/76.950628
# Build each material independently; duplicate body surface and optional eyelid variants are discarded.
for o in objects:
 mesh=o.data;names=[m.name for m in mesh.materials]
 for mi,name in enumerate(names):
  if name.startswith(('gordon_sheet.002','sk41_wallace_eyelid')):continue
  faces=[p for p in mesh.polygons if p.material_index==mi]
  if not faces:continue
  used=sorted({v for p in faces for v in p.vertices});lookup={v:i for i,v in enumerate(used)}
  me=bpy.data.meshes.new(name);me.from_pydata([mesh.vertices[i].co for i in used],[],[[lookup[v] for v in p.vertices]for p in faces]);me.update();uv=me.uv_layers.new()
  for p,original in zip(me.polygons,faces):
   for li,ori in zip(p.loop_indices,original.loop_indices):uv.data[li].uv=mesh.uv_layers.active.data[ori].uv
  obj=bpy.data.objects.new(name,me);bpy.context.collection.objects.link(obj);bpy.context.view_layer.objects.active=obj
  mod=obj.modifiers.new('N64 reduction','DECIMATE');mod.ratio=.30 if name.startswith('gordon') else (.55 if 'head' in name else .20);bpy.ops.object.modifier_apply(modifier=mod.name)
  me=obj.data;me.calc_loop_triangles();offset=len(out['vertices']);rotations=[]
  for v in me.vertices:
   p=v.co.copy();bone=1 if name.startswith('sk41') else (2 if p.x>8 and p.y>29 else 3 if p.x< -8 and p.y>29 else 0);rot=Matrix.Identity(3)
   if bone>=2:
    # Original is an A-pose: lower arms about their own shoulders, uniformly.
    rot=Matrix.Rotation(math.radians(-30 if bone==2 else 30),3,'Z');p=pivots[bone]+rot@(p-pivots[bone])
   p.y+=.087118
   out['vertices'].append({'bone':bone,'position':[round(x*scale) for x in p]});rotations.append(rot)
  texture=('gordon_sheet.png' if name.startswith('gordon') else name.split('.001')[0]+'.png');shutil=__import__('shutil');shutil.copyfile(src/texture,D/texture)
  mat=len(out['materials']);out['materials'].append({'name':name.replace('.','_'),'texture':texture,'size':[64,64]})
  for t in me.loop_triangles:
   cs=[]
   for vi,li in zip(t.vertices,t.loops):
    normal=rotations[vi]@me.vertices[vi].normal;normal.normalize();cs.append({'vertex':offset+vi,'uv':list(me.uv_layers.active.data[li].uv),'normal':[round(x*127)for x in normal]})
   out['triangles'].append({'material':mat,'corners':cs})
for b,p in zip(out['bones'],pivots):b['position']=[round(p.x*scale),round((p.y+.087118)*scale),round(p.z*scale)]
out['pivots']=[b['position']for b in out['bones']];out['height_game_units']=90;out['source']='User uploaded wallace-freeman-hl2-but-ruined-by-mods.zip/source/wallace freeman.obj'
(R/'tools/wallace_adult_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n');print('ADULT_WALLACE',len(out['triangles']),'tris',out['pivots'])

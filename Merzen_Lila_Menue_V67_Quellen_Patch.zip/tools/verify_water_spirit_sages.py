"""Verify Water/Spirit sage replacements against the published Forest Temple/Sahur baseline."""
from pathlib import Path
import argparse,csv,hashlib,json,math,re,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as dialogue
ROOT=Path(__file__).resolve().parent.parent
BASE_SHA='4c8b47f2932793016b1ea3ee7ce45f1ca1b054ad91742a9677ed98b7a26d584c'

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('oot',type=Path);ap.add_argument('baseline',type=Path);args=ap.parse_args()
    oot=args.oot.resolve();build=oot/'build/pal-1.0'
    old=args.baseline.read_bytes();packed=(build/'oot-pal-1.0-compressed.z64').read_bytes()
    plain=(build/'oot-pal-1.0.z64').read_bytes()
    assert hashlib.sha256(old).hexdigest()==BASE_SHA
    assert len(packed)==33554432 and packed[0x3e:0x40]==b'P\0'
    assert struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
    mp=(build/'oot-pal-1.0.map').read_text()
    symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):
        symbols.setdefault(name,int(address,16))
    def sym(name):
        return symbols[name]
    elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(build/'oot-pal-1.0.elf')],text=True)
    rels={};current=None
    for line in elf.splitlines():
        header=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
        if header:
            current=header[1];rels.setdefault(current,{})
        entry=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
        if current and entry:
            rels[current][int(entry[1],16)]=(entry[2],entry[3])
    intentional={'makerom','dmadata','code','ger_message_data_static','object_dekujr','ovl_Obj_Dekujr','object_ru2','object_nb','ovl_En_Ru2','ovl_En_Nb','ovl_En_Ik','ovl_Demo_Sa','jyasinboss_scene','kenjyanoma_scene'}
    identical=[];relocated=[];changed=[];verified=0;object_bytes=None
    names=[r['Name'] for r in csv.DictReader((oot/'baseroms/pal-1.0/segments.csv').open())]
    for index,name in enumerate(names):
        _,_,before=segment(old,index)
        start,end,unpacked=segment(packed,index)
        if unpacked is None:
            continue
        expected=plain[start:end]
        if name=='makerom':
            assert unpacked[:16]==expected[:16] and unpacked[24:]==expected[24:]
        elif name!='dmadata':
            assert unpacked==expected,('compression',name)
            verified+=1
        lo,hi=[sym('_'+name+'SegmentRom'+suffix) for suffix in ['Start','End']]
        after=plain[lo:hi]
        if name=='object_im':
            object_bytes=len(after)
            assert len(after)<=86016,('object memory budget exceeded',len(after))
        if before==after:
            identical.append(name);continue
        if name in intentional:
            changed.append({'segment':name,'before_bytes':len(before),'after_bytes':len(after)});continue
        assert len(before)==len(after),('unexpected size change',name,len(before),len(after))
        origin=sym('_'+name+'SegmentStart')
        differences=sorted({i//4*4 for i,(x,y) in enumerate(zip(before,after)) if x!=y})
        for offset in differences:
            rel=rels.get(name,{}).get(origin+offset)
            assert rel,('unexplained changed word',name,hex(origin+offset))
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[offset:offset+2]==after[offset:offset+2],(name,rel)
            elif kind=='R_MIPS_26':
                assert before[offset]>>2==after[offset]>>2,(name,rel)
            else:
                assert kind=='R_MIPS_32',(name,rel)
        relocated.append({'segment':name,'relocated_words':len(differences)})
    assert verified==1509
    # Read the actual ROM language tables, rather than trusting generated JSON alone.
    # Symbols from the SHA256-pinned published baseline ELF.
    old_symbols={}
    def german_messages(rom,tab,code_base):
        _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'))
        off=tab-code_base;entries=[]
        # PAL German table contains only pointers; IDs/order come from NES entries.
        ids=[];nes=(old_symbols if rom==args.baseline.read_bytes() else symbols)['sNesMessageEntryTable']-code_base
        while True:
            ident=struct.unpack_from('>H',code,nes)[0]
            if ident==0xffff:break
            if ident!=0xfffc:ids.append(ident)
            nes+=8
        for i,ident in enumerate(ids):entries.append((ident,struct.unpack_from('>I',code,off+4*i)[0]&0xffffff))
        result={}
        for i,(ident,start) in enumerate(entries):
            end=entries[i+1][1] if i+1<len(entries) else len(data)
            result[ident]=data[start:end].rstrip(bytes([0]))
        return result
    _,_,before_code=segment(args.baseline.read_bytes(),names.index('code'))
    _,_,after_code=segment(packed,names.index('code'))
    baseline_map=(args.baseline.parent/'baseline.map').read_text()
    baseline_symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',baseline_map):
        baseline_symbols.setdefault(name,int(address,16))
    old_symbols=baseline_symbols
    # Apply ONLY the exact 3130 camera-coordinate delta to the comparison copy.
    # All other core words must still be unchanged or verified relocations.
    marker=struct.pack('>6f',0,45,0,0,45,50)
    assert before_code.count(marker)==1
    array=before_code.index(marker)-0x28-0x10
    camera=before_code[array:array+12*0x28]
    for e in json.loads((ROOT/'tools/sage_camera_edits.json').read_text()):
        if e['script']!='water-onepoint3130':continue
        def vector(v):return struct.pack('>3f',*map(float,re.findall(r'(-?\d+\.\d+)f',v)))
        a,b=vector(e['before']),vector(e['after']);assert camera.count(a)==e['count'],e
        camera=camera.replace(a,b)
    before_code=before_code[:array]+camera+before_code[array+12*0x28:]
    oldbase=baseline_symbols['_codeSegmentStart'];newbase=sym('_codeSegmentStart')
    anchors={oldbase:(newbase,['_codeSegmentStart'])}
    for name,addr in baseline_symbols.items():
        if name not in symbols:continue
        current=sym(name)
        if oldbase<=addr<oldbase+len(before_code) and newbase<=current<newbase+len(after_code):
            if addr in anchors:
                assert anchors[addr][0]==current,('alias movement',name)
                anchors[addr][1].append(name)
            else:anchors[addr]=(current,[name])
    anchors[oldbase+len(before_code)]=(newbase+len(after_code),['code ROM end'])
    order=sorted(anchors);code_relocations=[];padding=[]
    for lo,hi in zip(order,order[1:]):
        start,names_at=anchors[lo];end=anchors[hi][0]
        before=before_code[lo-oldbase:hi-oldbase];after=after_code[start-newbase:end-newbase]
        if len(before)!=len(after):
            common=min(len(before),len(after));assert abs(len(before)-len(after))<=16,('unexpected interval growth',names_at,len(before),len(after))
            assert all(x==0 for x in before[common:]+after[common:]),('non-padding growth',names_at)
            padding.append({'symbols':names_at,'before':len(before),'after':len(after)})
        common=min(len(before),len(after));assert common%4==0
        for i in range(0,common,4):
            if baseline_symbols['sGerMessageEntryTable']<=lo+i<baseline_symbols['sFraMessageEntryTable']:continue
            if before[i:i+4]==after[i:i+4]:continue
            addr=start+i;rel=rels.get('code',{}).get(addr);assert rel,('unexpected core word',hex(addr),names_at)
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[i:i+2]==after[i:i+2],(hex(addr),rel)
            elif kind=='R_MIPS_26':assert before[i]>>2==after[i]>>2,(hex(addr),rel)
            else:
                assert kind=='R_MIPS_32',rel
                oldword=struct.unpack_from('>I',before,i)[0];newword=struct.unpack_from('>I',after,i)[0]
                if target=='..code':
                    import bisect
                    assert oldbase<=oldword<baseline_symbols['_codeSegmentEnd'],('section pointer',hex(oldword))
                    if oldword>=order[-1]:expected=oldword+sym('_codeSegmentDataStart')-baseline_symbols['_codeSegmentDataStart']
                    else:
                        key=order[bisect.bisect_right(order,oldword)-1];expected=anchors[key][0]+oldword-key
                    assert newword==expected,('section pointer movement',hex(addr),hex(oldword),hex(newword),hex(expected))
                else:
                    assert (oldword-baseline_symbols[target])&0xffffffff == (newword-sym(target))&0xffffffff,('relocation addend',hex(addr),target)
            code_relocations.append({'address':hex(addr),'type':kind,'target':target})

    before_text=german_messages(old,old_symbols['sGerMessageEntryTable'],old_symbols['_codeSegmentStart'])
    after_text=german_messages(packed,sym('sGerMessageEntryTable'),sym('_codeSegmentStart'))
    changed_ids={i for i in before_text if before_text[i]!=after_text[i]}
    manifest=json.loads((ROOT/'planning/SAGE_NAMEN.json').read_text())
    assert changed_ids=={int(x,16) for x in manifest}
    # The target text encoding represents ä by 0x93 (see PAL charmap).
    for ident in changed_ids:
        expected=before_text[ident].replace(b'Nabooru',b'Waluigi').replace(b'Naboru',b'Waluigi')
        if ident in {0x003d,0x4013,0x403e,0x4043,0x4045,0x4059}:expected=expected.replace(b'Ruto',b'Thadd'+bytes([0x93])+b'us')
        assert expected==after_text[ident],('non-name text change',hex(ident))
    assert {'object_ru1','object_zo','object_sa','object_im','object_rl','bdan_room_3','spot01_room_0','HAKAdan_room_0'}<=set(identical)
    edits={}
    native=dialogue.messages((ROOT/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
    current=dialogue.messages((oot/'extracted/pal-1.0/text/message_data.h').read_text())
    chain={'704F':'0121','0121':'0122','0122':'0123'}
    for path in (ROOT/'story').glob('*.json'):
        for ident,entry in json.loads(path.read_text())['messages'].items():
            assert ident not in edits;edits[ident]=entry
            src=native[entry.get('native_template',ident)]['parts'][2][2];dst=current[ident]['parts'][2][2]
            assert dialogue.controls(src)+(['TEXTID(0x'+chain[ident]+')'] if ident in chain else [])==dialogue.controls(dst),ident
    assert len(edits)==724
    for ident in manifest:edits.setdefault(ident,{})
    from verify_bowling_sage_revision import function_bodies
    # Every old gameplay function stays verbatim except these reviewed model adapters.
    allowed={'En_Ru2':{'EnRu2_Init','EnRu2_WaterTempleEncounterRangeCheck','EnRu2_WaterTempleEncounterUnconditional','EnRu2_WaterTempleEncounterBegin','EnRu2_WaterTempleEncounterDialog','EnRu2_WaterTempleEncounterEnd','EnRu2_WaterTempleSwimmingUp'},'En_Nb':{'EnNb_Init','func_80AB2FC0','EnNb_OverrideLimbDraw'},'En_Ik':{'EnIk_OverrideLimbDrawDefeat','EnIk_CsDrawDefeat'}}
    function_changes={}
    for actor,permit in allowed.items():
        rel='src/overlays/actors/ovl_'+actor+'/z_'+actor.lower()+'.c'
        a=function_bodies((ROOT/'tools/originals/water_spirit_sages'/rel).read_text());b=function_bodies((oot/rel).read_text())
        fnchanged={n for n in a if a[n]!=b[n]};function_changes[actor]=sorted(fnchanged)
        # Two medallion-script assignment functions additionally point to private cameras.
        for n in fnchanged-permit:
            assert b[n].replace('gSquidWaterMedallionCs','gWaterMedallionCs').replace('gWaluigiSpiritMedallionCs','gSpiritMedallionCs')==a[n],(actor,n)
    # Camera files differ only at the recorded XYZ points, all cues/timings are exact.
    cameras=json.loads((ROOT/'tools/sage_camera_edits.json').read_text())
    for label,rel,newname,oldname in [('water','src/overlays/actors/ovl_En_Ru2/z_en_ru2_cutscene_data.inc.c','gSquidWaterMedallionCs','gWaterMedallionCs'),('spirit','src/overlays/actors/ovl_En_Nb/z_en_nb_cutscene_data.inc.c','gWaluigiSpiritMedallionCs','gSpiritMedallionCs')]:
        src=(oot/rel).read_text();start=src.index('static CutsceneData '+oldname);src=src[start:src.index('};',start)+2];both=(ROOT/'tools/sage_medallion_cameras.inc.c').read_text();a=both.index('static CutsceneData '+newname);dst=both[a:both.index('};',a)+2]+'\n'
        for e in reversed([e for e in cameras if e['script']==label]):
            assert e['after'] in dst;dst=dst.replace(e['after'],e['before'],1)
        assert dst.replace(newname,oldname).strip()==src.strip(),label
    rel='extracted/pal-1.0/assets/scenes/dungeons/jyasinboss/gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c'
    a=(ROOT/'tools/originals/water_spirit_sages'/rel).read_text();b=(oot/rel).read_text()
    for e in reversed([e for e in cameras if e['script']=='knuckle-defeat']):b=b.replace(e['after'],e['before'],1)
    assert a==b
    rel='extracted/pal-1.0/assets/scenes/indoors/kenjyanoma/gChamberOfSagesSealOpeningCs.csdata.inc.c'
    a=(ROOT/'tools/originals/water_spirit_sages'/rel).read_text();b=(oot/rel).read_text()
    for e in reversed([e for e in cameras if e['script'].startswith('sealing-')]):b=b.replace(e['after'],e['before'],1)
    assert a==b
    refs=json.loads((ROOT/'tools/sage_animation_reference.json').read_text());model_report={}
    from rigid_math import fk,points
    import numpy as np
    for obj,src,prefix,count,tri in [('object_ru2','squid_sage','SquidSage',27,254),('object_nb','waluigi_sage','WaluigiSage',14,420)]:
        m=json.loads((ROOT/'tools'/(src+'_source.json')).read_text());assert len(m['bones'])==count and len(m['triangles'])==tri
        data=segment(packed,names.index(obj))[2];_,actual=struct.unpack_from('>IB',data,sym('g'+prefix+'Skel')&0xffffff);assert actual==count
        for name,frames in refs[obj]['animations'].items():
            assert len(m['animations'][name])==len(frames)
            assert struct.unpack_from('>h',data,sym(name)&0xffffff)[0]==len(frames)
        for frames in m['animations'].values():
            for frame in frames:
                assert set(frame)=={'root','rotation'} and len(frame['rotation'])==count
                world=fk(m['bones'],frame)
                for i,b in enumerate(m['bones']):
                    if b['parent']<0:continue
                    assert abs(np.linalg.norm(world[i][:3,3]-world[b['parent']][:3,3])-np.linalg.norm(b['position']))<1e-6
        for t in m['triangles']:
            for c in t['corners']:assert abs(np.linalg.norm(c['normal'])-127)<1.1
        before=len(segment(old,names.index(obj))[2]);model_report[obj]={'before_bytes':before,'after_bytes':len(data),'saved_bytes':before-len(data),'own_bones':count,'triangles':tri,'native_animation_frames_preserved':True}
    assert len(json.loads((ROOT/'tools/waluigi_sage_source.json').read_text())['animations']['gWaluigiKnuckleRevealAnim'])==60
    # Census all native room lists that load either replaced model.
    obj=dict((enum,name) for name,enum in re.findall(r'DEFINE_OBJECT\((\w+), (\w+)\)',(oot/'include/tables/object_table.h').read_text()));budgets=[]
    for path in (oot/'extracted/pal-1.0/assets/scenes').rglob('*ObjectList.inc.c'):
        text=path.read_text()
        if not re.search(r'\bOBJECT_(RU2|NB|DEKUJR)\b',text):continue
        objs=['gameplay_keep','object_link_boy','gameplay_field_keep']+[obj[x] for x in re.findall(r'\bOBJECT_\w+',text)]
        size=sum(sym('_'+x+'SegmentRomEnd')-sym('_'+x+'SegmentRomStart') for x in dict.fromkeys(objs));cap=(1226 if 'kenjyanoma' in str(path) and any(x in path.name for x in ['AltHeaders_03000180','AltHeaders_03000230']) else 1050 if 'kenjyanoma' in str(path) else 1000)*1024-4096
        assert size<cap,(path,size,cap)
        budgets.append({'room':str(path.relative_to(oot/'extracted/pal-1.0/assets/scenes')),'bytes':size,'conservative_capacity':cap,'remaining':cap-size})
    # Original sprout cues/root motion and all previous cameo geometry stay intact.
    rel='src/overlays/actors/ovl_Obj_Dekujr/z_obj_dekujr.c';a=function_bodies((ROOT/'tools/originals/sahur'/rel).read_text());b=function_bodies((oot/rel).read_text())
    for n in ['ObjDekujr_GetCueStartPos','ObjDekujr_GetCueEndPos','ObjDekujr_ComeUp']:assert a[n]==b[n]
    assert 'Matrix_RotateY(-1.062f' in (oot/rel).read_text() and '0.0111111111f' in (oot/rel).read_text()
    # Name replacements must still fit their native lines (no reflow or timing changes).
    layout=dialogue.Layout(oot);data=(build/'assets/text/ger_message_data_static.o.bin').read_bytes()
    nm=subprocess.check_output(['mips-linux-gnu-nm','-S',str(build/'assets/text/ger_message_data_static.o')],text=True)
    ns={m[3].upper():(int(m[1],16),int(m[2],16)) for m in re.finditer(r'^([0-9a-f]+) ([0-9a-f]+) R _message_0x([0-9a-fA-F]+)_ger$',nm,re.M)}
    arg={5:1,6:1,7:2,12:1,14:1,17:2,18:2,19:1,20:1,21:3,30:1};name_layout={}
    for ident in manifest:
        start,size=ns[ident];raw=data[start:start+size];i=0;width=0;lines=[]
        while i<len(raw):
            c=raw[i]
            if c in [1,2,4,12]:lines.append(width);width=0
            elif c==6:width+=raw[i+1]
            elif c==15:width+=layout.width('{name}')
            elif c>=32:width+=6 if c==32 else int(layout.widths[c-32]*.75)
            i+=1+arg.get(c,0)
        name_layout[ident]=max(lines+[width]);limit=180 if 'ITEM_ICON(' in current[ident]['parts'][2][2] else 210
        assert name_layout[ident]<=limit,(ident,name_layout[ident],limit)
    original_deku=segment(old,names.index('object_dekujr'))[2];new_deku=segment(packed,names.index('object_dekujr'))[2]
    assert original_deku[:13584]==new_deku[:13584]
    model=json.loads((ROOT/'tools/sahur_source.json').read_text());assert len(model['triangles'])==1436 and len(model['bones'])==25
    report={'rom_sha256':hashlib.sha256(packed).hexdigest(),'rom_bytes':len(packed),'baseline_sha256':BASE_SHA,'compressed_segments_verified':verified,'identical_segments':identical,'relocated_segments':relocated,'intentional_changes':changed,'core_relocations_checked':len(code_relocations),'changed_german_ids':sorted(f'{x:04X}' for x in changed_ids),'dialogue_buffers':check_buffers(build,edits),'models':model_report,'room_budgets':budgets,'function_changes':function_changes,'camera_timing_preserved':True,'camera_xyz_edits':len(cameras),'sahur_height':60,'sahur_object_bytes':len(new_deku),'name_line_pixels':name_layout,'sahur_native_yaw_correction_radians':-1.062}
    (build/'water-spirit-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Verified',verified,'compressed segments;',len(identical),'identical;',len(changed_ids),'name-only messages;',len(edits),'message buffers;',model_report)
if __name__=='__main__':main()

"""Convert the supplied N64 South Park OBJ models without polygon reduction.

python3 tools/export_kenny.py <workdir>; extracted user files under input/alive,
input/dead. OBJ coordinates are Y-up. The corpse is laid on its back offline.
"""
from pathlib import Path
import hashlib,json,math,shutil,sys
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[1]);report={}
for key,folder in [('kenny','alive'),('kenny_dead','dead')]:
 source=next((W/'input'/folder).rglob('*.obj'));root=source.parent
 vertices=[];normals=[];uvs=[];faces=[];material=None
 for line in source.read_text().splitlines():
  s=line.split()
  if not s:continue
  if s[0]=='v':vertices.append(list(map(float,s[1:4])))
  elif s[0]=='vt':uvs.append(list(map(float,s[1:3])))
  elif s[0]=='vn':normals.append(list(map(float,s[1:4])))
  elif s[0]=='usemtl':material=s[1]
  elif s[0]=='f':
   corners=[[int(n)-1 if n else None for n in x.split('/')]for x in s[1:]]
   for j in range(1,len(corners)-1):faces.append((material,[corners[0],corners[j],corners[j+1]]))
 dead=key=='kenny_dead';height=max(v[1]for v in vertices)-min(v[1]for v in vertices);scale=4800/height
 def transform(p):return [p[0],p[2],-p[1]]if dead else p[:]
 points=[transform(p)for p in vertices];lo=[min(p[i]for p in points)for i in range(3)];hi=[max(p[i]for p in points)for i in range(3)];center=[(lo[0]+hi[0])/2,lo[1],(lo[2]+hi[2])/2]
 mats={};textures={};name=None
 for line in source.with_suffix('.mtl').read_text().splitlines():
  if line.startswith('newmtl '):name=line.split(maxsplit=1)[1]
  if line.startswith('map_Kd '):textures[name]=line.split(maxsplit=1)[1]
 D=R/'models'/key;D.mkdir(parents=True,exist_ok=True)
 from PIL import Image
 for mat,_ in faces:
  if mat in mats:continue
  tex=textures[mat];shutil.copyfile(root/tex,D/tex);mats[mat]=dict(name=mat,texture=tex,size=list(Image.open(root/tex).size))
 m=dict(bones=[dict(name='root',parent=-1,position=[0,0,0])],materials=list(mats.values()),vertices=[dict(bone=0,position=[round((p[i]-center[i])*scale)for i in range(3)])for p in points],triangles=[],uniform_scale=True,native_lighting=True,static=dead,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),original_triangles=len(faces),dimensions_game_units=[round((hi[i]-lo[i])*scale/100,2)for i in range(3)])
 for mat,corners in faces:
  out=[]
  for vi,ti,ni in corners:
   normal=transform(normals[ni]);length=math.sqrt(sum(v*v for v in normal));out.append(dict(vertex=vi,uv=uvs[ti],normal=[round(v/length*127)for v in normal]))
  m['triangles'].append(dict(material=list(mats).index(mat),corners=out))
 (R/'tools'/f'{key}_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');report[key]=dict(triangles=len(faces),dimensions=m['dimensions_game_units'],unchanged_geometry=True,lying_on_back=dead)
 print(key,report[key])
(W/'models.json').write_text(json.dumps(report,indent=2)+'\n')

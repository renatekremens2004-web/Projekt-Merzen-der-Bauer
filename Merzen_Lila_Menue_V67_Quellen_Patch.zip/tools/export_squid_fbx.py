"""Blender export: preserve the supplied rigid SuperSponge rig and poses."""
import bpy,json,math,sys,hashlib
from mathutils import Matrix,Vector
from pathlib import Path
ROOT=Path(__file__).resolve().parent;W=ROOT.parent/'models/squid';dest=ROOT/'squid_source.json'
p=W/'Breathe.fbx'
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(p));rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');obj=next(o for o in bpy.context.scene.objects if o.type=='MESH');mesh=obj.data;mesh.calc_loop_triangles();scene=bpy.context.scene
A=Matrix(((1,0,0),(0,0,1),(0,-1,0)));bones=list(rig.data.bones);idx={b.name:i for i,b in enumerate(bones)}
# Retain all 27 source bones, including finger/toe tips for future motions.
rest=[A.to_4x4()@rig.matrix_world@b.matrix_local for b in bones];positions=[A@(obj.matrix_world@v.co) for v in mesh.vertices];ground=min(v.y for v in positions);height=max(v.y for v in positions)-ground;scale=10000/height;offset=Vector((-(min(v.x for v in positions)+max(v.x for v in positions))/2,-ground,0))
def ints(v):return [int(round(x)) for x in v]
def angle(r):return [int(round(v*32768/math.pi))%65536 for v in r.to_euler('XYZ')]
out={'model':'SuperSponge Squidward','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scale':scale,'height':10000,'bones':[],'vertices':[],'triangles':[],'materials':[],'animations':{}}
for i,b in enumerate(bones):
 parent=idx[b.parent.name] if b.parent else -1;local=rest[parent].inverted()@rest[i] if parent>=0 else rest[i]
 out['bones'].append({'name':b.name,'parent':parent,'position':ints(local.translation*scale),'rest_rotation':angle(local.to_3x3()),'world_head':list(rest[i].translation),'world_matrix':[list(row) for row in rest[i]]})
for v,pw in zip(mesh.vertices,positions):
 assert len(v.groups)==1 and abs(v.groups[0].weight-1)<1e-5
 bone=idx[obj.vertex_groups[v.groups[0].group].name];local=rest[bone].inverted()@pw
 out['vertices'].append({'bone':bone,'position':ints(local*scale),'source_world':list((pw+offset)*scale)})
for tri in mesh.loop_triangles:
 corners=[]
 for li in tri.loops:
  vi=mesh.loops[li].vertex_index;bone=out['vertices'][vi]['bone'];normal=(rest[bone].to_3x3().inverted()@A@obj.matrix_world.to_3x3().inverted().transposed()@mesh.corner_normals[li].vector).normalized()
  corners.append({'vertex':vi,'normal':ints(normal*127),'uv':list(mesh.uv_layers.active.data[li].uv)})
 out['triangles'].append({'corners':corners,'material':tri.material_index})
for m in mesh.materials:
 images=[n.image.name for n in m.node_tree.nodes if n.type=='TEX_IMAGE'] if m.use_nodes else []
 out['materials'].append({'name':m.name,'color':list(m.diffuse_color),'images':images});print('MATERIAL',m.name,list(m.diffuse_color),images)
# Keep bone lengths fixed. Pose-local translations other than the root are
# checked below, never copied as scale/stretch channels into OoT.
for label,file in [('breathe',p),('idle',W/'Idle.fbx')]:
 if label=='idle':
  bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(file));rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');scene=bpy.context.scene
 frames=[];translation_error=0
 for f in range(1,91):
  scene.frame_set(f);world=[A.to_4x4()@rig.matrix_world@rig.pose.bones[b['name']].matrix for b in out['bones']];rots=[]
  for i,b in enumerate(out['bones']):
   parent=b['parent'];local=world[parent].inverted()@world[i] if parent>=0 else world[i]
   if parent>=0:translation_error=max(translation_error,(local.translation-Vector(b['position'])/scale).length*scale)
   rots.append(angle(local.to_3x3().normalized()))
  frames.append({'root':ints((world[0].translation+offset)*scale),'rotation':rots})
 out['animations'][label]={'fps':30,'frames':frames,'max_child_translation_error_units':translation_error}
 print('ANIM',label,'translation error',translation_error)
dest.write_text(json.dumps(out,separators=(',',':'))+'\n');print('EXPORTED',len(out['triangles']),'triangles',len(out['bones']),'bones; scale',scale)

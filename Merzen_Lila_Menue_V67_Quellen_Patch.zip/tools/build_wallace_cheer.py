"""Apply after build_walk_followup.py: happy inventor gestures only for the Fire Temple prisoner."""
from pathlib import Path
import sys
from n64_model import emit
from rig_wallace_elbows import rig
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();m=rig()
for path,prefix in [('assets/objects/object_du','AdultWallace'),('assets/scenes/dungeons/HIDAN','PrisonWallace')]:
 s=emit(m,R/'models/wallace-adult',prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');(O/'extracted/pal-1.0'/path/'wallace_adult_model.inc.c').write_text(s)
for overlay in ['En_Go2','Demo_Du']:
 d=O/'src/overlays/actors'/('ovl_'+overlay);(d/'wallace_adult_draw.inc.c').write_bytes((R/'tools/wallace_adult_draw.inc.c').read_bytes());p=d/('z_'+overlay.lower()+'.c');s=p.read_text()
 if overlay=='En_Go2':
  old='((60 - this->animTimer) & 15) * (3.14159265358979323846f / 8.0f));'
  new='((60 - this->animTimer) & 15) * (3.14159265358979323846f / 8.0f), 1.0f);'
 else:
  old='return WallaceAdult_Draw(&this->actor, play, gfx, gAdultWallaceDL, arm, head, 0.0f, 0.0f);'
  new='return WallaceAdult_Draw(&this->actor, play, gfx, gAdultWallaceDL, arm, head, 0.0f, 0.0f, 0.0f);'
 assert old in s or new in s;s=s.replace(old,new);p.write_text(s)
print('Wallace: two own elbows, friendly asymmetrical gestures and springy steps; native escape unchanged.')

"""German fusion title only; native combat, cutscene timers and other languages."""
from pathlib import Path
import json
import shutil
import sys

R = Path(__file__).resolve().parent.parent
O = Path(sys.argv[1]).resolve()
backup = R / 'tools/originals/twinrova-dialogue'

def original(rel):
    p = O / rel
    q = backup / rel
    q.parent.mkdir(parents=True, exist_ok=True)
    if not q.exists():
        shutil.copyfile(p, q)
    return p, q.read_text()

p, source = original(Path('src/overlays/actors/ovl_Boss_Tw/z_boss_tw.c'))
old = '''                TitleCard_InitBossName(play, &play->actorCtx.titleCtx, SEGMENTED_TO_VIRTUAL(gTwinrovaTitleCardTex), 160,
                                       180, 128, 40);'''
assert source.count(old) == 1
source = source.replace(old, '''                /* The German epithet introduces the fused witch instead. */
                if (gSaveContext.language != LANGUAGE_GER) {
                    TitleCard_InitBossName(play, &play->actorCtx.titleCtx,
                                           SEGMENTED_TO_VIRTUAL(gTwinrovaTitleCardTex), 160, 180, 128, 64);
                }''')
old = '''                this->work[TW_BLINK_IDX] = 8;
                Sfx_PlaySfxCentered(NA_SE_EN_TWINROBA_YOUNG_WINK);'''
assert source.count(old) == 1
source = source.replace(old, old + '''
                if (gSaveContext.language == LANGUAGE_GER) {
                    TitleCard_InitBossName(play, &play->actorCtx.titleCtx,
                                           SEGMENTED_TO_VIRTUAL(gTwinrovaTitleCardTex), 160, 180, 128, 64);
                }''')
if p.read_text() != source:
    p.write_text(source)

p, source = original(Path('extracted/pal-1.0/assets/objects/object_tw/object_tw.h'))
assert source.count('#define gTwinrovaTitleCardTex_HEIGHT 120') == 1
source = source.replace('#define gTwinrovaTitleCardTex_HEIGHT 120', '#define gTwinrovaTitleCardTex_HEIGHT 192')
if p.read_text() != source:
    p.write_text(source)

rel = Path('extracted/pal-1.0/assets/objects/object_tw/gTwinrovaTitleCardTex.ia8.png')
p = O / rel
q = backup / rel
q.parent.mkdir(parents=True, exist_ok=True)
if not q.exists():
    shutil.copyfile(p, q)
asset = R / 'textures/twinrova-title/gTwinrovaTitleCardTex.ia8.png'
if p.read_bytes() != asset.read_bytes():
    shutil.copyfile(asset, p)
spec = json.loads((R / 'textures/twinrova-title/title.json').read_text())
assert spec['width'] * spec['height'] == 8192
assert 4096 % spec['width'] == 0 and spec['width'] <= 255 and spec['height'] <= 255
print('Twinrova: German epithet at native fusion wink; +9216 object bytes, unchanged combat/timers.')

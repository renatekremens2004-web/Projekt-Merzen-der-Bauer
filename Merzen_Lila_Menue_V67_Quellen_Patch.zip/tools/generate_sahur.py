import bpy,json,math,hashlib
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent.parent;src=R/'models/sahur/tung_tung.fbx'
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(src));rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');obj=next(o for o in bpy.context.scene.objects if o.type=='MESH');rig.animation_data_clear()
for pb in rig.pose.bones:pb.matrix_basis=Matrix.Identity(4)
bpy.context.view_layer.update();A=Matrix(((1,0,0),(0,0,1),(0,-1,0)));bones=[b for b in rig.data.bones if not b.name.endswith('_end')];idx={b.name:i for i,b in enumerate(bones)}
def selected(name):
 b=rig.data.bones[name]
 while b.name not in idx:b=b.parent
 return idx[b.name]
rest=[A.to_4x4()@rig.matrix_world@b.matrix_local for b in bones]
# FBX armature uses uniform 0.01 object scale; bake it into positions before deriving rigid bone coordinates.
for r in rest:
 t=r.translation.copy();r[:]=r.to_3x3().normalized().to_4x4();r.translation=t
ps=[A@(obj.matrix_world@v.co) for v in obj.data.vertices];height=max(p.y for p in ps)-min(p.y for p in ps);scale=5400/height;offset=Vector((0,-min(p.y for p in ps),0))
def ints(v):return [round(x) for x in v]
def angles(m):return [round(a*32768/math.pi)%65536 for a in m.to_euler('XYZ')]
out={'model':'User supplied lowpoly Tung Tung Tung Sahur','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'height':5400,'actor_uniform_scale':.01,'uniform_scale':scale,'source_triangles':1436,'bones':[],'vertices':[],'triangles':[],'materials':[{'name':'wood','texture':'tung_texture.jpg'}],'animations':{}}
for i,b in enumerate(bones):
 p=selected(b.parent.name) if b.parent else -1;local=rest[p].inverted()@rest[i] if p>=0 else rest[i]
 out['bones'].append({'name':b.name,'parent':p,'position':ints(local.translation*scale),'rest_matrix':[list(r) for r in rest[i]]})
mesh=obj.data;mesh.calc_loop_triangles()
for v,p in zip(mesh.vertices,ps):
 weights={}
 for g in v.groups:
  k=selected(obj.vertex_groups[g.group].name);weights[k]=weights.get(k,0)+g.weight
 bone=max(weights,key=weights.get);out['vertices'].append({'bone':bone,'position':ints((rest[bone].inverted()@p)*scale),'source_world':ints((p+offset)*scale)})
for tri in mesh.loop_triangles:
 cs=[]
 for li in tri.loops:
  vi=mesh.loops[li].vertex_index;bone=out['vertices'][vi]['bone'];nw=A@obj.matrix_world.to_3x3().inverted().transposed()@mesh.corner_normals[li].vector;n=(rest[bone].to_3x3().inverted()@nw).normalized();cs.append({'vertex':vi,'normal':ints(n*127),'uv':list(mesh.uv_layers.active.data[li].uv)})
 out['triangles'].append({'material':0,'corners':cs})
# Own restrained idle. Native rising cues move the whole character, not its proportions.
frames=[];world=[r.to_3x3() for r in rest];changes={}
for name in ['LeftArm','RightArm']:
 full='mixamorig:'+name;i=idx[full];d=rest[idx['mixamorig:'+name.replace('Arm','ForeArm')]].translation-rest[i].translation
 # Rotate shoulders toward a relaxed downward arm direction, preserving all source segment lengths.
 target=Vector((.22 if d.x>=0 else -.22,-.97,.08)).normalized();q=d.normalized().rotation_difference(target);delta=q.to_matrix()
 for b in [name,name.replace('Arm','ForeArm'),name.replace('Arm','Hand')]:changes[idx['mixamorig:'+b]]=delta
for f in range(32):
 wr=[(changes.get(i,Matrix.Identity(3))@rest[i].to_3x3()) for i in range(len(bones))];wr[idx['mixamorig:Head']]=Matrix.Rotation(math.radians(.6*math.sin(f*2*math.pi/32)),3,'Y')@wr[idx['mixamorig:Head']];rots=[]
 for i,b in enumerate(out['bones']):rots.append(angles(wr[b['parent']].inverted()@wr[i] if b['parent']>=0 else wr[i]))
 frames.append({'root':ints((rest[0].translation+offset)*scale),'rotation':rots})
out['animations']['idle']=frames
M=R/'models/sahur';M.mkdir(exist_ok=True);(R/'tools/sahur_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print('Sahur',len(out['vertices']),len(out['triangles']),len(bones),'height',height,'scale',scale)

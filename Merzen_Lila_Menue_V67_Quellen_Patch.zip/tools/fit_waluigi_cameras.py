"""Fit only Waluigi camera coordinates to the resized actor, preserving every native cue/timing field."""
from pathlib import Path
import re,json
R=Path(__file__).resolve().parent.parent
POINT=re.compile(r'(CS_CAM_POINT\([^\n]*?CS_FLOAT\([^)]*\),\s*)(-?\d+),\s*(-?\d+),\s*(-?\d+)(,\s*0x[0-9A-Fa-f]+\),)')
def refit(current,reference,starts,anchor,factor,dy):
 def collect(s):
  mode=None;start=None;groups={}
  for line in s.splitlines():
   h=re.search(r'CS_CAM_(EYE|AT)_SPLINE\((\d+),',line)
   if h:mode=h[1];start=int(h[2])
   elif re.search(r'^\s*CS_\w+\(',line)and'CS_CAM_POINT('not in line:mode=None
   m=POINT.search(line)
   if m and mode and start in starts:groups.setdefault((mode,start),[]).append(tuple(map(int,m.group(2,3,4))))
  return groups
 groups=collect(reference);seen={};mode=None;start=None;out=[]
 for line in current.splitlines(True):
  h=re.search(r'CS_CAM_(EYE|AT)_SPLINE\((\d+),',line)
  if h:mode=h[1];start=int(h[2])
  elif re.search(r'^\s*CS_\w+\(',line)and'CS_CAM_POINT('not in line:mode=None
  m=POINT.search(line)
  if m and mode and start in starts:
   key=(mode,start);i=seen.get(key,0);x,y,z=groups[key][i];seen[key]=i+1
   xyz=[round(anchor[0]+(x-anchor[0])*factor),round(y+dy),round(anchor[2]+(z-anchor[2])*factor)]
   line=line[:m.start()]+m[1]+', '.join(map(str,xyz))+m[5]+line[m.end():]
  out.append(line)
 assert {k:len(v)for k,v in groups.items()}==seen,(starts,seen)
 result=''.join(out)
 strip=lambda s:POINT.sub(lambda m:m[1]+'X, Y, Z'+m[5],s)
 assert strip(result)==strip(current)
 return result,dict(camera_groups={f'{k[0]}-{k[1]}':v for k,v in seen.items()},factor_xz=factor,eye_and_at_y_offset=dy,anchor=anchor)
def fit(oot):
 specs=[
  ('hall',R/'tools/sage_medallion_cameras.inc.c',oot/'src/overlays/actors/ovl_En_Nb/sage_medallion_cameras.inc.c',oot/'src/overlays/actors/ovl_En_Nb/z_en_nb_cutscene_data.inc.c',{263,363,433},(94,6,165),1.15,8),
  ('reveal',None,oot/'extracted/pal-1.0/assets/scenes/dungeons/jyasinboss/gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c',R/'tools/originals/water_spirit_sages/extracted/pal-1.0/assets/scenes/dungeons/jyasinboss/gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c',{65,85,140,222},(-1515,0,1519),1.25,10),
  ('final_seal',None,oot/'extracted/pal-1.0/assets/scenes/indoors/kenjyanoma/gChamberOfSagesSealOpeningCs.csdata.inc.c',R/'tools/originals/water_spirit_sages/extracted/pal-1.0/assets/scenes/indoors/kenjyanoma/gChamberOfSagesSealOpeningCs.csdata.inc.c',{110},(94,6,165),1.15,8),
  ('credits',R/'tools/bowling_sage_cutscene_data.inc.c',oot/'src/overlays/actors/ovl_Demo_Sa/bowling_sage_cutscene_data.inc.c',R/'tools/sage_credits_camera_reference.inc.c',{246},(14,3199,-3996),1.25,6)]
 report=[]
 for name,project,target,reference,starts,anchor,factor,dy in specs:
  current=target.read_text();ref=reference.read_text()
  if name=='hall':
   # The combined project include contains the water script too; leave it byte-for-byte intact.
   ref=ref.replace('gSpiritMedallionCs','gWaluigiSpiritMedallionCs');fitted,info=refit(current,ref,starts,anchor,factor,dy)
   combined=project.read_text();marker='static CutsceneData gWaluigiSpiritMedallionCs';i=combined.index(marker);project.write_text(combined[:i]+fitted)
  else:fitted,info=refit(current,ref,starts,anchor,factor,dy)
  target.write_text(fitted)
  if project and name!='hall':project.write_text(fitted)
  report.append(dict(role=name,**info))
 (R/'tools/waluigi_camera_fit.json').write_text(json.dumps(report,indent=2)+'\n')
if __name__=='__main__':fit(Path(__import__('sys').argv[1]).resolve())

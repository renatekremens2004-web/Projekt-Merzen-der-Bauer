/* Each supplied character is restricted to its own scene, room, marker and era. */
extern Gfx gYellowGuyDL[];
extern Gfx gPunkYellowDL[];
extern Gfx gWarioDL[];
static s32 ElfMsg2_IsYellowCast(Actor* actor, PlayState* play) {
    return actor->room == 0 &&
        ((play->sceneId == SCENE_HYRULE_CASTLE && actor->params == 0x3F7D) ||
         (play->sceneId == SCENE_OUTSIDE_GANONS_CASTLE && actor->params == 0x3F7E) ||
         (play->sceneId == SCENE_KAKARIKO_VILLAGE && actor->params == 0x3F7F));
}
static void ElfMsg2_DrawYellowCast(Actor* actor, PlayState* play) {
    static Vec3f yellowPivots[4] = { YELLOWGUY_PIVOTS };
    static Vec3f punkPivots[4] = { PUNKYELLOW_PIVOTS };
    static Vec3f warioPivots[4] = { WARIO_PIVOTS };
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Vec3f* pivots = normal ? yellowPivots : wario ? warioPivots : punkPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (normal ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "yellowcast", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "yellowcast", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, normal ? gYellowGuyDL : wario ? gWarioDL : gPunkYellowDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "yellowcast", 3);
}
static void ElfMsg2_InitYellowCast(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if ((LINK_IS_CHILD ? actor->params == 0x3F7E : actor->params != 0x3F7E) || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = normal ? 0x608F : wario ? 0x601C : 0x6073;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, wario ? 19 : 14);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = wario ? 22 : 13;
    this->wallaceCollider.dim.height = normal ? 55 : wario ? 65 : 59;
    Actor_SetFocus(actor, normal ? 55 : wario ? 65 : 59);
    actor->draw = ElfMsg2_DrawYellowCast;
}
static void ElfMsg2_UpdateYellowCast(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Actor_SetFocus(actor, normal ? 55 : wario ? 65 : 59);
    actor->textId = normal ? 0x608F : wario ? 0x601C : 0x6073;
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight;
    if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play) &&
        Message_GetState(&play->msgCtx) == TEXT_STATE_NONE && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

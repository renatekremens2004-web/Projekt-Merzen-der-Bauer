#include "ice_doukutu_room_11.h"
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_scene.h"

#include "actor.h"
#include "array_count.h"
#include "gfx.h"
#include "object.h"
#include "sequence.h"
#include "skybox.h"
#include "sys_matrix.h"
#include "ultra64.h"

SceneCmd ice_doukutu_room_11[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11.inc.c"
};

SceneCmd* ice_doukutu_room_11_03000048_AltHeaders[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000048_AltHeaders.inc.c"
};

s16 ice_doukutu_room_11_03000058_ObjectList[LENGTH_ice_doukutu_room_11_03000058_ObjectList] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000058_ObjectList.inc.c"
};

ActorEntry ice_doukutu_room_11_03000068_ActorEntryList[LENGTH_ice_doukutu_room_11_03000068_ActorEntryList] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000068_ActorEntryList.inc.c"
};

u8 ice_doukutu_room_11_zeros_000238[8] = { 0 };

RoomShapeNormal ice_doukutu_room_11_03000240_RoomShapeNormal = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal.inc.c"
};

RoomShapeDListsEntry ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries[LENGTH_ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries.inc.c"
};

u8 ice_doukutu_room_11_unaccounted_000254[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_unaccounted_000254.bin.inc.c"
};

SceneCmd ice_doukutu_room_11_03000048_AltHeaders_03000260_Cmds[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000048_AltHeaders_03000260_Cmds.inc.c"
};

s16 ice_doukutu_room_11_03000048_AltHeaders_03000260_Cmds_030002A0_ObjectList[LENGTH_ice_doukutu_room_11_03000048_AltHeaders_03000260_Cmds_030002A0_ObjectList] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000048_AltHeaders_03000260_Cmds_030002A0_ObjectList.inc.c"
};

ActorEntry ice_doukutu_room_11_03000048_AltHeaders_03000260_Cmds_030002A8_ActorEntryList[LENGTH_ice_doukutu_room_11_03000048_AltHeaders_03000260_Cmds_030002A8_ActorEntryList] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000048_AltHeaders_03000260_Cmds_030002A8_ActorEntryList.inc.c"
};

u8 ice_doukutu_room_11_zeros_0002D8[8] = { 0 };

Vtx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_030004C0_DL_030002E0_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_030004C0_DL_030002E0_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_030004C0_DL[35] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_030004C0_DL.inc.c"
};

Vtx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03000C18_DL_030005D8_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03000C18_DL_030005D8_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03000C18_DL[60] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03000C18_DL.inc.c"
};

Vtx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_030012C8_DL_03000DF8_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_030012C8_DL_03000DF8_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_030012C8_DL[63] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_030012C8_DL.inc.c"
};

Vtx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03002470_DL_030014C0_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03002470_DL_030014C0_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03002470_DL[104] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03002470_DL.inc.c"
};

Vtx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03002910_DL_030027B0_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03002910_DL_030027B0_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03002910_DL[19] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL_03002910_DL.inc.c"
};

Gfx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL[6] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030029A8_DL.inc.c"
};

u64 ice_doukutu_room_11_000029D8_Tex[TEX_LEN(u64, ice_doukutu_room_11_000029D8_Tex_WIDTH, ice_doukutu_room_11_000029D8_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_000029D8_Tex.rgba16.inc.c"
};

u64 ice_doukutu_room_11_000031D8_Tex[TEX_LEN(u64, ice_doukutu_room_11_000031D8_Tex_WIDTH, ice_doukutu_room_11_000031D8_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_000031D8_Tex.rgba16.inc.c"
};

u64 ice_doukutu_room_11_000039D8_Tex[TEX_LEN(u64, ice_doukutu_room_11_000039D8_Tex_WIDTH, ice_doukutu_room_11_000039D8_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_000039D8_Tex.rgba16.inc.c"
};

u8 ice_doukutu_room_11_zeros_0041D8[8] = { 0 };

Vtx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030048E8_DL_03004760_DL_030041E0_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030048E8_DL_03004760_DL_030041E0_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030048E8_DL_03004760_DL[49] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030048E8_DL_03004760_DL.inc.c"
};

Gfx ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030048E8_DL[2] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_03000240_RoomShapeNormal_0300024C_DListsEntries_030048E8_DL.inc.c"
};

u64 ice_doukutu_room_11_000048F8_Tex[TEX_LEN(u64, ice_doukutu_room_11_000048F8_Tex_WIDTH, ice_doukutu_room_11_000048F8_Tex_HEIGHT, 8)] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_11_000048F8_Tex.i8.inc.c"
};

u8 ice_doukutu_room_11_zeros_0058F8[8] = { 0 };


#include "ice_doukutu_room_10.h"
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_scene.h"

#include "array_count.h"
#include "gfx.h"
#include "object.h"
#include "sequence.h"
#include "skybox.h"
#include "sys_matrix.h"
#include "ultra64.h"

SceneCmd ice_doukutu_room_10[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10.inc.c"
};

SceneCmd* ice_doukutu_room_10_03000040_AltHeaders[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000040_AltHeaders.inc.c"
};

s16 ice_doukutu_room_10_03000050_ObjectList[LENGTH_ice_doukutu_room_10_03000050_ObjectList] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000050_ObjectList.inc.c"
};

u8 ice_doukutu_room_10_zeros_000064[12] = { 0 };

RoomShapeNormal ice_doukutu_room_10_03000070_RoomShapeNormal = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal.inc.c"
};

RoomShapeDListsEntry ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries[LENGTH_ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries.inc.c"
};

u8 ice_doukutu_room_10_unaccounted_000084[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_unaccounted_000084.bin.inc.c"
};

SceneCmd ice_doukutu_room_10_03000040_AltHeaders_03000090_Cmds[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000040_AltHeaders_03000090_Cmds.inc.c"
};

s16 ice_doukutu_room_10_03000040_AltHeaders_03000090_Cmds_030000C8_ObjectList[LENGTH_ice_doukutu_room_10_03000040_AltHeaders_03000090_Cmds_030000C8_ObjectList] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000040_AltHeaders_03000090_Cmds_030000C8_ObjectList.inc.c"
};

Vtx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000390_DL_030000D0_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000390_DL_030000D0_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000390_DL[43] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000390_DL.inc.c"
};

Vtx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_030006F8_DL_030004E8_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_030006F8_DL_030004E8_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_030006F8_DL[39] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_030006F8_DL.inc.c"
};

Vtx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000C10_DL_03000830_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000C10_DL_03000830_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000C10_DL[40] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000C10_DL.inc.c"
};

Vtx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000E10_DL_03000D50_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000E10_DL_03000D50_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000E10_DL[16] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03000E10_DL.inc.c"
};

Vtx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03001800_DL_03000E90_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03001800_DL_03000E90_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03001800_DL[63] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL_03001800_DL.inc.c"
};

Gfx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL[6] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_030019F8_DL.inc.c"
};

u64 ice_doukutu_room_10_00001A28_Tex[TEX_LEN(u64, ice_doukutu_room_10_00001A28_Tex_WIDTH, ice_doukutu_room_10_00001A28_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_00001A28_Tex.rgba16.inc.c"
};

u64 ice_doukutu_room_10_00002A28_Tex[TEX_LEN(u64, ice_doukutu_room_10_00002A28_Tex_WIDTH, ice_doukutu_room_10_00002A28_Tex_HEIGHT, 8)] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_00002A28_Tex.i8.inc.c"
};

u8 ice_doukutu_room_10_zeros_003A28[8] = { 0 };

Vtx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_03003BC8_DL_03003AF0_DL_03003A30_Vtx_fused_[] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_03003BC8_DL_03003AF0_DL_03003A30_Vtx_fused_.inc.c"
};

Gfx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_03003BC8_DL_03003AF0_DL[27] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_03003BC8_DL_03003AF0_DL.inc.c"
};

Gfx ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_03003BC8_DL[2] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_03000070_RoomShapeNormal_0300007C_DListsEntries_03003BC8_DL.inc.c"
};

u64 ice_doukutu_room_10_00003BD8_Tex[TEX_LEN(u64, ice_doukutu_room_10_00003BD8_Tex_WIDTH, ice_doukutu_room_10_00003BD8_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/ice_doukutu/ice_doukutu_room_10_00003BD8_Tex.rgba16.inc.c"
};

u8 ice_doukutu_room_10_zeros_0043D8[8] = { 0 };


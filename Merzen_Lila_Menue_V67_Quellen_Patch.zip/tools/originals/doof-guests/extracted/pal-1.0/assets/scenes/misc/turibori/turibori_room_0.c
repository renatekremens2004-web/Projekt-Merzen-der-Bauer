#include "turibori_room_0.h"
#include "assets/scenes/misc/turibori/turibori_scene.h"

#include "actor.h"
#include "array_count.h"
#include "gfx.h"
#include "object.h"
#include "sequence.h"
#include "skybox.h"
#include "sys_matrix.h"
#include "ultra64.h"

SceneCmd turibori_room_0[] = {
#include "assets/scenes/misc/turibori/turibori_room_0.inc.c"
};

s16 turibori_room_0_03000040_ObjectList[LENGTH_turibori_room_0_03000040_ObjectList] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000040_ObjectList.inc.c"
};

ActorEntry turibori_room_0_03000044_ActorEntryList[LENGTH_turibori_room_0_03000044_ActorEntryList] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000044_ActorEntryList.inc.c"
};

u8 turibori_room_0_zeros_000054[12] = { 0 };

RoomShapeNormal turibori_room_0_03000060_RoomShapeNormal = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal.inc.c"
};

RoomShapeDListsEntry turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries[LENGTH_turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries.inc.c"
};

u8 turibori_room_0_unaccounted_000074[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_unaccounted_000074.bin.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03000140_DL_03000080_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03000140_DL_03000080_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03000140_DL[23] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03000140_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030005D8_DL_030001F8_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030005D8_DL_030001F8_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030005D8_DL[117] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030005D8_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03000B60_DL_03000980_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03000B60_DL_03000980_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03000B60_DL[44] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03000B60_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03001720_DL_03000CC0_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03001720_DL_03000CC0_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03001720_DL[107] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03001720_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03001DF8_DL_03001A78_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03001DF8_DL_03001A78_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03001DF8_DL[35] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03001DF8_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03002B70_DL_03001F10_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03002B70_DL_03001F10_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03002B70_DL[170] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03002B70_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03003500_DL_030030C0_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03003500_DL_030030C0_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03003500_DL[66] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03003500_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03003DD0_DL_03003710_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03003DD0_DL_03003710_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03003DD0_DL[180] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03003DD0_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030044B0_DL_03004370_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030044B0_DL_03004370_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030044B0_DL[33] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030044B0_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03004938_DL_030045B8_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03004938_DL_030045B8_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03004938_DL[36] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03004938_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03005098_DL_03004A58_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03005098_DL_03004A58_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03005098_DL[52] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_03005098_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030055C8_DL_03005238_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030055C8_DL_03005238_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030055C8_DL[38] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL_030055C8_DL.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL[13] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_030056F8_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_03005C80_DL_03005760_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_03005C80_DL_03005760_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_03005C80_DL[101] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_03005C80_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_030061A8_DL_03005FA8_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_030061A8_DL_03005FA8_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_030061A8_DL[52] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_030061A8_DL.inc.c"
};

Vtx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_030065B8_DL_03006348_Vtx_fused_[] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_030065B8_DL_03006348_Vtx_fused_.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_030065B8_DL[49] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL_030065B8_DL.inc.c"
};

Gfx turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL[4] = {
#include "assets/scenes/misc/turibori/turibori_room_0_03000060_RoomShapeNormal_0300006C_DListsEntries_03006740_DL.inc.c"
};


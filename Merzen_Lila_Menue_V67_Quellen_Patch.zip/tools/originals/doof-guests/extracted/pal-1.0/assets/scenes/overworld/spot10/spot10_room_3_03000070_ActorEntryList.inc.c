    {
        ACTOR_EN_RIVER_SOUND,
        {   1596,      0,  -1067 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x000C, // params
    }, // 0
    {
        ACTOR_OBJECT_KANKYO,
        {   1735,      0,   -792 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 1
    {
        ACTOR_EN_OKUTA,
        {   2114,    -20,   -847 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
        -0x100 /* 0xFF00 */, // params
    }, // 2
    {
        ACTOR_SHOT_SUN,
        {   1930,      0,   -795 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x0BF /* 0xFF41 */, // params
    }, // 3
    {
        ACTOR_EN_ITEM00,
        {   2215,   -260,   -850 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3400, // params
    }, // 4
    {
        ACTOR_EN_ITEM00,
        {   2164,   -260,   -850 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3500, // params
    }, // 5
    {
        ACTOR_EN_ITEM00,
        {   2113,   -260,   -850 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3600, // params
    }, // 6
    {
        ACTOR_EN_ITEM00,
        {   2061,   -260,   -853 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3700, // params
    }, // 7
    {
        ACTOR_EN_ITEM00,
        {   2194,   -260,   -895 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3900, // params
    }, // 8
    {
        ACTOR_EN_ITEM00,
        {   2156,   -260,   -937 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3A00, // params
    }, // 9
    {
        ACTOR_EN_ITEM00,
        {   2193,   -260,   -813 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3B00, // params
    }, // 10
    {
        ACTOR_EN_ITEM00,
        {   2153,   -260,   -779 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3C00, // params
    }, // 11


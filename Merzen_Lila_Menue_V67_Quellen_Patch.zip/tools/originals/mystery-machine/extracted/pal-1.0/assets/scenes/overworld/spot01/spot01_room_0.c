#include "spot01_room_0.h"
#include "assets/scenes/overworld/spot01/spot01_scene.h"

#include "actor.h"
#include "array_count.h"
#include "gfx.h"
#include "object.h"
#include "sequence.h"
#include "skybox.h"
#include "sys_matrix.h"
#include "ultra64.h"

SceneCmd spot01_room_0[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0.inc.c"
};

SceneCmd* spot01_room_0_03000048_AltHeaders[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders.inc.c"
};

s16 spot01_room_0_03000068_ObjectList[LENGTH_spot01_room_0_03000068_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000068_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000084_ActorEntryList[LENGTH_spot01_room_0_03000084_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000084_ActorEntryList.inc.c"
};

u8 spot01_room_0_zeros_000414[12] = { 0 };

RoomShapeCullable spot01_room_0_03000420_RoomShapeCullable = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000420_RoomShapeCullable.inc.c"
};

RoomShapeCullableEntry spot01_room_0_03000420_RoomShapeCullable_0300042C_CullableEntries[LENGTH_spot01_room_0_03000420_RoomShapeCullable_0300042C_CullableEntries] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000420_RoomShapeCullable_0300042C_CullableEntries.inc.c"
};

u8 spot01_room_0_unaccounted_00056C[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_unaccounted_00056C.bin.inc.c"
};

SceneCmd spot01_room_0_03000048_AltHeaders_03000570_Cmds[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000570_Cmds.inc.c"
};

s16 spot01_room_0_03000048_AltHeaders_03000570_Cmds_030005B0_ObjectList[LENGTH_spot01_room_0_03000048_AltHeaders_03000570_Cmds_030005B0_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000570_Cmds_030005B0_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000048_AltHeaders_03000570_Cmds_030005CC_ActorEntryList[LENGTH_spot01_room_0_03000048_AltHeaders_03000570_Cmds_030005CC_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000570_Cmds_030005CC_ActorEntryList.inc.c"
};

u8 spot01_room_0_zeros_0008FC[4] = { 0 };

SceneCmd spot01_room_0_03000048_AltHeaders_03000900_Cmds[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000900_Cmds.inc.c"
};

s16 spot01_room_0_03000048_AltHeaders_03000900_Cmds_03000940_ObjectList[LENGTH_spot01_room_0_03000048_AltHeaders_03000900_Cmds_03000940_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000900_Cmds_03000940_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000048_AltHeaders_03000900_Cmds_0300095C_ActorEntryList[LENGTH_spot01_room_0_03000048_AltHeaders_03000900_Cmds_0300095C_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000900_Cmds_0300095C_ActorEntryList.inc.c"
};

u8 spot01_room_0_zeros_000C3C[4] = { 0 };

SceneCmd spot01_room_0_03000048_AltHeaders_03000C40_Cmds[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000C40_Cmds.inc.c"
};

s16 spot01_room_0_03000048_AltHeaders_03000C40_Cmds_03000C80_ObjectList[LENGTH_spot01_room_0_03000048_AltHeaders_03000C40_Cmds_03000C80_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000C40_Cmds_03000C80_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000048_AltHeaders_03000C40_Cmds_03000C98_ActorEntryList[LENGTH_spot01_room_0_03000048_AltHeaders_03000C40_Cmds_03000C98_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000C40_Cmds_03000C98_ActorEntryList.inc.c"
};

u8 spot01_room_0_zeros_000FB8[8] = { 0 };

SceneCmd spot01_room_0_03000048_AltHeaders_03000FC0_Cmds[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000FC0_Cmds.inc.c"
};

s16 spot01_room_0_03000048_AltHeaders_03000FC0_Cmds_03001000_ObjectList[LENGTH_spot01_room_0_03000048_AltHeaders_03000FC0_Cmds_03001000_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000FC0_Cmds_03001000_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000048_AltHeaders_03000FC0_Cmds_03001014_ActorEntryList[LENGTH_spot01_room_0_03000048_AltHeaders_03000FC0_Cmds_03001014_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03000FC0_Cmds_03001014_ActorEntryList.inc.c"
};

u8 spot01_room_0_zeros_0011E4[12] = { 0 };

SceneCmd spot01_room_0_03000048_AltHeaders_030011F0_Cmds[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_030011F0_Cmds.inc.c"
};

s16 spot01_room_0_03000048_AltHeaders_030011F0_Cmds_03001230_ObjectList[LENGTH_spot01_room_0_03000048_AltHeaders_030011F0_Cmds_03001230_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_030011F0_Cmds_03001230_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000048_AltHeaders_030011F0_Cmds_03001240_ActorEntryList[LENGTH_spot01_room_0_03000048_AltHeaders_030011F0_Cmds_03001240_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_030011F0_Cmds_03001240_ActorEntryList.inc.c"
};

SceneCmd spot01_room_0_03000048_AltHeaders_03001390_Cmds[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001390_Cmds.inc.c"
};

s16 spot01_room_0_03000048_AltHeaders_03001390_Cmds_030013D0_ObjectList[LENGTH_spot01_room_0_03000048_AltHeaders_03001390_Cmds_030013D0_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001390_Cmds_030013D0_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000048_AltHeaders_03001390_Cmds_030013D4_ActorEntryList[LENGTH_spot01_room_0_03000048_AltHeaders_03001390_Cmds_030013D4_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001390_Cmds_030013D4_ActorEntryList.inc.c"
};

u8 spot01_room_0_zeros_001474[12] = { 0 };

SceneCmd spot01_room_0_03000048_AltHeaders_03001480_Cmds[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001480_Cmds.inc.c"
};

s16 spot01_room_0_03000048_AltHeaders_03001480_Cmds_030014C0_ObjectList[LENGTH_spot01_room_0_03000048_AltHeaders_03001480_Cmds_030014C0_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001480_Cmds_030014C0_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000048_AltHeaders_03001480_Cmds_030014DC_ActorEntryList[LENGTH_spot01_room_0_03000048_AltHeaders_03001480_Cmds_030014DC_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001480_Cmds_030014DC_ActorEntryList.inc.c"
};

u8 spot01_room_0_zeros_00162C[4] = { 0 };

SceneCmd spot01_room_0_03000048_AltHeaders_03001630_Cmds[] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001630_Cmds.inc.c"
};

s16 spot01_room_0_03000048_AltHeaders_03001630_Cmds_03001670_ObjectList[LENGTH_spot01_room_0_03000048_AltHeaders_03001630_Cmds_03001670_ObjectList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001630_Cmds_03001670_ObjectList.inc.c"
};

ActorEntry spot01_room_0_03000048_AltHeaders_03001630_Cmds_03001688_ActorEntryList[LENGTH_spot01_room_0_03000048_AltHeaders_03001630_Cmds_03001688_ActorEntryList] = {
#include "assets/scenes/overworld/spot01/spot01_room_0_03000048_AltHeaders_03001630_Cmds_03001688_ActorEntryList.inc.c"
};

u8 spot01_room_0_zeros_001718[8] = { 0 };

Vtx gSpot01DL_009E38_03001F20_DL_03001720_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03001F20_DL_03001720_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03001F20_DL[75] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03001F20_DL.inc.c"
};

Vtx gSpot01DL_009E38_030024E8_DL_03002178_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_030024E8_DL_03002178_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_030024E8_DL[48] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_030024E8_DL.inc.c"
};

Vtx gSpot01DL_009E38_03003B48_DL_03002668_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03003B48_DL_03002668_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03003B48_DL[221] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03003B48_DL.inc.c"
};

Vtx gSpot01DL_009E38_03004420_DL_03004230_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03004420_DL_03004230_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03004420_DL[37] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03004420_DL.inc.c"
};

Vtx gSpot01DL_009E38_030048C8_DL_03004548_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_030048C8_DL_03004548_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_030048C8_DL[53] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_030048C8_DL.inc.c"
};

Vtx gSpot01DL_009E38_03004DB0_DL_03004A70_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03004DB0_DL_03004A70_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03004DB0_DL[66] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03004DB0_DL.inc.c"
};

Vtx gSpot01DL_009E38_03005680_DL_03005420_DL_03005290_DL_03004FC0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005680_DL_03005420_DL_03005290_DL_03004FC0_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03005680_DL_03005420_DL_03005290_DL[48] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005680_DL_03005420_DL_03005290_DL.inc.c"
};

Vtx gSpot01DL_009E38_03005680_DL_03005420_DL_03005410_Vtx[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005680_DL_03005420_DL_03005410_Vtx.inc.c"
};

Gfx gSpot01DL_009E38_03005680_DL_03005420_DL[4] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005680_DL_03005420_DL.inc.c"
};

Vtx gSpot01DL_009E38_03005680_DL_03005440_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005680_DL_03005440_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03005680_DL[42] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005680_DL.inc.c"
};

Vtx gSpot01DL_009E38_03005AD0_DL_030057D0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005AD0_DL_030057D0_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03005AD0_DL[33] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005AD0_DL.inc.c"
};

Vtx gSpot01DL_009E38_03005E48_DL_03005BD8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005E48_DL_03005BD8_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03005E48_DL[51] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03005E48_DL.inc.c"
};

Vtx gSpot01DL_009E38_030063A0_DL_03005FE0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_030063A0_DL_03005FE0_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_030063A0_DL[69] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_030063A0_DL.inc.c"
};

Vtx gSpot01DL_009E38_03006758_DL_030065C8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03006758_DL_030065C8_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03006758_DL[34] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03006758_DL.inc.c"
};

Vtx gSpot01DL_009E38_03006B18_DL_03006868_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03006B18_DL_03006868_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03006B18_DL[39] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03006B18_DL.inc.c"
};

Vtx gSpot01DL_009E38_03006EC0_DL_03006C50_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03006EC0_DL_03006C50_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03006EC0_DL[37] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03006EC0_DL.inc.c"
};

Vtx gSpot01DL_009E38_03007418_DL_03006FE8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03007418_DL_03006FE8_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03007418_DL[66] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03007418_DL.inc.c"
};

Vtx gSpot01DL_009E38_03007888_DL_03007628_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03007888_DL_03007628_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03007888_DL[38] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03007888_DL.inc.c"
};

Vtx gSpot01DL_009E38_03007C18_DL_030079B8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03007C18_DL_030079B8_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03007C18_DL[47] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03007C18_DL.inc.c"
};

Vtx gSpot01DL_009E38_030086F0_DL_03007D90_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_030086F0_DL_03007D90_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_030086F0_DL[131] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_030086F0_DL.inc.c"
};

Vtx gSpot01DL_009E38_03008EC8_DL_03008B08_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03008EC8_DL_03008B08_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03008EC8_DL[36] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03008EC8_DL.inc.c"
};

Vtx gSpot01DL_009E38_03009108_DL_03008FE8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03009108_DL_03008FE8_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03009108_DL[35] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03009108_DL.inc.c"
};

Vtx gSpot01DL_009E38_03009A70_DL_03009220_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03009A70_DL_03009220_Vtx_fused_.inc.c"
};

Gfx gSpot01DL_009E38_03009A70_DL[121] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38_03009A70_DL.inc.c"
};

Gfx gSpot01DL_009E38[21] = {
#include "assets/scenes/overworld/spot01/gSpot01DL_009E38.inc.c"
};


#include "wario_model.inc.c"

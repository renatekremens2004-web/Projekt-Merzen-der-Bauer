    {
        ACTOR_EN_HEISHI4,
        {   -384,    240,   1773 }, // pos
        {  0x0000, -0x5E94,  0x0000 }, // rot
        -0x0FC /* 0xFF04 */, // params
    }, // 0
    {
        ACTOR_BG_SPOT01_IDOHASHIRA,
        {    799,     80,    503 }, // pos
        {  0x0000, -0x2AAB,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 1
    {
        ACTOR_BG_SPOT01_IDOMIZU,
        {    762,     52,    524 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 2
    {
        ACTOR_EN_DAIKU_KAKARIKO,
        {   1105,     80,     88 }, // pos
        {  0x0000, -0x24FA,  0x0000 }, // rot
         0x0002, // params
    }, // 3
    {
        ACTOR_EN_DAIKU_KAKARIKO,
        {   1167,    260,    663 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0103, // params
    }, // 4
    {
        ACTOR_BG_SPOT01_OBJECTS2,
        {    324,    160,   1000 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0203, // params
    }, // 5
    {
        ACTOR_BG_SPOT01_FUSYA,
        {   1140,    990,    524 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 6
    {
        ACTOR_EN_HEISHI2,
        {    -30,    400,  -1298 }, // pos
        {  0x0000,  0x0E39,  0x0000 }, // rot
        -0x0FB /* 0xFF05 */, // params
    }, // 7
    {
        ACTOR_OBJ_TSUBO,
        {    222,    200,   -377 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x4103, // params
    }, // 8
    {
        ACTOR_OBJ_TSUBO,
        {    255,    200,   -366 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x4303, // params
    }, // 9
    {
        ACTOR_OBJ_TSUBO,
        {    284,    200,   -356 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x4503, // params
    }, // 10
    {
        ACTOR_OBJ_TSUBO,
        {   -384,    240,   1568 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x4703, // params
    }, // 11
    {
        ACTOR_OBJ_TSUBO,
        {   -384,    240,   1539 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x4903, // params
    }, // 12
    {
        ACTOR_OBJ_TSUBO,
        {   -384,    240,   1510 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x4B03, // params
    }, // 13
    {
        ACTOR_OBJ_TSUBO,
        {   -450,    320,   -895 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x4D03, // params
    }, // 14
    {
        ACTOR_OBJ_TSUBO,
        {   -422,    320,   -883 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x4F03, // params
    }, // 15
    {
        ACTOR_OBJ_TSUBO,
        {   -392,    320,   -870 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x5103, // params
    }, // 16
    {
        ACTOR_OBJ_TSUBO,
        {    781,    200,     89 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x5303, // params
    }, // 17
    {
        ACTOR_OBJ_TSUBO,
        {    815,    200,     89 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x5503, // params
    }, // 18
    {
        ACTOR_DOOR_ANA,
        {    860,     80,   -260 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0028, // params
    }, // 19
    {
        ACTOR_DOOR_ANA,
        {   -400,      0,    400 }, // pos
        {  0x0000,  0x0000,  0x0003 }, // rot
         0x02E7, // params
    }, // 20
    {
        ACTOR_EN_ANI,
        {    370,    483,    100 }, // pos
        {  0x0000, -0x6AAB,  0x0000 }, // rot
         0x0000, // params
    }, // 21
    {
        ACTOR_EN_A_OBJ,
        {  -2590,    138,    965 }, // pos
        {  0x0000, -0x71C7,  0x0000 }, // rot
         0x010A, // params
    }, // 22
    {
        ACTOR_EN_A_OBJ,
        {   1165,     80,   1550 }, // pos
        {  0x0000,  0x0E39,  0x0000 }, // rot
         0x060A, // params
    }, // 23
    {
        ACTOR_EN_NIW,
        {  -1697,     80,    870 }, // pos
        {  0x0000,  0x127D,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 24
    {
        ACTOR_EN_NIW,
        {     57,    320,   -673 }, // pos
        {  0x0000, -0x293F,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 25
    {
        ACTOR_EN_NIW,
        {    796,     80,   1639 }, // pos
        {  0x0000,  0x4889,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 26
    {
        ACTOR_EN_NIW,
        {   1417,    465,    169 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 27
    {
        ACTOR_EN_NIW,
        {    -60,      0,    -46 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0004, // params
    }, // 28
    {
        ACTOR_EN_NIW,
        {   -247,     80,    854 }, // pos
        {  0x0000, -0x2222,  0x0000 }, // rot
         0x0008, // params
    }, // 29
    {
        ACTOR_EN_NIW,
        {   1079,     80,    -47 }, // pos
        {  0x0000,  0x1F4A,  0x0000 }, // rot
         0x0008, // params
    }, // 30
    {
        ACTOR_EN_NIW_LADY,
        {    486,     80,   1423 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 31
    {
        ACTOR_EN_ISHI,
        {    220,    400,  -1236 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 32
    {
        ACTOR_EN_ISHI,
        {   -664,     80,   1288 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0210, // params
    }, // 33
    {
        ACTOR_EN_KANBAN,
        {    655,     80,    525 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x0307, // params
    }, // 34
    {
        ACTOR_EN_KANBAN,
        {    210,    400,  -1275 }, // pos
        {  0x0000, -0x71C,  0x0000 }, // rot
         0x0308, // params
    }, // 35
    {
        ACTOR_EN_KUSA,
        {   -887,      0,    467 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 36
    {
        ACTOR_EN_KUSA,
        {   -883,      0,    582 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 37
    {
        ACTOR_EN_KUSA,
        {   -827,      0,    465 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 38
    {
        ACTOR_EN_KUSA,
        {   -826,      0,    585 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 39
    {
        ACTOR_EN_KUSA,
        {   -800,      0,    521 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 40
    {
        ACTOR_EN_KUSA,
        {   1072,     80,   1592 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 41
    {
        ACTOR_EN_KUSA,
        {   1103,     80,   1532 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 42
    {
        ACTOR_EN_KUSA,
        {   1116,     80,   1581 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 43
    {
        ACTOR_EN_TORYO,
        {   -932,      0,    521 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 44
    {
        ACTOR_EN_WOOD02,
        {   -860,      0,    522 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0201, // params
    }, // 45
    {
        ACTOR_OBJ_MURE,
        {      4,    805,   -117 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x2324, // params
    }, // 46
    {
        ACTOR_EN_HEISHI4,
        {  -2201,    138,    919 }, // pos
        {  0x0000, -0x2B61,  0x0000 }, // rot
        -0x100 /* 0xFF00 */, // params
    }, // 47
    {
        ACTOR_BG_SPOT16_DOUGHNUT,
        {  -1409,   2767,  -4417 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 48
    {
        ACTOR_OBJ_KIBAKO2,
        {   -636,    200,   -478 }, // pos
        { -0x001,  0x305B,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 49
    {
        ACTOR_OBJ_KIBAKO2,
        {    -60,      0,    -46 }, // pos
        { -0x001,  0x4000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 50
    {
        ACTOR_OBJ_KIBAKO2,
        {   1170,     80,    111 }, // pos
        { -0x001,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 51
    {
        ACTOR_OBJ_KIBAKO2,
        {   1170,    260,    601 }, // pos
        { -0x001,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 52
    {
        ACTOR_OBJ_KIBAKO2,
        {   1732,    189,   1366 }, // pos
        { -0x001,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 53
    {
        ACTOR_BG_GATE_SHUTTER,
        {     91,    400,  -1350 }, // pos
        {  0x0000, -0x666,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 54
    {
        ACTOR_EN_WONDER_ITEM,
        {    148,    300,   1165 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x129F, // params
    }, // 55
    {
        ACTOR_EN_RIVER_SOUND,
        {    158,    257,   1742 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0015, // params
    }, // 56

    { ACTOR_ELF_MSG2, { -900, 80, 950 }, { 0, -16384, 0 }, 0x3F7F }, /* friendly wario; own era only */

    {
        ACTOR_EN_RIVER_SOUND,
        {  -2862,   -315,   -500 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0001, // params
    }, // 0
    {
        ACTOR_EN_RIVER_SOUND,
        {   5161,     29,   3688 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 1
    {
        ACTOR_EN_RIVER_SOUND,
        {  -7870,   -300,   6920 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0015, // params
    }, // 2
    {
        ACTOR_EN_OWL,
        {   4284,    182,   7877 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x004C, // params
    }, // 3
    {
        ACTOR_EN_OWL,
        {   3276,    510,    971 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x00FF, // params
    }, // 4
    {
        ACTOR_EN_OWL,
        {  -6270,     30,   8579 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x013F, // params
    }, // 5
    {
        ACTOR_EN_OWL,
        {  -4670,   -500,  13739 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x014B, // params
    }, // 6
    {
        ACTOR_BG_SPOT00_HANEBASI,
        {      0,    -10,    670 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 7
    {
        ACTOR_EN_PEEHAT,
        {  -4858,   -300,   -216 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 8
    {
        ACTOR_EN_PEEHAT,
        {   -993,   -402,   9938 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 9
    {
        ACTOR_EN_PEEHAT,
        {    483,   -436,  11174 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 10
    {
        ACTOR_EN_PEEHAT,
        {   1411,   -447,  12262 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 11
    {
        ACTOR_EN_PEEHAT,
        {   3145,   -189,   7530 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 12
    {
        ACTOR_EN_PEEHAT,
        {  -5445,   -195,  10195 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 13
    {
        ACTOR_EN_PEEHAT,
        {  -1349,   -500,  13418 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 14
    {
        ACTOR_EN_ENCOUNT1,
        {    116,    192,   6206 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x10A4, // params
    }, // 15
    {
        ACTOR_DOOR_ANA,
        {  -1425,      0,    810 }, // pos
        {  0x0000, -0x2000,  0x0000 }, // rot
         0x0000, // params
    }, // 16
    {
        ACTOR_DOOR_ANA,
        {  -4030,   -700,  13860 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x0003, // params
    }, // 17
    {
        ACTOR_DOOR_ANA,
        {   -270,   -500,  12350 }, // pos
        {  0x0000, -0x6AAB,  0x0000 }, // rot
         0x0022, // params
    }, // 18
    {
        ACTOR_DOOR_ANA,
        {  -4945,   -300,   2835 }, // pos
        {  0x0000,  0x1555,  0x000B }, // rot
         0x02E1, // params
    }, // 19
    {
        ACTOR_DOOR_ANA,
        {  -7870,   -300,   6920 }, // pos
        {  0x0000,  0x0000,  0x0005 }, // rot
         0x02E4, // params
    }, // 20
    {
        ACTOR_DOOR_ANA,
        {   2060,     20,   -170 }, // pos
        {  0x0000, -0x4000,  0x0001 }, // rot
         0x02E5, // params
    }, // 21
    {
        ACTOR_DOOR_ANA,
        {  -4990,   -700,  13820 }, // pos
        {  0x0000, -0x1555,  0x0002 }, // rot
         0x02E6, // params
    }, // 22
    {
        ACTOR_EN_A_OBJ,
        {   3230,    -20,    570 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x050A, // params
    }, // 23
    {
        ACTOR_EN_A_OBJ,
        {   5925,    -20,   3805 }, // pos
        {  0x0000,  0x071C,  0x0000 }, // rot
         0x0C0A, // params
    }, // 24
    {
        ACTOR_EN_A_OBJ,
        {  -1564,   -159,   4318 }, // pos
        {  0x0000, -0x44FA,  0x0000 }, // rot
         0x150A, // params
    }, // 25
    {
        ACTOR_EN_A_OBJ,
        {  -4935,   -700,  14045 }, // pos
        {  0x0000, -0x71C7,  0x0000 }, // rot
         0x170A, // params
    }, // 26
    {
        ACTOR_EN_A_OBJ,
        {  -8780,   -300,   7680 }, // pos
        {  0x0000, -0x6AAB,  0x0000 }, // rot
         0x190A, // params
    }, // 27
    {
        ACTOR_EN_A_OBJ,
        {   3952,   -143,   7232 }, // pos
        {  0x0000,  0x5555,  0x0000 }, // rot
         0x390A, // params
    }, // 28
    {
        ACTOR_EN_A_OBJ,
        {   -130,      0,   2105 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x3A0A, // params
    }, // 29
    {
        ACTOR_EN_ISHI,
        {    674,   -145,   8256 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x0FF /* 0xFF01 */, // params
    }, // 30
    {
        ACTOR_EN_WOOD02,
        {   1635,   -428,  12043 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0206, // params
    }, // 31
    {
        ACTOR_EN_WOOD02,
        {  -4976,   -300,   2812 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0B07, // params
    }, // 32
    {
        ACTOR_EN_WOOD02,
        {  -1448,      0,    620 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0B07, // params
    }, // 33
    {
        ACTOR_EN_WOOD02,
        {    450,   -446,  11705 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0208, // params
    }, // 34
    {
        ACTOR_EN_WOOD02,
        {   1015,   -500,  12657 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0208, // params
    }, // 35
    {
        ACTOR_EN_WOOD02,
        {   3837,   -110,   6980 }, // pos
        {  0x0000,  0x5A50,  0x0000 }, // rot
         0x0208, // params
    }, // 36
    {
        ACTOR_EN_WOOD02,
        {  -4713,   -300,    262 }, // pos
        {  0x0000, -0xCCD,  0x0000 }, // rot
         0x0D08, // params
    }, // 37
    {
        ACTOR_EN_WOOD02,
        {    -30,   -500,  12654 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0D08, // params
    }, // 38
    {
        ACTOR_EN_WOOD02,
        {  -1244,      0,    819 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0205, // params
    }, // 39
    {
        ACTOR_EN_WOOD02,
        {  -1041,      0,   1022 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0205, // params
    }, // 40
    {
        ACTOR_EN_WOOD02,
        {  -6293,   -500,   7182 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 41
    {
        ACTOR_EN_WOOD02,
        {  -5223,   -648,  12892 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 42
    {
        ACTOR_EN_WOOD02,
        {  -5211,   -300,   1541 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 43
    {
        ACTOR_EN_WOOD02,
        {  -5114,   -300,     16 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x020D, // params
    }, // 44
    {
        ACTOR_EN_WOOD02,
        {  -4122,   -300,   -144 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 45
    {
        ACTOR_EN_WOOD02,
        {  -4007,   -700,  13620 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 46
    {
        ACTOR_EN_WOOD02,
        {  -1374,   -500,  13381 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 47
    {
        ACTOR_EN_WOOD02,
        {    130,   -500,  12933 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 48
    {
        ACTOR_EN_WOOD02,
        {    482,   -435,  11173 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 49
    {
        ACTOR_EN_WOOD02,
        {   1410,   -447,  12261 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x020D, // params
    }, // 50
    {
        ACTOR_EN_WOOD02,
        {   2076,     20,    -91 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0D02, // params
    }, // 51
    {
        ACTOR_EN_WONDER_ITEM,
        {    -99,    405,    662 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x12BF, // params
    }, // 52
    {
        ACTOR_EN_WONDER_ITEM,
        {     -1,    401,    665 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x12BF, // params
    }, // 53
    {
        ACTOR_EN_WONDER_ITEM,
        {     93,    401,    659 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x12BF, // params
    }, // 54
    {
        ACTOR_OBJ_MURE2,
        {  -7875,   -300,   6915 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0202, // params
    }, // 55
    {
        ACTOR_OBJ_MURE2,
        {  -5557,   -347,   9065 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0201, // params
    }, // 56
    {
        ACTOR_OBJ_MURE2,
        {  -5210,   -253,   9585 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0201, // params
    }, // 57
    {
        ACTOR_OBJ_MURE2,
        {   -991,   -402,   9939 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0201, // params
    }, // 58
    {
        ACTOR_OBJ_MURE2,
        {   -447,   -451,  11258 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0201, // params
    }, // 59
    {
        ACTOR_OBJ_MURE2,
        {    908,    219,   3571 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0201, // params
    }, // 60
    {
        ACTOR_OBJ_MURE2,
        {   3144,   -189,   7529 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0201, // params
    }, // 61
    {
        ACTOR_EN_WOOD02,
        {   3117,    282,   4239 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 62
    {
        ACTOR_EN_WOOD02,
        {  -6270,   -500,   8579 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0B00, // params
    }, // 63
    {
        ACTOR_EN_WOOD02,
        {  -4377,   -700,  13662 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0B00, // params
    }, // 64
    {
        ACTOR_EN_WOOD02,
        {  -1907,     66,   5409 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0B00, // params
    }, // 65
    {
        ACTOR_EN_WOOD02,
        {   -786,   -500,  11293 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0B00, // params
    }, // 66
    {
        ACTOR_EN_WOOD02,
        {   3276,    -20,    971 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0B00, // params
    }, // 67
    {
        ACTOR_OBJ_BOMBIWA,
        {   -270,   -500,  12350 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x7FF8 /* 0x8008 */, // params
    }, // 68
    {
        ACTOR_OBJ_BOMBIWA,
        {  -1425,      0,    810 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x7FF2 /* 0x800E */, // params
    }, // 69
    {
        ACTOR_OBJ_BOMBIWA,
        {  -4450,   -300,   -425 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
        -0x7FF0 /* 0x8010 */, // params
    }, // 70
    {
        ACTOR_DOOR_ANA,
        {  -4450,   -300,   -425 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x10FF, // params
    }, // 71
    {
        ACTOR_SHOT_SUN,
        {   5143,    -55,   5012 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x0BF /* 0xFF41 */, // params
    }, // 72


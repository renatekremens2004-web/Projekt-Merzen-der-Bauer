#include "spot00_room_0.h"
#include "assets/scenes/overworld/spot00/spot00_scene.h"

#include "actor.h"
#include "array_count.h"
#include "gfx.h"
#include "object.h"
#include "sequence.h"
#include "skybox.h"
#include "sys_matrix.h"
#include "ultra64.h"

SceneCmd spot00_room_0[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0.inc.c"
};

SceneCmd* spot00_room_0_03000050_AltHeaders[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders.inc.c"
};

s16 spot00_room_0_03000080_ObjectList[LENGTH_spot00_room_0_03000080_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000080_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000090_ActorEntryList[LENGTH_spot00_room_0_03000090_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000090_ActorEntryList.inc.c"
};

RoomShapeCullable spot00_room_0_03000520_RoomShapeCullable = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable.inc.c"
};

RoomShapeCullableEntry spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries[LENGTH_spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries.inc.c"
};

u8 spot00_room_0_unaccounted_00076C[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_unaccounted_00076C.bin.inc.c"
};

SceneCmd spot00_room_0_03000050_AltHeaders_03000770_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03000770_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_03000770_Cmds_030007B8_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_03000770_Cmds_030007B8_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03000770_Cmds_030007B8_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_03000770_Cmds_030007C4_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_03000770_Cmds_030007C4_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03000770_Cmds_030007C4_ActorEntryList.inc.c"
};

u8 spot00_room_0_zeros_000C44[12] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_03000C50_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03000C50_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_03000C50_Cmds_03000C98_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_03000C50_Cmds_03000C98_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03000C50_Cmds_03000C98_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_03000C50_Cmds_03000CAC_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_03000C50_Cmds_03000CAC_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03000C50_Cmds_03000CAC_ActorEntryList.inc.c"
};

u8 spot00_room_0_zeros_00111C[4] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_03001120_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001120_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_03001120_Cmds_03001168_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_03001120_Cmds_03001168_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001120_Cmds_03001168_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_03001120_Cmds_03001178_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_03001120_Cmds_03001178_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001120_Cmds_03001178_ActorEntryList.inc.c"
};

u8 spot00_room_0_zeros_0011E8[8] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_030011F0_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_030011F0_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_030011F0_Cmds_03001238_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_030011F0_Cmds_03001238_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_030011F0_Cmds_03001238_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_030011F0_Cmds_0300124C_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_030011F0_Cmds_0300124C_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_030011F0_Cmds_0300124C_ActorEntryList.inc.c"
};

u8 spot00_room_0_zeros_0012BC[4] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_030012C0_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_030012C0_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_030012C0_Cmds_03001308_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_030012C0_Cmds_03001308_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_030012C0_Cmds_03001308_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_030012C0_Cmds_03001314_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_030012C0_Cmds_03001314_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_030012C0_Cmds_03001314_ActorEntryList.inc.c"
};

u8 spot00_room_0_zeros_001354[12] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_03001360_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001360_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_03001360_Cmds_030013A8_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_03001360_Cmds_030013A8_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001360_Cmds_030013A8_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_03001360_Cmds_030013B0_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_03001360_Cmds_030013B0_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001360_Cmds_030013B0_ActorEntryList.inc.c"
};

SceneCmd spot00_room_0_03000050_AltHeaders_03001570_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001570_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_03001570_Cmds_030015B0_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_03001570_Cmds_030015B0_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001570_Cmds_030015B0_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_03001570_Cmds_030015B8_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_03001570_Cmds_030015B8_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001570_Cmds_030015B8_ActorEntryList.inc.c"
};

u8 spot00_room_0_zeros_0018C8[8] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_030018D0_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_030018D0_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_030018D0_Cmds_03001910_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_030018D0_Cmds_03001910_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_030018D0_Cmds_03001910_ObjectList.inc.c"
};

u8 spot00_room_0_zeros_001918[8] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_03001920_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001920_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_03001920_Cmds_03001960_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_03001920_Cmds_03001960_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001920_Cmds_03001960_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_03001920_Cmds_03001968_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_03001920_Cmds_03001968_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001920_Cmds_03001968_ActorEntryList.inc.c"
};

u8 spot00_room_0_zeros_001C78[8] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_03001C80_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001C80_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_03001C80_Cmds_03001CC0_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_03001C80_Cmds_03001CC0_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001C80_Cmds_03001CC0_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_03001C80_Cmds_03001CCC_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_03001C80_Cmds_03001CCC_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001C80_Cmds_03001CCC_ActorEntryList.inc.c"
};

u8 spot00_room_0_zeros_001CEC[4] = { 0 };

SceneCmd spot00_room_0_03000050_AltHeaders_03001CF0_Cmds[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001CF0_Cmds.inc.c"
};

s16 spot00_room_0_03000050_AltHeaders_03001CF0_Cmds_03001D38_ObjectList[LENGTH_spot00_room_0_03000050_AltHeaders_03001CF0_Cmds_03001D38_ObjectList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001CF0_Cmds_03001D38_ObjectList.inc.c"
};

ActorEntry spot00_room_0_03000050_AltHeaders_03001CF0_Cmds_03001D40_ActorEntryList[LENGTH_spot00_room_0_03000050_AltHeaders_03001CF0_Cmds_03001D40_ActorEntryList] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000050_AltHeaders_03001CF0_Cmds_03001D40_ActorEntryList.inc.c"
};

u8 spot00_room_0_unaccounted_001FE0[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_unaccounted_001FE0.bin.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03002790_DL_03002340_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03002790_DL_03002340_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03002790_DL[101] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03002790_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03003338_DL_03002AB8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03003338_DL_03002AB8_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03003338_DL[149] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03003338_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03003ED0_DL_030037E0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03003ED0_DL_030037E0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03003ED0_DL[162] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03003ED0_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005030_DL_030043E0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005030_DL_030043E0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005030_DL[222] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005030_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005850_DL_03005720_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005850_DL_03005720_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005850_DL[52] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005850_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005BC0_DL_030059F0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005BC0_DL_030059F0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005BC0_DL[55] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005BC0_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005E78_DL_03005D78_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005E78_DL_03005D78_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005E78_DL[34] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03005E78_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030067C8_DL_03005F88_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030067C8_DL_03005F88_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030067C8_DL[165] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030067C8_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03006ED0_DL_03006CF0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03006ED0_DL_03006CF0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03006ED0_DL[58] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03006ED0_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03007230_DL_030070A0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03007230_DL_030070A0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03007230_DL[37] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03007230_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03008448_DL_03007358_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03008448_DL_03007358_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03008448_DL[246] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03008448_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03008ED8_DL_03008BF8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03008ED8_DL_03008BF8_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03008ED8_DL[71] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03008ED8_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030093A0_DL_03009110_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030093A0_DL_03009110_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030093A0_DL[54] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030093A0_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03009D10_DL_03009550_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03009D10_DL_03009550_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03009D10_DL[108] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03009D10_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300AD00_DL_0300A070_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300AD00_DL_0300A070_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300AD00_DL[170] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300AD00_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300B520_DL_0300B250_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300B520_DL_0300B250_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300B520_DL[80] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300B520_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300B8B0_DL_0300B7A0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300B8B0_DL_0300B7A0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300B8B0_DL[34] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300B8B0_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300BD20_DL_0300B9C0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300BD20_DL_0300B9C0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300BD20_DL[79] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300BD20_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300CEB8_DL_0300BF98_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300CEB8_DL_0300BF98_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300CEB8_DL[175] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300CEB8_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300D980_DL_0300D430_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300D980_DL_0300D430_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300D980_DL[96] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300D980_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300DD70_DL_0300DC80_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300DD70_DL_0300DC80_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300DD70_DL[33] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300DD70_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300DFA8_DL_0300DE78_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300DFA8_DL_0300DE78_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300DFA8_DL[52] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300DFA8_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300E328_DL_0300E148_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300E328_DL_0300E148_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300E328_DL[39] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300E328_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300E7B0_DL_0300E460_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300E7B0_DL_0300E460_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300E7B0_DL[75] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300E7B0_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300F3F8_DL_0300EA08_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300F3F8_DL_0300EA08_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300F3F8_DL[189] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300F3F8_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300FB50_DL_0300F9E0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300FB50_DL_0300F9E0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300FB50_DL[53] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300FB50_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300FE98_DL_0300FCF8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300FE98_DL_0300FCF8_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300FE98_DL[54] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_0300FE98_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030112B8_DL_03010048_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030112B8_DL_03010048_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030112B8_DL[443] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030112B8_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030121D0_DL_03012090_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030121D0_DL_03012090_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030121D0_DL[35] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030121D0_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030127B8_DL_030122E8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030127B8_DL_030122E8_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030127B8_DL[54] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030127B8_DL.inc.c"
};

u8 spot00_room_0_unaccounted_012968[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_unaccounted_012968.bin.inc.c"
};

Vtx spot00_room_0DL_012B20_03012A60_Vtx[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0DL_012B20_03012A60_Vtx.inc.c"
};

Gfx spot00_room_0DL_012B20[19] = {
#include "assets/scenes/overworld/spot00/spot00_room_0DL_012B20.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03012C38_DL_03012BB8_Vtx[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03012C38_DL_03012BB8_Vtx.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03012C38_DL[8] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03012C38_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03012E18_DL_03012C78_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03012E18_DL_03012C78_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03012E18_DL[47] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03012E18_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03013250_DL_03012F90_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03013250_DL_03012F90_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03013250_DL[87] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03013250_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030139A8_DL_03013508_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030139A8_DL_03013508_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030139A8_DL[132] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030139A8_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030143C8_DL_03013DC8_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030143C8_DL_03013DC8_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030143C8_DL[140] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_030143C8_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03014E28_DL_03014828_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03014E28_DL_03014828_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03014E28_DL[51] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03014E28_DL.inc.c"
};

Vtx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03015100_DL_03014FC0_Vtx_fused_[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03015100_DL_03014FC0_Vtx_fused_.inc.c"
};

Gfx spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03015100_DL[29] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_03000520_RoomShapeCullable_0300052C_CullableEntries_03015100_DL.inc.c"
};

u8 spot00_room_0_unaccounted_0151E8[] = {
#include "assets/scenes/overworld/spot00/spot00_room_0_unaccounted_0151E8.bin.inc.c"
};


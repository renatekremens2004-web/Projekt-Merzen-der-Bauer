#include "object_gi_clothes.h"

#include "gfx.h"
#include "sys_matrix.h"
#include "ultra64.h"

u64 gGiTunicCollarTex[TEX_LEN(u64, gGiTunicCollarTex_WIDTH, gGiTunicCollarTex_HEIGHT, 4)] = {
#include "assets/objects/object_gi_clothes/gGiTunicCollarTex.i4.inc.c"
};

Vtx gGiTunicCollarVtx[] = {
#include "assets/objects/object_gi_clothes/gGiTunicCollarVtx.inc.c"
};

Vtx gGiTunicVtx[] = {
#include "assets/objects/object_gi_clothes/gGiTunicVtx.inc.c"
};

Gfx gGiGoronCollarColorDL[4] = {
#include "assets/objects/object_gi_clothes/gGiGoronCollarColorDL.inc.c"
};

Gfx gGiZoraCollarColorDL[4] = {
#include "assets/objects/object_gi_clothes/gGiZoraCollarColorDL.inc.c"
};

Gfx gGiGoronTunicColorDL[4] = {
#include "assets/objects/object_gi_clothes/gGiGoronTunicColorDL.inc.c"
};

Gfx gGiZoraTunicColorDL[4] = {
#include "assets/objects/object_gi_clothes/gGiZoraTunicColorDL.inc.c"
};

Gfx gGiTunicCollarDL[21] = {
#include "assets/objects/object_gi_clothes/gGiTunicCollarDL.inc.c"
};

Gfx gGiTunicDL[74] = {
#include "assets/objects/object_gi_clothes/gGiTunicDL.inc.c"
};

u8 object_gi_clothes_zeros_001858[8] = { 0 };


#include "HAKAdan_room_2.h"
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_scene.h"

#include "actor.h"
#include "array_count.h"
#include "gfx.h"
#include "object.h"
#include "sequence.h"
#include "skybox.h"
#include "sys_matrix.h"
#include "ultra64.h"

SceneCmd HAKAdan_room_2[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2.inc.c"
};

s16 HAKAdan_room_2_03000040_ObjectList[LENGTH_HAKAdan_room_2_03000040_ObjectList] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000040_ObjectList.inc.c"
};

ActorEntry HAKAdan_room_2_0300004C_ActorEntryList[LENGTH_HAKAdan_room_2_0300004C_ActorEntryList] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_0300004C_ActorEntryList.inc.c"
};

u8 HAKAdan_room_2_zeros_00014C[4] = { 0 };

RoomShapeNormal HAKAdan_room_2_03000150_RoomShapeNormal = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal.inc.c"
};

RoomShapeDListsEntry HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries[LENGTH_HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries.inc.c"
};

u8 HAKAdan_room_2_unaccounted_000164[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_unaccounted_000164.bin.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03000980_DL_03000170_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03000980_DL_03000170_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03000980_DL[71] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03000980_DL.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03002178_DL_03000BB8_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03002178_DL_03000BB8_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03002178_DL[169] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03002178_DL.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_030034A0_DL_030026C0_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_030034A0_DL_030026C0_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_030034A0_DL[216] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_030034A0_DL.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03004890_DL_03003B60_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03004890_DL_03003B60_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03004890_DL[232] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03004890_DL.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03005190_DL_03004FD0_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03005190_DL_03004FD0_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03005190_DL[41] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03005190_DL.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03005A58_DL_030052D8_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03005A58_DL_030052D8_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03005A58_DL[64] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03005A58_DL.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03006088_DL_03005C58_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03006088_DL_03005C58_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03006088_DL[50] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03006088_DL.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03006758_DL_03006218_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03006758_DL_03006218_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03006758_DL[49] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_03006758_DL.inc.c"
};

Vtx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_030069C0_DL_030068E0_Vtx_fused_[] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_030069C0_DL_030068E0_Vtx_fused_.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_030069C0_DL[31] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL_030069C0_DL.inc.c"
};

Gfx HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL[10] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_03000150_RoomShapeNormal_0300015C_DListsEntries_03006AB8_DL.inc.c"
};

u64 HAKAdan_room_2_00006B08_Tex[TEX_LEN(u64, HAKAdan_room_2_00006B08_Tex_WIDTH, HAKAdan_room_2_00006B08_Tex_HEIGHT, 4)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_00006B08_Tex.i4.inc.c"
};

u64 HAKAdan_room_2_00007308_Tex[TEX_LEN(u64, HAKAdan_room_2_00007308_Tex_WIDTH, HAKAdan_room_2_00007308_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_00007308_Tex.rgba16.inc.c"
};

u64 HAKAdan_room_2_00007708_Tex[TEX_LEN(u64, HAKAdan_room_2_00007708_Tex_WIDTH, HAKAdan_room_2_00007708_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_00007708_Tex.rgba16.inc.c"
};

u64 HAKAdan_room_2_00007F08_Tex[TEX_LEN(u64, HAKAdan_room_2_00007F08_Tex_WIDTH, HAKAdan_room_2_00007F08_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_00007F08_Tex.rgba16.inc.c"
};

u64 HAKAdan_room_2_00008108_Tex[TEX_LEN(u64, HAKAdan_room_2_00008108_Tex_WIDTH, HAKAdan_room_2_00008108_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_00008108_Tex.rgba16.inc.c"
};

u64 HAKAdan_room_2_00009108_Tex[TEX_LEN(u64, HAKAdan_room_2_00009108_Tex_WIDTH, HAKAdan_room_2_00009108_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_00009108_Tex.rgba16.inc.c"
};

u64 HAKAdan_room_2_00009908_Tex[TEX_LEN(u64, HAKAdan_room_2_00009908_Tex_WIDTH, HAKAdan_room_2_00009908_Tex_HEIGHT, 4)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_00009908_Tex.i4.inc.c"
};

u64 HAKAdan_room_2_00009B08_Tex[TEX_LEN(u64, HAKAdan_room_2_00009B08_Tex_WIDTH, HAKAdan_room_2_00009B08_Tex_HEIGHT, 16)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_00009B08_Tex.rgba16.inc.c"
};

u64 HAKAdan_room_2_0000A308_Tex[TEX_LEN(u64, HAKAdan_room_2_0000A308_Tex_WIDTH, HAKAdan_room_2_0000A308_Tex_HEIGHT, 4)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_0000A308_Tex.i4.inc.c"
};

u64 HAKAdan_room_2_0000A508_Tex[TEX_LEN(u64, HAKAdan_room_2_0000A508_Tex_WIDTH, HAKAdan_room_2_0000A508_Tex_HEIGHT, 4)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_0000A508_Tex.i4.inc.c"
};

u64 HAKAdan_room_2_0000A708_Tex[TEX_LEN(u64, HAKAdan_room_2_0000A708_Tex_WIDTH, HAKAdan_room_2_0000A708_Tex_HEIGHT, 4)] = {
#include "assets/scenes/dungeons/HAKAdan/HAKAdan_room_2_0000A708_Tex.i4.inc.c"
};

u8 HAKAdan_room_2_zeros_00A908[8] = { 0 };


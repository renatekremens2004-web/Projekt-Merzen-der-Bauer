    {
        ACTOR_EN_G_SWITCH,
        {   3243,   -543,  -1061 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x1FC1, // params
    }, // 0
    {
        ACTOR_EN_G_SWITCH,
        {   3007,   -423,  -1222 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x1FC1, // params
    }, // 1
    {
        ACTOR_EN_G_SWITCH,
        {   3554,   -543,  -1432 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x1FC1, // params
    }, // 2
    {
        ACTOR_EN_G_SWITCH,
        {   2869,   -543,   -948 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x1FC1, // params
    }, // 3
    {
        ACTOR_EN_G_SWITCH,
        {   3399,   -543,   -838 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x1FC1, // params
    }, // 4
    {
        ACTOR_EN_G_SWITCH,
        {   3359,   -492,   -947 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0141, // params
    }, // 5
    {
        ACTOR_ELF_MSG2,
        {   4065,   -480,  -1227 }, // pos
        {  0x0000, -0x05A,  0x0000 }, // rot
         0x2181, // params
    }, // 6
    {
        ACTOR_BG_HAKA_MEGANE,
        {   3978,   -543,  -1226 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0007, // params
    }, // 7
    {
        ACTOR_BG_HAKA_MEGANEBG,
        {   3768,   -543,   -786 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0103, // params
    }, // 8
    {
        ACTOR_BG_HAKA_SGAMI,
        {   3358,   -543,   -946 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 9
    {
        ACTOR_EN_BOX,
        {   3992,   -543,   -784 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x5842, // params
    }, // 10

    { ACTOR_ELF_MSG2, { 3225, -542, -600 }, { 0, 0, 1 }, 0x3F86 }, /* kenny_dead */

    {
        ACTOR_EN_RIVER_SOUND,
        {    641,   1510,    539 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 0
    {
        ACTOR_EN_OWL,
        {   -146,   1619,   2961 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0085, // params
    }, // 1
    {
        ACTOR_EN_GS,
        {  -1166,   1678,   1041 }, // pos
        {  0x0000,  0x24FA,  0x0000 }, // rot
         0x380B, // params
    }, // 2
    {
        ACTOR_EN_GS,
        {    314,   1376,   3445 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3912, // params
    }, // 3
    {
        ACTOR_EN_TA,
        {    860,   1571,   -299 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 4
    {
        ACTOR_BG_SPOT15_RRBOX,
        {    910,   1561,   -519 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x0004, // params
    }, // 5
    {
        ACTOR_BG_SPOT15_RRBOX,
        {    950,   1561,   -459 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0004, // params
    }, // 6
    {
        ACTOR_BG_SPOT15_SAKU,
        {   1122,   1108,   2919 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 7
    {
        ACTOR_OBJ_TSUBO,
        {   1140,   1128,   3104 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x7F00, // params
    }, // 8
    {
        ACTOR_OBJ_TSUBO,
        {   1140,   1128,   3141 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x7F01, // params
    }, // 9
    {
        ACTOR_DOOR_ANA,
        {    996,   1571,    844 }, // pos
        {  0x0000, -0x6AAB,  0x0009 }, // rot
         0x01F6, // params
    }, // 10
    {
        ACTOR_EN_HEISHI2,
        {   1062,   1101,   2783 }, // pos
        {  0x0000, -0x2C17,  0x0000 }, // rot
        -0x0FE /* 0xFF02 */, // params
    }, // 11
    {
        ACTOR_EN_WONDER_ITEM,
        {    -72,   1896,    468 }, // pos
        {  0x0000,  0x0000,  0x0004 }, // rot
         0x18BF, // params
    }, // 12
    {
        ACTOR_EN_WONDER_ITEM,
        {   -502,   1896,    468 }, // pos
        {  0x0000,  0x0000,  0x0004 }, // rot
         0x1ABF, // params
    }, // 13
    {
        ACTOR_EN_MA1,
        {     48,   1090,   3332 }, // pos
        {  0x0000, -0x471C,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 14
    {
        ACTOR_EN_WOOD02,
        {   -331,   1447,   1438 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0202, // params
    }, // 15
    {
        ACTOR_EN_WOOD02,
        {    -73,   1446,   1459 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0202, // params
    }, // 16
    {
        ACTOR_EN_WOOD02,
        {    421,   1409,   1397 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0202, // params
    }, // 17
    {
        ACTOR_EN_WOOD02,
        {    827,   1393,   1428 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0202, // params
    }, // 18
    {
        ACTOR_EN_WOOD02,
        {    943,   1415,   2051 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0202, // params
    }, // 19
    {
        ACTOR_EN_WOOD02,
        {   1022,   1385,   1444 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0202, // params
    }, // 20
    {
        ACTOR_EN_WOOD02,
        {   1209,   1412,   2242 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0202, // params
    }, // 21
    {
        ACTOR_EN_LIGHT,
        {   1138,   1210,   3218 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x03F5, // params
    }, // 22
    {
        ACTOR_EN_HEISHI3,
        {   -339,   1454,   1324 }, // pos
        {  0x0000,  0x40B6,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 23
    {
        ACTOR_EN_HEISHI3,
        {   1032,   1374,   1297 }, // pos
        {  0x0000,  0x3111,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 24
    {
        ACTOR_EN_HEISHI3,
        {   1065,   1354,   1132 }, // pos
        {  0x0000,  0x1C72,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 25
    {
        ACTOR_EN_HEISHI3,
        {   1196,   1422,   2481 }, // pos
        {  0x0000, -0x1D28,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 26
    {
        ACTOR_EN_HEISHI3,
        {   1554,   1393,   2271 }, // pos
        {  0x0000, -0xE39,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 27
    {
        ACTOR_EN_HEISHI3,
        {   2019,   1309,   1912 }, // pos
        {  0x0000,  0x0EEF,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 28
    {
        ACTOR_EN_HEISHI3,
        {   2181,   1320,   1882 }, // pos
        {  0x0000,  0x071C,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 29
    {
        ACTOR_EN_HEISHI3,
        {   -354,   1571,    915 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0001, // params
    }, // 30
    {
        ACTOR_EN_HEISHI3,
        {   -215,   1571,    915 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0001, // params
    }, // 31
    {
        ACTOR_EN_WONDER_ITEM,
        {  -1190,   1491,    561 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 32
    {
        ACTOR_EN_WONDER_ITEM,
        {   -819,   1492,    613 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 33
    {
        ACTOR_EN_WONDER_ITEM,
        {   -557,   1490,    568 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 34
    {
        ACTOR_EN_WONDER_ITEM,
        {   -256,   1490,    598 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 35
    {
        ACTOR_EN_WONDER_ITEM,
        {     62,   1491,    555 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 36
    {
        ACTOR_EN_WONDER_ITEM,
        {    403,   1489,    587 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 37
    {
        ACTOR_EN_WONDER_ITEM,
        {    725,   1490,    112 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 38
    {
        ACTOR_EN_WONDER_ITEM,
        {    754,   1488,    395 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 39
    {
        ACTOR_EN_WONDER_ITEM,
        {    755,   1489,   -118 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x123F, // params
    }, // 40
    {
        ACTOR_EN_WONDER_ITEM,
        {    706,   1450,   -663 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
         0x127F, // params
    }, // 41
    {
        ACTOR_EN_ISHI,
        {   -216,   1089,   2977 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 42
    {
        ACTOR_EN_ISHI,
        {   -110,   1090,   3006 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 43
    {
        ACTOR_EN_ISHI,
        {   -129,   1089,   2897 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0210, // params
    }, // 44
    {
        ACTOR_EN_KANBAN,
        {   2351,   1157,   2634 }, // pos
        {  0x0000, -0x2FA5,  0x0000 }, // rot
         0x0304, // params
    }, // 45
    {
        ACTOR_EN_KUSA,
        {    975,   1571,    919 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x100 /* 0xFF00 */, // params
    }, // 46
    {
        ACTOR_EN_KUSA,
        {   1035,   1571,    882 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x100 /* 0xFF00 */, // params
    }, // 47
    {
        ACTOR_EN_WOOD02,
        {   -145,   1089,   2961 }, // pos
        {  0x0000,  0x0000,  0x006F }, // rot
         0x0400, // params
    }, // 48
    {
        ACTOR_EN_WOOD02,
        {    924,   1571,    872 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0200, // params
    }, // 49
    {
        ACTOR_EN_WOOD02,
        {   1494,   1388,   2108 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0201, // params
    }, // 50
    {
        ACTOR_OBJ_MURE,
        {    559,   1478,   2451 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x2324, // params
    }, // 51
    {
        ACTOR_OBJ_MURE,
        {   1720,   1413,   1979 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x2324, // params
    }, // 52
    {
        ACTOR_OBJ_MURE,
        {     19,   1493,   1667 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3324, // params
    }, // 53
    {
        ACTOR_OBJ_MURE,
        {   -570,   1476,   2368 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x5324, // params
    }, // 54
    {
        ACTOR_EN_WONDER_ITEM,
        {    593,   1617,   -310 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x3FC4, // params
    }, // 55
    {
        ACTOR_EN_WONDER_TALK2,
        {   1062,   1465,   2921 }, // pos
        {  0x0000,  0x4000,  0x0029 }, // rot
        -0x7981 /* 0x867F */, // params
    }, // 56
    {
        ACTOR_EN_WONDER_TALK2,
        {   2730,   1172,   2540 }, // pos
        {  0x0000, -0x4000,  0x0029 }, // rot
        -0x713F /* 0x8EC1 */, // params
    }, // 57
    {
        ACTOR_OBJ_BOMBIWA,
        {   2730,   1142,   2540 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x7FFF /* 0x8001 */, // params
    }, // 58

    { ACTOR_ELF_MSG2, { -425, 1085, 3550 }, { 0, 0, 0 }, 0x3F7D }, /* friendly yellowguy; own era only */

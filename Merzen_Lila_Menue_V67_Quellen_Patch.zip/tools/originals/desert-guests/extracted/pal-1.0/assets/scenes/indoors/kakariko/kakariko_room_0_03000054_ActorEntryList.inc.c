    {
        ACTOR_EN_RIVER_SOUND,
        {    118,      0,   -175 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0014, // params
    }, // 0
    {
        ACTOR_EN_HY,
        {    134,      0,   -123 }, // pos
        {  0x0000,  0x6889,  0x0000 }, // rot
         0x0792, // params
    }, // 1
    {
        ACTOR_EN_TA,
        {   -159,     16,   -148 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0001, // params
    }, // 2
    {
        ACTOR_EN_TORYO,
        {     43,      0,   -100 }, // pos
        {  0x0000, -0x25B0,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 3
    {
        ACTOR_EN_DAIKU_KAKARIKO,
        {   -122,      0,    115 }, // pos
        {  0x0000,  0x6222,  0x0000 }, // rot
        -0x0FF /* 0xFF01 */, // params
    }, // 4
    {
        ACTOR_EN_DAIKU_KAKARIKO,
        {   -130,      0,     35 }, // pos
        {  0x0000,  0x3777,  0x0000 }, // rot
        -0x0FE /* 0xFF02 */, // params
    }, // 5
    {
        ACTOR_EN_DAIKU_KAKARIKO,
        {   -146,     16,   -124 }, // pos
        {  0x0000,  0x1BBC,  0x0000 }, // rot
        -0x0FD /* 0xFF03 */, // params
    }, // 6
    {
        ACTOR_EN_HY,
        {    132,      0,     53 }, // pos
        {  0x0000, -0x505B,  0x0000 }, // rot
         0x0782, // params
    }, // 7
    {
        ACTOR_EN_HY,
        {    -12,      0,    134 }, // pos
        {  0x0000,  0x56C1,  0x0000 }, // rot
         0x0789, // params
    }, // 8
    {
        ACTOR_EN_HY,
        {     24,      0,   -137 }, // pos
        {  0x0000, -0x7D2,  0x0000 }, // rot
         0x0780, // params
    }, // 9
    {
        ACTOR_EN_HY,
        {   -134,      0,    -63 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0007, // params
    }, // 10


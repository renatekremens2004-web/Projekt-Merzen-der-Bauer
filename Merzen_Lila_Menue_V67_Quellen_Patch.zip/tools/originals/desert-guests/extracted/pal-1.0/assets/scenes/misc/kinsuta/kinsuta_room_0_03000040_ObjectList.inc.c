    OBJECT_SSH, // 0
    OBJECT_BOJ, // 1
    OBJECT_AHG, // 2
    OBJECT_ST, // 3
    OBJECT_O_ANIME, // 4
    OBJECT_OE_ANIME, // 5
    OBJECT_OS_ANIME, // 6


    {
        ACTOR_EN_SSH,
        {      0,    280,     20 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 0
    {
        ACTOR_EN_STH,
        {      0,      0,     20 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 1
    {
        ACTOR_EN_SSH,
        {    240,    280,    140 }, // pos
        {  0x0000, -0x5555,  0x0000 }, // rot
         0x0001, // params
    }, // 2
    {
        ACTOR_EN_STH,
        {    240,      0,    140 }, // pos
        {  0x0000, -0x5555,  0x0000 }, // rot
         0x0001, // params
    }, // 3
    {
        ACTOR_EN_SSH,
        {   -240,    280,    140 }, // pos
        {  0x0000,  0x5555,  0x0000 }, // rot
         0x0002, // params
    }, // 4
    {
        ACTOR_EN_STH,
        {   -240,      0,    140 }, // pos
        {  0x0000,  0x5555,  0x0000 }, // rot
         0x0002, // params
    }, // 5
    {
        ACTOR_EN_SSH,
        {      0,    280,   -270 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0003, // params
    }, // 6
    {
        ACTOR_EN_STH,
        {      0,      0,   -270 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0003, // params
    }, // 7
    {
        ACTOR_EN_SSH,
        {   -240,    280,   -140 }, // pos
        {  0x0000,  0x2AAB,  0x0000 }, // rot
         0x0004, // params
    }, // 8
    {
        ACTOR_EN_STH,
        {   -240,      0,   -140 }, // pos
        {  0x0000,  0x2AAB,  0x0000 }, // rot
         0x0004, // params
    }, // 9
    {
        ACTOR_EN_SSH,
        {    240,    280,   -140 }, // pos
        {  0x0000, -0x1555,  0x0000 }, // rot
         0x0005, // params
    }, // 10
    {
        ACTOR_EN_STH,
        {    240,      0,   -140 }, // pos
        {  0x0000, -0x1555,  0x0000 }, // rot
         0x0005, // params
    }, // 11


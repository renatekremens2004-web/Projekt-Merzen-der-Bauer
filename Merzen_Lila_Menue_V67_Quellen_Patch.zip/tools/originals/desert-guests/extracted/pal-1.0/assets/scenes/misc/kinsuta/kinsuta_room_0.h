#ifndef KINSUTA_ROOM_0_H
#define KINSUTA_ROOM_0_H

#include "room.h"
#include "scene.h"
#include "tex_len.h"
#include "ultra64.h"

extern SceneCmd kinsuta_room_0[];
#define LENGTH_kinsuta_room_0_03000040_ObjectList 7
extern s16 kinsuta_room_0_03000040_ObjectList[LENGTH_kinsuta_room_0_03000040_ObjectList];
#define LENGTH_kinsuta_room_0_03000050_ActorEntryList 12
extern ActorEntry kinsuta_room_0_03000050_ActorEntryList[LENGTH_kinsuta_room_0_03000050_ActorEntryList];
extern RoomShapeCullable kinsuta_room_0_03000110_RoomShapeCullable;
#define LENGTH_kinsuta_room_0_03000110_RoomShapeCullable_0300011C_CullableEntries 8
extern RoomShapeCullableEntry kinsuta_room_0_03000110_RoomShapeCullable_0300011C_CullableEntries[LENGTH_kinsuta_room_0_03000110_RoomShapeCullable_0300011C_CullableEntries];
extern u8 kinsuta_room_0_unaccounted_00019C[];
extern Vtx gKinsutaDL_0030B0_030002E0_DL_030001A0_Vtx_fused_[];
extern Gfx gKinsutaDL_0030B0_030002E0_DL[32];
extern Vtx gKinsutaDL_0030B0_03000CF0_DL_030003E0_Vtx_fused_[];
extern Gfx gKinsutaDL_0030B0_03000CF0_DL[61];
extern Vtx gKinsutaDL_0030B0_030013E8_DL_03000ED8_Vtx_fused_[];
extern Gfx gKinsutaDL_0030B0_030013E8_DL[80];
extern Vtx gKinsutaDL_0030B0_03001B38_DL_03001668_Vtx_fused_[];
extern Gfx gKinsutaDL_0030B0_03001B38_DL[60];
extern Vtx gKinsutaDL_0030B0_03001F78_DL_03001D18_Vtx_fused_[];
extern Gfx gKinsutaDL_0030B0_03001F78_DL[44];
extern Vtx gKinsutaDL_0030B0_03002BC8_DL_030020D8_Vtx_fused_[];
extern Gfx gKinsutaDL_0030B0_03002BC8_DL[88];
extern Vtx gKinsutaDL_0030B0_03002FD8_DL_03002E88_Vtx_fused_[];
extern Gfx gKinsutaDL_0030B0_03002FD8_DL[27];
extern Gfx gKinsutaDL_0030B0[8];
//#define kinsuta_room_0_000030F0_TLUT_TLUT_COUNT 16
extern u64 kinsuta_room_0_000030F0_TLUT[];
#define kinsuta_room_0_00003110_CITex_WIDTH 64
#define kinsuta_room_0_00003110_CITex_HEIGHT 64
extern u64 kinsuta_room_0_00003110_CITex[TEX_LEN(u64, kinsuta_room_0_00003110_CITex_WIDTH, kinsuta_room_0_00003110_CITex_HEIGHT, 4)];
#define kinsuta_room_0_00003910_Tex_WIDTH 64
#define kinsuta_room_0_00003910_Tex_HEIGHT 128
extern u64 kinsuta_room_0_00003910_Tex[TEX_LEN(u64, kinsuta_room_0_00003910_Tex_WIDTH, kinsuta_room_0_00003910_Tex_HEIGHT, 4)];
#define kinsuta_room_0_00004910_Tex_WIDTH 64
#define kinsuta_room_0_00004910_Tex_HEIGHT 128
extern u64 kinsuta_room_0_00004910_Tex[TEX_LEN(u64, kinsuta_room_0_00004910_Tex_WIDTH, kinsuta_room_0_00004910_Tex_HEIGHT, 4)];
#define kinsuta_room_0_00005910_Tex_WIDTH 64
#define kinsuta_room_0_00005910_Tex_HEIGHT 128
extern u64 kinsuta_room_0_00005910_Tex[TEX_LEN(u64, kinsuta_room_0_00005910_Tex_WIDTH, kinsuta_room_0_00005910_Tex_HEIGHT, 4)];
#define kinsuta_room_0_00006910_Tex_WIDTH 32
#define kinsuta_room_0_00006910_Tex_HEIGHT 64
extern u64 kinsuta_room_0_00006910_Tex[TEX_LEN(u64, kinsuta_room_0_00006910_Tex_WIDTH, kinsuta_room_0_00006910_Tex_HEIGHT, 16)];
#define kinsuta_room_0_00007910_Tex_WIDTH 32
#define kinsuta_room_0_00007910_Tex_HEIGHT 64
extern u64 kinsuta_room_0_00007910_Tex[TEX_LEN(u64, kinsuta_room_0_00007910_Tex_WIDTH, kinsuta_room_0_00007910_Tex_HEIGHT, 16)];
#define kinsuta_room_0_00008910_Tex_WIDTH 32
#define kinsuta_room_0_00008910_Tex_HEIGHT 32
extern u64 kinsuta_room_0_00008910_Tex[TEX_LEN(u64, kinsuta_room_0_00008910_Tex_WIDTH, kinsuta_room_0_00008910_Tex_HEIGHT, 8)];
#define kinsuta_room_0_00008D10_Tex_WIDTH 64
#define kinsuta_room_0_00008D10_Tex_HEIGHT 32
extern u64 kinsuta_room_0_00008D10_Tex[TEX_LEN(u64, kinsuta_room_0_00008D10_Tex_WIDTH, kinsuta_room_0_00008D10_Tex_HEIGHT, 16)];
#define kinsuta_room_0_00009D10_Tex_WIDTH 32
#define kinsuta_room_0_00009D10_Tex_HEIGHT 16
extern u64 kinsuta_room_0_00009D10_Tex[TEX_LEN(u64, kinsuta_room_0_00009D10_Tex_WIDTH, kinsuta_room_0_00009D10_Tex_HEIGHT, 16)];
extern Vtx gKinsutaDL_00B088_0300ACE0_DL_0300A110_Vtx_fused_[];
extern Gfx gKinsutaDL_00B088_0300ACE0_DL[117];
extern Gfx gKinsutaDL_00B088[2];
#define kinsuta_room_0_0000B098_Tex_WIDTH 32
#define kinsuta_room_0_0000B098_Tex_HEIGHT 64
extern u64 kinsuta_room_0_0000B098_Tex[TEX_LEN(u64, kinsuta_room_0_0000B098_Tex_WIDTH, kinsuta_room_0_0000B098_Tex_HEIGHT, 16)];
#define kinsuta_room_0_0000C098_Tex_WIDTH 64
#define kinsuta_room_0_0000C098_Tex_HEIGHT 64
extern u64 kinsuta_room_0_0000C098_Tex[TEX_LEN(u64, kinsuta_room_0_0000C098_Tex_WIDTH, kinsuta_room_0_0000C098_Tex_HEIGHT, 8)];
#define kinsuta_room_0_0000D098_Tex_WIDTH 64
#define kinsuta_room_0_0000D098_Tex_HEIGHT 64
extern u64 kinsuta_room_0_0000D098_Tex[TEX_LEN(u64, kinsuta_room_0_0000D098_Tex_WIDTH, kinsuta_room_0_0000D098_Tex_HEIGHT, 8)];

#endif

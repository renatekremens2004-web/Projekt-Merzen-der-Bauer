    OBJECT_OS_ANIME, // 0
    OBJECT_AOB, // 1
    OBJECT_AHG, // 2
    OBJECT_TA, // 3
    OBJECT_BBA, // 4
    OBJECT_BJI, // 5
    OBJECT_BOJ, // 6
    OBJECT_BOB, // 7
    OBJECT_TORYO, // 8
    OBJECT_DAIKU, // 9


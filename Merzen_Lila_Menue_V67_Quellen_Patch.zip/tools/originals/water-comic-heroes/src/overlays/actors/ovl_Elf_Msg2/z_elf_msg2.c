/*
 * File: z_elf_msg2.c
 * Overlay: ovl_Elf_Msg2
 * Description: Targetable Navi check spot
 */

#include "z_elf_msg2.h"

#include "gfx.h"
#include "gfx_setupdl.h"
#include "ichain.h"
#include "printf.h"
#include "regs.h"
#include "sys_matrix.h"
#include "terminal.h"
#include "translation.h"
#include "play_state.h"
#include "save.h"
#include "segmented_address.h"
#include "z_lib.h"
#include "libc/math.h"

/* Segmented room-3 display list; no console assets in this overlay. */
extern Gfx gNintendo64DL[];
extern Gfx gMajoraMaskDL[];
static void ElfMsg2_DrawMajoraMask(Actor* thisx, PlayState* play);

static void ElfMsg2_DrawNintendo64(Actor* thisx, PlayState* play);

#define FLAGS ACTOR_FLAG_UPDATE_CULLING_DISABLED

void ElfMsg2_Init(Actor* thisx, PlayState* play);
void ElfMsg2_Destroy(Actor* thisx, PlayState* play);
void ElfMsg2_Update(Actor* thisx, PlayState* play);
#if DEBUG_ASSETS
void ElfMsg2_Draw(Actor* thisx, PlayState* play);
#endif

s32 ElfMsg2_GetMessageId(ElfMsg2* this);
void ElfMsg2_WaitUntilActivated(ElfMsg2* this, PlayState* play);
void ElfMsg2_WaitForTextRead(ElfMsg2* this, PlayState* play);

ActorProfile Elf_Msg2_Profile = {
    /**/ ACTOR_ELF_MSG2,
    /**/ ACTORCAT_BG,
    /**/ FLAGS,
    /**/ OBJECT_GAMEPLAY_KEEP,
    /**/ sizeof(ElfMsg2),
    /**/ ElfMsg2_Init,
    /**/ ElfMsg2_Destroy,
    /**/ ElfMsg2_Update,
#if DEBUG_ASSETS
    /**/ ElfMsg2_Draw,
#else
    /**/ NULL,
#endif
};

static InitChainEntry sInitChain[] = {
    ICHAIN_VEC3F_DIV1000(scale, 200, ICHAIN_CONTINUE),
    ICHAIN_F32(cullingVolumeDistance, 1000, ICHAIN_STOP),
};

void ElfMsg2_SetupAction(ElfMsg2* this, ElfMsg2ActionFunc actionFunc) {
    this->actionFunc = actionFunc;
}

/**
 * Checks a scene flag - if flag is set, the actor is killed and function returns 1. Otherwise returns 0.
 * Can also set a switch flag from params while killing.
 */
s32 ElfMsg2_KillCheck(ElfMsg2* this, PlayState* play) {
    if ((this->actor.world.rot.y > 0) && (this->actor.world.rot.y < 0x41) &&
        Flags_GetSwitch(play, this->actor.world.rot.y - 1)) {
        LOG_STRING_T("共倒れ", "Mutual destruction", "../z_elf_msg2.c", 171);
        if (PARAMS_GET_U(this->actor.params, 8, 6) != 0x3F) {
            Flags_SetSwitch(play, PARAMS_GET_U(this->actor.params, 8, 6));
        }
        Actor_Kill(&this->actor);
        return 1;
    } else if ((this->actor.world.rot.y == -1) && Flags_GetClear(play, this->actor.room)) {
        LOG_STRING_T("共倒れ２", "Mutual destruction 2", "../z_elf_msg2.c", 182);
        if (PARAMS_GET_U(this->actor.params, 8, 6) != 0x3F) {
            Flags_SetSwitch(play, PARAMS_GET_U(this->actor.params, 8, 6));
        }
        Actor_Kill(&this->actor);
        return 1;
    } else if (PARAMS_GET_U(this->actor.params, 8, 6) == 0x3F) {
        return 0;
    } else if (Flags_GetSwitch(play, PARAMS_GET_U(this->actor.params, 8, 6))) {
        LOG_STRING_T("共倒れ", "Mutual destruction", "../z_elf_msg2.c", 192);
        Actor_Kill(&this->actor);
        return 1;
    }
    return 0;
}

/* Dedicated mode only. All ordinary Elf_Msg2 objects keep their native actions. */
extern Gfx gWallaceDL[];
static ColliderCylinderInit sWallaceCylinderInit = {
    { COL_MATERIAL_NONE, AT_NONE, AC_NONE, OC1_ON | OC1_TYPE_ALL, OC2_TYPE_1, COLSHAPE_CYLINDER },
    { ELEM_MATERIAL_UNK0,
      { 0, HIT_SPECIAL_EFFECT_NONE, 0 }, { 0, HIT_BACKLASH_NONE, 0 },
      ATELEM_NONE, ACELEM_NONE, OCELEM_ON },
    { 16, 82, 0, { 0, 0, 0 } },
};

static s32 ElfMsg2_IsWallace(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_DODONGOS_CAVERN && actor->room == 2 && actor->params == 0x3F9A;
}

static void ElfMsg2_DrawWallace(Actor* actor, PlayState* play) {
    static Vec3f pivots[4] = { {0,0,0}, {0,6851,-275}, {918,6186,-574}, {-918,6186,-574} };
    void* roomSegment = NULL;
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 520));
    f32 gesture = Math_SinS((s16)(play->gameplayFrames * 970));
    if (play->roomCtx.curRoom.num == actor->room) roomSegment = play->roomCtx.curRoom.segment;
    else if (play->roomCtx.prevRoom.num == actor->room) roomSegment = play->roomCtx.prevRoom.segment;
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "wallace", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateX(idle * 0.025f, MTXMODE_APPLY);
        else if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.025f : -0.025f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(gesture * 0.06f, MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i], "wallace", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gWallaceDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "wallace", 3);
}

static void ElfMsg2_InitWallace(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    /* Initialization precedes removal, so the destroy path is valid for adults too. */
    if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x019A;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 22);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    Actor_SetFocus(actor, 75);
    actor->draw = ElfMsg2_DrawWallace;
}

static void ElfMsg2_UpdateWallace(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 75);
    actor->textId = 0x019A;
    if (!Actor_TalkOfferAccepted(actor, play)) {
        if (actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
            Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
            Actor_OfferTalk(actor, play, 115.0f);
        }
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Private Water Temple modes. Assets live in the native room segment, not object slots. */
extern Gfx gPepsimanDL[];
extern Gfx gPepsiCanRoom7DL[];
extern Gfx gPepsiCanRoom9DL[];
extern Gfx gPepsiCanRoom16DL[];
extern Gfx gPepsiCrushedRoom16DL[];
extern Gfx gPepsiCanRoom17DL[];
extern Gfx gPepsiCanRoom19DL[];

static s32 ElfMsg2_IsPepsiman(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_WATER_TEMPLE && actor->room == 16 && actor->params == 0x3F72;
}
static s32 ElfMsg2_IsPepsiCan(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_WATER_TEMPLE &&
        (actor->params == 0x3F73 || actor->params == 0x3F74) &&
        (actor->room == 7 || actor->room == 9 || actor->room == 16 || actor->room == 17 || actor->room == 19);
}
static void* ElfMsg2_PepsiRoom(Actor* actor, PlayState* play) {
    if (play->roomCtx.curRoom.num == actor->room) return play->roomCtx.curRoom.segment;
    if (play->roomCtx.prevRoom.num == actor->room) return play->roomCtx.prevRoom.segment;
    return NULL;
}
static void ElfMsg2_DrawPepsiman(Actor* actor, PlayState* play) {
    static Vec3f pivots[4] = { {0,6313,0}, {0,8280,0}, {-1242,7918,-311}, {1242,7918,-311} };
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 430));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1100));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "pepsiman", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.035f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.025f : -0.025f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.07f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "pepsiman", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gPepsimanDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "pepsiman", 3);
}
static void ElfMsg2_DrawPepsiCan(Actor* actor, PlayState* play) {
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Gfx* dl = NULL;
    if (roomSegment == NULL) return;
    switch (actor->room) {
        case 7: dl = gPepsiCanRoom7DL; break;
        case 9: dl = gPepsiCanRoom9DL; break;
        case 16: dl = actor->params == 0x3F74 ? gPepsiCrushedRoom16DL : gPepsiCanRoom16DL; break;
        case 17: dl = gPepsiCanRoom17DL; break;
        case 19: dl = gPepsiCanRoom19DL; break;
    }
    if (dl == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "pepsi-can", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "pepsi-can", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, dl);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "pepsi-can", 3);
}
static void ElfMsg2_InitPepsiman(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x3072;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 17);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 14;
    this->wallaceCollider.dim.height = 94;
    Actor_SetFocus(actor, 82);
    actor->draw = ElfMsg2_DrawPepsiman;
}
static void ElfMsg2_UpdatePepsiman(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 82);
    actor->textId = 0x3072;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 115.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Two isolated Forest Temple NPC rooms; never a connected room pair. */
extern Gfx gFanboyDL[];
extern Gfx gChumChumDL[];
extern Gfx gCrockerDL[];
static s32 ElfMsg2_IsSuperhero(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_FOREST_TEMPLE &&
        ((actor->room == 3 && actor->params == 0x3F75) || (actor->room == 5 && actor->params == 0x3F76))) ||
        (play->sceneId == SCENE_SHADOW_TEMPLE && actor->room == 12 && actor->params == 0x3F77);
}
static void ElfMsg2_DrawSuperhero(Actor* actor, PlayState* play) {
    static Vec3f fanboyPivots[4] = { {0,47,0}, {0,5039,0}, {-947,4121,0}, {947,4121,0} };
    static Vec3f chumPivots[4] = { {0,-6,0}, {0,2858,0}, {-1403,2332,0}, {1403,2332,0} };
    static Vec3f crockerPivots[4] = { {0,35,0}, {0,7058,0}, {-850,6651,0}, {850,6651,0} };
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Vec3f* pivots = crocker ? crockerPivots : fanboy ? fanboyPivots : chumPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (fanboy ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "superhelden", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "superhelden", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, crocker ? gCrockerDL : fanboy ? gFanboyDL : gChumChumDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "superhelden", 3);
}
static void ElfMsg2_InitSuperhero(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = crocker ? 0x6089 : fanboy ? 0x6087 : 0x6088;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, crocker ? 16 : fanboy ? 15 : 18);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = crocker ? 13 : fanboy ? 13 : 18;
    this->wallaceCollider.dim.height = crocker ? 86 : fanboy ? 76 : 47;
    Actor_SetFocus(actor, crocker ? 75 : fanboy ? 66 : 40);
    actor->draw = ElfMsg2_DrawSuperhero;
}
static void ElfMsg2_UpdateSuperhero(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 fanboy = actor->params == 0x3F75;
    s32 crocker = actor->params == 0x3F77;
    Actor_SetFocus(actor, crocker ? 75 : fanboy ? 66 : 40);
    actor->textId = crocker ? 0x6089 : fanboy ? 0x6087 : 0x6088;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

#include "player.h"
/* Room-local flavor: no boss changes, collision, object slots, save flags or forced text. */
extern Gfx gTriangleGuyDL[];
extern Gfx gPregtestDL[];
extern Gfx gFlatSquidDL[];
static s32 ElfMsg2_IsTriangleGuy(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_GANON_BOSS && actor->room == 0 && actor->params == 0x3F78;
}
static s32 ElfMsg2_IsFundstueck(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_BOTTOM_OF_THE_WELL && actor->room == 6 && actor->params == 0x3F79) ||
           (play->sceneId == SCENE_WATER_TEMPLE_BOSS && actor->room == 1 && actor->params == 0x3F7A);
}
static void ElfMsg2_DrawFundstueck(Actor* actor, PlayState* play) {
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Gfx* dl = actor->params == 0x3F78 ? gTriangleGuyDL : actor->params == 0x3F79 ? gPregtestDL : gFlatSquidDL;
    if (roomSegment == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "fundstuecke", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "fundstuecke", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, dl);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "fundstuecke", 3);
}
static void ElfMsg2_InitTriangleGuy(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_0;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x608A;
    Actor_SetScale(actor, 0.01f);
    Actor_SetFocus(actor, 65);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 17);
    actor->draw = ElfMsg2_DrawFundstueck;
}
static void ElfMsg2_UpdateTriangleGuy(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 65);
    if (Actor_TalkOfferAccepted(actor, play) ||
        (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)) return;
    /* Native talking freezes bosses. Offer only in free play, never during a boss cinematic. */
    if (play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play)) {
        actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED;
        if (Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
            actor->xzDistToPlayer < 105.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
            Actor_OfferTalk(actor, play, 100.0f);
        }
    } else {
        actor->flags &= ~ACTOR_FLAG_ATTENTION_ENABLED;
    }
}

/* Separate adult-only rooms; preserve all native guards, capture and escape logic. */
extern Gfx gWawarioDL[];
extern Gfx gWawaluigiDL[];
static s32 ElfMsg2_IsWawarioBros(Actor* actor, PlayState* play) {
    return actor->room == 0 &&
        ((play->sceneId == SCENE_GERUDOS_FORTRESS && actor->params == 0x3F7B) ||
         (play->sceneId == SCENE_GERUDO_VALLEY && actor->params == 0x3F7C));
}
static void ElfMsg2_DrawWawarioBros(Actor* actor, PlayState* play) {
    static Vec3f wawarioPivots[4] = { {0,0,0}, {0,7317,0}, {1463,6585,0}, {-1463,6585,0} };
    static Vec3f wawaluigiPivots[4] = { {0,0,0}, {0,7788,0}, {986,6901,0}, {-986,6901,0} };
    s32 orange = actor->params == 0x3F7B;
    Vec3f* pivots = orange ? wawarioPivots : wawaluigiPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (orange ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "wawario", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "wawario", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, orange ? gWawarioDL : gWawaluigiDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "wawario", 3);
}
static void ElfMsg2_InitWawarioBros(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 orange = actor->params == 0x3F7B;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = orange ? 0x608D : 0x608E;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 14);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 14;
    this->wallaceCollider.dim.height = orange ? 65 : 80;
    Actor_SetFocus(actor, orange ? 65 : 80);
    actor->draw = ElfMsg2_DrawWawarioBros;
}
static void ElfMsg2_UpdateWawarioBros(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 orange = actor->params == 0x3F7B;
    Actor_SetFocus(actor, orange ? 65 : 80);
    actor->textId = orange ? 0x608D : 0x608E;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

/* Each supplied character is restricted to its own scene, room, marker and era. */
extern Gfx gYellowGuyDL[];
extern Gfx gPunkYellowDL[];
extern Gfx gWarioDL[];
static s32 ElfMsg2_IsYellowCast(Actor* actor, PlayState* play) {
    return actor->room == 0 &&
        ((play->sceneId == SCENE_HYRULE_CASTLE && actor->params == 0x3F7D) ||
         (play->sceneId == SCENE_OUTSIDE_GANONS_CASTLE && actor->params == 0x3F7E) ||
         (play->sceneId == SCENE_KAKARIKO_VILLAGE && actor->params == 0x3F7F));
}
static void ElfMsg2_DrawYellowCast(Actor* actor, PlayState* play) {
    static Vec3f yellowPivots[4] = { {0,0,0}, {0,4580,0}, {-975,4265,-375}, {975,4265,-375} };
    static Vec3f punkPivots[4] = { {0,0,0}, {0,4768,0}, {-842,4207,0}, {842,4207,0} };
    static Vec3f warioPivots[4] = { {0,0,0}, {0,4775,0}, {-2029,4083,0}, {2029,4083,0} };
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Vec3f* pivots = normal ? yellowPivots : wario ? warioPivots : punkPivots;
    void* roomSegment = ElfMsg2_PepsiRoom(actor, play);
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (normal ? 590 : 700)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 1250));
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "yellowcast", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
        if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.03f : -0.03f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.075f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "yellowcast", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, normal ? gYellowGuyDL : wario ? gWarioDL : gPunkYellowDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "yellowcast", 3);
}
static void ElfMsg2_InitYellowCast(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if ((LINK_IS_CHILD ? actor->params == 0x3F7E : actor->params != 0x3F7E) || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = normal ? 0x608F : wario ? 0x601C : 0x6073;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, wario ? 19 : 14);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = wario ? 22 : 13;
    this->wallaceCollider.dim.height = normal ? 55 : wario ? 65 : 59;
    Actor_SetFocus(actor, normal ? 55 : wario ? 65 : 59);
    actor->draw = ElfMsg2_DrawYellowCast;
}
static void ElfMsg2_UpdateYellowCast(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 normal = actor->params == 0x3F7D;
    s32 wario = actor->params == 0x3F7F;
    Actor_SetFocus(actor, normal ? 55 : wario ? 65 : 59);
    actor->textId = normal ? 0x608F : wario ? 0x601C : 0x6073;
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight;
    if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE && !Player_InCsMode(play) &&
        Message_GetState(&play->msgCtx) == TEXT_STATE_NONE && actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
        Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
        Actor_OfferTalk(actor, play, 105.0f);
    }
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

void ElfMsg2_Init(Actor* thisx, PlayState* play) {
    ElfMsg2* this = (ElfMsg2*)thisx;

    if (ElfMsg2_IsTriangleGuy(thisx, play)) {
        ElfMsg2_InitTriangleGuy(this, play);
        return;
    }
    if (ElfMsg2_IsYellowCast(thisx, play)) {
        ElfMsg2_InitYellowCast(this, play);
        return;
    }
    if (ElfMsg2_IsWawarioBros(thisx, play)) {
        ElfMsg2_InitWawarioBros(this, play);
        return;
    }
    if (ElfMsg2_IsSuperhero(thisx, play)) {
        ElfMsg2_InitSuperhero(this, play);
        return;
    }
    if (ElfMsg2_IsPepsiman(thisx, play)) {
        ElfMsg2_InitPepsiman(this, play);
        return;
    }

    if (ElfMsg2_IsWallace(thisx, play)) {
        ElfMsg2_InitWallace(this, play);
        return;
    }

    PRINTF(VT_FGCOL(CYAN) " Elf_Msg2_Actor_ct %04x\n\n" VT_RST, this->actor.params);
    if (!ElfMsg2_KillCheck(this, play)) {
        if ((this->actor.world.rot.x > 0) && (this->actor.world.rot.x < 8)) {
            this->actor.attentionRangeType = this->actor.world.rot.x - 1;
        }
        Actor_ProcessInitChain(thisx, sInitChain);
        if (this->actor.world.rot.y >= 0x41) {
            ElfMsg2_SetupAction(this, ElfMsg2_WaitUntilActivated);
        } else {
            ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
            this->actor.flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_TALK_WITH_C_UP;
            this->actor.textId = ElfMsg2_GetMessageId(this);
        }
        this->actor.shape.rot.x = this->actor.shape.rot.y = this->actor.shape.rot.z = 0;
        if (ElfMsg2_IsFundstueck(thisx, play)) {
            s32 test = thisx->params == 0x3F79;
            if (gSaveContext.language != LANGUAGE_GER || (test ? !LINK_IS_CHILD : LINK_IS_CHILD)) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, test ? 2.0f : 5.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = test ? 0x608B : 0x608C;
            thisx->draw = ElfMsg2_DrawFundstueck;
        }
        if (ElfMsg2_IsPepsiCan(thisx, play)) {
            if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 4.0f);
            thisx->shape.rot.y = (s16)(thisx->home.pos.x * 71.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = 0x3073;
            thisx->draw = ElfMsg2_DrawPepsiCan;
        }
        /* Room 21 is a later west-side corridor, below the twisted hallway. */
        if (play->sceneId == SCENE_FOREST_TEMPLE && thisx->room == 21 && thisx->params == 0x3F09) {
            if (gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 5.0f);
            thisx->draw = ElfMsg2_DrawMajoraMask;
        }
        /* One German decoration; all other check spots retain their native setup. */
        if (play->sceneId == SCENE_JABU_JABU && thisx->room == 3 && thisx->params == 0x3F25) {
            if (gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 3.0f);
            thisx->draw = ElfMsg2_DrawNintendo64;
        }
    }
}

void ElfMsg2_Destroy(Actor* thisx, PlayState* play) {
    if (ElfMsg2_IsWallace(thisx, play) || ElfMsg2_IsPepsiman(thisx, play) || ElfMsg2_IsSuperhero(thisx, play) || ElfMsg2_IsWawarioBros(thisx, play) || ElfMsg2_IsYellowCast(thisx, play)) {
        Collider_DestroyCylinder(play, &((ElfMsg2*)thisx)->wallaceCollider);
    }
}

s32 ElfMsg2_GetMessageId(ElfMsg2* this) {
    return PARAMS_GET_U(this->actor.params, 0, 8) + 0x100;
}

/**
 * Runs while Navi text is up. Kills the actor upon closing the text box unless rot.z == 1, can also set a switch flag
 * from params.
 */
void ElfMsg2_WaitForTextClose(ElfMsg2* this, PlayState* play) {
    s32 switchFlag;

    if (Actor_TextboxIsClosing(&this->actor, play)) {
        if (this->actor.world.rot.z != 1) {
            Actor_Kill(&this->actor);
            switchFlag = PARAMS_GET_U(this->actor.params, 8, 6);
            if (switchFlag != 0x3F) {
                Flags_SetSwitch(play, switchFlag);
            }
        } else {
            ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
        }
    }
}

/**
 * Runs while Navi text is not up.
 */
void ElfMsg2_WaitForTextRead(ElfMsg2* this, PlayState* play) {
    if (Actor_TalkOfferAccepted(&this->actor, play)) {
        ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextClose);
    }
}

/**
 * Idles until a switch flag is set, at which point the actor becomes interactable
 */
void ElfMsg2_WaitUntilActivated(ElfMsg2* this, PlayState* play) {
    // If (y >= 0x41) && (y <= 0x80), Idles until switch flag (actor.world.rot.y - 0x41) is set
    // If (y > 0x80), Idles forever (Bug?)
    if ((this->actor.world.rot.y >= 0x41) && (this->actor.world.rot.y <= 0x80) &&
        (Flags_GetSwitch(play, (this->actor.world.rot.y - 0x41)))) {
        ElfMsg2_SetupAction(this, ElfMsg2_WaitForTextRead);
        this->actor.flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_TALK_WITH_C_UP;
        this->actor.textId = ElfMsg2_GetMessageId(this);
    }
}

void ElfMsg2_Update(Actor* thisx, PlayState* play) {
    ElfMsg2* this = (ElfMsg2*)thisx;
    if (ElfMsg2_IsTriangleGuy(thisx, play)) {
        ElfMsg2_UpdateTriangleGuy(this, play);
        return;
    }
    if (ElfMsg2_IsYellowCast(thisx, play)) {
        ElfMsg2_UpdateYellowCast(this, play);
        return;
    }
    if (ElfMsg2_IsWawarioBros(thisx, play)) {
        ElfMsg2_UpdateWawarioBros(this, play);
        return;
    }
    if (ElfMsg2_IsSuperhero(thisx, play)) {
        ElfMsg2_UpdateSuperhero(this, play);
        return;
    }
    if (ElfMsg2_IsPepsiman(thisx, play)) {
        ElfMsg2_UpdatePepsiman(this, play);
        return;
    }
    if (ElfMsg2_IsWallace(thisx, play)) {
        ElfMsg2_UpdateWallace(this, play);
        return;
    }


    if (!ElfMsg2_KillCheck(this, play)) {
        this->actionFunc(this, play);
    }
}

#if DEBUG_ASSETS

static Gfx sMaterialDL[8] = {
#include "assets/overlays/ovl_Elf_Msg2/sMaterialDL.inc.c"
};

static Vtx sCubeVtx[] = {
#include "assets/overlays/ovl_Elf_Msg2/sCubeVtx.inc.c"
};

static Gfx sCubeDL[8] = {
#include "assets/overlays/ovl_Elf_Msg2/sCubeDL.inc.c"
};

void ElfMsg2_Draw(Actor* thisx, PlayState* play) {
    OPEN_DISPS(play->state.gfxCtx, "../z_elf_msg2.c", 355);

    if (R_NAVI_MSG_REGION_ALPHA == 0) {
        return;
    }

    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    gDPSetPrimColor(POLY_XLU_DISP++, 0, 0, 100, 100, 255, R_NAVI_MSG_REGION_ALPHA);
    MATRIX_FINALIZE_AND_LOAD(POLY_XLU_DISP++, play->state.gfxCtx, "../z_elf_msg2.c", 362);
    gSPDisplayList(POLY_XLU_DISP++, sMaterialDL);
    gSPDisplayList(POLY_XLU_DISP++, sCubeDL);

    CLOSE_DISPS(play->state.gfxCtx, "../z_elf_msg2.c", 367);
}
#endif

/* Rendering only: targeting, C-Up, closing and repeat behavior are all native Elf_Msg2. */
static void ElfMsg2_DrawNintendo64(Actor* thisx, PlayState* play) {
    void* roomSegment = NULL;
    if (play->roomCtx.curRoom.num == thisx->room) {
        roomSegment = play->roomCtx.curRoom.segment;
    } else if (play->roomCtx.prevRoom.num == thisx->room) {
        roomSegment = play->roomCtx.prevRoom.segment;
    }
    if (roomSegment == NULL) {
        return;
    }
    OPEN_DISPS(play->state.gfxCtx, "nintendo64", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "nintendo64", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, gNintendo64DL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "nintendo64", 3);
}

static void ElfMsg2_DrawMajoraMask(Actor* thisx, PlayState* play) {
    void* roomSegment = NULL;
    if (play->roomCtx.curRoom.num == thisx->room) {
        roomSegment = play->roomCtx.curRoom.segment;
    } else if (play->roomCtx.prevRoom.num == thisx->room) {
        roomSegment = play->roomCtx.prevRoom.segment;
    }
    if (roomSegment == NULL) {
        return;
    }
    OPEN_DISPS(play->state.gfxCtx, "majoras-mask", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "majoras-mask", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, gMajoraMaskDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "majoras-mask", 3);
}

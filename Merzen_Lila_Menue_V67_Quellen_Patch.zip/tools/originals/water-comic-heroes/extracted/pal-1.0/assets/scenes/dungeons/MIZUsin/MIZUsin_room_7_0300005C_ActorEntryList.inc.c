    {
        ACTOR_ELF_MSG2,
        {  -3120,   1067,  -4219 }, // pos
        {  0x0000,  0x000D,  0x0001 }, // rot
         0x3F05, // params
    }, // 0
    {
        ACTOR_EN_BOX,
        {  -3120,   1080,  -4020 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x0127, // params
    }, // 1
    {
        ACTOR_OBJ_TIMEBLOCK,
        {  -3121,    962,  -4220 }, // pos
        {  0x0000,  0x0000,  0x0001 }, // rot
        -0x47F4 /* 0xB80C */, // params
    }, // 2

    { ACTOR_ELF_MSG2, { -3330, 1060, -4050 }, { 2, 0, 1 }, 0x3F73 }, /* optional Pepsi can */

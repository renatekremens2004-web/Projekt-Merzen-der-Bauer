import bpy,bmesh,json,sys
from pathlib import Path
from mathutils import Matrix
W=Path(sys.argv[sys.argv.index('--')+1]);bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(W/'input/source/jabba.glb'));bpy.ops.wm.save_as_mainfile(filepath=str(W/'import.blend'));o=next(o for o in bpy.context.scene.objects if o.type=='MESH'and len(o.data.vertices)>10000);bpy.context.view_layer.objects.active=o;bpy.ops.object.select_all(action='DESELECT');o.select_set(True)
o.data.transform(o.matrix_world);o.matrix_world=Matrix.Identity(4)
# Dense source UV seams must not dictate the low-poly silhouette. Rebuild a
# closed evenly sampled surface; original diffuse colors are baked separately.
o.data.remesh_voxel_size=.04;o.data.remesh_voxel_adaptivity=0.;bpy.ops.object.voxel_remesh();o.data.calc_loop_triangles();before=len(o.data.loop_triangles)
# Keep the overall triangle budget, but spend it on the eyes, nose, lips and
# jowls instead of evenly sampling the broad belly and tail. Smoothly varying
# weights avoid introducing a hard ring or a seam around the face.
group=o.vertex_groups.new(name='Face priority')
for v in o.data.vertices:
 x,y,z=v.co
 height=max(0.,min(1.,(z-4.9)/.8));front=max(0.,min(1.,(y+.2)/.8))
 side=max(0.,min(1.,(2.1-abs(x-.25))/.7))
 group.add([v.index],1.-.98*height*front*side,'REPLACE')
mod=o.modifiers.new('Face-first N64 budget','DECIMATE');mod.ratio=2100/before;mod.vertex_group=group.name;mod.vertex_group_factor=12.;bpy.ops.object.modifier_apply(modifier=mod.name)
for p in o.data.polygons:p.use_smooth=True
o.data.calc_loop_triangles();face_count=sum(1 for t in o.data.loop_triangles if sum(o.data.vertices[v].co.z for v in t.vertices)/3>5.1 and sum(o.data.vertices[v].co.y for v in t.vertices)/3>.35)
assert len(o.data.loop_triangles)<=2200 and face_count>=1000, 'Face detail or total N64 budget violated'
report=[dict(object=o.name,original=491546,voxel_triangles=before,after=len(o.data.loop_triangles),face_triangles=face_count,voxel_size=.04,face_weight_factor=12.)]
for eye in list(bpy.context.scene.objects):
 if eye.type!='MESH'or eye==o:continue
 bpy.context.view_layer.objects.active=eye;eye.select_set(True);eye.data.transform(eye.matrix_world);eye.matrix_world=Matrix.Identity(4);eye.data.calc_loop_triangles();mod=eye.modifiers.new('Eye silhouette','DECIMATE');mod.ratio=.1;bpy.ops.object.modifier_apply(modifier=mod.name);eye.data.calc_loop_triangles();report.append(dict(object=eye.name,after=len(eye.data.loop_triangles)))
(W/'reduction.json').write_text(json.dumps(report,indent=2)+'\n');bpy.ops.wm.save_as_mainfile(filepath=str(W/'reduced.blend'));print(report)

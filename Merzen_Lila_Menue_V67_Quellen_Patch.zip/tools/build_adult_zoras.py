"""Adult Zora reunion and King Zora aftermath. Preserve native rewards and trade priority."""
from pathlib import Path
import sys,re
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/adult_zoras'
def original(p):
 q=B/p.relative_to(O);q.parent.mkdir(parents=True,exist_ok=True)
 if not q.exists():q.write_bytes(p.read_bytes())
 return q.read_text()
# A marked adult instance of the same native type-6 Zora; childhood remains unchanged.
p=O/'src/overlays/actors/ovl_En_Zo/z_en_zo.c';s=original(p)
needle='''    u16 textId = MaskReaction_GetTextId(play, MASK_REACTION_SET_ZORA);''';assert s.count(needle)==1
s=s.replace(needle,needle+'''

    if (gSaveContext.language == LANGUAGE_GER && LINK_IS_ADULT &&
        play->sceneId == SCENE_ZORAS_DOMAIN && thisx->params == 0x7FC6) {
        return 0x209F;
    }''')
needle='''                case 0x4020:
                case 0x4021:''';assert s.count(needle)==1;s=s.replace(needle,'''                case 0x209F:
'''+needle)
needle='''void EnZo_Init(Actor* thisx, PlayState* play) {
    EnZo* this = (EnZo*)thisx;
''';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    if (thisx->params == 0x7FC6 &&
        (gSaveContext.language != LANGUAGE_GER || !LINK_IS_ADULT || play->sceneId != SCENE_ZORAS_DOMAIN)) {
        Actor_Kill(thisx);
        return;
    }
''');p.write_text(s)
# Native native post-talk flag gates the extra lines, so neither the tunic nor
# the prescription exchange can be swallowed by the new water-medallion branch.
p=O/'src/overlays/actors/ovl_En_Kz/z_en_kz.c';s=original(p)
helper='''static u16 EnKz_GetAfterTalkTextId(void) {
    if (gSaveContext.language == LANGUAGE_GER) {
        return CHECK_QUEST_ITEM(QUEST_MEDALLION_WATER) ? 0x4044 : 0x4045;
    }
    return CHECK_QUEST_ITEM(QUEST_SONG_SERENADE) ? 0x4045 : 0x401A;
}

'''
needle='u16 EnKz_GetTextIdAdult(PlayState* play, EnKz* this) {';assert s.count(needle)==1;s=s.replace(needle,helper+needle)
needle='''u16 EnKz_GetTextIdAdult(PlayState* play, EnKz* this) {
    Player* player = GET_PLAYER(play);
''';assert s.count(needle)==1
s=s.replace(needle,needle+'''
    if (gSaveContext.language == LANGUAGE_GER && GET_INFTABLE(INFTABLE_139)) {
        player->exchangeItemId = EXCH_ITEM_PRESCRIPTION;
        return EnKz_GetAfterTalkTextId();
    }
''')
needle='this->actor.textId = CHECK_QUEST_ITEM(QUEST_SONG_SERENADE) ? 0x4045 : 0x401A;';assert s.count(needle)==1;s=s.replace(needle,'this->actor.textId = EnKz_GetAfterTalkTextId();');p.write_text(s)
# Only adult regular room-1 setup (day and night share this header). Preserve
# every native entry and place her at the original dry standing-Zora ledge.
A=O/'extracted/pal-1.0/assets/scenes/overworld/spot07';base='spot07_room_1_03000048_AltHeaders_03000360_Cmds'
p=A/(base+'_030003B0_ActorEntryList.inc.c');s=original(p)
assert s.count('ACTOR_EN_ZO')==0
s+='''    {
        ACTOR_EN_ZO,
        {   -786,     14,   -486 },
        {  0x0000, -0x00B6,  0x0000 },
         0x7FC6,
    }, // adult reunion: type-6 Zora from Lake Hylia
''';p.write_text(s)
p=A/(base+'_030003A0_ObjectList.inc.c');s=original(p);assert 'OBJECT_ZO'not in s;p.write_text(s+'    OBJECT_ZO, // adult reunion\n')
p=A/'spot07_room_1.h';s=original(p)
for name in [base+'_030003B0_ActorEntryList',base+'_030003A0_ObjectList']:
 pattern=r'(#define LENGTH_'+name+r' )(\d+)'
 s,n=re.subn(pattern,lambda m:m[1]+str(int(m[2])+1),s);assert n==1
p.write_text(s)
print('Adult Zora reunion: one native actor/object entry; King reward/trade priority retained.')
# Soft sky blue on the worn Zora tunic; unchanged equipment IDs and hazard logic.
p=O/'src/code/z_player_lib.c';s=original(p)
needle='{ 0, 60, 100 },  // PLAYER_TUNIC_ZORA';assert s.count(needle)==1
p.write_text(s.replace(needle,'{ 110, 195, 240 }, // PLAYER_TUNIC_ZORA: sky blue'))

"""Final actor-only age selector after story generation and previous character builders."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();rel=Path('src/overlays/actors/ovl_En_Js/z_en_js.c');p=O/rel;b=R/'tools/originals/gerudo-dialogue'/rel;b.parent.mkdir(parents=True,exist_ok=True)
if not b.exists():b.write_bytes(p.read_bytes())
source=b.read_text();old='        this->actor.textId = textId;';new='''        /* Only the opening offer differs by age. Prices, choices and item flow stay native. */
        this->actor.textId = (gSaveContext.language == LANGUAGE_GER && LINK_IS_CHILD && textId == 0x6077)
                                 ? 0x71C6 : textId;''';assert source.count(old)==1;source=source.replace(old,new)
if p.read_text()!=source:p.write_text(source)
print('Child carpet offer 71C6; adult/default-language offer and all shop mechanics unchanged.')

# Earlier room builders restore their published message snapshot. Reapply this
# revision last, so a clean cumulative rebuild retains these new conversations.
import json
from build_story import messages,Layout,rewrite,add_private_message,plain
entries={}
for chapter in(R/'story').glob('*.json'):
 for ident,entry in json.loads(chapter.read_text())['messages'].items():entries[ident]=entry
ids=json.loads((R/'tools/intro_gerudo_ids.json').read_text());target=O/'extracted/pal-1.0/text/message_data.h';source=target.read_text()
for ident in ids:
 if entries[ident].get('new_message'):source=add_private_message(source,ident,entries[ident])
parsed=messages(source);layout=Layout(O);replacements=[]
for ident in ids:
 entry=entries[ident];a,b,body=parsed[ident]['parts'][2]
 if 'native_template'in entry and plain(body).strip().upper()==ident:body=parsed[entry['native_template']]['parts'][2][2]
 new,_=rewrite(body,entry,layout,ident);replacements.append((a,b,new))
for a,b,new in sorted(replacements,reverse=True):source=source[:a]+new+source[b:]
if source!=target.read_text():target.write_text(source)
print('Refreshed',len(ids),'opening/Gerudo messages from canonical story JSON.')

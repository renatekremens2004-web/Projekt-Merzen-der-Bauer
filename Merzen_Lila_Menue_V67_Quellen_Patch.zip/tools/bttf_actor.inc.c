/* Time travellers: child castle and their first meeting with adult Link in the desert. */
extern Gfx gMartyDL[];
extern Gfx gDocDL[];
extern Gfx gDeloreanDL[];
static s32 ElfMsg2_IsBttf(Actor* actor, PlayState* play) {
    return (play->sceneId == SCENE_HYRULE_CASTLE || play->sceneId == SCENE_DESERT_COLOSSUS) && actor->room == 0 &&
        actor->params >= 0x3F82 && actor->params <= 0x3F84;
}
static void ElfMsg2_DrawBttf(Actor* actor, PlayState* play) {
    static Vec3f martyPivots[4] = { MARTY_PIVOTS };
    static Vec3f docPivots[4] = { DOC_PIVOTS };
    s32 car = actor->params == 0x3F84;
    s32 doc = actor->params == 0x3F83;
    s32 slot = Object_GetSlot(&play->objectCtx, OBJECT_BTTF);
    Vec3f* pivots = doc ? docPivots : martyPivots;
    Mtx* matrices;
    s32 i;
    u16 first = play->sceneId == SCENE_DESERT_COLOSSUS ? 0x71BF : 0x71B4;
    s32 conversation = play->msgCtx.textId >= first && play->msgCtx.textId <= first + 3 &&
        Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    s32 speaking = conversation && ((play->msgCtx.textId - first) & 1) == doc;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * (doc ? 340 : 410) + (doc ? 12000 : 0)));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * (doc ? 850 : 1050)));
    f32 gesture = Math_SinS((s16)(play->gameplayFrames * (doc ? 510 : 640) + 7000));
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, (car ? 1 : 4) * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "bttf", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < (car ? 1 : 4); i++) {
        Matrix_Push();
        if (!car) Matrix_RotateZ(idle * 0.004f, MTXMODE_APPLY);
        if (!car) {
            Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
            if (i == 1) {
                Matrix_RotateY(idle * 0.025f, MTXMODE_APPLY);
                if (speaking) Matrix_RotateX(talk * 0.026f, MTXMODE_APPLY);
            }
            if (i >= 2) {
                Matrix_RotateZ((i == 2 ? 1 : -1) * (idle * 0.012f +
                    (speaking ? gesture * (doc ? 0.065f : 0.045f) : 0)), MTXMODE_APPLY);
                if (speaking) Matrix_RotateX(talk * (i == 2 ? 0.022f : -0.015f), MTXMODE_APPLY);
            }
            Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i], "bttf", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, car ? gDeloreanDL : doc ? gDocDL : gMartyDL);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "bttf", 3);
}
static void ElfMsg2_InitBttf(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 car = actor->params == 0x3F84;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if ((play->sceneId == SCENE_DESERT_COLOSSUS ? LINK_IS_CHILD : LINK_IS_ADULT) || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, car ? ACTORCAT_PROP : ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    if (!car) actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = car ? 0 : play->sceneId == SCENE_DESERT_COLOSSUS ? 0x71BF : 0x71B4;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1800.0f;
    actor->cullingVolumeScale = car ? 240.0f : 130.0f;
    actor->cullingVolumeDownward = 120.0f;
    Actor_SetScale(actor, 0.0085f);
    ActorShape_Init(&actor->shape, 0, car ? NULL : ActorShadow_DrawCircle, 14);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = car ? 37 : 14;
    this->wallaceCollider.dim.height = car ? 40 : actor->params == 0x3F83 ? 77 : 70;
    Actor_SetFocus(actor, actor->params == 0x3F83 ? 72 : 65);
    actor->draw = ElfMsg2_DrawBttf;
}
static void ElfMsg2_UpdateBttf(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    s32 car = actor->params == 0x3F84;
    u16 first = play->sceneId == SCENE_DESERT_COLOSSUS ? 0x71BF : 0x71B4;
    /* These three instances never move and the meadow has static collision.
     * Resolve their floor once instead of three full raycasts every frame. */
    if (actor->floorPoly == NULL) {
        Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
        if (actor->floorHeight > BGCHECK_Y_MIN + 1.0f) actor->world.pos.y = actor->floorHeight + (car ? 1.0f : 0.0f);
    }
    if (!car) {
        Actor_SetFocus(actor, actor->params == 0x3F83 ? 72 : 65);
        actor->textId = first;
        Math_SmoothStepToS(&actor->shape.rot.y,
            play->msgCtx.textId >= first && play->msgCtx.textId <= first + 3 &&
            Message_GetState(&play->msgCtx) != TEXT_STATE_NONE && actor->xzDistToPlayer < 350 ?
            actor->yawTowardsPlayer : actor->home.rot.y, 6, 0x280, 1);
        if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) == TEXT_STATE_EVENT &&
            play->msgCtx.textId >= first && play->msgCtx.textId < first + 3 && Message_ShouldAdvance(play)) {
            Message_ContinueTextbox(play, play->msgCtx.textId + 1);
        } else if (!Actor_TalkOfferAccepted(actor, play) && play->csCtx.state == CS_STATE_IDLE &&
            !Player_InCsMode(play) && Message_GetState(&play->msgCtx) == TEXT_STATE_NONE &&
            actor->xzDistToPlayer < 140.0f && fabsf(actor->yDistToPlayer) < 65.0f) {
            Actor_OfferTalk(actor, play, 125.0f);
        }
    }
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

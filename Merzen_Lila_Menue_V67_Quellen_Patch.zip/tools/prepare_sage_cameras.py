"""Only eye/at coordinates change. Native camera timing, cues and text stay verbatim."""
from pathlib import Path
import re,json
R=Path(__file__).resolve().parent;O=Path(__import__('sys').argv[1]).resolve();edits=[]
point=re.compile(r'(CS_CAM_POINT\([^\n]*?CS_FLOAT\([^)]*\),\s*)(-?\d+),\s*(-?\d+),\s*(-?\d+)(,\s*0x[0-9A-Fa-f]+\),)')
def transform(s,anchor,starts,factor,dy,label):
 mode=None;start=None;lines=[]
 for line in s.splitlines(True):
  h=re.search(r'CS_CAM_(EYE|AT)_SPLINE\((\d+),',line)
  if h:mode=h[1];start=int(h[2])
  elif re.search(r'^\s*CS_\w+\(',line) and not re.search(r'CS_CAM_POINT\(',line):mode=None
  m=point.search(line)
  if m and mode and start in starts:
   x,y,z=map(int,m.group(2,3,4));pos=[round(anchor[0]+(x-anchor[0])*factor),y+dy,round(anchor[2]+(z-anchor[2])*factor)];new=m[1]+', '.join(map(str,pos))+m[5];after=line[:m.start()]+new+line[m.end():];edits.append({'script':label,'before':line.strip(),'after':after.strip()});line=after
  lines.append(line)
 return ''.join(lines)
ru=(O/'src/overlays/actors/ovl_En_Ru2/z_en_ru2_cutscene_data.inc.c').read_text();ru=transform(ru,(192,6,1),{263,383,453,553,623,693,763},1.7,28,'water');ru=ru.replace('gWaterMedallionCs','gSquidWaterMedallionCs')
nb=(O/'src/overlays/actors/ovl_En_Nb/z_en_nb_cutscene_data.inc.c').read_text();nb=transform(nb,(94,6,165),{263,363,433},1.6,28,'spirit');nb=nb.replace('gSpiritMedallionCs','gWaluigiSpiritMedallionCs')
(R/'sage_medallion_cameras.inc.c').write_text('/* Only framing adjusted to the new own-proportioned characters. */\n'+ru+'\n'+nb)
# Preserve the corrected Bowling Lady shoulder shot; change only the old Nabooru closeup.
p=R/'bowling_sage_cutscene_data.inc.c';base=R/'originals/water_spirit_sages/bowling_sage_cutscene_data.inc.c';base.parent.mkdir(parents=True,exist_ok=True)
if not base.exists():base.write_bytes(p.read_bytes())
s=(R/'sage_credits_camera_reference.inc.c').read_text();cut=s.index('static CutsceneData gBowlingCreditsCs');s=s[:cut]+transform(s[cut:],(14,3199,-3996),{246},1.8,20,'credits-waluigi');p.write_text(s)
# Native Iron Knuckle defeat closeups: lift and back up for the taller replacement.
p=O/'extracted/pal-1.0/assets/scenes/dungeons/jyasinboss/gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c'
base=R/'originals/water_spirit_sages'/p.relative_to(O);base.parent.mkdir(parents=True,exist_ok=True)
if not base.exists():base.write_bytes(p.read_bytes())
p.write_text(transform(base.read_text(),(-1515,0,1519),{65,85,140,222},2.2,38,'knuckle-defeat'))
# Only camera 3130 is used by the Water Temple encounter. All action/timing fields stay intact.
p=O/'src/code/z_onepointdemo.c';base=R/'originals/water_spirit_sages'/p.relative_to(O);base.parent.mkdir(parents=True,exist_ok=True)
if not base.exists():base.write_bytes(p.read_bytes())
s=base.read_text();a=s.index('        case 3130: {');b=s.index('        case 3140:',a);block=s[a:b]
for before,after in [
 ('{ 0.0f, 45.0f, 0.0f }','{ 0.0f, 80.0f, 0.0f }'),
 ('{ 0.0f, 45.0f, 50.0f }','{ 0.0f, 80.0f, 130.0f }'),
 ('{ 30.0f, 30.0f, 15.0f }','{ 30.0f, 60.0f, 15.0f }'),
 ('{ 70.0f, 30.0f, -40.0f }','{ 100.0f, 70.0f, -100.0f }'),
 ('{ 20.0f, 30.0f, -5.0f }','{ 20.0f, 65.0f, -5.0f }'),
 ('{ 0.0f, 70.0f, 70.0f }','{ 0.0f, 105.0f, 140.0f }'),
 ('{ 0.0f, 30.0f, 30.0f }','{ 0.0f, 65.0f, 30.0f }'),
 ('{ 25.0f, 60.0f, -60.0f }','{ 25.0f, 90.0f, -120.0f }'),
 ('{ 0.0f, 0.0f, 30.0f }','{ 0.0f, 30.0f, 30.0f }'),
 ('{ 0.0f, 60.0f, -60.0f }','{ 0.0f, 85.0f, -120.0f }')]:
 assert before in block
 edits.append({'script':'water-onepoint3130','before':before,'after':after,'count':block.count(before)})
 block=block.replace(before,after)
p.write_text(s[:a]+block+s[b:])
# The same two sages in the finale seal-opening montage.
p=O/'extracted/pal-1.0/assets/scenes/indoors/kenjyanoma/gChamberOfSagesSealOpeningCs.csdata.inc.c'
base=R/'originals/water_spirit_sages'/p.relative_to(O);base.parent.mkdir(parents=True,exist_ok=True)
if not base.exists():base.write_bytes(p.read_bytes())
s=transform(base.read_text(),(192,6,1),{95},1.7,30,'sealing-water')
s=transform(s,(94,6,165),{110},1.7,35,'sealing-spirit');p.write_text(s)
(R/'sage_camera_edits.json').write_text(json.dumps(edits,indent=2)+'\n');print('Camera points',len(edits),'native timings unchanged')

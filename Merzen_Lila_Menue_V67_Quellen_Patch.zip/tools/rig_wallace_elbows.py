"""Split existing forearm vertices into two rigid parts; geometry and textures stay unchanged."""
from pathlib import Path
import json
R=Path(__file__).resolve().parent

def rig():
 p=R/'wallace_adult_source.json';m=json.loads(p.read_text())
 if len(m['bones'])==12:
  assert m['elbow_rig']['version']==1;return m
 assert len(m['bones'])==10 and m['height_game_units']==90
 m['bones'] += [dict(name='left_forearm',parent=-1,position=[1220,4900,-220]),dict(name='right_forearm',parent=-1,position=[-1220,4900,-220])]
 counts={}
 for v in m['vertices']:
  if v['bone']in[2,3]and v['position'][1]<4900:v['bone']=10+(v['bone']-2)
  counts[v['bone']]=counts.get(v['bone'],0)+1
 m['pivots']=[b['position']for b in m['bones']];m['elbow_rig']=dict(version=1,additional_matrix_bytes=128,geometry_positions_normals_uvs_triangles_unchanged=True,vertices_by_group=counts)
 p.write_text(json.dumps(m,separators=(',',':'))+'\n');return m
if __name__=='__main__':print('Elbow rig:',rig()['elbow_rig'])

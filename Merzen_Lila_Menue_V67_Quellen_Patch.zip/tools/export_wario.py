"""Preserve the supplied 460-triangle N64 Wario; add only four small rigid pose groups."""
import bpy,json,sys,shutil
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);D=R/'models/wario';D.mkdir(parents=True,exist_ok=True)
src=W/'input/wario/nested/wario/wario.obj';bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.obj_import(filepath=str(src),forward_axis='NEGATIVE_Z',up_axis='Y');objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];bpy.ops.object.select_all(action='DESELECT')
for o in objects:o.select_set(True)
bpy.context.view_layer.objects.active=objects[0];bpy.ops.object.join();o=bpy.context.object;me=o.data;me.calc_loop_triangles();assert len(me.loop_triangles)==460
bottom=min(v.co.y for v in me.vertices);scale=8200/(max(v.co.y for v in me.vertices)-bottom);center=Vector((.452,0,.249));piv=[Vector((0,0,0)),Vector((0,9.8-bottom,0)),Vector((-4.1,8.4-bottom,0)),Vector((4.1,8.4-bottom,0))]
shutil.copyfile(src.parent/'imwario.png',D/'wario.png')
m={'bones':[{'name':name,'parent':-1,'position':[round(x*scale)for x in p]}for name,p in zip(['body','head','left_arm','right_arm'],piv)],'materials':[{'name':'wario','texture':'wario.png','size':[64,64]}],'vertices':[],'triangles':[]}
for v in me.vertices:
 p=v.co-center;b=1 if p.y>9.8 else(2 if p.x<0 else 3)if abs(p.x)>4.1 and p.y>4.0 else 0;p.y-=bottom;m['vertices'].append({'bone':b,'position':[round(x*scale)for x in p]})
for t in me.loop_triangles:m['triangles'].append({'material':0,'corners':[{'vertex':vi,'uv':list(me.uv_layers.active.data[li].uv),'normal':[round(x*127)for x in me.vertices[vi].normal.normalized()]}for vi,li in zip(t.vertices,t.loops)]})
m.update(source_triangles=460,height_game_units=82,native_lighting=True,source='Mario Tennis 64/wario.obj');(R/'tools/wario_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');print('Wario: 460 original triangles, 82 units tall, one 64x64 CI4 texture')

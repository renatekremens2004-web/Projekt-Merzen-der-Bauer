"""D-pad Down/Up toggle owned iron/hover boots through native equipment logic."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();p=O/'src/overlays/actors/ovl_player_actor/z_player.c';b=R/'tools/originals/quick_iron_boots/src/overlays/actors/ovl_player_actor/z_player.c';b.parent.mkdir(parents=True,exist_ok=True)
if not b.exists():b.write_bytes(p.read_bytes())
s=b.read_text();needle='void Player_UpdateCommon(Player* this, PlayState* play, Input* input) {';assert s.count(needle)==1;s=s.replace(needle,'#include "quick_iron_boots.inc.c"\n\n'+needle)
a=s.index(needle);needle='    sControlInput = input;';i=s.index(needle,a);s=s[:i]+s[i:].replace(needle,needle+'\n    Player_TryQuickIronBoots(this, play, input);',1);p.write_text(s);(p.parent/'quick_iron_boots.inc.c').write_bytes((R/'tools/quick_iron_boots.inc.c').read_bytes())
print('D-pad Down: iron, Up: hover; owned adult boots toggle through native equipment path.')

"""Prepare Bean using source bone lengths and one uniform model scale.

Requires NumPy only for preparation. The resulting bean_bound.json remains
usable by build_bean.py with the standard Python library alone.
"""
from pathlib import Path
import copy
import json
import numpy as np

ROOT = Path(__file__).resolve().parent


def rotation_between(a, b):
    a, b = np.array(a, dtype=float), np.array(b, dtype=float)
    a /= np.linalg.norm(a)
    b /= np.linalg.norm(b)
    c = np.clip(np.dot(a, b), -1, 1)
    if c > 1 - 1e-9:
        return np.eye(3)
    if c < -1 + 1e-9:
        axis = np.cross(a, [0, 0, 1])
        if np.linalg.norm(axis) < 1e-6:
            axis = np.cross(a, [0, 1, 0])
        axis /= np.linalg.norm(axis)
        return 2 * np.outer(axis, axis) - np.eye(3)
    v = np.cross(a, b)
    skew = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + skew + skew @ skew / (1 + c)


def main():
    source = json.loads((ROOT / 'bean_source.json').read_text())
    native = json.loads((ROOT / 'bean_native_rig.json').read_text())
    # Reuse the previously verified 128x128 CI8 atlas without another conversion.
    atlas = json.loads((ROOT / 'bean_bound.json').read_text())
    scale = 360000.0
    target = native['target']
    source_names = {'Pelvis': 'Hips', 'Torso': 'Hips', 'Head': 'Head',
        'LeftUpperArm': 'LeftArm', 'LeftForearm': 'LeftForeArm', 'LeftHand': 'LeftHand',
        'RightUpperArm': 'RightArm', 'RightForearm': 'RightForeArm', 'RightHand': 'RightHand',
        'LeftThigh': 'LeftUpLeg', 'LeftShin': 'LeftLeg', 'LeftFoot': 'LeftFoot',
        'RightThigh': 'RightUpLeg', 'RightShin': 'RightLeg', 'RightFoot': 'RightFoot'}
    rotations = [np.array(b['matrix'])[:3, :3] for b in native['bones']]
    heads = {k: np.array(v['head']) * scale for k, v in source['bones'].items()}
    anchors = {name: heads[bone] for name, bone in source_names.items()}
    poses = {}
    for name, bone in source_names.items():
        if name == 'Pelvis' or name.endswith('Foot'):
            poses[name] = np.eye(3)
        elif name in ['Torso', 'Head']:
            poses[name] = rotation_between([0, 1, 0], rotations[target[name]][:, 0])
        else:
            direction = np.array(source['bones'][bone]['tail']) - np.array(source['bones'][bone]['head'])
            poses[name] = rotation_between(direction, rotations[target[name]][:, 0])

    # Both native torso branches pivot at the pelvis. All other origins follow
    # the original source joints, rotated into Impa's reference pose.
    positions = {'Pelvis': np.zeros(3), 'Torso': np.zeros(3)}
    parents = {'Head': 'Torso'}
    for side in ['Left', 'Right']:
        parents.update({side+'UpperArm': 'Torso', side+'Forearm': side+'UpperArm',
                        side+'Hand': side+'Forearm', side+'Thigh': 'Pelvis',
                        side+'Shin': side+'Thigh', side+'Foot': side+'Shin'})
    pending = dict(parents)
    while pending:
        for child, parent in list(pending.items()):
            if parent in positions:
                positions[child] = positions[parent] + poses[parent] @ (anchors[child] - anchors[parent])
                del pending[child]

    def mapped_group(name):
        if name == 'Hips':
            return 'Pelvis'
        if name.startswith('Spine'):
            return 'Torso'
        if name in ['Neck', 'Head', 'HeadTop_End']:
            return 'Head'
        for side in ['Left', 'Right']:
            part = name.removeprefix(side)
            if part == name:
                continue
            if part.startswith('Hand'):
                return side+'Hand'
            return side + {'Shoulder':'UpperArm', 'Arm':'UpperArm', 'ForeArm':'Forearm',
                           'UpLeg':'Thigh', 'Leg':'Shin', 'Foot':'Foot',
                           'ToeBase':'Foot', 'Toe_End':'Foot'}[part]
        raise ValueError(name)

    vertex_groups = []
    for v in source['vertices']:
        weights = {}
        for name, weight in v['weights']:
            group = mapped_group(name)
            weights[group] = weights.get(group, 0.0) + weight
        group = max(weights, key=weights.get)
        # The supplied auto-rig assigns some shoe vertices to a calf and the
        # knee ring to a thigh. Use the source joint planes to keep each shoe
        # rigid and put the lower pant section on its actual knee segment.
        for side in ['Left', 'Right']:
            if group in {side+'Thigh', side+'Shin', side+'Foot'}:
                height = v['position'][1] * scale
                ankle = heads[side+'Foot'][1] + 0.00005 * scale
                knee = heads[side+'Leg'][1]
                group = side + ('Foot' if height <= ankle else 'Shin' if height < knee else 'Thigh')
                break
        vertex_groups.append(group)

    # The FBX also contains two detached shoe shells, with a visible gap
    # below the trouser cuffs even in its untouched bind pose. Translate each
    # complete shoe upward as a rigid piece; never stretch shoe geometry.
    adjacent=[set() for _ in source['vertices']]
    for triangle in source['triangles']:
        indices=[c['vertex'] for c in triangle]
        for a,b in zip(indices,indices[1:]+indices[:1]):
            adjacent[a].add(b);adjacent[b].add(a)
    remaining=set(range(len(adjacent)));shoe_offsets={}
    while remaining:
        component={remaining.pop()};queue=list(component)
        while queue:
            for index in adjacent[queue.pop()]&remaining:
                remaining.remove(index);component.add(index);queue.append(index)
        if len(component)==34:
            points=np.array([source['vertices'][i]['position'] for i in component])
            assert points[:,1].max()<0.0007
            for index in component:
                shoe_offsets[index]=np.array([0.0,0.0004*scale,0.0])
    assert len(shoe_offsets)==68

    vertices, triangles, cache, posed = [], [], {}, []
    for tri in source['triangles']:
        ids = []
        for corner in tri:
            vi = corner['vertex']
            name = vertex_groups[vi]
            bone = target[name]
            point = np.array(source['vertices'][vi]['position']) * scale + shoe_offsets.get(vi,0)
            delta = poses[name] @ (point - anchors[name])
            position = rotations[bone].T @ delta
            normal = rotations[bone].T @ poses[name] @ np.array(corner['normal'])
            normal /= np.linalg.norm(normal)
            uv = [round(corner['uv'][0]*128*32), round((1-corner['uv'][1])*128*32)]
            key = (vi, tuple(np.round(normal, 5)), tuple(uv))
            if key not in cache:
                cache[key] = len(vertices)
                v = {'bone':bone, 'position':np.rint(position).astype(int).tolist(),
                     'normal':np.rint(normal*127).astype(int).tolist(), 'uv':uv,
                     'bind':(positions[name]+delta).tolist(), 'source_vertex':vi}
                vertices.append(v)
                posed.append(positions[name]+delta)
            ids.append(cache[key])
        triangles.append(ids)

    # Standing reference feet touch the floor. A normal actor scales only its
    # animation root translation; the horse actor keeps its saddle anchor.
    posed = np.array(posed)
    root_height = -float(posed[:, 1].min())
    root_ratio = root_height / native['bones'][0]['head'][1]
    origin = np.array([0, root_height, 0])
    bones = copy.deepcopy(native['bones'])
    by_index = {index:name for name,index in target.items()}
    joints = []
    for index, bone in enumerate(bones):
        if index == 0:
            position = origin
            local = origin
        else:
            name = by_index[index]
            position = origin + positions[name]
            parent = bone['parent']
            parent_pos = origin if parent == 0 else origin + positions[by_index[parent]]
            local = rotations[parent].T @ (position-parent_pos)
            joints.append({'bone':name,'original_source_distance':float(np.linalg.norm(anchors[name]-anchors[parents[name]])) if name in parents else 0,
                           'new_joint_distance':float(np.linalg.norm(local))})
        matrix = np.eye(4)
        matrix[:3,:3] = rotations[index]
        matrix[:3,3] = position
        bone.update(p=np.rint(local).astype(int).tolist(), head=position.tolist(), matrix=matrix.tolist())

    for v in vertices:
        v['bind'][1] += root_height
    result = {'object':native['object'],'palette':native['palette'],'bones':bones,'target':target,
              'vertices':vertices,'triangles':triangles,'texture':atlas['texture'],
              'texture_palette':atlas['texture_palette'],'scale':scale,
              'root_translation_scale':root_ratio,'binding':'source proportions; uniformly scaled; native animation rotations'}
    (ROOT/'bean_bound.json').write_text(json.dumps(result,separators=(',',':'))+'\n')
    report = {'source_vertices':len(source['vertices']),'source_triangles':len(source['triangles']),
              'output_vertices':len(vertices),'output_triangles':len(triangles),'uniform_scale':scale,
              'root_height':root_height,'root_translation_scale':root_ratio,
              'reference_height':float(posed[:,1].max()-posed[:,1].min()),
              'rigid_shoe_translation_source_units':0.0004,'shoe_vertices':len(shoe_offsets),
              'joint_lengths':joints}
    (ROOT/'bean_binding_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='joint_lengths'},indent=2))


if __name__ == '__main__':
    main()

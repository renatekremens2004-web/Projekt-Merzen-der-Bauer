"""Last-step child-castle Marty/Doc conversation and parked low-poly DeLorean."""
from pathlib import Path
import sys,json,re
from n64_model import emit
from build_story import add_private_message,messages,Layout,rewrite,closing
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/bttf'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
models={key:json.loads((R/f'tools/{key}_source.json').read_text())for key in ['marty','doc','delorean']}
A=O/'extracted/pal-1.0/assets/objects/object_bttf';A.mkdir(parents=True,exist_ok=True)
code='#include "ultra64.h"\n#include "animation.h"\n#include "gfx.h"\n#include "sys_matrix.h"\n'
for key,m in models.items():
 prefix=key.title();code+=emit(m,R/'models'/key,prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL')
(A/'object_bttf.c').write_text(code)
p=O/'include/tables/object_table.h';p.write_text(original(p)+'\n/* 0x0193 */ DEFINE_OBJECT(object_bttf, OBJECT_BTTF)\n')
p=O/'spec/spec';p.write_text(original(p)+'\n/* Private child-castle object: native DMA indices remain intact. */\nbeginseg\n    name "object_bttf"\n    compress\n    romalign 0x1000\n    include "$(BUILD_DIR)/assets/objects/object_bttf/object_bttf.o"\n    number 6\nendseg\n')
D=O/'extracted/pal-1.0/assets/scenes/overworld/spot15';p=D/'spot15_room_0_03000054_ActorEntryList.inc.c';s=original(p);count=s.count('ACTOR_');assert count==60
s+='''    { ACTOR_ELF_MSG2, { -390, 1410, 2340 }, { 0, -0x1000, 0 }, 0x3F82 }, /* Marty: grass, away from guard paths */
    { ACTOR_ELF_MSG2, { -500, 1425, 2310 }, { 0, 0x1000, 0 }, 0x3F83 }, /* Doc: same shared dialogue */
    { ACTOR_ELF_MSG2, { -480, 1440, 2150 }, { 1142, 0x4000, 815 }, 0x3F84 }, /* parked car, mild native meadow slope */
''';p.write_text(s)
p=D/'spot15_room_0_03000040_ObjectList.inc.c';s=original(p);objects=s.count('OBJECT_');assert objects==10;p.write_text(s+'    OBJECT_BTTF, /* shared by all three child-castle instances */\n')
p=D/'spot15_room_0.h';h=original(p)
for macro,old,new in [('LENGTH_spot15_room_0_03000054_ActorEntryList',count,count+3),('LENGTH_spot15_room_0_03000040_ObjectList',objects,objects+1)]:
 h,n=re.subn(rf'(#define {macro} ){old}\b',lambda m:m[1]+str(new),h);assert n==1,macro
p.write_text(h)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p).replace('#include "play_state.h"','#include "play_state.h"\n#include "player.h"');helper=(R/'tools/bttf_actor.inc.c').read_text()
for key in ['marty','doc']:helper=helper.replace(key.upper()+'_PIVOTS',','.join('{'+','.join(map(str,b['position']))+'}'for b in models[key]['bones']))
needle='/* Private child-field traveller.';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
for action in ['Init','Update']:
 needle=f'void ElfMsg2_{action}(Actor* thisx, PlayState* play) {{\n    ElfMsg2* this = (ElfMsg2*)thisx;'
 assert s.count(needle)==1;s=s.replace(needle,needle+f'\n    if (ElfMsg2_IsBttf(thisx, play)) {{\n        ElfMsg2_{action}Bttf(this, play);\n        return;\n    }}')
needle='if (ElfMsg2_IsJabba(thisx, play) ||';assert s.count(needle)==1;s=s.replace(needle,'if (ElfMsg2_IsBttf(thisx, play) || ElfMsg2_IsJabba(thisx, play) ||');p.write_text(s)
dialogues={
 '71B4':['Marty: Hey Doc! Das ist doch der Junge aus der Wüste!'],
 '71B5':['Doc: Marty! Grundgütiger, du mußt vierdimensional denken!','Doc: Er ist uns doch in dieser Zeit noch gar nicht begegnet!'],
 '71B6':['Marty: Jesus Christ, Doc, du hast ja recht! Ich steig mit diesen Zeitreisen nicht durch. Ich brauch echt ne Pause!'],
 '71B7':['Doc: Du sollst so viele Pausen kriegen, wie du möchtest, sobald wir erst einmal Friedrich Merz aufgehalten haben.','Doc: Denk an unsere Aufgabe, Marty!']}
entries={ident:dict(new_message=True,insert_before='71B2',native_template='0022'if ident=='71B7'else'009E',reserve_text='Time travellers.',pages=pages)for ident,pages in dialogues.items()}
(R/'story/bttf_de.json').write_text(json.dumps(dict(chapter='Marty und Doc am jungen Schloß Hyrule',orthography='de-vor-1996',conversation='Ansprache beider NPCs startet 71B4, dann native A-bestätigte EVENT-Fortsetzungen bis 71B7. Keine Quest-/Zeitreise-Funktion.',messages=entries),ensure_ascii=False,indent=2)+'\n')
p=O/'extracted/pal-1.0/text/message_data.h';s=p.read_text();native=messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
for ident,entry in entries.items():
 s=add_private_message(s,ident,entry);parsed=messages(s);a,b,_=parsed[ident]['parts'][2];body,_=rewrite(native[entry['native_template']]['parts'][2][2],entry,Layout(O),ident);s=s[:a]+body+s[b:]
# A full story rebuild discovers chapter files alphabetically. Keep the same
# physical private-message order as an incremental build after Jabba, with a
# real following DMA pointer for every language's final private message.
order=['71B3',*entries,'71B2']
if [s.index('DEFINE_MESSAGE(0x'+ident+',')for ident in order]!=sorted(s.index('DEFINE_MESSAGE(0x'+ident+',')for ident in order):
 blocks=[]
 for ident in entries:
  start=s.index('DEFINE_MESSAGE(0x'+ident+',');end=closing(s,start+len('DEFINE_MESSAGE('))+1
  while end<len(s)and s[end]=='\n':end+=1
  blocks.append(s[start:end]);s=s[:start]+s[end:]
 at=s.index('DEFINE_MESSAGE(0x71B2,');s=s[:at]+''.join(blocks)+s[at:]
p.write_text(s)
print('BTTF child castle:',sum(len(m['triangles'])for m in models.values()),'combined triangles; one shared object, two talkers, parked car; four private conversation IDs.')

"""Blender: simplify the supplied avatar and retain its own rigid joint distances."""
import bpy,json,math,sys,hashlib
from pathlib import Path
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent.parent
src=Path(sys.argv[sys.argv.index('--')+1]) if '--' in sys.argv else R/'models/habeck/model.fbx'
bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(src));rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE')
A=Matrix(((1,0,0),(0,0,1),(0,-1,0)));A4=A.to_4x4()
keep=['Hips','Spine','Spine1','Spine2','Neck','Neck1','Neck2','Head','LeftShoulder','LeftArm','LeftForeArm','LeftHand','RightShoulder','RightArm','RightForeArm','RightHand','LeftUpLeg','LeftLeg','LeftFoot','LeftToeBase','RightUpLeg','RightLeg','RightFoot','RightToeBase']
idx={n:i for i,n in enumerate(keep)};bones=[rig.data.bones[n] for n in keep];rest=[A4@rig.matrix_world@b.matrix_local for b in bones]
def selected(name):
 b=rig.data.bones[name]
 while b.name not in idx:b=b.parent
 return idx[b.name]
# All size changes are uniform, including local bone translations.
meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];allp=[A@(o.matrix_world@v.co) for o in meshes for v in o.data.vertices];ground=min(v.y for v in allp);height=max(v.y for v in allp)-ground;scale=6800/height;offset=Vector((0,-ground,0))
out={'model':'Supplied Robert Habeck avatar','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_triangles':0,'height':6800,'uniform_scale':scale,'bones':[],'vertices':[],'triangles':[],'materials':[],'animations':{},'simplification':{}}
def ints(v):return [round(x) for x in v]
def angles(m):return [round(a*32768/math.pi)%65536 for a in m.to_euler('XYZ')]
for i,b in enumerate(bones):
 p=selected(b.parent.name) if b.parent else -1;local=rest[p].inverted()@rest[i] if p>=0 else rest[i]
 out['bones'].append({'name':b.name,'parent':p,'position':ints(local.translation*scale),'rest_rotation':angles(local.to_3x3()),'rest_matrix':[list(r) for r in rest[i]]})
targets={'AvatarHead':900,'outfit':1000,'AvatarBody':220,'AvatarLeftEyeball':80,'AvatarRightEyeball':80,'AvatarTeethLower':32,'AvatarTeethUpper':32}
for obj in meshes:
 obj.data.calc_loop_triangles();before=len(obj.data.loop_triangles);out['source_triangles']+=before
 if obj.name not in targets:continue
 bpy.context.view_layer.objects.active=obj;obj.select_set(True)
 if obj.data.shape_keys:obj.shape_key_clear()
 mod=obj.modifiers.new('N64 geometry budget','DECIMATE');mod.ratio=min(1,targets[obj.name]/before);mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name)
 mesh=obj.data;mesh.calc_loop_triangles();base=len(out['vertices']);mat=len(out['materials']);out['materials'].append({'name':obj.name,'texture':{'AvatarHead':'AvatarHeadMale_Color_2K.jpeg','outfit':'ARARAT_Color_2K.jpeg','AvatarBody':'AvatarBodyMale_Color_2K.jpeg','AvatarLeftEyeball':'AvatarEyes_Color_512.jpeg','AvatarRightEyeball':'AvatarEyes_Color_512.jpeg','AvatarTeethLower':'AvatarTeeth_Color_1K.jpeg','AvatarTeethUpper':'AvatarTeeth_Color_1K.jpeg'}[obj.name]})
 for v in mesh.vertices:
  weights={}
  for g in v.groups:
   k=selected(obj.vertex_groups[g.group].name);weights[k]=weights.get(k,0)+g.weight
  bone=max(weights,key=weights.get);pw=A@(obj.matrix_world@v.co);local=rest[bone].inverted()@pw
  out['vertices'].append({'bone':bone,'position':ints(local*scale)})
 for t in mesh.loop_triangles:
  cs=[]
  for li in t.loops:
   vi=mesh.loops[li].vertex_index;bone=out['vertices'][base+vi]['bone'];nw=A@obj.matrix_world.to_3x3().inverted().transposed()@mesh.corner_normals[li].vector;n=(rest[bone].to_3x3().inverted()@nw).normalized();cs.append({'vertex':base+vi,'normal':ints(n*127),'uv':list(mesh.uv_layers.active.data[li].uv)})
  out['triangles'].append({'material':mat,'corners':cs})
 out['simplification'][obj.name]={'before':before,'after':len(mesh.loop_triangles)}
# Idle, raising hands and holding the blessing share the native 27/30/30 frames.
local_rest=[(rest[b['parent']].inverted()@rest[i]).to_3x3() if b['parent']>=0 else rest[i].to_3x3() for i,b in enumerate(out['bones'])]
for label,count in [('idle',27),('raise',30),('hold',30)]:
 frames=[]
 for f in range(count):
  t=0 if label=='idle' else (0.5-0.5*math.cos(math.pi*f/(count-1)) if label=='raise' else 1)
  rotations=[r.copy() for r in local_rest]
  for name,sign in [('LeftArm',-1),('RightArm',1)]:
   i=idx[name];p=out['bones'][i]['parent'];rotations[i]=rest[p].to_3x3().inverted()@Matrix.Rotation(math.radians(sign*(74-35*t)),3,'Z')@rest[i].to_3x3()
  # Small breathing/nodding motions; never animate scale or child translation.
  rotations[idx['Spine2']]=rotations[idx['Spine2']]@Matrix.Rotation(math.radians(0.6*math.sin(2*math.pi*f/count)),3,'X')
  rotations[idx['Head']]=rotations[idx['Head']]@Matrix.Rotation(math.radians(0.8*math.sin(2*math.pi*f/count)),3,'X')
  frames.append({'root':ints((rest[0].translation+offset)*scale),'rotation':[angles(r) for r in rotations]})
 out['animations'][label]=frames
(R/'tools/habeck_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print('HABECK',out['source_triangles'],'->',len(out['triangles']),'triangles;',len(keep),'bones; height',height,'scale',scale);print(out['simplification'])

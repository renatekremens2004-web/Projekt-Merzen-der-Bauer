"""Verify the Bean build against the published German Kokiri ROM.

Unchanged code/data may have newly linked ROM/overlay addresses. Every
such changed word must be covered by an ELF relocation; instruction
opcodes must remain identical. The changed Impa object, German messages
and one small actor animation function are checked separately.
"""
from pathlib import Path
import argparse,csv,hashlib,json,re,struct,subprocess,zipfile
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers

ROOT=Path(__file__).resolve().parent.parent
BASE_SHA='deb863379b007e3a54c3f5d652af12c5353b1a32619dc5b5ec08532405332bfc'


def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('oot',type=Path);args=ap.parse_args();o=args.oot.resolve();b=o/'build/pal-1.0'
 plain=(b/'oot-pal-1.0.z64').read_bytes();packed=(b/'oot-pal-1.0-compressed.z64').read_bytes()
 with zipfile.ZipFile(ROOT/'downloads/Mr_Burns_Merz_Kokiri_DE_PAL10.zip') as archive:
  old=archive.read('Mr_Burns_Merz_Kokiri_DE_PAL10.z64')
  assert archive.read('story/kokiri_de.json')==(ROOT/'story/kokiri_de.json').read_bytes()
 assert hashlib.sha256(old).hexdigest()==BASE_SHA
 assert len(packed)==33554432 and packed[0x3e:0x40]==b'P\0'
 assert struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
 mp=(b/'oot-pal-1.0.map').read_text()
 def sym(s):return int(re.search(r'0x([0-9a-f]+)\s+'+re.escape(s)+r'\b',mp)[1],16)
 elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(b/'oot-pal-1.0.elf')],text=True)
 rels={};current=None
 for line in elf.splitlines():
  header=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
  if header:current=header[1];rels.setdefault(current,{})
  entry=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
  if current and entry:rels[current][int(entry[1],16)]=(entry[2],entry[3])
 names=[row['Name'] for row in csv.DictReader((o/'baseroms/pal-1.0/segments.csv').open())]
 identical=[];relocated=[];intentional=[];verified=0;model=None
 for index,name in enumerate(names):
  _,_,before=segment(old,index);start,end,unpacked=segment(packed,index)
  if unpacked is None:continue
  expected=plain[start:end]
  if name=='makerom':assert unpacked[:16]==expected[:16] and unpacked[24:]==expected[24:]
  elif name!='dmadata':assert unpacked==expected,('compression',name);verified+=1
  lo,hi=[sym('_'+name+'SegmentRom'+s) for s in ['Start','End']];after=plain[lo:hi]
  if name=='object_im':
   assert len(after)<=len(before)
   model={'native_bytes':len(before),'bean_bytes':len(after),'fits_native_budget':True}
  if before==after:identical.append(name);continue
  if name in {'makerom','dmadata','ger_message_data_static','object_im','ovl_Demo_Im'}:
   intentional.append({'segment':name,'before_bytes':len(before),'after_bytes':len(after)});continue
  assert len(before)==len(after),('unexpected size change',name,len(before),len(after))
  origin=sym('_'+name+'SegmentStart');changes=sorted({i//4*4 for i,(x,y) in enumerate(zip(before,after)) if x!=y});count=0
  for off in changes:
   address=origin+off
   if name=='code' and sym('sGerMessageEntryTable')<=address<sym('sFraMessageEntryTable'):continue
   rel=rels.get(name,{}).get(address);assert rel,('unexplained change',name,hex(address))
   kind,target=rel
   if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert before[off:off+2]==after[off:off+2],(name,hex(address),rel)
   elif kind=='R_MIPS_26':assert (before[off]>>2)==(after[off]>>2),(name,hex(address),rel)
   else:assert kind=='R_MIPS_32',(name,hex(address),rel)
   count+=1
  relocated.append({'segment':name,'relocated_words':count,'instruction_opcodes_preserved':True})
 # Only the original animation hold is removed from the Impa actor.
 rel='src/overlays/actors/ovl_Demo_Im/z_demo_im.c';source=subprocess.check_output(['git','-C',str(o),'show','HEAD:'+rel],text=True)
 a=source.index('void func_80985EF4(');z=source.index('\n}',a)+2
 expected=source[:a]+'''void func_80985EF4(DemoIm* this) {
    /* Keep Bean dancing during native song playback and player input. */
    DemoIm_UpdateSkelAnime(this);
}'''+source[z:]
 assert (o/rel).read_text()==expected
 opening='src/overlays/gamestates/ovl_opening/z_opening.c'
 assert (o/opening).read_bytes()==subprocess.check_output(['git','-C',str(o),'show','HEAD:'+opening])
 allowed={'src/code/z_sram.c','src/overlays/actors/ovl_En_Ganon_Mant/z_en_ganon_mant.c','src/overlays/actors/ovl_En_Viewer/z_en_viewer.c',rel}
 changed=set(subprocess.check_output(['git','-C',str(o),'diff','--name-only','HEAD','--','src','include'],text=True).splitlines())
 assert changed<=allowed,changed
 edits={}
 for chapter in sorted((ROOT/'story').glob('*.json')):
  for ident,entry in json.loads(chapter.read_text())['messages'].items():assert ident not in edits;edits[ident]=entry
 dances=json.loads((ROOT/'tools/bean_dances.json').read_text());assert [x['frame_count'] for x in dances.values()]==[40,55]
 report={'version':'German PAL 1.0, Burns/Merz + Mr. Bean','rom_bytes':len(packed),'rom_sha256':hashlib.sha256(packed).hexdigest(),'baseline_sha256':BASE_SHA,'crc':['%08X'%v for v in struct.unpack_from('>II',packed,16)],'compressed_segments_verified':verified,'normal_start_restored':True,'original_kokiri_chapter_preserved':True,'impa_actor_change_only_visual_animation_hold':True,'native_gameplay_sources_preserved':True,'intentional_changes':intentional,'identical_segments':identical,'relocated_segments':relocated,'identical_count':len(identical),'relocated_only_count':len(relocated),'object_budget':model,'text_buffers':check_buffers(b,edits)}
 (b/'bean-verification.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items() if k not in ['identical_segments','relocated_segments','text_buffers']},indent=2));print('Text buffers:',len(edits),'verified')


if __name__=='__main__':main()

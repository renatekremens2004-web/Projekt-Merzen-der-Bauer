"""Build the supplied reduced Habeck avatar for Rauru, preserving native cue logic."""
from pathlib import Path
import sys,json,math,itertools,re
from PIL import Image
ROOT=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();A=O/'extracted/pal-1.0/assets/objects/object_rl';B=ROOT/'originals/habeck'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
m=json.loads((ROOT/'habeck_source.json').read_text());n=len(m['bones']);assert n==24;lines=['/* Supplied Habeck avatar: own proportions and unit-scale poses. */']
def u64(name,data):
 data+=bytes((-len(data))%8);lines.append('static u64 '+name+'[]={');lines.extend('0x'+data[i:i+8].hex().upper()+',' for i in range(0,len(data),8));lines.append('};')
def rgba16(c):
 r,g,b=c[:3];return ((r>>3)<<11)|((g>>3)<<6)|((b>>3)<<1)|1
texspec=[]
for i,mat in enumerate(m['materials']):
 im=Image.open(ROOT.parent/'models/habeck/textures'/mat['texture']).convert('RGB').resize((64,64),Image.Resampling.LANCZOS)
 im=im.quantize(colors=16,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE);pal=im.getpalette();data=list(im.getdata());u64('gHabeckPalette%d'%i,b''.join(rgba16(pal[j:j+3]).to_bytes(2,'big') for j in range(0,48,3)));u64('gHabeckTex%d'%i,bytes((data[j]<<4)|data[j+1] for j in range(0,len(data),2)));texspec.append((64,64));im.save(ROOT.parent/'models/habeck/textures'/('n64_'+mat['name']+'.png'))
vertices=[];commands=[]
for mat,(w,h) in enumerate(texspec):
 commands+=['gsDPPipeSync(),','gsDPSetTextureLUT(G_TT_RGBA16),','gsDPLoadTLUT_pal16(0,gHabeckPalette%d),'%mat,'gsDPLoadTextureBlock_4b(gHabeckTex%d,G_IM_FMT_CI,%d,%d,0,G_TX_WRAP,G_TX_WRAP,6,6,G_TX_NOLOD,G_TX_NOLOD),'%(mat,w,h)]
 tris=[t for t in m['triangles'] if t['material']==mat]
 for start in range(0,len(tris),10):
  batch=tris[start:start+10];local=[]
  for t in batch:
   for c in t['corners']:
    v=m['vertices'][c['vertex']];local.append({'bone':v['bone'],'position':v['position'],'normal':c['normal'],'uv':[round(c['uv'][0]*w*32),round((1-c['uv'][1])*h*32)]})
  order=sorted(range(len(local)),key=lambda j:local[j]['bone']);slots={v:i for i,v in enumerate(order)}
  for bone,itr in itertools.groupby(order,key=lambda j:local[j]['bone']):
   group=list(itr);off=len(vertices);vertices.extend(local[j] for j in group);commands+=['gsSPMatrix((Mtx*)0x%08X,G_MTX_NOPUSH|G_MTX_LOAD|G_MTX_MODELVIEW),'%(0x0d000000+bone*64),'gsSPVertex(&gHabeckVertices[%d],%d,%d),'%(off,len(group),slots[group[0]])]
  for j in range(len(batch)):commands+=['gsSP1Triangle(%d,%d,%d,0),'%tuple(slots[j*3+k] for k in range(3))]
lines+=['static Vtx gHabeckVertices[]={']
for v in vertices:
 assert all(-32768<=x<=32767 for x in v['position']+v['uv']);lines.append('{{{%d,%d,%d},0,{%d,%d},{%d,%d,%d,255}}},'%tuple(v['position']+v['uv']+[x&255 for x in v['normal']]))
lines+=['};','static Gfx gHabeckEmptyDL[]={gsSPEndDisplayList()};','static Gfx gHabeckBodyDL[]={','gsDPPipeSync(),','gsDPSetCycleType(G_CYC_2CYCLE),','gsSPTexture(0xffff,0xffff,0,0,G_ON),','gsDPSetRenderMode(G_RM_FOG_SHADE_A,G_RM_AA_ZB_OPA_SURF2),','gsSPDisplayList(0x0c000000),','gsSPClearGeometryMode(G_CULL_FRONT|G_CULL_BACK|G_TEXTURE_GEN|G_TEXTURE_GEN_LINEAR),','gsSPSetGeometryMode(G_LIGHTING|G_SHADE|G_SHADING_SMOOTH|G_ZBUFFER|G_FOG),','gsDPSetCombineLERP(TEXEL0,0,SHADE,0,0,0,0,TEXEL0,PRIMITIVE,0,COMBINED,0,COMBINED,0,ENVIRONMENT,0),','gsDPSetPrimColor(0,0,255,255,255,255),','gsDPSetTextureFilter(G_TF_BILERP),']+commands+['gsSPEndDisplayList(),','};']
for i,b in enumerate(m['bones']):
 children=[j for j,x in enumerate(m['bones']) if x['parent']==i];siblings=[j for j,x in enumerate(m['bones']) if x['parent']==b['parent']];sib=siblings[siblings.index(i)+1] if siblings.index(i)+1<len(siblings) else 255
 lines+=['static StandardLimb gHabeckLimb%d={{%d,%d,%d},%d,%d,%s};'%tuple([i]+b['position']+[children[0] if children else 255,sib,'gHabeckBodyDL' if i==n-1 else 'gHabeckEmptyDL'])]
lines+=['static void* gHabeckLimbs[]={'+','.join('&gHabeckLimb%d'%i for i in range(n))+'};','FlexSkeletonHeader gHabeckSkel={{gHabeckLimbs,%d},%d};'%(n,n)]
for name,label in [('Idle','idle'),('Raise','raise'),('Hold','hold')]:
 frames=m['animations'][label];channels=[[p['root'][k] for p in frames] for k in range(3)]+[[p['rotation'][b][k] for p in frames] for b in range(n) for k in range(3)];constants=[]
 for ch in channels:
  if len(set(ch))==1 and ch[0]%65536 not in constants:constants.append(ch[0]%65536)
 data=list(constants);indices=[]
 for ch in channels:
  if len(set(ch))==1:indices.append(constants.index(ch[0]%65536))
  else:indices.append(len(data));data.extend(x%65536 for x in ch)
 lines+=['static s16 gHabeck%sFrames[]={%s};'%(name,','.join('0x%04X'%v for v in data)),'static JointIndex gHabeck%sJoints[]={'%name];lines+=['{%d,%d,%d},'%tuple(indices[i:i+3]) for i in range(0,len(indices),3)];lines+=['};','AnimationHeader gHabeck%sAnim={{%d},gHabeck%sFrames,gHabeck%sJoints,%d};'%(name,len(frames),name,name,len(constants))]
(A/'habeck_model.inc.c').write_text('\n'.join(lines)+'\n')
p=A/'object_rl.c';p.write_text(original(p)+'\n#include "habeck_model.inc.c"\n');p=A/'object_rl.h';p.write_text(original(p)+'\nextern FlexSkeletonHeader gHabeckSkel;\nextern AnimationHeader gHabeckIdleAnim;\nextern AnimationHeader gHabeckRaiseAnim;\nextern AnimationHeader gHabeckHoldAnim;\n')
p=O/'src/overlays/actors/ovl_En_Rl/z_en_rl.c';s=original(p)
for old,new in [('object_rl_Skel_007B38','gHabeckSkel'),('object_rl_Anim_000A3C','gHabeckIdleAnim'),('object_rl_Anim_00040C','gHabeckRaiseAnim'),('object_rl_Anim_000830','gHabeckHoldAnim')]:s=s.replace(old,new)
p.write_text(s)
# Split the extended explanation across three safe native message buffers.
# TEXTID keeps the current cutscene text open; no timer/camera/choice change.
p=O/'extracted/pal-1.0/text/message_data.h';s=p.read_text();sys.path.insert(0,str(ROOT));import build_story
parsed=build_story.messages(s);edits=[]
for a,b in [('704F','0121'),('0121','0122'),('0122','0123')]:
 start,end,body=parsed[a]['parts'][2];assert not any(t.startswith('TEXTID') for t in build_story.tokens(body));edits.append((start,end,body+' TEXTID(0x'+b+')\n'))
for start,end,body in sorted(edits,reverse=True):s=s[:start]+body+s[end:]
p.write_text(s)
print('Habeck:',len(m['triangles']),'triangles,',n,'own bones; native cue, medallion and fade logic retained.')

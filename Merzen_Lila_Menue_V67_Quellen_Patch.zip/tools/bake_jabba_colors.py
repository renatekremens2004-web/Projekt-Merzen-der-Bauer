import bpy,bmesh,json,sys
from pathlib import Path
from mathutils import Matrix
W=Path(sys.argv[sys.argv.index('--')+1]);bpy.ops.wm.open_mainfile(filepath=str(W/'reduced.blend'),load_ui=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=16;scene.cycles.use_denoising=False
low=[o for o in scene.objects if o.type=='MESH'and not o.name.startswith('Sphere')]
bpy.ops.object.select_all(action='DESELECT')
for o in low:o.select_set(True)
bpy.context.view_layer.objects.active=low[0];bpy.ops.object.join();joined=bpy.context.object;joined.name='JabbaLow'
parts=[]
def region(f):
 p=f.calc_center_median()
 return 'JabbaFace' if p.z>5.1 and p.y>.35 else 'JabbaHead' if p.z>5.1 else 'JabbaBody'
for label in ['JabbaBody','JabbaHead','JabbaFace']:
 o=joined.copy();o.data=joined.data.copy();o.name=label;scene.collection.objects.link(o);bm=bmesh.new();bm.from_mesh(o.data);remove=[f for f in bm.faces if region(f)!=label];bmesh.ops.delete(bm,geom=remove,context='FACES');bm.to_mesh(o.data);bm.free();parts.append(o)
bpy.data.objects.remove(joined,do_unlink=True)
# Bring the untouched dense source into the same world coordinates for color-only baking.
with bpy.data.libraries.load(str(W/'import.blend'),link=False)as(src,dst):dst.objects=['Object_6']
high=dst.objects[0];scene.collection.objects.link(high);high.name='JabbaHigh';high.data.transform(high.matrix_world);high.matrix_world=Matrix.Identity(4)
scene.render.bake.use_selected_to_active=True;scene.render.bake.use_pass_direct=False;scene.render.bake.use_pass_indirect=False;scene.render.bake.use_pass_color=True;scene.render.bake.cage_extrusion=.12;scene.render.bake.max_ray_distance=.6;scene.render.bake.margin=12
for o in parts:
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 if o.name=='JabbaFace':
  # A continuous front projection dedicates the whole tile to facial features,
  # instead of spreading it over numerous tiny islands and the back of the head.
  if not o.data.uv_layers:o.data.uv_layers.new()
  xs=[v.co.x for v in o.data.vertices];zs=[v.co.z for v in o.data.vertices]
  xlo,xhi=min(xs)-.04,max(xs)+.04;zlo,zhi=min(zs)-.04,max(zs)+.04
  for loop in o.data.loops:
   p=o.data.vertices[loop.vertex_index].co
   o.data.uv_layers.active.data[loop.index].uv=((p.x-xlo)/(xhi-xlo),(p.z-zlo)/(zhi-zlo))
 else:
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.15,island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
 # One target material so every low face writes into the one active image.
 image=bpy.data.images.new(o.name+'Baked',width=512,height=512,alpha=False);image.generated_color=(.25,.3,.12,1)
 mat=bpy.data.materials.new(o.name+'Mat');mat.use_nodes=True;node=mat.node_tree.nodes.new('ShaderNodeTexImage');node.image=image;mat.node_tree.nodes.active=node;o.data.materials.clear();o.data.materials.append(mat)
 for p in o.data.polygons:p.material_index=0
 high.select_set(True);bpy.context.view_layer.objects.active=o
 if o.name=='JabbaFace':
  # Bake only local crevice shading into the face so the mouth and eyelids
  # survive the small N64 tile. Directional scene lighting stays native.
  for source_mat in high.data.materials:
   if not source_mat or not source_mat.use_nodes:continue
   nodes=source_mat.node_tree.nodes;links=source_mat.node_tree.links
   bsdf=next(n for n in nodes if n.type=='BSDF_PRINCIPLED')
   base=bsdf.inputs['Base Color'];mix=nodes.new('ShaderNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=.65
   if base.is_linked:links.new(base.links[0].from_socket,mix.inputs[1])
   else:mix.inputs[1].default_value=base.default_value
   ao=nodes.new('ShaderNodeAmbientOcclusion');ao.only_local=True;ao.inputs['Distance'].default_value=.4
   links.new(ao.outputs['AO'],mix.inputs[2]);emission=nodes.new('ShaderNodeEmission');links.new(mix.outputs['Color'],emission.inputs['Color']);links.new(emission.outputs[0],next(n for n in nodes if n.type=='OUTPUT_MATERIAL').inputs['Surface'])
  bpy.ops.object.bake(type='EMIT',use_selected_to_active=True,use_clear=True,cage_extrusion=.12,max_ray_distance=.6)
 else:bpy.ops.object.bake(type='DIFFUSE',use_selected_to_active=True,use_clear=True,cage_extrusion=.12,max_ray_distance=.6,pass_filter={'COLOR'})
 mat.node_tree.links.new(node.outputs['Color'],mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color']);image.filepath_raw=str(W/(o.name+'.png'));image.file_format='PNG';image.save();high.select_set(False)
bpy.data.objects.remove(high,do_unlink=True);bpy.ops.wm.save_as_mainfile(filepath=str(W/'baked.blend'));print('Baked original colors onto body/head atlases and a dedicated continuous face tile.')

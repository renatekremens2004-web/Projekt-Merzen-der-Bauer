/* The native fishing actor and minigame remain responsible for every action. */
extern Gfx gDoofDL[];
extern Gfx gDoofevilDL[];
static u16 Fishing_DoofText(u16 id) {
    static u16 nativeIds[] = { DOOF_NATIVE_IDS };
    static u16 adultIds[] = { DOOF_ADULT_IDS };
    s32 i;
    if (gSaveContext.language == LANGUAGE_GER && LINK_IS_ADULT) {
        for (i = 0; i < ARRAY_COUNT(nativeIds); i++) if (id == nativeIds[i]) return adultIds[i];
    }
    return id;
}
static s32 Fishing_DrawDoof(Fishing* this, PlayState* play) {
    static Vec3f pivots[2][4] = { DOOF_PIVOTS };
    Actor* actor = &this->actor;
    s32 index = LINK_IS_ADULT ? 1 : 0;
    s32 slot = Object_GetSlot(&play->objectCtx, index ? OBJECT_DOOFEVIL : OBJECT_DOOF);
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 310));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 830));
    s32 speaking = Message_GetState(&play->msgCtx) != TEXT_STATE_NONE;
    f32 strength = index ? 0.3f : 1.0f;
    Mtx* matrices;
    s32 i;
    if (gSaveContext.language != LANGUAGE_GER || slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return false;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return true;
    OPEN_DISPS(play->state.gfxCtx, "doof_owner", 1);
    Matrix_Push();
    /* Native owner scale is .011; these original-proportion meshes use .01. */
    Matrix_Scale(10.0f / 11.0f, 10.0f / 11.0f, 10.0f / 11.0f, MTXMODE_APPLY);
    for (i = 0; i < 4; i++) {
        Vec3f* pivot = &pivots[index][i];
        Matrix_Push();
        Matrix_RotateZ(idle * 0.004f * strength, MTXMODE_APPLY);
        Matrix_Translate(pivot->x, pivot->y, pivot->z, MTXMODE_APPLY);
        if (i == 1) {
            Matrix_RotateY(BINANG_TO_RAD(-this->unk_164) * 0.6f, MTXMODE_APPLY);
            Matrix_RotateX((speaking ? talk * 0.018f : idle * 0.006f) * strength, MTXMODE_APPLY);
        } else if (i >= 2) {
            Matrix_RotateZ((i == 2 ? 1 : -1) * (idle * 0.008f +
                (speaking ? talk * 0.035f : 0)) * strength, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivot->x, -pivot->y, -pivot->z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "doof_owner", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, index ? gDoofevilDL : gDoofDL);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    Matrix_Pop();
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    CLOSE_DISPS(play->state.gfxCtx, "doof_owner", 3);
    return true;
}

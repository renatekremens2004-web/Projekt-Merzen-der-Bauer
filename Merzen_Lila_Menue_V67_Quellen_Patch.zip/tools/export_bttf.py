"""Own-scale, face-first Marty/Doc and the supplied 190-triangle parked car.

Blender 4.3: --python tools/export_bttf.py -- <workdir>, with the user archives
extracted under input/marty, input/doc and input/delorean. No run-time FBX/OBJ.
"""
import bpy,bmesh,json,math,shutil,sys,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);T=Matrix(((-1,0,0),(0,0,1),(0,1,0)))
reports={}
for key in ['marty','doc','delorean']:
 bpy.ops.wm.read_factory_settings(use_empty=True);D=R/'models'/key;D.mkdir(parents=True,exist_ok=True)
 source=next((W/'input'/key).rglob('*.fbx'if key=='delorean'else'*.obj'))
 if key=='delorean':bpy.ops.import_scene.fbx(filepath=str(source))
 else:bpy.ops.wm.obj_import(filepath=str(source))
 objects=[o for o in bpy.context.scene.objects if o.type=='MESH'and(key!='delorean'or len(o.data.vertices)>10)]
 for o in list(bpy.context.scene.objects):
  if o.type=='MESH'and o not in objects:bpy.data.objects.remove(o,do_unlink=True)
 for o in objects:o.data.transform(o.matrix_world);o.matrix_world=Matrix.Identity(4)
 points=[v.co for o in objects for v in o.data.vertices];bottom=min(p.z for p in points);top=max(p.z for p in points)
 if key=='delorean':
  shutil.copyfile(W/'input/delorean/textures/delorean_color.tga.png',D/'car.png')
  mats=[dict(name='car',texture='car.png',size=[64,64])];scale=20000/(max(p.y for p in points)-min(p.y for p in points));center=Vector((0,(max(p.y for p in points)+min(p.y for p in points))/2,bottom));pivots=[Vector((0,0,0))]
 else:
  root=source.parent
  for name in ['body','face','eyes','hair','teeth']:shutil.copyfile(root/(name+'.png'),D/(name+'.png'))
  mats=[dict(name=name,texture=name+'.png',size=[64,64]if name not in['eyes','teeth']else[32,32])for name in ['body','face','eyes','hair','teeth']]
  mats.append(dict(name='face_close',texture='face.png',size=[64,64],crop=[0,0,1024,704]))
  scale=5000.;center=Vector((0,0,bottom));pivots=[Vector((0,0,0)),Vector((0,(1.38 if key=='marty'else 1.52)-bottom,0)),Vector((-.20,1.34 if key=='marty'else 1.45,0)),Vector((.20,1.34 if key=='marty'else 1.45,0))]
 m=dict(bones=[dict(name=['body','head','left_arm','right_arm'][i],parent=-1,position=[round(v*scale)for v in p])for i,p in enumerate(pivots)],materials=mats,vertices=[],triangles=[],uniform_scale=True,native_lighting=True,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),height_game_units=round((top-bottom)*scale/100,2),parked=key=='delorean')
 original=0;budgets=dict(body=410,face=670 if key=='doc'else 620,hair=170 if key=='doc'else 130,eyes=80,teeth=36)
 if key!='delorean':
  bpy.ops.object.select_all(action='DESELECT');objects[0].select_set(True);bpy.context.view_layer.objects.active=objects[0]
  bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.mesh.separate(type='MATERIAL');bpy.ops.object.mode_set(mode='OBJECT');objects=[o for o in bpy.context.scene.objects if o.type=='MESH']
 for o in objects:
  bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o;me=o.data;me.calc_loop_triangles();original+=len(me.loop_triangles)
  material='car'if key=='delorean'else me.materials[next(iter(me.polygons)).material_index].name.split('.')[0]
  if key!='delorean':
   # Weld OBJ UV duplicates before reduction; UVs remain per loop.
   bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);bm.to_mesh(me);bm.free();me.calc_loop_triangles()
   target=budgets[material]
   if len(me.loop_triangles)>target:
    mod=o.modifiers.new('Face-first N64 budget','DECIMATE');mod.ratio=target/len(me.loop_triangles);bpy.ops.object.modifier_apply(modifier=mod.name)
  me.calc_loop_triangles();off=len(m['vertices']);rotations=[]
  for v in me.vertices:
   p=T@(v.co-center);bone=0;rot=Matrix.Identity(3)
   if key!='delorean':
    # Lower the T-pose arms once, around their own shoulder. Subsequent idle
    # gestures are tiny rigid rotations, with no foreign skeleton or scaling.
    if abs(p.x)>.19 and p.y>.90 and material in['body','face']:
     bone=2 if p.x<0 else 3;rot=Matrix.Rotation(math.radians(63 if bone==2 else -63),3,'Z');p=pivots[bone]+rot@(p-pivots[bone])
    elif p.y>(1.43 if key=='marty'else 1.57)or material in['face','eyes','teeth','hair']:bone=1
   m['vertices'].append(dict(bone=bone,position=[round(v*scale)for v in p]));rotations.append(rot)
  for t in me.loop_triangles:
   mat=0 if key=='delorean'else ['body','face','eyes','hair','teeth'].index(material)
   uv=[list(me.uv_layers.active.data[i].uv)for i in t.loops]
   if key!='delorean'and material=='face'and all(m['vertices'][off+v]['bone']==1 for v in t.vertices)and all(0<=u<=1 and 0<=(1-v)*1024<=704 for u,v in uv):
    mat=5;uv=[[u,1-((1-v)*1024/704)]for u,v in uv]
   m['triangles'].append(dict(material=mat,corners=[dict(vertex=off+v,uv=coords,normal=[round(x*127)for x in(rotations[v]@T@me.vertices[v].normal).normalized()])for v,coords in zip(t.vertices,uv)]))
  # Keep a posed Blender copy only as an offline visual aid.
  for v in me.vertices:
   p=m['vertices'][off+v.index]['position'];v.co=Vector((-p[0]/scale,p[2]/scale,p[1]/scale))
 m['original_triangles']=original
 assert len(m['triangles'])<1600 if key!='delorean'else len(m['triangles'])==190
 (R/'tools'/(key+'_source.json')).write_text(json.dumps(m,separators=(',',':'))+'\n')
 bpy.ops.wm.save_as_mainfile(filepath=str(W/(key+'-posed.blend')))
 reports[key]=dict(original_triangles=original,triangles=len(m['triangles']),height=m['height_game_units'],bones=len(m['bones']),material_triangles={mat['name']:sum(t['material']==i for t in m['triangles'])for i,mat in enumerate(mats)})
 print(key,reports[key],flush=True)
(W/'reduction.json').write_text(json.dumps(reports,indent=2)+'\n')

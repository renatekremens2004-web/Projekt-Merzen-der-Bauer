/* Match native 32x32 RGBA icons to Link's existing custom tunic colors.
 * Only recolor the dominant cloth hue. Preserve neutral collar/belt detail,
 * pixel alpha and shading, using the already allocated DMA buffer. */
static void CustomTunics_RecolorIcon(u8* pixels, u16 itemId) {
    s32 i;
    u8* start = pixels;
    for (i = 0; i < 32 * 32; i++, pixels += 4) {
        u32 r = pixels[0];
        u32 g = pixels[1];
        u32 b = pixels[2];
        if (itemId == ITEM_TUNIC_GORON && r > g && r > b) {
            pixels[1] = (r + g) / 2;
        } else if (itemId == ITEM_TUNIC_ZORA && b > r && b > g) {
            pixels[0] = b * 110 / 240;
            pixels[1] = b * 195 / 240;
        }
    }
    osWritebackDCache(start, 32 * 32 * 4);
}

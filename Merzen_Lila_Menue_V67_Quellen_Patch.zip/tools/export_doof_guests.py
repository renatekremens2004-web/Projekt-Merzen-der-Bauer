"""User-supplied DS OBJ models; small own rigid groups, relaxed arms, original faces.
blender -b --python tools/export_doof_guests.py -- WORK
"""
import bpy,json,math,shutil,sys,hashlib
from pathlib import Path
from mathutils import Vector,Matrix
from PIL import Image
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);report={}
settings={'doof':(78,1.03,.18,.91,67),'doofevil':(82,1.04,.18,.94,64),'shrek':(86,1.52,.56,1.47,63),'monopoly':(64,1.95,.49,1.90,65)}
for key,(height,neck,shoulder,sy,angle)in settings.items():
 root=W/'input'/key;src=next(root.rglob('*.obj'));D=R/'models'/key;D.mkdir(parents=True,exist_ok=True);vs=[];uv=[];ns=[];faces=[];mats={};mat='';kd={};name=''
 for line in src.with_suffix('.mtl').read_text().splitlines():
  q=line.split()
  if not q:continue
  if q[0]=='newmtl':name=q[1];kd[name]=[.75,.75,.75]
  if q[0]=='map_Kd':mats[name]=line.split(maxsplit=1)[1].replace('\\','/').split('/')[-1]
  if q[0]=='Kd':kd[name]=list(map(float,q[1:4]))
 for line in src.read_text().splitlines():
  q=line.split()
  if not q:continue
  if q[0]=='v':vs.append(Vector(map(float,q[1:4])))
  elif q[0]=='vn':ns.append(Vector(map(float,q[1:4])))
  elif q[0]=='vt':uv.append(tuple(map(float,q[1:3])))
  elif q[0]=='usemtl':mat=q[1]
  elif q[0]=='f':
   corners=[[int(x)-1 if x else None for x in c.split('/')]for c in q[1:]]
   for i in range(1,len(corners)-1):
    cs=[corners[0],corners[i],corners[i+1]];a,b,c=[vs[k[0]]for k in cs];normal=(b-a).cross(c-a).normalized();faces.append((mat,[dict(p=vs[k[0]].copy(),uv=uv[k[1]],n=ns[k[2]].copy()if len(k)>2 and k[2]is not None else normal.copy())for k in cs]))
 repaired_uv=0;repaired_normal=0
 for _,cs in faces:
  fallback=(cs[1]['p']-cs[0]['p']).cross(cs[2]['p']-cs[0]['p']).normalized()
  for c in cs:
   if not all(math.isfinite(x)for x in c['uv']):c['uv']=(.5,.5);repaired_uv+=1
   if not all(math.isfinite(x)for x in c['n'])or c['n'].length<1e-8:c['n']=fallback.copy();repaired_normal+=1
 original_count=len(faces)
 if key=='monopoly':
  # Keep every head/face/hat triangle exactly; only simplify below the neck.
  head=[f for f in faces if all(c['p'].y>neck for c in f[1])];body=[f for f in faces if f not in head];points=[];polys=[];lookup={};uvs=[]
  for _,cs in body:
   poly=[]
   for c in cs:
    pos=tuple(c['p'])
    if pos not in lookup:lookup[pos]=len(points);points.append(pos)
    poly.append(lookup[pos]);uvs.append(c['uv'])
   polys.append(poly)
  bpy.ops.wm.read_factory_settings(use_empty=True);me=bpy.data.meshes.new('body only');me.from_pydata(points,[],polys);me.update();layer=me.uv_layers.new(name='UVMap')
  for loop,coord in zip(layer.data,uvs):loop.uv=coord
  obj=bpy.data.objects.new('Monopoly body reduction',me);bpy.context.collection.objects.link(obj);bpy.context.view_layer.objects.active=obj;obj.select_set(True);mod=obj.modifiers.new('Keep face original','DECIMATE');mod.ratio=500/len(body);mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name);me=obj.data;me.calc_loop_triangles();faces=head+[(mat,[dict(p=me.vertices[vi].co.copy(),uv=tuple(me.uv_layers.active.data[li].uv),n=me.vertices[vi].normal.copy())for vi,li in zip(t.vertices,t.loops)])for t in me.loop_triangles]
  assert all(f in faces for f in head);assert len(faces)<=920
 materials=[];indices={}
 for mat,_ in faces:
  if mat in indices:continue
  tex=mats.get(mat);p=next((p for p in root.rglob('*.png')if p.name.lower()==str(tex).lower()),None)
  if p is None:
   tex='solid_'+mat+'.png';Image.new('RGBA',(4,4),tuple(round(x*255)for x in kd.get(mat,[.5,.5,.5]))+(255,)).save(D/tex);size=(4,4)
  else:shutil.copyfile(p,D/p.name);tex=p.name;size=Image.open(p).size
  indices[mat]=len(materials);materials.append(dict(name=mat,texture=tex,size=[min(64,2**round(math.log2(x)))for x in size]))
 points=[c['p']for _,cs in faces for c in cs];lo=min(p.y for p in points);hi=max(p.y for p in points);scale=height*100/(hi-lo);cx=(min(p.x for p in points)+max(p.x for p in points))/2
 pivots=[Vector((cx,lo,0)),Vector((cx,neck,0)),Vector((cx-shoulder,sy,0)),Vector((cx+shoulder,sy,0))]
 def integer(p):return[round((p.x-cx)*scale),round((p.y-lo)*scale),round(p.z*scale)]
 model=dict(bones=[dict(name=n,parent=-1 if i==0 else 0,position=integer(p)if i else[0,0,0])for i,(n,p)in enumerate(zip(['body','head','left_arm','right_arm'],pivots))],materials=materials,vertices=[],triangles=[],height_game_units=height,native_lighting=True,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest());lookup={}
 for mat,cs in faces:
  corners=[]
  for c in cs:
   p=c['p'].copy();n=c['n'].copy();bone=0
   if abs(p.x-cx)>shoulder and sy-.43<p.y<sy+.25:bone=2 if p.x<cx else 3
   elif p.y>neck and abs(p.x-cx)<(shoulder+.1):bone=1
   if bone>=2:
    rot=Matrix.Rotation(math.radians(angle if bone==2 else-angle),3,'Z');p=pivots[bone]+rot@(p-pivots[bone]);n=rot@n
   pos=integer(p);k=(bone,*pos)
   if k not in lookup:lookup[k]=len(model['vertices']);model['vertices'].append(dict(bone=bone,position=pos))
   corners.append(dict(vertex=lookup[k],uv=c['uv'],normal=[round(x*127)for x in n.normalized()]))
  model['triangles'].append(dict(material=indices[mat],corners=corners))
 (R/'tools'/f'{key}_source.json').write_text(json.dumps(model,separators=(',',':'))+'\n');S=D/'source';S.mkdir(exist_ok=True);shutil.copyfile(src,S/src.name);shutil.copyfile(src.with_suffix('.mtl'),S/src.with_suffix('.mtl').name);(S/'README.txt').write_text('User-supplied DS game model. Original proportions, small rigid head/arm gestures, offline relaxed arm pose. Monopoly: original 400 head/face/hat triangles preserved; body reduced. All source textures are one folder above. Export: tools/export_doof_guests.py.\n');report[key]=dict(original_triangles=original_count,triangles=len(faces),height_game_units=height,rigid_groups=4,repaired_uv_corners=repaired_uv,repaired_normal_corners=repaired_normal,source_sha256=model['source_sha256']);print(key,report[key],flush=True)
(W/'models.json').write_text(json.dumps(report,indent=2)+'\n')

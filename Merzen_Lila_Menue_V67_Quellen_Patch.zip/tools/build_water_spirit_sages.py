"""Full replacement of Adult Ruto/Nabooru objects; all native roles and frame counts retained."""
from pathlib import Path
import sys,json,re
from n64_model import emit
R=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();B=R/'originals/water_spirit_sages'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
for objectname,source,prefix,modeldir,skel in [('object_ru2','squid_sage','SquidSage','squid/textures','gAdultRutoSkel'),('object_nb','waluigi_sage','WaluigiSage','waluigi-party3','gNabooruSkel')]:
 A=O/'extracted/pal-1.0/assets/objects'/objectname;m=json.loads((R/(source+'_source.json')).read_text());s=emit(m,R.parent/'models'/modeldir,prefix,True)
 for label in m['animations']:s=s.replace('g'+prefix+label.title().replace('_','')+'Anim',label)
 (A/(source+'_model.inc.c')).write_text(s);p=A/(objectname+'.c');original(p);p.write_text('#include "'+objectname+'.h"\n#include "gfx.h"\n#include "sys_matrix.h"\n#include "'+source+'_model.inc.c"\n')
 eyes=['gAdultRutoEyeOpenTex','gAdultRutoEyeHalfTex','gAdultRutoEyeClosedTex'] if objectname=='object_ru2' else ['gNabooruEyeOpenTex','gNabooruEyeHalfTex','gNabooruEyeClosedTex','gNabooruEyeWideOpenTex']
 p.write_text(p.read_text()+'\n/* Unused native eye slots remain valid; the replacement has own face textures. */\n'+'\n'.join('u64 '+n+'[]={0};' for n in eyes)+'\n')
 p=A/(objectname+'.h');original(p);h='#pragma once\n#include "animation.h"\n#include "ultra64.h"\nextern FlexSkeletonHeader g'+prefix+'Skel;\n';h+='\n'.join('extern AnimationHeader '+n+';' for n in m['animations'])+'\n';h+='\n'.join('extern u64 '+n+'[];' for n in eyes)+'\n'
 if objectname=='object_nb':h+='#define NABOORU_LIMB_MAX 15\n#define NABOORU_LIMB_HEAD '+str(m['native_head_limb'])+'\n#define NABOORU_LIMB_TORSO '+str(m['native_torso_limb'])+'\n'
 p.write_text(h)
p=O/'src/overlays/actors/ovl_En_Ru2/z_en_ru2.h';s=original(p).replace('jointTable[23]','jointTable[28]').replace('morphTable[23]','morphTable[28]');p.write_text(s)
p=O/'src/overlays/actors/ovl_En_Ru2/z_en_ru2.c';s=original(p).replace('&gAdultRutoSkel','&gSquidSageSkel').replace('this->morphTable, 23)','this->morphTable, 28)');s=s.replace('Actor_SetFocus(&this->actor, 50.0f);','Actor_SetFocus(&this->actor, 70.0f);');p.write_text(s)
p=O/'src/overlays/actors/ovl_En_Nb/z_en_nb.c';s=original(p).replace('&gNabooruSkel','&gWaluigiSageSkel');a=s.index('    if (limbIndex == NABOORU_LIMB_HEAD)',s.index('s32 func_80AB2FC0('));b=s.index('\n    return 0;',a);s=s[:a]+'    /* Own Waluigi face; never substitute Nabooru\'s alternative head mesh. */\n'+s[b:]
# Keep attention/focus but restrict tracking to the real own head; no twisting the pelvis.
a=s.index('    if (this->headTurnFlag != 0)',s.index('s32 EnNb_OverrideLimbDraw('));b=s.index('\n    return ret;',a);s=s[:a]+'''    if (this->headTurnFlag != 0 && limbIndex == NABOORU_LIMB_HEAD) {
        rot->x += CLAMP(interactInfo->headRot.y, -0x0600, 0x0600);
        rot->z += CLAMP(interactInfo->headRot.x, -0x0600, 0x0600);
    }
'''+s[b:];p.write_text(s)
# Defeat reveal: native armor pieces over the same Waluigi body, never a one-frame Nabooru flash.
p=O/'src/overlays/actors/ovl_En_Ik/z_en_ik.c';s=original(p);s=s.replace('#include "assets/objects/object_ik/object_ik.h"','#include "assets/objects/object_ik/object_ik.h"\n#include "assets/objects/object_nb/object_nb.h"\n#include "object.h"\n#include "segmented_address.h"')
a=s.index('s32 EnIk_OverrideLimbDrawDefeat(');b=s.index('    return false;',a);needle='\n    return false;'
extra="""    if ((limbIndex >= IRON_KNUCKLE_DEFEAT_LIMB_RIGHT_THIGH && limbIndex <= IRON_KNUCKLE_DEFEAT_LIMB_LEFT_FOOT) ||
        limbIndex == IRON_KNUCKLE_DEFEAT_LIMB_HEAD ||
        (limbIndex >= IRON_KNUCKLE_DEFEAT_LIMB_RIGHT_UPPER_ARM && limbIndex <= IRON_KNUCKLE_DEFEAT_LIMB_LEFT_HAND) ||
        limbIndex == IRON_KNUCKLE_DEFEAT_LIMB_TORSO || limbIndex == IRON_KNUCKLE_DEFEAT_LIMB_WAIST) {
        *dList = NULL;
    }
"""
s=s[:b]+extra+s[b:];marker='void EnIk_CsDrawDefeat(EnIk* this, PlayState* play) {';s=s.replace(marker,'#include "waluigi_knuckle.inc.c"\n\n'+marker)
needle='                          EnIk_OverrideLimbDrawDefeat, EnIk_PostLimbDrawDefeat, this);';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    EnIk_DrawWaluigiReveal(this, play);');p.write_text(s)
(p.parent/'waluigi_knuckle.inc.c').write_bytes((R/'waluigi_knuckle.inc.c').read_bytes())
# Private medallion cameras; no changes to native cues, text or frame counts.
for actor,old,new in [('En_Ru2','gWaterMedallionCs','gSquidWaterMedallionCs'),('En_Nb','gSpiritMedallionCs','gWaluigiSpiritMedallionCs')]:
 p=O/('src/overlays/actors/ovl_'+actor+'/z_'+actor.lower()+'.c');s=p.read_text();marker='#include "z_'+actor.lower()+'_cutscene_data.inc.c"';assert s.count(marker)==1;s=s.replace(marker,marker+'\n#include "sage_medallion_cameras.inc.c"');s=s.replace('play->csCtx.script = '+old+';', 'play->csCtx.script = '+new+';');p.write_text(s)
 # Each overlay needs only its own private script, avoid unused script warnings.
 data=(R/'sage_medallion_cameras.inc.c').read_text();start=data.index('static CutsceneData '+new);end=data.index('};',start)+2;(p.parent/'sage_medallion_cameras.inc.c').write_text(data[start:end]+'\n')
print('Water/Spirit: Thaddaeus 27 own bones, Waluigi 14 own bones; 7/22 full native-length animations; every native role retained.')

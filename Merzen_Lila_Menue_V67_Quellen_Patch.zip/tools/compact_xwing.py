"""Reduce excessive geometry in the 24-unit LEGO prop while preserving materials."""
import bpy,bmesh,json,sys
from pathlib import Path
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);m=json.loads((R/'tools/xwing_source.json').read_text());bpy.ops.wm.read_factory_settings(use_empty=True)
mesh=bpy.data.meshes.new('XWing');mesh.from_pydata(m['vertices'],[],[[c['vertex']for c in t['corners']]for t in m['triangles']]);mesh.update()
for mat in m['materials']:
 material=bpy.data.materials.new(mat['name']);material.diffuse_color=mat['rgba'];mesh.materials.append(material)
for face,t in zip(mesh.polygons,m['triangles']):face.material_index=t['material']
bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.01);bm.to_mesh(mesh);bm.free();mesh.update()
obj=bpy.data.objects.new('LEGO X-Wing',mesh);bpy.context.collection.objects.link(obj);bpy.context.view_layer.objects.active=obj;obj.select_set(True)
mod=obj.modifiers.new('Small toy geometry budget','DECIMATE');mod.ratio=.15;mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name)
mesh=obj.data;mesh.calc_loop_triangles();out=dict(m);out['vertices']=[[float(x)for x in v.co]for v in mesh.vertices];out['triangles']=[dict(material=t.material_index,corners=[dict(vertex=v,normal=[round(x*127)for x in t.normal.normalized()])for v in t.vertices])for t in mesh.loop_triangles];out['memory_revision']=dict(original_triangles=len(m['triangles']),target='Small 24-unit decorative toy; preserve material colors and silhouette.')
print('Reduced triangles',len(out['triangles']),flush=True)
assert 800<=len(out['triangles'])<=3300
(R/'tools/xwing_compact_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n');(W/'xwing-storage.json').write_text(json.dumps(dict(original_triangles=len(m['triangles']),triangles=len(out['triangles']),native_room_collision_unchanged=True),indent=2)+'\n');print('X-Wing',len(m['triangles']),'->',len(out['triangles']),flush=True)

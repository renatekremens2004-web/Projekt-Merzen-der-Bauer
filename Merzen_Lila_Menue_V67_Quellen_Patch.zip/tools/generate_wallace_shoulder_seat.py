"""Fit a natural forward-knee shoulder seat to Wallace, preserving every mesh and bone length."""
from pathlib import Path
import bpy,json,math
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent.parent;p=R/'tools/bowling_sage_source.json';m=json.loads(p.read_text());rest=[Matrix(b['rest_matrix']) for b in m['bones']];idx={int(b['name'].split('_')[1]):i for i,b in enumerate(m['bones'])}
height=json.loads((R/'tools/wallace_adult_source.json').read_text())['height_game_units']
factor=height/110
seat=[0,96.25*factor,-6*factor]
root=[round((seat[i]-[1,2.25,-9][i])*100)for i in range(3)]
def angles(mat):return [round(a*32768/math.pi)%65536 for a in mat.to_euler('XYZ')]
def align(first,second,direction,world):
 a=idx[first];b=idx[second];source=(rest[b].translation-rest[a].translation).normalized();world[a]=source.rotation_difference(Vector(direction).normalized()).to_matrix()@rest[a].to_3x3()
for label,count in [('sit_idle',24),('sit_down',19),('sit_up',43)]:
 frames=[]
 for f in range(count):
  t=f/(count-1);ease=.5-.5*math.cos(math.pi*t);head_tilt=0 if label=='sit_idle' else (20*ease if label=='sit_down' else 20*(1-ease));world=[r.to_3x3().copy()for r in rest]
  # Legs go forward over the shoulder pads, with knees bent and shins almost vertical.
  # Former Darunia pose splayed both thighs AND shins sideways.
  for thigh,knee,foot,sign in [(3,4,5,-1),(6,7,8,1)]:
   align(thigh,knee,(sign*.55*factor,-.40,.73),world)
   align(knee,foot,(sign*.02,-.98,.20),world)
   world[idx[foot]]=Matrix.Rotation(math.radians(12),3,'X')@rest[idx[foot]].to_3x3()
  lean=Matrix.Rotation(math.radians(-2),3,'X')
  world[idx[20]]=lean@rest[idx[20]].to_3x3()
  world[idx[10]]=Matrix.Rotation(math.radians(head_tilt-2),3,'X')@rest[idx[10]].to_3x3()
  # Hands rest near the collar/shoulder line, with a small elbow bend.
  for upper,lower,hand,sign in [(13,14,15,1),(16,17,18,-1)]:
   align(upper,lower,(sign*.35,-.93,.10),world)
   align(lower,hand,(sign*.10,-.88,.46),world)
   world[idx[hand]]=world[idx[lower]]@rest[idx[lower]].to_3x3().inverted()@rest[idx[hand]].to_3x3()
  rotation=[]
  for i,b in enumerate(m['bones']):rotation.append(angles(world[b['parent']].inverted()@world[i]if b['parent']>=0 else world[i]))
  # Native actors differ by X +1, Y +2.25, Z -9. Compensate in local root.
  frames.append({'root':list(root),'rotation':rotation})
 m['animations'][label]=frames
m['credits']={'seat_reference':'Wallace HEV collar / upper back; native actor offset explicitly compensated','support_model_height':height,'root_model_units':root,'native_actor_offset_game_units':[1,2.25,-9],'seat_root_relative_to_wallace_game_units':seat,'thigh_direction':[.55*factor,-.40,.73],'shin_direction':[.02,-.98,.20],'torso_lean_back_degrees':2,'own_mesh_bones_and_uniform_scale_unchanged':True,'source_native_frame_counts':{'sit_down':19,'sit_up':43,'sit_idle':24,'seal':75}}
p.write_text(json.dumps(m,separators=(',',':'))+'\n');print('Wallace seat: forward thighs, hanging shins, collar support; all bone lengths retained.')

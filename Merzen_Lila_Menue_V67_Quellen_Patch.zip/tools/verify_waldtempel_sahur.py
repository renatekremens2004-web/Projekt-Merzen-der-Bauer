"""Verify Forest Temple / Sahur revision against the published Waldweise-v2 ROM and map."""
from pathlib import Path
import argparse,csv,hashlib,json,math,re,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as dialogue
ROOT=Path(__file__).resolve().parent.parent
BASE_SHA='59b69171d06cf38da8301e8290423405e583d7f13ab15008393cd8bb4cbd15f1'

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('oot',type=Path);ap.add_argument('baseline',type=Path);args=ap.parse_args()
    oot=args.oot.resolve();build=oot/'build/pal-1.0'
    old=args.baseline.read_bytes();packed=(build/'oot-pal-1.0-compressed.z64').read_bytes()
    plain=(build/'oot-pal-1.0.z64').read_bytes()
    assert hashlib.sha256(old).hexdigest()==BASE_SHA
    assert len(packed)==33554432 and packed[0x3e:0x40]==b'P\0'
    assert struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
    mp=(build/'oot-pal-1.0.map').read_text()
    symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):
        symbols.setdefault(name,int(address,16))
    def sym(name):
        return symbols[name]
    elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(build/'oot-pal-1.0.elf')],text=True)
    rels={};current=None
    for line in elf.splitlines():
        header=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
        if header:
            current=header[1];rels.setdefault(current,{})
        entry=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
        if current and entry:
            rels[current][int(entry[1],16)]=(entry[2],entry[3])
    intentional={'makerom','dmadata','code','ger_message_data_static','object_dekujr','ovl_Obj_Dekujr','ovl_Elf_Msg2','Bmori1_room_21'}
    identical=[];relocated=[];changed=[];verified=0;object_bytes=None
    names=[r['Name'] for r in csv.DictReader((oot/'baseroms/pal-1.0/segments.csv').open())]
    for index,name in enumerate(names):
        _,_,before=segment(old,index)
        start,end,unpacked=segment(packed,index)
        if unpacked is None:
            continue
        expected=plain[start:end]
        if name=='makerom':
            assert unpacked[:16]==expected[:16] and unpacked[24:]==expected[24:]
        elif name!='dmadata':
            assert unpacked==expected,('compression',name)
            verified+=1
        lo,hi=[sym('_'+name+'SegmentRom'+suffix) for suffix in ['Start','End']]
        after=plain[lo:hi]
        if name=='object_im':
            object_bytes=len(after)
            assert len(after)<=86016,('object memory budget exceeded',len(after))
        if before==after:
            identical.append(name);continue
        if name in intentional:
            changed.append({'segment':name,'before_bytes':len(before),'after_bytes':len(after)});continue
        assert len(before)==len(after),('unexpected size change',name,len(before),len(after))
        origin=sym('_'+name+'SegmentStart')
        differences=sorted({i//4*4 for i,(x,y) in enumerate(zip(before,after)) if x!=y})
        for offset in differences:
            rel=rels.get(name,{}).get(origin+offset)
            assert rel,('unexplained changed word',name,hex(origin+offset))
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[offset:offset+2]==after[offset:offset+2],(name,rel)
            elif kind=='R_MIPS_26':
                assert before[offset]>>2==after[offset]>>2,(name,rel)
            else:
                assert kind=='R_MIPS_32',(name,rel)
        relocated.append({'segment':name,'relocated_words':len(differences)})
    assert verified==1509
    # Read the actual ROM language tables, rather than trusting generated JSON alone.
    # Symbols from the SHA256-pinned published baseline ELF.
    old_symbols={}
    def german_messages(rom,tab,code_base):
        _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'))
        off=tab-code_base;entries=[]
        # PAL German table contains only pointers; IDs/order come from NES entries.
        ids=[];nes=(old_symbols if rom==args.baseline.read_bytes() else symbols)['sNesMessageEntryTable']-code_base
        while True:
            ident=struct.unpack_from('>H',code,nes)[0]
            if ident==0xffff:break
            if ident!=0xfffc:ids.append(ident)
            nes+=8
        for i,ident in enumerate(ids):entries.append((ident,struct.unpack_from('>I',code,off+4*i)[0]&0xffffff))
        result={}
        for i,(ident,start) in enumerate(entries):
            end=entries[i+1][1] if i+1<len(entries) else len(data)
            result[ident]=data[start:end].rstrip(bytes([0]))
        return result
    _,_,before_code=segment(args.baseline.read_bytes(),names.index('code'))
    _,_,after_code=segment(packed,names.index('code'))
    baseline_map=(args.baseline.parent/'baseline.map').read_text()
    baseline_symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',baseline_map):
        baseline_symbols.setdefault(name,int(address,16))
    old_symbols=baseline_symbols
    oldbase=baseline_symbols['_codeSegmentStart'];newbase=sym('_codeSegmentStart')
    anchors={oldbase:(newbase,['_codeSegmentStart'])}
    for name,addr in baseline_symbols.items():
        if name not in symbols:continue
        current=sym(name)
        if oldbase<=addr<oldbase+len(before_code) and newbase<=current<newbase+len(after_code):
            if addr in anchors:
                assert anchors[addr][0]==current,('alias movement',name)
                anchors[addr][1].append(name)
            else:anchors[addr]=(current,[name])
    anchors[oldbase+len(before_code)]=(newbase+len(after_code),['code ROM end'])
    order=sorted(anchors);code_relocations=[];padding=[]
    for lo,hi in zip(order,order[1:]):
        start,names_at=anchors[lo];end=anchors[hi][0]
        before=before_code[lo-oldbase:hi-oldbase];after=after_code[start-newbase:end-newbase]
        if len(before)!=len(after):
            common=min(len(before),len(after));assert abs(len(before)-len(after))<=16,('unexpected interval growth',names_at,len(before),len(after))
            assert all(x==0 for x in before[common:]+after[common:]),('non-padding growth',names_at)
            padding.append({'symbols':names_at,'before':len(before),'after':len(after)})
        common=min(len(before),len(after));assert common%4==0
        for i in range(0,common,4):
            if baseline_symbols['sGerMessageEntryTable']<=lo+i<baseline_symbols['sFraMessageEntryTable']:continue
            if before[i:i+4]==after[i:i+4]:continue
            addr=start+i;rel=rels.get('code',{}).get(addr);assert rel,('unexpected core word',hex(addr),names_at)
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[i:i+2]==after[i:i+2],(hex(addr),rel)
            elif kind=='R_MIPS_26':assert before[i]>>2==after[i]>>2,(hex(addr),rel)
            else:
                assert kind=='R_MIPS_32',rel
                oldword=struct.unpack_from('>I',before,i)[0];newword=struct.unpack_from('>I',after,i)[0]
                if target=='..code':
                    import bisect
                    assert oldbase<=oldword<baseline_symbols['_codeSegmentEnd'],('section pointer',hex(oldword))
                    if oldword>=order[-1]:expected=oldword+sym('_codeSegmentDataStart')-baseline_symbols['_codeSegmentDataStart']
                    else:
                        key=order[bisect.bisect_right(order,oldword)-1];expected=anchors[key][0]+oldword-key
                    assert newword==expected,('section pointer movement',hex(addr),hex(oldword),hex(newword),hex(expected))
                else:
                    assert (oldword-baseline_symbols[target])&0xffffffff == (newword-sym(target))&0xffffffff,('relocation addend',hex(addr),target)
            code_relocations.append({'address':hex(addr),'type':kind,'target':target})

    old_rom=args.baseline.read_bytes()
    before_text=german_messages(old_rom,old_symbols['sGerMessageEntryTable'],old_symbols['_codeSegmentStart'])
    after_text=german_messages(packed,sym('sGerMessageEntryTable'),sym('_codeSegmentStart'))
    changed_ids={i for i in before_text if before_text[i]!=after_text[i]}
    expected={0x7054,0x014E,0x0151,0x018C,0x018D,0x018F,0x0190,0x0191,0x0192,0x0194,0x0195,0x0197,0x0198,0x0105,0x0109,0x1062,0x1063,0x1064,0x1065,0x1066,0x1078}
    assert changed_ids==expected,sorted(hex(x) for x in changed_ids^expected)
    assert {0x0120,0x0150,0x014D,0x0107,0x015F}.isdisjoint(changed_ids)
    assert {'object_sa','object_zo','object_im','object_rl','bdan_room_3','spot01_room_0','HAKAdan_room_0'}<=set(identical)
    edits={}
    native=dialogue.messages((ROOT/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
    current=dialogue.messages((oot/'extracted/pal-1.0/text/message_data.h').read_text())
    chain={'704F':'0121','0121':'0122','0122':'0123'}
    for path in (ROOT/'story').glob('*.json'):
        for ident,entry in json.loads(path.read_text())['messages'].items():
            assert ident not in edits;edits[ident]=entry
            src=native[entry.get('native_template',ident)]['parts'][2][2];dst=current[ident]['parts'][2][2]
            assert dialogue.controls(src)+(['TEXTID(0x'+chain[ident]+')'] if ident in chain else [])==dialogue.controls(dst),ident
    assert len(edits)==724
    assert dialogue.controls(current['1065']['parts'][2][2])==['BOX_BREAK_DELAYED(90)']*4+['FADE(90)']
    # Native rise movement/cues are literally unchanged; no timing scripts edited.
    from verify_bowling_sage_revision import function_bodies
    rel='src/overlays/actors/ovl_Obj_Dekujr/z_obj_dekujr.c'
    before=function_bodies((ROOT/'tools/originals/sahur'/rel).read_text());after=function_bodies((oot/rel).read_text())
    for name in ['ObjDekujr_GetCueStartPos','ObjDekujr_GetCueEndPos','ObjDekujr_ComeUp']:assert before[name]==after[name],name
    assert ('static '+before['ObjDekujr_Draw'].replace('ObjDekujr_Draw','ObjDekujr_DrawNative'))==after['ObjDekujr_DrawNative']
    rel='src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';before=function_bodies((ROOT/'tools/originals/majora'/rel).read_text());after=function_bodies((oot/rel).read_text())
    assert set(after)-set(before)=={'ElfMsg2_DrawMajoraMask'}
    assert {k for k in before if before[k]!=after[k]}=={'ElfMsg2_Init'}
    assert len(segment(old,names.index('object_dekujr'))[2])==13584
    old_deku=segment(old,names.index('object_dekujr'))[2];new_deku=segment(packed,names.index('object_dekujr'))[2];assert new_deku.startswith(old_deku)
    model=json.loads((ROOT/'tools/sahur_source.json').read_text());assert len(model['bones'])==25 and len(model['triangles'])==1436 and model['height']==5400
    def traverse(i):
        return [i]+[j for k,b in enumerate(model['bones']) if b['parent']==i for j in traverse(k)]
    assert traverse(0)==list(range(25)), 'Flex matrix order must match bone order'
    for anim in model['animations'].values():
        for frame in anim:assert set(frame)=={'root','rotation'} and len(frame['rotation'])==25
    for t in model['triangles']:
        for corner in t['corners']:assert abs(math.sqrt(sum(x*x for x in corner['normal']))-127)<1.1
    obj=dict((enum,name) for name,enum in re.findall(r'DEFINE_OBJECT\((\w+), (\w+)\)',(oot/'include/tables/object_table.h').read_text()))
    budgets=[]
    for path in (oot/'extracted/pal-1.0/assets/scenes').rglob('*ObjectList.inc.c'):
        if 'OBJECT_DEKUJR' not in path.read_text():continue
        objs=['gameplay_keep','object_link_boy','gameplay_field_keep']+[obj[x] for x in re.findall(r'\bOBJECT_\w+',path.read_text())]
        size=sum(sym('_'+x+'SegmentRomEnd')-sym('_'+x+'SegmentRomStart') for x in dict.fromkeys(objs));cap=1000*1024-4096
        assert size<cap,(path,size,cap)
        budgets.append({'room':str(path.relative_to(oot/'extracted/pal-1.0/assets/scenes')),'bytes':size,'capacity':cap,'remaining':cap-size})
    mask=json.loads((ROOT/'tools/majora_source.json').read_text());assert len(mask['triangles'])==102
    assert max(v['position'][0] for v in mask['vertices'])-min(v['position'][0] for v in mask['vertices'])==2200
    room=oot/'extracted/pal-1.0/assets/scenes/dungeons/Bmori1/Bmori1_room_21_03000054_ActorEntryList.inc.c'
    original=(ROOT/'tools/originals/majora'/room.relative_to(oot)).read_text();assert room.read_text().startswith(original) and room.read_text().count('ACTOR_')==3
    assert 'ACTOR_ELF_MSG2' not in original
    report={'rom_sha256':hashlib.sha256(packed).hexdigest(),'rom_bytes':len(packed),'baseline_sha256':BASE_SHA,'compressed_segments_verified':verified,'identical_segments':identical,'relocated_segments':relocated,'intentional_changes':changed,'core_relocations_checked':len(code_relocations),'changed_german_ids':sorted(f'{x:04X}' for x in changed_ids),'dialogue_buffers':check_buffers(build,edits),'sahur_object_bytes':len(new_deku),'sahur_room_budgets':budgets,'native_rise_and_text_times_preserved':True,'mask_room':21,'mask_triangles':102,'sahur_triangles':1436}
    (build/'waldtempel-sahur-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Verified',verified,'compressed segments;',len(identical),'identical;',len(changed_ids),'changed German messages; all 724 controls/buffers; native rise/timings; room budgets.')
if __name__=='__main__':main()

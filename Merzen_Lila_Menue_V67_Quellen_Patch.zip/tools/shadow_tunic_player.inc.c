/* Called once by the native item-receipt action, never by the frame loop. */
static void Player_ReceiveShadowTunic(PlayState* play, Player* this) {
    u16 tunicMask = (u16)(0xF << (EQUIP_TYPE_TUNIC * 4));
    u16 tunic = EQUIP_VALUE_TUNIC_KOKIRI << (EQUIP_TYPE_TUNIC * 4);

    SET_INFTABLE(SHADOW_TUNIC_FLAG);
    Inventory_ChangeEquipment(EQUIP_TYPE_TUNIC, EQUIP_VALUE_TUNIC_KOKIRI);
    gSaveContext.save.info.playerData.childEquips.equipment =
        (gSaveContext.save.info.playerData.childEquips.equipment & ~tunicMask) | tunic;
    gSaveContext.save.info.playerData.adultEquips.equipment =
        (gSaveContext.save.info.playerData.adultEquips.equipment & ~tunicMask) | tunic;
    Player_SetEquipmentData(play, this);
}

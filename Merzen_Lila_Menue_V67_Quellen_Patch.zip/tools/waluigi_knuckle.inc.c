/* Render the same own-proportioned Waluigi under the falling Iron Knuckle armor.
 * Native armor animation, cues, battle, sounds and defeat flags remain in En_Ik.
 * Object NB is already present in every native confrontation room layer. */
static void EnIk_DrawWaluigiReveal(EnIk* this, PlayState* play) {
    s32 slot = Object_GetSlot(&play->objectCtx, OBJECT_NB);
    u32 oldSegment;
    FlexSkeletonHeader* skeleton;
    Vec3s joints[NABOORU_LIMB_MAX];
    AnimationHeader* animation;
    JointIndex* indices;
    s16* data;
    s16 frame = this->skelAnime.curFrame;
    s32 i;
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) {
        return;
    }
    oldSegment = gSegments[6];
    gSegments[6] = OS_K0_TO_PHYSICAL(play->objectCtx.slots[slot].segment);
    skeleton = SEGMENTED_TO_VIRTUAL(&gWaluigiSageSkel);
    animation = SEGMENTED_TO_VIRTUAL(&gWaluigiKnuckleRevealAnim);
    indices = SEGMENTED_TO_VIRTUAL(animation->jointIndices);
    data = SEGMENTED_TO_VIRTUAL(animation->frameData);
    frame = CLAMP(frame, 0, animation->common.frameCount - 1);
    for (i = 0; i < NABOORU_LIMB_MAX; i++) {
        joints[i].x = data[indices[i].x < animation->staticIndexMax ? indices[i].x : indices[i].x + frame];
        joints[i].y = data[indices[i].y < animation->staticIndexMax ? indices[i].y : indices[i].y + frame];
        joints[i].z = data[indices[i].z < animation->staticIndexMax ? indices[i].z : indices[i].z + frame];
    }
    OPEN_DISPS(play->state.gfxCtx, "waluigi-reveal", 1);
    gSPSegment(POLY_OPA_DISP++, 6, play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++, 0x0C, ACTOR_SETUP_OPA_DL);
    gDPSetEnvColor(POLY_OPA_DISP++, 0, 0, 0, 255);
    Matrix_Push();
    /* En_Ik is 0.012; keep Waluigi at the same 0.01 as the NPC. */
    Matrix_Scale(0.83333333f, 0.83333333f, 0.83333333f, MTXMODE_APPLY);
    SkelAnime_DrawFlexOpa(play, SEGMENTED_TO_VIRTUAL(skeleton->sh.segment), joints, skeleton->dListCount,
                         NULL, NULL, this);
    Matrix_Pop();
    gSegments[6] = oldSegment;
    gSPSegment(POLY_OPA_DISP++, 6, OS_PHYSICAL_TO_K0(oldSegment));
    CLOSE_DISPS(play->state.gfxCtx, "waluigi-reveal", 2);
}

"""Small mask found in an inner western corridor, never in the entrance or hub."""
from pathlib import Path
import sys,json
from n64_model import emit
ROOT=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();B=ROOT/'originals/majora';D=O/'extracted/pal-1.0/assets/scenes/dungeons/Bmori1';A=O/'src/overlays/actors/ovl_Elf_Msg2'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
m=json.loads((ROOT/'majora_source.json').read_text());(D/'majora_mask_model.inc.c').write_text(emit(m,ROOT.parent/'models/majora','MajoraMask'))
p=D/'Bmori1_room_21.c';p.write_text(original(p)+'\n#include "majora_mask_model.inc.c"\n')
p=D/'Bmori1_room_21_03000054_ActorEntryList.inc.c';s=original(p);assert s.count('ACTOR_')==2;p.write_text(s+'''    {
        ACTOR_ELF_MSG2,
        { -1940, 444, -3220 }, /* original corridor floor Y=443; no doorway obstruction */
        { 0x0002, 0x0000, 0x0001 }, /* native repeatable Z/C-Up, no save switch */
        0x3F09, /* private message 0109 */
    },
''')
p=D/'Bmori1_room_21.h';s=original(p);old='#define LENGTH_Bmori1_room_21_03000054_ActorEntryList 2';assert s.count(old)==1;p.write_text(s.replace(old,old[:-1]+'3'))
p=A/'z_elf_msg2.c';s=original(p);s=s.replace('extern Gfx gNintendo64DL[];','extern Gfx gNintendo64DL[];\nextern Gfx gMajoraMaskDL[];\nstatic void ElfMsg2_DrawMajoraMask(Actor* thisx, PlayState* play);')
needle='        /* One German decoration; all other check spots retain their native setup. */';assert s.count(needle)==1
s=s.replace(needle,'''        /* Room 21 is a later west-side corridor, below the twisted hallway. */
        if (play->sceneId == SCENE_FOREST_TEMPLE && thisx->room == 21 && thisx->params == 0x3F09) {
            if (gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 5.0f);
            thisx->draw = ElfMsg2_DrawMajoraMask;
        }
'''+needle)
# Share the room-segment-safe existing N64 drawing path, preserving its old behavior.
start=s.index('static void ElfMsg2_DrawNintendo64(Actor* thisx, PlayState* play) {');draw=s[start:].replace('ElfMsg2_DrawNintendo64','ElfMsg2_DrawMajoraMask').replace('gNintendo64DL','gMajoraMaskDL').replace('"nintendo64"','"majoras-mask"');s+='\n'+draw;p.write_text(s)
print('Mask: 102 triangles, 22-unit width; native corridor21 target; Jabu console unchanged.')

"""Binary validation of the Phantom Amthor revision against the published mask build."""
from pathlib import Path
import sys,csv,hashlib,re,json,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as story
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0'
before=(W/'baseline.z64').read_bytes();packed=(B/'oot-pal-1.0-compressed.z64').read_bytes();plain=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(before).hexdigest()=='03fd8d7124b11ea661b9d2b506a2c61ca076ce2279029557edcceda69c55aaa6'
assert len(packed)==33554432 and struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
def symbols(path):
 d={}
 for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',path.read_text()):d.setdefault(n,int(a,16))
 return d
old=symbols(W/'baseline.map');new=symbols(B/'oot-pal-1.0.map');names=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())]
relocs={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if m:section=m[1];relocs.setdefault(section,{})
 m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if m and section:relocs[section][int(m[1],16)]=(m[2],m[3])
def relocated(a,b,base,segment_name):
 assert len(a)==len(b),(segment_name,'length')
 changed=sorted({i//4*4 for i,(x,y) in enumerate(zip(a,b))if x!=y})
 for i in changed:
  if segment_name=='code' and new['sNesMessageEntryTable']<=base+i<new['sGerMessageEntryTable'] and a[i:i+4]==bytes.fromhex('209b0000') and b[i:i+4]==bytes.fromhex('209b0300'):
   continue  # Dedicated, previously unused greeting: bottom textbox placement.
  rel=relocs.get(segment_name,{}).get(base+i);assert rel,(segment_name,hex(base+i),'unexplained change')
  kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert a[i:i+2]==b[i:i+2],(segment_name,hex(base+i),kind)
  elif kind=='R_MIPS_26':assert a[i]>>2==b[i]>>2
  else:assert kind=='R_MIPS_32',(segment_name,kind)
 return len(changed)
intentional={'makerom','dmadata','ger_message_data_static','object_gnd','object_fhg','ovl_Boss_Ganondrof','ovl_En_fHG','ovl_En_Hy'}
identical=[];rels=[];changes=[];decompressed=0;segments={}
for i,name in enumerate(names):
 start,end,b=segment(packed,i);_,_,a=segment(before,i)
 if b is None:continue
 if name!='dmadata':
  if name=='makerom':assert b[:16]==plain[start:start+16] and b[24:]==plain[start+24:end]
  else:assert b==plain[start:end],name;decompressed+=1
 segments[name]=(a,b)
 if a==b:identical.append(name)
 elif name in intentional:changes.append(dict(segment=name,before_bytes=len(a),after_bytes=len(b)))
 else:rels.append(dict(segment=name,changed_relocated_words=relocated(a,b,new['_'+name+'SegmentStart'],name)))
assert decompressed==1509
# Compare actual German-language tables against the authored delta manifest.
def messages(rom,syms):
 _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'));base=syms['_codeSegmentStart'];n=syms['sNesMessageEntryTable']-base;ids=[]
 while True:
  ident=struct.unpack_from('>H',code,n)[0];n+=8
  if ident==65535:break
  if ident!=65532:ids.append(ident)
 table=syms['sGerMessageEntryTable']-base;offsets=[struct.unpack_from('>I',code,table+4*i)[0]&0xffffff for i in range(len(ids))]+[len(data)]
 return {f'{ident:04X}':data[offsets[i]:offsets[i+1]].rstrip(b'\0')for i,ident in enumerate(ids)}
a=messages(before,old);b=messages(packed,new);changed=[i for i in a if a[i]!=b[i]];assert set(changed)==set(json.loads((W/'expected-message-changes.json').read_text())),changed
oldtext=story.messages((W/'baseline_message_data.h').read_text());text=story.messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
for ident,item in text.items():
 for lang in [0,1,3]:assert item['parts'][lang][2]==oldtext[ident]['parts'][lang][2],(ident,lang)
 if ident!='209B':assert item['header']==oldtext[ident]['header'],ident
 assert story.controls(item['parts'][2][2])==story.controls(oldtext['002D' if ident=='209B' else ident]['parts'][2][2]),ident
assert 'TEXTBOX_POS_BOTTOM' in text['209B']['header']
assert story.plain(text['209B']['parts'][2][2]).strip()=='Sooo, genug Schabernack!'
assert 'Deku-Wurm' not in story.plain(text['1045']['parts'][2][2])
assert story.plain(text['1045']['parts'][2][2]).count('Deku-Baum')==3
# No horse mesh/animation changes: only the middle PAL name plate may differ.
a,b=segments['object_fhg'];offset=new['gPhantomGanonTitleCardTex']-new['_object_fhgSegmentStart'];assert len(a)==len(b)
assert a[:offset+5120]==b[:offset+5120] and a[offset+10240:]==b[offset+10240:]
assert a[offset+5120:offset+10240]!=b[offset+5120:offset+10240]
# Every retained original object_gnd symbol must be byte-identical except for
# its real linker relocations. This includes every native animation and limb.
a,b=segments['object_gnd'];base_old=old['_object_gndSegmentStart'];base_new=new['_object_gndSegmentStart'];retained=0
nm=subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'assets/objects/object_gnd/object_gnd.o')],text=True)
for _,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) (\w) (\S+)$',nm,re.M):
 if name.startswith('gAmthor') or name in ['gPhantomGanonFaceDL','object_gnd_0080F8_DL'] or name not in old or name not in new:continue
 n=int(size,16);before_offset=old[name]-base_old;after_offset=new[name]-base_new
 if not 0<=before_offset<len(a) or not 0<=after_offset<len(b):continue
 relocated(a[before_offset:before_offset+n],b[after_offset:after_offset+n],new[name],'object_gnd');retained+=1
assert retained>100,retained
# The head clear-pixel mapping cannot leave its CI4 buffer for any native index.
for label in ['burns','smithers']:
 m=json.loads((R/'tools'/('phantom_'+label+'_source.json')).read_text())
 for mat in m['materials']:
  w,h=mat['size']
  for index in range(256):
   for y in range(h//16):
    for x in range(w//16):assert 0<=(((index//16)*(h//16)+y)*w+(index%16)*(w//16)+x)//2<w*h//2
edits={i:e for p in (R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};buffer=check_buffers(B,edits)
report=dict(rom_sha256=hashlib.sha256(packed).hexdigest(),baseline_sha256=hashlib.sha256(before).hexdigest(),rom_bytes=len(packed),compressed_segments_verified=decompressed,identical_segments=identical,relocated_segments=rels,intentional_segments=changes,changed_german_messages=changed,retained_phantom_symbols_checked=retained,horse_except_german_title_byte_identical=True,all_other_models_and_scenes_preserved=True,native_controls_and_fixed_times_preserved=True,story_count=len(edits),text_buffers=buffer)
(B/'phantom-amthor-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified 1509 segments, '+str(len(changed))+' German messages,',retained,'retained Phantom symbols;',len(edits),'buffers; native horse, skeleton, animations and combat preserved.')

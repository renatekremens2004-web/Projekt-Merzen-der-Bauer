"""Verify the proportion revision against the previous Bean release ROM.

Usage: python tools/verify_bean_revision.py OOT PREVIOUS_BEAN_ROM.z64
Run in the OOT Python environment, with MIPS binutils on PATH.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import re
import struct
import subprocess
from ipl3checksum import CICKind, calculateChecksum
from verify_story import segment, check_buffers

ROOT = Path(__file__).resolve().parent.parent
BASE_SHA = '2c33901bb6f34e66a84ce2cfecca84bdaf4469d01528f4898950fa19425f76d3'


def function_bodies(source):
    clean = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:[^"\\]|\\.)*"',
                   lambda m: ' ' * len(m[0]), source, flags=re.S)
    out = {}
    for match in re.finditer(r'(?m)^[\w *]+\s+(\w+)\([^;{}]*\)\s*\{', clean):
        depth, end = 1, match.end()
        while depth:
            depth += (clean[end] == '{') - (clean[end] == '}')
            end += 1
        out[match[1]] = clean[match.start():end]
    return out


def geometry():
    model = json.loads((ROOT/'tools/bean_bound.json').read_text())
    source = json.loads((ROOT/'tools/bean_source.json').read_text())
    assert len(model['triangles']) == len(source['triangles']) == 1258
    assert len(model['bones']) == 16 and len(model['palette']) == 15
    assert len(model['texture']) == 128*128 and len(model['texture_palette']) == 256*3
    pairs, maximum_error = set(), 0
    for triangle in model['triangles']:
        assert len(triangle) == 3 and all(0 <= i < len(model['vertices']) for i in triangle)
        for a,b in zip(triangle,triangle[1:]+triangle[:1]):
            pairs.add(tuple(sorted((a,b))))
    for vertex in model['vertices']:
        assert vertex['bone'] in model['palette']
        assert all(-32768 <= v < 32768 for v in vertex['position']+vertex['uv'])
        assert abs(math.sqrt(sum(n*n for n in vertex['normal']))-127) <= 1
    edges = 0
    for a,b in pairs:
        va,vb = model['vertices'][a],model['vertices'][b]
        if va['bone'] != vb['bone']:
            continue
        sa,sb = (source['vertices'][v['source_vertex']]['position'] for v in [va,vb])
        expected = math.dist(sa,sb)*model['scale']
        actual = math.dist(va['position'],vb['position'])
        error = abs(actual-expected)
        assert error < 1.74, (a,b,error)
        maximum_error=max(maximum_error,error)
        edges += 1
    assert edges > 1000
    return {'source_triangles':1258,'output_triangles':1258,'uniform_scale':model['scale'],
            'rigid_edges_checked':edges,'maximum_edge_quantization_error':maximum_error,
            'normalized_lighting_normals':True,'native_limb_count':16,'native_matrix_count':15}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('oot',type=Path)
    ap.add_argument('baseline',type=Path)
    args=ap.parse_args()
    oot=args.oot.resolve();build=oot/'build/pal-1.0'
    old=args.baseline.read_bytes();packed=(build/'oot-pal-1.0-compressed.z64').read_bytes()
    plain=(build/'oot-pal-1.0.z64').read_bytes()
    assert hashlib.sha256(old).hexdigest()==BASE_SHA
    assert len(packed)==33554432 and packed[0x3e:0x40]==b'P\0'
    assert struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
    mp=(build/'oot-pal-1.0.map').read_text()
    symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):
        symbols.setdefault(name,int(address,16))
    def sym(name):
        return symbols[name]
    elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(build/'oot-pal-1.0.elf')],text=True)
    rels={};current=None
    for line in elf.splitlines():
        header=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
        if header:
            current=header[1];rels.setdefault(current,{})
        entry=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
        if current and entry:
            rels[current][int(entry[1],16)]=(entry[2],entry[3])
    intentional={'makerom','dmadata','object_im','ovl_Demo_Im','spot00_scene','nakaniwa_scene'}
    identical=[];relocated=[];changed=[];verified=0;object_bytes=None
    names=[r['Name'] for r in csv.DictReader((oot/'baseroms/pal-1.0/segments.csv').open())]
    for index,name in enumerate(names):
        _,_,before=segment(old,index)
        start,end,unpacked=segment(packed,index)
        if unpacked is None:
            continue
        expected=plain[start:end]
        if name=='makerom':
            assert unpacked[:16]==expected[:16] and unpacked[24:]==expected[24:]
        elif name!='dmadata':
            assert unpacked==expected,('compression',name)
            verified+=1
        lo,hi=[sym('_'+name+'SegmentRom'+suffix) for suffix in ['Start','End']]
        after=plain[lo:hi]
        if name=='object_im':
            object_bytes=len(after)
            assert len(after)<=74288,('native object budget exceeded',len(after))
        if before==after:
            identical.append(name);continue
        if name in intentional:
            changed.append({'segment':name,'before_bytes':len(before),'after_bytes':len(after)});continue
        assert len(before)==len(after),('unexpected size change',name,len(before),len(after))
        origin=sym('_'+name+'SegmentStart')
        differences=sorted({i//4*4 for i,(x,y) in enumerate(zip(before,after)) if x!=y})
        for offset in differences:
            rel=rels.get(name,{}).get(origin+offset)
            assert rel,('unexplained changed word',name,hex(origin+offset))
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[offset:offset+2]==after[offset:offset+2],(name,rel)
            elif kind=='R_MIPS_26':
                assert before[offset]>>2==after[offset]>>2,(name,rel)
            else:
                assert kind=='R_MIPS_32',(name,rel)
        relocated.append({'segment':name,'relocated_words':len(differences)})
    assert verified==1509
    opening='src/overlays/gamestates/ovl_opening/z_opening.c'
    assert (oot/opening).read_bytes()==subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+opening])
    rel='src/overlays/actors/ovl_Demo_Im/z_demo_im.c'
    vanilla=function_bodies(subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+rel],text=True))
    actual=function_bodies((oot/rel).read_text())
    assert vanilla.keys()==actual.keys()
    function_changes={k for k in vanilla if vanilla[k]!=actual[k]}
    assert function_changes=={'func_80985EF4','DemoIm_DrawSolid','DemoIm_DrawTranslucent'},function_changes
    allowed={rel,'src/code/z_sram.c','src/overlays/actors/ovl_En_Ganon_Mant/z_en_ganon_mant.c',
             'src/overlays/actors/ovl_En_Viewer/z_en_viewer.c'}
    source_changes=set(subprocess.check_output(['git','-C',str(oot),'diff','--name-only','HEAD','--','src','include'],text=True).splitlines())
    assert source_changes<=allowed,source_changes
    edits={}
    for chapter in sorted((ROOT/'story').glob('*.json')):
        for ident,entry in json.loads(chapter.read_text())['messages'].items():
            assert ident not in edits;edits[ident]=entry
    assert len(edits)==182
    report={'version':'German PAL 1.0; Bean source proportions revision',
            'rom_sha256':hashlib.sha256(packed).hexdigest(),'rom_bytes':len(packed),
            'baseline_sha256':BASE_SHA,'compressed_segments_verified':verified,
            'identical_segments':identical,'relocated_segments':relocated,'intentional_changes':changed,
            'native_gameplay_instructions_preserved':True,'normal_start_preserved':True,
            'impa_modified_functions':sorted(function_changes),'object_bytes':object_bytes,
            'native_object_budget_bytes':74288,'geometry':geometry(),'text_buffers':check_buffers(build,edits)}
    output=build/'bean-proportions-verification.json'
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['identical_segments','relocated_segments','text_buffers']},indent=2))


if __name__=='__main__':
    main()

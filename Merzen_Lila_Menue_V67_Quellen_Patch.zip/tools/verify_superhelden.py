"""Binary, relocation, damage, model, native scene and dialogue isolation for three superhero NPCs."""
from pathlib import Path
import sys,csv,re,json,hashlib,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as story
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';a=(W/'baseline.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();plain=(B/'oot-pal-1.0.z64').read_bytes();assert hashlib.sha256(a).hexdigest()=='dfa18e3c0db488033ebc9254e12725901a0a56e5dbea420263ce4730e5d9ce71'
assert len(b)==33554432 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
def symbols(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
old=symbols(W/'baseline.map');new=symbols(B/'oot-pal-1.0.map');names=[x['Name']for x in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];relocs={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if m:section=m[1];relocs.setdefault(section,{})
 m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if m and section:relocs[section][int(m[1],16)]=(m[2],m[3])
def relocated(x,y,base,name):
 assert len(x)==len(y),(name,'length',len(x),len(y));changes=sorted({j//4*4 for j,(q,r)in enumerate(zip(x,y))if q!=r})
 for j in changes:
  rel=relocs.get(name,{}).get(base+j);assert rel,(name,hex(base+j),'unexplained change');kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[j:j+2]==y[j:j+2]
  elif kind=='R_MIPS_26':assert x[j]>>2==y[j]>>2
  else:assert kind=='R_MIPS_32',kind
 return len(changes)
intentional={'makerom','dmadata','ger_message_data_static','code','ovl_Elf_Msg2','ovl_En_Torch2','ovl_En_Dekubaba','ovl_En_Fw','Bmori1_room_3','Bmori1_room_5','HAKAdan_room_12'};segments={};changed=[];identical=[];relocated_segments=[];verified=0
for i,name in enumerate(names):
 start,end,y=segment(b,i);_,_,x=segment(a,i)
 if y is None:continue
 segments[name]=(x,y)
 if name!='dmadata':
  if name=='makerom':assert y[:16]==plain[start:start+16] and y[24:]==plain[start+24:end]
  else:assert y==plain[start:end],name;verified+=1
 if x==y:identical.append(name)
 elif name in intentional:changed.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)))
 else:relocated_segments.append(dict(segment=name,changed_words=relocated(x,y,new['_'+name+'SegmentStart'],name)))
assert verified==1509

nm=subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'oot-pal-1.0.elf')],text=True);functions=re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([Tt]) (\S+)$',nm,re.M);retained={};checked_names=set()
excluded={'ElfMsg2_Init','ElfMsg2_Destroy','ElfMsg2_Update','CollisionCheck_ApplyDamage','EnTorch2_Init','EnDekubaba_CheckCollide','EnFw_CheckCollider'}
func_addrs={int(q[1],16)for line in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(B/'oot-pal-1.0.elf')],text=True).splitlines()if len(q:=line.split())>=8 and q[3]=='FUNC'}
for seg in ['code','ovl_Elf_Msg2','ovl_En_Torch2','ovl_En_Dekubaba','ovl_En_Fw']:
 x,y=segments[seg];count=0
 for addr,size,kind,name in functions:
  address=int(addr,16);length=int(size,16)
  if address not in func_addrs or name in excluded or name not in old or not new['_'+seg+'SegmentStart']<=address<new['_'+seg+'SegmentEnd']or not old['_'+seg+'SegmentStart']<=old[name]<old['_'+seg+'SegmentEnd']:continue
  i=old[name]-old['_'+seg+'SegmentStart'];j=address-new['_'+seg+'SegmentStart'];relocated(x[i:i+length],y[j:j+length],address,seg);count+=1;checked_names.add(name)
 retained[seg]=count
for name in ['Player_SetEquipmentData','Player_SetBootData','Inventory_ChangeEquipment','Room_SetupFirstRoom','Room_RequestNewRoom','ElfMsg2_KillCheck','ElfMsg2_GetMessageId','ElfMsg2_WaitForTextRead','ElfMsg2_WaitForTextClose','ElfMsg2_WaitUntilActivated','CollisionCheck_GetSwordDamage','Actor_ApplyDamage','EnTorch2_Update','EnTorch2_Draw']:
 assert name in checked_names,name
assert retained['code']>2900 and retained['ovl_Elf_Msg2']>=6,retained
# Static legacy helper bodies remain verbatim, including the three earlier custom objects.
source=(O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c').read_text();old_source=(R/'tools/originals/superhelden/src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c').read_text()
static_helpers=['ElfMsg2_DrawNintendo64','ElfMsg2_DrawMajoraMask','ElfMsg2_DrawWallace','ElfMsg2_InitWallace','ElfMsg2_UpdateWallace','ElfMsg2_IsWallace','ElfMsg2_DrawPepsiman','ElfMsg2_InitPepsiman','ElfMsg2_UpdatePepsiman','ElfMsg2_DrawPepsiCan','ElfMsg2_IsPepsiCan','ElfMsg2_PepsiRoom']
for name in static_helpers:
 m=re.search(r'static [^\n]+\b'+name+r'\([^;]+?\) \{',old_source);assert m,name;start=m.start();brace=old_source.index('{',m.start());end=brace+1;depth=1
 while depth:
  depth+=(old_source[end]=='{')-(old_source[end]=='}');end+=1
 assert old_source[start:end] in source,name
# Original room geometry, objects, actors, doors, triggers and collision retained.
assets=0;room_growth={};rows=[('Bmori1',3,5),('Bmori1',5,5),('HAKAdan',12,12)]
for scene,room,count in rows:
 seg=scene+'_room_'+str(room);x,y=segments[seg];room_growth[seg]=len(y)-len(x);obj=B/('assets/scenes/dungeons/'+scene+'/'+seg+'.o')
 for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) (\w) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(obj)],text=True),re.M):
  if name not in old or name not in new:continue
  i=old[name]-old['_'+seg+'SegmentStart'];j=new[name]-new['_'+seg+'SegmentStart'];length=int(size,16)
  if not 0<=i<len(x)or not 0<=j<len(y):continue
  if name.endswith('_ActorEntryList'):length=count*16
  q=x[i:i+length];r=y[j:j+length]
  if name==seg:
   q=bytearray(q);cmd=[k for k in range(0,length,8)if q[k]==1];assert len(cmd)==1;assert q[cmd[0]+1]==count;q[cmd[0]+1]+=1;q=bytes(q)
  relocated(q,r,new[name],seg);assets+=1
capacities={};connections={}
for scene,rooms in [('Bmori1',23),('HAKAdan',23)]:
 pairs=[tuple(map(int,v))for v in re.findall(r'\{\s*(-?\d+), -1 \},\s*\{\s*(-?\d+), -1 \}',next((O/('extracted/pal-1.0/assets/scenes/dungeons/'+scene)).glob('*TransitionActorEntryList.inc.c')).read_text())];connections[scene]=pairs;assert len(pairs)>15
 def capacity(which):
  sizes={i:len(segments[scene+'_room_'+str(i)][which])for i in range(rooms)};return max(list(sizes.values())+[sizes.get(a,0)+(sizes.get(b,0)if a!=b else 0)for a,b in pairs])
 capacities[scene]=[capacity(0),capacity(1)]
assert (3,5)not in connections['Bmori1']and(5,3)not in connections['Bmori1']
# Exactly one HP scaling instruction changes in Dark Link's initialization.
seg='ovl_En_Torch2';x,y=segments[seg];addr=new['EnTorch2_Init'];length=next(int(n,16)for a,n,t,name in functions if name=='EnTorch2_Init');i=old['EnTorch2_Init']-old['_'+seg+'SegmentStart'];j=addr-new['_'+seg+'SegmentStart'];q=bytearray(x[i:i+length]);r=y[j:j+length];hp_instruction=[]
for k in range(0,length,4):
 u,v=struct.unpack_from('>I',q,k)[0],struct.unpack_from('>I',r,k)[0]
 if (u & ~0x7C0)==(v & ~0x7C0) and ((u>>6)&31)==3 and ((v>>6)&31)==4 and (u&63)in[2,3]:hp_instruction.append(k);q[k:k+4]=r[k:k+4]
assert len(hp_instruction)==1,hp_instruction;relocated(bytes(q),r,addr,seg)
# Original retail IDs, all other languages, all other German messages unchanged.
def messages(rom,syms):
 _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'));base=syms['_codeSegmentStart'];p=syms['sNesMessageEntryTable']-base;ids=[]
 while True:
  ident=struct.unpack_from('>H',code,p)[0];p+=8
  if ident==65535:break
  if ident!=65532:ids.append(ident)
 table=syms['sGerMessageEntryTable']-base;off=[struct.unpack_from('>I',code,table+4*j)[0]&0xffffff for j in range(len(ids))]+[len(data)]
 return {f'{ident:04X}':data[off[j]:off[j+1]].rstrip(b'\0')for j,ident in enumerate(ids)}
ma=messages(a,old);mb=messages(b,new);diff=[i for i in ma if ma[i]!=mb[i]];chapter=json.loads((R/'story/superhelden_de.json').read_text())['messages'];assert set(diff)==set(chapter),diff
before=story.messages((W/'baseline_message_data.h').read_text());after=story.messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
for ident,v in after.items():
 for lang in [0,1,3]:assert v['parts'][lang][2]==before[ident]['parts'][lang][2],(ident,lang)
 assert v['header']==before[ident]['header'],ident
 template='0022' if ident in ['6087','6088','6089']else ident
 assert story.controls(v['parts'][2][2])==story.controls(before[template]['parts'][2][2]),ident
edits={i:e for p in (R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};buffers=check_buffers(B,edits);assert len(edits)==997
# Every unrelated actor/model/room keeps its data or only genuine linker relocations.
for name in ['ovl_player_actor','ovl_En_Mk','ovl_En_Hy','ovl_Boss_Mo','ovl_Boss_Ganondrof','ovl_En_Ge1','ovl_En_Ge2','ovl_En_Ge3','object_zo','object_du','object_sa','kenjyanoma_scene','MIZUsin_room_16','MIZUsin_room_0','HAKAdan_room_0']:
 assert name in identical or any(v['segment']==name for v in relocated_segments),name
assert 'COLOR(LIGHTBLUE)'in after['6089']['parts'][2][2]
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,changed_german_messages=diff,story_count=len(edits),text_buffers=buffers,intentional_segments=changed,identical_segments=identical,relocated_segments=relocated_segments,retained_native_functions=retained,native_room_assets_retained=assets,room_growth=room_growth,room_buffer_before_after=capacities,fanboy_chumchum_rooms_not_adjacent=True,fanboy_triangles=1463,chumchum_triangles=1287,crocker_triangles=205,new_object_slots=0,legacy_static_helpers_preserved=static_helpers,native_collision_and_doors_unchanged=True,dark_link_scaling_instruction_count=len(hp_instruction),master_sword_hit_damage_uses_remaining_hp=True,native_boss_sword_helper_retained=True,crocker_navi_reply_is_same_message_last_page=True)
(B/'superhelden-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments;',retained,'native functions;',assets,'original room assets;',len(edits),'dialogue buffers; room capacities',capacities)

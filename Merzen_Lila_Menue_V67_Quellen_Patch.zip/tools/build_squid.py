"""Build the supplied rigid Squidward rig for the diving-game actor only."""
from pathlib import Path
import sys,json,math,collections,itertools,copy
from PIL import Image
ROOT=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();A=O/'assets/objects/object_zo';B=ROOT/'originals/squid'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
m=json.loads((ROOT/'squid_source.json').read_text());n=len(m['bones']);assert n==27 and len(m['triangles'])==254
lines=['/* Supplied SuperSponge Squidward. Original rigid weights and proportions. */']
def u64(name,data):
 data+=bytes((-len(data))%8);lines.append('static u64 '+name+'[] = {');lines.extend('0x'+data[i:i+8].hex().upper()+',' for i in range(0,len(data),8));lines.append('};')
texdir=ROOT.parent/'models/squid/textures';texspec=[None,('squidfaceNEW.png',16,32),('shirt.png',32,32),('suckers.png',16,32)]
for i,spec in enumerate(texspec):
 if not spec:continue
 name,w,h=spec;im=Image.open(texdir/name).convert('RGBA').resize((w,h),Image.Resampling.NEAREST);data=b''
 for r,g,b,a in im.getdata():data+=(((r>>3)<<11)|((g>>3)<<6)|((b>>3)<<1)|(a>=128)).to_bytes(2,'big')
 u64('gSquidTex%d'%i,data)
commands=[];vertices=[]
for mat in range(4):
 commands+=['gsDPPipeSync(),']
 if mat==0:
  commands+=['gsSPTexture(0,0,0,0,G_OFF),','gsDPSetCombineLERP(PRIMITIVE,0,SHADE,0,0,0,0,PRIMITIVE,0,0,0,COMBINED,0,0,0,COMBINED),','gsDPSetPrimColor(0,0,165,255,203,255),']
 else:
  _,w,h=texspec[mat];commands+=['gsSPTexture(0xFFFF,0xFFFF,0,0,G_ON),','gsDPSetCombineLERP(TEXEL0,0,SHADE,0,0,0,0,TEXEL0,0,0,0,COMBINED,0,0,0,COMBINED),','gsDPLoadTextureBlock(gSquidTex%d,G_IM_FMT_RGBA,G_IM_SIZ_16b,%d,%d,0,G_TX_WRAP,G_TX_WRAP,%d,%d,G_TX_NOLOD,G_TX_NOLOD),'%(mat,w,h,int(math.log2(w)),int(math.log2(h)))]
 tris=[t for t in m['triangles'] if t['material']==mat]
 # Triangle-local vertex slots retain source normals/UV seams and bone ownership.
 for start in range(0,len(tris),10):
  batch=tris[start:start+10];offset=len(vertices);local=[]
  for t in batch:
   for c in t['corners']:
    v=m['vertices'][c['vertex']];w,h=texspec[mat][1:] if mat else (1,1)
    local.append({'bone':v['bone'],'position':v['position'],'normal':c['normal'],'uv':[round(c['uv'][0]*w*32),round((1-c['uv'][1])*h*32)]})
  # Sort cache slots by bone so every matrix load applies to a contiguous run.
  order=sorted(range(len(local)),key=lambda j:local[j]['bone']);slots={v:i for i,v in enumerate(order)}
  for bone,itr in itertools.groupby(order,key=lambda j:local[j]['bone']):
   group=list(itr);off=len(vertices);vertices.extend(local[j] for j in group)
   commands+=['gsSPMatrix((Mtx*)0x%08X,G_MTX_NOPUSH|G_MTX_LOAD|G_MTX_MODELVIEW),'%(0x0d000000+bone*64),'gsSPVertex(&gSquidVertices[%d],%d,%d),'%(off,len(group),slots[group[0]])]
  for j in range(len(batch)):commands+=['gsSP1Triangle(%d,%d,%d,0),'%tuple(slots[j*3+k] for k in range(3))]
lines+=['static Vtx gSquidVertices[] = {']
for v in vertices:
 assert all(-32768<=x<=32767 for x in v['position']+v['uv'])
 lines.append('{{{%d,%d,%d},0,{%d,%d},{%d,%d,%d,255}}},'%tuple(v['position']+v['uv']+[x&255 for x in v['normal']]))
lines+=['};','static Gfx gSquidEmptyDL[]={gsSPEndDisplayList()};','static Gfx gSquidBodyDL[]={','gsDPPipeSync(),','gsDPSetCycleType(G_CYC_2CYCLE),','gsDPSetRenderMode(G_RM_FOG_SHADE_A,G_RM_AA_ZB_OPA_SURF2),','gsSPClearGeometryMode(G_CULL_BACK|G_CULL_FRONT|G_TEXTURE_GEN|G_TEXTURE_GEN_LINEAR),','gsSPSetGeometryMode(G_LIGHTING|G_SHADE|G_SHADING_SMOOTH|G_ZBUFFER|G_FOG),','gsDPSetTextureLUT(G_TT_NONE),','gsDPSetTextureFilter(G_TF_BILERP),']+commands+['gsSPEndDisplayList(),','};']
for i,b in enumerate(m['bones']):
 children=[j for j,x in enumerate(m['bones']) if x['parent']==i];siblings=[j for j,x in enumerate(m['bones']) if x['parent']==b['parent']];sib=siblings[siblings.index(i)+1] if siblings.index(i)+1<len(siblings) else 255
 lines+=['static StandardLimb gSquidLimb%d={{%d,%d,%d},%d,%d,%s};'%tuple([i]+b['position']+[children[0] if children else 255,sib,'gSquidBodyDL' if i==n-1 else 'gSquidEmptyDL'])]
lines+=['static void* gSquidLimbs[]={'+','.join('&gSquidLimb%d'%i for i in range(n))+'};','FlexSkeletonHeader gSquidSkel={{gSquidLimbs,%d},%d};'%(n,n)]
# Native Zora idle/throw headers are actor-local replacements; 60-frame throw
# preserves every existing minigame timer and the >=15-frame camera trigger.
idle=m['animations']['idle']['frames'];throw=copy.deepcopy([idle[0] for _ in range(60)])
# An original dismissive outward arm flick, using the model's own elbow/hand.
# Matrices are baked offline so no scale is introduced in the runtime pose.
def mul(a,b):return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def euler_matrix(a):
 x,y,z=a;cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
 return [[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]]
def euler(r):
 y=math.asin(max(-1,min(1,-r[2][0])))
 return [math.atan2(r[2][1],r[2][2]),y,math.atan2(r[1][0],r[0][0])]
for f,pose in enumerate(throw):
 # Lift, flick, then return, with eased shoulders and elbows.
 amount=math.sin(math.pi*min(f,40)/40)**2 if f<=40 else 0
 for bone,axis,degrees in [(12,'x',-48),(13,'z',-55),(14,'y',25),(6,'x',-12)]:
  r=euler_matrix([x*math.pi/32768 for x in pose['rotation'][bone]])
  a=[0,0,0];a['xyz'.index(axis)]=degrees*amount*math.pi/180
  pose['rotation'][bone]=[round(x*32768/math.pi)%65536 for x in euler(mul(r,euler_matrix(a)))]
for name,frames in [('Idle',idle),('Throw',throw)]:
 channels=[[p['root'][k] for p in frames] for k in range(3)]+[[p['rotation'][b][k] for p in frames] for b in range(n) for k in range(3)]
 constants=[]
 for ch in channels:
  if len(set(ch))==1 and ch[0]%65536 not in constants:constants.append(ch[0]%65536)
 data=list(constants);indices=[]
 for ch in channels:
  if len(set(ch))==1:indices.append(constants.index(ch[0]%65536))
  else:indices.append(len(data));data.extend(x%65536 for x in ch)
 lines+=['static s16 gSquid%sFrames[]={%s};'%(name,','.join('0x%04X'%v for v in data)),'static JointIndex gSquid%sJoints[]={'%name]
 lines+=['{%d,%d,%d},'%tuple(indices[i:i+3]) for i in range(0,len(indices),3)];lines+=['};','AnimationHeader gSquid%sAnim={{%d},gSquid%sFrames,gSquid%sJoints,%d};'%(name,len(frames),name,name,len(constants))]
(A/'squid_model.inc.c').write_text('\n'.join(lines)+'\n')
p=A/'gZoraSkel.c';p.write_text(original(p)+'\n#include "squid_model.inc.c"\n');p=A/'object_zo.h';h=original(p);p.write_text(h+'\nextern FlexSkeletonHeader gSquidSkel;\nextern AnimationHeader gSquidIdleAnim;\nextern AnimationHeader gSquidThrowAnim;\n')
p=O/'src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.h';s=original(p).replace('jointTable[20]','jointTable[28]').replace('morphTable[20]','morphTable[28]');s='\n'.join(__import__('re').sub(r'/\* 0x[0-9A-Fa-f]+ \*/ ', '',line) for line in s.splitlines());s=s.replace('// size = 0x0398','// Original fields retained; two 28-entry pose tables.');p.write_text(s+'\n')
p=O/'src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.c';s=original(p).replace('&gZoraSkel','&gSquidSkel').replace('&gZoraIdleAnim','&gSquidIdleAnim').replace('&gZoraThrowRupeesAnim','&gSquidThrowAnim').replace('this->morphTable, 20)','this->morphTable, 28)');s=s.replace('    this->actor.scale.x = 0.01f;\n    this->actor.scale.y = 0.012999999f;\n    this->actor.scale.z = 0.0139999995f;','    Actor_SetScale(&this->actor, 0.01f);')
s=s.replace('0x85', '(gSaveContext.language == LANGUAGE_GER ? 0x0138 : 0x85)').replace('0x2D', '(gSaveContext.language == LANGUAGE_GER ? 0x013B : 0x2D)')
s=s.replace('this->actor.textId = 0x71AD;','this->actor.textId = (gSaveContext.language == LANGUAGE_GER) ? 0x0136 : 0x71AD;')
a=s.index('    if (limbIndex == 6)',s.index('s32 EnDivingGame_OverrideLimbDraw'));b=s.index('\n    return 0;',a)
s=s[:a]+'''    /* Source head is limb 4. No Zora limb offsets or fidget distortions. */
    if (limbIndex == 4) {
        rot->x += CLAMP(this->headRot.y, -0x0800, 0x0800);
        rot->z += CLAMP(this->headRot.z, -0x0800, 0x0800);
    }
'''+s[b:];p.write_text(s)
print('Squidward: 254 source triangles, 27 source bones; 28 pose entries; uniform 0.01 actor scale.')

"""Verify approved sage dialogues and German mask routing against the published Wallace revision."""
from pathlib import Path
import argparse,csv,hashlib,json,math,re,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as dialogue
ROOT=Path(__file__).resolve().parent.parent
BASE_SHA='1bdb74d9e7dc2f128d0313bd6e4d6aa95dc908ceb9f65a7f40031df2f9aba838'

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('oot',type=Path);ap.add_argument('baseline',type=Path);args=ap.parse_args()
    oot=args.oot.resolve();build=oot/'build/pal-1.0'
    old=args.baseline.read_bytes();packed=(build/'oot-pal-1.0-compressed.z64').read_bytes()
    plain=(build/'oot-pal-1.0.z64').read_bytes()
    assert hashlib.sha256(old).hexdigest()==BASE_SHA
    assert len(packed)==33554432 and packed[0x3e:0x40]==b'P\0'
    assert struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
    mp=(build/'oot-pal-1.0.map').read_text()
    symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):
        symbols.setdefault(name,int(address,16))
    def sym(name):
        return symbols[name]
    elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(build/'oot-pal-1.0.elf')],text=True)
    rels={};current=None
    for line in elf.splitlines():
        header=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
        if header:
            current=header[1];rels.setdefault(current,{})
        entry=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
        if current and entry:
            rels[current][int(entry[1],16)]=(entry[2],entry[3])
    intentional={'makerom','dmadata','code','ger_message_data_static','ovl_En_Ko','ovl_En_Diving_Game'}
    identical=[];relocated=[];changed=[];verified=0;object_bytes=None
    names=[r['Name'] for r in csv.DictReader((oot/'baseroms/pal-1.0/segments.csv').open())]
    for index,name in enumerate(names):
        _,_,before=segment(old,index)
        start,end,unpacked=segment(packed,index)
        if unpacked is None:
            continue
        expected=plain[start:end]
        if name=='makerom':
            assert unpacked[:16]==expected[:16] and unpacked[24:]==expected[24:]
        elif name!='dmadata':
            assert unpacked==expected,('compression',name)
            verified+=1
        lo,hi=[sym('_'+name+'SegmentRom'+suffix) for suffix in ['Start','End']]
        after=plain[lo:hi]
        if name=='object_im':
            object_bytes=len(after)
            assert len(after)<=86016,('object memory budget exceeded',len(after))
        if before==after:
            identical.append(name);continue
        if name in intentional:
            changed.append({'segment':name,'before_bytes':len(before),'after_bytes':len(after)});continue
        assert len(before)==len(after),('unexpected size change',name,len(before),len(after))
        origin=sym('_'+name+'SegmentStart')
        differences=sorted({i//4*4 for i,(x,y) in enumerate(zip(before,after)) if x!=y})
        for offset in differences:
            rel=rels.get(name,{}).get(origin+offset)
            assert rel,('unexplained changed word',name,hex(origin+offset))
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[offset:offset+2]==after[offset:offset+2],(name,rel)
            elif kind=='R_MIPS_26':
                assert before[offset]>>2==after[offset]>>2,(name,rel)
            else:
                assert kind=='R_MIPS_32',(name,rel)
        relocated.append({'segment':name,'relocated_words':len(differences)})
    assert verified==1509
    # Read the actual ROM language tables, rather than trusting generated JSON alone.
    # Symbols from the SHA256-pinned published baseline ELF.
    old_symbols={}
    def german_messages(rom,tab,code_base):
        _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'))
        off=tab-code_base;entries=[]
        # PAL German table contains only pointers; IDs/order come from NES entries.
        ids=[];nes=(old_symbols if rom==args.baseline.read_bytes() else symbols)['sNesMessageEntryTable']-code_base
        while True:
            ident=struct.unpack_from('>H',code,nes)[0]
            if ident==0xffff:break
            if ident!=0xfffc:ids.append(ident)
            nes+=8
        for i,ident in enumerate(ids):entries.append((ident,struct.unpack_from('>I',code,off+4*i)[0]&0xffffff))
        result={}
        for i,(ident,start) in enumerate(entries):
            end=entries[i+1][1] if i+1<len(entries) else len(data)
            result[ident]=data[start:end].rstrip(bytes([0]))
        return result
    _,_,before_code=segment(args.baseline.read_bytes(),names.index('code'))
    _,_,after_code=segment(packed,names.index('code'))
    baseline_map=(args.baseline.parent/'baseline.map').read_text()
    baseline_symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',baseline_map):
        baseline_symbols.setdefault(name,int(address,16))
    old_symbols=baseline_symbols
    oldbase=baseline_symbols['_codeSegmentStart'];newbase=sym('_codeSegmentStart')
    mask_table_start=sym('gGermanMaskReactionTextIds');mask_table_end=mask_table_start+60*9*2
    mask_code_checked=False;mask_table_checked=False
    anchors={oldbase:(newbase,['_codeSegmentStart'])}
    for name,addr in baseline_symbols.items():
        if name not in symbols:continue
        current=sym(name)
        if oldbase<=addr<oldbase+len(before_code) and newbase<=current<newbase+len(after_code):
            if addr in anchors:
                assert anchors[addr][0]==current,('alias movement',name)
                anchors[addr][1].append(name)
            else:anchors[addr]=(current,[name])
    anchors[oldbase+len(before_code)]=(newbase+len(after_code),['code ROM end'])
    order=sorted(anchors);code_relocations=[];padding=[]
    table_old_cut=None;table_growth=None;table_old_end=None
    for lo,hi in zip(order,order[1:]):
        start=anchors[lo][0];end=anchors[hi][0]
        if start<=mask_table_start and mask_table_end<=end:
            table_old_cut=lo+mask_table_start-start
            table_growth=(end-start)-(hi-lo);table_old_end=hi
    assert table_growth==1088 and table_old_cut is not None
    for lo,hi in zip(order,order[1:]):
        start,names_at=anchors[lo];end=anchors[hi][0]
        before=before_code[lo-oldbase:hi-oldbase];after=after_code[start-newbase:end-newbase]
        cut=None
        if 'MaskReaction_GetTextId' in names_at:
            # Sole intentionally changed core function. All other functions still undergo word-level relocation checks.
            assert start==sym('MaskReaction_GetTextId') and len(after)<=256
            mask_code_checked=True
            continue
        if start<=mask_table_start and mask_table_end<=end:
            offset=mask_table_start-start
            catalog=json.loads((ROOT/'planning/MASKEN_ZUORDNUNG.json').read_text())
            expected_table=b''.join(struct.pack('>H',v) for row in catalog['german_rows'].values() for v in row)
            assert after[offset:offset+len(expected_table)]==expected_table
            assert after[offset+1080:offset+table_growth]==bytes(table_growth-1080)
            after=after[:offset]+after[offset+table_growth:]
            cut=offset;mask_table_checked=True
        if len(before)!=len(after):
            common=min(len(before),len(after));assert abs(len(before)-len(after))<=16,('unexpected interval growth',names_at,len(before),len(after))
            assert all(x==0 for x in before[common:]+after[common:]),('non-padding growth',names_at)
            padding.append({'symbols':names_at,'before':len(before),'after':len(after)})
        common=min(len(before),len(after));assert common%4==0
        for i in range(0,common,4):
            if baseline_symbols['sGerMessageEntryTable']<=lo+i<baseline_symbols['sFraMessageEntryTable']:continue
            if before[i:i+4]==after[i:i+4]:continue
            addr=start+i+(table_growth if cut is not None and i>=cut else 0);rel=rels.get('code',{}).get(addr);assert rel,('unexpected core word',hex(addr),names_at)
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[i:i+2]==after[i:i+2],(hex(addr),rel)
            elif kind=='R_MIPS_26':assert before[i]>>2==after[i]>>2,(hex(addr),rel)
            else:
                assert kind=='R_MIPS_32',rel
                oldword=struct.unpack_from('>I',before,i)[0];newword=struct.unpack_from('>I',after,i)[0]
                if target=='..code':
                    import bisect
                    assert oldbase<=oldword<baseline_symbols['_codeSegmentEnd'],('section pointer',hex(oldword))
                    if oldword>=order[-1]:expected=oldword+sym('_codeSegmentDataStart')-baseline_symbols['_codeSegmentDataStart']
                    else:
                        key=order[bisect.bisect_right(order,oldword)-1];expected=anchors[key][0]+oldword-key
                        if table_old_cut<=oldword<table_old_end:expected+=table_growth
                    assert newword==expected,('section pointer movement',hex(addr),hex(oldword),hex(newword),hex(expected))
                else:
                    assert (oldword-baseline_symbols[target])&0xffffffff == (newword-sym(target))&0xffffffff,('relocation addend',hex(addr),target)
            code_relocations.append({'address':hex(addr),'type':kind,'target':target})

    assert mask_code_checked and mask_table_checked
    before_text=german_messages(old,old_symbols['sGerMessageEntryTable'],old_symbols['_codeSegmentStart'])
    after_text=german_messages(packed,sym('sGerMessageEntryTable'),sym('_codeSegmentStart'))
    changed_ids={i for i in before_text if before_text[i]!=after_text[i]}
    chapters=['weise_thaddaeus_waluigi_de.json','weise_masken_kontext_de.json','masken_reaktionen_de.json']
    expected={int(i,16) for f in chapters for i in json.loads((ROOT/'story'/f).read_text())['messages']}
    assert changed_ids==expected,sorted(hex(i) for i in changed_ids^expected)
    assert {'object_ru2','object_ru1','object_nb','object_sa','object_im','object_rl','object_dekujr','object_zo','ddan_room_2','nes_message_data_static','fra_message_data_static'}<=set(identical)
    assert 'ovl_Elf_Msg2' in set(identical)|{r['segment'] for r in relocated}

    import build_story as b
    current=b.messages((oot/'extracted/pal-1.0/text/message_data.h').read_text())
    native=b.messages((ROOT/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
    edits={};chains={'704F':'0121','0121':'0122','0122':'0123'}
    for path in (ROOT/'story').glob('*.json'):
        for ident,entry in json.loads(path.read_text())['messages'].items():
            assert ident not in edits;edits[ident]=entry
            src=native[entry.get('native_template',ident)]['parts'][2][2];dst=current[ident]['parts'][2][2]
            assert b.controls(src)+(['TEXTID(0x'+chains[ident]+')'] if ident in chains else [])==b.controls(dst),ident
            if entry.get('native_template'):
                assert all(b.plain(native[ident]['parts'][lang][2]).strip().upper()==ident for lang in [1,2,3])
    def readable(i):return re.sub(r'\s+',' ',b.plain(current[i]['parts'][2][2]))
    assert 'Prinzessin Ruto ist nie wieder aufgetaucht' in readable('403E')
    assert 'Thaddäus Quentin Tentakel' in readable('403E')
    assert 'Friedrich Merz soll Eier lecken!' in readable('6020')
    assert b.controls(current['6036']['parts'][2][2])==['BOX_BREAK_DELAYED(80)','FADE(80)']
    for ident in ['6021','6022']:assert b.controls(current[ident]['parts'][2][2])==['TEXTID(0x6023)']
    assert b.controls(current['6023']['parts'][2][2])==['TEXTID(0x6024)']
    assert b.controls(current['6025']['parts'][2][2])==['TEXTID(0x6026)']
    catalog=json.loads((ROOT/'planning/MASKEN_ZUORDNUNG.json').read_text())
    orig=list(catalog['original_rows'].values());german=list(catalog['german_rows'].values())
    assert len(orig)==len(german)==60 and all(len(row)==9 for row in german)
    assert all((orig[j][k]==0)==(german[j][k]==0) for j in range(60) for k in range(9))
    assert len({row[7] for j,row in enumerate(german) if j!=12 and row[7]})==58
    table_offset=sym('sMaskReactionSetTextIds')-newbase
    assert after_code[table_offset:table_offset+1080]==b''.join(struct.pack('>H',v) for row in orig for v in row)
    assert all(f'{v:04X}' in edits for j,row in enumerate(german) if j!=12 for v in row if v)
    # Ordinary save-state and trading branches remain in the actor originals; only dedicated German reactions are added.
    mask_source=(oot/'src/code/z_face_reaction.c').read_text()
    assert 'gSaveContext.language == LANGUAGE_GER' in mask_source
    assert 'return sMaskReactionSetTextIds[maskReactionSet][currentMask];' in mask_source
    assert '!CHECK_QUEST_ITEM(QUEST_ZORA_SAPPHIRE)' in mask_source
    for rel in ['src/code/z_face_reaction.c','src/overlays/actors/ovl_En_Ko/z_en_ko.c','src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.c']:
        source=(oot/rel).read_text();baseline=(ROOT/'tools/originals/masken'/rel).read_text()
        recovered=source.replace('#include "custom_mask_reactions.h"\n','')
        if rel.endswith('z_en_ko.c'):
            recovered=re.sub(r'    /\* The existing 50-rupee debtor.*?(?=    if \(ENKO_TYPE == ENKO_TYPE_CHILD_0)', '',recovered,flags=re.S)
        elif rel.endswith('z_en_diving_game.c'):
            recovered=re.sub(r'/\* Thaddaeus has his own sincere answer.*?(?=void EnDivingGame_Init\()', '',recovered,flags=re.S)
            recovered=recovered.replace('EnDivingGame_GetMaskReaction(play)','MaskReaction_GetTextId(play, MASK_REACTION_SET_ZORA)')
        else:
            recovered=recovered.replace('#include "save.h"\n','')
            recovered=re.sub(r'/\* German-only, mask-specific IDs.*?\};\n(?=u16 MaskReaction_GetTextId)', '',recovered,flags=re.S)
            recovered=re.sub(r'    if \(gSaveContext.language == LANGUAGE_GER\).*?(?=    return sMaskReactionSetTextIds)', '',recovered,flags=re.S)
        assert recovered==baseline,('source outside documented mask additions changed',rel)
    report={'rom_sha256':hashlib.sha256(packed).hexdigest(),'rom_bytes':len(packed),'baseline_sha256':BASE_SHA,'compressed_segments_verified':verified,'identical_segments':identical,'relocated_segments':relocated,'intentional_changes':changed,'core_relocations_checked':len(code_relocations),'sole_modified_core_function':'MaskReaction_GetTextId','german_table_verified_bytes':1080,'changed_german_ids':sorted(f'{i:04X}' for i in changed_ids),'dialogue_buffers':check_buffers(build,edits),'all_models_and_scenes_preserved':True,'fixed_times_and_controls_unchanged':True,'native_mask_zeros_and_original_table_preserved':True,'supportive_gerudo_groups':58,'thaddaeus_separate_supportive_gerudo':True,'story_count':len(edits)}
    (build/'weise-masken-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Verified',verified,'segments;',len(changed_ids),'German changes;',len(edits),'buffers; all models, scenes, fixed timings, choices and text chains preserved; mask table and native zeros checked.')
if __name__=='__main__':main()


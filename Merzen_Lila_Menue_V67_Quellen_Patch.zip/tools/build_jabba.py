"""Last-step, child-only Hyrule Field Jabba, bilingual supplied dialogue."""
from pathlib import Path
import json,sys,re
from n64_model import emit
from build_story import add_private_message,messages,Layout,rewrite,plain
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/jabba';D=O/'extracted/pal-1.0/assets/scenes/overworld/spot00'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
m=json.loads((R/'tools/jabba_source.json').read_text());model=emit(m,R/'models/jabba','Jabba',True).replace('static Gfx gJabbaBodyDL[]={','Gfx gJabbaDL[]={').replace('gJabbaBodyDL','gJabbaDL')
A=O/'extracted/pal-1.0/assets/objects/object_jabba';A.mkdir(parents=True,exist_ok=True);(A/'object_jabba.c').write_text('#include "ultra64.h"\n#include "animation.h"\n#include "gfx.h"\n#include "sys_matrix.h"\n'+model)
p=D/'spot00_room_0.c';p.write_text(original(p))
old_model=D/'jabba_model.inc.c'
if old_model.exists():old_model.unlink()
p=O/'include/tables/object_table.h';p.write_text(original(p)+'\n/* 0x0192 */ DEFINE_OBJECT(object_jabba, OBJECT_JABBA)\n')
p=O/'spec/spec';p.write_text(original(p)+'\n/* Private object appended: all original DMA indices remain intact. */\nbeginseg\n    name "object_jabba"\n    compress\n    romalign 0x1000\n    include "$(BUILD_DIR)/assets/objects/object_jabba/object_jabba.o"\n    number 6\nendseg\n')
p=D/'spot00_room_0.h';header=original(p)
for name in ['spot00_room_0_03000090_ActorEntryList.inc.c','spot00_room_0_03000050_AltHeaders_03000C50_Cmds_03000CAC_ActorEntryList.inc.c']:
 p=D/name;s=original(p);count=s.count('ACTOR_');p.write_text(s+'    { ACTOR_ELF_MSG2, { -500, 0, 2400 }, { 0, 0x6000, 0 }, 0x3F81 }, /* Jabba: off the castle road, child day/night only */\n');macro='LENGTH_'+name.removesuffix('.inc.c');header,n=re.subn(rf'(#define {macro} ){count}\b',lambda m:m[1]+str(count+1),header);assert n==1
for name in ['spot00_room_0_03000080_ObjectList.inc.c','spot00_room_0_03000050_AltHeaders_03000C50_Cmds_03000C98_ObjectList.inc.c']:
 p=D/name;text=original(p);count=text.count('OBJECT_');p.write_text(text+'    OBJECT_JABBA, /* child field only; native cutscenes retain their object lists */\n');macro='LENGTH_'+name.removesuffix('.inc.c');header,n=re.subn(rf'(#define {macro} ){count}\b',lambda m:m[1]+str(count+1),header);assert n==1
(D/'spot00_room_0.h').write_text(header)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p).replace('#include "play_state.h"','#include "play_state.h"\n#include "object.h"');helper=(R/'tools/jabba_actor.inc.c').read_text().replace('JABBA_HEAD_PIVOT','{'+','.join(map(str,m['bones'][1]['position']))+'}');s=s.replace('/* Two isolated Forest Temple NPC rooms;',helper+'\n/* Two isolated Forest Temple NPC rooms;')
assert 'static s32 ElfMsg2_IsJabba'in s
for fn in ['Init','Update']:
 needle='void ElfMsg2_'+fn+'(Actor* thisx, PlayState* play) {\n    ElfMsg2* this = (ElfMsg2*)thisx;'
 assert s.count(needle)==1;s=s.replace(needle,needle+'\n    if (ElfMsg2_IsJabba(thisx, play)) {\n        ElfMsg2_'+fn+'Jabba(this, play);\n        return;\n    }')
needle='if (ElfMsg2_IsWallace(thisx, play) ||';assert s.count(needle)==1;s=s.replace(needle,'if (ElfMsg2_IsJabba(thisx, play) || ElfMsg2_IsWallace(thisx, play) ||');p.write_text(s)
entry=dict(new_message=True,insert_before='71B2',native_template='0022',pages=['Jabba! (JABBA!)','Jee am on Ma way Tah meet friedrich merz at Ta castle of hyrule.','(ICH BIN AUF DEM WEG FRIEDRICH MERZ IM SCHLOSS HYRULE ZU TREFFEN!)','He offered Je Du Grancha Bargon! (ER BAT MIR EINEN GUTEN DEAL AN!)','ho ho ho! (HO HO HO!)'])
for p in (R/'story').glob('*.json'):
 if p.name=='jabba_de.json':continue
 assert '71B3'not in json.loads(p.read_text())['messages'],('duplicate text',p)
(R/'story/jabba_de.json').write_text(json.dumps(dict(chapter='Jabba auf dem Weg zum Schloß',orthography='de-vor-1996',jabba_rule='Immer zuerst der vom Nutzer vorgegebene huttische Satz; danach die deutsche Übersetzung in Klammern. Jede Satzgruppe bleibt in dieser Reihenfolge. Deutsche Großschreibung/BAT wortgetreu.',messages={'71B3':entry}),ensure_ascii=False,indent=2)+'\n')
p=O/'extracted/pal-1.0/text/message_data.h';s=add_private_message(p.read_text(),'71B3',entry);parsed=messages(s);a,b,_=parsed['71B3']['parts'][2];native=messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text());body,_=rewrite(native['0022']['parts'][2][2],entry,Layout(O),'71B3');p.write_text(s[:a]+body+s[b:])
print('Jabba:',len(m['triangles']),'triangles; child day/night beside castle road, own height 78, two rigid groups; private new ID71B3, Huttese followed by parenthesized German.')

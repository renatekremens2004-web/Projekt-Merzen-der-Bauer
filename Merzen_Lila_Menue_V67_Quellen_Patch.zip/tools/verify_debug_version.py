"""Compare final icon/debug editions with the published Schattengewand build."""
from pathlib import Path
import sys,re,subprocess,struct,hashlib,json
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment
O=Path(sys.argv[1]);W=Path(sys.argv[2]);base=W/'baseline/build/pal-1.0'

def syms(p):
 d={}
 for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(a,16))
 return d

def elfsy(p):
 d={}
 for a,z,k,n in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([tTdDrR]) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(p)],text=True),re.M):
  if int(z,16):d[n]=(int(a,16),int(z,16),k)
 return d

oldrom=(base/'oot-pal-1.0-compressed.z64').read_bytes();om=syms(base/'oot-pal-1.0.map');os=elfsy(base/'oot-pal-1.0.elf')
assert hashlib.sha256(oldrom).hexdigest()=='0c717a4d2b8746f749707b098a51b009014b5c0f72fb97b7d0e1c3560c635332'
secnums={n:s for n,s in re.findall(r'\[\s*(\d+)\] \.\.(\w+)\s',subprocess.check_output(['mips-linux-gnu-readelf','-SW',str(base/'oot-pal-1.0.elf')],text=True))}
ss={f[-1]:secnums.get(f[6]) for l in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(base/'oot-pal-1.0.elf')],text=True).splitlines() if len(f:=l.split())==8}
names=re.findall(r'DEFINE_DMA_ENTRY\((\w+),',(O/'build/pal-1.0/dmadata_table_spec.h').read_text())
reports={}
for kind,B in [('normal',W/'normal'),('debug',O/'build/pal-1.0')]:
 rom=(B/'oot-pal-1.0-compressed.z64').read_bytes();unpacked=(B/'oot-pal-1.0.z64').read_bytes();nm=syms(B/'oot-pal-1.0.map');ns=elfsy(B/'oot-pal-1.0.elf')
 assert struct.unpack_from('>II',rom,16)==calculateChecksum(rom,CICKind.CIC_X105)
 rels={};sec=None
 for l in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
  m=re.match(r"Relocation section '\.rel\.\.([^']+)'",l)
  if m:sec=m[1];rels.setdefault(sec,{})
  m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',l)
  if m and sec:rels[sec][int(m[1],16)]=(m[2],m[3])
 def linked(x,y,off,addr,name):
  r=rels.get(name,{}).get(addr);assert r,(kind,name,hex(addr),'unexplained difference',x[off:off+4].hex(),y[off:off+4].hex())
  t,target=r
  if t in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[off:off+2]==y[off:off+2],(name,target)
  elif t=='R_MIPS_26':assert x[off]>>2==y[off]>>2
  else:assert t=='R_MIPS_32',t
 allowed={'code':{'Message_LoadItemIcon'},'ovl_kaleido_scope':{'KaleidoScope_Update'}}
 if kind=='debug':
  allowed['code']|={'Graph_Update','Sram_WriteSave'}
  allowed['ovl_kaleido_scope']|={'KaleidoScope_HandlePageToggles','KaleidoScope_DrawInventoryEditor','KaleidoScope_DrawInventoryEditorText'}
  allowed['ovl_select']={'MapSelect_LoadGame','MapSelect_Init','MapSelect_PrintMenu','MapSelect_PrintAgeSetting','MapSelect_PrintCutsceneSetting','sAgeLabels','sMapSelectEntries','sLoadingMessages'}
 oldsecs={};newsecs={};same=[];changed=[];relocated=[]
 for i,name in enumerate(names):
  _,_,x=segment(oldrom,i);start,end,y=segment(rom,i);oldsecs[name]=x;newsecs[name]=y
  if y is None:continue
  if name!='dmadata':
   if name=='makerom':assert y[:16]==unpacked[start:start+16] and y[24:]==unpacked[start+24:end]
   else:assert y==unpacked[start:end],name
  if x==y:same.append(name);continue
  if name in {'makerom','dmadata'}|allowed.keys():changed.append(name);continue
  assert len(x)==len(y),(kind,name,'size')
  for off in sorted({j//4*4 for j,(a,b) in enumerate(zip(x,y)) if a!=b}):linked(x,y,off,nm['_'+name+'SegmentStart']+off,name)
  relocated.append(name)
 counts={}
 for name,exceptions in allowed.items():
  x,y=oldsecs[name],newsecs[name];lo=om['_'+name+'SegmentStart'];nlo=nm['_'+name+'SegmentStart'];count=0
  for n,(a,z,k) in os.items():
   if n in exceptions or ss.get(n)!=name:continue
   assert n in ns,(kind,name,n,'missing symbol')
   na,nz,_=ns[n];assert z==nz,(kind,name,n,'size')
   xx=x[a-lo:a-lo+z];yy=y[na-nlo:na-nlo+z];assert len(xx)==len(yy)==z
   for off in sorted({j//4*4 for j,(p,q) in enumerate(zip(xx,yy)) if p!=q}):linked(xx,yy,off,na+off,name)
   count+=1
  counts[name]=count
 # All character, room, collision, texture, text-data and item-object bytes are unchanged.
 immutable=[n for n in names if n.startswith('object_') or n.endswith(('_scene','_room_0')) or n.endswith('_message_data_static') or n=='icon_item_static']
 assert all(oldsecs[n]==newsecs[n] for n in immutable)
 reports[kind]=dict(rom_sha256=hashlib.sha256(rom).hexdigest(),rom_bytes=len(rom),dma_entries=len(names),identical_segments=len(same),intentional_segments=changed,relocated_segments=relocated,existing_symbols_compared=counts,immutable_asset_groups=len(immutable),all_existing_text_bytes_unchanged=True,global_debug_features=0,actual_ram_target=4194304)
(W/'binary-verification.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))

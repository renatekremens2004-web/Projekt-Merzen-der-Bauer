"""Append the uploaded LEGO toy to one Shadow Temple room without changing actors/collision."""
from pathlib import Path
import sys,json,struct
ROOT=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();D=O/'extracted/pal-1.0/assets/scenes/dungeons/HAKAdan';B=ROOT/'originals/xwing'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
compact=ROOT/'xwing_compact_source.json'
m=json.loads((compact if compact.exists() else ROOT/'xwing_source.json').read_text());assert len(m['triangles'])<4500
lines=['/* Uploaded LEGO X-Wing: room-local geometry and native scene lighting. */']
# libultra 16.16 row-vector model matrix, exact uniform scale 1/128.
ma=[1/128,0,0,0,0,1/128,0,0,0,0,1/128,0,-1750,-63,-300,1];fixed=[round(x*65536)&0xffffffff for x in ma];data=b''.join(struct.pack('>H',x>>16) for x in fixed)+b''.join(struct.pack('>H',x&65535) for x in fixed)
lines += ['static u64 gXWingPlacement[]={']+['0x'+data[i:i+8].hex().upper()+',' for i in range(0,64,8)]+['};']
vertices=[];commands=[]
for mi,mat in enumerate(m['materials']):
 color=[round(x*255) for x in mat['rgba'][:3]];commands += ['gsDPPipeSync(),','gsDPSetPrimColor(0,0,%d,%d,%d,255),'%tuple(color)]
 tris=[t for t in m['triangles'] if t['material']==mi]
 for start in range(0,len(tris),10):
  batch=tris[start:start+10];base=len(vertices)
  for t in batch:
   for c in t['corners']:
    # Source JSON normalized to width 2400; 3072 / 128 = 24 game units.
    p=[round(x*3072/2400) for x in m['vertices'][c['vertex']]];assert all(-32768<=x<=32767 for x in p);vertices.append(p+[x&255 for x in c['normal']])
  commands+=['gsSPVertex(&gXWingVertices[%d],%d,0),'%(base,len(batch)*3)]
  commands+=['gsSP1Triangle(%d,%d,%d,0),'%(j*3,j*3+1,j*3+2) for j in range(len(batch))]
lines+=['static Vtx gXWingVertices[]={']+['{{{%d,%d,%d},0,{0,0},{%d,%d,%d,255}}},'%tuple(v) for v in vertices]+['};','Gfx gXWingDL[]={','gsDPPipeSync(),','gsSPMatrix((Mtx*)gXWingPlacement,G_MTX_MODELVIEW|G_MTX_MUL|G_MTX_PUSH),','gsDPSetCycleType(G_CYC_2CYCLE),','gsSPTexture(0,0,0,0,G_OFF),','gsDPSetTextureLUT(G_TT_NONE),','gsSPClearGeometryMode(G_CULL_BACK|G_CULL_FRONT|G_TEXTURE_GEN|G_TEXTURE_GEN_LINEAR),','gsSPSetGeometryMode(G_LIGHTING|G_SHADE|G_SHADING_SMOOTH|G_ZBUFFER|G_FOG),','gsDPSetRenderMode(G_RM_FOG_SHADE_A,G_RM_AA_ZB_OPA_SURF2),','gsDPSetCombineLERP(PRIMITIVE,0,SHADE,0,0,0,0,1,0,0,0,COMBINED,0,0,0,COMBINED),']+commands+['gsDPPipeSync(),','gsSPPopMatrix(G_MTX_MODELVIEW),','gsSPEndDisplayList(),','};']
(D/'xwing_model.inc.c').write_text('\n'.join(lines)+'\n')
p=D/'HAKAdan_room_0.c';p.write_text(original(p)+'\n#include "xwing_model.inc.c"\n')
p=D/'HAKAdan_room_0.h';p.write_text(original(p).replace('#include "room.h"','#include "room.h"\nextern Gfx gXWingDL[];'))
p=D/'HAKAdan_room_0_03000190_RoomShapeNormal_0300019C_DListsEntries_03008170_DL.inc.c';s=original(p);assert s.count('gsSPEndDisplayList(),')==1;p.write_text(s.replace('gsSPEndDisplayList(),','gsSPBranchList(gXWingDL),'))
print('X-Wing:',len(m['triangles']),'triangles, 24-unit span; Room 0 (-1750,-63,-300); existing actors/collision untouched')

/* D-pad Down: iron boots; D-pad Up: hover boots. Press again for Kokiri boots.
 * Use the same inventory/equipment path as the pause menu.
 * Called before native currentBoots/prevBoots processing, including swimming.
 */
static void Player_TryQuickIronBoots(Player* this, PlayState* play, Input* input) {
    s32 nextBoots;
    s32 targetBoots;
    s32 ownedBoots;
    u16 button;

    if (CHECK_BTN_ALL(input->press.button, BTN_DDOWN)) {
        targetBoots = EQUIP_VALUE_BOOTS_IRON;
        ownedBoots = EQUIP_INV_BOOTS_IRON;
        button = BTN_DDOWN;
    } else if (CHECK_BTN_ALL(input->press.button, BTN_DUP)) {
        targetBoots = EQUIP_VALUE_BOOTS_HOVER;
        ownedBoots = EQUIP_INV_BOOTS_HOVER;
        button = BTN_DUP;
    } else {
        return;
    }

    if (!LINK_IS_ADULT || !CHECK_OWNED_EQUIP(EQUIP_TYPE_BOOTS, ownedBoots) ||
        IS_PAUSED(&play->pauseCtx) || play->gameOverCtx.state != GAMEOVER_INACTIVE ||
        play->msgCtx.msgMode != MSGMODE_NONE || Player_InCsMode(play) ||
        play->transitionTrigger != TRANS_TRIGGER_OFF || play->transitionMode != TRANS_MODE_OFF ||
        (this->stateFlags1 & (PLAYER_STATE1_DEAD | PLAYER_STATE1_5 | PLAYER_STATE1_23 | PLAYER_STATE1_29))) {
        return;
    }

    nextBoots = CUR_EQUIP_VALUE(EQUIP_TYPE_BOOTS) == targetBoots
                    ? EQUIP_VALUE_BOOTS_KOKIRI
                    : targetBoots;
    Inventory_ChangeEquipment(EQUIP_TYPE_BOOTS, nextBoots);
    Player_SetEquipmentData(play, this);
    Sfx_PlaySfxCentered(NA_SE_SY_DECIDE);
    input->press.button &= ~button;
}

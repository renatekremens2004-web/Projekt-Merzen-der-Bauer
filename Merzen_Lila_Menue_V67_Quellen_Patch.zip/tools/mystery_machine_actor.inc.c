/* Parked van: only the child day/night spawn lists contain this prop. */
extern Gfx gMysteryMachineDL[];
static s32 ElfMsg2_IsMysteryMachine(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_KAKARIKO_VILLAGE && actor->room == 0 && actor->params == 0x3F8C;
}
static s32 ElfMsg2_MysteryMachineVisible(void) {
    /* Permanent song ownership survives time travel; transient windmill flags do not. */
    return LINK_IS_CHILD && CHECK_QUEST_ITEM(QUEST_SONG_STORMS);
}
static void ElfMsg2_DrawMysteryMachine(Actor* actor, PlayState* play) {
    void* room = play->roomCtx.curRoom.segment;
    if (!ElfMsg2_MysteryMachineVisible() || room == NULL || play->roomCtx.curRoom.num != 0) return;
    OPEN_DISPS(play->state.gfxCtx, "mystery_machine", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "mystery_machine", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, room);
    gSPDisplayList(POLY_OPA_DISP++, gMysteryMachineDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "mystery_machine", 3);
}
static void ElfMsg2_InitMysteryMachine(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    if (!ElfMsg2_MysteryMachineVisible()) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_PROP);
    actor->flags = 0;
    actor->textId = 0;
    actor->cullingVolumeDistance = 2000;
    actor->cullingVolumeScale = 180;
    actor->cullingVolumeDownward = 120;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 35);
    actor->draw = ElfMsg2_DrawMysteryMachine;
    /* Flat native verge verified at all four wheel positions; no moving collider,
     * enemy collision, talk sequence or changes to scene collision/pathfinding. */
}
static void ElfMsg2_UpdateMysteryMachine(ElfMsg2* this, PlayState* play) {
    if (!ElfMsg2_MysteryMachineVisible()) Actor_Kill(&this->actor);
}

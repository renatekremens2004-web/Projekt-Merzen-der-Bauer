"""Install the user's well/Shadow chapter dialogue; retain native message controls."""
from pathlib import Path
import sys, json
from build_story import Layout, messages, split_pages, controls, rewrite

R = Path(__file__).resolve().parent.parent
O = Path(sys.argv[1]).resolve()
layout = Layout(O)
text = {
    '0155': ["Okay, das komische Ding kam eindeutig aus dem Brunnen. Glaubst Du, das wird jetzt der nächste Dungeon sein? Einfach so? Der Brunnen von Kakariko? Müssen wir dann das Brunnenlied lernen?"],
    '0157': ["Alles klar, ich wollte schon immer mal einen Song haben, mit dem wir zum ekligsten und gefährlichsten Ort Hyrules zurückreisen können."],
    '0156': ["Aber warum heißt das Ding Geistertempel und nicht Wüstentempel? Müßte der Schattentempel nicht eher Geistertempel heißen? Was soll Schatten in diesem Zusammenhang überhaupt bedeuten?"],
    '0126': ["Ich höre in diesem Raum geisterhafte Stimmen flüstern.", "Mir doch scheißegal, was die zu sagen haben. Ich ignoriere die einfach."],
    '0128': ["Die Geister in diesem Raum sind schon wieder am Flüstern.", "Sie flüstern mir zu.", "Okay, die sollen mal aufhören, mich zu belästigen, die Geister."],
    '0129': ['Da steht: "Alles Gute von oben." Das ist doch safe wieder ironisch gemeint.'],
    '012A': ["Bei dieser Mauer steht irgendwas über Tiefe. Ob das mit dem Giant Squid zu tun hat?"],
    '012B': ["Wäre es jetzt nicht witzig, das hier alles unter Wasser zu stellen?"],
    '0181': ["Jetzt redet auch noch diese bescheuerte Mauer mit mir.", "Wieso will alles in diesem Dungeon mit mir reden? Was soll das?"],
    '0184': ["Yo, siehst Du da vorne die Tür? Laß da mal gucken, ob wir da hinkommen können."],
    '5034': ["Auch nach sieben Jahren bin ich immer noch sowas von wütend. Ich stehe jeden Tag mit einem wütenden Gefühl auf und ziehe mir meine wütenden Schuhe an.", "Der hat meine ganze Mühle geschrottet. Das ist unfaßbar.", "Sag mal, wißt ihr eigentlich, wie teuer dieser ganze Schuppen hier gewesen ist?"],
    '5035': ["Ey, ich werde wahnsinnig. Das ist doch jetzt... Sag mir bitte nicht, daß das eine Okarina ist.", "Sag mir nicht, daß Du der Wichser von damals gewesen bist, sonst werde ich Dir so in die Fresse hauen.", "Irgendjemand hat damals diese absolut bescheuerte Regenmusik gespielt. Warum gibt es sowas überhaupt? Warum erlauben die Götter das?", "Ich erkläre Dir jetzt das Lied, einfach nur damit Du weißt, daß Du es auf keinen Fall spielen sollst. Jetzt ist es sowieso zu spät.", "Gott sei Dank hast Du keine Zeitmaschine oder so."],
    '508E': ["Oh nein, das war ein Fehler!"],
    '5033': ["Was zur Hölle geht hier vor sich? Du hast meine Mühle zerstört! Du hast alles kaputtgemacht! Diese Mühle hat mit meinem Einkommen zu tun. Wenn ich nicht genug Kram mühle, lande ich auf der Straße!"],
    '5030': ["Okay, ich sehe, Du hast noch genug Herzen. Na perfekt. Solltest aber vielleicht mal mehr Herzteile sammeln."],
    '501C': ["{name}, es gab da einst einen Dämon, den jemand im Brunnen eingesperrt hat. Das war Mr. Bean! Nur er kommt auf sowas Verrücktes. Das absolute Genie, der Typ.", "Na ja, jetzt ist die Kraft des Dämons gewachsen. Irgendwie wegen Friedrich Merz. Der ist, glaube ich, selbst ein Dämon. Seine Frisur sieht zumindest dämonisch beschissen aus.", "Und das Siegel ist jetzt halt gebrochen, ne? Und ja, ist jetzt halt Mist, ne?"],
    '5031': ["{name}, leider ist Mr. Bean nicht mehr hier. Damals hat er Zelda bei der Flucht aus dem Schloß gut beschützt. Davon hast Du ja sogar geträumt.", "Dann verlor er gegen Merz. Die haben krass gekämpft, aber Merz spielte unfair. Muß man einfach sagen.", "Heute kein großer Reim. Ich wußte nichts vom Schattentempel! Das Blut, die Schädel... Als hätte man da Leute gefoltert.", "Schon beim Brunnen denkt man: War dieser Dämon ein Serienmörder? Spannende Theorie. Aber der Tempel ist ja auch nicht besser.", "Und das war kein einzelner irrer Täter, sondern Hyrule selbst. Das ist jetzt ein bißchen unglücklich.", "Versetzen wir das ganz weit in die Vergangenheit. Nicht bloß sieben Jahre! Machen wir erst mal einen hohen Bogen drum.", "Das werden wir bei Zeit mal aufarbeiten. Der Zugang liegt hinter dem Friedhof. Mr. Bean ist der Weise des Schattens.", "Besiege den Dämon. Dann lerne jetzt die Nocturne des Schattens, unseren neuen Teleport-Song."],
    '501D': ["{name}, Du weißt, was zu tun ist. Du kannst auch in den Geistertempel gehen, falls Du da nicht schon warst. Ich würde erst den Schattentempel machen. Der Dämon kam ja gerade ganz frisch aus dem Brunnen, ne?"],
    '0208': ["Der Schattentempel. Hier ruhen Hyrules blutige Zeugnisse von großer Gier und blindem Haß. Es ist gar nicht mal so lange her."],
}
native = messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
chapter = dict(chapter='Brunnen, Schattentempel und Sheiks Nocturne', orthography='de-vor-1996', messages={})
target=O/'extracted/pal-1.0/text/message_data.h'
source=target.read_text(); current=messages(source); replacements=[]; reports={}
for ident, paragraphs in text.items():
    pages=[]
    for paragraph in paragraphs:
        lines=layout.wrap(paragraph,210)
        pages.extend(' '.join(lines[i:i+4]) for i in range(0,len(lines),4))
    entry={'pages':pages}
    # The final native page of 0128 originally changed to the normal colour;
    # retain blue for the user's continuing Navi voice instead.
    if ident in ['0126','0128','0129','012A','012B','0181','0184']:
        entry['color']='LIGHTBLUE'
    body,report=rewrite(native[ident]['parts'][2][2],entry,layout,ident)
    start,end,old=current[ident]['parts'][2]
    assert controls(old)==controls(body),(ident,'native control mismatch')
    replacements.append((start,end,body)); reports[ident]={'pages':report,'player_name_tokens':body.count('NAME')}
    chapter['messages'][ident]=entry

# Move existing entries rather than duplicate IDs across chapters.
for p in sorted((R/'story').glob('*.json')):
    if p.name=='schatten_brunnen_de.json':
        continue
    data=json.loads(p.read_text()); moved=set(data['messages'])&set(text)
    if moved:
        for ident in moved: del data['messages'][ident]
        p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
(R/'story/schatten_brunnen_de.json').write_text(json.dumps(chapter,ensure_ascii=False,indent=2)+'\n')
print('Prepared',len(text),'messages; 0191 unchanged; native controls retained.')
# Run last, after the existing character/chapter builders. Replace only these
# German bodies; retain every existing header, other language, private actor
# textbox configuration and continuation (including Habeck's TEXTID chain).
for start,end,body in sorted(replacements,reverse=True): source=source[:start]+body+source[end:]
target.write_text(source)
lp=O/'build/pal-1.0/story-layout.json'; report=json.loads(lp.read_text())if lp.exists()else{}
report.update(reports); lp.write_text(json.dumps(report,indent=2)+'\n')
print('Only selected German bodies replaced; existing headers, continuations, models and actor logic untouched.')

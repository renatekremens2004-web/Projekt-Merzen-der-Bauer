"""Run with Blender: --python tools/export_bean_fbx.py -- MODEL.fbx OUTPUT.json."""
import bpy
import hashlib
import json
from mathutils import Matrix
from pathlib import Path
import sys

args = sys.argv[sys.argv.index('--') + 1:]
if len(args) != 2:
    raise SystemExit(__doc__)
source, destination = map(Path, args)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.fbx(filepath=str(source.resolve()))
axis = Matrix(((1, 0, 0), (0, 0, 1), (0, -1, 0)))
rig = next(o for o in bpy.context.scene.objects if o.type == 'ARMATURE')
obj = next(o for o in bpy.context.scene.objects if o.type == 'MESH')
mesh = obj.data
mesh.calc_loop_triangles()
normals = (axis @ obj.matrix_world.to_3x3()).inverted().transposed()
out = {'bones': {}, 'vertices': [], 'triangles': []}
for bone in rig.data.bones:
    out['bones'][bone.name.split(':')[-1]] = {
        'head': list(axis @ (rig.matrix_world @ bone.head_local)),
        'tail': list(axis @ (rig.matrix_world @ bone.tail_local)),
        'matrix': [list(row) for row in axis @ rig.matrix_world.to_3x3() @ bone.matrix_local.to_3x3()],
    }
for vertex in mesh.vertices:
    out['vertices'].append({
        'position': list(axis @ (obj.matrix_world @ vertex.co)),
        'weights': [(obj.vertex_groups[g.group].name.split(':')[-1], g.weight) for g in vertex.groups],
    })
for triangle in mesh.loop_triangles:
    corners = []
    for li in triangle.loops:
        corners.append({
            'vertex': mesh.loops[li].vertex_index,
            'normal': list((normals @ mesh.corner_normals[li].vector).normalized()),
            'uv': list(mesh.uv_layers.active.data[li].uv),
        })
    out['triangles'].append(corners)
assert len(out['triangles']) == 1258
destination.write_text(json.dumps(out, indent=2) + '\n')
print('Exported source mesh:', len(out['vertices']), 'vertices;', len(out['triangles']), 'triangles.')
print('Source SHA256:', hashlib.sha256(source.read_bytes()).hexdigest())

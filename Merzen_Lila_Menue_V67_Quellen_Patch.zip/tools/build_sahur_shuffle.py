"""Replace the old Sahur with the supplied shuffling model; dance only after native rise."""
from pathlib import Path
import json,sys,copy
from PIL import Image
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();D=R/'models/sahur-shuffle';m=json.loads((R/'tools/sahur_shuffle_source.json').read_text())
assert len(m['bones'])==22 and len(m['triangles'])==2000
m=copy.deepcopy(m);im=Image.open(D/'shaded.png');w,h=im.size
for label,rect in [('front',(0.,0.,.23,.24)),('side',(.61,0.,.82,.24))]:
 u0,v0,u1,v1=rect;box=(round(u0*w),round((1-v1)*h),round(u1*w),round((1-v0)*h));name='face_'+label+'.png';im.crop(box).save(D/name);mat=len(m['materials']);m['materials'].append(dict(name='face_'+label,texture=name,size=[64,64]));count=0
 for t in m['triangles']:
  if t['material']!=0:continue
  if all(u0<=c['uv'][0]<=u1 and v0<=c['uv'][1]<=v1 for c in t['corners']):
   t['material']=mat;count+=1
   for c in t['corners']:u,v=c['uv'];c['uv']=[(u*w-box[0])/(box[2]-box[0]),(v*h-(h-box[3]))/(box[3]-box[1])]
 print('Sahur detail tile',label,count,'triangles')
A=O/'extracted/pal-1.0/assets/objects/object_dekujr';(A/'sahur_model.inc.c').write_text(emit(m,D,'Sahur',True))
p=A/'object_dekujr.h';s=p.read_text();line='extern AnimationHeader gSahurDanceAnim;'
if line not in s:s+='\n'+line+'\n';p.write_text(s)
p=O/'src/overlays/actors/ovl_Obj_Dekujr/z_obj_dekujr.c';s=p.read_text()
if '#include "segmented_address.h"'not in s:s=s.replace('#include "sys_matrix.h"','#include "sys_matrix.h"\n#include "segmented_address.h"')
s=s.replace('Actor_SetScale(thisx, 0.0111111111f);','Actor_SetScale(thisx, 0.01f);')
old='''    if (this->sahurSkelAnime.skeleton != NULL) {
        SkelAnime_Update(&this->sahurSkelAnime);
    }
    Collider_UpdateCylinder'''
new='''    if (this->sahurSkelAnime.skeleton != NULL) {
        /* Shuffle only once the original rise has finished and normal talk is possible. */
        AnimationHeader* animation = (play->csCtx.state == CS_STATE_IDLE && this->unk_19B == 0) ?
                                         &gSahurDanceAnim : &gSahurIdleAnim;
        if (this->sahurSkelAnime.animation != animation) {
            Animation_Change(&this->sahurSkelAnime, animation, 1.0f, 0.0f,
                             Animation_GetLastFrame(animation), ANIMMODE_LOOP, -6.0f);
        }
        SkelAnime_Update(&this->sahurSkelAnime);
    }
    Collider_UpdateCylinder'''
s=s.replace('this->sahurSkelAnime.animation != SEGMENTED_TO_VIRTUAL(animation)', 'this->sahurSkelAnime.animation != animation')
assert old in s or new in s;s=s.replace(old,new);p.write_text(s)
print('Sahur: 2000 triangles, 22 own bones, three small CI4 tiles; idle during native rise, shuffle afterwards.')

/* Recolor the already loaded 32x32 RGBA32 icon once, after its native DMA.
 * Work in the existing buffer: preserve alpha and shading; allocate no texture.
 */
static void ShadowTunic_RecolorIcon(u8* pixels) {
    s32 i;
    for (i = 0; i < 32 * 32; i++, pixels += 4) {
        u32 light = pixels[0];
        if (pixels[1] > light) light = pixels[1];
        if (pixels[2] > light) light = pixels[2];
        light = light * 52 / 255;
        pixels[0] = pixels[1] = pixels[2] = light;
    }
    osWritebackDCache(pixels - 32 * 32 * 4, 32 * 32 * 4);
}

"""Binary, relocation, scene and dialogue isolation checks for the Fire/Wallace chapter."""
from pathlib import Path
import sys,csv,re,json,hashlib,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as story
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';a=(W/'baseline.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();plain=(B/'oot-pal-1.0.z64').read_bytes();assert hashlib.sha256(a).hexdigest()=='ce303971fb48595d137aec348a323b52a74af487c56d3c34272b8c8b662cfff8'
assert len(b)==33554432 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
def symbols(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
old=symbols(W/'baseline.map');new=symbols(B/'oot-pal-1.0.map');names=[x['Name']for x in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];relocs={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if m:section=m[1];relocs.setdefault(section,{})
 m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if m and section:relocs[section][int(m[1],16)]=(m[2],m[3])
def relocated(x,y,base,name):
 assert len(x)==len(y),(name,'length',len(x),len(y));changes=sorted({j//4*4 for j,(q,r)in enumerate(zip(x,y))if q!=r})
 for j in changes:
  rel=relocs.get(name,{}).get(base+j);assert rel,(name,hex(base+j),'unexplained change');kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[j:j+2]==y[j:j+2]
  elif kind=='R_MIPS_26':assert x[j]>>2==y[j]>>2
  else:assert kind=='R_MIPS_32',kind
 return len(changes)
intentional={'makerom','dmadata','ger_message_data_static','code','ovl_En_Kz','ovl_En_Zo','ovl_player_actor','spot07_room_1'};segments={};changed=[];identical=[];relocated_segments=[];verified=0
for i,name in enumerate(names):
 start,end,y=segment(b,i);_,_,x=segment(a,i)
 if y is None:continue
 segments[name]=(x,y)
 if name!='dmadata':
  if name=='makerom':assert y[:16]==plain[start:start+16] and y[24:]==plain[start+24:end]
  else:assert y==plain[start:end],name;verified+=1
 if x==y:identical.append(name)
 elif name in intentional:changed.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)))
 else:relocated_segments.append(dict(segment=name,changed_words=relocated(x,y,new['_'+name+'SegmentStart'],name)))
assert verified==1509

nm=subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'oot-pal-1.0.elf')],text=True);functions=re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([Tt]) (\S+)$',nm,re.M);retained={};checked_names=set()
excluded={'EnZo_GetTextId','EnZo_Init','EnZo_UpdateTalkState','EnKz_GetTextIdAdult','func_80A9CB18','Player_UpdateCommon'}
func_addrs={int(q[1],16)for line in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(B/'oot-pal-1.0.elf')],text=True).splitlines()if len(q:=line.split())>=8 and q[3]=='FUNC'}
for seg in ['code','ovl_En_Kz','ovl_En_Zo','ovl_player_actor']:
 x,y=segments[seg];count=0
 for addr,size,kind,name in functions:
  address=int(addr,16);length=int(size,16)
  if address not in func_addrs or name in excluded or name not in old or not new['_'+seg+'SegmentStart']<=address<new['_'+seg+'SegmentEnd']or not old['_'+seg+'SegmentStart']<=old[name]<old['_'+seg+'SegmentEnd']:continue
  i=old[name]-old['_'+seg+'SegmentStart'];j=address-new['_'+seg+'SegmentStart'];relocated(x[i:i+length],y[j:j+length],address,seg);count+=1;checked_names.add(name)
 retained[seg]=count
for name in ['Player_SetEquipmentData','Player_SetBootData','Inventory_ChangeEquipment','EnKz_SetupGetItem','EnKz_StartTimer']:assert name in checked_names,name
assert retained['code']>2900 and retained['ovl_player_actor']>500,retained
# Only the three Zora RGB bytes changed; Kokiri green / Wallace orange retained.
x,y=segments['code'];i=old['sTunicColors']-old['_codeSegmentStart'];j=new['sTunicColors']-new['_codeSegmentStart'];assert x[i:i+6]==y[j:j+6] and x[i+6:i+9]==bytes([0,60,100])and y[j+6:j+9]==bytes([110,195,240])
# Preserve every original room-1 asset. Only adult object/actor counts increase.
seg='spot07_room_1';x,y=segments[seg];base='spot07_room_1_03000048_AltHeaders_03000360_Cmds';actors=base+'_030003B0_ActorEntryList';objects=base+'_030003A0_ObjectList';prefixes={actors:17*16,objects:7*2}
for name,length in prefixes.items():
 i=old[name]-old['_'+seg+'SegmentStart'];j=new[name]-new['_'+seg+'SegmentStart'];assert x[i:i+length]==y[j:j+length],name
# Check appended native actor exactly: id 0x1CE, position, rotation and marker.
j=new[actors]-new['_'+seg+'SegmentStart']+17*16
assert struct.unpack_from('>HhhhhhhH',y,j)==(0x1ce,-786,14,-486,0,-182,0,0x7fc6)
assets=0
obj=B/'assets/scenes/overworld/spot07/spot07_room_1.o'
for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) (\w) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(obj)],text=True),re.M):
 if name not in old or name not in new or name in prefixes:continue
 i=old[name]-old['_'+seg+'SegmentStart'];j=new[name]-new['_'+seg+'SegmentStart'];length=int(size,16)
 if not 0<=i<len(x)or not 0<=j<len(y):continue
 q=x[i:i+length];r=y[j:j+length]
 if name==base:
  q=bytearray(q);assert q[5*8]==0x0b and q[6*8]==0x01
  q[5*8+1]+=1;q[6*8+1]+=1;q=bytes(q)
 relocated(q,r,new[name],seg);assets+=1
# Original retail IDs, all other languages, all other German messages unchanged.
def messages(rom,syms):
 _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'));base=syms['_codeSegmentStart'];p=syms['sNesMessageEntryTable']-base;ids=[]
 while True:
  ident=struct.unpack_from('>H',code,p)[0];p+=8
  if ident==65535:break
  if ident!=65532:ids.append(ident)
 table=syms['sGerMessageEntryTable']-base;off=[struct.unpack_from('>I',code,table+4*j)[0]&0xffffff for j in range(len(ids))]+[len(data)]
 return {f'{ident:04X}':data[off[j]:off[j+1]].rstrip(b'\0')for j,ident in enumerate(ids)}
ma=messages(a,old);mb=messages(b,new);diff=[i for i in ma if ma[i]!=mb[i]];chapter=json.loads((R/'story/zoras_erwachsen_de.json').read_text())['messages'];assert set(diff)==set(chapter),diff
before=story.messages((W/'baseline_message_data.h').read_text());after=story.messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
for ident,v in after.items():
 for lang in [0,1,3]:assert v['parts'][lang][2]==before[ident]['parts'][lang][2],(ident,lang)
 assert v['header']==before[ident]['header'],ident
 template={'209F':'4020','4044':'4045'}.get(ident,ident)
 assert story.controls(v['parts'][2][2])==story.controls(before[template]['parts'][2][2]),ident
edits={i:e for p in (R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};buffers=check_buffers(B,edits);assert len(edits)==989
# All other models, scenes and Gerudo actors are covered by identical/relocated
# segment verification above. The original PAL-1.0 inherited-colour effect remains.
for name in ['ovl_En_Ge1','ovl_En_Ge2','ovl_En_Ge3','ovl_En_GeldB','object_zo','object_du','object_sa','kenjyanoma_scene']:
 assert name in identical or any(v['segment']==name for v in relocated_segments),name
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,changed_german_messages=diff,story_count=len(edits),text_buffers=buffers,intentional_segments=changed,identical_segments=identical,relocated_segments=relocated_segments,retained_native_functions=retained,native_room_assets_retained=assets,zora_tunic_rgb=[110,195,240],original_other_tunic_colours_retained=True,adult_reunion_actor_count_added=1,adult_reunion_object_count_added=1,original_gerudo_renderers_and_models_retained=True,native_king_reward_and_trade_functions_retained=True,native_swimming_boot_change_processing_retained=True)
(B/'adult-zoras-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments;',retained,'native functions;',len(edits),'dialogue buffers;',len(diff),'changed German texts.')

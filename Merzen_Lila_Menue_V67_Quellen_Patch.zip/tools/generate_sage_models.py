"""Offline own-rig retargeting. Fixed child translations, no scale/shear pose channels."""
from pathlib import Path
import json,math,re,copy,hashlib
import numpy as np
from PIL import Image
from rigid_math import rot,angles,fk,points,basis
R=Path(__file__).resolve().parent.parent;T=R/'tools';M=R/'models';refs=json.loads((T/'sage_animation_reference.json').read_text())

def waluigi():
 p=M/'waluigi-party3/waluigi.smd';lines=p.read_text().splitlines();a=lines.index('nodes')+1;b=lines.index('end',a);nodes=[re.match(r'(\d+) "(.*)" (-?\d+)',l).groups() for l in lines[a:b]];a=lines.index('time 0')+1;bind=[list(map(float,l.split()[1:])) for l in lines[a:a+len(nodes)]];A=np.array([[1,0,0],[0,0,1],[0,-1,0]],float);world=[]
 for i,(name,label,parent) in enumerate(nodes):
  m=np.eye(4);m[:3,:3]=rot(np.array(bind[i][3:])*32768/math.pi);m[:3,3]=bind[i][:3];world.append(world[int(parent)]@m if int(parent)>=0 else m)
 B=np.eye(4);B[:3,:3]=A;world=[B@w for w in world];a=lines.index('triangles')+1;tris=[]
 while lines[a]!='end':
  mat=lines[a];cs=[]
  for line in lines[a+1:a+4]:
   v=line.split();bone=int(v[0]);pos=A@np.array(list(map(float,v[1:4])));norm=A@np.array(list(map(float,v[4:7])));uv=list(map(float,v[7:9]));cs.append((bone,pos,norm,uv))
  tris.append((mat,cs));a+=4
 assert len(tris)==420
 used=[0,1,4,5,6,13,14,15,22,23,24,31,32];keep=set(used)
 def owner(i):
  while i not in keep:i=int(nodes[i][2])
  return i
 allpos=[c[1] for _,cs in tris for c in cs];scale=6600/(max(p[1] for p in allpos)-min(p[1] for p in allpos));ground=min(p[1] for p in allpos)
 # Separate pelvis and chest; source zero-transform helper bones collapse exactly.
 bones=[{'name':'pelvis','parent':-1,'position':[0,0,0],'world_matrix':world[0].tolist()}];old_to_new={0:0};rest=[world[0]]
 for old in [4,5,6,13,14,15]:
  parent=old_to_new[owner(int(nodes[old][2]))];local=np.linalg.inv(rest[parent])@world[old];old_to_new[old]=len(bones);bones.append({'name':nodes[old][1],'parent':parent,'position':np.rint(local[:3,3]*scale).astype(int).tolist(),'world_matrix':world[old].tolist()});rest.append(world[old])
 chest=world[0].copy();chest[:3,3]+=np.array([0,1.2,0]);spine=len(bones);local=np.linalg.inv(world[0])@chest;bones.append({'name':'spine','parent':0,'position':np.rint(local[:3,3]*scale).astype(int).tolist(),'world_matrix':chest.tolist()});rest.append(chest)
 for old in [1,22,23,24,31,32]:
  par=owner(int(nodes[old][2]));parent=spine if par==0 else old_to_new[par];local=np.linalg.inv(rest[parent])@world[old];old_to_new[old]=len(bones);bones.append({'name':nodes[old][1],'parent':parent,'position':np.rint(local[:3,3]*scale).astype(int).tolist(),'world_matrix':world[old].tolist()});rest.append(world[old])
 out={'model':'Supplied Mario Party 3 Waluigi','source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'height':6600,'uniform_scale':scale,'actor_setup':True,'bones':bones,'vertices':[],'triangles':[],'materials':[{'name':'body','texture':'img1.png','size':[64,64]},{'name':'face','texture':'img2.png','size':[32,64]},{'name':'detail','texture':'img3.png','size':[64,64]}]};lookup={}
 for mat,cs in tris:
  corners=[]
  for old,pos,norm,uv in cs:
   o=owner(old);bone=spine if o==0 else old_to_new[o];local=np.linalg.inv(rest[bone])@np.r_[pos,1];normal=rest[bone][:3,:3].T@norm;normal/=np.linalg.norm(normal);key=(bone,*np.rint(local[:3]*scale).astype(int))
   if key not in lookup:lookup[key]=len(out['vertices']);out['vertices'].append({'bone':bone,'position':list(map(int,key[1:])),'source_world':np.rint((pos-np.array([0,ground,0]))*scale).astype(int).tolist()})
   corners.append({'vertex':lookup[key],'normal':np.rint(normal*127).astype(int).tolist(),'uv':uv})
  out['triangles'].append({'material':['img1.png','img2.png','img3.png'].index(mat),'corners':corners})
 # source->native semantic map; +X is anatomical left in the native actors.
 mapping={0:0,spine:7,old_to_new[1]:14,old_to_new[4]:4,old_to_new[5]:5,old_to_new[6]:6,old_to_new[13]:1,old_to_new[14]:2,old_to_new[15]:3,old_to_new[22]:11,old_to_new[23]:12,old_to_new[24]:13,old_to_new[31]:8,old_to_new[32]:9}
 pairs={old_to_new[4]:(old_to_new[5],5),old_to_new[5]:(old_to_new[6],6),old_to_new[13]:(old_to_new[14],2),old_to_new[14]:(old_to_new[15],3),old_to_new[22]:(old_to_new[23],12),old_to_new[23]:(old_to_new[24],13),old_to_new[31]:(old_to_new[32],9)}
 # Right glove has no distinct wrist in the source. Keep its source forearm orientation.
 source_root=(world[0][:3,3]-np.array([0,ground,0]))*scale
 return out,rest,mapping,pairs,source_root,old_to_new

def squid():
 m=copy.deepcopy(json.loads((T/'squid_source.json').read_text()));out={k:m[k] for k in ['model','source_sha256','height','bones','vertices','triangles']};out['actor_setup']=True;rest=[np.array(b['world_matrix']) for b in m['bones']]
 # Both thighs belong to the pelvis, not to the animated upper spine.
 for i in [17,22]:out['bones'][i]['parent']=0;local=np.linalg.inv(rest[0])@rest[i];out['bones'][i]['position']=np.rint(local[:3,3]*m['scale']).astype(int).tolist()
 out['materials']=[{'name':'skin','texture':'sage_skin.png','size':[8,8]},{'name':'face','texture':'squidfaceNEW.png','size':[16,32]},{'name':'shirt','texture':'shirt.png','size':[32,32]},{'name':'suckers','texture':'suckers.png','size':[16,32]}];Image.new('RGB',(8,8),(165,255,203)).save(M/'squid/textures/sage_skin.png')
 mapping={0:0,1:9,3:20,6:10,7:13,8:14,12:15,13:18,14:19,17:1,18:2,19:3,22:5,23:6,24:7};pairs={6:(7,13),7:(8,14),12:(13,18),13:(14,19),17:(18,2),18:(19,3),22:(23,6),23:(24,7)}
 return out,rest,mapping,pairs,np.array(m['animations']['idle']['frames'][0]['root'])

def retarget(out,rest,mapping,pairs,source_root,native,neutral):
 bones=out['bones'];ref=fk(native['bones'],native['animations'][neutral][0]);correction={};front=np.array([0,0,1.])
 for own,nat in mapping.items():
  if own in pairs:
   child,nchild=pairs[own];ownvec=bones[child]['position'];natvec=native['bones'][nchild]['position'];correction[own]=basis(natvec,ref[nat][:3,:3].T@front)@basis(ownvec,rest[own][:3,:3].T@front).T
  else:correction[own]=ref[nat][:3,:3].T@rest[own][:3,:3]
 refverts=points(native['vertices'],ref);factor=out['height']/(refverts[:,1].max()-refverts[:,1].min());out['animations']={};ownverts=[[v['bone'],*v['position']] for v in out['vertices']]
 for name,frames in native['animations'].items():
  new=[]
  for f in frames:
   nw=fk(native['bones'],f);wr=[]
   for i,b in enumerate(bones):
    if i in mapping:r=nw[mapping[i]][:3,:3]@correction[i]
    elif b['parent']>=0:r=wr[b['parent']]@rest[b['parent']][:3,:3].T@rest[i][:3,:3]
    else:r=rest[i][:3,:3]
    wr.append(r)
   rotations=[angles(wr[b['parent']].T@wr[i] if b['parent']>=0 else wr[i]) for i,b in enumerate(bones)];root=source_root.copy().astype(float);native_root=np.array(f['root']);neutral_root=np.array(native['animations'][neutral][0]['root']);root[[0,2]]+=(native_root-neutral_root)[[0,2]]*factor;root[1]=0
   pose={'root':np.rint(root).astype(int).tolist(),'rotation':rotations};world=fk(bones,pose);ownp=points(ownverts,world);nativep=points(native['vertices'],nw);pose['root'][1]=round(nativep[:,1].min()*factor-ownp[:,1].min());new.append(pose)
  out['animations'][name]=new
 out['native_frames_preserved']={name:len(v) for name,v in native['animations'].items()};out['retarget']='Fixed own bone lengths; native rotation directions, full original frame counts; source-proportioned ground/portal clearance.'
 return out

w,rest,mapping,pairs,root,lookup=waluigi();w=retarget(w,rest,mapping,pairs,root,refs['object_nb'],'gNabooruHandsOnHipsAnim');# The exposed body under the Iron Knuckle armor needs the same replacement too.
ik=copy.deepcopy(refs['object_ik']);ik['vertices']=[v for v in ik['vertices'] if v[0] in [0,1,2,3,4,5,6,7,8,9,10,13,14,15,18,19,20,28]]
ik_map={0:0,1:5,2:6,3:7,4:2,5:3,6:4,7:9,8:18,9:19,10:20,11:13,12:14,13:15,14:10}
wi,wr,wm,wp,wroot,unused=waluigi();im={o:ik_map[n] for o,n in wm.items()};ip={o:(child,ik_map[nc]) for o,(child,nc) in wp.items()};wi=retarget(wi,wr,im,ip,wroot,ik,'gIronKnuckleNabooruDeathAnim');w['animations']['gWaluigiKnuckleRevealAnim']=wi['animations']['gIronKnuckleNabooruDeathAnim']
w['native_head_limb']=lookup[1]+1;w['native_torso_limb']=8;(T/'waluigi_sage_source.json').write_text(json.dumps(w,separators=(',',':'))+'\n');s,rest,mapping,pairs,root=squid();s=retarget(s,rest,mapping,pairs,root,refs['object_ru2'],'gAdultRutoIdleAnim');(T/'squid_sage_source.json').write_text(json.dumps(s,separators=(',',':'))+'\n');print('Waluigi',len(w['bones']),len(w['triangles']),len(w['animations']),'Squid',len(s['bones']),len(s['triangles']),len(s['animations']))

"""Small further reduction of the already reduced static Squidward; UVs retained."""
import bpy,json,sys
from pathlib import Path
R=Path(__file__).resolve().parent.parent;p=R/'tools/flatsquid_source.json';m=json.loads(p.read_text())
if m.get('extra_reduction'):
 print('Already reduced:',len(m['triangles']));raise SystemExit(0)
bpy.ops.wm.read_factory_settings(use_empty=True);me=bpy.data.meshes.new('FlatSquid');me.from_pydata([v['position']for v in m['vertices']],[],[[c['vertex']for c in t['corners']]for t in m['triangles']]);me.update();uv=me.uv_layers.new()
for face,t in zip(me.polygons,m['triangles']):
 for li,c in zip(face.loop_indices,t['corners']):uv.data[li].uv=c['uv']
o=bpy.data.objects.new('FlatSquid',me);bpy.context.collection.objects.link(o);bpy.context.view_layer.objects.active=o;mod=o.modifiers.new('Extra 15 percent reduction','DECIMATE');mod.ratio=.85;mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name);me=o.data;me.calc_loop_triangles();before=len(m['triangles']);m['vertices']=[dict(bone=0,position=[round(x)for x in v.co])for v in me.vertices];m['triangles']=[]
for t in me.loop_triangles:m['triangles'].append(dict(material=0,corners=[dict(vertex=vi,uv=list(me.uv_layers.active.data[li].uv),normal=[round(x*127)for x in me.vertices[vi].normal.normalized()])for vi,li in zip(t.vertices,t.loops)]))
m['extra_reduction']=dict(previous_triangles=before,current_triangles=len(m['triangles']),factor=.85,uvs_preserved=True,static_no_collision=True);p.write_text(json.dumps(m,separators=(',',':'))+'\n');print('FLAT_SQUID',before,'->',len(m['triangles']))

#include "libc64/math64.h"
/* Own proportions. Gestures are visual; the original actor owns movement, timing and rewards. */
static Gfx* WallaceAdult_Draw(Actor* actor, PlayState* play, Gfx* gfx, Gfx* displayList,
                             f32 arm, f32 head, f32 walk, f32 phase, f32 cheerful) {
    static Vec3f pivots[] = { {0,10,0}, {0,7027,0}, {819,6910,0}, {-819,6910,0},
                             {500,4200,-100}, {-500,4200,-100}, {500,2400,-100}, {-500,2400,-100},
                             {500,600,-100}, {-500,600,-100}, {1220,4900,-220}, {-1220,4900,-220} };
    Mtx* matrices = GRAPH_ALLOC(play->state.gfxCtx, sizeof(Mtx) * 12);
    f32 hip[2];
    f32 knee[2];
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 470));
    f32 gesture = Math_SinS((s16)(play->gameplayFrames * 1000));
    f32 answer = Math_SinS((s16)(play->gameplayFrames * 1410 + 0x2500));
    f32 step = sinf(phase);
    f32 blend = CLAMP(walk, 0.0f, 1.0f);
    f32 lively = CLAMP(cheerful, 0.0f, 1.0f);
    f32 drop = 230.0f * blend + lively * ((1.0f - blend) * 20.0f * (1.0f + gesture) +
                     blend * 90.0f * (1.0f - cosf(phase * 2.0f)));
    f32 leanZ = lively * (0.025f * gesture + blend * 0.055f * step);
    f32 leanX = lively * 0.025f * answer;
    s32 side;
    s32 i;
    if (matrices == NULL) return gfx;
    for (side = 0; side < 2; side++) {
        f32 q = phase + side * 3.14159265358979323846f;
        f32 t;
        f32 z;
        f32 lift = 0.0f;
        f32 down;
        f32 cosine;
        f32 bend;
        while (q >= 6.28318530717958647692f) q -= 6.28318530717958647692f;
        if (q < 3.14159265358979323846f) {
            t = q / 3.14159265358979323846f;
            z = 1200.0f * (1.0f - 2.0f * t);
        } else {
            t = (q - 3.14159265358979323846f) / 3.14159265358979323846f;
            z = -1200.0f + 2400.0f * (t - sinf(t * 6.28318530717958647692f) / 6.28318530717958647692f);
            lift = sinf(t * 3.14159265358979323846f) * (550.0f + lively * 180.0f);
        }
        z *= blend;
        lift *= blend;
        down = 3600.0f - drop - lift;
        cosine = CLAMP((down * down + z * z - 6480000.0f) / 6480000.0f, -1.0f, 1.0f);
        bend = Math_FAtan2F(sqrtf(MAX(0.0f, 1.0f - cosine * cosine)), cosine);
        hip[side] = Math_FAtan2F(-z, down) - bend * 0.5f;
        knee[side] = bend;
    }
    Matrix_Push();
    Matrix_Translate(actor->world.pos.x, actor->world.pos.y + actor->shape.yOffset * 0.01f - drop * 0.01f,
                     actor->world.pos.z, MTXMODE_NEW);
    Matrix_RotateY(actor->shape.rot.y * (3.14159265358979323846f / 32768.0f), MTXMODE_APPLY);
    Matrix_Scale(0.01f, 0.01f, 0.01f, MTXMODE_APPLY);
    for (i = 0; i < 12; i++) {
        Matrix_Push();
        if (i >= 4 && i < 10) {
            side = (i - 4) & 1;
            Matrix_Translate(pivots[4+side].x, pivots[4+side].y, pivots[4+side].z, MTXMODE_APPLY);
            Matrix_RotateX(hip[side], MTXMODE_APPLY);
            Matrix_Translate(-pivots[4+side].x, -pivots[4+side].y, -pivots[4+side].z, MTXMODE_APPLY);
            if (i >= 6) {
                Matrix_Translate(pivots[6+side].x, pivots[6+side].y, pivots[6+side].z, MTXMODE_APPLY);
                Matrix_RotateX(knee[side], MTXMODE_APPLY);
                Matrix_Translate(-pivots[6+side].x, -pivots[6+side].y, -pivots[6+side].z, MTXMODE_APPLY);
            }
            if (i >= 8) {
                Matrix_Translate(pivots[8+side].x, pivots[8+side].y, pivots[8+side].z, MTXMODE_APPLY);
                Matrix_RotateX(-hip[side] - knee[side], MTXMODE_APPLY);
                Matrix_Translate(-pivots[8+side].x, -pivots[8+side].y, -pivots[8+side].z, MTXMODE_APPLY);
            }
        } else {
            s32 upper = i >= 10 ? i - 8 : i;
            if (lively > 0.0f) {
                Matrix_Translate(0.0f, 4200.0f, 0.0f, MTXMODE_APPLY);
                Matrix_RotateZ(leanZ, MTXMODE_APPLY);
                Matrix_RotateX(leanX, MTXMODE_APPLY);
                Matrix_Translate(0.0f, -4200.0f, 0.0f, MTXMODE_APPLY);
            }
            Matrix_Translate(pivots[upper].x, pivots[upper].y, pivots[upper].z, MTXMODE_APPLY);
            if (upper == 1) {
                Matrix_RotateX(head + idle * 0.015f + lively * (0.025f + 0.055f * answer), MTXMODE_APPLY);
                if (lively > 0.0f) Matrix_RotateZ(lively * 0.045f * gesture, MTXMODE_APPLY);
            }
            if (upper >= 2) {
                f32 direction = upper == 2 ? 1.0f : -1.0f;
                f32 wave = upper == 2 ? gesture : answer;
                Matrix_RotateZ((arm + idle * 0.015f + lively * (0.16f + 0.10f * wave +
                                  blend * 0.12f * step * direction)) * direction, MTXMODE_APPLY);
                Matrix_RotateX(step * blend * (upper == 2 ? -0.20f : 0.20f) +
                                  lively * (-0.18f - 0.16f * wave), MTXMODE_APPLY);
            }
            Matrix_Translate(-pivots[upper].x, -pivots[upper].y, -pivots[upper].z, MTXMODE_APPLY);
            if (i >= 10) {
                f32 wave = i == 10 ? answer : gesture;
                Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
                Matrix_RotateX(-lively * (1.08f + 0.30f * wave + blend * 0.12f * step * (i == 10 ? 1.0f : -1.0f)), MTXMODE_APPLY);
                Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
            }
        }
        MATRIX_TO_MTX(&matrices[i], "wallace adult", 1);
        Matrix_Pop();
    }
    Matrix_Pop();
    gSPSegment(gfx++, 0x0D, matrices);
    gSPDisplayList(gfx++, displayList);
    gSPSegment(gfx++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    return gfx;
}

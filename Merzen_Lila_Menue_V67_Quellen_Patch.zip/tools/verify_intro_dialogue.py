"""Verify a text-only revision against the preceding cumulative PAL build."""
from pathlib import Path
import sys,re,json,struct,hashlib
from ipl3checksum import CICKind,calculateChecksum
from build_story import messages,controls,split_pages
from verify_story import segment,check_buffers
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]);W=Path(sys.argv[2]);B=O/'build/pal-1.0';P=W/'baseline';base=P/'build/pal-1.0'
a=(base/'oot-pal-1.0-compressed.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();u=(B/'oot-pal-1.0.z64').read_bytes();assert hashlib.sha256(a).hexdigest()=='55d2d55989441ef99221df41a7fcc34429c303bbb6d61e91dfe8fb7444488066'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
ids=set(json.loads((W/'changed-ids.json').read_text()));old=messages((P/'extracted/pal-1.0/text/message_data.h').read_text());new=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());assert old.keys()==new.keys();source_changed=set()
for ident in old:
 assert old[ident]['header']==new[ident]['header']
 for lang in range(4):
  x=old[ident]['parts'][lang][2];y=new[ident]['parts'][lang][2]
  if x!=y:assert lang==2;source_changed.add(ident)
  assert controls(x)==controls(y),(ident,lang,'controls')
  assert len(split_pages(x)[0])==len(split_pages(y)[0]),(ident,lang,'pages')
assert source_changed==ids
names=re.findall(r'DEFINE_DMA_ENTRY\((\w+),',(B/'dmadata_table_spec.h').read_text());changed=[];verified=0
for i,name in enumerate(names):
 x=segment(a,i)[2];lo,hi,y=segment(b,i)
 if y is None:continue
 if name=='makerom':assert y[:16]==u[lo:lo+16]and y[24:]==u[lo+24:hi]
 elif name!='dmadata':assert y==u[lo:hi],name;verified+=1
 if x!=y:changed.append(name)
assert set(changed)=={'makerom','dmadata','ger_message_data_static','code'}
def symbols(p):
 d={}
 for a,n in re.findall(r'0x([0-9a-f]+)\s+([A-Za-z_]\w*)\b',p.read_text()):d.setdefault(n,int(a,16))
 return d
os=symbols(base/'oot-pal-1.0.map');ns=symbols(B/'oot-pal-1.0.map');assert os.keys()==ns.keys();moved={k for k in os if os[k]!=ns[k]};assert all(re.fullmatch(r'_message_0x[0-9A-Fa-f]+_ger',k)or k.startswith('_ger_message_data_staticSegment')for k in moved),sorted(moved)
x=segment(a,names.index('code'))[2];y=segment(b,names.index('code'))[2];cb=ns['_codeSegmentStart'];lo=ns['sGerMessageEntryTable']-cb;hi=ns['sFraMessageEntryTable']-cb
assert len(x)==len(y)and x[:lo]==y[:lo]and x[hi:]==y[hi:],'Only German message pointers may change in code'
def compiled(rom,code):
 raw=segment(rom,names.index('ger_message_data_static'))[2];start=ns['sNesMessageEntryTable']-cb;rows=[];i=0
 while True:
  ident=struct.unpack_from('>H',code,start+i*8)[0]
  if ident==0xffff:break
  if ident not in [0xfffc,0xfffd]:rows.append((f'{ident:04X}',struct.unpack_from('>I',code,lo+i*4)[0]&0xffffff))
  i+=1
 return{ident:raw[p:(rows[j+1][1]if j+1<len(rows)else len(raw))].rstrip(b'\x00')for j,(ident,p)in enumerate(rows)}
c1=compiled(a,x);c2=compiled(b,y);assert c1.keys()==c2.keys();assert{k for k in c1 if c1[k]!=c2[k]}==ids
edits={}
for p in(R/'story').glob('*.json'):
 for k,e in json.loads(p.read_text())['messages'].items():assert k not in edits;edits[k]=e
buffers=check_buffers(B,edits);assert len(edits)==1049
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),changed_german_ids=sorted(ids),compressed_segments_verified=verified,changed_segments=changed,all_native_code_and_assets_identical=True,all_non_german_text_symbols_identical=True,all_other_messages_all_languages_unchanged=True,native_controls_page_counts_and_times_preserved=True,text_buffers=buffers)
(B/'intro-dialogue-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments;',len(ids),'German texts changed; code, assets, controls and all other messages preserved.')

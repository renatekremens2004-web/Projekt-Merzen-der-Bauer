/* Private child-field traveller. Model uses one dedicated field-only object slot. */
extern Gfx gJabbaDL[];
static s32 ElfMsg2_IsJabba(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_HYRULE_FIELD && actor->room == 0 && actor->params == 0x3F81;
}
static void ElfMsg2_DrawJabba(Actor* actor, PlayState* play) {
    static Vec3f pivots[2] = { {0,0,0}, JABBA_HEAD_PIVOT };
    s32 slot = Object_GetSlot(&play->objectCtx, OBJECT_JABBA);
    void* objectSegment;
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 350));
    f32 talk = Math_SinS((s16)(play->gameplayFrames * 870));
    if (slot < 0 || !Object_IsLoaded(&play->objectCtx, slot)) return;
    objectSegment = play->objectCtx.slots[slot].segment;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 2 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "jabba", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 2; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) {
            Matrix_RotateY(idle * 0.01f, MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(talk * 0.008f, MTXMODE_APPLY);
        }
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "jabba", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x06, objectSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gJabbaDL);
    gSPSegment(POLY_OPA_DISP++, 0x06, OS_PHYSICAL_TO_K0(gSegments[6]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "jabba", 3);
}
static void ElfMsg2_InitJabba(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_3;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x71B3;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    actor->cullingVolumeDistance = 1700.0f;
    actor->cullingVolumeScale = 180.0f;
    actor->cullingVolumeDownward = 100.0f;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 32);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    this->wallaceCollider.dim.radius = 42;
    this->wallaceCollider.dim.height = 76;
    Actor_SetFocus(actor, 68);
    actor->draw = ElfMsg2_DrawJabba;
}
static void ElfMsg2_UpdateJabba(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 68);
    actor->textId = 0x71B3;
    if (!Actor_TalkOfferAccepted(actor, play) && actor->xzDistToPlayer < 160.0f && fabsf(actor->yDistToPlayer) < 70.0f) {
        Actor_OfferTalk(actor, play, 150.0f);
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

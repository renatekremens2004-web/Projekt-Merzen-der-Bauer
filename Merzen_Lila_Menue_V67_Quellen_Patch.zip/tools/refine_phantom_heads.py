"""Restore the established Burns likeness; export a full-detail Smithers head only."""
from pathlib import Path
import sys,json,math,hashlib,collections,shutil
from PIL import Image
R=Path(__file__).resolve().parent.parent;D=R/'models/phantom-amthor';D.mkdir(exist_ok=True)
# Burns: reuse the already approved CC-BY model from the main Merz replacement.
a=json.loads((R/'tools/adult_bound.json').read_text());chosen={a['target']['Head'],a['target']['Jaw']};garment={(0,74,66),(140,0,90),(82,33,0),(66,33,99)}
def is_garment(v):
 return tuple(v['rgb']) in garment or (tuple(v['rgb'])==(247,247,247) and v['bind'][1]<3000 and v['bind'][2]<0)
triangles=[t for t in a['triangles'] if all(a['vertices'][v]['bone'] in chosen and not is_garment(a['vertices'][v]) for v in t)]
used={v for t in triangles for v in t};lo=min(a['vertices'][v]['bind'][1]for v in used);hi=max(a['vertices'][v]['bind'][1]for v in used);scale=1650/(hi-lo);neck_z=a['bones'][a['target']['Head']]['head'][2]
colours=sorted({tuple(a['vertices'][v]['rgb'])for v in used});assert len(colours)<=15
im=Image.new('RGBA',(64,64),(0,0,0,255))
for i,c in enumerate(colours):
 for y in range(i//4*16,i//4*16+16):
  for x in range(i%4*16,i%4*16+16):im.putpixel((x,y),(*c,255))
im.save(D/'burns_classic_head_palette.png')
m=dict(bones=[],materials=[dict(name='BurnsClassicHead',texture='burns_classic_head_palette.png',size=[64,64])],vertices=[],triangles=[],model='Established CC-BY Mr Burns head and original neutral jaw; garments excluded',uniform_scale=scale,source='adult_bound.json; chicosantossaraiva, CC BY 4.0',source_sha256=hashlib.sha256((R/'tools/adult_bound.json').read_bytes()).hexdigest(),source_triangles=len(triangles),head_height=1650)
for t in triangles:
 corners=[]
 for v in t:
  old=a['vertices'][v];p=list(old['bind']);mat=a['bones'][old['bone']]['matrix'];norm=[sum(mat[i][j]*old['normal'][j]for j in range(3))for i in range(3)];
  length=math.sqrt(sum(x*x for x in norm));nw=[x/length for x in norm];pos=[round((p[2]-neck_z)*scale),round(-(p[1]-lo)*scale+250),round(p[0]*scale)];i=len(m['vertices']);m['vertices'].append(dict(bone=0,position=pos));ci=colours.index(tuple(old['rgb']));uv=[(ci%4*16+8)/64,1-(ci//4*16+8)/64]
  corners.append(dict(vertex=i,normal=[round(nw[2]*127),round(-nw[1]*127),round(nw[0]*127)],uv=uv))
 m['triangles'].append(dict(material=0,corners=corners))
(R/'tools/phantom_burns_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n')
print('Burns classic head:',len(triangles),'triangles, no jacket/shoulders; original neutral jaw.')
# Optional raw full-detail Smithers mesh exported by refine_smithers_fbx.py.
if len(sys.argv)>1:
 p=Path(sys.argv[1]);m=json.loads(p.read_text());im=Image.open(D/m['materials'][0]['texture']).convert('RGB');kept=[];colours=[]
 for t in m['triangles']:
  if t['material']!=0:kept.append((t,None));continue
  samples=[]
  for c in t['corners']:
   u,v=c['uv'];samples.append(im.getpixel((int(u*im.width)%im.width,int((1-v)*im.height)%im.height)))
  col=collections.Counter(samples).most_common(1)[0][0]
  if col in [(99,99,0),(115,16,123)]:continue # shirt/bow-tie remnants at neck cut
  if col==(148,107,0):col=(156,166,176) # restore Smithers' gray hair and eyebrows
  if col not in colours:colours.append(col)
  kept.append((t,col))
 assert len(colours)<=15,colours
 atlas=Image.new('RGBA',(64,64),(0,0,0,255))
 for i,c in enumerate(colours):
  for y in range(i//4*16,i//4*16+16):
   for x in range(i%4*16,i%4*16+16):atlas.putpixel((x,y),(*c,255))
 atlas.save(D/'smithers_head_palette.png');m['materials'][0]['texture']='smithers_head_palette.png';m['materials'][0]['size']=[64,64]
 for t,col in kept:
  if col is not None:
   i=colours.index(col)
   for c in t['corners']:c['uv']=[(i%4*16+8)/64,1-(i//4*16+8)/64]
 m['triangles']=[t for t,col in kept];m['palette_colours']=colours;m['garments_excluded']=True
 (R/'tools/phantom_smithers_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');print('Smithers head:',len(m['triangles']),'triangles, original glasses/eyes retained; colors',colours)

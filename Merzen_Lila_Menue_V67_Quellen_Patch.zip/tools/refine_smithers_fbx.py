"""Blender: retain full supplied facial geometry, clipping above shirt and bow tie."""
import bpy,json,sys,shutil,hashlib
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent.parent;D=R/'models/phantom-amthor';args=sys.argv[sys.argv.index('--')+1:];src=Path(args[0]);out=Path(args[1]);bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.fbx(filepath=str(src));objs=[o for o in bpy.context.scene.objects if o.type=='MESH'];cut=3.00;top=max((o.matrix_world@v.co).z for o in objs for v in o.data.vertices);scale=1650/(top-cut);m=dict(bones=[],materials=[],vertices=[],triangles=[],model='Full-detail Smithers head above shirt and bow tie',source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),uniform_scale=scale,cut_height=cut,head_height=1650);materials={}
def material(mat):
 if mat.name not in materials:
  images=[n.image for n in mat.node_tree.nodes if n.type=='TEX_IMAGE'and n.image];assert images
  path=Path(bpy.path.abspath(images[0].filepath));dst=D/('smithers_'+path.name)
  if path.exists()and path.resolve()!=dst.resolve():shutil.copyfile(path,dst)
  assert dst.exists(),dst
  materials[mat.name]=len(m['materials']);m['materials'].append(dict(name='SmithersHead'+str(len(m['materials'])),texture=dst.name,size=[64,64]))
 return materials[mat.name]
for o in objs:
 mesh=o.data;mesh.calc_loop_triangles();normal=o.matrix_world.to_3x3().inverted().transposed()
 for t in mesh.loop_triangles:
  cs=[]
  for li in t.loops:
   p=o.matrix_world@mesh.vertices[mesh.loops[li].vertex_index].co;n=(normal@mesh.corner_normals[li].vector).normalized();uv=mesh.uv_layers.active.data[li].uv;cs.append(dict(p=p,n=n,uv=Vector(uv)))
  clipped=[]
  for a,b in zip(cs,cs[1:]+cs[:1]):
   ina=a['p'].z>=cut;inb=b['p'].z>=cut
   if ina:clipped.append(a)
   if ina!=inb:
    f=(cut-a['p'].z)/(b['p'].z-a['p'].z);clipped.append({k:a[k].lerp(b[k],f)for k in ['p','n','uv']})
  if len(clipped)<3:continue
  mi=material(mesh.materials[t.material_index])
  for j in range(1,len(clipped)-1):
   corners=[]
   for c in [clipped[0],clipped[j],clipped[j+1]]:
    p=c['p'];n=c['n'].normalized();v=len(m['vertices']);m['vertices'].append(dict(bone=0,position=[round(-(p.y-.10)*scale+100),round(-(p.z-cut)*scale+250),round(p.x*scale)]));corners.append(dict(vertex=v,normal=[round(-n.y*127),round(-n.z*127),round(n.x*127)],uv=list(c['uv'])))
   m['triangles'].append(dict(material=mi,corners=corners))
out.write_text(json.dumps(m,separators=(',',':'))+'\n');print('Full-detail Smithers:',len(m['triangles']),'triangles.')

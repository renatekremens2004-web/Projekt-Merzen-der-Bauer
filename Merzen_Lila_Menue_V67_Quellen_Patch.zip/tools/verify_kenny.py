"""Differential build validation for room-local Kenny and Up/Down boot shortcuts."""
from pathlib import Path
import csv,hashlib,json,re,struct,subprocess,sys
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
from build_story import messages
from verify_bowling_sage_revision import function_bodies
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';base=W/'baseline'
a=(base/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();unpacked=(B/'oot-pal-1.0.z64').read_bytes()
assert hashlib.sha256(a).hexdigest()=='d83e8a5b717e5b597014d2ceede438e7cd890a37ecdddf8710e921b1e73b0b85'
assert len(b)==41943040 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
old=messages((base/'extracted/pal-1.0/text/message_data.h').read_text());new=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());assert set(new)-set(old)=={'71B8','71B9'} and not(set(old)-set(new))
for ident in old:assert old[ident]['header']==new[ident]['header'] and all(old[ident]['parts'][k][2]==new[ident]['parts'][k][2]for k in range(4)),ident
edits={}
for p in(R/'story').glob('*.json'):
 for ident,e in json.loads(p.read_text())['messages'].items():assert ident not in edits;edits[ident]=e
buffers=check_buffers(B,edits);assert len(edits)==1037
for f,h in json.loads(Path('/workspace/back-to-future/native-code-hashes.json').read_text()).items():
 assert hashlib.sha256((O/f).read_bytes()).hexdigest()==h,f
f='src/code/z_scene.c';of=function_bodies((R/'tools/originals/kenny'/f).read_text());nf=function_bodies((O/f).read_text());assert of==nf
f='src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';of=function_bodies((base/f).read_text());nf=function_bodies((O/f).read_text());assert set(nf)-set(of)=={'ElfMsg2_IsKenny','ElfMsg2_KennyVisible','ElfMsg2_DrawKenny','ElfMsg2_InitKenny','ElfMsg2_UpdateKenny'};assert {k for k in of if of[k]!=nf[k]}=={'ElfMsg2_Init','ElfMsg2_Update'}
f='src/overlays/actors/ovl_player_actor/z_player.c';assert(base/f).read_bytes()==(O/f).read_bytes()
helper=(O/'src/overlays/actors/ovl_player_actor/quick_iron_boots.inc.c').read_text();assert helper==(R/'tools/quick_iron_boots.inc.c').read_text()
assert all(n in helper for n in ['BTN_DUP','BTN_DDOWN','EQUIP_INV_BOOTS_HOVER','EQUIP_INV_BOOTS_IRON','Player_SetEquipmentData','Inventory_ChangeEquipment','IS_PAUSED','Player_InCsMode'])
for p in(R/'tools/originals/kenny').rglob('*'):
 if not p.is_file() or p.name in ['z_elf_msg2.c','z_scene.c']:continue
 after=(O/p.relative_to(R/'tools/originals/kenny')).read_text();before=p.read_text()
 if p.suffix=='.c':assert after.startswith(before),p
# Linker relocations account for changed addresses in otherwise untouched assets.
def syms(path):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',path.read_text()):d.setdefault(n,int(x,16))
 return d
ns=syms(B/'oot-pal-1.0.map');os=syms(base/'build/pal-1.0/oot-pal-1.0.map');rels={};sec=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 q=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if q:sec=q[1];rels.setdefault(sec,{})
 q=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if q and sec:rels[sec][int(q[1],16)]=(q[2],q[3])
def linked_word(x,y,off,addr,name):
 if name=='ovl_En_Ossan' and all(p==q or (p==0x194 and q==0x195)for p,q in zip(struct.unpack_from('>HH',x,off),struct.unpack_from('>HH',y,off))):return
 rel=rels.get(name,{}).get(addr);assert rel,(name,hex(addr),'unexplained difference');kind,target=rel
 if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[off:off+2]==y[off:off+2],(name,target)
 elif kind=='R_MIPS_26':assert x[off]>>2==y[off]>>2
 else:assert kind=='R_MIPS_32',kind
names=re.findall(r'DEFINE_DMA_ENTRY\((\w+),',(B/'dmadata_table_spec.h').read_text());expected=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())]+['object_jabba','object_bttf','object_kenny'];assert names==expected
intentional={'makerom','dmadata','code','nes_message_data_static','ger_message_data_static','fra_message_data_static','ovl_Elf_Msg2','ovl_player_actor','HAKAdan_room_0','HAKAdan_room_2','HAKAdan_room_6','object_kenny'};same=[];changed=[];relocated=[];verified=0
for i,name in enumerate(names):
 x=segment(a,i)[2]if i<len(names)-1 else None;start,end,y=segment(b,i)
 if y is None:continue
 if name=='makerom':assert y[:16]==unpacked[start:start+16] and y[24:]==unpacked[start+24:end]
 elif name!='dmadata':assert y==unpacked[start:end],name;verified+=1
 if x==y:same.append(name);continue
 if name in intentional:changed.append(dict(segment=name,before_bytes=len(x)if x is not None else 0,after_bytes=len(y)));continue
 assert len(x)==len(y),(name,'size')
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(x,y))if p!=q}):linked_word(x,y,off,ns['_'+name+'SegmentStart']+off,name)
 relocated.append(name)
assert verified==1512
# Every existing compiled message in every language retains exactly its bytes.
def elf_symbols(path):
 d={}
 for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([tTdDrR]) (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(path)],text=True),re.M):
  addr,size=int(addr,16),int(size,16)
  if size:d[name]=(addr,size,kind)
 return d
for lang in ['nes','ger','fra']:
 before=elf_symbols(W/f'baseline-{lang}.o');after=elf_symbols(B/f'assets/text/{lang}_message_data_static.o');rawold=(W/f'baseline-{lang}.o.bin').read_bytes();rawnew=(B/f'assets/text/{lang}_message_data_static.o.bin').read_bytes()
 for name,(addr,size,_)in before.items():
  na,nsize,_=after[name];assert size==nsize and rawold[addr:addr+size]==rawnew[na:na+size],(lang,name)
 assert len(after)==len(before)+2
oldsy=elf_symbols(base/'build/pal-1.0/oot-pal-1.0.elf');newsy=elf_symbols(B/'oot-pal-1.0.elf');_,_,x=segment(a,names.index('code'));_,_,y=segment(b,names.index('code'));count=0;tables={'sNesMessageEntryTable','sGerMessageEntryTable','sFraMessageEntryTable','gObjectTable','gObjectTableSize'}
for name,(addr,size,kind)in oldsy.items():
 if name in tables or not(os['_codeSegmentStart']<=addr<os['_codeSegmentEnd']):continue
 na,nsize,_=newsy[name];assert size==nsize,(name,'size');xx=x[addr-os['_codeSegmentStart']:addr-os['_codeSegmentStart']+size];yy=y[na-ns['_codeSegmentStart']:na-ns['_codeSegmentStart']+size];assert len(xx)==len(yy)==size
 for off in sorted({j//4*4 for j,(p,q)in enumerate(zip(xx,yy))if p!=q}):linked_word(xx,yy,off,na+off,'code')
 count+=1
# Check private text DMA bounds, including the language tables' following pointer.
def data(name):addr,size,_=newsy[name];return y[addr-ns['_codeSegmentStart']:addr-ns['_codeSegmentStart']+size]
entries=list(struct.iter_unpack('>HBBI',data('sNesMessageEntryTable')))
for ident,nextid in [(0x71B8,0x71B9),(0x71B9,0x71B2)]:
 idx=[e[0]for e in entries].index(ident);assert entries[idx+1][0]==nextid
 for lang,table in [('nes','sNesMessageEntryTable'),('ger','sGerMessageEntryTable'),('fra','sFraMessageEntryTable')]:
  ptr=entries[idx][3]if lang=='nes'else struct.unpack_from('>I',data(table),idx*4)[0];nxt=entries[idx+1][3]if lang=='nes'else struct.unpack_from('>I',data(table),(idx+1)*4)[0];assert 0<nxt-ptr<1280
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),compressed_segments_verified=verified,native_core_symbols_verified=count,previous_messages_all_languages_source_and_compiled_unchanged=True,text_buffers=buffers,new_messages=['71B8','71B9'],new_object_slots=1,shadow_object_budget=json.loads((W/'object-budget.json').read_text()),xwing_storage=json.loads((W/'xwing-storage.json').read_text()),models=json.loads((W/'models.json').read_text()),intentional_segments=changed,relocation_only_segments=relocated,identical_segments=same)
(B/'kenny-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments,',count,'native core symbols,',len(edits),'custom messages; all previous dialogue bytes preserved.')

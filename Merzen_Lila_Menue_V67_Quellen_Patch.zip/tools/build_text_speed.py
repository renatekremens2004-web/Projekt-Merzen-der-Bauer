"""Double ordinary German textbox reveal speed without changing message data/timers.

Run after other source generators. Idempotent; does not reset existing z_message mods.
"""
from pathlib import Path
import sys

HELPER = '''/* Merzen: only ordinary, manually advanced German pages use faster reveal.
 * Keep the native parser, including every control and its arguments, in charge.
 * Conservative whitelist: timed pages, choices, quicktext, SFX, explicit speeds
 * and instrument text retain their exact native reveal behavior.
 */
static s32 Message_CanRevealFaster(PlayState* play) {
    MessageContext* msgCtx = &play->msgCtx;
    s32 pos;

    if (gSaveContext.language != LANGUAGE_GER || sTextIsCredits || sTextboxSkipped ||
        play->csCtx.state != 0 || msgCtx->msgMode != MSGMODE_TEXT_DISPLAYING ||
        msgCtx->textBoxType > TEXTBOX_TYPE_BLUE || msgCtx->textDelay != 0 ||
        msgCtx->decodedTextLen >= ARRAY_COUNT(msgCtx->msgBufDecoded)) {
        return false;
    }
    for (pos = 0; pos <= msgCtx->decodedTextLen; pos++) {
        switch (msgCtx->msgBufDecoded[pos]) {
            case MESSAGE_NEWLINE:
            case MESSAGE_UNSKIPPABLE:
                break;
            case MESSAGE_COLOR:
            case MESSAGE_SHIFT:
                if (++pos >= msgCtx->decodedTextLen) {
                    return false;
                }
                break;
            case MESSAGE_END:
            case MESSAGE_BOX_BREAK:
            case MESSAGE_TEXTID:
            case MESSAGE_EVENT:
                return true;
            default:
                if (msgCtx->msgBufDecoded[pos] < MESSAGE_CHAR_SPACE) {
                    return false;
                }
                break;
        }
    }
    return false;
}

'''
ANCHOR = 'void Message_DrawText(PlayState* play, Gfx** gfxP) {'
OLD = '''    if (msgCtx->textDelayTimer == 0) {
        msgCtx->textDrawPos = i + 1;
        msgCtx->textDelayTimer = msgCtx->textDelay;
'''
NEW = '''    if (msgCtx->textDelayTimer == 0) {
        msgCtx->textDrawPos = i + 1;
        /* Reveal one extra printable byte only. Never step over a control,
         * its arguments, or the decoded page boundary. */
        if (Message_CanRevealFaster(play) && i + 1 < msgCtx->decodedTextLen &&
            MSG_BUF_DECODED[i] >= MESSAGE_CHAR_SPACE && MSG_BUF_DECODED[i + 1] >= MESSAGE_CHAR_SPACE) {
            msgCtx->textDrawPos++;
        }
        msgCtx->textDelayTimer = msgCtx->textDelay;
'''

def apply(oot):
    path = oot / 'src/code/z_message.c'
    source = path.read_text()
    if HELPER in source:
        assert NEW in source
        print('Ordinary German text speed already installed.')
        return
    assert source.count(ANCHOR) == 1
    # Wide and Western renderers share the old tail: change only Western.
    start = source.index(ANCHOR)
    assert OLD in source[start:]
    source = source[:start] + source[start:].replace(OLD, NEW, 1)
    source = source.replace(ANCHOR, HELPER + ANCHOR, 1)
    path.write_text(source)
    print('Ordinary German text: up to two printable bytes per frame; native controls/timers preserved.')

if __name__ == '__main__':
    apply(Path(sys.argv[1]).resolve())

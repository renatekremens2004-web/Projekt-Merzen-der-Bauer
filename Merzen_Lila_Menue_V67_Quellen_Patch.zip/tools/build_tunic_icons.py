"""Cumulative production builder after shadow_tunic, before optional debug edition."""
from pathlib import Path
import sys
R = Path(__file__).resolve().parents[1]
O = Path(sys.argv[1]).resolve()
B = R / 'tools/originals/tunic-icons'

def original(rel):
    p = B / rel
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes((O / rel).read_bytes())
    return p.read_text()

def replace(s, a, b):
    assert s.count(a) == 1, a
    return s.replace(a, b)

for folder in ['src/code', 'src/overlays/misc/ovl_kaleido_scope']:
    (O / folder / 'tunic_color_icons.inc.c').write_bytes((R / 'tools/tunic_color_icons.inc.c').read_bytes())
rel = 'src/code/z_message.c'
s = replace(original(rel), '#include "shadow_tunic_icon.inc.c"', '#include "shadow_tunic_icon.inc.c"\n#include "tunic_color_icons.inc.c"')
s = replace(s, '''        if (itemId == ITEM_TUNIC_KOKIRI && SHADOW_TUNIC_OWNED()) {''', '''        if (itemId == ITEM_TUNIC_GORON || itemId == ITEM_TUNIC_ZORA) {
            CustomTunics_RecolorIcon(msgCtx->textboxSegment + MESSAGE_STATIC_TEX_SIZE, itemId);
        }
        if (itemId == ITEM_TUNIC_KOKIRI && SHADOW_TUNIC_OWNED()) {''')
(O / rel).write_text(s)
rel = 'src/overlays/misc/ovl_kaleido_scope/z_kaleido_scope.c'
s = replace(original(rel), '#include "shadow_tunic_icon.inc.c"', '#include "shadow_tunic_icon.inc.c"\n#include "tunic_color_icons.inc.c"')
for line in [3662, 4356]:
    a = '                             "../z_kaleido_scope_PAL.c", ' + str(line) + ');'
    s = replace(s, a, a + '''
            CustomTunics_RecolorIcon((u8*)pauseCtx->iconItemSegment + ITEM_TUNIC_GORON * ITEM_ICON_SIZE, ITEM_TUNIC_GORON);
            CustomTunics_RecolorIcon((u8*)pauseCtx->iconItemSegment + ITEM_TUNIC_ZORA * ITEM_ICON_SIZE, ITEM_TUNIC_ZORA);''')
(O / rel).write_text(s)
print('Orange/fire and sky-blue/water icons in both pause-load paths and item messages; no new texture buffers.')

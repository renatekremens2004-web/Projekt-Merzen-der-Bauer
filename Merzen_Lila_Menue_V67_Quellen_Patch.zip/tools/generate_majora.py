from pathlib import Path
from PIL import Image
import json,math,shutil
R=Path(__file__).resolve().parent.parent;D=R/'models/majora'
# Archive omits the texture for one lower spike pair (6 triangles).
# A small warm red ramp restores that pair; no game texture is copied.
im=Image.new('RGB',(16,16));im.putdata([(max(0,170+y*3-x),40+y*3,25+y*2) for y in range(16) for x in range(16)]);im.save(D/'060079E0.png')
src=D/'Majora.obj';vs=[];uv=[];ts=[];mat=None
for line in src.read_text().splitlines():
 p=line.split()
 if not p:continue
 if p[0]=='v':vs.append(list(map(float,p[1:4])))
 elif p[0]=='vt':uv.append(list(map(float,p[1:3])))
 elif p[0]=='usemtl':mat=p[1].removeprefix('mtl_')
 elif p[0]=='f':
  corners=[tuple(int(x)-1 if x else -1 for x in c.split('/')) for c in p[1:]]
  for i in range(1,len(corners)-1):ts.append((mat,[corners[0],corners[i],corners[i+1]]))
materials=list(dict.fromkeys(t[0] for t in ts));scale=2200/(max(v[0] for v in vs)-min(v[0] for v in vs));zmin=min(v[2] for v in vs);m={'bones':[],'materials':[{'name':n,'texture':n+'.png','size':list(Image.open(D/(n+'.png')).size)} for n in materials],'vertices':[{'bone':0,'position':[round(x*scale),round((z-zmin)*scale),round(-y*scale)]} for x,y,z in vs],'triangles':[]}
for mat,cs in ts:
 a,b,c=[m['vertices'][v[0]]['position'] for v in cs];u=[b[k]-a[k] for k in range(3)];v=[c[k]-a[k] for k in range(3)];n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];l=math.sqrt(sum(x*x for x in n));n=[round(x/l*127) for x in n];m['triangles'].append({'material':materials.index(mat),'corners':[{'vertex':c[0],'uv':uv[c[1]],'normal':n} for c in cs]})
(R/'tools/majora_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');assert len(ts)==102;print('Mask',len(vs),len(ts),'width22 units')

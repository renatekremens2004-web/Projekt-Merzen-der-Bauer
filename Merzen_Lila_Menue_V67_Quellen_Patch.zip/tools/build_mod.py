from pathlib import Path
import json,re,collections,sys

ROOT=Path(__file__).resolve().parent
if not 2<=len(sys.argv)<=3:
 raise SystemExit('Usage: python3 tools/build_mod.py /path/to/oot [ntsc-1.0|pal-1.0]')
OOT=Path(sys.argv[1]).resolve()
VERSION=sys.argv[2] if len(sys.argv)==3 else 'ntsc-1.0'
if VERSION not in {'ntsc-1.0','pal-1.0'}:raise SystemExit('Unsupported version: '+VERSION)
EXTRACTED=OOT/'extracted'/VERSION
ASSETS=EXTRACTED/'assets/objects'
BACKUPS=ROOT/'originals' if VERSION=='ntsc-1.0' else ROOT/'originals'/VERSION

def original(path):
 path=Path(path);backup=BACKUPS/path.relative_to(OOT)
 backup.parent.mkdir(parents=True,exist_ok=True)
 if not backup.exists():backup.write_bytes(path.read_bytes())
 return backup.read_text()

def generate(key):
 m=json.loads((ROOT/(key+'_bound.json')).read_text());folder=ASSETS/m['object']
 palette={bone:i for i,bone in enumerate(m['palette'])}
 name='gBurns'+key.capitalize()
 # Keep adjacent triangles in the same RSP vertex-cache batch. This leaves
 # room for the original face geometry within the stock object-bank budget.
 adjacent=collections.defaultdict(set)
 for i,t in enumerate(m['triangles']):
  for v in t:adjacent[v].add(i)
 remaining=set(range(len(m['triangles'])));ordered_tris=[]
 while remaining:
  cache=set();frontier=set();batch=[]
  while True:
   candidates=frontier & remaining
   if not candidates:
    if batch:break
    candidates={min(remaining)}
   fitting=[i for i in candidates if len(cache|set(m['triangles'][i]))<=32]
   if not fitting:break
   i=min(fitting,key=lambda i:(len(set(m['triangles'][i])-cache),sum(len(adjacent[v]&remaining) for v in m['triangles'][i]),i))
   t=m['triangles'][i];remaining.remove(i);batch.append(t);cache.update(t)
   for v in t:frontier.update(adjacent[v])
  ordered_tris.extend(batch)
 batches=[];look={};verts=[];tris=[]
 def flush():
  nonlocal look,verts,tris
  if tris:batches.append((verts,tris))
  look={};verts=[];tris=[]
 for tri in ordered_tris:
  if len(look)+len(set(tri)-look.keys())>32:flush()
  for v in tri:
   if v not in look:look[v]=len(verts);verts.append(v)
  tris.append(tri)
 flush()
 packed=[];commands=[]
 for vs,ts in batches:
  ordered=sorted(vs,key=lambda v:m['vertices'][v]['bone']);slot={v:i for i,v in enumerate(ordered)}
  for bone,group in __import__('itertools').groupby(ordered,key=lambda v:m['vertices'][v]['bone']):
   group=list(group);offset=len(packed)
   commands+=['gsSPMatrix((Mtx*)0x%08X, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),'%(0x0D000000+palette[bone]*64),
              'gsSPVertex(&%sVertices[%d], %d, %d),'%(name,offset,len(group),slot[group[0]])]
   packed.extend(m['vertices'][v] for v in group)
  for i in range(0,len(ts),2):
   t=[slot[v] for v in ts[i]]
   if i+1<len(ts):commands.append('gsSP2Triangles(%d,%d,%d,0,%d,%d,%d,0),'%tuple(t+[slot[v] for v in ts[i+1]]))
   else:commands.append('gsSP1Triangle(%d,%d,%d,0),'%tuple(t))
 colors=sorted({tuple(v['rgb']) for v in m['vertices']})
 assert len(colors)<=16
 palette_pixels=[]
 for y in range(16):
  for x in range(16):
   i=(y//4)*4+x//4;r,g,b=colors[i] if i<len(colors) else (0,0,0)
   palette_pixels.append(((r>>3)<<11)|((g>>3)<<6)|((b>>3)<<1)|1)
 lines=['/* Mr. Burns by chicosantossaraiva, CC BY 4.0; adapted to OOT native bones. */',
        'static u64 '+name+'Palette[] = {']
 for i in range(0,len(palette_pixels),4):lines.append('0x'+''.join('%04X'%v for v in palette_pixels[i:i+4])+',')
 lines+=['};',
        'static Vtx '+name+'Vertices[] = {']
 for v in packed:
  assert all(-32768<=x<=32767 for x in v['position'])
  ci=colors.index(tuple(v['rgb']));uv=[(ci%4*4+2)*32,(ci//4*4+2)*32]
  lines.append('{{{%d,%d,%d},0,{%d,%d},{%d,%d,%d,255}}},'%tuple(v['position']+uv+[n&255 for n in v['normal']]))
 lines+=['};','static Gfx '+name+'BodyDL[] = {',
         'gsDPPipeSync(),','gsDPSetCycleType(G_CYC_2CYCLE),',
         'gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),',
         'gsDPSetCombineMode(G_CC_MODULATERGB, G_CC_PASS2),',
         'gsSPClearGeometryMode(G_CULL_BACK | G_CULL_FRONT | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),',
         'gsSPSetGeometryMode(G_LIGHTING | G_SHADE | G_SHADING_SMOOTH | G_ZBUFFER | G_FOG),',
         'gsDPSetTextureLUT(G_TT_NONE),','gsDPSetTextureFilter(G_TF_POINT),',
         'gsSPTexture(0xFFFF,0xFFFF,0,G_TX_RENDERTILE,G_ON),',
         'gsDPLoadTextureBlock('+name+'Palette, G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 16, 0, G_TX_CLAMP, G_TX_CLAMP, 4, 4, G_TX_NOLOD, G_TX_NOLOD),']+commands+['gsSPEndDisplayList(),','};']
 (folder/('burns_'+key+'.inc.c')).write_text('\n'.join(lines)+'\n')
 cpath=folder/(m['object']+'.c');hpath=folder/(m['object']+'.h')
 c=original(cpath);h=original(hpath)
 body=m['bones'][m['target']['Torso']]['dl']
 model_dls={b['dl'] for b in m['bones'] if b['dl']!='NULL'}
 if key=='adult':model_dls.update(['gGanondorfEyesDL','gGanondorfRightHandOpenDL'])
 if key=='young':model_dls.add('gYoungGanondorfOpenLeftHandDL')
 for dl in sorted(model_dls):
  inc=folder/(dl+'.inc.c');original(inc)
  inc.write_text(('    gsSPDisplayList('+name+'BodyDL),\n' if dl==body else '')+'    gsSPEndDisplayList(),\n')
  c=re.sub(r'\bGfx '+re.escape(dl)+r'\[\d+\]', 'Gfx '+dl+'[]',c)
  h=re.sub(r'\bGfx '+re.escape(dl)+r'\[\d+\]', 'Gfx '+dl+'[]',h)
 c=c.replace('#include "ultra64.h"','#include "ultra64.h"\n\n#include "burns_'+key+'.inc.c"',1)
 # Drop stock mesh vertices and palette textures whose display lists were replaced.
 # External actor references and remaining effects/animation data stay intact.
 src='\n'.join(p.read_text(errors='replace') for p in (OOT/'src').rglob('*.c'))
 defs=list(re.finditer(r'(?m)^(?:Vtx|u64|u16|u8) (\w+)\[[^\]]*\] = \{\n#include "([^"\n]+)"\n\};\n',c))
 refs=[]
 for inc in re.findall(r'#include "([^"\n]+)"',c):
  if not inc.endswith('.inc.c'):continue
  for base in [EXTRACTED,folder]:
   ip=base/inc
   if ip.exists():refs.append(ip.read_text());break
 refs='\n'.join(refs)+'\n'+src
 for definition in reversed(defs):
  if not re.search(r'\b'+re.escape(definition[1])+r'\b',refs):
   c=c[:definition.start()]+c[definition.end():]
 cpath.write_text(c);hpath.write_text(h)
 print(key,'static vertex data:',len(packed)*16,'bytes; triangles:',len(m['triangles']),'palette:',len(palette),'model display lists replaced:',len(model_dls))

for key in ['adult','young']:generate(key)

# Burns wears a suit. The separate original cape actor keeps updating for
# cutscene and combat dependencies, while its old cape geometry is hidden.
p=OOT/'src/overlays/actors/ovl_En_Ganon_Mant/z_en_ganon_mant.c';s=original(p)
start=s.index('void EnGanonMant_Draw(Actor* thisx, PlayState* play) {')
a=s.index('{',start);end=a+1;depth=1
while depth:
 if s[end]=='{':depth+=1
 if s[end]=='}':depth-=1
 end+=1
s=s[:a+1]+'\n    /* Mr. Burns uses his own suit; keep cape actor dependencies but hide its mesh. */\n    return;\n'+s[end-1:]
p.write_text(s)


if VERSION=='pal-1.0':
 # In the floating vision only, allow more room for Burns' large head and nose.
 # Keep his eye height fixed while reducing this scene's original giant scale.
 m=json.loads((ROOT/'young_bound.json').read_text())
 eyes=[v['bind'][1] for v in m['vertices'] if v['bone']==m['target']['Head'] and v['rgb']==[0,0,0]]
 eye_y=sum(eyes)/len(eyes)
 vision_scale=0.18
 vision_offset=(eye_y-600.0)*0.3/vision_scale-eye_y
 p=OOT/'src/overlays/actors/ovl_En_Viewer/z_en_viewer.c';s=original(p)
 needle='Actor_SetScale(&this->actor, 0.3f);'
 assert s.count(needle)==1
 s=s.replace(needle, '/* Burns vision framing: preserve eye height with a smaller silhouette. */\n        Actor_SetScale(&this->actor, %.8ff);\n        this->actor.shape.yOffset = %.8ff;'%(vision_scale,vision_offset))
 p.write_text(s)
 print('PAL German default; vision scale',vision_scale,'offset',vision_offset)

if VERSION=='pal-1.0':
 # Native PAL messages and menus; default to German on fresh SRAM.
 p=OOT/'src/code/z_sram.c';s=original(p)
 s=s.replace('LANGUAGE_ENG, // SRAM_HEADER_LANGUAGE','LANGUAGE_GER, // SRAM_HEADER_LANGUAGE')
 s=s.replace('gSaveContext.language = LANGUAGE_ENG;', 'gSaveContext.language = LANGUAGE_GER;')
 p.write_text(s)

"""German mask-specific reactions; preserve native zeros, sales and other languages."""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parent.parent
def apply(oot):
 data=json.loads((ROOT/'planning/MASKEN_ZUORDNUNG.json').read_text());special=data['special']
 def original(p):
  q=ROOT/'tools/originals/masken'/p.relative_to(oot);q.parent.mkdir(parents=True,exist_ok=True)
  if not q.exists():q.write_bytes(p.read_bytes())
  return q.read_text()
 p=oot/'src/code/z_face_reaction.c';s=original(p);s=s.replace('#include "player.h"','#include "player.h"\n#include "save.h"')
 lines=['/* German-only, mask-specific IDs. Native zero entries remain zero. */','const u16 gGermanMaskReactionTextIds[MASK_REACTION_SET_MAX][PLAYER_MASK_MAX] = {']
 for name,row in data['german_rows'].items():lines.append('    { '+', '.join('0x%04X'%v for v in row)+' }, /* '+name+' */')
 lines+=['};','']
 marker='u16 MaskReaction_GetTextId(struct PlayState* play, u32 maskReactionSet) {';assert s.count(marker)==1;s=s.replace(marker,'\n'.join(lines)+marker)
 marker='    return sMaskReactionSetTextIds[maskReactionSet][currentMask];';assert s.count(marker)==1
 s=s.replace(marker,'''    if (gSaveContext.language == LANGUAGE_GER) {
        /* Avoid mentioning the whale visit before the Sapphire was received. */
        if (maskReactionSet == MASK_REACTION_SET_MAN_1_BEARD && currentMask == PLAYER_MASK_ZORA &&
            !CHECK_QUEST_ITEM(QUEST_ZORA_SAPPHIRE)) {
            return 0x%04X;
        }
        return gGermanMaskReactionTextIds[maskReactionSet][currentMask];
    }
'''%special['zora_whale_before']+marker);p.write_text(s)
 (oot/'include/custom_mask_reactions.h').write_text('''#ifndef CUSTOM_MASK_REACTIONS_H
#define CUSTOM_MASK_REACTIONS_H
#define CUSTOM_MASK_KOKIRI_DEBT 0x%04X
#define CUSTOM_MASK_THADDAEUS_GERUDO 0x%04X
#endif
'''%(special['kokiri_debt'],special['thaddaeus_gerudo']))
 p=oot/'src/overlays/actors/ovl_En_Ko/z_en_ko.c';s=original(p).replace('#include "face_reaction.h"','#include "face_reaction.h"\n#include "custom_mask_reactions.h"')
 marker='    EnKo* this = (EnKo*)thisx;\n\n    if (ENKO_TYPE == ENKO_TYPE_CHILD_0';assert s.count(marker)==1
 s=s.replace(marker,'''    EnKo* this = (EnKo*)thisx;

    /* The existing 50-rupee debtor alone gets the thought-reading callback. */
    if (gSaveContext.language == LANGUAGE_GER && !LINK_IS_ADULT && ENKO_TYPE == ENKO_TYPE_CHILD_3 &&
        Player_GetMask(play) == PLAYER_MASK_TRUTH) {
        return CUSTOM_MASK_KOKIRI_DEBT;
    }

    if (ENKO_TYPE == ENKO_TYPE_CHILD_0''');p.write_text(s)
 p=oot/'src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.c';s=original(p).replace('#include "z_en_diving_game.h"','#include "z_en_diving_game.h"\n#include "custom_mask_reactions.h"')
 old='MaskReaction_GetTextId(play, MASK_REACTION_SET_ZORA)';assert s.count(old)==2
 s=s.replace(old,'EnDivingGame_GetMaskReaction(play)')
 marker='void EnDivingGame_Init(Actor* thisx, PlayState* play) {';assert s.count(marker)==1
 helper='''/* Thaddaeus has his own sincere answer instead of the shared Zora answer. */
static u16 EnDivingGame_GetMaskReaction(PlayState* play) {
    if (gSaveContext.language == LANGUAGE_GER && Player_GetMask(play) == PLAYER_MASK_GERUDO) {
        return CUSTOM_MASK_THADDAEUS_GERUDO;
    }
    return MaskReaction_GetTextId(play, MASK_REACTION_SET_ZORA);
}

'''
 s=s.replace(marker,helper+marker);p.write_text(s)
 print('German mask table: 58 distinct supportive Gerudo groups + Thaddaeus; all native zero entries preserved.')
if __name__=='__main__':apply(Path(sys.argv[1]).resolve())

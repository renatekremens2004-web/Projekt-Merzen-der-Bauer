"""Replace only Phantom Ganon's two head display lists and German presentation."""
from pathlib import Path
import sys,re,json,collections
from PIL import Image
from n64_model import emit
R=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();B=R/'originals/phantom_amthor';D=R.parent/'models/phantom-amthor';A=O/'extracted/pal-1.0/assets/objects/object_gnd'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text() if p.suffix!='.png' else b

def carray(name,data,static=True):
 data+=bytes((-len(data))%8)
 return ('static ' if static else '')+'u64 '+name+'[]={\n'+''.join('0x'+data[j:j+8].hex().upper()+',\n' for j in range(0,len(data),8))+'};'
# Palette zero is transparent so the native per-pixel death pattern can clear
# CI4 blocks as well. Models keep their own proportions and neck/head pivot.
models=[];textures=[];headers=[]
for label in ['Burns','Smithers']:
 m=json.loads((R/('phantom_'+label.lower()+'_source.json')).read_text());prefix='Amthor'+label
 text=emit(m,D,prefix)
 for i,mat in enumerate(m['materials']):
  im=Image.open(D/mat['texture']).convert('RGBA').resize(tuple(mat['size']),Image.Resampling.LANCZOS)
  if label=='Smithers' and i==0:
   # This is a shared character swatch atlas. Quantizing its mostly-unused
   # image area loses the yellow skin; weight colours by actual mesh UV use.
   count=collections.Counter()
   for tri in m['triangles']:
    if tri['material']!=i:continue
    samples=[c['uv'] for c in tri['corners']]+[[sum(c['uv'][k] for c in tri['corners'])/3 for k in range(2)]]
    for u,v in samples:
     c=im.getpixel((int(u*im.width)%im.width,int((1-v)*im.height)%im.height))
     if c[3]>=128:count[c[:3]]+=1
   colours=[c for c,n in count.most_common(15)];assert (247,206,0) in colours
   lookup=Image.new('P',(1,1));lookup.putpalette([x for c in colours for x in c]+[0]*(768-3*len(colours)))
   q=im.convert('RGB').quantize(palette=lookup,dither=Image.Dither.NONE)
   # The unused palette tail is black. Redirect that duplicate to the real
   # black entry, keeping all indices in the fifteen-colour payload.
   data=list(q.getdata());black=min(range(len(colours)),key=lambda j:sum(colours[j]));q.putdata([v if v<len(colours) else black for v in data]);pal=[x for c in colours for x in (*c,255)];pal+=[0]*(60-len(pal))
  else:
   q=im.quantize(colors=15,method=Image.Quantize.FASTOCTREE,dither=Image.Dither.NONE);pal=q.getpalette('RGBA') or [];pal+=[0]*(60-len(pal))
  def color(c):return ((c[0]>>3)<<11)|((c[1]>>3)<<6)|((c[2]>>3)<<1)|int(c[3]>=128)
  palette=b'\0\0'+b''.join(color(pal[k:k+4]).to_bytes(2,'big') for k in range(0,60,4));indices=[int(v)+1 if a>=128 else 0 for v,a in zip(q.getdata(),im.getchannel('A').getdata())];data=bytes((indices[j]<<4)|indices[j+1] for j in range(0,len(indices),2))
  pn='g'+prefix+'Palette'+str(i);tn='g'+prefix+'Tex'+str(i)
  for name,payload,isstatic in [(pn,palette,True),(tn,data,False)]:
   text,n=re.subn(r'static u64 '+name+r'\[\]=\{.*?\};',lambda _:carray(name,payload,isstatic),text,flags=re.S);assert n==1
  textures.append((tn,mat['size'][0],mat['size'][1]));headers.append('extern u64 '+tn+'[];')
 text=text.replace('gsSPTexture(0xffff','gsSPDisplayList(0x08000000),\n'+'gsSPTexture(0xffff',1)
 models.append(text)
(A/'amthor_heads.inc.c').write_text('\n'.join(models))
p=A/'object_gnd.c';s=original(p);s=s.replace('#include "ultra64.h"','#include "ultra64.h"\n#include "amthor_heads.inc.c"',1)
for dl,target in [('gPhantomGanonFaceDL','gAmthorBurnsDL'),('object_gnd_0080F8_DL','gAmthorSmithersDL')]:
 original(A/(dl+'.inc.c'));(A/(dl+'.inc.c')).write_text('    gsSPDisplayList('+target+'),\n    gsSPEndDisplayList(),\n')
 s=re.sub(r'Gfx '+dl+r'\[\d+\]', 'Gfx '+dl+'[]',s)
# The two old head vertex arrays no longer have any users; their body, horse,
# original textures, skeleton, animations, collision and effects stay intact.
for name in ['gPhantomGanonFaceVtx','object_gnd_Vtx_005548']:
 s,n=re.subn(r'Vtx '+name+r'\[[^\]]*\] = \{.*?\};\n','',s,flags=re.S);assert n==1
p.write_text(s)
p=A/'object_gnd.h';h=original(p)
for dl in ['gPhantomGanonFaceDL','object_gnd_0080F8_DL']:h=re.sub(r'Gfx '+dl+r'\[\d+\]', 'Gfx '+dl+'[]',h)
h+='\n/* Supplied replacement heads; CPU death-mask clearing uses these buffers. */\n'+'\n'.join(headers)+'\n';p.write_text(h)
# Extend the existing clear-pixel routine, so the own head disappears with
# the armour in the original death effect rather than remaining solid.
p=O/'src/overlays/actors/ovl_Boss_Ganondrof/z_boss_ganondrof.c';s=original(p);marker='void BossGanondrof_ClearPixels(u8* mask, s16 index) {';assert s.count(marker)==1
helper='''static void BossGanondrof_ClearAmthorHeadPixels(u8* mask, s16 index) {
    static void* textures[] = { NAMES };
    static u8 widths[] = { WIDTHS };
    static u8 heights[] = { HEIGHTS };
    s32 i;
    s32 x;
    s32 y;
    s32 startX;
    s32 startY;
    s32 pixel;
    u8* texture;

    if (!mask[index]) {
        return;
    }
    for (i = 0; i < ARRAY_COUNT(textures); i++) {
        texture = SEGMENTED_TO_VIRTUAL(textures[i]);
        startX = (index % 16) * (widths[i] / 16);
        startY = (index / 16) * (heights[i] / 16);
        for (y = 0; y < heights[i] / 16; y++) {
            for (x = 0; x < widths[i] / 16; x++) {
                pixel = (startY + y) * widths[i] + startX + x;
                texture[pixel / 2] &= (pixel & 1) ? 0xF0 : 0x0F;
            }
        }
    }
}

'''.replace('NAMES',', '.join(t[0] for t in textures)).replace('WIDTHS',', '.join(str(t[1]) for t in textures)).replace('HEIGHTS',', '.join(str(t[2]) for t in textures))
s=s.replace(marker,helper+marker);needle='    BossGanondrof_ClearPixels32x16(SEGMENTED_TO_VIRTUAL(gPhantomGanonLimbTex_00B380), mask, index);';assert s.count(needle)==1;s=s.replace(needle,'    BossGanondrof_ClearAmthorHeadPixels(mask, index);\n'+needle);p.write_text(s)
# One small state byte replaces padding. The actor's instance size and all
# original offsets stay unchanged; retries still take the native short intro.
p=O/'src/overlays/actors/ovl_En_fHG/z_en_fhg.h';s=original(p);s=s.replace('char unk_1B0[0x10];','u8 amthorGreetingState;\n    /* 0x01B1 */ char unk_1B1[0x0F];');p.write_text(s)
p=O/'src/overlays/actors/ovl_En_fHG/z_en_fhg.c';s=original(p);s=s.replace('#include "z_en_fhg.h"','#include "z_en_fhg.h"\n#include "message.h"');marker='    if (this->cutsceneState != INTRO_FINISH) {';assert s.count(marker)==1
s=s.replace(marker,'''    /* German Amthor greeting, after his face reveal and before the title.
     * EnfHG_Update already decremented timer[0]; restore it only while waiting.
     * Resume the original frame sequence after a normal A-button advance. */
    if (this->amthorGreetingState == 1) {
        if (Message_GetState(&play->msgCtx) != TEXT_STATE_EVENT || !Message_ShouldAdvance(play)) {
            this->timers[0]++;
            return;
        }
        Message_CloseTextbox(play);
        this->amthorGreetingState = 2;
    }
    if (gSaveContext.language == LANGUAGE_GER && this->cutsceneState == INTRO_LAUGH &&
        this->timers[0] == 50 && this->amthorGreetingState == 0) {
        /* The ordinary room light replaces the skull's violet reveal light.
         * Own face colours still receive native directional light and fog. */
        play->envCtx.lightSettingOverride = 0;
        play->envCtx.lightBlendRateOverride = 20;
        Message_StartTextbox(play, 0x209B, &bossGnd->actor);
        this->amthorGreetingState = 1;
        this->timers[0]++;
        return;
    }

'''+marker);p.write_text(s)
# PAL boss-name textures contain three stacked 128x40 language plates.
# Keep English/French bytes and the native allocation exactly unchanged.
p=O/'extracted/pal-1.0/assets/objects/object_fhg/gPhantomGanonTitleCardTex.ia8.png';backup=original(p);im=Image.open(backup).convert('RGBA');assert im.size==(128,120)
plate=Image.open(D/'amthor_bossname_de.png').convert('RGBA');assert plate.size==(128,40)
im.paste(plate,(0,40));im.save(p)
# Move the existing long Jabu shopping speech from the high platform NPC
# to the accessible blue-shirt moustached man. Swap message selections, not
# page layouts or actor placements. Worn-mask reactions keep first priority.
p=O/'src/overlays/actors/ovl_En_Hy/z_en_hy.c';s=original(p)
marker='    switch (ENHY_GET_TYPE(&this->actor)) {';start=s.index('u16 EnHy_GetTextId');at=s.index(marker,start)
s=s[:at]+"""    if (gSaveContext.language == LANGUAGE_GER &&
        (play->sceneId == SCENE_MARKET_DAY || play->sceneId == SCENE_MARKET_NIGHT) &&
        GET_EVENTCHKINF(EVENTCHKINF_ZELDA_FLED_CASTLE)) {
        if (ENHY_GET_TYPE(&this->actor) == ENHY_TYPE_MAN_2_MUSTACHE_BLUE_SHIRT) {
            return 0x7044;
        }
        if (ENHY_GET_TYPE(&this->actor) == ENHY_TYPE_MAN_2_ALT_MUSTACHE) {
            return 0x7046;
        }
    }

"""+s[at:];p.write_text(s)
# The dedicated placeholder has no callers in other languages. Use the native
# greeting template's bottom placement, keeping the revealed face unobscured.
p=O/'extracted/pal-1.0/text/message_data.h';s=p.read_text();old='DEFINE_MESSAGE(0x209B, TEXTBOX_TYPE_BLACK, TEXTBOX_POS_VARIABLE,';new='DEFINE_MESSAGE(0x209B, TEXTBOX_TYPE_BLACK, TEXTBOX_POS_BOTTOM,'
assert old in s or new in s;s=s.replace(old,new);p.write_text(s)
print('Phantom Amthor: two own heads; native reveal/battle skeleton; German greeting 209B; German title plate; native death-pattern support.')

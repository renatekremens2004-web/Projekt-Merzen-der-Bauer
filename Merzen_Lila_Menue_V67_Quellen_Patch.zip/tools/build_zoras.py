"""Install narrowly scoped presentation hooks for the German Zora chapter."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();B=R/'originals/zoras'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
# Shared map text remains native everywhere except the Jabu-Jabu scene.
p=O/'src/code/z_message.c';s=original(p);marker='    MessageContext* msgCtx = &play->msgCtx;\n';a=s.index('void Message_StartTextbox(');b=s.index('\n}',a);body=s[a:b];assert body.count(marker)==1
body=body.replace(marker,marker+'''
    if (gSaveContext.language == LANGUAGE_GER && play->sceneId == SCENE_JABU_JABU && textId == 0x0066) {
        textId = 0x013E;
    }
''',1);s=s[:a]+body+s[b:];p.write_text(s)
# Keep the native merchant's item, price and continuation to 10A3.
p=O/'src/overlays/actors/ovl_En_Dns/z_en_dns.c';s=original(p);marker='this->actor.textId = sStartingTextIds[DNS_GET_TYPE(&this->actor)];';assert s.count(marker)==2
s=s.replace(marker,'''this->actor.textId = (gSaveContext.language == LANGUAGE_GER && play->sceneId == SCENE_JABU_JABU &&
                          DNS_GET_TYPE(&this->actor) == DNS_TYPE_DEKU_NUTS_5)
                             ? 0x0130
                             : sStartingTextIds[DNS_GET_TYPE(&this->actor)];''');p.write_text(s)
# Insert one freely advanced greeting at the end of the original boss intro.
# Original title/camera timers and the combat state machine remain native.
p=O/'src/overlays/actors/ovl_Boss_Va/z_boss_va.c';s=original(p);s=s.replace('#include "z_boss_va.h"','#include "z_boss_va.h"\n#include "message.h"');marker='        case INTRO_FINISH:\n            this->timer--;';assert s.count(marker)==1
s=s.replace(marker,'''        case INTRO_FINISH:
            if (gSaveContext.language == LANGUAGE_GER && this->timer == 1) {
                Vec3f greetingAt = this->actor.world.pos;
                Vec3f greetingEye = this->actor.world.pos;

                greetingAt.y += 100.0f;
                greetingEye.y += 110.0f;
                greetingEye.z += 280.0f;
                Play_SetCameraAtEye(play, sSubCamId, &greetingAt, &greetingEye);
                Play_SetCameraFov(play, sSubCamId, 60.0f);
                Message_StartTextbox(play, 0x013C, &this->actor);
                this->timer = -1;
                break;
            }
            if (this->timer == -1) {
                if (Message_GetState(&play->msgCtx) != TEXT_STATE_EVENT || !Message_ShouldAdvance(play)) {
                    break;
                }
                Message_CloseTextbox(play);
                this->timer = 1;
            }
            this->timer--;''');p.write_text(s)
# Ruto really stays away after handing over the stone; dungeon appearances
# and the older Ruto actor are not touched.
p=O/'src/overlays/actors/ovl_En_Ru1/z_en_ru1.c';s=original(p);marker='void EnRu1_InitBesideKingZora(EnRu1* this, PlayState* play) {\n';assert s.count(marker)==1
s=s.replace(marker,marker+'''    if (gSaveContext.language == LANGUAGE_GER && CHECK_QUEST_ITEM(QUEST_ZORA_SAPPHIRE)) {
        Actor_Kill(&this->actor);
        return;
    }

''');p.write_text(s)
print('German Jabu map/merchant, Barinade greeting and Ruto disappearance installed.')

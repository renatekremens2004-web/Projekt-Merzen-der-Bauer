"""Uniform offline size adjustment; retain topology, normals, textures and animation angles."""
from pathlib import Path
import json
R=Path(__file__).resolve().parent.parent
for key,height in [('wawaluigi',100),('wallace_adult',90)]:
 p=R/f'tools/{key}_source.json';m=json.loads(p.read_text());before=m['height_game_units'];factor=height/before
 if before!=height:
  for value in m['vertices']+m['bones']:value['position']=[round(x*factor)for x in value['position']]
  if 'pivots'in m:m['pivots']=[b['position']for b in m['bones']]
  m['height_game_units']=height
  m['size_adjustment']={'from_game_units':before,'to_game_units':height,'uniform_factor':factor,'topology_normals_uvs_unchanged':True}
  p.write_text(json.dumps(m,separators=(',',':'))+'\n')
 print(key,before,'->',height)
m=json.loads((R/'tools/wallace_adult_source.json').read_text());p=R/'tools/wallace_adult_draw.inc.c'
import re
s=p.read_text();values=', '.join('{'+','.join(map(str,b['position']))+'}'for b in m['bones'])
s,n=re.subn(r'(static Vec3f pivots\[\] = \{).*?(\};)',lambda q:q[1]+' '+values+' '+q[2],s,count=1);assert n==1;p.write_text(s)

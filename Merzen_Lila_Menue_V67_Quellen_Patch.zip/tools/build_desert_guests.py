"""Final builder after build_mystery_machine.py; preserve all existing scenes/dialogue."""
from pathlib import Path
import sys,json,re
from n64_model import emit
from build_story import add_private_message,messages,Layout,rewrite,closing
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/desert-guests'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
def write(p,s):
 if not p.exists()or p.read_text()!=s:p.write_text(s)
models={k:json.loads((R/'tools'/f'{k}_source.json').read_text())for k in ['meowth','jimmy','mackey','marty','doc']}
table='';spec=''
for i,key in enumerate(['meowth','jimmy','mackey']):
 prefix=key.title();A=O/f'extracted/pal-1.0/assets/objects/object_{key}';A.mkdir(parents=True,exist_ok=True);code='#include "ultra64.h"\n#include "animation.h"\n#include "gfx.h"\n'+emit(models[key],R/'models'/key,prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');write(A/f'object_{key}.c',code)
 table+=f'\n/* 0x{0x19A+i:04X} */ DEFINE_OBJECT(object_{key}, OBJECT_{key.upper()})\n';spec+=f'\nbeginseg\n    name "object_{key}"\n    compress\n    romalign 0x1000\n    include "$(BUILD_DIR)/assets/objects/object_{key}/object_{key}.o"\n    number 6\nendseg\n'
for rel,extra in [('include/tables/object_table.h',table),('spec/spec',spec)]:p=O/rel;write(p,original(p)+extra)
def append(sc,typ,room,fragments,objfragments,actors,obj):
 D=O/f'extracted/pal-1.0/assets/scenes/{typ}/{sc}';p=D/f'{sc}_room_{room}.h';h=original(p)
 for fragment in fragments:
  p=next(D.glob(f'{sc}_room_{room}_*{fragment}_ActorEntryList.inc.c'));s=original(p);n=s.count('ACTOR_');s+=''.join('    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, { '+', '.join(map(str,rot))+' }, 0x%04X }, /* '%param+comment+' */\n'for pos,rot,param,comment in actors);write(p,s);macro='LENGTH_'+p.name.replace('.inc.c','');h,k=re.subn(rf'(#define {macro} ){n}\b',lambda q:q[1]+str(n+len(actors)),h);assert k==1,(p,n)
 for fragment in objfragments:
  p=next(D.glob(f'{sc}_room_{room}_*{fragment}_ObjectList.inc.c'));s=original(p);n=s.count('OBJECT_');write(p,s+'    '+obj+', /* one room-local guest object */\n');macro='LENGTH_'+p.name.replace('.inc.c','');h,k=re.subn(rf'(#define {macro} ){n}\b',lambda q:q[1]+str(n+1),h);assert k==1,(p,n)
 write(D/f'{sc}_room_{room}.h',h)
append('spot11','overworld',0,['03000474'],['03000458'],[([-100,-32,-200],[0,0,0],0x3F82,'adult Marty, first meeting'),([20,-32,-200],[0,0,0],0x3F83,'adult Doc, first meeting'),([-160,-31,-430],[0,0,0],0x3F84,'parked car on flat sand')],'OBJECT_BTTF')
append('jyasinzou','dungeons',19,['03000048'],['03000040'],[([2050,843,510],[0,-16384,0],0x3F8D,'adult Mauzi beside lower stair landing')],'OBJECT_MEOWTH')
append('spot20','overworld',0,['03000340','0300054C'],['03000330','03000540'],[([850,0,-2850],[0,0,0],0x3F8E,'Jimmy, outer yard outside horse racing track')],'OBJECT_JIMMY')
append('kakariko','indoors',0,['03000054'],['03000040'],[([-140,0,60],[0,16384,0],0x3F8F,'adult Mr Mackey in the normal Kakariko guest house')],'OBJECT_MACKEY')
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);helper=(R/'tools/bttf_actor.inc.c').read_text()
for key in ['marty','doc']:helper=helper.replace(key.upper()+'_PIVOTS',','.join('{'+','.join(map(str,b['position']))+'}'for b in models[key]['bones']))
a=s.index('/* Private child-castle tableau:');b=s.index('/* Private child-field traveller.',a);s=s[:a]+helper+'\n'+s[b:]
helper=(R/'tools/desert_guests_actor.inc.c').read_text().replace('DESERT_GUEST_PIVOTS',','.join('{'+','.join('{'+','.join(map(str,b['position']))+'}'for b in models[k]['bones'])+'}'for k in ['meowth','jimmy','mackey']));needle='/* Parked van:';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
for action in ['Init','Update']:
 needle=f'void ElfMsg2_{action}(Actor* thisx, PlayState* play) {{\n    ElfMsg2* this = (ElfMsg2*)thisx;';assert s.count(needle)==1;s=s.replace(needle,needle+f'\n    if (ElfMsg2_IsDesertGuest(thisx, play)) {{\n        ElfMsg2_{action}DesertGuest(this, play);\n        return;\n    }}')
s=s.replace('if (ElfMsg2_IsMysteryInc(thisx, play) ||','if (ElfMsg2_IsDesertGuest(thisx, play) || ElfMsg2_IsMysteryInc(thisx, play) ||');write(p,s)
dialogues={
 '71BF':['Marty: Hey, Fremder! Bist Du auch wegen Friedrich Merz hier?','Marty: Der Typ ist ein ganz mieser Kerl. Und eine feige Sau! Mann, das ist doch der reinste Albtraum!'],
 '71C0':['Doc: Ruhig, Marty! Unserem fremden Freund hilft es wenig, wenn Du hier die ganze Wüste anschreist.'],
 '71C1':['Marty: Schon gut, Doc. Aber der Kerl macht dieses ganze Land fertig! Das ist echt stark... im übelsten Sinne.'],
 '71C2':['Doc: Grundgütiger, Marty! Denk an unsere Mission. Wir werden das Ganze schon wieder ins Lot bringen.','Doc: Und Du, Fremder: Sei vorsichtig. Bei diesem Mann ist selbst die Zukunft keine sichere Sache.'],
 '71C3':['Ich bin Mauzi! In diesem Tempel gibt\'s bestimmt große Beute!','Diese goldenen Statuen! Die ganzen Schatztruhen! Da kribbelt mir das Münzchen auf der Stirn!','Du kümmerst Dich um Friedrich Merz, ich mich um den Reichtum. Ein genialer Plan, miuaz genau!'],
 '71C4':['Ich bin Jimmy Neutron, junges Genie! Ich hatte einen GEDANKENBLITZ!','Jetzt helfe ich Luigi auf dieser Farm mit meinen neuesten Erfindungen!','Mein automatischer Milchsortierer erkennt Vanillemilch, Schokomilch und... normale Milch. Noch bevor man sie hergestellt hat!','Das mit der explosionsfreien Inbetriebnahme krieg ich auch noch hin. Wissenschaft braucht eben Zeit!'],
 '71C5':['Ich bin Mr. Mackey, mhhkay? Und ich bin NICHT Friedrich Merz!','Nur weil jemand einen großen Kopf und wenig Haare hat, ist er doch nicht gleich dieser Kerl, mhhkay!','Gestern hat mich einer nach Steuersenkungen gefragt. Ich bin Schulberater, mhhkay!','Dieses ständige Verwechseln ist nicht okay. Also wirklich nicht okay, mhhkay.']}
entries={ident:dict(new_message=True,insert_before='71B2',native_template='009E'if ident in ['71BF','71C0','71C1']else'0022',reserve_text='New guests.',pages=pages)for ident,pages in dialogues.items()}
(R/'story/desert_guests_de.json').write_text(json.dumps(dict(chapter='Erste Zeitreisenden-Begegnung und erwachsene Gäste',orthography='de-vor-1996',messages=entries),ensure_ascii=False,indent=2)+'\n')
p=O/'extracted/pal-1.0/text/message_data.h';s=original(p);native=messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
for ident,e in entries.items():
 s=add_private_message(s,ident,e);a,b,_=messages(s)[ident]['parts'][2];body,_=rewrite(native[e['native_template']]['parts'][2][2],e,Layout(O),ident);s=s[:a]+body+s[b:]
blocks=[]
for ident in entries:
 a=s.index('DEFINE_MESSAGE(0x'+ident+',');b=closing(s,a+len('DEFINE_MESSAGE('))+1
 while b<len(s)and s[b]=='\n':b+=1
 blocks.append(s[a:b]);s=s[:a]+s[b:]
a=s.index('DEFINE_MESSAGE(0x71B2,');s=s[:a]+''.join(blocks)+s[a:];write(p,s)
print('Adult-only desert BTTF, Mauzi, Jimmy, Mackey; seven new private messages; original castle dialogue unchanged; improved BTTF gestures in both eras.')

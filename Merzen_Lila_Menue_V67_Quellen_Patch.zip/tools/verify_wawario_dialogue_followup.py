"""Prove the last dialogue additions leave the already tested imported models and NPC code intact."""
from pathlib import Path
import csv,hashlib,json,sys
from verify_story import segment
O=Path(sys.argv[1]);W=Path(sys.argv[2]);B=O/'build/pal-1.0';before=(W/'model-tested.z64').read_bytes();after=(B/'oot-pal-1.0-compressed.z64').read_bytes();names=[r['Name']for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())]
preserved={}
for name in ['ovl_Elf_Msg2','ovl_En_Go2','ovl_En_Tg','ovl_En_Hy','ovl_Boss_Ganon2','ovl_Boss_Mo','object_du','object_zo','object_sa','ganon_demo_room_0','spot09_room_0','spot12_room_0','HIDAN_room_5','ddan_room_2']:
 _,_,a=segment(before,names.index(name));_,_,b=segment(after,names.index(name));assert a==b,name;preserved[name]=hashlib.sha256(a).hexdigest()
report=dict(model_tested_rom_sha256=hashlib.sha256(before).hexdigest(),final_rom_sha256=hashlib.sha256(after).hexdigest(),byte_identical_model_and_actor_segments=preserved,followup_changes_only_dialogue_sources=True)
(B/'wawario-dialogue-preservation.json').write_text(json.dumps(report,indent=2)+'\n');print('Retained',len(preserved),'tested model/actor segments byte-for-byte')

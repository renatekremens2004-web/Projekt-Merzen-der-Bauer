"""One child-only Wallace NPC in Dodongo's Cavern's bomb-flower stair room (room 2)."""
from pathlib import Path
import json,sys
from n64_model import emit
R=Path(__file__).resolve().parent.parent
def apply(oot):
 def original(p):
  b=R/'tools/originals/wallace'/p.relative_to(oot);b.parent.mkdir(parents=True,exist_ok=True)
  if not b.exists():b.write_bytes(p.read_bytes())
  return b.read_text()
 d=oot/'extracted/pal-1.0/assets/scenes/dungeons/ddan'
 m=json.loads((R/'tools/wallace_source.json').read_text())
 generated=emit(m,R/'models/wallace','Wallace',rigged=True).replace('static Gfx gWallaceBodyDL[]={','Gfx gWallaceDL[]={').replace('gWallaceBodyDL','gWallaceDL')
 (d/'wallace_model.inc.c').write_text(generated)
 p=d/'ddan_room_2.c';p.write_text(original(p)+'\n#include "wallace_model.inc.c"\n')
 p=d/'ddan_room_2_0300004C_ActorEntryList.inc.c';s=original(p);assert s.count('ACTOR_')==27
 p.write_text(s+'''    {
        ACTOR_ELF_MSG2,
        { -2250, 0, -1160 }, /* quiet west edge; clear of stairs, doors and bomb flowers */
        { 0, -32768, 0 },
        0x3F9A, /* unique Wallace instance, not a Navi hint */
    },
''')
 p=d/'ddan_room_2.h';s=original(p);old='#define LENGTH_ddan_room_2_0300004C_ActorEntryList 27';assert s.count(old)==1;p.write_text(s.replace(old,old[:-2]+'28'))
 a=oot/'src/overlays/actors/ovl_Elf_Msg2'
 p=a/'z_elf_msg2.h';s=original(p).replace('#include "actor.h"','#include "actor.h"\n#include "collision_check.h"').replace('} ElfMsg2; // size = 0x0150','    /* Only the dedicated Wallace instance initializes/uses this cylinder. */\n    ColliderCylinder wallaceCollider;\n} ElfMsg2;');p.write_text(s)
 p=a/'z_elf_msg2.c';s=original(p)
 s=s.replace('#include "segmented_address.h"','#include "segmented_address.h"\n#include "z_lib.h"\n#include "libc/math.h"')
 marker='void ElfMsg2_Init(Actor* thisx, PlayState* play) {'
 helper=(R/'tools/wallace_actor.inc.c').read_text();assert s.count(marker)==1;s=s.replace(marker,helper+'\n'+marker)
 marker='    PRINTF(VT_FGCOL(CYAN) " Elf_Msg2_Actor_ct';assert s.count(marker)==1
 s=s.replace(marker,'''    if (ElfMsg2_IsWallace(thisx, play)) {
        ElfMsg2_InitWallace(this, play);
        return;
    }

'''+marker)
 marker='void ElfMsg2_Destroy(Actor* thisx, PlayState* play) {\n}';assert s.count(marker)==1
 s=s.replace(marker,'''void ElfMsg2_Destroy(Actor* thisx, PlayState* play) {
    if (ElfMsg2_IsWallace(thisx, play)) {
        Collider_DestroyCylinder(play, &((ElfMsg2*)thisx)->wallaceCollider);
    }
}''')
 marker='void ElfMsg2_Update(Actor* thisx, PlayState* play) {\n    ElfMsg2* this = (ElfMsg2*)thisx;';assert s.count(marker)==1
 s=s.replace(marker,marker+'''
    if (ElfMsg2_IsWallace(thisx, play)) {
        ElfMsg2_UpdateWallace(this, play);
        return;
    }
''');p.write_text(s)
 print('Wallace: child-only German NPC; room 2; 1444 triangles; own rigid idle/gesture matrices.')
if __name__=='__main__':apply(Path(sys.argv[1]).resolve())

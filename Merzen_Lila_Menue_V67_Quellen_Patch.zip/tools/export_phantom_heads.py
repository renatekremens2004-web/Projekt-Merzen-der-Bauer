"""Export only supplied head meshes, in rest pose, with one uniform scale each."""
import bpy,json,math,shutil,hashlib,sys
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parent.parent;W=R.parent/'phantom-amthor';D=R/'models/phantom-amthor';D.mkdir(exist_ok=True)
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
burns=Path(args[0]) if args else next((W/'input/burns').rglob('burns_lowpoly.obj'))
smithers=Path(args[1]) if len(args)>1 else next((W/'input/smithers').rglob('*.fbx'))
report={}
for label,path,cut,center in [('Burns',burns,0.62,0.0),('Smithers',smithers,2.86,0.10)]:
 bpy.ops.wm.read_factory_settings(use_empty=True)
 if path.suffix=='.fbx':bpy.ops.import_scene.fbx(filepath=str(path))
 else:bpy.ops.wm.obj_import(filepath=str(path))
 objs=[o for o in bpy.context.scene.objects if o.type=='MESH']
 for obj in objs:
  bpy.context.view_layer.objects.active=obj
  mod=obj.modifiers.new('N64 head budget','DECIMATE');mod.ratio=.38 if label=='Burns' else .65;mod.use_collapse_triangulate=True
  bpy.ops.object.modifier_apply(modifier=mod.name)
 top=max((o.matrix_world@v.co).z for o in objs for v in o.data.vertices);scale=1800/(top-cut)
 m={'bones':[],'materials':[],'vertices':[],'triangles':[]};mats={};rawcount=0
 def addmat(mat):
  if mat.name not in mats:
   images=[n.image for n in mat.node_tree.nodes if n.type=='TEX_IMAGE' and n.image];assert images
   src=Path(bpy.path.abspath(images[0].filepath));dst=D/(label.lower()+'_'+src.name);shutil.copyfile(src,dst)
   mats[mat.name]=len(m['materials']);m['materials'].append({'name':label+str(len(m['materials'])),'texture':dst.name,'size':[64,64] if 'burns.png' in src.name else ([32,32] if 'eyeball' in src.name else [64,64])})
  return mats[mat.name]
 for obj in objs:
  mesh=obj.data;mesh.calc_loop_triangles();matr=obj.matrix_world.to_3x3().inverted().transposed()
  for t in mesh.loop_triangles:
   cs=[]
   for li in t.loops:
    vi=mesh.loops[li].vertex_index;pw=obj.matrix_world@mesh.vertices[vi].co;nw=(matr@mesh.corner_normals[li].vector).normalized();uv=mesh.uv_layers.active.data[li].uv
    cs.append(dict(p=pw,n=nw,uv=Vector(uv)))
   # Clip at neck plane, interpolating every corner attribute. No face stretching.
   out=[]
   for a,b in zip(cs,cs[1:]+cs[:1]):
    ina=a['p'].z>=cut;inb=b['p'].z>=cut
    if ina:out.append(a)
    if ina!=inb:
     f=(cut-a['p'].z)/(b['p'].z-a['p'].z);out.append({k:a[k].lerp(b[k],f) for k in ['p','n','uv']})
   if len(out)<3:continue
   mat=addmat(mesh.materials[t.material_index]);rawcount+=1
   for j in range(1,len(out)-1):
    tri=[]
    for c in [out[0],out[j],out[j+1]]:
     p=c['p'];n=c['n'].normalized();pos=[round(-(p.y-center)*scale+200),round(-(p.z-cut)*scale+250),round(p.x*scale)]
     normal=[round(-n.y*127),round(-n.z*127),round(n.x*127)];i=len(m['vertices']);m['vertices'].append({'bone':0,'position':pos});tri.append({'vertex':i,'normal':normal,'uv':list(c['uv'])})
    m['triangles'].append({'material':mat,'corners':tri})
 m.update(model='Supplied '+label+' head only',source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),uniform_scale=scale,cut_height=cut)
 (R/'tools'/('phantom_'+label.lower()+'_source.json')).write_text(json.dumps(m,separators=(',',':'))+'\n')
 report[label]=dict(triangles=len(m['triangles']),uniform_scale=scale,bounds=[[min(v['position'][i] for v in m['vertices']),max(v['position'][i] for v in m['vertices'])]for i in range(3)],materials=m['materials'])
(W/'heads-report.json').write_text(json.dumps(report,indent=2));print(report)

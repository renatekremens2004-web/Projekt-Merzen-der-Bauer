"""German adult lab intro only. Keep the actor's native 4018 state and all trade/reward checks."""
from pathlib import Path
import sys
O=Path(sys.argv[1]).resolve();R=Path(__file__).resolve().parent
p=O/'src/overlays/actors/ovl_En_Mk/z_en_mk.c';backup=R/'originals/wald_nachschlag'/p.relative_to(O);backup.parent.mkdir(parents=True,exist_ok=True)
if not backup.exists():backup.write_bytes(p.read_bytes())
s=backup.read_text();needle='player->actor.textId = 0x4018;';assert s.count(needle)==2
s=s.replace(needle,'player->actor.textId = (gSaveContext.language == LANGUAGE_GER && LINK_IS_ADULT) ? 0x0199 : 0x4018;')
p.write_text(s)
print('Lab: German adult intro 0199; child, mask, swim reward and trade branches unchanged.')

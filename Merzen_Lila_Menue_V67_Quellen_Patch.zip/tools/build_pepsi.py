"""Append one friendly Pepsiman and six tiny native Navi-check cans, after all legacy gag builders."""
from pathlib import Path
import sys,json,re
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();D=O/'extracted/pal-1.0/assets/scenes/dungeons/MIZUsin';B=R/'tools/originals/pepsi'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
models={k:json.loads((R/f'tools/{k}_source.json').read_text())for k in ['pepsiman','pepsi_can','pepsi_crushed']}
# Each added actor is optional German flavor. Native room contents/collision remain byte-identical.
placements={7:[('can',[-3330,1060,-4050])],9:[('can',[-1265,60,-1540])],16:[('man',[-1160,108,-2790]),('can',[-1390,108,-2820]),('crushed',[-1380,108,-2990])],17:[('can',[1060,780,75])],19:[('can',[1730,780,-55])]}
for room,entries in placements.items():
 chunks=[]
 for kind in dict.fromkeys(k for k,p in entries):
  key='pepsiman'if kind=='man'else 'pepsi_'+kind;prefix='Pepsiman'if kind=='man'else f'Pepsi{kind.title()}Room{room}';g=emit(models[key],R/'models/pepsi',prefix,rigged=kind=='man')
  if kind=='man':g=g.replace('static Gfx gPepsimanBodyDL[]={','Gfx gPepsimanDL[]={').replace('gPepsimanBodyDL','gPepsimanDL')
  g=g.replace('g'+prefix+'BodyDL','g'+prefix+'DL')
  chunks.append(g)
 inc=f'pepsi_room_{room}_model.inc.c';(D/inc).write_text('\n'.join(chunks));p=D/f'MIZUsin_room_{room}.c';p.write_text(original(p)+f'\n#include "{inc}"\n')
 p=next(D.glob(f'MIZUsin_room_{room}_*ActorEntryList.inc.c'));s=original(p);count=s.count('ACTOR_')
 for kind,pos in entries:
  params={'man':'0x3F72','can':'0x3F73','crushed':'0x3F74'}[kind];rot='{ 0, -16384, 0 }'if kind=='man'else '{ 2, 0, 1 }'
  s+='    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, '+rot+', '+params+' }, /* optional Pepsi '+kind+' */\n'
 p.write_text(s);p=D/f'MIZUsin_room_{room}.h';s=original(p);pattern=rf'(#define LENGTH_MIZUsin_room_{room}_\w+_ActorEntryList )'+str(count)+r'\b';s,n=re.subn(pattern,lambda m:m[1]+str(count+len(entries)),s);assert n==1;p.write_text(s)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);helper=(R/'tools/pepsi_actor.inc.c').read_text().replace('PEPSIMAN_PIVOTS',', '.join('{'+','.join(map(str,b['position']))+'}'for b in models['pepsiman']['bones']));needle='void ElfMsg2_Init(Actor* thisx, PlayState* play) {';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
needle='    if (ElfMsg2_IsWallace(thisx, play)) {\n        ElfMsg2_InitWallace';assert s.count(needle)==1;s=s.replace(needle,'    if (ElfMsg2_IsPepsiman(thisx, play)) {\n        ElfMsg2_InitPepsiman(this, play);\n        return;\n    }\n\n'+needle)
needle='        /* Room 21 is a later west-side corridor';assert s.count(needle)==1;s=s.replace(needle,'''        if (ElfMsg2_IsPepsiCan(thisx, play)) {
            if (LINK_IS_CHILD || gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 4.0f);
            thisx->shape.rot.y = (s16)(thisx->home.pos.x * 71.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = 0x3073;
            thisx->draw = ElfMsg2_DrawPepsiCan;
        }
'''+needle)
s=s.replace('    if (ElfMsg2_IsWallace(thisx, play)) {\n        Collider_DestroyCylinder','    if (ElfMsg2_IsWallace(thisx, play) || ElfMsg2_IsPepsiman(thisx, play)) {\n        Collider_DestroyCylinder')
needle='    if (ElfMsg2_IsWallace(thisx, play)) {\n        ElfMsg2_UpdateWallace';assert s.count(needle)==1;s=s.replace(needle,'    if (ElfMsg2_IsPepsiman(thisx, play)) {\n        ElfMsg2_UpdatePepsiman(this, play);\n        return;\n    }\n'+needle);p.write_text(s)
print('Pepsiman:',len(models['pepsiman']['triangles']),'triangles; six collision-free cans in rooms 7/9/16/17/19.')

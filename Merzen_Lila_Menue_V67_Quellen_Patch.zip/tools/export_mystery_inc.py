"""Import supplied N64 OBJ/PNGs unchanged; preserve authored relaxed poses.
python3 tools/export_mystery_inc.py WORK; user files under WORK/input/KEY.
Own rigid head/arms or head/tail, small rotations only; no foreign skeleton.
"""
from pathlib import Path
import json,sys,hashlib,math,shutil
from PIL import Image
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[1]);report={}
for key,height in [('shaggy',94),('velma',76),('daphne',86),('scooby',62),('fred',92),('mysterymachine',150*2.365934/3.709847)]:
 p=next((W/'input'/key).rglob('*.obj'));vs=[];uv=[];ns=[];fs=[];mat=None
 for line in p.read_text().splitlines():
  q=line.split()
  if not q:continue
  if q[0]=='v':vs.append(list(map(float,q[1:4])))
  elif q[0]=='vt':uv.append(list(map(float,q[1:3])))
  elif q[0]=='vn':ns.append(list(map(float,q[1:4])))
  elif q[0]=='usemtl':mat=q[1]
  elif q[0]=='f':
   c=[[int(n)-1 if n else None for n in x.split('/')]for x in q[1:]]
   for j in range(1,len(c)-1):fs.append((mat,[c[0],c[j],c[j+1]]))
 textures={};name=None
 for line in p.with_suffix('.mtl').read_text().splitlines():
  if line.startswith('newmtl '):name=line.split(maxsplit=1)[1]
  if line.startswith('map_Kd '):textures[name]=line.split(maxsplit=1)[1].replace('\\','/').split('/')[-1]
 # Center on the torso/head rather than the outside of the authored hand pose.
 headtex=['Face.png','Hair.png']if key!='velma'else['Head.png','Eyes.png','Glasses1.png','Glasses2.png']
 points=[vs[c[0]]for ma,corners in fs if textures[ma]in headtex for c in corners]
 if not points:points=vs
 lo=[min(v[k]for v in vs)for k in range(3)];hi=[max(v[k]for v in vs)for k in range(3)];scale=height*100/(hi[1]-lo[1]);cx=(min(v[0]for v in points)+max(v[0]for v in points))/2;cz=0
 def pos(v):return [round((v[k]-[cx,lo[1],cz][k])*scale)for k in range(3)]
 pivots=[[0,0,0],[cx,lo[1]+(hi[1]-lo[1])*.79,0],[cx-.21*(hi[1]-lo[1]),lo[1]+(hi[1]-lo[1])*.78,0],[cx+.21*(hi[1]-lo[1]),lo[1]+(hi[1]-lo[1])*.78,0]]
 if key=='scooby':pivots=[[0,lo[1],0],[0,.57,.12],[0,.39,-.35],[0,lo[1],0]]
 bones=[dict(name=n,parent=-1 if i==0 else 0,position=pos(v)if i else[0,0,0])for i,(n,v)in enumerate(zip(['body','head','left_arm'if key!='scooby'else'tail','right_arm'if key!='scooby'else'spare'],pivots))]
 D=R/'models'/key;D.mkdir(parents=True,exist_ok=True);mats=[];texnames=[]
 for ma,c in fs:
  tex=textures[ma]
  if tex in texnames:continue
  src=next(t for t in p.parent.rglob('*')if t.name.lower()==tex.lower());shutil.copyfile(src,D/tex)
  size=Image.open(src).size;size=[min(64,2**round(math.log2(x)))for x in size];texnames.append(tex);mats.append(dict(name=tex.replace('.png','').replace('+','_'),texture=tex,size=size))
 out=dict(bones=bones,materials=mats,vertices=[],triangles=[],uniform_scale=True,native_lighting=True,authored_pose_preserved=True,source_sha256=hashlib.sha256(p.read_bytes()).hexdigest());lookup={}
 for ma,corners in fs:
  tex=textures[ma];face=[]
  for corner in corners:
   vi,ti=corner[:2];ni=corner[2]if len(corner)>2 else None
   v=vs[vi];bone=0
   if key=='scooby':
    if tex in ['Face.png','Neck.png']:bone=1
    elif v[2]<-.36 and v[1]>.32:bone=2
   elif tex in headtex or(key=='shaggy'and tex.startswith(('Hair','Eyes','Mouth'))):bone=1
   elif tex in ['Arms.png','Hands.png']:bone=2 if v[0]<cx else 3
   pair=(vi,bone)
   if pair not in lookup:lookup[pair]=len(out['vertices']);out['vertices'].append(dict(bone=bone,position=pos(v)))
   a,b,c=[vs[x[0]]for x in corners];ab=[b[i]-a[i]for i in range(3)];ac=[c[i]-a[i]for i in range(3)];norm=ns[ni]if ni is not None else[ab[1]*ac[2]-ab[2]*ac[1],ab[2]*ac[0]-ab[0]*ac[2],ab[0]*ac[1]-ab[1]*ac[0]];length=max(1e-10,math.sqrt(sum(n*n for n in norm)));face.append(dict(vertex=lookup[pair],uv=uv[ti],normal=[round(n/length*127)for n in norm]))
  out['triangles'].append(dict(material=texnames.index(tex),corners=face))
 out['dimensions_game_units']=[round((hi[k]-lo[k])*scale/100,2)for k in range(3)]
 (R/'tools'/f'{key}_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n');report[key]=dict(triangles=len(fs),dimensions=out['dimensions_game_units'],textures=len(mats),authored_pose_preserved=True);print(key,report[key])
 # Keep safe source assets and provenance, no .blend/executables from uploads.
 S=D/'source';S.mkdir(exist_ok=True);shutil.copyfile(p,S/p.name);shutil.copyfile(p.with_suffix('.mtl'),S/p.with_suffix('.mtl').name)
 (S/'README.txt').write_text('User-supplied Scooby-Doo: Classic Creep Capers N64 model, OBJ/MTL and textures. Original triangle count and authored pose preserved. Export: tools/export_mystery_inc.py.\n')
(W/'models.json').write_text(json.dumps(report,indent=2)+'\n')

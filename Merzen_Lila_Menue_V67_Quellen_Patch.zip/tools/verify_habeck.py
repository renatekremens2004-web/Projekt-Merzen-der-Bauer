"""Verify Habeck/Rauru against the published time-transition release ROM.

Usage: python tools/verify_habeck.py OOT PREVIOUS_BEAN_ROM.z64
Run in the OOT Python environment, with MIPS binutils on PATH.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import re
import struct
import subprocess
from ipl3checksum import CICKind, calculateChecksum
from verify_story import segment, check_buffers

ROOT = Path(__file__).resolve().parent.parent
BASE_SHA = 'e078d63250213382fc811efc03c9a8ea118bb528c76e6abc05c948aa08bf8829'


def function_bodies(source):
    clean = re.sub(r'/\*.*?\*/|//[^\n]*|"(?:[^"\\]|\\.)*"',
                   lambda m: ' ' * len(m[0]), source, flags=re.S)
    out = {}
    for match in re.finditer(r'(?m)^[\w *]+\s+(\w+)\([^;{}]*\)\s*\{', clean):
        if match[1].isupper():
            continue
        depth, end = 1, match.end()
        while depth:
            depth += (clean[end] == '{') - (clean[end] == '}')
            end += 1
        out[match[1]] = clean[match.start():end]
    return out


def geometry():
    model = json.loads((ROOT/'tools/bean_bound.json').read_text())
    source = json.loads((ROOT/'tools/bean_source.json').read_text())
    assert len(model['triangles']) == len(source['triangles']) == 1258
    assert len(model['bones']) == 16 and len(model['palette']) == 15
    assert len(model['texture']) == 128*128 and len(model['texture_palette']) == 256*3
    pairs, maximum_error = set(), 0
    for triangle in model['triangles']:
        assert len(triangle) == 3 and all(0 <= i < len(model['vertices']) for i in triangle)
        for a,b in zip(triangle,triangle[1:]+triangle[:1]):
            pairs.add(tuple(sorted((a,b))))
    for vertex in model['vertices']:
        assert vertex['bone'] in model['palette']
        assert all(-32768 <= v < 32768 for v in vertex['position']+vertex['uv'])
        assert abs(math.sqrt(sum(n*n for n in vertex['normal']))-127) <= 1
    edges = 0
    for a,b in pairs:
        va,vb = model['vertices'][a],model['vertices'][b]
        if va['bone'] != vb['bone']:
            continue
        sa,sb = (source['vertices'][v['source_vertex']]['position'] for v in [va,vb])
        expected = math.dist(sa,sb)*model['scale']
        actual = math.dist(va['position'],vb['position'])
        error = abs(actual-expected)
        assert error < 1.74, (a,b,error)
        maximum_error=max(maximum_error,error)
        edges += 1
    assert edges > 1000
    return {'source_triangles':1258,'output_triangles':1258,'uniform_scale':model['scale'],
            'rigid_edges_checked':edges,'maximum_edge_quantization_error':maximum_error,
            'normalized_lighting_normals':True,'native_limb_count':16,'native_matrix_count':15}


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('oot',type=Path)
    ap.add_argument('baseline',type=Path)
    args=ap.parse_args()
    oot=args.oot.resolve();build=oot/'build/pal-1.0'
    old=args.baseline.read_bytes();packed=(build/'oot-pal-1.0-compressed.z64').read_bytes()
    plain=(build/'oot-pal-1.0.z64').read_bytes()
    assert hashlib.sha256(old).hexdigest()==BASE_SHA
    assert len(packed)==33554432 and packed[0x3e:0x40]==b'P\0'
    assert struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
    mp=(build/'oot-pal-1.0.map').read_text()
    symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):
        symbols.setdefault(name,int(address,16))
    def sym(name):
        return symbols[name]
    elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(build/'oot-pal-1.0.elf')],text=True)
    rels={};current=None
    for line in elf.splitlines():
        header=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
        if header:
            current=header[1];rels.setdefault(current,{})
        entry=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
        if current and entry:
            rels[current][int(entry[1],16)]=(entry[2],entry[3])
    intentional={'makerom','dmadata','code','ger_message_data_static','ovl_En_Rl','object_rl'}
    identical=[];relocated=[];changed=[];verified=0;object_bytes=None
    names=[r['Name'] for r in csv.DictReader((oot/'baseroms/pal-1.0/segments.csv').open())]
    for index,name in enumerate(names):
        _,_,before=segment(old,index)
        start,end,unpacked=segment(packed,index)
        if unpacked is None:
            continue
        expected=plain[start:end]
        if name=='makerom':
            assert unpacked[:16]==expected[:16] and unpacked[24:]==expected[24:]
        elif name!='dmadata':
            assert unpacked==expected,('compression',name)
            verified+=1
        lo,hi=[sym('_'+name+'SegmentRom'+suffix) for suffix in ['Start','End']]
        after=plain[lo:hi]
        if name=='object_im':
            object_bytes=len(after)
            assert len(after)<=86016,('object memory budget exceeded',len(after))
        if before==after:
            identical.append(name);continue
        if name in intentional:
            changed.append({'segment':name,'before_bytes':len(before),'after_bytes':len(after)});continue
        assert len(before)==len(after),('unexpected size change',name,len(before),len(after))
        origin=sym('_'+name+'SegmentStart')
        differences=sorted({i//4*4 for i,(x,y) in enumerate(zip(before,after)) if x!=y})
        for offset in differences:
            rel=rels.get(name,{}).get(origin+offset)
            assert rel,('unexplained changed word',name,hex(origin+offset))
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[offset:offset+2]==after[offset:offset+2],(name,rel)
            elif kind=='R_MIPS_26':
                assert before[offset]>>2==after[offset]>>2,(name,rel)
            else:
                assert kind=='R_MIPS_32',(name,rel)
        relocated.append({'segment':name,'relocated_words':len(differences)})
    assert verified==1509
    assert 'object_zo' in identical and 'object_im' in identical
    opening='src/overlays/gamestates/ovl_opening/z_opening.c'
    assert (oot/opening).read_bytes()==subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+opening])
    rel='src/overlays/actors/ovl_Demo_Im/z_demo_im.c'
    vanilla=function_bodies(subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+rel],text=True))
    actual=function_bodies((oot/rel).read_text())
    assert vanilla.keys()==actual.keys()
    function_changes={k for k in vanilla if vanilla[k]!=actual[k]}
    assert function_changes=={'func_80985EF4','DemoIm_DrawSolid','DemoIm_DrawTranslucent'},function_changes
    allowed={rel,'src/code/z_sram.c','src/overlays/actors/ovl_En_Ganon_Mant/z_en_ganon_mant.c',
             'src/overlays/actors/ovl_En_Viewer/z_en_viewer.c','src/code/z_elf_message.c','src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.c','src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.h','src/code/z_message.c','src/overlays/actors/ovl_En_Dns/z_en_dns.c','src/overlays/actors/ovl_Boss_Va/z_boss_va.c','src/overlays/actors/ovl_En_Ru1/z_en_ru1.c','src/overlays/actors/ovl_En_Elf/z_en_elf.c','src/overlays/actors/ovl_En_Rl/z_en_rl.c'}
    source_changes=set(subprocess.check_output(['git','-C',str(oot),'diff','--name-only','HEAD','--','src','include'],text=True).splitlines())
    assert source_changes<=allowed,source_changes
    edits={}
    for chapter in sorted((ROOT/'story').glob('*.json')):
        for ident,entry in json.loads(chapter.read_text())['messages'].items():
            assert ident not in edits;edits[ident]=entry
    assert len(edits)==596
    for path, backup, expected in [
        ('src/code/z_elf_message.c', ROOT/'tools/originals/story/src/code/z_elf_message.c', {'QuestHint_GetNaviTextId'}),
        ('src/overlays/actors/ovl_En_Viewer/z_en_viewer.c', ROOT/'tools/originals/bean/src/overlays/actors/ovl_En_Viewer/z_en_viewer.c', {'EnViewer_ImpaOverrideLimbDraw'})]:
        before_functions=function_bodies(backup.read_text());after_functions=function_bodies((oot/path).read_text())
        assert before_functions.keys()==after_functions.keys()
        assert {k for k in before_functions if before_functions[k]!=after_functions[k]}==expected
    rel='src/overlays/actors/ovl_En_Diving_Game/z_en_diving_game.c'
    original=(ROOT/'tools/originals/squid'/rel).read_text()
    actual=(oot/rel).read_text()
    normalized=actual.replace('&gSquidSkel','&gZoraSkel').replace('&gSquidIdleAnim','&gZoraIdleAnim').replace('&gSquidThrowAnim','&gZoraThrowRupeesAnim').replace('this->morphTable, 28)','this->morphTable, 20)')
    normalized=normalized.replace('(gSaveContext.language == LANGUAGE_GER ? 0x0138 : 0x85)','0x85').replace('(gSaveContext.language == LANGUAGE_GER ? 0x013B : 0x2D)','0x2D').replace('(gSaveContext.language == LANGUAGE_GER) ? 0x0136 : 0x71AD','0x71AD')
    original_functions=function_bodies(original);actual_functions=function_bodies(normalized)
    assert original_functions.keys()==actual_functions.keys()
    assert {k for k in original_functions if original_functions[k]!=actual_functions[k]}=={'EnDivingGame_Init','EnDivingGame_OverrideLimbDraw'}
    rp='src/overlays/actors/ovl_En_Ex_Ruppy/z_en_ex_ruppy.c'
    assert (oot/rp).read_bytes()==subprocess.check_output(['git','-C',str(oot),'show','HEAD:'+rp])
    path = 'src/overlays/actors/ovl_En_Elf/z_en_elf.c'
    before_functions = function_bodies((ROOT/'tools/originals/transition'/path).read_text())
    after_functions = function_bodies((oot/path).read_text())
    assert before_functions.keys() == after_functions.keys()
    assert {k for k in before_functions if before_functions[k] != after_functions[k]} == {'func_80A053F0'}
    # Rauru's cue/medallion/fade routines are byte-identical source after undoing only asset names.
    rel='src/overlays/actors/ovl_En_Rl/z_en_rl.c'
    normalized=(oot/rel).read_text()
    for new,old in [('gHabeckSkel','object_rl_Skel_007B38'),('gHabeckIdleAnim','object_rl_Anim_000A3C'),('gHabeckRaiseAnim','object_rl_Anim_00040C'),('gHabeckHoldAnim','object_rl_Anim_000830')]:normalized=normalized.replace(new,old)
    assert normalized==(ROOT/'tools/originals/habeck'/rel).read_text()
    rel='src/overlays/actors/ovl_En_Hy/z_en_hy.c'
    assert (oot/rel).read_text()==(ROOT/'tools/originals/habeck'/rel).read_text()
    model=json.loads((ROOT/'tools/habeck_source.json').read_text());assert len(model['bones'])==24 and len(model['triangles'])==2341
    assert {k:len(v) for k,v in model['animations'].items()}=={'idle':27,'raise':30,'hold':30}
    for frames in model['animations'].values():
        for frame in frames:assert len(frame['rotation'])==24 and len(frame['root'])==3
    for triangle in model['triangles']:
        for c in triangle['corners']:assert abs(math.sqrt(sum(x*x for x in c['normal']))-127)<1.1
    assert sym('_object_rlSegmentRomEnd')-sym('_object_rlSegmentRomStart')<300000
    seams=json.loads((ROOT/'tools/bean_riding_seams.json').read_text())['vertices']
    assert len(seams)==117
    for vertex in seams.values():
        assert all(-32768<=x<32768 for x in vertex['position'])
        assert abs(math.sqrt(sum(n*n for n in vertex['normal']))-127)<1
    report={'version':'German PAL 1.0; Habeck as Rauru and child Kakariko witness; 596 messages',
            'rom_sha256':hashlib.sha256(packed).hexdigest(),'rom_bytes':len(packed),
            'baseline_sha256':BASE_SHA,'compressed_segments_verified':verified,
            'identical_segments':identical,'relocated_segments':relocated,'intentional_changes':changed,
            'native_minigame_rules_preserved':True,'normal_start_preserved':True,
            'impa_modified_functions':sorted(function_changes),'object_bytes':object_bytes,
            'object_memory_budget_bytes':86016,'original_object_bytes':74288,'riding_seam_vertices':117,'geometry':geometry(),'text_buffers':check_buffers(build,edits)}
    output=build/'habeck-verification.json'
    output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['identical_segments','relocated_segments','text_buffers']},indent=2))


if __name__=='__main__':
    main()

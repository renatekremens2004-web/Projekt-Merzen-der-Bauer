"""Model-only comparison against the previously delivered Jabba ROM.

Requires the local previous build/map saved before this face revision. Neither
ROM is part of the public source archive.
"""
from pathlib import Path
import hashlib, json, re, struct, subprocess, sys
from verify_story import segment

O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve()
B=O/'build/pal-1.0';P=W/'previous/build/pal-1.0'
old=(P/'oot-pal-1.0-compressed.z64').read_bytes();new=(B/'oot-pal-1.0-compressed.z64').read_bytes()
assert hashlib.sha256(old).hexdigest()=='d090fc67ed85e5416181ead5250af5996b86b58e3d05c7f7adf2cde4b6a6fdf6'
names=re.findall(r'DEFINE_DMA_ENTRY\((\w+),',(B/'dmadata_table_spec.h').read_text())
def symbols(p):
 return {n:(int(a,16),int(s,16)) for a,s,n in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) [tTdDrR] (\S+)$',subprocess.check_output(['mips-linux-gnu-nm','-S',str(p)],text=True),re.M)}
oldsy=symbols(P/'oot-pal-1.0.elf');newsy=symbols(B/'oot-pal-1.0.elf')
maps=[(p/'oot-pal-1.0.map').read_text() for p in [P,B]]
starts=[{n:int(a,16) for a,n in re.findall(r'0x([0-9a-f]+)\s+(_\w+SegmentStart)\b',s)} for s in maps]
changes=[];model_size=None
for i,name in enumerate(names):
 a=segment(old,i)[2];b=segment(new,i)[2]
 if a==b:continue
 assert name in {'makerom','dmadata','code','ovl_Elf_Msg2','object_jabba'},name
 changes.append(dict(segment=name,before_bytes=len(a),after_bytes=len(b)))
 if name=='makerom':assert a[:16]==b[:16] and a[24:]==b[24:]
 elif name=='code':
  # Only the end of the new object's extent changes in the native core.
  assert oldsy['gObjectTable']==newsy['gObjectTable']
  address,size=newsy['gObjectTable'];off=address-starts[1]['_codeSegmentStart']+size-4
  assert a[:off]==b[:off] and a[off+4:]==b[off+4:]
 elif name=='ovl_Elf_Msg2':
  # Normalizing the denser remesh adjusts the head-pivot constants. The same
  # display-list reference is relocated inside the smaller Jabba object.
  assert len(a)==len(b)
  before_model=json.loads((W/'previous/tools/jabba_source.json').read_text())
  after_model=json.loads((Path(__file__).resolve().parent/'jabba_source.json').read_text())
  before_pivot=struct.pack('>6f',0,0,0,*before_model['bones'][1]['position'])
  after_pivot=struct.pack('>6f',0,0,0,*after_model['bones'][1]['position'])
  assert a.count(before_pivot)==b.count(after_pivot)==1
  assert a.index(before_pivot)==b.index(after_pivot)
  off=a.index(before_pivot);a=a[:off]+after_pivot+a[off+24:]
  diffs=sorted({j//4*4 for j,(x,y)in enumerate(zip(a,b))if x!=y})
  assert len(diffs)==1
  off=diffs[0];x,y=struct.unpack_from('>I',a,off)[0],struct.unpack_from('>I',b,off)[0]
  assert x>>16==y>>16 and x&0xffff==oldsy['gJabbaDL'][0]&0xffff and y&0xffff==newsy['gJabbaDL'][0]&0xffff
 elif name=='object_jabba':
  assert len(b)<len(a);model_size=(len(a),len(b))
assert len(changes)==5 and model_size
m=json.loads((Path(__file__).resolve().parent/'jabba_source.json').read_text())
counts={mat['name']:sum(t['material']==i for t in m['triangles']) for i,mat in enumerate(m['materials'])}
assert counts==dict(body=859,head=130,face=1111,eyes=191)
assert len(m['triangles'])==2291<2391 and all(x['size']==[64,64] for x in m['materials'])
report=dict(previous_sha256=hashlib.sha256(old).hexdigest(),rom_sha256=hashlib.sha256(new).hexdigest(),changed_segments=changes,triangles_by_material=counts,model_bytes_before=model_size[0],model_bytes_after=model_size[1],all_previous_messages_and_other_models_byte_identical=True,native_core_only_object_extent_changed=True,actor_only_head_pivot_and_display_list_relocation_changed=True)
(W/'face-verification.json').write_text(json.dumps(report,indent=2)+'\n')
print('Face revision verified: five segments; only Jabba geometry/textures/pivot, object extent, DMA and CRC changed.')

"""Binary, relocation, scene and dialogue isolation checks for the Fire/Wallace chapter."""
from pathlib import Path
import sys,csv,re,json,hashlib,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as story
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();W=Path(sys.argv[2]).resolve();B=O/'build/pal-1.0';a=(W/'baseline.z64').read_bytes();b=(B/'oot-pal-1.0-compressed.z64').read_bytes();plain=(B/'oot-pal-1.0.z64').read_bytes();assert hashlib.sha256(a).hexdigest()=='54945b5aaec82f7f7094a0653c11a730455d2b04bcf3462960e3f5b48acebaf2'
assert len(b)==33554432 and struct.unpack_from('>II',b,16)==calculateChecksum(b,CICKind.CIC_X105)
def symbols(p):
 d={}
 for x,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',p.read_text()):d.setdefault(n,int(x,16))
 return d
old=symbols(W/'baseline.map');new=symbols(B/'oot-pal-1.0.map');names=[x['Name']for x in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];relocs={};section=None
for line in subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(B/'oot-pal-1.0.elf')],text=True).splitlines():
 m=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
 if m:section=m[1];relocs.setdefault(section,{})
 m=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
 if m and section:relocs[section][int(m[1],16)]=(m[2],m[3])
def relocated(x,y,base,name):
 assert len(x)==len(y),(name,'length',len(x),len(y));changes=sorted({j//4*4 for j,(q,r)in enumerate(zip(x,y))if q!=r})
 for j in changes:
  rel=relocs.get(name,{}).get(base+j);assert rel,(name,hex(base+j),'unexplained change');kind,target=rel
  if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:assert x[j:j+2]==y[j:j+2]
  elif kind=='R_MIPS_26':assert x[j]>>2==y[j]>>2
  else:assert kind=='R_MIPS_32',kind
 return len(changes)
intentional={'makerom','dmadata','ger_message_data_static','code','ovl_En_Go2','ovl_Demo_Du','ovl_Demo_Sa','HIDAN_room_5','object_du','object_sa','item_name_static','kenjyanoma_scene'};segments={};changed=[];identical=[];relocated_segments=[];verified=0
for i,name in enumerate(names):
 start,end,y=segment(b,i);_,_,x=segment(a,i)
 if y is None:continue
 segments[name]=(x,y)
 if name!='dmadata':
  if name=='makerom':assert y[:16]==plain[start:start+16] and y[24:]==plain[start+24:end]
  else:assert y==plain[start:end],name;verified+=1
 if x==y:identical.append(name)
 elif name in intentional:changed.append(dict(segment=name,before_bytes=len(x),after_bytes=len(y)))
 else:relocated_segments.append(dict(segment=name,changed_words=relocated(x,y,new['_'+name+'SegmentStart'],name)))
assert verified==1509
# The only DemoSa change is the shared credits camera fit. Verify whole overlay,
# preserving every cue, frame, function and FOV; remaining words must be relocations.
camfile=R/'tools/bowling_sage_cutscene_data.inc.c'
camtext=camfile.read_text()
assert camtext.count('-150, 3303, -4149')==8 and camtext.count('0, 3277, -4025')==8
previous=camtext.replace('-150, 3303, -4149','-115, 3290, -4120').replace('0, 3277, -4025','0, 3270, -4025')
def camera_points(text):
 pat=r'CS_CAM_POINT\((CS_CAM_CONTINUE|CS_CAM_STOP), (0x[0-9A-Fa-f]+), (\d+), CS_FLOAT\((0x[0-9A-Fa-f]+), [^)]*\), (-?\d+), (-?\d+), (-?\d+), (0x[0-9A-Fa-f]+)\)'
 return [struct.pack('>BBHIhhhH',0 if a=='CS_CAM_CONTINUE' else 255,int(b,16),int(c),int(d,16),int(e),int(f),int(g),int(h,16))for a,b,c,d,e,f,g,h in re.findall(pat,text)]
x,y=segments['ovl_Demo_Sa'];fitted=x;camera_edits=0;replacements=set()
for before_point,after_point in zip(camera_points(previous),camera_points(camtext)):
 if before_point==after_point:continue
 camera_edits+=1
 if (before_point,after_point) in replacements:continue
 assert before_point in fitted and after_point in y,(before_point.hex(),after_point.hex())
 fitted=fitted.replace(before_point,after_point);replacements.add((before_point,after_point))
assert camera_edits==16
relocated(fitted,y,new['_ovl_Demo_SaSegmentStart'],'ovl_Demo_Sa')
nm=subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/'oot-pal-1.0.elf')],text=True);functions=re.findall(r'^([0-9a-f]+) ([0-9a-f]+) ([Tt]) (\S+)$',nm,re.M);retained={};native_functions={}
func_addrs={int(q[1],16) for line in subprocess.check_output(['mips-linux-gnu-readelf','-sW',str(B/'oot-pal-1.0.elf')],text=True).splitlines() if len(q:=line.split())>=8 and q[3]=='FUNC'}
excluded={'sTunicColors','EnGo2_GoronFireGenericGetTextId','EnGo2_GetTextIdGoronFireGeneric','EnGo2_UpdateTalkStateGoronFireGeneric','EnGo2_Update','EnGo2_Draw','DemoDu_Draw_01','DemoDu_Draw_02','DemoDu_CsFireMedallion_AdvanceTo01'}
for seg in ['code','ovl_En_Go2','ovl_Demo_Du']:
 x,y=segments[seg];n=0;nf=0
 for addr,size,kind,name in functions:
  address=int(addr,16);length=int(size,16)
  if name in excluded or name not in old or not new['_'+seg+'SegmentStart']<=address<new['_'+seg+'SegmentEnd'] or not old['_'+seg+'SegmentStart']<=old[name]<old['_'+seg+'SegmentEnd']:continue
  relocated(x[old[name]-old['_'+seg+'SegmentStart']:old[name]-old['_'+seg+'SegmentStart']+length],y[address-new['_'+seg+'SegmentStart']:address-new['_'+seg+'SegmentStart']+length],address,seg);n+=1;nf+=address in func_addrs
 retained[seg]=n;native_functions[seg]=nf
assert retained['code']>3000 and retained['ovl_En_Go2']>80 and retained['ovl_Demo_Du']>70,retained
# Every native Darunia asset and Fire-room asset is retained, independent of appended model data.
assets={}
for seg,obj in [('object_du','assets/objects/object_du/object_du.o'),('HIDAN_room_5','assets/scenes/dungeons/HIDAN/HIDAN_room_5.o')]:
 x,y=segments[seg];symbols_nm=subprocess.check_output(['mips-linux-gnu-nm','-S',str(B/obj)],text=True);n=0
 for addr,size,kind,name in re.findall(r'^([0-9a-f]+) ([0-9a-f]+) (\w) (\S+)$',symbols_nm,re.M):
  if name not in old or name not in new:continue
  i=old[name]-old['_'+seg+'SegmentStart'];j=new[name]-new['_'+seg+'SegmentStart'];length=int(size,16)
  if 0<=i<len(x) and 0<=j<len(y):relocated(x[i:i+length],y[j:j+length],new[name],seg);n+=1
 assets[seg]=n
# Tunic table alone changes its Goron RGB; equipment code and hazard checks verified above.
x,y=segments['code'];i=old['sTunicColors']-old['_codeSegmentStart'];j=new['sTunicColors']-new['_codeSegmentStart'];assert x[i:i+3]==y[j:j+3] and y[j+3:j+6]==bytes([200,75,0]) and x[i+6:i+9]==y[j+6:j+9]
# German item-name slot only, identical total segment length.
x,y=segments['item_name_static'];assert len(x)==len(y);label='gMegatonHammerItemNameGERTex';idx=new[label]-new['_item_name_staticSegmentStart'];namepng=O/'extracted/pal-1.0/assets/textures/item_name_static'/ (label+'.ia4.png');from PIL import Image
w,h=Image.open(namepng).size;length=w*h//2;assert x[:idx]==y[:idx] and x[idx+length:]==y[idx+length:]
# Retail message tables and native control macros.
def messages(rom,syms):
 _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'));base=syms['_codeSegmentStart'];p=syms['sNesMessageEntryTable']-base;ids=[]
 while True:
  ident=struct.unpack_from('>H',code,p)[0];p+=8
  if ident==65535:break
  if ident!=65532:ids.append(ident)
 table=syms['sGerMessageEntryTable']-base;off=[struct.unpack_from('>I',code,table+4*j)[0]&0xffffff for j in range(len(ids))]+[len(data)]
 return {f'{ident:04X}':data[off[j]:off[j+1]].rstrip(b'\0')for j,ident in enumerate(ids)}
ma=messages(a,old);mb=messages(b,new);diff=[i for i in ma if ma[i]!=mb[i]];chapter=json.loads((R/'story/feuertempel_wallace_de.json').read_text())['messages'];assert set(diff)==set(chapter),diff
before=story.messages((W/'baseline_message_data.h').read_text());after=story.messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
for ident,v in after.items():
 for lang in [0,1,3]:assert v['parts'][lang][2]==before[ident]['parts'][lang][2],(ident,lang)
 assert v['header']==before[ident]['header'],ident
 assert story.controls(v['parts'][2][2])==story.controls(before['0022' if ident in ['209D','209E'] else ident]['parts'][2][2]),ident
# Bowling mesh, own bone lengths and all non-seated animations are retained.
prior=json.loads((W/'baseline_bowling_sage_source.json').read_text());now=json.loads((R/'tools/bowling_sage_source.json').read_text())
for label in ['sit_idle','sit_up','sit_down']:
 assert len(now['animations'][label])==len(prior['animations'][label])
 for frame in now['animations'][label]:
  assert frame['root']==[-100,9400,300] and len(frame['rotation'])==len(now['bones'])
  assert all(len(rot)==3 for rot in frame['rotation'])
 now['animations'][label]=prior['animations'][label]
now['credits']=prior['credits'];assert now==prior
# Earlier feature probes used seat-v1. Confirm their implementation/assets and
# all chapter texts other than the four subsequently requested hall speeches.
probe_rom=(W/'seat-v1.z64').read_bytes()
assert hashlib.sha256(probe_rom).hexdigest()=='d5632e191dbb1dd5c8bd8b037d9fb6cea769e22ca0d6f39efca15c25f6c4ea45'
probe_delta={}
for name in ['ovl_En_Go2','ovl_Demo_Du','ovl_En_Xc','HIDAN_room_5','object_du','item_name_static']:
 _,_,q=segment(probe_rom,names.index(name));_,_,r=segment(b,names.index(name))
 probe_delta[name]=relocated(q,r,new['_'+name+'SegmentStart'],name)
probe_messages=messages(probe_rom,new)
for ident in chapter:
 if ident not in ['303C','3045','3046','303D']:assert probe_messages[ident]==mb[ident],ident
edits={i:e for p in (R/'story').glob('*.json')for i,e in json.loads(p.read_text())['messages'].items()};buffers=check_buffers(B,edits);assert len(edits)==977
report=dict(rom_sha256=hashlib.sha256(b).hexdigest(),baseline_sha256=hashlib.sha256(a).hexdigest(),rom_bytes=len(b),compressed_segments_verified=verified,changed_german_messages=diff,story_count=len(edits),text_buffers=buffers,intentional_segments=changed,identical_segments=identical,relocated_segments=relocated_segments,retained_native_symbols=retained,retained_native_functions=native_functions,retained_native_assets=assets,tunic_rgb=[200,75,0],german_pause_item_label='Wallace Hammer',native_cells_paths_keys_rewards_and_timing_retained=True,bowling_mesh_and_bone_lengths_retained=True,only_credits_sitting_poses_refitted=True,credits_group_camera_points_refitted=camera_edits,credits_camera_timing_and_all_other_overlay_words_retained=True,earlier_runtime_feature_implementations_retained=probe_delta,earlier_runtime_probe_sha256=hashlib.sha256(probe_rom).hexdigest())
(B/'fire-wallace-verification.json').write_text(json.dumps(report,indent=2)+'\n');print('Verified',verified,'segments;',retained,'native symbols;',native_functions,'functions;',len(edits),'dialogue buffers;',len(diff),'changed German texts.')

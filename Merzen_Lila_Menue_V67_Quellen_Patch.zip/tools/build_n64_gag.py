"""Draw the supplied small console on a native, repeatable Navi check spot."""
from pathlib import Path
import sys,json,math,re
from PIL import Image
ROOT=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();B=ROOT/'originals/n64';A=O/'src/overlays/actors/ovl_Elf_Msg2';D=O/'extracted/pal-1.0/assets/scenes/dungeons/bdan'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
m=json.loads((ROOT/'n64_source.json').read_text());assert len(m['triangles'])==1376;lines=['/* User-supplied Nintendo 64. Casing width: 10.0 game units. */']
def u64(name,data):
 data+=bytes((-len(data))%8);lines.append('static u64 '+name+'[]={');lines.extend('0x'+data[i:i+8].hex().upper()+',' for i in range(0,len(data),8));lines.append('};')
def rgba16(c):
 r,g,b=c[:3];return ((r>>3)<<11)|((g>>3)<<6)|((b>>3)<<1)|1
for i,mat in enumerate(m['materials']):
 im=Image.open(ROOT.parent/'models/n64/textures'/mat['texture']).convert('RGB').resize((64,64),Image.Resampling.LANCZOS).quantize(colors=16,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE);pal=im.getpalette();pal+=([0]*(48-len(pal)));data=list(im.getdata());u64('gNintendo64Palette%d'%i,b''.join(rgba16(pal[j:j+3]).to_bytes(2,'big') for j in range(0,48,3)));u64('gNintendo64Tex%d'%i,bytes((data[j]<<4)|data[j+1] for j in range(0,len(data),2)));im.save(ROOT.parent/'models/n64/textures'/('n64_'+mat['name']+'.png'))
vertices=[];commands=[]
for mat in range(len(m['materials'])):
 commands+=['gsDPPipeSync(),','gsDPSetTextureLUT(G_TT_RGBA16),','gsDPLoadTLUT_pal16(0,gNintendo64Palette%d),'%mat,'gsDPLoadTextureBlock_4b(gNintendo64Tex%d,G_IM_FMT_CI,64,64,0,G_TX_WRAP,G_TX_WRAP,6,6,G_TX_NOLOD,G_TX_NOLOD),'%mat]
 tris=[t for t in m['triangles'] if t['material']==mat]
 for start in range(0,len(tris),10):
  batch=tris[start:start+10];off=len(vertices)
  for t in batch:
   # Whole-tile offsets retain wrapping while keeping source UVs inside s16.
   u0=math.floor(min(c['uv'][0] for c in t['corners']));v0=math.floor(min(1-c['uv'][1] for c in t['corners']))
   for c in t['corners']:
    p=m['vertices'][c['vertex']];uv=[round((c['uv'][0]-u0)*2048),round((1-c['uv'][1]-v0)*2048)];assert all(-32768<=x<=32767 for x in p+uv);vertices.append(p+uv+[x&255 for x in c['normal']])
  commands+=['gsSPVertex(&gNintendo64Vertices[%d],%d,0),'%(off,len(batch)*3)]
  for j in range(len(batch)):commands+=['gsSP1Triangle(%d,%d,%d,0),'%(j*3,j*3+1,j*3+2)]
lines+=['static Vtx gNintendo64Vertices[]={'];lines+=['{{{%d,%d,%d},0,{%d,%d},{%d,%d,%d,255}}},'%tuple(v) for v in vertices];lines+=['};','Gfx gNintendo64DL[]={','gsDPPipeSync(),','gsDPSetCycleType(G_CYC_2CYCLE),','gsSPTexture(0xffff,0xffff,0,0,G_ON),','gsDPSetRenderMode(G_RM_FOG_SHADE_A,G_RM_AA_ZB_OPA_SURF2),','gsSPClearGeometryMode(G_CULL_BACK|G_CULL_FRONT|G_TEXTURE_GEN|G_TEXTURE_GEN_LINEAR),','gsSPSetGeometryMode(G_LIGHTING|G_SHADE|G_SHADING_SMOOTH|G_ZBUFFER|G_FOG),','gsDPSetCombineLERP(TEXEL0,0,SHADE,0,0,0,0,TEXEL0,0,0,0,COMBINED,0,0,0,COMBINED),','gsDPSetTextureFilter(G_TF_BILERP),']+commands+['gsSPEndDisplayList(),','};']
(D/'nintendo64_model.inc.c').write_text('\n'.join(lines)+'\n')
p=A/'z_elf_msg2.c';s=original(p);s=s.replace('#include "play_state.h"','#include "play_state.h"\n#include "save.h"\n#include "segmented_address.h"\n\n/* Segmented room-3 display list; no console assets in this overlay. */\nextern Gfx gNintendo64DL[];\n\nstatic void ElfMsg2_DrawNintendo64(Actor* thisx, PlayState* play);')
marker='        this->actor.shape.rot.x = this->actor.shape.rot.y = this->actor.shape.rot.z = 0;';assert s.count(marker)==1
s=s.replace(marker,marker+'''
        /* One German decoration; all other check spots retain their native setup. */
        if (play->sceneId == SCENE_JABU_JABU && thisx->room == 3 && thisx->params == 0x3F25) {
            if (gSaveContext.language != LANGUAGE_GER) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, 3.0f);
            thisx->draw = ElfMsg2_DrawNintendo64;
        }''')
s+='''
/* Rendering only: targeting, C-Up, closing and repeat behavior are all native Elf_Msg2. */
static void ElfMsg2_DrawNintendo64(Actor* thisx, PlayState* play) {
    void* roomSegment = NULL;
    if (play->roomCtx.curRoom.num == thisx->room) {
        roomSegment = play->roomCtx.curRoom.segment;
    } else if (play->roomCtx.prevRoom.num == thisx->room) {
        roomSegment = play->roomCtx.prevRoom.segment;
    }
    if (roomSegment == NULL) {
        return;
    }
    OPEN_DISPS(play->state.gfxCtx, "nintendo64", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++, play->state.gfxCtx, "nintendo64", 2);
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPDisplayList(POLY_OPA_DISP++, gNintendo64DL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    CLOSE_DISPS(play->state.gfxCtx, "nintendo64", 3);
}
''';p.write_text(s)
p=D/'bdan_room_3_0300006C_ActorEntryList.inc.c';s=original(p);assert s.count('ACTOR_')==8
p.write_text(s+'''    {
        ACTOR_ELF_MSG2,
        {    130,  -1113,  -3180 },
        { 0x0002, 0x0000, 0x0001 }, /* repeatable native check, no switch flag */
        0x3F25, /* message 0125; native switch sentinel 3F */
    },
''')
p=D/'bdan_room_3.h';s=original(p);old='#define LENGTH_bdan_room_3_0300006C_ActorEntryList 8';assert s.count(old)==1;p.write_text(s.replace(old,old[:-1]+'9'))
p=D/'bdan_room_3.c';p.write_text(original(p)+'\n#include \"nintendo64_model.inc.c\"\n')
old=A/'nintendo64_model.inc.c'
if old.exists():
 assert 'User-supplied Nintendo 64' in old.read_text()[:150];old.unlink()
print('N64: 1376 supplied-mesh triangles; 10.0-unit case width; native Z-target/C-Up/retalk; one Room 3 entry.')

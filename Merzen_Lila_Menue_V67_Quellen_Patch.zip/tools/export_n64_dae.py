"""Blender: read the supplied Collada geometry, retain UVs and simplify for N64."""
from pathlib import Path
import bpy,sys,json,math,hashlib,xml.etree.ElementTree as ET
from mathutils import Matrix,Vector
R=Path(__file__).resolve().parent.parent
src=Path(sys.argv[sys.argv.index('--')+1]);root=ET.parse(src).getroot();ns={'c':root.tag.split('}')[0][1:]}
bpy.ops.wm.read_factory_settings(use_empty=True)
geos={g.attrib['id']:g for g in root.findall('c:library_geometries/c:geometry',ns)};stats={};total=0
for node in root.findall('c:library_visual_scenes/c:visual_scene/c:node',ns):
 inst=node.find('c:instance_geometry',ns)
 if inst is None:continue
 name=node.attrib['name'];ma=list(map(float,node.find('c:matrix',ns).text.split()));assert ma==[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1]
 mesh=geos[inst.attrib['url'][1:]].find('c:mesh',ns);arrays={}
 for s in mesh.findall('c:source',ns):
  v=list(map(float,s.find('c:float_array',ns).text.split()));stride=int(s.find('c:technique_common/c:accessor',ns).attrib['stride']);arrays[s.attrib['id']]=[v[i:i+stride] for i in range(0,len(v),stride)]
 posid=mesh.find('c:vertices/c:input',ns).attrib['source'][1:];positions=arrays[posid];faces=[];uvs=[];normals=[]
 for p in list(mesh):
  if p.tag.split('}')[-1] not in ['polylist','triangles']:continue
  inputs=p.findall('c:input',ns);stride=max(int(i.attrib['offset']) for i in inputs)+1;values=list(map(int,p.find('c:p',ns).text.split()));values=[values[i:i+stride] for i in range(0,len(values),stride)];counts=list(map(int,p.find('c:vcount',ns).text.split())) if p.tag.endswith('polylist') else [3]*int(p.attrib['count']);start=0
  links={i.attrib['semantic']:(int(i.attrib['offset']),i.attrib['source'][1:]) for i in inputs};normal_off,normal_id=links['NORMAL'];uv_off,uv_id=links['TEXCOORD'];v_off,_=links['VERTEX']
  for count in counts:
   cs=values[start:start+count];start+=count
   for k in range(1,count-1):
    tri=[cs[0],cs[k],cs[k+1]];faces.append(tuple(c[v_off] for c in tri));uvs.extend(arrays[uv_id][c[uv_off]][:2] for c in tri);normals.extend(arrays[normal_id][c[normal_off]][:3] for c in tri)
 material=inst.find('.//c:instance_material',ns).attrib['target'][1:]
 data=bpy.data.meshes.new(name);data.from_pydata([v[:3] for v in positions],[],faces);data.update();uv=data.uv_layers.new(name='SourceUV')
 for i,value in enumerate(uvs):uv.data[i].uv=value
 for p in data.polygons:p.use_smooth=True
 data.normals_split_custom_set(normals)
 obj=bpy.data.objects.new(name,data);bpy.context.collection.objects.link(obj);mat=bpy.data.materials.get(material)
 if mat is None:mat=bpy.data.materials.new(material)
 data.materials.append(mat)
 before=len(faces);total+=before
 budget={'mainbase_low':260,'good_cart':180,'main_con_low':200,'feet_low':52,'control_cord1':140,'power_cord1':36,'power_bank_low':48,'on_off_low':68,'joystick_low':40,'joystick_holder_low':28,'yellow_buttons_low':28,'LR_low':24,'pluin_low':40}.get(name,20)
 bpy.context.view_layer.objects.active=obj;obj.select_set(True);mod=obj.modifiers.new('N64 budget','DECIMATE');mod.ratio=min(1,budget/before);mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name);obj.data.calc_loop_triangles();stats[obj.name]={'before':before,'after':len(obj.data.loop_triangles),'material':material};obj.select_set(False)
# Console casing itself is 1000 model units = 10 game units at uniform 0.01 scale.
objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];body=next(o for o in objects if o.name=='mainbase_low');bodyp=[v.co for v in body.data.vertices];width=max(v.x for v in bodyp)-min(v.x for v in bodyp);center=Vector(((min(v.x for v in bodyp)+max(v.x for v in bodyp))/2,0,(min(v.z for v in bodyp)+max(v.z for v in bodyp))/2));ground=min(v.co.y for o in objects for v in o.data.vertices);center.y=ground;scale=1000/width
out={'model':'Supplied Nintendo 64 with Ocarina of Time cartridge and controller','source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_triangles':total,'console_width_model_units':1000,'actor_uniform_scale':0.01,'source_uniform_scale':scale,'source_center':list(center),'parts':stats,'materials':[],'vertices':[],'triangles':[]}
materials={}
for obj in objects:
 mat=obj.data.materials[0].name
 if mat not in materials:materials[mat]=len(materials);out['materials'].append({'name':mat,'texture':mat+'_albedo.jpeg'})
 mesh=obj.data;mesh.calc_loop_triangles();base=len(out['vertices'])
 for v in mesh.vertices:out['vertices'].append([round(x) for x in (v.co-center)*scale])
 for t in mesh.loop_triangles:
  cs=[]
  for li in t.loops:
   vi=mesh.loops[li].vertex_index;n=mesh.corner_normals[li].vector.normalized();cs.append({'vertex':base+vi,'normal':[round(x*127) for x in n],'uv':list(mesh.uv_layers.active.data[li].uv)})
  out['triangles'].append({'material':materials[mat],'corners':cs})
(R/'tools/n64_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n');print('N64',total,'->',len(out['triangles']),'triangles, console width 10.0 game units;',len(materials),'materials')
# Kept locally as an inspection aid, not required to build the patch.
bpy.ops.wm.save_as_mainfile(filepath='/workspace/n64-gag/reduced.blend')

"""Append three optional room-local gags after build_superhelden.py; leave both boss actors untouched."""
from pathlib import Path
import json,re,sys
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/fundstuecke'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
placements=[('triangle','TriangleGuy','ganon_demo',0,[-800,1086,-550],0x4000,'0x3F78'),('pregtest','Pregtest','HAKAdanCH',6,[-415,1,-1010],0,'0x3F79'),('flatsquid','FlatSquid','MIZUsin_bs',1,[545,1,545],0,'0x3F7A')]
for key,prefix,scene,room,pos,yaw,param in placements:
 d=O/'extracted/pal-1.0/assets/scenes/dungeons'/scene;m=json.loads((R/f'tools/{key}_source.json').read_text());inc=key+'_model.inc.c';(d/inc).write_text(emit(m,R/'models'/key,prefix).replace('g'+prefix+'BodyDL','g'+prefix+'DL'))
 p=d/f'{scene}_room_{room}.c';p.write_text(original(p)+f'\n#include "{inc}"\n');p=next(p for p in d.glob(f'{scene}_room_{room}_*ActorEntryList.inc.c') if 'AltHeaders' not in p.name);s=original(p);count=s.count('ACTOR_');assert count=={'triangle':26,'pregtest':5,'flatsquid':1}[key]
 rot=f'{{ 0, {yaw}, 0 }}'if key=='triangle'else'{ 2, 0, 1 }'
 p.write_text(s+'    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, '+rot+', '+param+' }, /* optional '+key+' */\n')
 p=d/f'{scene}_room_{room}.h';s=original(p);s,n=re.subn(rf'(#define LENGTH_{scene}_room_{room}_\w+_ActorEntryList ){count}\b',lambda m:m[1]+str(count+1),s,count=1);assert n==1;p.write_text(s)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);helper=(R/'tools/fundstuecke_actor.inc.c').read_text();needle='void ElfMsg2_Init(Actor* thisx, PlayState* play) {';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
needle='    if (ElfMsg2_IsSuperhero(thisx, play)) {\n        ElfMsg2_InitSuperhero';assert s.count(needle)==1;s=s.replace(needle,'    if (ElfMsg2_IsTriangleGuy(thisx, play)) {\n        ElfMsg2_InitTriangleGuy(this, play);\n        return;\n    }\n'+needle)
needle='    if (ElfMsg2_IsSuperhero(thisx, play)) {\n        ElfMsg2_UpdateSuperhero';assert s.count(needle)==1;s=s.replace(needle,'    if (ElfMsg2_IsTriangleGuy(thisx, play)) {\n        ElfMsg2_UpdateTriangleGuy(this, play);\n        return;\n    }\n'+needle)
needle='        if (ElfMsg2_IsPepsiCan(thisx, play)) {';assert s.count(needle)==1;s=s.replace(needle,'''        if (ElfMsg2_IsFundstueck(thisx, play)) {
            s32 test = thisx->params == 0x3F79;
            if (gSaveContext.language != LANGUAGE_GER || (test ? !LINK_IS_CHILD : LINK_IS_CHILD)) {
                Actor_Kill(thisx);
                return;
            }
            Actor_SetScale(thisx, 0.01f);
            Actor_SetFocus(thisx, test ? 2.0f : 5.0f);
            thisx->attentionRangeType = ATTENTION_RANGE_0;
            thisx->textId = test ? 0x608B : 0x608C;
            thisx->draw = ElfMsg2_DrawFundstueck;
        }
'''+needle);p.write_text(s)
print('Three room-local gags; native Navi checks and optional final-battle conversation; no boss actor edits.')

"""Last builder after build_kenny.py: replace the old LEGO X-Wing completely."""
from pathlib import Path
import json,struct,sys
from build_story import messages,Layout,rewrite
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();D=O/'extracted/pal-1.0/assets/scenes/dungeons/HAKAdan';native=R/'tools/originals/xwing'
m=json.loads((R/'tools/naboo_source.json').read_text());assert len(m['triangles'])<=1600
lines=['/* User-supplied LEGO Naboo Starfighter; 36-unit length, original aspect ratio. */'];ma=[.01,0,0,0,0,.01,0,0,0,0,.01,0,-1750,-63,-300,1];fixed=[round(x*65536)&0xffffffff for x in ma];data=b''.join(struct.pack('>H',x>>16)for x in fixed)+b''.join(struct.pack('>H',x&65535)for x in fixed)
lines+=['static u64 gNabooPlacement[]={']+['0x'+data[i:i+8].hex().upper()+','for i in range(0,64,8)]+['};'];vertices=[];commands=[]
for mi,mat in enumerate(m['materials']):
 color=[round(x*255)for x in mat['rgba'][:3]];commands+=['gsDPPipeSync(),','gsDPSetPrimColor(0,0,%d,%d,%d,255),'%tuple(color)]
 local=[];lookup={};faces=[]
 def flush():
  if not faces:return
  base=len(vertices);vertices.extend(local);commands.append('gsSPVertex(&gNabooVertices[%d],%d,0),'%(base,len(local)))
  for j in range(0,len(faces),2):
   if j+1<len(faces):commands.append('gsSP2Triangles(%d,%d,%d,0,%d,%d,%d,0),'%tuple(faces[j]+faces[j+1]))
   else:commands.append('gsSP1Triangle(%d,%d,%d,0),'%tuple(faces[j]))
 for t in (t for t in m['triangles']if t['material']==mi):
  keys=[tuple(m['vertices'][c['vertex']]+[x&255 for x in c['normal']])for c in t['corners']]
  if len(set(lookup)|set(keys))>32:flush();local=[];lookup={};faces=[]
  face=[]
  for key in keys:
   if key not in lookup:lookup[key]=len(local);local.append(key)
   face.append(lookup[key])
  faces.append(face)
 flush()
lines+=['static Vtx gNabooVertices[]={']+['{{{%d,%d,%d},0,{0,0},{%d,%d,%d,255}}},'%v for v in vertices]+['};','Gfx gNabooDL[]={','gsDPPipeSync(),','gsSPMatrix((Mtx*)gNabooPlacement,G_MTX_MODELVIEW|G_MTX_MUL|G_MTX_PUSH),','gsDPSetCycleType(G_CYC_2CYCLE),','gsSPTexture(0,0,0,0,G_OFF),','gsDPSetTextureLUT(G_TT_NONE),','gsSPClearGeometryMode(G_CULL_BACK|G_CULL_FRONT|G_TEXTURE_GEN|G_TEXTURE_GEN_LINEAR),','gsSPSetGeometryMode(G_LIGHTING|G_SHADE|G_SHADING_SMOOTH|G_ZBUFFER|G_FOG),','gsDPSetRenderMode(G_RM_FOG_SHADE_A,G_RM_AA_ZB_OPA_SURF2),','gsDPSetCombineLERP(PRIMITIVE,0,SHADE,0,0,0,0,1,0,0,0,COMBINED,0,0,0,COMBINED),']+commands+['gsDPPipeSync(),','gsSPPopMatrix(G_MTX_MODELVIEW),','gsSPEndDisplayList(),','};']
(D/'naboo_model.inc.c').write_text('\n'.join(lines)+'\n')
def orig(p):return(native/p.relative_to(O)).read_text()
p=D/'HAKAdan_room_0.c';p.write_text(orig(p)+'\n#include "naboo_model.inc.c"\n')
p=D/'HAKAdan_room_0.h';p.write_text(orig(p).replace('#include "room.h"','#include "room.h"\nextern Gfx gNabooDL[];'))
p=D/'HAKAdan_room_0_03000190_RoomShapeNormal_0300019C_DListsEntries_03008170_DL.inc.c';s=orig(p);assert s.count('gsSPEndDisplayList(),')==1;p.write_text(s.replace('gsSPEndDisplayList(),','gsSPBranchList(gNabooDL),'))
p=R/'story/xwing_kakariko_de.json';chapter=json.loads(p.read_text());chapter['chapter']='LEGO Naboo-Starfighter im Schattentempel'
for ident in ['507B','507C']:chapter['messages'][ident]['pages'][0]="Scheiße, ich hab' meinen Lego Naboo-Starfighter im Schattentempel liegen lassen!"
p.write_text(json.dumps(chapter,ensure_ascii=False,indent=2)+'\n')
p=O/'extracted/pal-1.0/text/message_data.h';s=p.read_text();layout=Layout(O)
for ident,entry in chapter['messages'].items():
 a,b,body=messages(s)[ident]['parts'][2];replacement,_=rewrite(body,entry,layout,ident);s=s[:a]+replacement+s[b:]
p.write_text(s)
print('Naboo:',len(m['triangles']),'triangles,',m['game_dimensions'],'units; X-Wing display list removed; texts 507B/507C updated.')

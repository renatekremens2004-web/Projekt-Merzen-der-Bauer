"""Yellow Guy in each era; Wario only in child Kakariko. Append room-local models after build_wawario.py."""
from pathlib import Path
import sys,json,re
from n64_model import emit
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/yellow-guy'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
models={k:json.loads((R/f'tools/{k}_source.json').read_text())for k in ['yellowguy','punkyellow','wario']}
placements=[('yellowguy','YellowGuy','spot15',[-425,1085,3550],0,'0x3F7D',['03000054']),('punkyellow','PunkYellow','ganon_tou',[300,1315,1750],0,'0x3F7E',['03000070']),('wario','Wario','spot01',[-900,80,950],-16384,'0x3F7F',['03000084','03000C98'])]
for key,prefix,scene,pos,yaw,param,addresses in placements:
 d=O/'extracted/pal-1.0/assets/scenes/overworld'/scene;inc=key+'_model.inc.c';m=models[key];assert len(m['triangles'])<=1500
 (d/inc).write_text(emit(m,R/'models'/key,prefix,rigged=True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL'))
 p=d/f'{scene}_room_0.c';p.write_text(original(p)+f'\n#include "{inc}"\n');hp=d/f'{scene}_room_0.h';h=original(hp)
 for addr in addresses:
  p=next(d.glob(f'{scene}_room_0_*{addr}_ActorEntryList.inc.c'));s=original(p);count=s.count('ACTOR_');expected={'spot15':59,'ganon_tou':13,'spot01':57 if addr=='03000084'else 50};assert count==expected[scene],(scene,count)
  p.write_text(s+'    { ACTOR_ELF_MSG2, { '+', '.join(map(str,pos))+' }, { 0, '+str(yaw)+', 0 }, '+param+' }, /* friendly '+key+'; own era only */\n')
  h,n=re.subn(r'(#define LENGTH_'+re.escape(p.stem.replace('.inc',''))+r' )'+str(count)+r'\b',lambda m:m[1]+str(count+1),h);assert n==1
 hp.write_text(h)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p);helper=(R/'tools/yellow_guy_actor.inc.c').read_text()
for key in models:helper=helper.replace(key.upper()+'_PIVOTS',', '.join('{'+','.join(map(str,b['position']))+'}'for b in models[key]['bones']))
needle='void ElfMsg2_Init(Actor* thisx, PlayState* play) {';assert s.count(needle)==1;s=s.replace(needle,helper+'\n'+needle)
for action in ['Init','Update']:
 needle=f'    if (ElfMsg2_IsWawarioBros(thisx, play)) {{\n        ElfMsg2_{action}WawarioBros';assert s.count(needle)==1
 s=s.replace(needle,f'    if (ElfMsg2_IsYellowCast(thisx, play)) {{\n        ElfMsg2_{action}YellowCast(this, play);\n        return;\n    }}\n'+needle)
needle='ElfMsg2_IsSuperhero(thisx, play) || ElfMsg2_IsWawarioBros(thisx, play))';assert s.count(needle)==1;s=s.replace(needle,needle[:-1]+' || ElfMsg2_IsYellowCast(thisx, play))');p.write_text(s)
print('Child Yellow Guy, adult Punk Yellow Guy, CHILD Wario; four own matrices each, no extra object slots.')

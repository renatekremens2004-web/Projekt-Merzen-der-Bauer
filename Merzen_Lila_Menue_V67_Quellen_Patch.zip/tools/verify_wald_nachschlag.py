"""Verify additional forest and Fire Temple dialogue against the published water/spirit sages revision."""
from pathlib import Path
import argparse,csv,hashlib,json,math,re,struct,subprocess
from ipl3checksum import CICKind,calculateChecksum
from verify_story import segment,check_buffers
import build_story as dialogue
ROOT=Path(__file__).resolve().parent.parent
BASE_SHA='c4c5971754b4a1972127881a44c11c06819aafb71ce110622beb9e0ab43ef406'

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('oot',type=Path);ap.add_argument('baseline',type=Path);args=ap.parse_args()
    oot=args.oot.resolve();build=oot/'build/pal-1.0'
    old=args.baseline.read_bytes();packed=(build/'oot-pal-1.0-compressed.z64').read_bytes()
    plain=(build/'oot-pal-1.0.z64').read_bytes()
    assert hashlib.sha256(old).hexdigest()==BASE_SHA
    assert len(packed)==33554432 and packed[0x3e:0x40]==b'P\0'
    assert struct.unpack_from('>II',packed,16)==calculateChecksum(packed,CICKind.CIC_X105)
    mp=(build/'oot-pal-1.0.map').read_text()
    symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp):
        symbols.setdefault(name,int(address,16))
    def sym(name):
        return symbols[name]
    elf=subprocess.check_output(['mips-linux-gnu-readelf','-rW',str(build/'oot-pal-1.0.elf')],text=True)
    rels={};current=None
    for line in elf.splitlines():
        header=re.match(r"Relocation section '\.rel\.\.([^']+)'",line)
        if header:
            current=header[1];rels.setdefault(current,{})
        entry=re.match(r'([0-9a-f]{8})\s+[0-9a-f]+\s+(R_MIPS_\w+)\s+[0-9a-f]+\s+(\S+)',line)
        if current and entry:
            rels[current][int(entry[1],16)]=(entry[2],entry[3])
    intentional={'makerom','dmadata','code','ger_message_data_static','ovl_En_Mk'}
    identical=[];relocated=[];changed=[];verified=0;object_bytes=None
    names=[r['Name'] for r in csv.DictReader((oot/'baseroms/pal-1.0/segments.csv').open())]
    for index,name in enumerate(names):
        _,_,before=segment(old,index)
        start,end,unpacked=segment(packed,index)
        if unpacked is None:
            continue
        expected=plain[start:end]
        if name=='makerom':
            assert unpacked[:16]==expected[:16] and unpacked[24:]==expected[24:]
        elif name!='dmadata':
            assert unpacked==expected,('compression',name)
            verified+=1
        lo,hi=[sym('_'+name+'SegmentRom'+suffix) for suffix in ['Start','End']]
        after=plain[lo:hi]
        if name=='object_im':
            object_bytes=len(after)
            assert len(after)<=86016,('object memory budget exceeded',len(after))
        if before==after:
            identical.append(name);continue
        if name in intentional:
            changed.append({'segment':name,'before_bytes':len(before),'after_bytes':len(after)});continue
        assert len(before)==len(after),('unexpected size change',name,len(before),len(after))
        origin=sym('_'+name+'SegmentStart')
        differences=sorted({i//4*4 for i,(x,y) in enumerate(zip(before,after)) if x!=y})
        for offset in differences:
            rel=rels.get(name,{}).get(origin+offset)
            assert rel,('unexplained changed word',name,hex(origin+offset))
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[offset:offset+2]==after[offset:offset+2],(name,rel)
            elif kind=='R_MIPS_26':
                assert before[offset]>>2==after[offset]>>2,(name,rel)
            else:
                assert kind=='R_MIPS_32',(name,rel)
        relocated.append({'segment':name,'relocated_words':len(differences)})
    assert verified==1509
    # Read the actual ROM language tables, rather than trusting generated JSON alone.
    # Symbols from the SHA256-pinned published baseline ELF.
    old_symbols={}
    def german_messages(rom,tab,code_base):
        _,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'))
        off=tab-code_base;entries=[]
        # PAL German table contains only pointers; IDs/order come from NES entries.
        ids=[];nes=(old_symbols if rom==args.baseline.read_bytes() else symbols)['sNesMessageEntryTable']-code_base
        while True:
            ident=struct.unpack_from('>H',code,nes)[0]
            if ident==0xffff:break
            if ident!=0xfffc:ids.append(ident)
            nes+=8
        for i,ident in enumerate(ids):entries.append((ident,struct.unpack_from('>I',code,off+4*i)[0]&0xffffff))
        result={}
        for i,(ident,start) in enumerate(entries):
            end=entries[i+1][1] if i+1<len(entries) else len(data)
            result[ident]=data[start:end].rstrip(bytes([0]))
        return result
    _,_,before_code=segment(args.baseline.read_bytes(),names.index('code'))
    _,_,after_code=segment(packed,names.index('code'))
    baseline_map=(args.baseline.parent/'baseline.map').read_text()
    baseline_symbols={}
    for address,name in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',baseline_map):
        baseline_symbols.setdefault(name,int(address,16))
    old_symbols=baseline_symbols
    oldbase=baseline_symbols['_codeSegmentStart'];newbase=sym('_codeSegmentStart')
    anchors={oldbase:(newbase,['_codeSegmentStart'])}
    for name,addr in baseline_symbols.items():
        if name not in symbols:continue
        current=sym(name)
        if oldbase<=addr<oldbase+len(before_code) and newbase<=current<newbase+len(after_code):
            if addr in anchors:
                assert anchors[addr][0]==current,('alias movement',name)
                anchors[addr][1].append(name)
            else:anchors[addr]=(current,[name])
    anchors[oldbase+len(before_code)]=(newbase+len(after_code),['code ROM end'])
    order=sorted(anchors);code_relocations=[];padding=[]
    for lo,hi in zip(order,order[1:]):
        start,names_at=anchors[lo];end=anchors[hi][0]
        before=before_code[lo-oldbase:hi-oldbase];after=after_code[start-newbase:end-newbase]
        if len(before)!=len(after):
            common=min(len(before),len(after));assert abs(len(before)-len(after))<=16,('unexpected interval growth',names_at,len(before),len(after))
            assert all(x==0 for x in before[common:]+after[common:]),('non-padding growth',names_at)
            padding.append({'symbols':names_at,'before':len(before),'after':len(after)})
        common=min(len(before),len(after));assert common%4==0
        for i in range(0,common,4):
            if baseline_symbols['sGerMessageEntryTable']<=lo+i<baseline_symbols['sFraMessageEntryTable']:continue
            if before[i:i+4]==after[i:i+4]:continue
            addr=start+i;rel=rels.get('code',{}).get(addr);assert rel,('unexpected core word',hex(addr),names_at)
            kind,target=rel
            if kind in ['R_MIPS_HI16','R_MIPS_LO16','R_MIPS_16']:
                assert before[i:i+2]==after[i:i+2],(hex(addr),rel)
            elif kind=='R_MIPS_26':assert before[i]>>2==after[i]>>2,(hex(addr),rel)
            else:
                assert kind=='R_MIPS_32',rel
                oldword=struct.unpack_from('>I',before,i)[0];newword=struct.unpack_from('>I',after,i)[0]
                if target=='..code':
                    import bisect
                    assert oldbase<=oldword<baseline_symbols['_codeSegmentEnd'],('section pointer',hex(oldword))
                    if oldword>=order[-1]:expected=oldword+sym('_codeSegmentDataStart')-baseline_symbols['_codeSegmentDataStart']
                    else:
                        key=order[bisect.bisect_right(order,oldword)-1];expected=anchors[key][0]+oldword-key
                    assert newword==expected,('section pointer movement',hex(addr),hex(oldword),hex(newword),hex(expected))
                else:
                    assert (oldword-baseline_symbols[target])&0xffffffff == (newword-sym(target))&0xffffffff,('relocation addend',hex(addr),target)
            code_relocations.append({'address':hex(addr),'type':kind,'target':target})

    before_text=german_messages(old,old_symbols['sGerMessageEntryTable'],old_symbols['_codeSegmentStart'])
    after_text=german_messages(packed,sym('sGerMessageEntryTable'),sym('_codeSegmentStart'))
    changed_ids={i for i in before_text if before_text[i]!=after_text[i]}
    forest=json.loads((ROOT/'story/wald_nachschlag_de.json').read_text())['messages']
    expected={int(i,16) for i in forest}|{0x016b,0x106c,0x01a3,0x01a5,0x01a7,0x01a9,0x0105,0x0152}
    assert changed_ids==expected,sorted(hex(i) for i in changed_ids^expected)
    assert all(before_text[i]==after_text[i] for i in [0x0151,0x0120,0x105f,0x1076,0x1060,0x1061,0x1068,0x4018,0x4019,0x4030,0x4074])
    assert {'object_ru1','object_ru2','object_nb','object_zo','object_sa','object_im','object_rl','object_dekujr','bdan_room_3','spot04_room_0'}<=set(identical)
    assert {'spot05_scene','HIDAN_scene'} <= set(identical)|{r['segment'] for r in relocated}
    import build_story as b
    current=b.messages((oot/'extracted/pal-1.0/text/message_data.h').read_text())
    native=b.messages((ROOT/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())
    edits={};chain={'704F':'0121','0121':'0122','0122':'0123'}
    for path in (ROOT/'story').glob('*.json'):
        for ident,entry in json.loads(path.read_text())['messages'].items():
            assert ident not in edits;edits[ident]=entry
            src=native[entry.get('native_template',ident)]['parts'][2][2];dst=current[ident]['parts'][2][2]
            assert b.controls(src)+(['TEXTID(0x'+chain[ident]+')'] if ident in chain else [])==b.controls(dst),ident
    for ident in json.loads((ROOT/'planning/SAGE_NAMEN.json').read_text()):edits.setdefault(ident,{})
    # Exactly two displayed intro assignments differ; native actor IDs, swimming and trade logic remain exact.
    rel='src/overlays/actors/ovl_En_Mk/z_en_mk.c';a=(ROOT/'tools/originals/wald_nachschlag'/rel).read_text();z=(oot/rel).read_text()
    replacement='(gSaveContext.language == LANGUAGE_GER && LINK_IS_ADULT) ? 0x0199 : 0x4018'
    assert z.count(replacement)==2 and z.replace(replacement,'0x4018')==a
    assert 'TEXTID(0x1056)' in b.controls(current['1055']['parts'][2][2])
    assert 'TEXTID(0x105E)' in b.controls(current['105D']['parts'][2][2])
    assert 'TEXTID(0x105C)' in b.controls(current['105B']['parts'][2][2])
    assert 'TEXTID(0x1059)' in b.controls(current['1058']['parts'][2][2])
    assert 'EVENT' in b.controls(current['016A']['parts'][2][2])
    report={'rom_sha256':hashlib.sha256(packed).hexdigest(),'rom_bytes':len(packed),'baseline_sha256':BASE_SHA,'compressed_segments_verified':verified,'identical_segments':identical,'relocated_segments':relocated,'intentional_changes':changed,'core_relocations_checked':len(code_relocations),'changed_german_ids':sorted(f'{i:04X}' for i in changed_ids),'dialogue_buffers':check_buffers(build,edits),'models_and_scene_data_unchanged':True,'fixed_times_and_controls_unchanged':True,'adult_lab_intro':{'new_id':'0199','native_state_id':'4018','child_english_reward_trade_branches_preserved':True},'navi_ids': ['0151','01A3','01A5','01A7','01A9','0105','0152'],'story_count':len({i for p in (ROOT/'story').glob('*.json') for i in json.loads(p.read_text())['messages']})}
    (build/'wald-nachschlag-verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print('Verified',verified,'compressed segments;',len(identical),'identical;',len(changed_ids),'German changes;',len(edits),'message buffers; models, scene data, native timings and lab trade/reward logic preserved.')
if __name__=='__main__':main()

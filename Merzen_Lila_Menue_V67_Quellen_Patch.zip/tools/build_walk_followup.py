"""Apply after build_character_sizes.py: articulated Wallace gait and proportionate Spirit Waluigi."""
from pathlib import Path
import sys,json,re,subprocess
from n64_model import emit
from rig_wallace_legs import rig
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();m=rig()
for path,prefix in [('assets/objects/object_du','AdultWallace'),('assets/scenes/dungeons/HIDAN','PrisonWallace')]:
 s=emit(m,R/'models/wallace-adult',prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');(O/'extracted/pal-1.0'/path/'wallace_adult_model.inc.c').write_text(s)
for overlay in ['En_Go2','Demo_Du']:
 d=O/'src/overlays/actors'/('ovl_'+overlay);(d/'wallace_adult_draw.inc.c').write_bytes((R/'tools/wallace_adult_draw.inc.c').read_bytes());p=d/('z_'+overlay.lower()+'.c');s=p.read_text()
 if overlay=='En_Go2':
  old='POLY_OPA_DISP = WallaceAdult_Draw(&this->actor, play, POLY_OPA_DISP, gPrisonWallaceDL, 0.0f, 0.0f);'
  new='''POLY_OPA_DISP = WallaceAdult_Draw(&this->actor, play, POLY_OPA_DISP, gPrisonWallaceDL, 0.0f, 0.0f,
        (this->goronState == 2 && this->actor.speed > 0.0f && this->animTimer > 0) ?
            CLAMP((60.0f - this->animTimer) / 4.0f, 0.0f, 1.0f) * CLAMP(this->animTimer / 4.0f, 0.0f, 1.0f) : 0.0f,
        ((60 - this->animTimer) & 15) * (3.14159265358979323846f / 8.0f));'''
 else:
  old='return WallaceAdult_Draw(&this->actor, play, gfx, gAdultWallaceDL, arm, head);'
  new='return WallaceAdult_Draw(&this->actor, play, gfx, gAdultWallaceDL, arm, head, 0.0f, 0.0f);'
 assert old in s or new in s;s=s.replace(old,new);p.write_text(s)
p=R/'tools/waluigi_sage_source.json';w=json.loads(p.read_text())
if w['height']==8800:
 f=.75
 for v in w['vertices']:
  for key in ['position','source_world']:
   if key in v:v[key]=[round(x*f)for x in v[key]]
 for b in w['bones']:b['position']=[round(x*f)for x in b['position']]
 for frames in w['animations'].values():
  for pose in frames:pose['root']=[round(x*f)for x in pose['root']]
 w['height']=6600;w['uniform_scale']*=f;w['size_adjustment']=dict(factor=f,previous_height=8800,new_height=6600,all_axes_and_animation_roots=True,rotations_normals_uvs_topology_unchanged=True);p.write_text(json.dumps(w,separators=(',',':'))+'\n')
assert w['height']==6600
s=emit(w,R/'models/waluigi-party3','WaluigiSage',True)
for label in w['animations']:s=s.replace('gWaluigiSage'+label.title().replace('_','')+'Anim',label)
(O/'extracted/pal-1.0/assets/objects/object_nb/waluigi_sage_model.inc.c').write_text(s)
from fit_waluigi_cameras import fit
fit(O)
print('Wallace: 10 own matrices, native release-only 16-frame IK gait; Waluigi uniformly 25 percent smaller.')

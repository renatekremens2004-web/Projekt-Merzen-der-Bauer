"""Last-step additions: adult Ben encounter, separated Ice heroes and native Zora."""
from pathlib import Path
import json,sys,re
from n64_model import emit
from build_story import messages,plain,Layout,rewrite
R=Path(__file__).resolve().parent.parent;O=Path(sys.argv[1]).resolve();B=R/'tools/originals/ben-ice'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
def append_actor(sc,room,actor,pos,yaw,param,model=None):
 D=O/f'extracted/pal-1.0/assets/scenes/dungeons/{sc}';p=D/f'{sc}_room_{room}.c';s=original(p)
 entries=[p for p in D.glob(f'{sc}_room_{room}_0*ActorEntryList.inc.c')if 'AltHeaders'not in p.name]
 line='    { '+actor+', { '+', '.join(map(str,pos))+' }, { 0, '+str(yaw)+', 0 }, '+param+' }, /* optional conversation; native puzzle unmodified */\n'
 if entries:
  assert len(entries)==1;q=entries[0];text=original(q);count=text.count('ACTOR_');q.write_text(text+line)
  q=D/f'{sc}_room_{room}.h';text,n=re.subn(rf'(#define LENGTH_{sc}_room_{room}_\w+_ActorEntryList ){count}\b',lambda m:m[1]+str(count+1),original(q));assert n==1;q.write_text(text)
 else:
  # Empty native shortcut corridor gets its first actor list, preserving every native command.
  q=D/f'{sc}_room_{room}.inc.c';text=original(q);text=text.replace('    SCENE_CMD_END(),','    SCENE_CMD_ACTOR_LIST(1, gIceChumSpawns),\n    SCENE_CMD_END(),');q.write_text(text)
  q=D/f'{sc}_room_{room}.h';q.write_text(original(q)+'\n#include "actor.h"\nextern ActorEntry gIceChumSpawns[1];\n')
  s=s.replace('#include "array_count.h"','#include "actor.h"\n#include "array_count.h"');s+='\nActorEntry gIceChumSpawns[1] = {\n'+line+'};\n'
 if model:
  key,prefix=model;m=json.loads((R/f'tools/{key}_source.json').read_text());g=emit(m,R/'models'/key,prefix,True).replace('static Gfx g'+prefix+'BodyDL[]={','Gfx g'+prefix+'DL[]={').replace('g'+prefix+'BodyDL','g'+prefix+'DL');inc=key+'_ben_ice_model.inc.c';(D/inc).write_text(g);s+=f'\n#include "{inc}"\n'
 p.write_text(s)
append_actor('men',3,'ACTOR_ELF_MSG2',[-1580,160,-2680],16384,'0x3F80',('ben10','Ben10'))
append_actor('ice_doukutu',9,'ACTOR_ELF_MSG2',[1000,22,-2500],-32768,'0x3F75',('fanboy','IceFanboy'))
append_actor('ice_doukutu',10,'ACTOR_ELF_MSG2',[-545,199,1450],16384,'0x3F76',('chumchum','IceChumChum'))
append_actor('ice_doukutu',11,'ACTOR_EN_ZO',[1170,-71,350],0,'0x7FC7')
D=O/'extracted/pal-1.0/assets/scenes/dungeons/ice_doukutu';p=next(p for p in D.glob('ice_doukutu_room_11_0*ObjectList.inc.c')if 'AltHeaders'not in p.name);s=original(p);count=s.count('OBJECT_');p.write_text(s+'    OBJECT_ZO, /* native animated plastic-ice expert */\n');p=D/'ice_doukutu_room_11.h';s=p.read_text();s,n=re.subn(rf'(#define LENGTH_ice_doukutu_room_11_\w+_ObjectList ){count}\b',lambda m:m[1]+str(count+1),s);assert n==1;p.write_text(s)
p=O/'src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(p)
s=s.replace('extern Gfx gFanboyDL[];','extern Gfx gBen10DL[];\nextern Gfx gIceFanboyDL[];\nextern Gfx gIceChumChumDL[];\nextern Gfx gFanboyDL[];')
a=s.index('static s32 ElfMsg2_IsSuperhero');b=s.index('\n#include "player.h"',a);part=s[a:b]
old='((actor->room == 7 && actor->params == 0x3F75) || (actor->room == 19 && actor->params == 0x3F76)));'
new='''((actor->room == 7 && actor->params == 0x3F75) || (actor->room == 19 && actor->params == 0x3F76))) ||
        (play->sceneId == SCENE_ICE_CAVERN &&
            ((actor->room == 9 && actor->params == 0x3F75) || (actor->room == 10 && actor->params == 0x3F76))) ||
        (play->sceneId == SCENE_GERUDO_TRAINING_GROUND && actor->room == 3 && actor->params == 0x3F80);'''
assert part.count(old)==1;part=part.replace(old,new)
# Own four rigid groups use only rotations; no imported Impa/Saria body proportions.
m=json.loads((R/'tools/ben10_source.json').read_text());pivots=', '.join('{'+','.join(map(str,b['position']))+'}'for b in m['bones'])
part=part.replace('    static Vec3f fanboyPivots[4]',f'    static Vec3f benPivots[4] = {{ {pivots} }};\n    static Vec3f fanboyPivots[4]')
part=part.replace('    s32 fanboy = actor->params == 0x3F75;','    s32 ben = actor->params == 0x3F80;\n    s32 fanboy = actor->params == 0x3F75;')
part=part.replace('Vec3f* pivots = crocker ?', 'Vec3f* pivots = ben ? benPivots : crocker ?')
part=part.replace('crocker ? gCrockerDL : play->sceneId', 'ben ? gBen10DL : crocker ? gCrockerDL : play->sceneId == SCENE_ICE_CAVERN ? (fanboy ? gIceFanboyDL : gIceChumChumDL) : play->sceneId')
old='crocker ? 0x6089 : fanboy ? (play->sceneId == SCENE_WATER_TEMPLE ? 0x7068 : 0x6087) : (play->sceneId == SCENE_WATER_TEMPLE ? 0x7069 : 0x6088)'
new='ben ? 0x706A : crocker ? 0x6089 : fanboy ? (play->sceneId == SCENE_ICE_CAVERN ? 0x403D : play->sceneId == SCENE_WATER_TEMPLE ? 0x7068 : 0x6087) : (play->sceneId == SCENE_ICE_CAVERN ? 0x4040 : play->sceneId == SCENE_WATER_TEMPLE ? 0x7069 : 0x6088)'
assert part.count(old)==2;part=part.replace(old,new).replace('crocker ? 16 : fanboy ? 15 : 18','ben ? 14 : crocker ? 16 : fanboy ? 15 : 18').replace('crocker ? 13 : fanboy ? 13 : 18','ben ? 13 : crocker ? 13 : fanboy ? 13 : 18').replace('crocker ? 86 : fanboy ? 76 : 47','ben ? 68 : crocker ? 86 : fanboy ? 76 : 47').replace('crocker ? 75 : fanboy ? 66 : 40','ben ? 60 : crocker ? 75 : fanboy ? 66 : 40')
# Native red ice uses the already loaded OBJECT_ICE_OBJECTS. Private home.rot.z
# records successful allocation only; no persistent child pointer or custom freeze ABI.
helper="""static s32 ElfMsg2_ChumFrozen(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_ICE_CAVERN && actor->room == 10 && actor->params == 0x3F76 &&
        actor->home.rot.z == 1 && !Flags_GetSwitch(play, 0x1E);
}
"""
part=part.replace('static void ElfMsg2_DrawSuperhero',helper+'static void ElfMsg2_DrawSuperhero')
part=part.replace('    if (roomSegment == NULL) return;','    if (ElfMsg2_ChumFrozen(actor, play)) idle = talk = 0.0f;\n    if (roomSegment == NULL) return;')
part=part.replace('    actor->draw = ElfMsg2_DrawSuperhero;','    actor->draw = ElfMsg2_DrawSuperhero;\n    if (play->sceneId == SCENE_ICE_CAVERN && actor->room == 10 && actor->params == 0x3F76 &&\n        !Flags_GetSwitch(play, 0x1E)) {\n        Actor* ice = Actor_Spawn(&play->actorCtx, play, ACTOR_BG_ICE_SHELTER,\n                                actor->world.pos.x, actor->world.pos.y, actor->world.pos.z,\n                                0, 0, 0, 0x011E);\n        if (ice != NULL) {\n            ice->room = actor->room;\n            actor->home.rot.z = 1;\n            actor->flags &= ~ACTOR_FLAG_ATTENTION_ENABLED;\n        }\n    }')
start=part.index('static void ElfMsg2_UpdateSuperhero');head=part[:start];tail=part[start:]
tail=tail.replace('    if (!Actor_TalkOfferAccepted(actor, play)', '    if (ElfMsg2_ChumFrozen(actor, play)) {\n        actor->flags &= ~ACTOR_FLAG_ATTENTION_ENABLED;\n        return;\n    }\n    actor->flags |= ACTOR_FLAG_ATTENTION_ENABLED;\n    if (!Actor_TalkOfferAccepted(actor, play)')
part=head+tail
s=s[:a]+part+s[b:];p.write_text(s)
p=O/'src/overlays/actors/ovl_En_Zo/z_en_zo.c';s=original(p);old='    u16 textId = MaskReaction_GetTextId(play, MASK_REACTION_SET_ZORA);';s=s.replace(old,old+'''\n\n    if (gSaveContext.language == LANGUAGE_GER && LINK_IS_ADULT &&
        play->sceneId == SCENE_ICE_CAVERN && thisx->room == 11 && thisx->params == 0x7FC7) {
        return 0x706B;
    }''')
a=s.index('void EnZo_Init(Actor* thisx, PlayState* play) {');pos=s.index('    ActorShape_Init',a);s=s[:pos]+'''    if (thisx->params == 0x7FC7 &&
        (gSaveContext.language != LANGUAGE_GER || LINK_IS_CHILD ||
         play->sceneId != SCENE_ICE_CAVERN || thisx->room != 11)) {
        Actor_Kill(thisx);
        return;
    }

'''+s[pos:];p.write_text(s)
entries={
 '706A':{'native_template':'0022','pages':["Ben 10! Mit der Omnitrix kann ich hier locker alles plattmachen. Monster? Roboter? Kein Problem!","Friedrich Merz ist allerdings ein Mensch. Und ich bin doch kein Mörder!","Bei Aliens ist das natürlich kein Mord. Sonst müßte ich mir über meine ganze Karriere Gedanken machen."]},
 '403D':{'native_template':'0022','pages':["Eisige Grüße! Fanboy und Chum Chum sind im Einsatz! Wir sammeln Eis für unsere Freezy-Slushies!","Andere Helden retten die Welt. Wir retten die Welt UND bringen ein kühles Getränk mit!","Chum Chum sucht schon mal weiter. Beim nächsten Schluck denken wir natürlich auch an Dich!"]},
 '4040':{'native_template':'0022','pages':["Oh Mann, ich krieg hier echt Hirnfrost. Und ich hab noch nicht mal einen Freezy-Slushie getrunken!","Ich glaub, ich brauch eine Pause. Ich fühl mich so müde...","Vielleicht leg ich mich einfach einmal kurz hin. Nur ganz kurz..."]},
 '706B':{'native_template':'0022','pages':["Der Großteil von dem Eis hier ist übrigens aus transparentem Plastik.","Wir wollten nur noch mehr Leute vom Schlittschuhlaufen abhalten. Jetzt hab ich leider vergessen, welches Eis echt ist."]},
}
for p in (R/'story').glob('*.json'):
 if p.name=='ben_ice_de.json':continue
 assert not(set(entries)&set(json.loads(p.read_text())['messages'])),('duplicate text',p)
(R/'story/ben_ice_de.json').write_text(json.dumps(dict(chapter='Ben und eisige Helden',orthography='de-vor-1996',messages=entries),ensure_ascii=False,indent=2)+'\n')
target=O/'extracted/pal-1.0/text/message_data.h';source=target.read_text();current=messages(source);native=messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text());layout=Layout(O);changes=[]
for ident,e in entries.items():
 assert plain(native[ident]['parts'][2][2]).strip().upper()==ident
 a,b,old=current[ident]['parts'][2];body,_=rewrite(native['0022']['parts'][2][2],e,layout,ident);changes.append((a,b,body))
for a,b,body in sorted(changes,reverse=True):source=source[:a]+body+source[b:]
target.write_text(source)
print('Ben 1753 tris; Ice Fanboy/Chum native unchanged meshes, separated rooms 9/10; animated native Zora in room11. Four private conversations.')

/* Dedicated mode only. All ordinary Elf_Msg2 objects keep their native actions. */
extern Gfx gWallaceDL[];
static ColliderCylinderInit sWallaceCylinderInit = {
    { COL_MATERIAL_NONE, AT_NONE, AC_NONE, OC1_ON | OC1_TYPE_ALL, OC2_TYPE_1, COLSHAPE_CYLINDER },
    { ELEM_MATERIAL_UNK0,
      { 0, HIT_SPECIAL_EFFECT_NONE, 0 }, { 0, HIT_BACKLASH_NONE, 0 },
      ATELEM_NONE, ACELEM_NONE, OCELEM_ON },
    { 16, 82, 0, { 0, 0, 0 } },
};

static s32 ElfMsg2_IsWallace(Actor* actor, PlayState* play) {
    return play->sceneId == SCENE_DODONGOS_CAVERN && actor->room == 2 && actor->params == 0x3F9A;
}

static void ElfMsg2_DrawWallace(Actor* actor, PlayState* play) {
    static Vec3f pivots[4] = { {0,0,0}, {0,6851,-275}, {918,6186,-574}, {-918,6186,-574} };
    void* roomSegment = NULL;
    Mtx* matrices;
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 520));
    f32 gesture = Math_SinS((s16)(play->gameplayFrames * 970));
    if (play->roomCtx.curRoom.num == actor->room) roomSegment = play->roomCtx.curRoom.segment;
    else if (play->roomCtx.prevRoom.num == actor->room) roomSegment = play->roomCtx.prevRoom.segment;
    if (roomSegment == NULL) return;
    matrices = GRAPH_ALLOC(play->state.gfxCtx, 4 * sizeof(Mtx));
    if (matrices == NULL) return;
    OPEN_DISPS(play->state.gfxCtx, "wallace", 1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateX(idle * 0.025f, MTXMODE_APPLY);
        else if (i > 1) {
            Matrix_RotateZ(idle * (i == 2 ? 0.025f : -0.025f), MTXMODE_APPLY);
            if (play->msgCtx.talkActor == actor && Message_GetState(&play->msgCtx) != TEXT_STATE_NONE)
                Matrix_RotateX(gesture * 0.06f, MTXMODE_APPLY);
        }
        MATRIX_TO_MTX(&matrices[i], "wallace", 2);
        Matrix_Pop();
    }
    gSPSegment(POLY_OPA_DISP++, 0x03, roomSegment);
    gSPSegment(POLY_OPA_DISP++, 0x0D, matrices);
    gSPDisplayList(POLY_OPA_DISP++, gWallaceDL);
    gSPSegment(POLY_OPA_DISP++, 0x03, OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    CLOSE_DISPS(play->state.gfxCtx, "wallace", 3);
}

static void ElfMsg2_InitWallace(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Collider_InitCylinder(play, &this->wallaceCollider);
    /* Initialization precedes removal, so the destroy path is valid for adults too. */
    if (LINK_IS_ADULT || gSaveContext.language != LANGUAGE_GER) {
        Actor_Kill(actor);
        return;
    }
    Actor_ChangeCategory(play, &play->actorCtx, actor, ACTORCAT_NPC);
    actor->flags = ACTOR_FLAG_ATTENTION_ENABLED | ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->attentionRangeType = ATTENTION_RANGE_1;
    actor->naviEnemyId = 0xFF;
    actor->textId = 0x019A;
    actor->colChkInfo.mass = MASS_IMMOVABLE;
    Actor_SetScale(actor, 0.01f);
    ActorShape_Init(&actor->shape, 0, ActorShadow_DrawCircle, 22);
    Collider_SetCylinder(play, &this->wallaceCollider, actor, &sWallaceCylinderInit);
    Actor_SetFocus(actor, 75);
    actor->draw = ElfMsg2_DrawWallace;
}

static void ElfMsg2_UpdateWallace(ElfMsg2* this, PlayState* play) {
    Actor* actor = &this->actor;
    Actor_SetFocus(actor, 75);
    actor->textId = 0x019A;
    if (!Actor_TalkOfferAccepted(actor, play)) {
        if (actor->xzDistToPlayer < 120.0f && fabsf(actor->yDistToPlayer) < 50.0f) {
            Math_SmoothStepToS(&actor->shape.rot.y, actor->yawTowardsPlayer, 5, 0x300, 0);
            Actor_OfferTalk(actor, play, 115.0f);
        }
    }
    Actor_UpdateBgCheckInfo(play, actor, 0, 0, 0, UPDBGCHECKINFO_FLAG_2);
    Collider_UpdateCylinder(actor, &this->wallaceCollider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->wallaceCollider.base);
}

# Prüfung der deutschen PAL-1.0-Fassung, Überarbeitung 2

Grundlage: Nutzer-ROM Europa/PAL 1.0, MD5 `e040de91a74b61e3201db0e2323f768a`. Emulator: Mupen64Plus 2.6.0 mit HLE-RSP, Rice und zusätzlich dem GLideN64-Quellstand aus RMG 0.6.0 (`4972e76aea6b327959d1761c786077fd96b6cb30`). Die RMG-Oberfläche selbst wurde hier nicht ausgeführt.

## Modell und Speicher

Das Modell hat 2.419 Dreiecke statt 1.834. Die 996 geschützten ursprünglichen Kopfvertices blieben bei der Vereinfachung erhalten; am Anzug wurde stärker reduziert. Pupillen verwenden eigene erhaltene Geometrie. Die native Kieferbindung und Ganondorfs Animationen bleiben erhalten. Knochenlokale Normalen und eine kleine Farbpalette ersetzen die bisherige unbeleuchtete Vertexfarbe. Die Szenenbeleuchtung bestimmt Richtung und Farbe der Schattierung.

| Objekt | PAL-Original | Überarbeitung 2 |
| --- | ---: | ---: |
| Erwachsener Ganondorf | 70.912 Bytes | 66.080 Bytes |
| Junger Ganondorf | 72.192 Bytes | 68.112 Bytes |

Die Modellobjekte bleiben im ursprünglichen Objektbank-Budget. Es gibt keinen neuen Speicheraufbau, keine Expansion-Pak-Pflicht und keine geänderte PAL-Zeitsteuerung. RAM wurde im Spiel über `osMemSize` geprüft: 4.194.304 bzw. 8.388.608 Bytes. Für 4 MB wurde der Cached Interpreter verwendet, da der Dynarec beim Speicherprobeverfahren trotz deaktivierter Erweiterung 8 MB erkannte.

## Laufzeittests dieser Überarbeitung

- Reguläre komprimierte Download-ROM bis zur deutschen Namenseingabe mit GLideN64 und 8 MB; zusätzlicher 4-MB-Lauf mit Kontrolle der erkannten RAM-Größe.
- Erwachsener Burns im nativen Kampf mit Rice und 4 MB: wechselnde Animationen und Posen; Angriffe verletzten Link. Kein vollständiger Siegtest.
- Junger Burns auf dem Pferd mit Rice und 4 MB: native Reitanimation und Beleuchtung in der Szene.
- Schwebende Vision mit Rice und GLideN64: Kopf, Pupillen, verschränkte Arme, Lachen und deutsche Texte.
- Verwandlung mit GLideN64 und 4 MB bis zur originalen Monsterform und deren aktivem Kampf. Menschliche, Übergangs- und Monster-Darstellung wurden protokolliert.
- Frisches deutsches Inventar mit GLideN64: `Sram_InitNewSave()` plus ausschließlich fünf für den Test vergebene Deku-Nüsse; alle anderen Inventarplätze bleiben `ITEM_NONE`. Kein zusätzlicher Schild. Das Bild im Repository stammt aus diesem kontrollierten Test und zeigt keine Startausrüstung der Download-ROM.

Für direkte Szenentests wurde ausschließlich in getrennten Test-ROMs eine vorübergehende Startfunktion verwendet. Im Verwandlungstest wurde Link einmal im Emulator-RAM zum ursprünglichen Abstandsauslöser bewegt. Die veröffentlichte ROM enthält den normalen Spielstart; ihre Startquelle wurde gegen den ursprünglichen Repository-Stand geprüft.

## Originale Spielregeln und Daten

- Das gesamte kompilierte Pausemenü (`ovl_kaleido_scope`) einschließlich Item-, Slot- und Ausrüstungs-Altersanforderungen stimmt bytegenau mit der PAL-Original-ROM überein.
- Item-Icons und deren zusätzliche Grafikbanken stimmen bytegenau mit dem PAL-Original überein. Spieler-, Item-, HUD- und Ausrüstungsquellen sind unverändert. Es ist keine Inventarreparatur enthalten.
- Der zusätzliche Spiegelschild konnte nur durch absichtlich eingespeiste ungültige Inventardaten nachgestellt werden. Der normale deutsche Start erzeugt diese Daten im Test nicht. Wie der Eintrag in der vom Nutzer getesteten älteren US-Fassung entstand, ist ungeklärt; diese US-Untersuchung ist nicht Teil des deutschen Builds.
- Phantom-Ganon, Ganons Monsterobjekt und die drei Ganondorf-Animationsbanken stimmen bytegenau mit dem PAL-Original überein.
- Deutsche, englische und französische Nachrichtendaten, deutsche Menütexturen und Schrift stimmen bytegenau mit dem PAL-Original überein.
- Alle 1.509 regulären komprimierten DMA-Segmente wurden dekomprimiert und mit dem unkomprimierten Build verglichen. Header-Prüfsummen und DMA-Kompressionsadressen unterscheiden sich erwartungsgemäß.

Aktuelle Ergebnisse und Protokolle: [validation/pal-1.0-v2](validation/pal-1.0-v2). Die früheren Ergebnisse unter `validation/pal-1.0` dokumentieren die erste deutsche Fassung.

## Grenzen

Kein vollständiger Story-Durchlauf und keine Prüfung auf echter N64-Hardware. Fingerstellungen und Gesichtsvarianten bleiben vereinfacht. Originale Nahkameras können Burns' größere Nase und anderen Kopf beschneiden; dunkle Szenen können jetzt das Gesicht stark abschatten. Die bekannte verdeckende Fläche des isolierten Schlosshof-Teststarts wurde nicht erneut untersucht; sie trat bereits beim unveränderten Modell-Kontrollbuild auf. Expansion Pak schaltet keine zusätzlichen Detailstufen oder höheren Bildraten frei.

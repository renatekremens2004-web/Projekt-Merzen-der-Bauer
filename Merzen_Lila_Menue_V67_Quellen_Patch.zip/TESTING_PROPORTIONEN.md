# Prüfung der Bean-Proportionen

Ausgangsfassung: die vorherige Bean-Produktions-ROM mit SHA256 `2c33901bb6f34e66a84ce2cfecca84bdaf4469d01528f4898950fa19425f76d3`. Neue Produktions-ROM: `2245294cf6dcb23183a8aa34fae0d4b3270cc8ff6350836d7e2b2cfa7461cb16`; 32 MiB. Der BPS-Patch setzt direkt auf der unveränderten Europa/PAL-1.0-ROM mit MD5 `e040de91a74b61e3201db0e2323f768a` auf.

## Modell und Beleuchtung

- Original-FBX erneut eingelesen: 633 Quellvertices und alle 1.258 Dreiecke. UV-/Normalen-Trennungen ergeben 1.099 vorbereitete Vertices.
- Gelenkabstände aus dem Originalmodell; gleichmäßige Skalierung. Keine unterschiedlich gestreckten X-/Y-/Z-Achsen. Kanten innerhalb desselben Gliedes wurden gegen das Ausgangsmodell geprüft: 2047 Kanten, höchstens 1.256 N64-Einheiten Rundungsfehler.
- Knieringe und Schuhgewichte berichtigt. Zwei abgesetzte Schuhe des FBX wurden als starre Teile an die Hosenenden gesetzt. Die Form der Schuhe bleibt erhalten.
- Die stehende Referenzhöhe beträgt ungefähr 57,6 Spieleinheiten. Normale Auftritte verwenden eine zur eigenen Hüfthöhe passende temporäre Animationswurzel; der Reiter behält seinen Sattelpunkt. Die ursprüngliche Animationstabelle wird nach dem Zeichnen wiederhergestellt.
- Normalen wurden aus dem FBX transformiert, normalisiert und für N64-Beleuchtung quantisiert. Szenenlicht, Nebel, Deckkraft und ursprüngliche Opaque-/Translucent-Einstellungen bleiben wirksam.
- Objektgröße 70,224 Bytes, unter dem ursprünglichen Budget von 74.288 Bytes. 16 Skelettglieder, 15 Matrixplätze und 128×128-CI8-Textur. Kein zusätzlicher RAM-Modus.

## Binär- und Funktionsprüfung

Alle 1.509 regulären komprimierten Datenblöcke passen bytegenau zum unkomprimierten Neubau. Unveränderte Segmente sind identisch oder unterscheiden sich ausschließlich durch nachgewiesene ELF-Relokationen mit unveränderten Instruktionscodes. Beabsichtigt geändert sind Impas Modellobjekt, die drei visuellen Funktionen im Impa-Schauspieler, ausgewählte Kamera-Punkte in zwei Szenen, DMA-Verzeichnis und Header.

Die ursprünglichen Impa-Funktionen bleiben bis auf `DemoIm_DrawSolid`, `DemoIm_DrawTranslucent` und die bereits vorher geänderte visuelle Animationspause `func_80985EF4` unverändert. Originaler Produktionsstart ist durch Quelltextvergleich geprüft. Keine Änderungen an Inventar-, Item-, Alters-, Shop-, Kampf- oder Questfunktionen. Alle 182 deutschen Nachrichten sind erhalten und erneut gegen die Textpuffer geprüft.

Die drei Generatoren und der Build wurden erneut in der dokumentierten Reihenfolge ausgeführt: bytegenau dieselbe komprimierte ROM. RomPatcher.js wendet den BPS-Patch mit aktivierter Quellvalidierung an und rekonstruiert exakt dieselben 33.554.432 Bytes.

## Emulatorprüfung

Mupen64Plus 2.6.0, HLE-RSP, GLideN64 aus RMG 0.6.0. Aufnahmen sind unveränderte 640×480-Ingame-Bilder. Gezielte Szenen verwenden getrennte Test-ROMs; die Patch-Ausgabe hat den regulären Spielstart. Die konkreten Ergebnisse und Protokolle liegen unter `validation/bean-proportions/`.

Geprüfte Abläufe: normale Schloßhof-Unterhaltung, vollständige Notendemonstration und Liedeingabe über Controller-Tasten mit 4 und 8 MB, Liedbestätigung und Rückkehr ins Feld; Schatten-Medaillon und Rückkehr auf den Friedhof; Flucht zu Pferd, Schwarzweiß-Rückblende; Ein-/Ausblenden beim Versiegeln. Die tatsächliche RAM-Größe wird aus `osMemSize` gelesen. Der normale Produktionsstart wird mit 4 und 8 MB bis zur PAL-Sprachauswahl geprüft.

Bei zusätzlichen Menü-Eingabeversuchen wurden im verwendeten Headless-GL-Frontend einzelne fehlerhafte Bilder während Seitenwechseln beobachtet. Die Instruktionscodes der Dateiauswahl sind gegenüber der Ausgangsfassung unverändert; vier geänderte Wörter sind nachgewiesene Adreßrelokationen. Der abschließende Starttest bestätigt nur den normalen Start bis zur PAL-Sprachauswahl, keine fehlerfreie Wiedergabe aller Menü-Übergänge in diesem Frontend. Die gesonderten Szenenaufnahmen und die beschriebenen funktionalen Prüfungen werden hiervon getrennt bewertet; es wurde dafür kein Menü- oder Inventarcode verändert.

## Grenzen

Kein vollständiger Spieldurchlauf, kein Hörtest und kein Test auf echter N64-Hardware. Nicht jede Abspannkamera wurde einzeln abgespielt. Finger- und Gesichtsanimationen bleiben vereinfacht. Die bisherigen Berichte beziehen sich auf frühere Fassungen.

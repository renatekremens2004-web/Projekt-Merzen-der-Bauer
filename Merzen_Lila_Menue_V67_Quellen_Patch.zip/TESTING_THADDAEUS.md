# Thaddäus beim Tauchspiel

## Modellentscheidung

Alle sieben bereitgestellten Archive wurden geöffnet und untersucht. Party Blast: 775 Dreiecke, ohne Rig. Battle for Bikini Bottom: 2000 Dreiecke, ohne Rig. Punch: 3112 Dreiecke über zwei Teilmeshes, 33 Mixamo-Gelenke. Die Unity-Variante hat viele Teilmeshes und 33 Gelenke. Das SBU-FBX enthält In-between-Blendshapes, die der vorhandene Blender-Importer nicht unterstützt. Das bedeutet zusätzlichen Konvertierungsbedarf, keine generelle Unbrauchbarkeit.

Gewählt: SuperSponge-Modell mit **254 Dreiecken, ausschließlich starren Originalgewichten und 27 Gelenken**. Breathe und Idle passen zum selben Rig. Alle Dreiecke und Gelenke bleiben erhalten. Im Spiel wird der Idle-Clip verwendet; der Atemclip bleibt als vorbereitete Animationsquelle enthalten. Ein eigener 60-Frame-Armwurf ersetzt nur die visuelle Zora-Wurfanimation. Originale Schwelle bei Frame 15 und sämtliche Spieltimer bleiben gleich.

Knochenlängen und Körpermaße bleiben fest, Actor-Skalierung ist auf allen drei Achsen 0,01. Die Ruhegeometrie weicht durch Ganzzahlquantisierung höchstens 0,013 Welteinheiten ab. Sehr kleine Nicht-Wurzel-Verschiebungen aus den Quellclips werden nicht als Dehnung übernommen; Bericht: `tools/squid_rig_report.json`. Keine Übernahme von Zora-Fidget-Verformungen. Kopftracking begrenzt auf ±0x800 Winkelwerte. Texturen RGBA16, normale Szenenbeleuchtung und Nebel. Keine neue Detailstufe für 8 MB.

Die 27 Gelenke bilden eine wiederverwendbare Basis für spätere Auftritte und eigene Bewegungen. Das ist keine Zusage, daß beliebige fremde Animationen ohne Retargeting passen. Gesichts-/Mundanimation ist vereinfacht; geprüft werden in dieser Revision Ruhepose, Kopftracking und Wurf. Die hochaufwendigeren Modelle bleiben mögliche spätere Quellen, sind aber nicht Teil der Produktionsgeometrie.

## Isolation und Regeln

Die Original-Zora-Assets bleiben erhalten; zusätzliche Thaddäus-Daten hängen am gemeinsamen Objekt. Nur En_Diving_Game verwendet den neuen Rig. Er hat zwei 28-Eintrag-Posefelder; En_Ex_Ruppy wird wegen der angepaßten Struktur neu übersetzt. Sein Quellcode bleibt unverändert. Funktionale Tauchspiel-Funktionen sind nach Rücknahme der lokalen Text- und Animationsnamen bytegleich als normalisierter Quelltext. Nur Initialisierung und Zeichen-Callback enthalten zusätzliche visuelle Änderungen.

Zehn deutsche Nachrichten, insgesamt 422 bearbeitete Nachrichten. Private Plätze 0136, 0138 und 013B verwenden die nativen Kontrollfolgen von 71AD, 0085 und 002D. Der Generator akzeptiert solche Vorlagen nur in überprüft unbenutzten Retail-Textplätzen. Schießbude und andere Händler erhalten deshalb weder den Clown-Spruch noch Thaddäus' Absagen. 405A/START bleibt wegen gemeinsamer Verwendung mit Bowling unberührt. Andere Sprachtexte unverändert.

Einsatz 20 Rubine, Zeit 50 Sekunden, erst fünf und dann zehn Rubine, silberne Schuppe, Questflag und Tauch-Upgrade bleiben nativ. Junge Ruto, erwachsene Ruto und die übrigen Zora-Modelle sind nicht ersetzt.

## Prüfungen und Grenzen

Build, PAL-Prüfsumme, alle 1509 gepackten Segmente und deutsche Textpuffer geprüft. Gegen die vorherige Mario-/Luigi-Fassung dürfen nur deutsche Texte/Adressdaten, Objekt object_zo und die davon betroffenen Aktorsegmente abweichen. Normale Startsequenz und unveränderte Bean-Assets geprüft. RomPatcher.js wendet den BPS-Patch mit aktivierter Originalprüfung bytegenau auf Vanilla an.

Gezielte 4-MB-Prüfungen in Mupen64Plus/GLideN64. Test-ROMs starten als Kind direkt in Zoras Reich mit 99 beziehungsweise 0 Rubinen; für die Wiederholung wird der erhaltene-Schuppe-Zustand geladen. Spielerposition vor dem Gespräch ist eine Testhilfe. Im Siegestest werden Rubine an den Spieler gebracht; ihre nativen Abholfunktionen zählen sie, anschließend folgen native Siegtexte und Belohnung. Das ist kein Nachweis eines manuell ertauchten Sieges. Im Niederlagentest läuft die ursprüngliche Uhr ab. Screenshots sind unbearbeitete Emulatoraufnahmen.

Maschinelle Berichte und Szenarien unter `validation/thaddaeus/`; Bilder unter `previews/thaddaeus/`. Keine Test-ROM in den Downloads. Kein vollständiger Spieldurchlauf, keine echte N64-Hardware und keine noch nicht eingebauten künftigen Animationen geprüft.

# Goronen, Kakariko und Navis Meinungen

84 zusätzliche deutsche Nachrichten und drei überarbeitete bestehende Navi-Nachrichten; insgesamt 349 bearbeitete Nachrichten. Alte Rechtschreibung und native Spielernamen bleiben erhalten. Schauplätze, NPC-Plazierung, Modelle, Questregeln und Inventarlogik der Produktions-ROM werden nicht verändert. Merz' Kohleabbau ist die satirische Erklärung für den bereits im Original verschütteten Höhleneingang.

## Stimmen und Spielfortschritt

Der hungrige Gorone am Eingang spricht über Speisesteine und Vorurteile. Der Gorone auf der mittleren Plattform liebt Rockmusik, der vor Darunias Raum haßt sie. Der Gorone im Treppenbereich argumentiert ausführlich für Kernenergie: Energiedichte, Flächenbedarf, niedrige Lebenszyklus-Emissionen und wetterunabhängige Erzeugung; Bauzeit, Kosten, Kühlung und Entsorgung werden nicht unterschlagen. Ein Gorone am Gipfelweg hat sehr berechtigte Einwände gegen einen Badeurlaub. Hinweise auf Donnerblumen, das Armband, Sarias Musik und die Fee bleiben brauchbar.

In Kakariko erhalten der Mann mit dem Alternativ-Schnurrbart, der Dachbewohner, die Hühnerfrau, Boris, der Friedhofsjunge, Guru-Guru und weitere Nebenfiguren passende Reaktionen. Die Hühneraufgabe, Flasche, Maskenhandel des Jungen, Grabtour, Fanghaken und Hymne des Sturms behalten ihre ursprünglichen Auslöser und Belohnungen. Der Name des Goronenführers ist Darunia; Darmani ist eine andere Figur aus Majora's Mask.

Navis erreichbare Oberwelt-Hinweise äußern ihre Meinung zum jeweiligen Fortschritt und enthalten weiterhin Orientierung. Der neue Rückblick 0135 wird ausschließlich auf Deutsch als Kind angeboten, wenn der Goronen-Opal im Inventar ist und das native Hinweisskript 0148 oder 0149 auswählen würde. So erscheint er nach dem vollständigen Höhlen-Abschluß in der nächsten passenden C-oben-Gelegenheit, auch nach Erhalt der Magie. Er kann wie ein normaler Hinweis erneut abgerufen werden, bis die Handlung zur nächsten Hinweisphase fortschreitet. Andere Sprachfassungen und Erwachsene verwenden die native Auswahl. Der frühere Deku-Baum-Kommentar 0134 bleibt erhalten.

## Unveränderte Lesezeiten

Auf ausdrücklichen Wunsch des Nutzers werden die Pointen an die vorhandenen Textzeiten angepaßt. Darunia warnt im normalen Dialog 3068 vor zu heftigen Umarmungen. Während die Goronen heranstürmen, stehen in 3005/3006 kurze Warnrufe. Beide behalten exakt das ursprüngliche `FADE(30)`, ohne neues Schnelltext-Steuerzeichen. Keine Verzögerungswerte, Szenenzeiten, Noten- oder Animationsabläufe werden für diese Texte geändert. Der Generator verlangt die unveränderte funktionale Steuerzeichenfolge jedes Originaltexts; normale, manuell weitergeschaltete Gespräche dürfen zusätzliche Seiten erhalten.

## Prüfung

Alle 349 Nachrichten werden mit den PAL-Schriftbreiten, bis zu acht breiten Buchstaben im Spielernamen, den nativen Auswahlzeilen und beiden Textpuffern geprüft. Größte kompilierte Nachricht: 946 Bytes von 1.280; größte dekodierte Seite: höchstens 137 Bytes von 200.

`tools/verify_goronen_revision.py` vergleicht gegen die veröffentlichte Dialog-/Reiterfassung mit SHA256 `f139ee21cb57f63a0fb9ef80feb2fa1d1e8efa8f9bea8c5a350ceb2986334793`. Alle 1.509 komprimierten Blöcke werden gegen den unkomprimierten Build geprüft. Beabsichtigte Binäränderungen sind ausschließlich deutsche Nachrichten, der Code mit seiner Nachrichtentabelle und der erweiterten Navi-Auswahl, DMA-Verzeichnis und ROM-Header. Weitere geänderte Wörter müssen nachgewiesene Relokationen mit unveränderten Instruktionscodes sein. Insbesondere bleiben die Bean-Objektdaten und Kameras der Ausgangsfassung erhalten.

Gezielte 4-MB-Emulatorprüfungen und unveränderte Ingame-PNGs sind unter `validation/goronen-kakariko/` und `previews/goronen-kakariko/` dokumentiert. Die Teststarter verwenden separate Test-ROMs. Positionierung dient nur dem Erreichen der Gespräche und gehört nicht zum Produktionspatch. Für den Kernkraft-Goronen wird im Test der Spielereinstieg in denselben Bereich verlegt. Für Boris wird die Figur für die Aufnahme kurz vor dem Spieler positioniert; anschließend laufen seine eigentlichen Gesprächs- und Grabtourfunktionen. Es werden keine Nachrichten direkt injiziert. Sämtliche Teständerungen an Startfunktion und Szeneneinstieg werden vor dem Produktionsbuild wiederhergestellt.

Der Navi-Vergleich benutzt zwei ansonsten gleiche Spielstände: mit bereits besiegtem Höhlenboß, aber ohne Opal, bleibt es bei 0148; mit Opal erscheint 0135 vollständig. Der Darunia-Test startet direkt seine ursprüngliche Abschlußsequenz und prüft die Darstellung und Rückkehr zur Steuerung. Er prüft nicht den vorhergehenden Boßkampf oder die Steinvergabe: Der Original-Warp vergibt den Stein bereits vor dieser Sequenz; sein Code bleibt unverändert.

Kein vollständiger Spieldurchlauf oder Hardware-Test. Nicht alle NPC-/Questvarianten sind im Emulator durchgespielt; die strukturellen Kontrollen umfassen sämtliche bearbeiteten Texte. Erfolglos erreichte Testszenen werden nicht als bestandene Gesprächsprüfungen ausgegeben. Neue Screenshots stammen aus echten Emulator-Textboxen. Der BPS-Patch wird mit RomPatcher.js und aktivierter Quellenprüfung bytegenau gegen die Produktions-ROM geprüft.

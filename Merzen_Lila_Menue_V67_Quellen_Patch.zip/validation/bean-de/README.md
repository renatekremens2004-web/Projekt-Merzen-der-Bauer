# Nachweise zur Bean-Fassung

`bean-verification.json` enthält den ROM-Hash, Segmentvergleiche, zulässige Adreßrelokationen, Objektbudget und Textpufferprüfung. `story-layout.json` dokumentiert die Breiten aller 182 neuen Nachrichten. `generator-repro.log` stammt vom erneuten Ausführen des portablen Modellgenerators mit identischem Ergebnis.

Die Emulatorprotokolle gehören zu den in [TESTING.md](../../TESTING.md) beschriebenen Abläufen. `lesson-hero`, `lesson-hero4` und `sage-hero` verwenden die zuletzt erweiterten Bean-Dialoge; Modell, Tanz und Beleuchtung sind ebenfalls final. `normal-4` und `normal-8` verwenden die komprimierte Produktions-ROM. Die gezielten Szenen werden mit separaten Test-ROMs gestartet.

`bean_runner.c` und `build_fixtures.py` dokumentieren die Testeingaben und Startvoraussetzungen. Sie sind Werkzeuge aus dieser Cloud-Umgebung mit absoluten Pfaden, keine Bestandteile der veröffentlichten Spiel-ROM. Die originale Startfunktion wird nach dem Erstellen der Test-ROMs wiederhergestellt. `conversion-final.log` enthält die gebundenen Geometrie- und Tanzdaten.

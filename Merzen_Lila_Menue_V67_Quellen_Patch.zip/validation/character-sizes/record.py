from pathlib import Path
import re,json,subprocess,os,hashlib,sys
W=Path('/workspace/character-sizes');O=Path('/workspace/oot-burns-pal');topic=sys.argv[1];suffix=os.environ.get('RUN','v1');case='sizes-'+topic+'-'+suffix+'-record-direct-clip-on';syms=json.loads((W/'symbols.json').read_text());rom=O/'build/pal-1.0/oot-pal-1.0-compressed.z64'
assert topic in ['wallace-free-native','credits'];folder=Path('/workspace/bean-rider')/('screens-'+case);glob='*.png'if topic=='credits'else'*.ppm';before=set(folder.rglob(glob))if folder.exists()else set();sha=hashlib.sha256(rom.read_bytes()).hexdigest()
with(W/(topic+'-'+suffix+'.log')).open('w')as log:subprocess.run([str(W/'record_runner'),str(rom),case,'2400'if topic=='wallace-free-native'else'1500','4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
log=(W/(topic+'-'+suffix+'.log')).read_text();m=re.search(r'VIDEO_END first=(\d+) last_exclusive=(\d+) frames=(\d+) transition=(\d+)',log);assert m and 'completed: 0'in log,topic
first,end,count,transition=map(int,m.groups());frames=sorted(set(folder.rglob(glob))-before);assert len(frames)==count==end-first and transition>first
frames.sort(key=lambda p:p.stat().st_mtime_ns);assert len({p.stat().st_mtime_ns for p in frames})==count;
encode=W/('encode-'+case);encode.mkdir(exist_ok=True);extension='png'if topic=='credits'else'ppm'
for i,p in enumerate(frames):
 link=encode/f'frame-{i:05d}.{extension}'
 if link.exists():link.unlink()
 link.symlink_to(p)
assert not any(x in log for x in ['OBJECT_BANK_OVERFLOW','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
if topic=='credits':assert re.search(r'FIVE_SAGES.*scene=60 RAM=4194304 a8=80[0-9a-f]+ c9=80[0-9a-f]+ d2=80[0-9a-f]+ c3=80[0-9a-f]+ a9=80[0-9a-f]+',log)
else:assert 'sawTalk=1 sawEscape=1'in log and re.search(r'FREE_STAGE .*state=2 .*switch=00000008',log)
name='Wallace_Kleiner_Befreiung.mp4'if topic!='credits'else'Wallace_Kleiner_Weise_Credits.mp4';out=Path('/workspace/artifacts')/name
subprocess.run(['ffmpeg','-y','-v','error','-framerate','50/3','-start_number','0','-i',str(encode/('frame-%05d.'+extension)),'-frames:v',str(count),'-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(out)],check=True)
meta=dict(rom_sha256=sha,case=case,first_frame=first,last_frame_exclusive=end,frames=count,transition_frame=transition,pal_frames_per_second='50/3',duration_seconds=count*3/50,silent=True,continuous_unedited_native_gameplay=True,controller_input=topic!='credits',native_actor_positions=True,ram_bytes=4194304,screenshot_start_index=0,screenshot_folder=str(encode),capture_files=[str(p.relative_to(folder))for p in frames],source_capture_folder=str(folder),mp4=name,mp4_sha256=hashlib.sha256(out.read_bytes()).hexdigest());(W/(topic+'-'+suffix+'.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n');print('Recorded',topic,count,'frames',meta['duration_seconds'],'seconds',sha,flush=True)

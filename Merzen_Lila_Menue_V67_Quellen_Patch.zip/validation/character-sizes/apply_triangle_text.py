from pathlib import Path
import sys,json
R=Path('/workspace/Projekt-Merzen-der-Bauer'); O=Path('/workspace/oot-burns-pal')
sys.path.insert(0,str(R/'tools'))
from build_story import messages,rewrite,Layout
p=R/'story/fundstuecke_de.json'; data=json.loads(p.read_text()); entry=data['messages']['608A']
entry['pages']=entry['pages'][:1]+['Ich bin das Triforce des Mutes und ich bin da für dich,\n{name}!', 'Laß uns Friedrich Merz verbannen, der auch irgendwie an ein Stück des Triforces gekommen ist!', 'Hat er sich wohl gekauft!\nAber ich bin nicht käuflich!']
p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
p=O/'extracted/pal-1.0/text/message_data.h'; source=p.read_text(); parsed=messages(source);a,b,body=parsed['608A']['parts'][2]
template=messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text())['0022']['parts'][2][2]
new,report=rewrite(template,entry,Layout(O),'608A'); p.write_text(source[:a]+new+source[b:]);print(report)

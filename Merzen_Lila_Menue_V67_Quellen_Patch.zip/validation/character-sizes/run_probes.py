from pathlib import Path
import subprocess,os,hashlib,json
W=Path('/workspace/character-sizes');rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64');s=json.loads((W/'symbols.json').read_text())
for topic,limit in [('blue',650),('hall',900)]:
 case='sizes-'+topic+'-v2-direct-clip-on';(W/(case+'.json')).write_text(json.dumps(dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),fixture=topic,frame_limit=limit,ram_bytes=4194304,native_actor_positions=True),indent=2)+'\n')
 with(W/(case+'.log')).open('w')as log:subprocess.run([str(W/'runner'),str(rom),case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)

from pathlib import Path
import json,hashlib,re,shutil,zipfile,subprocess
W=Path('/workspace/character-sizes');R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts');P=R/'previews/character-sizes';V=R/'validation/character-sizes';P.mkdir(parents=True,exist_ok=True);V.mkdir(parents=True,exist_ok=True)
for directory in [P,V]:
 for old in directory.iterdir():
  if old.is_file():old.unlink()
sha=hashlib.sha256((O/'build/pal-1.0/oot-pal-1.0-compressed.z64').read_bytes()).hexdigest();report=json.loads((O/'build/pal-1.0/character-sizes-verification.json').read_text());assert report['rom_sha256']==sha==json.loads((W/'patch-verification.json').read_text())['target_sha256']
records={};logs={}
for topic,run in [('credits','v2'),('wallace-free-native','v6')]:
 name=topic+'-'+run;meta=json.loads((W/(name+'.json')).read_text());log=(W/(name+'.log')).read_text();assert meta['rom_sha256']==sha and meta['ram_bytes']==4194304 and 'completed: 0'in log
 assert not any(x in log for x in ['OBJECT_BANK_OVERFLOW','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 mp4=A/meta['mp4'];assert hashlib.sha256(mp4.read_bytes()).hexdigest()==meta['mp4_sha256'];probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height,nb_frames,avg_frame_rate','-of','json',str(mp4)],text=True))['streams'][0];assert probe['codec_name']=='h264'and int(probe['nb_frames'])==meta['frames']and probe['avg_frame_rate']=='50/3';records[topic]=meta;logs[topic]=log
 for ext in ['.json','.log']:shutil.copyfile(W/(name+ext),V/(name+ext))
 shutil.copyfile(mp4,P/mp4.name)
for topic,ident in [('blue','608e'),('hall','303c')]:
 case='sizes-'+topic+'-v2-direct-clip-on';meta=json.loads((W/(case+'.json')).read_text());log=(W/(case+'.log')).read_text();assert meta['rom_sha256']==sha and 'completed: 0'in log and 'id='+ident in log and 'RAM=4194304'in log
 for ext in ['.json','.log']:shutil.copyfile(W/(case+ext),V/(case+ext))
for name in ['apply_triangle_text.py','prepare_runtime.py','record.py','record_runner.c','record_input.c','run_probes.py','runner.c','package.py','check_patch.js','patch-verification.json','verification.log','seat.log','generate.log']:
 shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/character-sizes-verification.json',V/'character-sizes-verification.json')
manifest=[]
def movie_photo(topic,index,dest):
 meta=records[topic];p=Path(meta['screenshot_folder']);source=p/f'frame-{index:05d}.{"ppm"if topic=="wallace-free-native"else"png"}'
 if source.suffix=='.ppm':
  from PIL import Image
  im=Image.open(source).convert('RGB');im.save(P/dest);assert im.tobytes()==Image.open(P/dest).convert('RGB').tobytes()
 else:shutil.copyfile(source,P/dest)
 manifest.append(dict(file=dest,case=meta['case'],frame=meta['first_frame']+index,rom_sha256=sha,unedited_emulator_image=True))
movie_photo('credits',190,'Weisen_Gruppe_neuer_Sitz.png');movie_photo('credits',390,'Schultersitz_Seitenansicht.png');movie_photo('wallace-free-native',294,'Wallace_Zelle_Groessenvergleich.png');movie_photo('wallace-free-native',1030,'Wallace_Flucht.png')
case='sizes-blue-v2-direct-clip-on';shutil.copyfile(Path('/workspace/bean-rider')/('screens-'+case)/'the_legend_of_zelda-001.png',P/'Wawaluigi_Kleiner.png');manifest.append(dict(file='Wawaluigi_Kleiner.png',case=case,rom_sha256=sha,unedited_emulator_image=True));(P/'Aufnahmen.json').write_text(json.dumps(manifest,indent=2)+'\n')
free=records['wallace-free-native'];credits=records['credits'];doc=f'''# Kleinere Figuren: Wawaluigi und Zukunfts-Wallace

Kumulativer Gesamtpatch auf die unveränderte Europa/PAL-1.0-ROM, Original-MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{sha}`. Alle bisherigen Änderungen enthalten. ROM-Datei weiterhin 40 MiB; alle neuen Proben mit tatsächlichen 4 MiB N64-RAM.

## Größen und Sitz

Der BLAUE Wawaluigi neben dem Zelt im erwachsenen Gerudotal ist von 125 auf 100 Spieleinheiten verkleinert (20 Prozent). Er bleibt lang und größer als der erwachsene Spieler. Gleichmäßige Änderung aller drei Achsen und seiner vier Schulter-/Kopfpunkte; kein Strecken. 1.251 Dreiecke, Texturen und Bewegung erhalten. Gesprächsfokus und Zylinderhöhe von 100 auf 80 angepaßt. Orange Wawario, normaler Wario und der Waluigi im Geistertempel bleiben unverändert.

Zukunfts-Wallace im Feuertempel und als Feuerweiser ist von 110 auf 90 Spieleinheiten verkleinert (rund 18 Prozent). Das entspricht der Höhe seines unveränderten 90-Einheiten-Modells in Dodongos Höhle. Beide Zeitmodelle behalten ihre eigenen Formen. 2.269 Dreiecke, Texturen, Normalen und vier Körperteile des Erwachsenenmodells bleiben erhalten; nur Positionen und feste Drehpunkte werden einheitlich skaliert. Seine Gesprächshöhe liegt jetzt bei 81, der Kollisionszylinder ist 86 hoch und hat Radius 15. Native Zell-, Schalter-, Gesprächs-, Belohnungs- und Fluchtlogik bleiben erhalten. Ausschließlich Wallaces private Fluchtkamera steht weiter zurück (horizontaler Abstand ×1,9, Blickhöhe 48, Augenhöhe 40 Spieleinheiten), damit beim Loslaufen auch sein Kopf im Bild bleibt. Andere Gefangene und die Zeitpunkte des Fluchtablaufs sind davon nicht betroffen. Derselbe kleinere Wallace gilt in der Halle der Weisen, bei den späteren Siegeln und in den Credits. Darunias frühere Auftritte bleiben unverändert.

Die Krabbelminenfrau behält Körpergröße, Knochenlängen und alle Bewegungen außerhalb ihrer drei Sitzanimationen. Ihre Sitzwurzel ist nun {report['seat']['root_model_units']} Modelleinheiten, relativ zu Wallace {report['seat']['seat_root_relative_to_wallace_game_units']} Spieleinheiten. Der native Akteursabstand +1/+2,25/−9 ist berücksichtigt. Die Oberschenkel liegen etwas enger um die schmaleren Schultern, die Unterschenkel hängen weiterhin fast senkrecht. Die Credits-Kameras, Cues, Zeitpunkte und Abspannszenen bleiben unverändert.

## MP4-Dateien

- `{free['mp4']}`: {free['frames']} fortlaufende gerenderte Bilder, {free['duration_seconds']:.2f} Sekunden. Beginn neben dem noch geschlossenen Käfig. Normale Controller-Eingaben betreten den nativen Bodenschalter, öffnen die Zelle, führen zum Gespräch und lesen alle Seiten. Wallace läuft danach selbständig über den bisherigen Weg aus der Zelle und verschwindet regulär. Keine Schalter-/Akteurspositionen während der Aufnahme in RAM geschrieben. Nur der lokale Ausgangsspielstand ist vorbereitet.
- `{credits['mp4']}`: {credits['frames']} fortlaufende gerenderte Bilder, {credits['duration_seconds']:.2f} Sekunden. Alle fünf nativen Rollen gemeinsam: Wallace, Krabbelminenfrau, Thaddäus, Waluigi und Mr. Bean. Ohne Controller-Eingaben, mit nativem Übergang in die nächste Abspannszene. Rauru/Habeck gehört im Original nicht zu dieser gemeinsamen Todesberg-Einstellung.

Beide Videos: 640×480, H.264, PAL 50/3 Bilder pro Sekunde, ohne Ton. Keine Montage, keine ausgetauschten Bilder und keine für die Vorschau versetzten NPCs oder Kameras. Der lange Befreiungsclip liest jedes gerenderte Bild über die unveränderte native READ_SCREEN-API als RGB aus. Damit wird die 1.000-Dateien-Grenze des Screenshotzählers umgangen. Reihenfolge, vollständige Framezahl und MP4-Framezahl werden geprüft; die Standbilder werden ohne Pixeländerung in PNG umgewandelt. Keine beschleunigte Wiedergabe und keine ausgelassenen Dialogseiten.

## Prüfung

Beide Videos auf genau der oben genannten finalen ROM aufgenommen. Zusätzlich normale Gespräche mit Wawaluigi beim Zelt und eine Kameraprobe in Wallaces Feuerweisen-Szene bis zur zweiten Rede. Keine beobachteten Abstürze oder fehlerhaften Grafikbefehle. Der gemeinsame Abspann benötigt dieselben Objekt-Slots wie zuvor und hat unveränderten Objektpuffer; weiterhin mindestens 15.440 Bytes frei. Die Befreiung erreicht die nativen Zustände 0, 2 und 4, danach ist der Gefangene regulär entfernt. Die Hallenprobe ist keine vollständige erneute Amulett-Questprüfung.

Alle 1.509 komprimierten Segmente gegen den unkomprimierten Neubau und die CIC-6105-Prüfsumme geprüft. Nur Triangle Guys deutsche Nachricht 608A erhält vier manuell weitergeschaltete Seiten: seine bisherige Begrüßung und den neuen Triforce-des-Mutes-Text, mit echtem Spielernamen und „Laß uns“. Alle anderen Nachrichten sowie alle englischen und französischen Texte sind bytegleich erhalten. Weiterhin 1.013 eigene Nachrichten. 2.955 Kernfunktionen, 96 Goronenfunktionen, 94 Feuerweisenfunktionen und 74 Waldweisenfunktionen erhalten; beabsichtigte Fokus-/Größenwerte und die auf Wallace beschränkte Fluchtkamera separat im Quelltext geprüft. Native Raum-/Objektdaten erhalten: Gerudotal 119 Symbole, Feuertempel-Raum 5 28, Darunia-Objekt 141, Salia-Objekt 184. Andere Figuren, Räume, Gegner, Kampfanpassungen, Stiefelumschaltung und Questabläufe unverändert bzw. nur mit echten MIPS-Linker-Relokationen verschoben. Das letzte korrigierte Punk-Modell ist enthalten.

RomPatcher.js mit aktiver Quellvalidierung erzeugt aus Vanilla und BPS bytegenau die getestete Produktions-ROM. Ein vollständiger normaler Durchlauf und echte N64-Hardware stehen weiterhin aus. Veröffentlicht werden Patch, Quellen, Videos, Bilder und Protokolle; keine ROMs, Spielstände, Emulatorzustände oder ausführbaren Dateien.
'''
(R/'TESTING_CHARACTER_SIZES.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Wallace_Wawaluigi_Groessen.bps';shutil.copyfile(patch,R/'patches'/patch.name)
instruction=A/'Anleitung_Wallace_Wawaluigi_Groessen.txt';instruction.write_text('Kleinere Figuren und angepaßter Schultersitz — kumulativer Gesamtpatch\n\nAuf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden, nicht auf eine alte Mod-ROM. Original-MD5 e040de91a74b61e3201db0e2323f768a. https://www.marcrobledo.com/RomPatcher.js/\n\nAlle bisherigen Änderungen enthalten. Blauer Wawaluigi beim Gerudo-Zelt 20 Prozent kleiner. Zukunfts-Wallace rund 18 Prozent kleiner; Sitz der Krabbelminenfrau in den Credits angepaßt. Triangle Guy erhält zusätzlich den Triforce-des-Mutes-Dialog mit Deinem Spielernamen. Beide Videos sind echte Emulatoraufnahmen ohne Ton mit 4 MiB N64-RAM.\n\nNormale Spielstände laden; alte Emulator-Save-States enthalten unter Umständen noch den früheren Modellstand im RAM.\n')
heading='# Kleinere Figuren: Wawaluigi und Zukunfts-Wallace';p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Befreiung und Credits als MP4](previews/character-sizes/) · [Prüfbericht](TESTING_CHARACTER_SIZES.md)\n\nAlle bisherigen Änderungen enthalten. `build_character_sizes.py` folgt zuletzt auf `build_yellow_guy.py`; vorbereitete Modelldaten und Sitzanimationen sind enthalten.\n\n'+p.read_text())
images=A/'Wallace_Wawaluigi_Groessen_Bilder.zip'
with zipfile.ZipFile(images,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.iterdir()):
  if p.suffix!='.mp4':z.write(p,p.name)
archive=A/'Merzen_Wallace_Wawaluigi_Groessen_Quellen_Patch_Videos.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl','.mp4'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R)
  allowed_sizes_source = rel.parts[:3]==('tools','originals','character_sizes') and p.suffix=='.c'
  if not p.is_file()or (any(x in exclude for x in rel.parts)and not allowed_sizes_source)or p.suffix.lower()not in suffixes:continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='character-sizes':continue
  with p.open('rb')as f:assert f.read(4)not in [bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None and not any(Path(x).suffix.lower()in{'.rom','.z64','.n64','.v64','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st'}for x in z.namelist())
files=[patch,images,archive,instruction]+[A/records[t]['mp4']for t in ['wallace-free-native','credits']];sums=A/'SHA256SUMS_Wallace_Wawaluigi_Groessen.txt';sums.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n'for p in files))
for p in files+[sums]:shutil.copyfile(p,D/p.name)
G=D/'Wallace_Wawaluigi_Groessen_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():
 if p.suffix!='.mp4':shutil.copyfile(p,G/p.name)
heading='# Merzen der Bauer: kleinere Figuren und neuer Schultersitz';p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Aktueller Gesamtpatch]('+patch.name+'?raw=true) · [Wallaces Befreiung als MP4]('+free['mp4']+'?raw=true) · [Weisen-Credits als MP4]('+credits['mp4']+'?raw=true)\n\n[Quellen und Prüfungen]('+archive.name+'?raw=true) · [Bilder]('+images.name+'?raw=true) · [Prüfbericht](Wallace_Wawaluigi_Groessen_Beispielbilder/Pruefbericht.md)\n\nBlauer Wawaluigi 125 → 100, Zukunfts-Wallace 110 → 90 Spieleinheiten. Schultersitz der Krabbelminenfrau angepaßt. Alle bisherigen Änderungen enthalten; auf unveränderte Europa/PAL-1.0-ROM anwenden. Videos mit 4 MiB aufgenommen, ohne Ton.\n\n'+p.read_text())
print('Packaged',sha,'source archive bytes',archive.stat().st_size,'free seconds',free['duration_seconds'],'credits seconds',credits['duration_seconds'])

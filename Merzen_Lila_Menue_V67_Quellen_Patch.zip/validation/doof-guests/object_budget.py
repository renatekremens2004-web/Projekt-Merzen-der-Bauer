from pathlib import Path
import re,json
O=Path('/workspace/oot-burns-pal');W=Path('/workspace/doof-guests');s=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();symbols={n:int(a,16)for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',s)};objects={obj:name for name,obj in re.findall(r'DEFINE_OBJECT\((\w+), (\w+)\)',(O/'include/tables/object_table.h').read_text())}
def size(key):n=objects[key];return symbols['_'+n+'SegmentRomEnd']-symbols['_'+n+'SegmentRomStart']
rows=[]
for name,typ,sc,room,fragments,link,extra in [('child fishing','misc','turibori',0,['03000040'],'OBJECT_LINK_CHILD',None),('adult fishing','misc','turibori',0,[],'OBJECT_LINK_BOY',['OBJECT_FISH','OBJECT_KANBAN','OBJECT_DOOFEVIL']),('Shrek','overworld','spot10',3,['03000058'],'OBJECT_LINK_CHILD',None),('Monopoly','dungeons','ganontika',1,['03000040'],'OBJECT_LINK_BOY',None)]:
 D=O/f'extracted/pal-1.0/assets/scenes/{typ}/{sc}';keep='OBJECT_GAMEPLAY_DANGEON_KEEP'if typ=='dungeons'else'OBJECT_GAMEPLAY_FIELD_KEEP';os=['OBJECT_GAMEPLAY_KEEP',keep,link]
 if extra:os+=extra
 else:
  for frag in fragments:os+=re.findall(r'\bOBJECT_\w+',next(D.glob(f'{sc}_room_{room}_*{frag}_ObjectList.inc.c')).read_text())
 total=sum((size(o)+15)//16*16 for o in os);assert total<=1019904 and len(os)<=19,(name,total,len(os));rows.append(dict(case=name,bytes=total,slots=len(os),objects=os,unused_variant_loaded=False if sc=='turibori'else None))
report=dict(native_capacity=1019904,rooms=rows,models={k:dict(bytes=size('OBJECT_'+k.upper()))for k in['doof','doofevil','shrek','monopoly']});(W/'object-budget.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

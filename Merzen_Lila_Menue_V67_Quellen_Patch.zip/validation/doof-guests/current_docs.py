from pathlib import Path
import json

R = Path('/workspace/Projekt-Merzen-der-Bauer')
W = Path('/workspace/doof-guests')
D = Path('/workspace/bean-download-delivery')
A = Path('/workspace/artifacts')
entries = json.loads((R / 'story/doof_guests_de.json').read_text())['messages']
mapping = json.loads((R / 'tools/doof_guest_text_map.json').read_text())
inactive = {'4087', '4097', '40B2', '71D0'}
text = [
    '# Doofenshmirtz, Shrek und Mr. Monopoly', '',
    'Eingebaute deutsche Dialoge in alter Rechtschreibung. Absätze entsprechen den weiterklickbaren Textseiten. [Spielername] und [Fischgewicht] werden im Spiel eingesetzt. Preise, Angelsteuerung, Rekorde und Belohnungen bleiben nativ. Doofenshmirtz trägt keine Mütze; der alte Mützenklau ist in der deutschen Fassung abgeschaltet.', '',
    '## Doofenshmirtz als Kind', '',
]

def append(ident, label):
    e = entries[ident]
    text.extend(['### ' + ident + ' — ' + label, ''])
    for page in e['pages']:
        text.extend([page.replace('{name}', '[Spielername]').replace('{fish}', '[Fischgewicht]'), ''])
    if e.get('choices'):
        text.extend(['Antworten: ' + ' / '.join(e['choices']), ''])

adult_only = {'4093', '4094', '4095'}
for ident, e in entries.items():
    if not e.get('new_message') and ident not in inactive and ident not in adult_only:
        append(ident, 'ursprünglicher Angel-Dialogplatz')
text.extend(['## Doofenshmirtz als Erwachsener', '',
             'Die ernstere Augenklappen-Version nutzt eigene altersabhängige Texte. Der Wiedersehensdialog 4093 folgt der nativen Bedingung, daß bereits als Kind geangelt wurde. Die gemeinsame Absage 002D und sonstige nicht ersetzte Spielmeldungen bleiben erhalten.', ''])
for native, adult in mapping.items():
    if len(native) == 4 and adult not in inactive:
        append(adult, 'erwachsene Variante von ' + native)
for ident in sorted(adult_only):
    append(ident, 'nativer Erwachsenen-Dialogplatz')
text.extend(['## Shrek — Kindheitszeit, Verlorene Wälder', ''])
append(mapping['shrek'], 'eigener NPC am trockenen Ufer im Waldraum mit dem Wasserbecken')
text.extend(['## Mr. Monopoly — Erwachsenenzeit, Merz’ Schloß', ''])
append(mapping['monopoly'], 'eigener NPC seitlich der Haupthalle')
text.extend(['## Unbenutzte Alttexte', '',
             '4087, 4097, 40B2 und die private Variante 71D0 bleiben als Tabellenplätze erhalten, werden durch den abgeschalteten deutschen Mützenklau jedoch nicht mehr regulär ausgelöst.', ''])
name = 'Dialoge_Doof_Shrek_Monopoly.md'
for p in [R / 'planning' / name, D / name, A / name]:
    p.write_text('\n'.join(text).rstrip() + '\n')
p = R / 'story/LEITLINIEN.md'
s = p.read_text()
marker = '## Doofenshmirtz, Shrek und Mr. Monopoly'
if marker not in s:
    s += '''

## Doofenshmirtz, Shrek und Mr. Monopoly

Der originale Angelteich-Betreiber bleibt der funktionale Fishing-Akteur. Deutsche Darstellung als Kind: normaler Doofenshmirtz mit Kindheitskränkungen, Jauchegruben und Angelinator. Als Erwachsener: ernstere, gefährlichere Augenklappen-Version mit zusammenhängender Kritik an Merz’ sozialer und ökologischer Politik. Die beiden Modelle werden über native altersabhängige Raumheader getrennt geladen. Preise, Fischbestand, Fangsteuerung, Rekorde, Belohnungen und feste Lesezeiten bleiben erhalten.

Ausdrücklicher Nutzer-Nachtrag: keine Angelmütze nötig. Kein Mützenmodell rendern; in der deutschen Fassung den ursprünglichen Mützenklau durch den normalen Haarzustand abschalten. Damit kann kein unsichtbares Zubehör am Haken landen. Bestehende Rekordbits nicht löschen. Englisch/Französisch behalten den nativen Angler und sein Mützensystem.

Shrek steht nur als Kind am trockenen Ufer in Raum 3 der Verlorenen Wälder. Mr. Monopoly steht nur als Erwachsener seitlich in Raum 1 des letzten Schlosses und hält sein Plädoyer für Kapitalismus und die bleibende menschliche Gier. Beide haben ansprechbare, kollidierende NPCs mit eigenen unverzerrten Proportionen, entspannten Armen und kleinen Kopf-/Handbewegungen. Keine Gegner- oder Questfunktionen. Native Wege und Türen bleiben frei.

374/564/442/900 Dreiecke; alle vier Objektsegmente getrennt. Bei Monopoly nur den Körper vereinfachen, die 400 ursprünglichen Kopf-/Gesichtsdreiecke erhalten. Echte 4-MiB-Proben und unveränderte Speicherpools. Insgesamt 1.154 eigene deutsche Nachrichten einschließlich reservierter, nicht mehr erreichbarer Mützenzeilen. Letzte Builder: build_desert_guests.py, build_gerudo_dialogue.py, build_twinrova_title.py, build_doof_guests.py.
'''
    p.write_text(s)
print('Exported active dialogue and documented the removed cap sidequest.')

from pathlib import Path
import re,json,subprocess
W=Path('/workspace/debug-version');O=Path('/workspace/oot-burns-pal')
syms={}
for a,n in re.findall(r'0x([0-9a-f]+)\s+([A-Za-z_]\w*)\b',(O/'build/pal-1.0/oot-pal-1.0.map').read_text()):syms.setdefault(n,int(a,16))
(W/'symbols.json').write_text(json.dumps(syms))
base=Path('/workspace/shadow-tunic/runner.c').read_text()
head=base[:base.index('static void scan(void)')]
head=head.replace('static uint32_t savebase=0x80118450, overlays=0x800e6500;',f'static uint32_t savebase={hex(syms["gSaveContext"])}, overlays={hex(syms["gActorOverlayTable"])};')
head+=f'\n#define GAME_TABLE {hex(syms["gGameStateOverlayTable"])}\n#define ARENA {hex(syms["sZeldaArena"])}\n#define OBJECT_TABLE {hex(syms["gObjectTable"])}\n'
body=r'''
static uint32_t play,mapstate;
static int valid(uint32_t a){return a>=0x80100000 && a<0x80400000;}
static uint32_t statefor(int entry,uint32_t prev){
 uint32_t target=r32(GAME_TABLE+entry*0x30+0x1c);
 if(target<0x80000000 || target>=0x80400000)return 0;
 if(valid(prev)&&r32(prev+8)==target&&r32(prev+0x98)==1)return prev;
 for(uint32_t a=0x80120000;a<0x80400000-0x240;a+=4){
  if(r32(a+8)==target&&r32(a+0x98)==1&&valid(r32(a))){
   if(entry==1 && r32(a+0x1d0)!=116)continue;
   return a;
  }
 }
 return 0;
}
static void shot(const char* name,unsigned f){printf("SHOT %s f=%u\n",name,f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
static void audit(unsigned f,uint32_t state){
 if(r32(0x80000318)!=4194304){puts("BAD_RAM_SIZE");exit(94);}
 uint32_t total=0,largest=0;for(uint32_t n=r32(ARENA),k=0;valid(n)&&k<1000;n=r32(n+8),k++)if(DebugMemRead16(n+2)){uint32_t z=r32(n+4);total+=z;if(z>largest)largest=z;}
 printf("HEAP f=%u free=%u largest=%u failures=%u RAM=%u\n",f,total,largest,DebugMemRead8(ARENA+12),r32(0x80000318));
 uint32_t gfx=r32(state);
 for(int k=0;k<4;k++){unsigned off[]={0x2b8,0x2c8,0x2a8,0x1b4};uint32_t ctx=gfx+off[k],size=r32(ctx),h=r32(ctx+8),t=r32(ctx+12);if(size&&(h>t||t-h>size)){puts("GFX_OVERFLOW");exit(94);}}
 if(state==play&&r32(savebase+0x135c)==0){
  uint32_t ctx=play+0x117a4,begin=r32(ctx),end=r32(ctx+4),last=begin;int entries=DebugMemRead8(ctx+8);
  for(int i=0;i<entries&&i<19;i++){uint32_t slot=ctx+12+i*0x44;int id=(int16_t)DebugMemRead16(slot);if(id<0)id=-id;if(id>0&&id<0x1a1){uint32_t e=r32(slot+4)+r32(OBJECT_TABLE+id*8+4)-r32(OBJECT_TABLE+id*8);if(e>last)last=e;}}
  printf("OBJECT_BANK f=%u entries=%d remaining=%d\n",f,entries,(int)(end-last));if(last>end){puts("OBJECT_OVERFLOW");exit(94);}
 }
}
static void iconcheck(unsigned f){
 uint32_t pixels=r32(play+0x10760+0x128);if(!valid(pixels))return;
 for(unsigned item=0x41;item<=0x43;item++){
  unsigned colored=0,red=0,blue=0,lightblue=0,orange=0,max=0,alpha=0;
  for(unsigned i=0;i<1024;i++){uint32_t p=pixels+item*4096+i*4;unsigned r=DebugMemRead8(p),g=DebugMemRead8(p+1),b=DebugMemRead8(p+2),a=DebugMemRead8(p+3);if(!a)continue;alpha++;if(r!=g||g!=b)colored++;if(r>max)max=r;if(g>max)max=g;if(b>max)max=b;if(r>g&&r>b)red++;if(b>r&&b>g)blue++;if(b>g&&g>r&&r*3>=b)lightblue++;if(r>g&&g>b&&g*2>=r-1)orange++;}
  printf("ICON f=%u item=%02x colored=%u red=%u blue=%u lightblue=%u orange=%u max=%u alpha=%u\n",f,item,colored,red,blue,lightblue,orange,max,alpha);
 }
}
static void onframe(unsigned f){
 alarm(30);
 if(f<200){if(buttons)buttons(0);return;}
 if(f%10==0){mapstate=statefor(1,mapstate);play=mapstate?0:statefor(3,play);}
 unsigned value=0;
 static unsigned phase=0,pf=0,next=0,open=0,paid=0,mapcount=0;
 unsigned pause=play?DebugMemRead16(play+0x10760+0x1d4):0,editor=play?DebugMemRead16(play+0x10760+0x1d6):0;
 unsigned scene=play?DebugMemRead16(play+0xa4):0xffff,gameMode=r32(savebase+0x135c);
 unsigned current=mapstate?r32(mapstate+0x1d8):999;
 if(f%50==0){printf("DEBUG f=%u phase=%u play=%08x map=%08x entry=%u age=%u mode=%u scene=%x pause=%u editor=%u equip=%04x rupees=%d file=%u\n",f,phase,play,mapstate,current,r32(savebase+4),gameMode,scene,pause,editor,DebugMemRead16(savebase+0x70),(int16_t)DebugMemRead16(savebase+0x34),r32(savebase+0x1354));if(mapstate||play)audit(f,mapstate?mapstate:play);}
 if(strstr(scenario,"sram-load") && phase==0){
  if(play&&gameMode==0&&r32(savebase+0x1354)<3&&f>400){
   printf("NATIVE_SRAM_LOADED f=%u file=%u shadow=%04x equip=%04x\n",f,r32(savebase+0x1354),DebugMemRead16(savebase+0xf30),DebugMemRead16(savebase+0x70));
   shot("Schattengewand_Spielstand",f);phase=8;pf=f;
  }else {value=f>250&&f%50<6?0x10:(f>250&&f%50>=20&&f%50<26?0x80:0);if(buttons)buttons(value);if(f>=(unsigned)limit)CoreDoCommand(M64CMD_STOP,0,NULL);return;}
 }
 switch(phase){
 case 0:
  if(play&&f>350){if(!pf)pf=f;unsigned d=f-pf;value=d<8?0x3000:(d<16?0x3020:0);if(mapstate){phase=1;pf=f;next=f+50;mapcount++;shot("Szenenauswahl",f);}}
  if(mapstate){phase=1;pf=f;next=f+50;mapcount++;shot("Szenenauswahl",f);}break;
 case 1:
  if(mapstate&&f>next){if(!strstr(scenario,"adult-start") && r32(savebase+4)!=1){value=0x40;next=f+35;}else if(current!=1){value=4;next=f+30;}else{value=0x80;phase=2;pf=f;}}
  break;
 case 2:
  if(play&&gameMode==0&&f>pf+130){shot("Kakariko_Debug_Start",f);printf("ENTERED_START age=%u equip=%04x\n",r32(savebase+4),DebugMemRead16(savebase+0x70));phase=3;pf=f;}
  break;
 case 3:
  if(pause==0&&f>pf+15&&f%30<6)value=0x10;
  if(pause==6){phase=4;pf=f;}
  break;
 case 4:
  if(f>pf+25&&f<pf+32)value=0x2000;
  if(editor==2){phase=5;pf=f;next=f+30;shot("Inventar_Editor",f);}
  break;
 case 5:
  if(f>next&&f<next+6)value=8;
  if(f>next+30&&f<next+36)value=4;
  if(f>next+60&&f<next+66)value=0x100;
  if(f==next+90){paid=DebugMemRead16(savebase+0x34);printf("EDITOR_ROW_WRAP_AND_RUPEE_RESULT rupees=%u\n",paid);shot("Inventar_geaendert",f);}
  if(f>next+105&&f<next+111)value=0x2000;
  if(f>next+120&&editor==0){phase=6;pf=f;next=f+25;}
  break;
 case 6:
  if(pause==6&&f>next){unsigned page=DebugMemRead16(play+0x10760+0x1e8),main=DebugMemRead16(play+0x10760+0x1e4);if(main==0){if(page!=3){value=0x20;next=f+45;}else{shot("Gewaender_Icons",f);iconcheck(f);phase=7;pf=f;}}}
  break;
 case 7:
  if(pause&&f>pf+30&&f%30<6)value=0x10;
  if(pause==0&&f>pf+65){phase=8;pf=f;}
  break;
 case 8:{unsigned d=f-pf;value=d<8?0x3000:(d<16?0x3020:0);if(mapstate){phase=9;pf=f;next=f+50;mapcount++;shot("Szenenauswahl_aus_Spiel",f);}}
  break;
 case 9:
  if(mapstate&&f>next){
   if(r32(savebase+4)!=0){value=0x40;next=f+35;}
   else if(current<73||current>78){value=0x2000;next=f+35;}
   else if(current<78){value=4;next=f+35;}
   else{shot("Wassertempel_Auswahl_Erwachsen",f);value=0x80;phase=10;pf=f;}
  }
  break;
 case 10:
  if(play&&gameMode==0&&f>pf+180){shot("Wassertempel_Erwachsen",f);printf("ENTERED_ADULT age=%u scene=%x equip=%04x rupees=%d\n",r32(savebase+4),scene,DebugMemRead16(savebase+0x70),(int16_t)DebugMemRead16(savebase+0x34));phase=11;pf=f;}
  break;
 case 11:{unsigned d=f-pf;value=d<8?0x3000:(d<16?0x3020:0);if(mapstate){phase=12;pf=f;next=f+50;mapcount++;}}
  break;
 case 12:
  if(mapstate&&f>next){if(r32(savebase+4)!=1){value=0x40;next=f+35;}else if(current!=73){value=0x2000;next=f+35;}else{value=0x80;phase=13;pf=f;}}
  break;
 case 13:
  if(play&&gameMode==0&&f>pf+150){shot("Brunnen_Kind",f);printf("DEBUG_TEST_PASS age=%u scene=%x equip=%04x rupees=%d maps=%u actual_ram=%u shadow=%04x\n",r32(savebase+4),scene,DebugMemRead16(savebase+0x70),(int16_t)DebugMemRead16(savebase+0x34),mapcount,r32(0x80000318),DebugMemRead16(savebase+0xf30));CoreDoCommand(M64CMD_STOP,0,NULL);}
  break;
 }
 static unsigned held=0,until=0;if(value){held=value;until=f+5;}else if(f<until)value=held;
 if(buttons)buttons(value);
 if(f>=(unsigned)limit){puts("DEBUG_TEST_TIMEOUT");CoreDoCommand(M64CMD_STOP,0,NULL);}
}
'''
end=base[base.index('static void setting('):]
(W/'runner.c').write_text(head+body+end)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)

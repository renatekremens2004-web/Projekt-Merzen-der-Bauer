from pathlib import Path
import os,json,subprocess,hashlib,shutil
from concurrent.futures import ThreadPoolExecutor
W=Path('/workspace/debug-version');O=Path('/workspace/oot-burns-pal')
rom=W/'debug/oot-pal-1.0-compressed.z64'
for ext in ['z64','elf','map']:
 shutil.copyfile(O/f'build/pal-1.0/oot-pal-1.0.{ext}',W/f'debug/oot-pal-1.0.{ext}')
shutil.copyfile(O/'build/pal-1.0/oot-pal-1.0-compressed.z64',rom)
subprocess.run(['python',str(W/'prepare_runtime.py')],check=True)
case='debug-release-verified-sram-load-clip-on'
cases=['debug-release-adult-start-clip-on',case]
sra=None
metadata=dict(rom_sha256=hashlib.sha256(rom.read_bytes()).hexdigest(),rom_path=str(rom),ram_bytes=4194304,save_injection=False,controller_only=True,cases=cases,native_sram_source='previous verified native Schattengewand save; copied to temporary emulator test directory',sram_name=sra)
(W/'runtime-release-inputs.json').write_text(json.dumps(metadata,indent=2)+'\n')
def run(case):
 env=dict(os.environ,DISPLAY=':99',OPENCV_VIDEOIO_PRIORITY_GPHOTO2='0',OPENCV_VIDEOIO_PRIORITY_GSTREAMER='0',OPENCV_VIDEOIO_PRIORITY_OBSENSOR='0',OPENCV_VIDEOIO_PRIORITY_V4L2='0')
 with(W/(case+'.log')).open('w')as log:
  log.write('ROM_SHA256 '+metadata['rom_sha256']+'\n');log.flush()
  subprocess.run([str(W/'runner'),str(rom),case,'6500','4'],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=400,check=True)
 print('Completed',case,flush=True)
run(cases[0])
# Read Mupen's actual per-ROM SRAM filename from the first completed probe.
sra=next((Path('/workspace/bean-rider')/('config-'+cases[0])).glob('*.sra')).name
dst=Path('/workspace/bean-rider')/('config-'+case);dst.mkdir(exist_ok=True)
shutil.copyfile(next(Path('/workspace/bean-rider/config-shadow-chest-release-direct-clip-on').glob('*.sra')),dst/sra)
metadata['sram_name']=sra
(W/'runtime-release-inputs.json').write_text(json.dumps(metadata,indent=2)+'\n')
run(cases[1])

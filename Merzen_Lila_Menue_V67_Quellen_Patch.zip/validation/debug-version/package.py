from pathlib import Path
import json,re,hashlib,shutil,zipfile
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/debug-version');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=json.loads((W/'binary-verification.json').read_text());pv=json.loads((W/'patch-verification.json').read_text());inp=json.loads((W/'runtime-release-inputs.json').read_text())
h=sha(W/'debug/oot-pal-1.0-compressed.z64');assert h==v['debug']['rom_sha256']==pv['debug']['target_sha256']==inp['rom_sha256']
assert sha(W/'normal/oot-pal-1.0-compressed.z64')==v['normal']['rom_sha256']==pv['normal']['target_sha256']
assert sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64') == v['normal']['rom_sha256']
rt=dict(rom_sha256=h,actual_ram_bytes=4194304,save_context_injected=False,controller_actions=True,cases=[])
alllogs=''
for case in inp['cases']:
 s=(W/(case+'.log')).read_text();assert 'DEBUG_TEST_PASS' in s and 'completed: 0' in s and h in s
 assert not any(x in s for x in ['DEBUG_TEST_TIMEOUT','GFX_OVERFLOW','OBJECT_OVERFLOW','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 assert set(re.findall(r'failures=(\d+)',s))=={'0'}
 assert set(re.findall(r'RAM=(\d+)',s))=={'4194304'}
 assert 'age=1 scene=8 equip=11' in s
 if 'adult-start' in case:
  assert 'ENTERED_START age=0 equip=1122' in s and 'EDITOR_ROW_WRAP_AND_RUPEE_RESULT rupees=151' in s
  assert 'ENTERED_ADULT age=0 scene=5 equip=1122 rupees=151' in s
  assert 'item=42 colored=481 red=470' in s and 'item=43 colored=483' in s
 else:
  assert 'NATIVE_SRAM_LOADED' in s and 'shadow=c000' in s
 rt['cases'].append(dict(name=case,native_sram_loaded='NATIVE_SRAM_LOADED' in s,passed=True))
 alllogs+=s
rt['smallest_gameplay_heap_block']=min(int(x) for x in re.findall(r'largest=(\d+)',alllogs) if int(x))
rt['smallest_object_buffer_reserve']=min(map(int,re.findall(r'OBJECT_BANK .*remaining=(\d+)',alllogs)))
(W/'runtime-verification.json').write_text(json.dumps(rt,indent=2)+'\n')
V=R/'validation/debug-version';P=R/'previews/debug-version';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True)
for name in ['prepare_runtime.py','release_runtime.py','runner.c','runtime-release-inputs.json','runtime-verification.json','binary-verification.json','verification.log','color-icon-tests.json','test_color_icons.py','test-color-icons.c','check_patch.js','patch-verification.json','package.py']:
 shutil.copyfile(W/name,V/name)
for case in inp['cases']:shutil.copyfile(W/(case+'.log'),V/(case+'.log'))
# Actual frames, copied without image edits. The initial editor-opening frame
# precedes drawing; the later editing frame shows the editor itself.
photos=[]
case=inp['cases'][0]
for number,name in [(0,'01_Szenenauswahl.png'),(3,'02_Inventar_Editor.png'),(4,'03_Orange_Hellblau_Icons.png'),(7,'04_Wassertempel_Debug.png')]:
 src=Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{number:03d}.png'
 assert src.is_file(),src
 shutil.copyfile(src,P/name);photos.append(dict(file=name,rom_sha256=h,source=str(src),unedited_emulator_capture=True))
src=Path('/workspace/bean-rider')/('screens-'+inp['cases'][1])/'the_legend_of_zelda-003.png'
assert src.is_file()
shutil.copyfile(src,P/'05_Schattengewand_Spielstand.png')
photos.append(dict(file='05_Schattengewand_Spielstand.png',rom_sha256=h,source=str(src),unedited_emulator_capture=True))
(P/'Aufnahmen.json').write_text(json.dumps(photos,indent=2)+'\n')
report=f'''# Gewandicons und separate Debugversion

Die normale Version ergänzt passend orange und hellblaue Fundtext-/Inventaricons. Die Debugversion enthält dieselben kumulativen Inhalte und zusätzlich die gezielt freigeschaltete native Szenenauswahl sowie den nativen Pause-Inventar-Editor. Alle bisherigen Figuren und 1.155 eigenen deutschen Nachrichten enthalten. [Bedienung](planning/Debug_Bedienung.md).

Normale Ziel-SHA256: `{v['normal']['rom_sha256']}`. Debug-Ziel-SHA256: `{h}`. Beide BPS auf Vanilla Europa/PAL 1.0 anwenden, nicht übereinander; Original-MD5 e040de91a74b61e3201db0e2323f768a.

## Umsetzung

Iconfarben werden nach dem nativen DMA in denselben 4.096-Byte-Puffern angepaßt. Nur die dominante Stoffarbe ändert sich; neutrale Kragen-/Gürteldetails, Alpha und Schattierung bleiben erhalten. Beide Pause-Ladepfade und das Itemicon im Fundtext verwenden dieselbe Routine. Die normale altersabhängige Graufärbung nicht benutzbarer Ausrüstung bleibt erhalten. Schwarzes Schattengewandicon und Schutzwirkung bleiben unverändert. Keine weitere Textur, kein neuer Speicherpuffer und keine Veränderung der gemeinsam benutzten NPC-Farbpalette.

Debugspezifisch: Controller 1 L+R halten und Z drücken, native sichere GameState-Transition; beim Verlassen des laufenden Spiels Szenenflags sichern. B wechselt das Alter, native Altersausrüstung wird mitgewechselt; ein bisher unbenutzter Kind-Cache erhält eine gültige Grundausrüstung. Menü öffnet nicht erneut über sich selbst und unterbricht keine bereits geplante GameState-Transition. Die zwei 64DD-Testaktionen wurden aus der Liste entfernt; unenthaltene Testkarten bleiben ausgeblendet. Menütexte werden nur in diesen beiden Menüdateien übersetzt, ohne globale Übersetzungseinstellungen zu verändern.

Start und L öffnet den vorhandenen Pause-Editor. Dessen ursprünglicher Rücksprung von Zeile 0 auf die ungültige Zeile 22 wurde auf die letzte der elf gültigen Zeilen korrigiert. Ein direkt vom Titel gestarteter Testzustand bleibt über Ortswechsel erhalten und hat weiterhin keinen echten SRAM-Slot. Sram_WriteSave fängt 0xFF ab; normale Speicherplätze werden nicht umgeleitet. Save-Struktur und Prüfsummenbereiche bleiben gleich. Kein globaler DEBUG_FEATURES-Build: retail DEBUG_FEATURES=0, ursprüngliche Speicherpools und 4 MiB erhalten.

## Prüfung

Beide PAL-Builds und ROM-Prüfsummen geprüft. Vergleich aller 1.526 DMA-Einträge mit der veröffentlichten Schattengewandfassung; alle veränderten übrigen Worte müssen echte Linker-Relokationen sein. Native Symbole in den betroffenen Segmenten außerhalb der ausdrücklich erlaubten Menü-/Iconfunktionen bleiben bis auf Relokationen identisch. Sämtliche Raum-, Modell-, Kollisions-, Itemobjekt- und Dialogdaten bleiben erhalten; alle bisherigen Sprachtextdaten sind bytegleich. Hosttest der tatsächlich verwendeten C-Iconroutine an 2.048 Originalpixeln prüft Farben, neutrale Details, Alpha, Puffergrenzen und Cache-Writeback.

Die finale Debug-ROM wurde in den aufgeführten Emulatorproben mit echten 4 MiB getestet, ohne SaveContext-Injektion: Titel-Hotkey, Szenenwahl, Inventar-Editor, Navigation über die erste/letzte Zeile, Rubinänderung 150 auf 151, Rückkehr ins Spiel, wiederholtes Menüöffnen, Kakariko, Wassertempel und Brunnen sowie Wechsel Erwachsener/Kind mit korrekter Ausrüstung. Ein separat kopierter echter SRAM-Spielstand wurde über Titel/Dateiauswahl geladen; Schattengewandflag und Nachbarflag bleiben nach Orts-/Alterswechsel erhalten. Die orange/hellblauen Icons sind als Erwachsener sichtbar, als Kind greift die normale graue Nichtbenutzbarkeitsdarstellung. Kleinste gemessene zusammenhängende Spielarenareserve {rt['smallest_gameplay_heap_block']:,} Byte, kleinste Objektpufferreserve {rt['smallest_object_buffer_reserve']:,} Byte. Keine fehlgeschlagenen Belegungen oder gemeldeten Grafik-/Objektpufferüberläufe. Kein vollständiger Spieldurchlauf und kein Hardwaretest.

Beide BPS wurden mit RomPatcher.js und aktiver Quellvalidierung auf Vanilla angewandt; die Ergebnisse sind bytegleich zu den jeweiligen geprüften ROMs. Alle Bilder sind unveränderte Emulatoraufnahmen.

## Reproduzieren

Nach dem bisherigen kumulativen Build zuletzt build_shadow_tunic.py und build_tunic_icons.py ausführen. Für die separate Debugversion anschließend optional build_debug_version.py ausführen; mit dessen --restore-Schalter zu den normalen Produktionsquellen zurückkehren. PAL bauen mit VERSION=pal-1.0 COMPARE=0 PYTHON=python3, normales retail DEBUG_FEATURES=0 beibehalten. Die normalen Produktionsquellen enthalten keine freigeschalteten Debugmenüs. Quellenpaket ohne ROM, Spielstände, SRAM, Savestates, ELF oder ausführbare Programme.
'''
(R/'TESTING_DEBUG_GEWAENDER.md').write_text(report)
for name in ['Mr_Burns_Mr_Bean_DE_PAL10_Gewandicons.bps','Mr_Burns_Mr_Bean_DE_PAL10_DEBUG.bps']:
 shutil.copyfile(A/name,R/'patches'/name);shutil.copyfile(A/name,D/name)
guide=R/'planning/Debug_Bedienung.md';shutil.copyfile(guide,D/'Debug_Bedienung.md')
(D/'Debug_Bedienung.txt').write_text(guide.read_text())
G=D/'Debug_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
(G/'Pruefbericht.md').write_text(report.replace('(planning/Debug_Bedienung.md)','(../Debug_Bedienung.md)'))
heading='# Debugversion und passende Gewandicons'
p=R/'README.md';s=p.read_text();prefix=heading+'\n\n[Normaler Gesamtpatch](patches/Mr_Burns_Mr_Bean_DE_PAL10_Gewandicons.bps) · [Debug-Gesamtpatch](patches/Mr_Burns_Mr_Bean_DE_PAL10_DEBUG.bps) · [Bedienung](planning/Debug_Bedienung.md) · [Prüfung](TESTING_DEBUG_GEWAENDER.md)\n\nOrange/hellblaue Icons zusätzlich zu den bisherigen Modellfarben. Separate Debugversion mit Szenenauswahl und Inventar-Editor; alle bisherigen Inhalte erhalten. Letzte normale Builder: build_shadow_tunic.py und build_tunic_icons.py, Debug nur optional danach.\n\n'
if not s.startswith(heading):p.write_text(prefix+s)
archive=A/'Merzen_Debug_Gewandicons_Quellen_Patch.zip'
suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'}
exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
original_dirs={'water-comic-heroes','ben-ice','jabba','bttf','kenny','xwing','mystery-inc','mystery-machine','desert-guests','gerudo-dialogue','twinrova-dialogue','doof-guests','shadow-tunic','tunic-icons','debug-version'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R)
  original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in original_dirs and(p.suffix in ['.c','.h','.png']or rel.parts[-2:]==('spec','spec'))
  if not p.is_file()or(any(q in exclude for q in rel.parts)and not original)or(p.suffix.lower()not in suffixes and not original):continue
  if rel.parts[0]=='patches'and p.name not in ['Mr_Burns_Mr_Bean_DE_PAL10_Gewandicons.bps','Mr_Burns_Mr_Bean_DE_PAL10_DEBUG.bps']:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='debug-version':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:
 assert z.testzip()is None
 assert not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.o','.so','.st','.exe','.glb'}for n in z.namelist())
 for n in ['tools/build_debug_version.py','tools/build_tunic_icons.py','planning/Debug_Bedienung.md']:assert n in z.namelist()
shutil.copyfile(archive,D/archive.name)
files=['Mr_Burns_Mr_Bean_DE_PAL10_Gewandicons.bps','Mr_Burns_Mr_Bean_DE_PAL10_DEBUG.bps',archive.name,'Debug_Bedienung.md','Debug_Bedienung.txt']
sums=D/'SHA256SUMS_Debug_Gewandicons.txt';sums.write_text(''.join(sha(D/n)+'  '+n+'\n'for n in files));files.append(sums.name)
p=D/'README.md';s=p.read_text();prefix=heading+'\n\n[Debug-Gesamtpatch](Mr_Burns_Mr_Bean_DE_PAL10_DEBUG.bps?raw=true) · [Normaler Gesamtpatch](Mr_Burns_Mr_Bean_DE_PAL10_Gewandicons.bps?raw=true) · [Bedienung](Debug_Bedienung.md) · [Bilder](Debug_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nAlle bisherigen Inhalte einschließlich Schattengewand. Orange/hellblaue Gewandicons in beiden Fassungen. Debug: L+R halten und Z drücken; im offenen Pausemenü L für den Inventar-Editor. Je einen Patch auf Vanilla PAL 1.0 anwenden. Separate Testspielstandkopie verwenden. Gezielte 4-MiB-Proben bestanden, kein vollständiger Spieldurchlauf.\n\n'
if not s.startswith(heading):p.write_text(prefix+s)
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=h,files=files,images=[str(p.relative_to(D))for p in G.iterdir()],normal_sha256=v['normal']['rom_sha256']),indent=2)+'\n')
print('Packaged',h,'archive bytes',archive.stat().st_size)

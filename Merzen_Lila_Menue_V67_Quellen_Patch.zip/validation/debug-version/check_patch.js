const fs=require('fs'),crypto=require('crypto');
global.BinFile=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/modules/BinFile');
const P=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/RomPatcher');
const original=new BinFile('/workspace/oot-burns-pal/baseroms/pal-1.0/baserom.z64');
let reports={};
for(const [name,kind] of [['Gewandicons','normal'],['DEBUG','debug']]){
 const patch=P.parsePatchFile(new BinFile('/workspace/artifacts/Mr_Burns_Mr_Bean_DE_PAL10_'+name+'.bps'));
 const output=P.applyPatch(original,patch,{requireValidation:true}),actual=Buffer.from(output._u8array),expected=fs.readFileSync('/workspace/debug-version/'+kind+'/oot-pal-1.0-compressed.z64');
 if(!actual.equals(expected))throw Error('ROM roundtrip mismatch '+name);
 reports[kind]={source_md5:crypto.createHash('md5').update(Buffer.from(original._u8array)).digest('hex'),target_sha256:crypto.createHash('sha256').update(actual).digest('hex'),target_bytes:actual.length,rompatcher_js_source_validation:true,byte_identical:true};
}
fs.writeFileSync('/workspace/debug-version/patch-verification.json',JSON.stringify(reports,null,2)+'\n');console.log(reports);

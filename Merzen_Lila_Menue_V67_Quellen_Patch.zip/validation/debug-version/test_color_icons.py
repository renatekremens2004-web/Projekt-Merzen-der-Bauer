from pathlib import Path
from PIL import Image
import subprocess,json
W=Path('/workspace/debug-version');R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal')
for name in ['Goron','Zora']:
 im=Image.open(O/f'extracted/pal-1.0/assets/textures/icon_item_static/gItemIconTunic{name}Tex.rgba32.png').convert('RGBA');(W/f'{name}.rgba').write_bytes(im.tobytes())
c=r'''
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
typedef uint8_t u8; typedef uint32_t u32; typedef int32_t s32;typedef uint16_t u16;
#define ITEM_TUNIC_GORON 0x42
#define ITEM_TUNIC_ZORA 0x43
static void* flushed;static int flush_size;
static void osWritebackDCache(void* p,int n){flushed=p;flush_size=n;}
'''+(R/'tools/tunic_color_icons.inc.c').read_text()+r'''
int main(int argc,char**argv){
 for(int k=0;k<2;k++){
  u8 buf[16+4096+16],old[4096];memset(buf,0xA5,sizeof(buf));FILE*f=fopen(argv[k+1],"rb");assert(f&&fread(buf+16,1,4096,f)==4096);fclose(f);memcpy(old,buf+16,4096);
  CustomTunics_RecolorIcon(buf+16,0x42+k);assert(flushed==buf+16&&flush_size==4096);
  int changed=0;
  for(int i=0;i<16;i++)assert(buf[i]==0xA5&&buf[16+4096+i]==0xA5);
  for(int i=0;i<1024;i++){u8*p=buf+16+i*4,*o=old+i*4;assert(p[3]==o[3]);
   if(o[0]==o[1]&&o[1]==o[2])assert(!memcmp(p,o,4));
   if(k==0){assert(p[0]==o[0]&&p[2]==o[2]);if(o[0]>o[1]&&o[0]>o[2])assert(p[1]==(o[0]+o[1])/2);}
   else {assert(p[2]==o[2]);if(o[2]>o[0]&&o[2]>o[1])assert(p[0]==o[2]*110/240&&p[1]==o[2]*195/240);}
   if(memcmp(p,o,4))changed++;
  }
  assert(changed>200);printf("item=%02x changed=%d alpha/detail/guards/cache PASS\n",0x42+k,changed);
 }
}
'''
(W/'test-color-icons.c').write_text(c)
subprocess.run(['gcc','-O2','-Wall',str(W/'test-color-icons.c'),'-o',str(W/'test-color-icons')],check=True)
r=subprocess.check_output([str(W/'test-color-icons'),str(W/'Goron.rgba'),str(W/'Zora.rgba')],text=True)
(W/'color-icon-tests.json').write_text(json.dumps(dict(passed=True,actual_c_routine=True,pixels=2048,alpha_preserved=True,neutral_detail_preserved=True,buffer_guards=True,cache_writeback=True,output=r),indent=2)+'\n');print(r)

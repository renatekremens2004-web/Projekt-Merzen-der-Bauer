Sechs native 4-MB-Gesprächsszenarien; siehe ../../TESTING_ALLTAGSGAGS.md. Keine ROMs, Spielstände oder Emulator-Binaries enthalten.

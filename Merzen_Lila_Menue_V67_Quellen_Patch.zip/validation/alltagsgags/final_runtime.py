from pathlib import Path
import re,json,struct,math
W=Path('/workspace/milch-aale');O=Path('/workspace/oot-burns-pal');s=Path('/workspace/transition/runner.c').read_text()
block='''  if(f>=450 && f<550 && mode==0 && strstr(scenario,"releasegag")) {
   uint32_t npc=0;float d=45;
   if(strstr(scenario,"milk")){npc=actor_type(0x1bc,2);d=35;}
   if(strstr(scenario,"bowling")){npc=actor_type(0x1bc,3);d=35;}
   if(strstr(scenario,"battery")){npc=actor_type(0x178,8);d=35;}
   if(strstr(scenario,"ice"))npc=actor_type(0x16e,19);
   if(strstr(scenario,"tentacle"))npc=actor_type(0x16e,20);
   if(strstr(scenario,"moon"))npc=actor_type(0xb3,2);
   if(npc){int yaw=DebugMemRead16(npc+0xb6);position(player,rf(npc+0x24)+sinf(yaw*3.14159265f/32768)*d,rf(npc+0x28),rf(npc+0x2c)+cosf(yaw*3.14159265f/32768)*d,yaw+0x8000);if(f==450)printf("NATIVE_NPC f=%u id=%x params=%x position=(%.1f %.1f %.1f)\\n",f,DebugMemRead16(npc),DebugMemRead16(npc+0x1c),rf(npc+0x24),rf(npc+0x28),rf(npc+0x2c));}
  }
'''
s=s.replace(' if(buttons)buttons(value);', ' if(f>=440 && f<456)value &= ~0x20;\n if(buttons)buttons(value);')
s=s.replace('  if(f==300 && strstr(scenario,"navi"))',block+'  if(f==300 && strstr(scenario,"navi"))');(W/'runner-final.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
cases=[('milk',0x2fd,0,(-66.,0.,48.),0),('battery',0xb1,0,(111.,0.,-475.),-32768),('bowling',0x2fd,0,(-110.,16.,-70.),-32768),('ice',0x388,0x8000,(40.,0.,86.),-0x4000),('tentacle',0xb7,0x8000,(-83.,0.,110.),-0x6000),('moon',0x138,0x8000,(1022.,1101.,2804.),0x53e9)]
for topic,entr,time,pos,yaw in cases:
 b=bytearray(Path('/workspace/transition/market-pre.save').read_bytes());struct.pack_into('>I',b,0,entr);struct.pack_into('>H',b,0xc,time);struct.pack_into('>I',b,0x10,int(time==0));struct.pack_into('>H',b,0x141a,time);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,entr,0);(W/(topic+'.save')).write_bytes(b)

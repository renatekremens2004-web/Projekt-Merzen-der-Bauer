from pathlib import Path
import sys,json
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');sys.path.insert(0,str(R/'tools'));import build_story as b
native=b.messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text());current=b.messages((O/'extracted/pal-1.0/text/message_data.h').read_text());report={};chain={'704F':'0121','0121':'0122','0122':'0123'}
for f in (R/'story').glob('*.json'):
 for ident,entry in json.loads(f.read_text())['messages'].items():
  old=native[entry.get('native_template',ident)]['parts'][2][2];new=current[ident]['parts'][2][2];expected=b.controls(old)+(['TEXTID(0x'+chain[ident]+')'] if ident in chain else []);assert expected==b.controls(new),ident
  report[ident]={'template':entry.get('native_template',ident),'controls':b.controls(new),'pages':len(b.split_pages(new)[0])}
assert len(report)==635
assert report['0125']['pages']==1
assert report['7051']['controls']==['TWO_CHOICE'] and report['7052']['controls']==['TEXTID(0x7051)']
assert all(x not in chain.values() or b.plain(native[x]['parts'][2][2]).strip()==x for x in report)
Path('/workspace/milch-aale/control-checks.json').write_text(json.dumps(report,indent=2)+'\n');print('635 control sequences checked; three explicit safe continuations; choice/retry preserved')

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/milch-aale');s=json.loads((W/'symbols.json').read_text())
def run(name):
 case='releasegag-'+name+os.environ.get('GAG_RUN_SUFFIX','')+'-focus-direct-clip-on'
 with (W/(case+'.log')).open('w') as out:subprocess.run([str(W/'runner-final'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,'1200','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(name+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
jobs=['milk','battery','bowling','ice','tentacle','moon']
if len(sys.argv)>1:jobs=[j for j in jobs if j in sys.argv[1:]]
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,jobs))

#define M64P_CORE_PROTOTYPES
#include "m64p_common.h"
#include "m64p_frontend.h"
#include "m64p_config.h"
#include "m64p_debugger.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <dlfcn.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <execinfo.h>
#include <math.h>
static void crash(int n){void* b[40];int c=backtrace(b,40);backtrace_symbols_fd(b,c,2);_exit(128+n);}

static void alarmcb(int sig){(void)sig;uint32_t* c=DebugGetCPUDataPtr(M64P_CPU_REG_COP0);printf("CPU pc=%08x cause=%08x epc=%08x bad=%08x\n",*(uint32_t*)DebugGetCPUDataPtr(M64P_CPU_PC),c[13],c[14],c[8]);for(uint32_t t=DebugMemRead32(0x8000633c),n=0;t>=0x80000000 && t<0x80800000 && n<15;t=DebugMemRead32(t+12),n++){printf("THREAD %08x id=%u state=%u pc=%08x ra=%08x sp=%08x\n",t,DebugMemRead32(t+20),DebugMemRead16(t+16),DebugMemRead32(t+0x11c),DebugMemRead32(t+0x104),DebugMemRead32(t+0xf4));}FILE* d=fopen("/workspace/bean-rider/stalled-ram.bin","wb");for(uint32_t a=0x80000000;a<0x80400000;a+=4){uint32_t v=__builtin_bswap32(DebugMemRead32(a));fwrite(&v,4,1,d);}fclose(d);alarm(15);}
static uint32_t savebase=0x80118450, overlays=0x800e6500;
static int limit=2400;static int memory_mb=4;
static const char* scenario;
static const char* snapshotfile;
static void (*buttons)(unsigned);
static unsigned actors[32],player;static int count;
static uint32_t r32(uint32_t a){return DebugMemRead32(a);}
static float rf(uint32_t a){uint32_t x=r32(a);float f;memcpy(&f,&x,4);return f;}
static void debugcb(void* ctx,int level,const char* message){static int bad=0;if(strstr(message,"UNKNOWN GBI COMMAND") || strstr(message,"Using Vertex outside buffer")){if(++bad>100)exit(98);}if(level<=2)fprintf(stderr,"EMU %d: %s\n",level,message);}
static void scan(void){
 count=0;
 for(uint32_t a=0x80120000;a<0x80400000-0x700;a+=4){
  unsigned id=DebugMemRead16(a);if(id==0 && r32(a+0x138)==overlays && DebugMemRead8(a+2)==2 && r32(a+0x130))player=a;if(id!=0xe8 && id!=0x2a && id!=0x17a && id!=0x52)continue;
  if(r32(a+0x138)!=overlays+id*0x20 || !r32(a+0x130))continue;
  int params=(int16_t)DebugMemRead16(a+0x1c);
  if(id==0xe8 && params>=100)continue;
  if(id==0x2a && (params>>8)!=3 && (params>>8)!=5 && (params>>8)!=7 && (params>>8)!=8 && (params>>8)!=9)continue;
  if(count<32)actors[count++]=a;
 }
}
static uint32_t play;
static uint32_t actor(int id){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130))return a;
 return 0;
}
static uint32_t actor_type(int id,int type){
 if(!play)return 0;
 for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80800000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==id && r32(a+0x130) && (type<0 || (DebugMemRead16(a+0x1c)&127)==type))return a;
 return 0;
}
static void findplay(void){
 if(play && r32(play+0x1c44)==player && player && r32(player+0x130))return;
 play=0;player=0;scan();if(!player)return;
 for(uint32_t a=0x80120000;a<0x80400000;a+=4)if(r32(a)==player && a>0x80121c44 && r32(a-4)==1){uint32_t p=a-0x1c44;if(DebugMemRead16(p+0xa4)<0x70 && r32(p)>=0x80000000){play=p;break;}}
 if(play)printf("PLAY %08x player=%08x scene=%x\n",play,player,DebugMemRead16(play+0xa4));
}
static void wf(uint32_t a,float f){uint32_t v;memcpy(&v,&f,4);DebugMemWrite32(a,v);}
static void position(uint32_t a,float x,float y,float z,int facing){wf(a+0x24,x);wf(a+0x28,y);wf(a+0x2c,z);wf(a+0x100,x);wf(a+0x104,y);wf(a+0x108,z);DebugMemWrite16(a+0xb6,facing);DebugMemWrite16(a+0x32,facing);}
static void baseframe(unsigned f){
 alarm(30);
 if (snapshotfile && f == 300) {
   findplay();
   if (strstr(scenario,"export")) {
     FILE* snap=fopen(snapshotfile,"wb");if(!snap)exit(90);
     for(unsigned i=0;i<0x1428;i++)fputc(DebugMemRead8(savebase+i),snap);
     fclose(snap);printf("EXPORTED save=%08x entrance=%x age=%d mode=%d\n",savebase,r32(savebase),r32(savebase+4),r32(savebase+0x135c));
     CoreDoCommand(M64CMD_STOP,0,NULL);return;
   }
   if(!play){fprintf(stderr,"No title PlayState found\n");exit(91);}
   printf("INJECT title scene=%x mode=%d save=%08x\n",DebugMemRead16(play+0xa4),r32(savebase+0x135c),savebase);
   FILE* snap=fopen(snapshotfile,"rb");if(!snap)exit(92);
   for(unsigned i=0;i<0x1428;i++){int ch=fgetc(snap);if(ch<0)exit(93);DebugMemWrite8(savebase+i,ch);}fclose(snap);
   DebugMemWrite32(savebase+0x135c,0);
   DebugMemWrite8(play+0x11de8,r32(savebase+4));
   DebugMemWrite16(savebase+0x1412,r32(savebase+8)?r32(savebase+8):0xffef);
   DebugMemWrite8(play+0x1d6c,0);
   if(strstr(scenario,"direct")) {
     uint32_t game=0x800ef7c0+3*0x30;
     if(r32(game+0x2c)!=0x12518){fprintf(stderr,"Invalid Play gamestate entry\n");exit(97);}
     DebugMemWrite8(play+0x11de9,1);
     DebugMemWrite32(play+0xc,r32(game+0x18));DebugMemWrite32(play+0x10,0x12518);DebugMemWrite32(play+0x98,0);
     printf("DIRECT Play_Init=%08x\n",r32(game+0x18));
   }else{
     DebugMemWrite16(play+0x11e1a,r32(savebase));
     DebugMemWrite8(play+0x11e5e,2);DebugMemWrite8(play+0x11e15,20);
   }
   printf("START entrance=%x age=%d cs=%x\n",r32(savebase),r32(savebase+4),r32(savebase+8));
 }
 if(snapshotfile){if(f<500){if(f%50==0)findplay();return;}f-=500;}
 if(f%50==0)findplay();unsigned value=0;
 if(play){
  uint32_t m=play+0x20d8;unsigned id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),pos=DebugMemRead16(m+0xe3ce);
  static unsigned oldkey=0,age=0;unsigned key=id*1024+pos;
  if(key!=oldkey || (mode!=7 && mode!=0x34 && mode!=0x35)){oldkey=key;age=0;}else age++;
  if((mode==7 || mode==0x34 || mode==0x35) && age==8){printf("TEXT f=%u id=%04x pos=%u mode=%x len=%u\n",f,id,pos,mode,r32(m+0xe300));if(!strstr(scenario,"record"))CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f==100 && !strstr(scenario,"record"))CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  if(f>150 && mode==0){value=0x20;if(f%30<4)value|=0x80;}
  else if(f>100 && (mode==6 || mode==7 || mode==0x34 || mode==0x35) && age>18 && f%20<4)value=0x80;
  if(strstr(scenario,"ruto") && mode==0)value=(f>300 && f<550)?0x40000000:0;
  if(strstr(scenario,"still"))value=0;
  if(f%50==0){
   uint32_t fan=actor_type(0x173,0x75),chum=actor_type(0x173,0x76),sprout=actor(0xd3),ruto=actor(0xd2),ben=actor_type(0x173,0),zora=actor(0x1ce);
   printf("ACTORS f=%u fan=%08x chum=%08x sprout=%08x ruto=%08x room=%d prev=%d fan_floor=%.1f chum_floor=%.1f\n",f,fan,chum,sprout,ruto,(int8_t)DebugMemRead8(play+0x11cbc),(int8_t)DebugMemRead8(play+0x11cd0),fan?rf(fan+0x80):0,chum?rf(chum+0x80):0);
   printf("NEWNPC f=%u ben=%08x zora=%08x benpos=(%.1f %.1f %.1f) chumpos=(%.1f %.1f %.1f) zora_floor=%.1f\n",f,ben,zora,ben?rf(ben+0x24):0,ben?rf(ben+0x28):0,ben?rf(ben+0x2c):0,chum?rf(chum+0x24):0,chum?rf(chum+0x28):0,chum?rf(chum+0x2c):0,zora?rf(zora+0x80):0);
   if(fan&&chum){fprintf(stderr,"HERO_COLOAD_ERROR\n");exit(95);}
   if(sprout)printf("SPROUT f=%u cs=%u rising=%u state=%u anim=%08x frame=%.1f limbs=%u pos=(%.1f %.1f %.1f) yaw=%x\n",f,DebugMemRead8(play+0x1d6c),DebugMemRead8(sprout+0x18b),DebugMemRead8(sprout+0x18c),r32(sprout+0x19c),rf(sprout+0x1ac),DebugMemRead8(sprout+0x194),rf(sprout+0x24),rf(sprout+0x28),rf(sprout+0x2c),DebugMemRead16(sprout+0xb6));
   if(ruto)printf("RUTO f=%u action=%u draw=%u anim=%08x frame=%.1f pos=(%.1f %.1f %.1f)\n",f,r32(ruto+0x2d4),r32(ruto+0x2d8),r32(ruto+0x144),rf(ruto+0x154),rf(ruto+0x24),rf(ruto+0x28),rf(ruto+0x2c));
   uint32_t ctx=play+0x117a4,begin=r32(ctx),end=r32(ctx+4),last=begin;int entries=DebugMemRead8(ctx+8);
   for(int i=0;i<entries && i<19;i++){uint32_t slot=ctx+12+i*0x44;int obj=(int16_t)DebugMemRead16(slot);if(obj<0)obj=-obj;if(obj>0 && obj<0x192){uint32_t e=r32(slot+4)+r32(0x800f7488+obj*8+4)-r32(0x800f7488+obj*8);if(e>last)last=e;}}
   printf("OBJECT_BANK f=%u entries=%d used=%u capacity=%u remaining=%d\n",f,entries,last-begin,end-begin,(int)(end-last));if(last>end){fprintf(stderr,"OBJECT_BANK_OVERFLOW\n");exit(96);}
   printf("ROOM_BANK f=%u capacity=%u\n",f,r32(play+0x11ce8)-r32(play+0x11ce4));
   printf("STATE f=%u scene=%x id=%04x msg=%x RAM=%u player=(%.1f %.1f %.1f)\n",f,DebugMemRead16(play+0xa4),id,mode,r32(0x80000318),rf(player+0x24),rf(player+0x28),rf(player+0x2c));
   if(!strstr(scenario,"record") && f>100 && f%200==0)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  }
 }

 if(buttons)buttons(value);if(f>=(unsigned)limit)CoreDoCommand(M64CMD_STOP,0,NULL);
}


static FILE* videoPipe=NULL;
static unsigned capturePending=0,videoCount=0,videoFirst=0,videoLast=0;
static void capture_render(void) {
 static unsigned char* pixels=NULL;
 if(!capturePending)return;
 capturePending=0;
 if(!pixels)pixels=malloc(640*480*3);
 if(!pixels || CoreDoCommand(M64CMD_READ_SCREEN,0,pixels))exit(94);
 if(fwrite(pixels,640*480*3,1,videoPipe)!=1)exit(94);
}
static void finish_video(void) {
 if(videoPipe){int result=pclose(videoPipe);videoPipe=NULL;if(result){fprintf(stderr,"VIDEO_ENCODER_FAILED %d\n",result);exit(94);}}
}
static void onframe(unsigned f) {
 static unsigned started=0,done=0,stopQueued=0,sawText=0,sawRuto=0,sawRise=0,after=0;
 baseframe(f);
 if(stopQueued){if(!capturePending)CoreDoCommand(M64CMD_STOP,0,NULL);return;}
 if(f<550)return;
 findplay();if(!play)return;
 unsigned scene=DebugMemRead16(play+0xa4),rutoCase=strstr(scenario,"ruto")!=NULL,danceCase=strstr(scenario,"dance-still")!=NULL;
 uint32_t sprout=actor(0xd3),ruto=actor(0xd2),m=play+0x20d8;
 unsigned id=DebugMemRead16(m+0xe2f8),cs=DebugMemRead8(play+0x1d6c),rising=sprout?DebugMemRead8(sprout+0x18b):255;
 if(id==0x403e)sawText=1;
 if(ruto)sawRuto=1;
 if(sprout && rising==1)sawRise=1;
 if(!started && ((rutoCase && scene==5 && ruto && f>=600) || (!rutoCase && scene==0x55 && sprout && (!danceCase || f>=600)))) {
  char command[1200];const char* name=rutoCase?"Thaddaeus_Wassertempel_Animationen.mp4":danceCase?"Tripple_T_Tanz.mp4":"Tripple_T_Aus_dem_Boden.mp4";
  snprintf(command,sizeof(command),"ffmpeg -y -v error -f rawvideo -pixel_format rgb24 -video_size 640x480 -framerate 50/3 -i pipe:0 -vf vflip -an -c:v libx264 -threads 2 -preset medium -crf 18 -pix_fmt yuv420p -movflags +faststart /workspace/artifacts/%s",name);
  videoPipe=popen(command,"w");if(!videoPipe)exit(94);
  started=1;videoFirst=f;printf("VIDEO_START frame=%u scene=%x file=%s\n",f,scene,name);
 }
 if(!started)return;
 if((rutoCase && sawText && sawRuto && !ruto) || (!rutoCase && sawRise && sprout && cs==0 && rising==0))after++;
 if((danceCase && videoCount>=400) || (!danceCase && after>=(rutoCase?90:360)))done=1;
 if(!rutoCase && !danceCase && videoCount>=700)done=1;
 if(done){printf("VIDEO_END first=%u last_exclusive=%u frames=%u sawText=%u sawRise=%u\n",videoFirst,f,videoCount,sawText,sawRise);stopQueued=1;return;}
 if(capturePending)exit(94);
 capturePending=1;videoLast=f;videoCount++;
 if(f%200==0){printf("VIDEO_PHOTO frame=%u relative=%u\n",f,f-videoFirst);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
}

static void setting(const char* section,const char* key,m64p_type type,const void* value){m64p_handle h;ConfigOpenSection(section,&h);ConfigSetParameter(h,key,type,value);}
static void integer(const char* section,const char* key,int value){setting(section,key,M64TYPE_INT,&value);}
static void boolean(const char* section,const char* key,int value){setting(section,key,M64TYPE_BOOL,&value);}
int main(int argc,char** argv){signal(SIGSEGV,crash);signal(SIGILL,crash);
 if(argc<3)return 2;scenario=argv[2];if(strstr(scenario,"-us")){savebase=0x8011a5d0;overlays=0x800e8530;}if(argc>3)limit=atoi(argv[3]);if(argc>4)memory_mb=atoi(argv[4]);setbuf(stdout,NULL);
 if(argc>5)savebase=strtoul(argv[5],NULL,0);if(argc>6)overlays=strtoul(argv[6],NULL,0);
 if(argc>7)snapshotfile=argv[7];
 char config[512],shots[512];snprintf(config,sizeof(config),"/workspace/bean-rider/config-%s",scenario);snprintf(shots,sizeof(shots),"/workspace/bean-rider/screens-%s",scenario);mkdir(config,0700);mkdir(shots,0700);
 void* sdl=dlopen("libSDL2-2.0.so.0",RTLD_NOW|RTLD_GLOBAL);int(*sdlinit)(unsigned)=dlsym(sdl,"SDL_Init");sdlinit(0x20|0x200);
 int r=CoreStartup(0x020001,config,"/workspace/toolchain/root/usr/share/games/mupen64plus",NULL,debugcb,NULL,NULL);if(r)return r;
 integer("Video-GLideN64","EnableCopyColorToRDRAM",1);
 boolean("Video-GLideN64","EnableClipping",strstr(scenario,"clip-on")!=NULL);
 boolean("Video-GLideN64","EnableCustomSettings",0);
 setting("Core","SharedDataPath",M64TYPE_STRING,"/workspace/toolchain/root/usr/share/games/mupen64plus");
 setting("Core","ScreenshotPath",M64TYPE_STRING,shots);setting("Core","SaveStatePath",M64TYPE_STRING,config);setting("Core","SaveSRAMPath",M64TYPE_STRING,config);
 boolean("Core","DisableExtraMem",memory_mb==4);integer("Core","R4300Emulator",memory_mb==4?1:2);boolean("Core","OnScreenDisplay",0);integer("Video-General","ScreenWidth",640);integer("Video-General","ScreenHeight",480);boolean("Video-General","Fullscreen",0);boolean("Video-General","VerticalSync",0);
 FILE* file=fopen(argv[1],"rb");if(!file)return 3;fseek(file,0,SEEK_END);long n=ftell(file);rewind(file);void* rom=malloc(n);if(fread(rom,1,n,file)!=(size_t)n)return 4;fclose(file);r=CoreDoCommand(M64CMD_ROM_OPEN,n,rom);if(r)return r;
 fprintf(stderr,"Core paths: %s | %s | %s\n",ConfigGetUserDataPath(),ConfigGetUserCachePath(),ConfigGetUserConfigPath());
 m64p_rom_settings rs;memset(&rs,0,sizeof(rs));r=CoreDoCommand(M64CMD_ROM_GET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 rs.disableextramem=memory_mb==4;r=CoreDoCommand(M64CMD_ROM_SET_SETTINGS,sizeof(rs),&rs);if(r)return r;
 printf("Requested memory: %d MiB; disableextramem=%d\n",memory_mb,rs.disableextramem);
 const char* paths[]={"/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-rsp-hle.so","/workspace/toolchain/RMG-060/glide-build/plugin/Release/mupen64plus-video-GLideN64.so",NULL,"/workspace/wallace-cheer/record_input.so"};
 if(strstr(scenario,"mk2"))paths[1]="/workspace/toolchain/root/usr/lib/x86_64-linux-gnu/mupen64plus/mupen64plus-video-glide64mk2.so";
 void* core=dlopen("libmupen64plus.so.2",RTLD_NOW|RTLD_GLOBAL);int order[]={1,2,3,0};
 for(int k=0;k<4;k++){int i=order[k];if(!paths[i])continue;void* plugin=dlopen(paths[i],RTLD_NOW|RTLD_LOCAL|RTLD_DEEPBIND);if(!plugin){puts(dlerror());return 5;}ptr_PluginStartup startup=dlsym(plugin,"PluginStartup");if((r=startup(core,NULL,debugcb)))return r;if((r=CoreAttachPlugin(i+1,plugin)))return r;if(i==3){buttons=dlsym(plugin,"TestSetButtons");void(*hook)(void(*)(void))=dlsym(plugin,"TestSetRenderCapture");if(!hook)return 95;hook(capture_render);}}
 int speed=0;CoreDoCommand(M64CMD_CORE_STATE_SET,M64CORE_SPEED_LIMITER,&speed);CoreDoCommand(M64CMD_SET_FRAME_CALLBACK,0,onframe);signal(SIGALRM,alarmcb);alarm(15);r=CoreDoCommand(M64CMD_EXECUTE,0,NULL);
 finish_video();printf("SCENARIO %s completed: %d\n",scenario,r);CoreDoCommand(M64CMD_ROM_CLOSE,0,NULL);CoreShutdown();return r;
}

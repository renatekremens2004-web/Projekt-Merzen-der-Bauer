from pathlib import Path
import re,json,sys
from PIL import ImageDraw
from PIL import Image
import numpy as np
W=Path('/workspace/ben-ice');O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer')
# Native collision floors, with room geometry bounds to place optional NPCs.
for sc,rooms in [('ice_doukutu',[3,5,9,10,11]),('men',[3])]:
 D=O/f'extracted/pal-1.0/assets/scenes/dungeons/{sc}'
 v=np.array([list(map(int,x))for x in re.findall(r'\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\}',next(D.glob('*_VtxList.inc.c')).read_text())])
 tris=[]
 for a,b,c,ny in re.findall(r'COLPOLY_VTX\((\d+),.*?COLPOLY_VTX\((\d+),.*?COLPOLY_VTX\((\d+),.*?COLPOLY_SNORMAL\([-.\d]+\).*?COLPOLY_SNORMAL\(([-.\d]+)\)',next(D.glob('*_PolyList.inc.c')).read_text(),re.S):
  if float(ny)>.5:tris.append(v[list(map(int,[a,b,c]))])
 for room in rooms:
  coords=[]
  for p in D.glob(f'{sc}_room_{room}_*Vtx_fused_*.inc.c'):
   coords.extend([list(map(int,x))for x in re.findall(r'VTX\(\s*(-?\d+),\s*(-?\d+),\s*(-?\d+),',p.read_text())])
  if not coords:continue
  ar=np.array(coords);lo=ar.min(0);hi=ar.max(0);print(sc,room,'bounds',lo,hi)
  im=Image.new('RGB',(1000,1000),'#181820');dr=ImageDraw.Draw(im);span=max(hi[0]-lo[0],hi[2]-lo[2])+40
  def proj(x,z):return (20+(x-lo[0])*960/span,20+(z-lo[2])*960/span)
  sel=[t for t in tris if all(lo[k]-5<=t[:,k].mean()<=hi[k]+5 for k in [0,2])]
  for t in sorted(sel,key=lambda t:t[:,1].mean()):
   val=int(t[:,1].mean())%200+40;dr.polygon([proj(x,z)for x,y,z in t],fill=(val//2,val,min(255,val+20)),outline='#777777')
  actors=next(iter(D.glob(f'{sc}_room_{room}_0*ActorEntryList.inc.c')),None)
  if actors:
   for t in re.split(r'    \{\n',actors.read_text()):
    a=re.search(r'ACTOR_(\w+)',t);pos=re.search(r'\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\}, // pos',t)
    if a and pos:
     x,y,z=map(int,pos.groups());px,pz=proj(x,z);dr.ellipse((px-3,pz-3,px+3,pz+3),fill='red');dr.text((px,pz),a[1],fill='white')
  for x in range(int(lo[0])//100*100,int(hi[0])+1,100):dr.text(proj(x,lo[2]),str(x),fill='yellow')
  for z in range(int(lo[2])//100*100,int(hi[2])+1,100):dr.text(proj(lo[0],z),str(z),fill='yellow')
  im.save(W/f'{sc}-{room}.png')
# Ben's native OBJ, unmodified shape and texture.
s=(W/'ben-original/source/extracted/Ben/Ben.obj').read_text();verts=np.array([list(map(float,l.split()[1:]))for l in s.splitlines()if l.startswith('v ')]);uv=np.array([list(map(float,l.split()[1:]))for l in s.splitlines()if l.startswith('vt ')]);faces=[[list(map(int,c.split('/')[:2]))for c in l.split()[1:]]for l in s.splitlines()if l.startswith('f ')];im=np.array(Image.open(W/'ben-original/textures/Body.png').convert('RGB'))
out=Image.new('RGB',(600,900),'#808080');dr=ImageDraw.Draw(out)
for f in sorted(faces,key=lambda f:np.mean([verts[v-1,2]for v,u in f])):
 p=np.mean([uv[u-1]for v,u in f],0)%1;c=im[min(im.shape[0]-1,int((1-p[1])*im.shape[0])),min(im.shape[1]-1,int(p[0]*im.shape[1]))]
 dr.polygon([(300+verts[v-1,0]*160,850-verts[v-1,1]*160)for v,u in f],fill=tuple(map(int,c)))
out.save(W/'ben-front.png')

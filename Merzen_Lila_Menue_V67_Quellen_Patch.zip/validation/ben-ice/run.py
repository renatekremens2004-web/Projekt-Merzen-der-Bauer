from pathlib import Path
import os,sys,json,subprocess
from concurrent.futures import ThreadPoolExecutor
W=Path('/workspace/ben-ice');s=json.loads((W/'symbols.json').read_text())
def run(topic):
 case='ben-ice-'+topic+'-'+os.environ.get('RUN','v1')+'-direct-clip-on';limit=int(os.environ.get('FRAME_LIMIT',7000 if topic=='rise'else 1900 if topic=='ruto'else 850))
 with(W/(case+'.log')).open('w')as log:subprocess.run([str(W/'runner'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99',MESA_SHADER_CACHE_DIR=str(W/'mesa-fresh')),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=int(os.environ.get('WORKERS','2')))as pool:list(pool.map(run,sys.argv[1:]))

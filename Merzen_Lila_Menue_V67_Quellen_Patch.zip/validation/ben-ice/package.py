from pathlib import Path
import hashlib,json,re,shutil,zipfile,subprocess,sys
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/ben-ice');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts');sys.path.insert(0,str(R/'tools'))
from build_story import messages,plain,split_pages
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
romsha=sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64');report=json.loads((O/'build/pal-1.0/ben-ice-verification.json').read_text());patchreport=json.loads((W/'patch-verification.json').read_text());assert romsha==report['rom_sha256']==patchreport['target_sha256']
V=R/'validation/ben-ice';P=R/'previews/ben-ice';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True)
checks={}
for topic,ident in [('ben','706a'),('ice-fan','403d'),('ice-chum','4040'),('ice-zora','706b')]:
 p=W/f'ben-ice-{topic}-final-direct-clip-on.log';log=p.read_text();assert 'completed: 0'in log and 'RAM=4194304'in log and 'id='+ident in log
 assert not any(x in log for x in ['OBJECT_BANK_OVERFLOW','HERO_COLOAD_ERROR','UNKNOWN GBI COMMAND','Using Vertex outside buffer']);checks[topic]=log;shutil.copyfile(p,V/p.name)
for topic in ['ice-zora-child','ice-zora-en','ben-live']:
 p=W/f'ben-ice-{topic}-final-direct-clip-on.log'
 if p.exists():
  log=p.read_text();assert 'completed: 0'in log and 'RAM=4194304'in log;checks[topic]=log;shutil.copyfile(p,V/p.name)
  if topic.startswith('ice-zora-'):assert not re.search(r'NEWNPC[^\n]*zora=(?!00000000)[0-9a-f]{8}',log)
rec=json.loads((W/'rise-record-final.json').read_text());compat=json.loads((W/'sahur-video-compatibility.json').read_text());assert compat['patch_rom_sha256']==romsha and compat['video_rom_sha256']==rec['rom_sha256'];assert rec['frames']==700 and sha(A/rec['mp4'])==rec['mp4_sha256'];shutil.copyfile(W/'rise-record-final.json',V/'rise-record-final.json');shutil.copyfile(W/'rise-record-final.log',V/'rise-record-final.log')
shots=[]
def photo(source,name,case,source_sha=romsha):
 from PIL import Image
 im=Image.open(source).convert('RGB');im.save(P/name);shots.append(dict(file=name,source=str(source),case=case,rom_sha256=source_sha,unaltered_emulator_image=True))
for topic,index,name in [('ben',2,'Ben_10.png'),('ice-fan',2,'Fanboy_Eisige_Gruesse.png'),('ice-chum',2,'Chum_Chum_Hirnfrost.png'),('ice-zora',2,'Zora_Plastik_Eis.png')]:
 case=f'ben-ice-{topic}-final-direct-clip-on';photo(Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{index:03d}.png',name,case,rec['rom_sha256'])
for index,p in enumerate(rec['photos']):photo(Path(p['file']),f'Tripple_T_Auftauchen_{index+1}.png',rec['case'],rec['rom_sha256'])
# Final build checks specifically cover the newly requested red-ice mechanic.
for topic in ['ice-chum-frozen','ice-chum-melt','ice-chum-thawed']:
 path=W/f'ben-ice-{topic}-freeze-direct-clip-on.log';log=path.read_text();assert 'completed: 0'in log and 'RAM=4194304'in log
 assert not any(x in log for x in ['OBJECT_BANK_OVERFLOW','HERO_COLOAD_ERROR','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 checks[topic]=log;shutil.copyfile(path,V/path.name)
frozen=checks['ice-chum-frozen'];melt=checks['ice-chum-melt'];thawed=checks['ice-chum-thawed']
assert 'params=011e alpha=255'in frozen and 'id=4040'not in frozen and 'swch=40000000'not in frozen
assert re.search(r'flame=(?!00000000)[0-9a-f]{8}',melt)and 'alpha=195'in melt and 'swch=40000000'in melt and 'id=4040'in melt
assert 'allocated=0 ice=00000000'in thawed and 'swch=40000000'in thawed and 'id=4040'in thawed
for topic,index,name in [('ice-chum-frozen',0,'Chum_Chum_Rotes_Eis.png'),('ice-chum-melt',2,'Chum_Chum_Aufgetaut.png')]:
 case=f'ben-ice-{topic}-freeze-direct-clip-on';photo(Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{index:03d}.png',name,case)
viewcase='ben-ice-ice-chum-view-view2-direct-clip-on';view=Path('/workspace/bean-rider')/('screens-'+viewcase)/'the_legend_of_zelda-000.png'
if view.exists():photo(view,'Chum_Chum_Eingefroren_Nah.png',viewcase)
shutil.copyfile(W/'sahur-video-compatibility.json',V/'sahur-video-compatibility.json')
(P/'Aufnahmen.json').write_text(json.dumps(shots,ensure_ascii=False,indent=2)+'\n')
# Ben's exact location is documented for reproducibility, concealed in user-facing overview.
m=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());text=['# Ben und Eishöhle: neue Dialoge','','Ben steht nur in der Erwachsenen-Zeit außerhalb des Feuertempels. Seine genaue Position steht im Prüfbericht, falls Du die Überraschung auflösen möchtest.','']
for ident,label in [('706A','Ben 10'),('403D','Fanboy, Eishöhle'),('4040','Chum Chum, anderer Abschnitt der Eishöhle'),('706B','Zora, Eishöhle')]:
 text+=['## '+ident+' — '+label,'']
 for j,body in enumerate(split_pages(m[ident]['parts'][2][2])[0],1):text+=['**Seite '+str(j)+'**','']+['> '+s for s in plain(body).strip().splitlines()]+['']
text='\n'.join(text);(R/'planning/BEN_EISHOEHLE_DIALOGE.md').write_text(text);(D/'Ben_Eishoehle_Dialoge.md').write_text(text)
runtime=dict(rom_sha256=romsha,ram_bytes=4194304,completed_probes=list(checks),minimum_object_bank_remaining=min(int(x)for log in checks.values()for x in re.findall(r'remaining=(\d+)',log)),pre_ice_probes_rom_sha256=rec['rom_sha256'],final_red_ice_probes=['ice-chum-frozen','ice-chum-melt','ice-chum-thawed'],blue_fire_thaws_and_unlocks_dialog=True,permanent_switch=30,native_actor_positions=True,normal_controller_talk=True,ice_heroes_never_loaded_together=True,video=rec['mp4'],video_seconds=42.0)
(V/'runtime-verification.json').write_text(json.dumps(runtime,indent=2)+'\n')
for name in ['prepare_runtime.py','runtime_source.py','runner.c','prepare_recording.py','record_runner.c','record.py','run.py','verification.log','check_patch.js','patch-verification.json','inspect_geometry.py','package.py']:
 shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/ben-ice-verification.json',V/'ben-ice-verification.json')
doc=f'''# Ben 10 und Eishöhle: Prüfung

Gesamtpatch gegen unveränderte Vanilla Europa/PAL 1.0, MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{romsha}`. 40 MiB ROM, tatsächliche 4 MiB N64-RAM. Alle bisherigen Änderungen enthalten.

## Neue Begegnungen

Ben: bereitgestelltes FusionFall-Modell, alle 1.753 Dreiecke und ursprünglichen UVs erhalten, Höhe 70 Spieleinheiten. Vier eigene starre Gruppen; ausschließlich leichte Rotationen beim Stehen/Sprechen, keine nichtuniforme Körper- oder Gliedmaßenskalierung. CI4-Textur 64×64, native Beleuchtung/Nebel/Tiefentest. A-Gespräch, normale OC-Körperkollision, keine Angriffs- oder Trefferkollision. Nur erwachsen/deutsch. Keine zusätzlichen Objekt-Slots.

**Spoiler zur Position:** Gerudo-Trainingsarena, Raum 3, −1580/160/−2680, seitlich im Wolfos-/Steinblockraum, nicht im Eingangsraum. Die Gegner, Truhe, Steinblöcke, Schalter und versteckte Passage bleiben unverändert. Neben dem Gespräch ist genügend Platz zum Vorbeigehen. Die lokale ruhige Gesprächsprobe beginnt nach dem Räumen der Gegner; die zusätzliche reguläre Gegnerprobe verwendet die ungeräumte Kammer.

Fanboy: Eishöhle Raum 9, 1000/22/−2500, auf dem festen unteren Boden im Blaue-Flamme-Raum. 1.463 Dreiecke, Höhe 78, identische Quelle/Proportionen/Atlas wie in Wald- und Wassertempel. Nach erster Sichtprobe von der Eiswand abgerückt. Chum Chum: getrennt im Rückweg-Korridor Raum 10, −545/199/1450, Bodenhöhe ungefähr 198,2; 1.573 Dreiecke, Höhe 49, dieselbe bereits korrigierte Augenfassung. Chum ist zunächst unbeweglich in kleinem rotem Eis eingefroren. Ohne Auftauen kein Gespräch und keine Zielmarkierung. Blaues Feuer löst die originale native Schmelzanimation aus; nach deren Abschluß schaltet der permanente Szenenschalter 30 Gespräch und Bewegungen frei. Bei Rückkehr mit gesetztem Schalter wird kein Eis mehr erzeugt. Nativer RED_ICE_SMALL, Parameter 0x011E, Radius 33, Höhe 54; Chums eigene Breite rund 48 und Höhe 49 passen hinein. OBJECT_ICE_OBJECTS ist bereits im Raum vorhanden, kein weiterer Objekt-Slot. Das Stück Eis steht seitlich im breiteren Abschnitt des Korridors, es ersetzt keine Tür oder Rätselbarriere. Kein Eingriff in den Eis-Akteur. Schlägt die native Eis-Allokation fehl, bleibt der NPC frei ansprechbar. Die beiden NPCs stehen in keinem gemeinsam geladenen angrenzenden Raumpaar. Ihr Verhalten und ihre Sprüche in den anderen Tempeln bleiben erhalten.

Zora: Raum 11, 1170/−71/350, frei vor dem Kompaß-/Herzteilbereich. Originales En_Zo-Modell mit Originalanimation, Blinzeln, Kopfverfolgung, Schatten und Gespräch. Genau ein zusätzlicher OBJECT_ZO-Eintrag; private Parameter 0x7FC7. Nur erwachsen/deutsch. Kein Händler, keine Quest- oder Inventaränderung. Gesprächsnummer vor Maskenreaktion gewählt. Alle übrigen Zoras behalten ihr bisheriges Verhalten.

## Erhalt des Spiels

Nur vier bisher freie deutsche Textplatzhalter belegt: 403D, 4040, 706A, 706B. Alle bisherigen deutschen Texte, alle anderen Sprachen und alle Textbox-Kopfdaten gegenüber dem vorigen Build unverändert. Alte Rechtschreibung, Originaltempo und manuell bestätigte Seiten. Insgesamt 1.030 eigene Nachrichten. Alle kompilierten Roh-/Seitenpuffer geprüft.

Sämtliche 1.509 komprimierten Segmente gegen den unkomprimierten Neubau und CIC-6105-Prüfsumme geprüft. Alle ursprünglichen object_*-Segmente bytegleich, einschließlich Sahur, Thaddäus und sämtlicher anderer Modelle; Boß-Overlays höchstens geprüfte Linker-Adressen verändert. Sahurs Actor, Skelett, Animationen, Kokiri-Szene und Raum bleiben gegenüber dem vorigen Build bytegleich. Alle anderen früheren Auftritte und Dialoge erhalten. In den neuen Räumen nur Akteure/Modelle und der einzelne Zora-Objekteintrag ergänzt. Native Kollision, Wasser, Eisfallen, Rätselschalter, Truhen, Gegner, Sheik-Sequenz, Türen und Ausgänge unverändert. Bestehende alternative Raum-Header bleiben unverändert.

Der bestehende Elf_Msg2-Helfer erhält Szenen-/Raumzuordnung, Modell, eigene Drehpunkte, Textnummern und die private Eissperre für Chum. Initialisierung des OC-Kolliders erfolgt vor dem Entfernen in Kinder-/Fremdsprachenfassung, damit Zerstörung sicher bleibt. Bei En_Zo ändern sich nur die private Sprach-/Altersprüfung und die Textauswahl. Für Chum kommt genau ein privater Einfrier-Helfer hinzu. Ein reserviertes Heimrotationsfeld merkt nur erfolgreiche Eis-Allokation; keine fremden Akteurspointer werden gespeichert. Alle übrigen Funktionen identisch zur vorigen Fassung.

## Laufzeit und Film

Vor dem nachträglichen Eiswunsch die vier Gespräche im Emulator erfolgreich geöffnet und durchgeblättert, tatsächliche 4 MiB. Danach im finalen Build drei gezielte Eisproben: ohne blaues Feuer bleibt der Block erhalten und kein Gespräch öffnet; echtes Flaschen-C-Tasten-Ausgießen erzeugt blaues Feuer, schmilzt das Eis (Alpha 255 über 195 auf 0), setzt Schalter 30 und öffnet anschließend 4040; mit vorbereitetem Rückkehrzustand/gesetztem Schalter kein Eis und normales Gespräch. Keine zur Demonstration gesetzten Laufzeitschalter oder erzeugten Effekt-Akteure; Auftauen geschieht durch normale Controller-Eingaben. Kein beobachteter Absturz, Objektpufferüberlauf oder ungültiger Grafikbefehl in den dokumentierten Proben. Minimal verbleibender Objektpuffer in den Proben: {runtime['minimum_object_bank_remaining']:,} Bytes. Native Platzierung/Kamera, keine für Bilder versetzten NPCs. Lokale Start-Spielstände stellen die Kapitel für Tests bereit; anschließend normale Controller-Eingaben.

`Tripple_T_Aus_dem_Boden.mp4`: 42 Sekunden / 700 fortlaufende PAL-Frames, 640×480 H.264, 50/3 fps, ohne Ton. Unmittelbar vor dem letzten roten-Eis-Nachtrag aufgenommen, vom Szenenbeginn im Kokiri-Wald über das native Auftauchen bis zum Anfang seiner Rede. Die vorausgehende Amulettsequenz wird lokal regulär durchlaufen. Keine manipulierten Kameras oder Animationszustände. Tanz weiterhin erst nach Ende der nativen Cutscene. Modell, Akteur, Skelett/Animationen, Kokiri-Szene und Raum sind gegen den finalen Patch bytegleich geprüft; Nachweis mit beiden SHA256 in sahur-video-compatibility.json. Der längere komplette Auftritt und der Tanzclip der vorigen Veröffentlichung bleiben verfügbar.

RomPatcher.js mit aktivierter Quellvalidierung erzeugt bytegenau die getestete ROM. Kein kompletter Durchlauf oder echter N64-Hardwaretest in diesem Schritt. ROM, Spielstände, Savestates, RAM-Abzüge und ausführbare Dateien bleiben privat. Einzelne Nahaufnahmen zeigen schwarze Aussparungen an Wand-/Deckenrändern; deren Ursache wurde in diesen neuen Räumen nicht gesondert gegen Vanilla geprüft. Ihre ursprüngliche Raumgeometrie und Kollision bleiben unverändert.

## Neubau

Nach den bisherigen Buildern und zuletzt `build_sahur_shuffle.py`/`build_water_comic_heroes.py` den neuen letzten Schritt `python3 tools/build_ben_ice.py <oot>` ausführen. Vorbereitete Modell-JSONs/Texturen und die benötigten Quell-Snapshots enthalten. Für Ben-Neuableitung: `python3 tools/export_ben10.py models/ben10/source/Ben.obj`. Normal komprimieren und BPS gegen Vanilla erzeugen. `verify_ben_ice.py` benötigt zusätzlich die privat gespeicherte vorige ROM als Vergleich.
'''
(R/'TESTING_BEN_EISHOEHLE.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Ben_Eishoehle.bps';shutil.copyfile(patch,R/'patches'/patch.name)
heading='# Ben 10 und eisige Slushie-Helden'
p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Dialoge](planning/BEN_EISHOEHLE_DIALOGE.md) · [Prüfung](TESTING_BEN_EISHOEHLE.md)\n\nBen in der Erwachsenen-Zeit außerhalb des Feuertempels. Fanboy/Chum an getrennten Stellen in der Eishöhle; Chum muß aus rotem Eis aufgetaut werden. Dazu ein Zora mit Plastik-Eis-Expertise. Neuer letzter Builder: `build_ben_ice.py`. Alle früheren Änderungen enthalten.\n\n'+p.read_text())
p=R/'story/LEITLINIEN.md';before=p.read_text();p.write_text(before if 'permanenter freier Schalter 30'in before else before+'\n\nBen/Eishöhle: Chum erst mit blauem Feuer aus kleinem rotem Eis befreien; permanenter freier Schalter 30. 706A Ben, 403D Fanboy, 4040 Chum, 706B Plastik-Zora. Wald-/Wasser-Comic-Gags bleiben erhalten. Letzter Builder build_ben_ice.py nach build_water_comic_heroes.py. Ben nur erwachsen außerhalb Feuertempel; eigene Proportionen/leichte Rotationen, Ice-Helden getrennt, keine Rätselwege blockieren.\n')
archive=A/'Merzen_Ben_Eishoehle_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);allowed_original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  allowed_original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  allowed_original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in['water-comic-heroes','ben-ice']and p.suffix in ['.c','.h']
  if not p.is_file()or(any(x in exclude for x in rel.parts)and not allowed_original)or p.suffix.lower()not in suffixes:continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='ben-ice':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st','.mp4'}for n in z.namelist())
instruction=A/'Anleitung_Ben_Eishoehle.txt';instruction.write_text('Gesamtpatch mit Ben 10, Fanboy/Chum in der Eishöhle und Plastik-Eis-Zora. Alle bisherigen Änderungen enthalten.\n\nMit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte, unveränderte Europa/PAL-1.0-ROM anwenden, nicht auf eine bereits gepatchte Fassung. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände verwenden; alte Emulator-Savestates können alte Overlays/Modelle im RAM enthalten. Video ohne Ton, tatsächliche 4 MiB.\n')
files=[patch,archive,instruction,D/'Ben_Eishoehle_Dialoge.md',A/rec['mp4']]
for p in [patch,archive,instruction,A/rec['mp4']]:shutil.copyfile(p,D/p.name)
sums=D/'SHA256SUMS_Ben_Eishoehle.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files));G=D/'Ben_Eishoehle_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Tripple T kommt aus dem Boden: 42 s](Tripple_T_Aus_dem_Boden.mp4?raw=true) · [Neue Dialoge](Ben_Eishoehle_Dialoge.md)\n\n[Bilder und Prüfung](Ben_Eishoehle_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nBen 10 in der Erwachsenen-Zeit, außerhalb des Feuertempels. Fanboy und Chum getrennt in der Eishöhle. Chum muß mit blauem Feuer aus rotem Eis befreit werden. Dazu ein Zora über Plastik-Eis. Alle bisherigen Änderungen enthalten. BPS auf unveränderte Vanilla PAL 1.0 anwenden. Video ohne Ton, 4 MiB geprüft.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=romsha,files=[p.name for p in files+[sums]],runtime=runtime),indent=2)+'\n');print('Packaged',romsha,'source ZIP',archive.stat().st_size,'bytes')

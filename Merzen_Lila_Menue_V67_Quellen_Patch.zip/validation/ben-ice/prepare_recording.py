from pathlib import Path
import subprocess
W=Path('/workspace/ben-ice');s=(W/'runner.c').read_text().replace('static void onframe(unsigned f){','static void baseframe(unsigned f){')
capture=r'''
static FILE* videoPipe=NULL;
static unsigned capturePending=0,videoCount=0,videoFirst=0,videoLast=0;
static void capture_render(void) {
 static unsigned char* pixels=NULL;
 if(!capturePending)return;
 capturePending=0;
 if(!pixels)pixels=malloc(640*480*3);
 if(!pixels || CoreDoCommand(M64CMD_READ_SCREEN,0,pixels))exit(94);
 if(fwrite(pixels,640*480*3,1,videoPipe)!=1)exit(94);
}
static void finish_video(void) {
 if(videoPipe){int result=pclose(videoPipe);videoPipe=NULL;if(result){fprintf(stderr,"VIDEO_ENCODER_FAILED %d\n",result);exit(94);}}
}
static void onframe(unsigned f) {
 static unsigned started=0,done=0,stopQueued=0,sawText=0,sawRuto=0,sawRise=0,after=0;
 baseframe(f);
 if(stopQueued){if(!capturePending)CoreDoCommand(M64CMD_STOP,0,NULL);return;}
 if(f<550)return;
 findplay();if(!play)return;
 unsigned scene=DebugMemRead16(play+0xa4),rutoCase=strstr(scenario,"ruto")!=NULL,danceCase=strstr(scenario,"dance-still")!=NULL;
 uint32_t sprout=actor(0xd3),ruto=actor(0xd2),m=play+0x20d8;
 unsigned id=DebugMemRead16(m+0xe2f8),cs=DebugMemRead8(play+0x1d6c),rising=sprout?DebugMemRead8(sprout+0x18b):255;
 if(id==0x403e)sawText=1;
 if(ruto)sawRuto=1;
 if(sprout && rising==1)sawRise=1;
 if(!started && ((rutoCase && scene==5 && ruto && f>=600) || (!rutoCase && scene==0x55 && sprout && (!danceCase || f>=600)))) {
  char command[1200];const char* name=rutoCase?"Thaddaeus_Wassertempel_Animationen.mp4":danceCase?"Tripple_T_Tanz.mp4":"Tripple_T_Aus_dem_Boden.mp4";
  snprintf(command,sizeof(command),"ffmpeg -y -v error -f rawvideo -pixel_format rgb24 -video_size 640x480 -framerate 50/3 -i pipe:0 -vf vflip -an -c:v libx264 -threads 2 -preset medium -crf 18 -pix_fmt yuv420p -movflags +faststart /workspace/artifacts/%s",name);
  videoPipe=popen(command,"w");if(!videoPipe)exit(94);
  started=1;videoFirst=f;printf("VIDEO_START frame=%u scene=%x file=%s\n",f,scene,name);
 }
 if(!started)return;
 if((rutoCase && sawText && sawRuto && !ruto) || (!rutoCase && sawRise && sprout && cs==0 && rising==0))after++;
 if((danceCase && videoCount>=400) || (!danceCase && after>=(rutoCase?90:360)))done=1;
 if(!rutoCase && !danceCase && videoCount>=700)done=1;
 if(done){printf("VIDEO_END first=%u last_exclusive=%u frames=%u sawText=%u sawRise=%u\n",videoFirst,f,videoCount,sawText,sawRise);stopQueued=1;return;}
 if(capturePending)exit(94);
 capturePending=1;videoLast=f;videoCount++;
 if(f%200==0){printf("VIDEO_PHOTO frame=%u relative=%u\n",f,f-videoFirst);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
}
'''
at=s.index('\nstatic void setting(');s=s[:at]+'\n'+capture+s[at:]
s=s.replace('if(i==3)buttons=dlsym(plugin,"TestSetButtons");','if(i==3){buttons=dlsym(plugin,"TestSetButtons");void(*hook)(void(*)(void))=dlsym(plugin,"TestSetRenderCapture");if(!hook)return 95;hook(capture_render);}')
s=s.replace(' printf("SCENARIO %s completed: %d\\n",scenario,r);',' finish_video();printf("SCENARIO %s completed: %d\\n",scenario,r);')
(W/'record_runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'record_runner.c'),'-o',str(W/'record_runner.new'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
(W/'record_runner.new').replace(W/'record_runner')
print('Prepared continuous render capture; native inputs/actors, no preview repositioning.')

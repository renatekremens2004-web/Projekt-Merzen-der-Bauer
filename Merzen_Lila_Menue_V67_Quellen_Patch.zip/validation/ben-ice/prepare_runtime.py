from pathlib import Path
import re
W=Path('/workspace/ben-ice')
s=Path('/workspace/sahur-dance/prepare_runtime.py').read_text().replace("W=Path('/workspace/sahur-dance')","W=Path('/workspace/ben-ice')")
s=s.replace('sprout=actor(0xd3),ruto=actor(0xd2);','sprout=actor(0xd3),ruto=actor(0xd2),ben=actor_type(0x173,0),zora=actor(0x1ce);')
s=s.replace('   if(fan&&chum)','   uint32_t ice=actor(0xef),flame=actor(0xf0);printf("FREEZE f=%u allocated=%u ice=%08x params=%04x alpha=%d flame=%08x swch=%08x\\n",f,chum?DebugMemRead16(chum+0x18):0,ice,ice?DebugMemRead16(ice+0x1c):0,ice?(int16_t)DebugMemRead16(ice+0x1f0):0,flame,r32(play+0x1d28));\n   if(fan&&chum)')
s=s.replace('  if(strstr(scenario,"still"))value=0;', '  if(strstr(scenario,"ice-chum-melt") && mode==0 && f<250)value=(f>=165 && f<169)?0x200:0;\n  if(strstr(scenario,"still"))value=0;')
s=s.replace('  if(strstr(scenario,"still"))value=0;', '  if(strstr(scenario,"still"))value=0;\n  if(strstr(scenario,"ice-chum-view")){value=(f>=60 && f<64)?0x800:(f>=80 && f<90)?0x20000000:0;}')
s+=r'''
fixture('ben',0x8,0xb,3,(-1495.,160.,-2680.),-16384,cleared=True)
fixture('ben-live',0x8,0xb,3,(-1495.,160.,-2680.),-16384)
fixture('ice-fan',0x88,9,9,(1000.,22.,-2420.),-32768)
fixture('ice-chum',0x88,9,10,(-475.,201.,1450.),-16384)
fixture('ice-zora',0x88,9,11,(1170.,-71.,398.),-32768)
for topic in ['ben','ice-fan','ice-chum','ice-zora']:
 b=bytearray((W/(topic+'.save')).read_bytes());b[0x1409]=0;(W/(topic+'-en.save')).write_bytes(b)
 b=bytearray((W/(topic+'.save')).read_bytes());struct.pack_into('>I',b,4,1);struct.pack_into('>H',b,0x70,0x1111);(W/(topic+'-child.save')).write_bytes(b)
'''
# Save generated preparation source, then execute with its imports/globals intact.
(W/'runtime_source.py').write_text(s);exec(compile(s,str(W/'runtime_source.py'),'exec'))
r=Path('/workspace/sahur-dance/run.py').read_text().replace('/workspace/sahur-dance','/workspace/ben-ice').replace("'sahur-comic-'","'ben-ice-'");(W/'run.py').write_text(r)

# Both frozen and melt tests start from a real bottle item and the native unset
# permanent switch. The thawed fixture independently verifies revisit behavior.
b=bytearray((W/'ice-chum.save').read_bytes());struct.pack_into('>f',b,0x1368,-492.);b[0x86]=0x1c;b[0x69]=0x1c;b[0x6c]=18;b[0x4a:0x54]=b[0x68:0x72]
for topic in ['ice-chum-frozen','ice-chum-melt']:(W/(topic+'.save')).write_bytes(b)
struct.pack_into('>I',b,0xd4+9*0x1c+4,1<<30);(W/'ice-chum-thawed.save').write_bytes(b)

b=bytearray((W/'ice-chum-frozen.save').read_bytes());struct.pack_into('>f',b,0x1368,-450.);(W/'ice-chum-view.save').write_bytes(b)

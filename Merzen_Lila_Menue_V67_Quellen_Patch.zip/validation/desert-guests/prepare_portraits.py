from pathlib import Path
import struct
W=Path('/workspace/desert-guests')
for topic,base,pos,yaw in [('mackey-portrait','mackey',(-90,0,20),-9344)]:
 s=bytearray((W/(base+'.save')).read_bytes());struct.pack_into('>fffh',s,0x1368,*pos,yaw);(W/(topic+'.save')).write_bytes(s)

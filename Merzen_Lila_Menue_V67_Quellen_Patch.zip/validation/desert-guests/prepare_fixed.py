from pathlib import Path
import subprocess,shutil
W=Path('/workspace/desert-guests')
s=(W/'runner.c').read_text().replace('if(strstr(scenario,"still"))value=0;','if(strstr(scenario,"still"))value=0;\n  if(strstr(scenario,"mackey-fixed-still")&&f==50)value=0x800;\n  if(strstr(scenario,"mackey-fixed-still")&&f==100)printf("HOUSE_CAMERA setting=%x bg=%d viewpoint=%d\\n",DebugMemRead16(play+0x1e0+0x142),(short)DebugMemRead16(play+0x1e0+0x148),DebugMemRead8(play+0x1242b));')
(W/'fixed-runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'fixed-runner.c'),'-o',str(W/'fixed-runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
shutil.copyfile(W/'mackey-portrait.save',W/'mackey-fixed-still.save')
s=(W/'run.py').read_text().replace("W/'runner'","W/'fixed-runner'");(W/'run_fixed.py').write_text(s)

from pathlib import Path
import json,hashlib,re,shutil,zipfile
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/desert-guests');A=Path('/workspace/artifacts');D=Path('/workspace/bean-download-delivery')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v=json.loads((O/'build/pal-1.0/desert-guests-verification.json').read_text());h=v['rom_sha256'];assert h==sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64')==json.loads((W/'patch-verification.json').read_text())['target_sha256']
V=R/'validation/desert-guests';P=R/'previews/desert-guests';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True);logs={}
cases=['desert-marty','desert-doc','castle-marty','meowth','jimmy','mackey','jimmy-night','desert-child-still','mackey-child-still','worst-still','mackey-fixed-still','mackey-portrait']
for topic in cases:
 p=W/f'guests-{topic}-native-direct-clip-on.log';s=p.read_text();assert h in s and 'completed: 0'in s and 'RAM=4194304'in s,p
 assert not any(x in s for x in ['OVERFLOW','GFX_POOL_CORRUPT','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 assert all(int(n)==0 for n in re.findall(r'HEAP f=\d+ failures=(\d+)',s)),p
 logs[topic]=s;shutil.copyfile(p,V/p.name)
for topic in ['desert-marty','desert-doc']:
 for ident in ['71bf','71c0','71c1','71c2']:assert f'id={ident}'in logs[topic],(topic,ident)
 assert 'BTTF_CONVERSATION_FINISHED'in logs[topic]
for ident in ['71b4','71b5','71b6','71b7']:assert f'id={ident}'in logs['castle-marty']
assert 'BTTF_CONVERSATION_FINISHED'in logs['castle-marty']
for topic,ident in [('meowth','71c3'),('jimmy','71c4'),('mackey','71c5')]:assert re.search(rf'TEXT .*id={ident} .*mode=35',logs[topic]),topic
assert 'id=71c4'in logs['jimmy-night']
assert 'HOUSE_CAMERA setting=19 bg=0 viewpoint=1'in logs['mackey-fixed-still']
assert re.search(r'BTTF f=200 marty=00000000 doc=00000000 car=00000000',logs['desert-child-still'])
assert re.search(r'GUEST f=200 type=15 actor=00000000',logs['mackey-child-still'])
heap=min(map(int,re.findall(r'largest=(\d+)','\n'.join(logs.values()))));bank=min(map(int,re.findall(r'OBJECT_BANK[^\n]*remaining=(\d+)','\n'.join(logs.values()))));assert heap>=16000
runtime=dict(rom_sha256=h,actual_ram_bytes=4194304,cases=cases,native_allocation_failures=0,minimum_largest_free_arena_bytes=heap,minimum_object_bank_free_bytes=bank,desert_shared_conversation_completed_twice=True,castle_conversation_unchanged_and_completed=True,all_new_npcs_reached_final_manual_page=True,child_desert_and_house_guests_absent=True)
(W/'runtime-verification.json').write_text(json.dumps(runtime,indent=2)+'\n')
for name in ['prepare_runtime.py','prepare_fixed.py','prepare_portraits.py','fixed-runner.c','run_fixed.py','runner.c','run.py','object_budget.py','object-budget.json','runtime-verification.json','verification.log','models.json','check_patch.js','patch-verification.json','package.py','selected-images.json']:shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/desert-guests-verification.json',V/'desert-guests-verification.json')
images=json.loads((W/'selected-images.json').read_text());photos=[]
for topic,indices in images.items():
 root=Path('/workspace/bean-rider')/f'screens-guests-{topic}-native-direct-clip-on'
 for n,idx in enumerate(indices):
  src=root/f'the_legend_of_zelda-{idx:03d}.png';name=topic.title()+('_Dialog'if n else'_Ingame')+'.png';shutil.copyfile(src,P/name);photos.append(dict(file=name,source=str(src),rom_sha256=h,unaltered_emulator_image=True))
(P/'Aufnahmen.json').write_text(json.dumps(photos,indent=2)+'\n')
text='\n\n'.join('**'+ident+'**\n\n'+'\n\n'.join(e['pages'])for ident,e in json.loads((R/'story/desert_guests_de.json').read_text())['messages'].items())
doc=f'''# Wüstengäste, Jimmy und Mr. Mackey

Kumulativer Gesamtpatch auf unveränderte Europa/PAL 1.0. Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`; Ziel-SHA256 `{h}`. Alle bisherigen Änderungen einschließlich Mystery Inc., Mystery Machine, Kenny und Naboo-Starfighter enthalten. BPS mit RomPatcher.js anwenden, normale Spielstände statt alter Emulator-Savestates laden. Deutsche Sprachfassung.

## Marty, Doc und Zeitreise

**Wüste ausschließlich als Erwachsener, Schloß ausschließlich als Kind.** Aus ihrer eigenen Perspektive treffen Marty und Doc Link zuerst als Erwachsenen am Geistertempel. Beide nennen ihn im neuen gemeinsamen Dialog Fremder. Marty schimpft über Merz, Doc beruhigt ihn und erinnert an die Mission. Am Schloß erkennt Marty später den jungen Link wieder, obwohl er bis dahin dessen ältere Version getroffen hatte. Der vorhandene Schloßdialog 71B4–71B7 bleibt in allen Sprachen bytegleich.

In der Wüste stehen Marty bei −100/−32/−200 und Doc bei 20/−32/−200, der DeLorean parkt seitlich bei −160/−31/−430. Alle vier Radpunkte liegen auf dem flachen Sandboden bei Y=−32. Tempelzugang und Warpstelle bleiben frei. Eine Ansprache beider Gesprächspartner startet dieselbe manuell bestätigte vierteilige Unterhaltung 71BF–71C2; kein Zeitreise-Auslöser und keine Quest-Funktion. Die Wüstenszene verwendet das bereits vorhandene OBJECT_BTTF, keine doppelten Marty-/Doc-/Autogeometrien.

An **beiden** Auftritten haben die drei Modelle jetzt gleichmäßig 85 Prozent ihrer bisherigen Größe: Marty rund **69,9**, Doc **77,5** Spieleinheiten hoch; DeLorean **170** lang und **51,4** hoch. Originale Körperproportionen bleiben erhalten. Fokus, Zylinder und Bodenschatten entsprechend angepaßt. Eigene Kopf-, Schulter- und Handgesten: versetzte Leerlaufphasen, kleine Gewichtsverlagerung, Nicken und unterschiedlich starke Armgesten beim jeweiligen Sprecher. Sanfte Wendung zu Link im Gespräch. Keine Skalierungsanimation, keine fremde Figur als Skelettvorlage.

## Neue Figuren

**Mauzi:** Pokémon Stadium 2 (N64), 699 Dreiecke, 24 Einheiten hoch. Nur als Erwachsener in Geistertempelraum 19, am freien Rand der unteren Treppenplattform bei 2050/843/510. Später Erwachsenenabschnitt, abseits von Truhen und Treppenweg. Kopf, Ohren/Münze/Schnurrhaare und Pfoten bleiben original; Arme einmal um eigene Schultern abgesenkt, danach kleine starre Gesten. Kein Gegnerverhalten, kein tatsächliches Stehlen von Rubinen.

**Jimmy:** Jimmy Neutron: Boy Genius (PC), originale 802 Dreiecke, 47 Einheiten einschließlich Haarlocke. Erwachsener äußerer Farmhof bei 850/0/−2850, außerhalb der Pferderennbahn. Tags und nachts vorhanden; keine Änderungen an Rennen, Epona, Toren, Luigi, Talon oder Malon. Besser aufgelöster Ausschnitt des eigenen Gesichtsatlasses; entspannte eigene Arme und kleine neugierige Kopf-/Handbewegungen. Die Erfindungen sind Dialoggags.

**Mr. Mackey:** South Park (N64), 266 Dreiecke, 74 Einheiten hoch. Nur als Erwachsener im Gästehaus in Kakariko bei −140/0/60. Originaler großer Kopf bleibt proportional, Arme abgesenkt, kleine nickende Gesten und sanfte Wendung zu Link. Normales Ansprechen; Kinderinstanz wird sauber entfernt. Die Figur steht abseits der zentralen Drehkamera und erscheint sowohl in der normalen Drehansicht als auch nach C-oben in der festen Hausansicht.

Drei eigene Objektdateien, jeweils nur im eigenen Raum bzw. den beiden Erwachsenen-Farmheadern geladen. Neue IDs am Ende der Objekttabelle, vorhandene IDs unverändert. Native Beleuchtung, Nebel und Tiefentest, kleine Bodenschatten. Zylinderradien 7/10/13, keine Gegner-/Angriffskollision. Die Körperhöhe wird mit dem erwachsenen Link und normalen NPCs im Spiel verglichen; Jimmy und Mauzi bleiben sichtbar kleiner als Erwachsene. Vier eigene starre Gruppen je Figur, ohne dynamische Netzstreckung.

## Dialoge

Neue private IDs 71BF–71C5; normale A-bestätigte Seiten, keine festen Lesezeiten. Alle bisherigen Nachrichten in allen drei PAL-Sprachen als Quelle und kompiliert unverändert.

{text}

## Prüfungen

Zwölf gezielte Emulatorproben mit echten 4 MiB: Wüstengespräch aus zwei Annäherungsrichtungen bis zum normalen Ende, unveränderte Schloßunterhaltung mit neuer Bewegung/Größe, Mauzi, Jimmy und Mackey bis zur letzten Seite, Jimmy nachts, kein Wüstenauftritt als Kind, kein Mackey als Kind, speicherkritischster Schattentempelraum 9 sowie beide nativen Kameraperspektiven des Gästehauses und eine zusätzliche seitliche Aufnahme von Mackey. Altersgrenzen aller drei neuen Figuren zusätzlich im gemeinsamen Init geprüft; Jimmy steht ausschließlich in den Erwachsenen-Tag-/Nachtlisten. Reale Controller-Eingaben, keine verschobenen Produktions-Actors oder nachbearbeiteten Screenshots. Testspielstände überspringen nur den Weg zu den Szenen. Keine fehlgeschlagenen nativen Speicherbelegungen, Grafikpufferüberläufe oder beschädigten GfxPool-Marken. Mindestreserve in diesen Proben: größte freie zusammenhängende Arena-Fläche {heap:,} Byte; Objektpuffer {bank:,} Byte. Kein vollständiger Durchlauf oder echter Hardwaretest.

Statischer Objekt-Audit der betroffenen Header mit ihrem tatsächlich benutzten Link-Alter und nativen Keep-Modellen: alle innerhalb des unveränderten 1.019.904-Byte-Puffers und maximal 19 Slots. Nicht benutzte Erwachsenen-/Kind-Kombinationen sowie unveränderte Credits-Header werden nicht als spielbare Räume bewertet. Die größte geprüfte Objektliste bleibt der frühere Schloßauftritt mit 992.224 Byte; Wüste 956.928 Byte. Keine Vergrößerung von Spiel-/Raumspeicherzuteilungen. Nur zusätzliche Actor-/Objekt-Einträge, native Kollision und Rätsellogik unverändert.

1.520 komprimierte Segmente gegen den unkomprimierten Build und CIC-6105-Prüfsumme geprüft, 3.664 Kernsymbole unverändert oder ausschließlich durch echte Linker-Relokationen verschoben. ElfMsg2: vier neue streng auf die neuen Szenen begrenzte Funktionen, Init/Update/Destroy-Zweige und überarbeitete BTTF-Helfer; sämtliche anderen bisherigen Sonderfunktionen unverändert. Alle 1.049 eigenen Texte passen in die nativen Textpuffer. Neue Nachrichten besitzen korrekte Folge-DMA-Zeiger in allen drei Sprachen. BPS mit RomPatcher.js und aktiver Quellvalidierung angewandt: bytegleich zur geprüften Ziel-ROM.

**Letzter Builder:** `python3 tools/build_desert_guests.py /pfad/zur/oot-decomp` nach `build_mystery_machine.py`. Anschließend regulärer PAL-1.0-Bau und Kompression. Vorbereitete JSONs und models-Texturen genügen. Optionaler Original-Export `python3 tools/export_desert_guests.py WORK`, Nutzerdateien unter WORK/input/meowth, jimmy, mackey. Sichere Originalmodelle und Quellenhinweise unter models/KEY/source; Builder-Ausgangszustände unter tools/originals/desert-guests. Quellenpaket enthält keine ROMs, Saves, Savestates, RAM-Abzüge oder ausführbare Programme. Bilder sind unveränderte echte Emulatoraufnahmen der angegebenen Ziel-ROM.
'''
(R/'TESTING_DESERT_GUESTS.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Wuesten_Gaeste.bps';shutil.copyfile(patch,R/'patches'/patch.name);heading='# Wüstengäste, Jimmy und Mr. Mackey'
p=R/'README.md';p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Prüfung und Dialoge](TESTING_DESERT_GUESTS.md) · [Bilder](previews/desert-guests/)\n\nErste Marty-/Doc-Begegnung beim erwachsenen Geistertempel, Mauzi im Erwachsenentempel, Jimmy auf der erwachsenen Farm, Mackey im erwachsenen Gästehaus in Kakariko. BTTF-Bewegungen und einheitliche Größen auch am jungen Schloß verbessert. Alle bisherigen Änderungen enthalten. Letzter Builder build_desert_guests.py nach build_mystery_machine.py.\n\n'+p.read_text())
archive=A/'Merzen_Wuesten_Gaeste_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in['water-comic-heroes','ben-ice','jabba','bttf','kenny','xwing','mystery-inc','mystery-machine','desert-guests']and(p.suffix in['.c','.h']or rel.parts[-2:]==('spec','spec'))
  if not p.is_file()or(any(q in exclude for q in rel.parts)and not original)or(p.suffix.lower()not in suffixes and not original):continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='desert-guests':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.o','.so','.st','.exe','.mp4','.glb'}for n in z.namelist());assert 'tools/originals/desert-guests/spec/spec'in z.namelist()
instruction=A/'Anleitung_Wuesten_Gaeste.txt';instruction.write_text('Kumulativer Gesamtpatch mit allen bisherigen Änderungen. Neu: erwachsene Wüstenbegegnung mit Marty/Doc/DeLorean, Mauzi im Geistertempel, Jimmy auf der Farm, Mackey im Gästehaus in Kakariko. Bewegungen und Größen von BTTF auch am jungen Schloß verbessert.\n\nBPS mit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände laden; alte Emulator-Savestates vermeiden. Deutsche Sprachfassung.\n')
for p in [patch,archive,instruction]:shutil.copyfile(p,D/p.name)
G=D/'Wuesten_Gaeste_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
files=[D/p.name for p in[patch,archive,instruction]];sums=D/'SHA256SUMS_Wuesten_Gaeste.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files));files.append(sums)
p=D/'README.md';p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Bilder, Dialoge und Prüfung](Wuesten_Gaeste_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nWüstenbegegnung ausschließlich als Erwachsener, Schloßauftritt ausschließlich als Kind. Mauzi im erwachsenen Geistertempel, Jimmy auf der erwachsenen Farm und Mackey im erwachsenen Gästehaus in Kakariko. BTTF-Gesten und Größen an beiden Auftritten verbessert. Alle bisherigen Änderungen enthalten. Auf unveränderte Vanilla PAL 1.0 anwenden. Zwölf gezielte Proben mit 4 MiB, kein vollständiger Durchlauf.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=h,files=[p.name for p in files],runtime=runtime),indent=2)+'\n');print('Packaged desert guests',h,'source bytes',archive.stat().st_size)

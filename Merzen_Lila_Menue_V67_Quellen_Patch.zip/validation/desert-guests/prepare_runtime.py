from pathlib import Path
import re,json,struct,subprocess,shutil
W=Path('/workspace/desert-guests');O=Path('/workspace/oot-burns-pal')
def symbols(p):return{n:int(a,16)for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\s*$',p.read_text(),re.M)}
a=symbols(W/'baseline/build/pal-1.0/oot-pal-1.0.map');b=symbols(O/'build/pal-1.0/oot-pal-1.0.map');(W/'symbols.json').write_text(json.dumps(b));s=Path('/workspace/mystery-inc/runner.c').read_text().replace('obj<0x19a','obj<0x19d')
for n in ['gGameStateOverlayTable','sZeldaArena','gObjectTable']:s=re.sub('0x'+format(a[n],'x')+r'\b',hex(b[n]),s)
s=s.replace('if(id>=0x71b4&&id<=0x71b7&&mode)', 'if(((id>=0x71b4&&id<=0x71b7)||(id>=0x71bf&&id<=0x71c2))&&mode)').replace('if(id==0x71b7)bttLast=1;', 'if(id==0x71b7||id==0x71c2)bttLast=1;')
extra=r'''
  if(f%50==0)for(int type=13;type<=15;type++){
    uint32_t a=actor_type(0x173,type);
    printf("GUEST f=%u type=%d actor=%08x pos=(%.1f %.1f %.1f) floor=%.1f draw=%08x\n",f,type,a,a?rf(a+0x24):0,a?rf(a+0x28):0,a?rf(a+0x2c):0,a?rf(a+0x80):0,a?r32(a+0x134):0);
  }
'''
s=s.replace('  if(f%50==0){\n   uint32_t fan=',extra+'  if(f%50==0){\n   uint32_t fan=');(W/'runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
base=Path('/workspace/pepsiman-water/man-30.save').read_bytes()
for name,entrance,room,pos,yaw,age,night in [('desert-marty',0x1e1,0,(-100,-32,-120),-32768,0,False),('desert-doc',0x1e1,0,(20,-32,-120),-32768,0,False),('desert-child-still',0x1e1,0,(-100,-32,-120),-32768,1,False),('meowth',0x82,19,(1980,843,510),16384,0,False),('jimmy',0x157,0,(850,0,-2780),-32768,0,False),('jimmy-night',0x157,0,(850,0,-2780),-32768,0,True),('mackey',0x2fd,0,(-70,0,100),-21500,0,False),('mackey-child-still',0x2fd,0,(-70,0,100),-21500,1,False)]:
 x=bytearray(base);struct.pack_into('>III',x,0,entrance,age,0);struct.pack_into('>I',x,0x1364,1);struct.pack_into('>fffhHhB',x,0x1368,*pos,yaw,0xdff,entrance,room);x[0x1409]=1;struct.pack_into('>HH',x,0x2e,160,160);x[0x13e2:0x13e7]=bytes(5);x[0x137c:0x1384]=bytes(8);x[0x34]=1;struct.pack_into('>H',x,0x0c,0 if night else 0x8000);struct.pack_into('>H',x,0x70,0x1111 if age else 0x1122);x[0x4a:0x54]=x[0x68:0x72]
 if name.startswith('mackey'):struct.pack_into('>H',x,0x1376,0xdff) # normal idle spawn, native room camera
 if name=='desert-doc':struct.pack_into('>H',x,0x1360,0) # no sequence overrides
 (W/(name+'.save')).write_bytes(x)
shutil.copyfile('/workspace/back-to-future/marty.save',W/'castle-marty.save');shutil.copyfile('/workspace/kenny/worst-still.save',W/'worst-still.save')
s=Path('/workspace/naboo/run.py').read_text().replace('/workspace/naboo','/workspace/desert-guests').replace("case='naboo-'","case='guests-'");s=s.replace('def run(topic):',"limits.update({'desert-marty':800,'desert-doc':800,'castle-marty':850,'meowth':500,'jimmy':650,'mackey':600,'jimmy-night':350,'desert-child-still':300,'mackey-child-still':300,'worst-still':300})\ndef run(topic):");(W/'run.py').write_text(s)
print('Prepared 10 native-scene fixtures; real controller conversations, true 4 MiB.')

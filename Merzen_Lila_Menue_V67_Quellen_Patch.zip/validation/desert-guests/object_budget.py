from pathlib import Path
import re,json
O=Path('/workspace/oot-burns-pal');W=Path('/workspace/desert-guests');s=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();symbols={n:int(a,16)for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',s,re.M)};objects={obj:name for name,obj in re.findall(r'DEFINE_OBJECT\((\w+), (\w+)\)',(O/'include/tables/object_table.h').read_text())}
def size(obj):
 n=objects[obj];return symbols['_'+n+'SegmentRomEnd']-symbols['_'+n+'SegmentRomStart']
rows=[]
for typ,sc in [('overworld','spot11'),('overworld','spot20'),('overworld','spot15'),('indoors','kakariko'),('dungeons','jyasinzou'),('dungeons','HAKAdan')]:
 D=O/f'extracted/pal-1.0/assets/scenes/{typ}/{sc}'
 for age,link in [('adult','OBJECT_LINK_BOY'),('child','OBJECT_LINK_CHILD')]:
  if sc=='spot15'and age!='child':continue
  if sc in['spot11','spot20','jyasinzou','HAKAdan']and age!='adult':continue
  persistent=['OBJECT_GAMEPLAY_KEEP','OBJECT_GAMEPLAY_DANGEON_KEEP'if typ=='dungeons'else'OBJECT_GAMEPLAY_FIELD_KEEP',link]
  for p in D.glob('*ObjectList.inc.c'):
   if sc=='spot20'and not any(k in p.name for k in ['03000330','03000540']):continue
   if sc=='spot11'and'03000458'not in p.name:continue
   if sc=='spot15'and'03000040'not in p.name:continue
   if sc=='jyasinzou'and'jyasinzou_room_19_'not in p.name:continue
   if sc=='HAKAdan'and'HAKAdan_room_9_'not in p.name:continue
   os=persistent+re.findall(r'\bOBJECT_\w+',p.read_text());total=sum((size(n)+15)//16*16 for n in os);assert len(os)<=19,(sc,p.name,len(os));assert total<=1019904,(sc,p.name,total);rows.append(dict(scene=sc,age=age,file=p.name,bytes=total,slots=len(os),objects=os))
report=dict(native_capacity=1019904,all_room_lists=rows,worst_case=max(rows,key=lambda r:r['bytes']));(W/'object-budget.json').write_text(json.dumps(report,indent=2)+'\n');print('Worst audited',report['worst_case']['scene'],report['worst_case']['file'],report['worst_case']['bytes'],'bytes; all lists within 19 slots.')

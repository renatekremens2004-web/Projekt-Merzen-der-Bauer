from pathlib import Path
import os,sys,json,subprocess,hashlib
from concurrent.futures import ThreadPoolExecutor
W=Path('/workspace/desert-guests');s=json.loads((W/'symbols.json').read_text());rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64')
limits={'alive':550,'dead':550,'boots-still':650,'dead-before-still':350,'worst-still':350,'gain-still':450}
limits.update({'desert-marty':800,'desert-doc':800,'castle-marty':850,'meowth':500,'jimmy':650,'mackey':600,'jimmy-night':350,'desert-child-still':300,'mackey-child-still':300,'worst-still':300})
def run(topic):
 case='guests-'+topic+'-'+os.environ.get('RUN','final')+'-direct-clip-on';limit=int(os.environ.get('FRAME_LIMIT',limits.get(topic,650)))
 env=dict(os.environ,DISPLAY=':99',MESA_SHADER_CACHE_DIR=str(W/'mesa-fresh'),OPENCV_VIDEOIO_PRIORITY_GPHOTO2='0',OPENCV_VIDEOIO_PRIORITY_GSTREAMER='0',OPENCV_VIDEOIO_PRIORITY_OBSENSOR='0',OPENCV_VIDEOIO_PRIORITY_V4L2='0')
 with(W/(case+'.log')).open('w')as log:
  log.write('ROM_SHA256 '+hashlib.sha256(rom.read_bytes()).hexdigest()+'\n');log.flush()
  subprocess.run([str(W/'fixed-runner'),str(rom),case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=300)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=int(os.environ.get('WORKERS','1')))as pool:list(pool.map(run,sys.argv[1:]))

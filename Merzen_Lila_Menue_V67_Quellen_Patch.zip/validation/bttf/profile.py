"""Serial, identical-camera PAL/4-MiB emulator comparisons; not hardware FPS."""
from pathlib import Path
import subprocess,re,json,hashlib,os,struct,statistics
W=Path('/workspace/back-to-future');O=Path('/workspace/oot-burns-pal')
clock=r'''
 if(strstr(scenario,"perf")) {
  struct timespec now;clock_gettime(CLOCK_MONOTONIC,&now);
  unsigned long long ns=(unsigned long long)now.tv_sec*1000000000ULL+now.tv_nsec;
  if(f>=100)printf("PERF f=%u ns=%llu gameFrames=%u\n",f,ns,play?r32(play+0x11de4):0);
 }
'''
source=(W/'runner.c').read_text().replace('#include <math.h>','#include <math.h>\n#include <time.h>')
source=source.replace(' if(play){',clock+' if(play){',1)
def syms(path):
 s=path.read_text();return {n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',s,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable','sZeldaArena']}
current=syms(O/'build/pal-1.0/oot-pal-1.0.map');runs=[]
for label,build in [('baseline',W/'baseline/build/pal-1.0'),('new',O/'build/pal-1.0')]:
 s=syms(build/'oot-pal-1.0.map');c=source
 for name in ['gObjectTable','gGameStateOverlayTable','sZeldaArena']:c=c.replace(hex(current[name]),hex(s[name]))
 p=W/f'perf-{label}.c';p.write_text(c)
 subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(p),'-o',str(W/f'perf-{label}'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
 for topic,fixture in [('crew','early')]:
  case=f'bttf-{topic}-perf-{label}-still-record-direct-clip-on';log=W/(case+'.log')
  with log.open('w')as out:
   subprocess.run([str(W/f'perf-{label}'),str(build/'oot-pal-1.0-compressed.z64'),case,'500','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(fixture+'.save'))],env=dict(os.environ,DISPLAY=':99',MESA_SHADER_CACHE_DIR=str(W/'mesa-fresh')),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=600)
  text=log.read_text();assert 'completed: 0'in text and not any(e in text for e in ['GFX_BANK_OVERFLOW','GFX_POOL_CORRUPT','OBJECT_BANK_OVERFLOW'])
  data=[tuple(map(int,m))for m in re.findall(r'PERF f=(\d+) ns=(\d+) gameFrames=(\d+)',text)];assert len(data)==401
  a,b=data[0],data[-1];seconds=(b[1]-a[1])/1e9
  intervals=[(b[1]-a[1])/1e6 for a,b in zip(data,data[1:])]
  item=dict(build=label,view=topic,rom_sha256=hashlib.sha256((build/'oot-pal-1.0-compressed.z64').read_bytes()).hexdigest(),elapsed_seconds=seconds,vi_callback_fps=(b[0]-a[0])/seconds,gameplay_fps=(b[2]-a[2])/seconds,p95_vi_ms=sorted(intervals)[int(len(intervals)*.95)],minimum_gfx_opa_free=min(int(free)for kind,free in re.findall(r'GFX_BANK f=\d+ kind=(\d+) size=\d+ free=(\d+)',text)if kind=='0'),minimum_arena_largest_free=min(map(int,re.findall(r'largest=(\d+)',text))),native_allocation_failures=max(map(int,re.findall(r'HEAP f=\d+ failures=(\d+)',text))))
  assert item['native_allocation_failures']==0;runs.append(item);print(json.dumps(item),flush=True)
report=dict(serial_runs=True,actual_ram_bytes=4194304,production_rom_unmodified=True,context='Host timings in Mupen64Plus cached interpreter, GLideN64, identical save/camera, no concurrent emulator; not real-N64 timings or a playthrough guarantee.',measurements=runs)
(W/'performance-comparison.json').write_text(json.dumps(report,indent=2)+'\n')

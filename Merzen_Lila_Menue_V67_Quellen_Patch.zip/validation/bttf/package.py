from pathlib import Path
import json,hashlib,re,shutil,zipfile,sys
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/back-to-future');A=Path('/workspace/artifacts');D=Path('/workspace/bean-download-delivery');sys.path.insert(0,str(R/'tools'))
from build_story import messages,plain,split_pages
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
romsha=sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64');verification=json.loads((O/'build/pal-1.0/bttf-verification.json').read_text());patchcheck=json.loads((W/'patch-verification.json').read_text());perf=json.loads((W/'performance-comparison.json').read_text());assert romsha==verification['rom_sha256']==patchcheck['target_sha256']
V=R/'validation/bttf';P=R/'previews/bttf';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True);logs={}
cases=[('marty','release2',750),('doc','release2',750),('night','final',750),('group-still','final',350),('english','final',350),('adult','final',350),('yellow','final',700),('early','native',850),('malon','release2',1000),('talon-wake','release2',1000)]
for topic,run,frames in cases:
 p=W/f'bttf-{topic}-{run}-direct-clip-on.log';s=p.read_text();assert 'completed: 0'in s and 'RAM=4194304'in s
 assert not any(x in s for x in ['OBJECT_BANK_OVERFLOW','GFX_BANK_OVERFLOW','GFX_POOL_CORRUPT','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 assert all(int(x)==0 for x in re.findall(r'HEAP f=\d+ failures=(\d+)',s))
 active=topic not in ['english','adult'];assert bool(re.search(r'BTTF[^\n]*marty=(?!00000000)[0-9a-f]{8} doc=(?!00000000)[0-9a-f]{8} car=(?!00000000)[0-9a-f]{8}',s))==active
 if topic in ['marty','doc','night','early']:
  assert all(f'id={i}'in s for i in ['71b4','71b5','71b6','71b7'])and 'BTTF_CONVERSATION_FINISHED'in s
 if topic in ['early','malon','talon-wake']:
  assert re.search(r'NATIVE_CAST[^\n]*talon=(?!00000000)[0-9a-f]{8} malon=(?!00000000)[0-9a-f]{8}',s)
 if topic=='malon':assert 'event1=0004 trade=21'in s
 if topic=='talon-wake':assert 'event1=0018 trade=22'in s and re.search(r'NATIVE_CAST[^\n]*talon=00000000 malon=00000000 event1=0018',s)
 logs[topic]=s;shutil.copyfile(p,V/p.name)
for p in W.glob('bttf-*-perf-*-still-record-direct-clip-on.log'):shutil.copyfile(p,V/p.name)
for name in ['prepare_runtime.py','runtime_source.py','runner.c','run.py','profile.py','performance-comparison.json','verification.log','check_patch.js','patch-verification.json','inspection.json','reduction.json','native-code-hashes.json','package.py']:
 shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/bttf-verification.json',V/'bttf-verification.json')
bankfree=min(int(n)for t,s in logs.items()if t not in['adult','english']for n in re.findall(r'OBJECT_BANK[^\n]*remaining=(\d+)',s));heapfree=min(int(n)for s in logs.values()for n in re.findall(r'largest=(\d+)',s));gfxfree=min(int(f)for s in logs.values()for k,f in re.findall(r'GFX_BANK f=\d+ kind=(\d+) size=\d+ free=(\d+)',s)if k=='0')
runtime=dict(rom_sha256=romsha,ram_bytes=4194304,completed=[dict(case=t,frames=f,rom_sha256=romsha if r=='release2'else'fdad1c164ce677512975d62a8e6cc5b5ffbfb38ffd7e7100178f68584070090f')for t,r,f in cases],minimum_object_bank_remaining=bankfree,minimum_arena_largest_free=heapfree,minimum_gfx_opa_remaining=gfxfree,native_allocation_failures=0,normal_cameras_and_actor_positions=True)
(V/'runtime-verification.json').write_text(json.dumps(runtime,indent=2)+'\n')
photos=[]
for topic,run,index,name in [('marty','release2',0,'Marty_Doc_DeLorean.png'),('marty','release2',2,'Marty_Junge_aus_der_Wueste.png'),('doc','release2',3,'Doc_Vierdimensional.png'),('marty','release2',6,'Marty_braucht_Pause.png'),('doc','release2',8,'Doc_Unsere_Aufgabe.png'),('malon','release2',0,'Malon_Originalablauf.png'),('talon-wake','release2',0,'Talon_Originalablauf.png')]:
 case=f'bttf-{topic}-{run}-direct-clip-on';src=Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{index:03d}.png';shutil.copyfile(src,P/name);assert sha(src)==sha(P/name);photos.append(dict(file=name,source=str(src),rom_sha256=romsha,unaltered_emulator_image=True))
(P/'Aufnahmen.json').write_text(json.dumps(photos,indent=2)+'\n')
source=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());text='# Marty und Doc: gemeinsames Gespräch\n\nAnsprache beider Figuren beginnt bei Marty und führt nacheinander durch alle vier Sprecherteile. Sechs manuell bestätigte Textseiten, keine feste Lesezeit.\n\n'
for ident in ['71B4','71B5','71B6','71B7']:
 text+='**'+ident+'**\n\n'+'\n\n'.join('> '+plain(p).strip().replace('\n','\n> ')for p in split_pages(source[ident]['parts'][2][2])[0])+'\n\n'
text=text.rstrip()+'\n'
(R/'planning/MARTY_DOC_DIALOG.md').write_text(text);(D/'Marty_Doc_Dialog.md').write_text(text)
rows='\n'.join('| '+p['build']+' | '+format(p['vi_callback_fps'],'.2f')+' | '+format(p['gameplay_fps'],'.2f')+' | '+format(p['p95_vi_ms'],'.2f')+' |'for p in perf['measurements'])
doc=f'''# Marty, Doc und DeLorean am jungen Schloß

Kumulativer Gesamtpatch für unveränderte Europa/PAL 1.0, Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`, Ziel-SHA256 `{romsha}`. ROM 40 MiB, tatsächliche 4 MiB RAM. Alle bisherigen Änderungen einschließlich Jabbas verbessertem Gesicht enthalten.

Die Gruppe steht auf der westlichen Grünfläche nach dem Kletterabschnitt, abseits von Tor und Wächterrouten. Marty −390/2340, Doc −500/2310, DeLorean −480/2150 (X/Z); Höhen werden aus der nativen Kollision ermittelt. Native Personen, Wege, Wachen und Skripte behalten ihre Positionen. Der Wagen folgt mit fester leichter Neigung der dortigen Wiese; seine unteren Radpunkte liegen rechnerisch etwa 1,0–1,2 Spieleinheiten über dem nativen Boden. Nur Kinder-Zeit und deutsche Fassung.

Marty 1.274 statt 7.761 Dreiecke, Doc 1.364 statt 7.349, DeLorean unverändert 190 ohne die mitgelieferte Bodenplatte. Zusammen 2.828. Gesichter, Augen und charakteristische Haare erhalten Vorrang vor Kleidung; eigene Gesichts-Ausschnitte statt gemeinsamen kleinen Hand-/Kopf-Texturen. Natürliche eigene Standproportionen: Marty 82,8, Doc 91,53, Wagen 60,42 hoch und 200 lang. Arme offline um eigene Schultern abgesenkt; vier starre eigene Gruppen pro Person, minimale Kopf-/Armgesten, aktive Sprecher nicken. Kein fremdes Skelett und keine Skalierung in der Animation. Die unbeweglichen Instanzen ermitteln den statischen Boden nur beim Laden; die unnötigen drei Raycasts pro laufendem Bild entfallen. Native Beleuchtung, Nebel und Tiefentest.

Beide NPCs starten denselben Dialog: 71B4 → 71B5 → 71B6 → 71B7, vier Sprecherteile auf sechs Seiten. Erster Sprecher immer Marty, Namen in der Textbox; native Gesprächskamera bleibt beim angesprochenen NPC. Die ersten drei privaten Texte verwenden den nativen EVENT-Abschluß und normale A-bestätigte Fortsetzung; der letzte schließt normal. Keine festen Zeiten, keine Geschichte-/Inventar-/Zeitreise-Schalter im neuen NPC-Code. Nach Abschluß wurde normale Bewegung per Controller geprüft. Der DeLorean ist ein geparktes Dekorationsobjekt mit einfacher zentraler OC-Körperkollision.

## Speicher, Grafik und bisherige Figuren

Alle drei teilen ein eigenes Objekt von 111.296 Byte und einen zusätzlichen Slot, maximal 14 von 19. Es wird nur in der normalen Objektliste des jungen Schloßgebiets angefordert. Freier Objektpuffer in den Prüfungen mindestens **{bankfree:,} Byte**, größte freie zusammenhängende Arena-Fläche mindestens **{heapfree:,} Byte**, null fehlgeschlagene native Belegungen. Der Raumpuffer wächst nur um 64 Byte für die Listen. Neue Objekt-ID 0x0193, DMA-Segment am Ende; bisherige IDs und DMA-Indizes bleiben erhalten. Andere Orte laden diesen Zusatz nicht. Händler-Platzhalter passen sich konsistent an OBJECT_ID_MAX 0x0194 an; 16 Änderungen geprüft.

Zusätzlich ausdrücklich mit gleichzeitig lebenden Talon/Malon und der neuen Gruppe geprüft. Der ursprüngliche Talon wurde mit dem Huhn geweckt, sein nativer Dialog und Weglaufablauf setzten die normalen Fortschrittsbits (0008 → 0018); danach verschwinden Talon/Malon wie vorgesehen. Malons normale Ei-Übergabe lieferte ITEM_WEIRD_EGG 0x21 und setzte ihr ursprüngliches Fortschrittsbit 0004. Der Test bei Malon stellt einen normalen Rückbesuch nach dem Eulengespräch dar. Im separaten frühen Gruppentest sind Talon, Malon und die Eule zugleich aktiv. Bisherige Personen werden nicht zur Speicherersparnis entfernt.

Alle vier nativen Grafik-Arenen zusätzlich geprüft: keine Überlappung der Kopf-/Endzeiger, Puffer-Magic 1234/5678 erhalten. Für undurchsichtige Geometrie mindestens **{gfxfree:,} Byte** frei in diesen Proben. Die geteilten Speichergrenzen und Meldungen stehen in den Protokollen.

Serieller Vergleich mit derselben Kamera, Startdatei, lebenden ursprünglichen NPCs und 4 MiB im verwendeten Mupen64Plus/GLideN64-Emulator. Neue Gruppe vollständig sichtbar, keine parallele Emulatorinstanz, keine Screenshot-Speicherung während der Messung. Je 400 VI-Intervalle nach 100 Aufwärm-Frames:

| Fassung | VI/s | Spielframes/s | VI-Intervall P95 ms |
| --- | ---: | ---: | ---: |
{rows}

Das sind Host-/Emulatormessungen und keine echten N64-Hardwarezeiten oder eine Garantie für einen vollständigen Durchlauf. Die Angaben zum Grafik-/Objektpuffer stammen getrennt aus den tatsächlichen nativen Datenstrukturen.

## Prüfung und Lieferung

Zehn abgeschlossene Szenenproben insgesamt: Ansprache Marty, Ansprache Doc, Nacht, Gruppenansicht, englische Abwesenheitskontrolle, Erwachsenen-Zeit, Yellow Guys Gespräch, früher Zustand mit allen ursprünglichen Personen, Malons Ei und Talons vollständiger Aufbruch. Die veröffentlichte Fassung mit der Bodenabfrage-Optimierung wurde bei Ansprache beider neuen NPCs, Malons Ei-Übergabe, Talons Aufbruch sowie im seriellen Gruppenvergleich erneut geprüft. Die zusätzlichen Alters-/Sprach-/Nacht-/Yellow-Guy-Kontrollen stammen vom vorherigen Build mit bytegleichen Modellen, Dialogen und Altersregeln; das Laufzeitmanifest nennt die jeweilige ROM-Prüfsumme. Vier Gesprächstests der neuen Gruppe durchlaufen alle vier IDs und geben danach wieder Steuerung frei. Yellow Guys bisherige fünf Seiten ebenfalls durchlaufen.

Alle 1.511 komprimierten Segmente gegen den unkomprimierten Build, CIC-6105-Prüfsumme, 3.664 native Kernfunktionen/Datensymbole und die Puffer sämtlicher 1.035 eigener Nachrichten geprüft. Alle bisherigen Texte aller PAL-Sprachen sowohl als Quelle als auch kompiliert unverändert. Vorherige Objektsegmente und Boßmodelle unverändert. Änderungen am Elf_Msg2-Quelltext auf vier private Helfer und drei frühe Verzweigungen begrenzt. Neue Nachrichten haben in allen Sprachen einen gültigen Folge-DMA-Zeiger. Vollständiger Story-Neubau und inkrementeller Aufbau erzeugen dieselbe Reihenfolge der privaten Nachrichten.

RomPatcher.js mit aktiver Quellvalidierung erzeugt bytegenau den getesteten Build. BPS auf die unveränderte entpackte Vanilla-PAL-1.0-ROM anwenden; normale Spielstände laden. Letzter Builder nach build_jabba.py ist build_bttf.py. Modell-Neuableitung mit Blender 4.3.2: export_bttf.py mit -- <Arbeitsordner> und den entpackten Nutzerarchiven unter input/marty, input/doc, input/delorean. Vorbereitete JSON/PNGs reichen für den normalen Bau. Keine ROM, Saves, Savestates, RAM-Abzüge, ausführbare Dateien oder dichte Importobjekte veröffentlicht. Kein vollständiger Durchlauf oder Hardwaretest in diesem Schritt.
'''
(R/'TESTING_BTTF.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
for key in ['marty','doc','delorean']:(R/'models'/key/'README.md').write_text('Teil des gemeinsamen jungen Schloß-Auftritts. Eigene Größe, native Beleuchtung. Quelle aus Nutzer-Upload; Export mit tools/export_bttf.py. Details in TESTING_BTTF.md.\n')
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Marty_Doc_Delorean.bps';shutil.copyfile(patch,R/'patches'/patch.name)
heading='# Marty, Doc und DeLorean'
p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Dialog](planning/MARTY_DOC_DIALOG.md) · [Prüfung](TESTING_BTTF.md) · [Bilder](previews/bttf/)\n\nJunges Schloß Hyrule, gemeinsamer Dialog bei beiden NPCs. Alle bisherigen Änderungen enthalten. Letzter Builder: build_bttf.py nach build_jabba.py.\n\n'+p.read_text())
p=R/'story/LEITLINIEN.md';s=p.read_text();line='\nMarty/Doc: 71B4–71B7, gemeinsames Gespräch am jungen Schloß. Vom Nutzer vorgegebener Wüsten-/Zeitreise-Dialog, alte Rechtschreibung, normale A-Fortsetzung. Keine neue Zeitreise-Mechanik.\n'
if line.strip()not in s:p.write_text(s+line)
archive=A/'Merzen_Marty_Doc_Delorean_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  original|=len(rel.parts)>=3 and rel.parts[:2]==('tools','originals')and rel.parts[2]in['water-comic-heroes','ben-ice','jabba','bttf']and(p.suffix in['.c','.h']or rel.parts[-2:]==('spec','spec'))
  if not p.is_file()or(any(q in exclude for q in rel.parts)and not original)or(p.suffix.lower()not in suffixes and not original):continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='bttf':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.o','.so','.st','.exe','.mp4','.glb'}for n in z.namelist());assert 'tools/originals/bttf/spec/spec'in z.namelist()
instruction=A/'Anleitung_Marty_Doc_Delorean.txt';instruction.write_text('Gesamtpatch mit Marty, Doc und DeLorean am jungen Schloß. Alle bisherigen Änderungen enthalten.\n\nMit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte unveränderte Europa/PAL-1.0-ROM anwenden. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände benutzen; keine alten Emulator-Savestates. Tatsächliche 4 MiB geprüft.\n')
for p in[patch,archive,instruction]:shutil.copyfile(p,D/p.name)
G=D/'Marty_Doc_Delorean_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
files=[D/p.name for p in[patch,archive,instruction]]+[D/'Marty_Doc_Dialog.md'];sums=D/'SHA256SUMS_Marty_Doc_Delorean.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files));files.append(sums)
p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Dialog](Marty_Doc_Dialog.md) · [Bilder und Prüfung](Marty_Doc_Delorean_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nAuf der Wiese am jungen Schloß. Beide NPCs starten das gemeinsame Gespräch. 2.828 Dreiecke zusammen; Talon/Malon samt Ei-Übergabe und Aufbruch geprüft. Alle bisherigen Änderungen enthalten, BPS auf unveränderte Vanilla PAL 1.0 anwenden. 4 MiB geprüft.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=romsha,files=[p.name for p in files],runtime=runtime),indent=2)+'\n');print('Packaged BTTF',romsha,'source bytes',archive.stat().st_size)

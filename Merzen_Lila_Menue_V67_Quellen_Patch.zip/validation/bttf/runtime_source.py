from pathlib import Path
import json,re,struct,shutil,subprocess
W=Path('/workspace/back-to-future');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text()
syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
s=Path('/workspace/fanboy-chumchum/runner.c').read_text();a=s.index(' if(play){',s.index('if(f%50==0)findplay();unsigned value=0;'));b=s.index('\n if(buttons)buttons(value);',a)
body=r''' if(play){
  uint32_t m=play+0x20d8;unsigned id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),pos=DebugMemRead16(m+0xe3ce);
  static unsigned oldkey=0,age=0;unsigned key=id*1024+pos;
  if(key!=oldkey || (mode!=7 && mode!=0x34 && mode!=0x35)){oldkey=key;age=0;}else age++;
  if((mode==7 || mode==0x34 || mode==0x35) && age==8){printf("TEXT f=%u id=%04x pos=%u mode=%x len=%u\n",f,id,pos,mode,r32(m+0xe300));if(!strstr(scenario,"record"))CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f==100 && !strstr(scenario,"record"))CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  static int bttStarted=0,bttLast=0,bttFinished=0;
  if(id>=0x71b4&&id<=0x71b7&&mode)bttStarted=1;
  if(id==0x71b7)bttLast=1;
  if(bttStarted&&bttLast&&mode==0)bttFinished=1;
  if(bttFinished&&f%50==0)printf("BTTF_CONVERSATION_FINISHED f=%u playerFlags=%08x\n",f,r32(player+0x66c));
  if(f>150 && mode==0&&!bttStarted){value=0x20;if(f%30<4)value|=0x80;}
  else if(f>100 && (mode==6 || mode==7 || mode==0x34 || mode==0x35) && age>18 && f%20<4)value=0x80;
  if(strstr(scenario,"ruto") && mode==0)value=(f>300 && f<550)?0x40000000:0;
  if(strstr(scenario,"talon-wake")&&f<175){value=f>=150?0x20:0;if(f>=165&&f<170)value|=0x200;}
  if(bttFinished&&f>620&&f<680)value=0x40000000;
  if(strstr(scenario,"still"))value=0;
  if(f%50==0){
   uint32_t fan=actor_type(0x173,0x75),chum=actor_type(0x173,0x76),sprout=actor(0xd3),ruto=actor(0xd2),jabba=actor_type(0x173,1);
   printf("ACTORS f=%u fan=%08x chum=%08x sprout=%08x ruto=%08x room=%d prev=%d fan_floor=%.1f chum_floor=%.1f\n",f,fan,chum,sprout,ruto,(int8_t)DebugMemRead8(play+0x11cbc),(int8_t)DebugMemRead8(play+0x11cd0),fan?rf(fan+0x80):0,chum?rf(chum+0x80):0);
   printf("JABBA f=%u actor=%08x pos=(%.1f %.1f %.1f) floor=%.1f yaw=%x\n",f,jabba,jabba?rf(jabba+0x24):0,jabba?rf(jabba+0x28):0,jabba?rf(jabba+0x2c):0,jabba?rf(jabba+0x80):0,jabba?DebugMemRead16(jabba+0xb6):0);
   printf("SETUP f=%u lang=%u age=%u layer=%u night=%u actors=%u overlay=%08x\n",f,DebugMemRead8(savebase+0x1409),r32(savebase+4),r32(savebase+0x1360),r32(savebase+0x10),DebugMemRead8(play+0x1c2c),r32(overlays+0x173*32+0x10));
   uint32_t totalFree=0,largestFree=0;for(uint32_t n=r32(0x8011a750),count=0;n>=0x80000000&&n<0x80400000&&count<1000;n=r32(n+8),count++){if(DebugMemRead16(n+2)){uint32_t size=r32(n+4);totalFree+=size;if(size>largestFree)largestFree=size;}}
   printf("HEAP f=%u failures=%u free=%u largest=%u\n",f,DebugMemRead8(0x8011a750+12),totalFree,largestFree);

   uint32_t marty=actor_type(0x173,2),doc=actor_type(0x173,3),car=actor_type(0x173,4),speaker=r32(m+0xe408);
   printf("BTTF f=%u marty=%08x doc=%08x car=%08x speaker=%04x martyFloor=%.1f docFloor=%.1f carFloor=%.1f carPitch=%d carRoll=%d\n",f,marty,doc,car,speaker?DebugMemRead16(speaker+0x1c):0,marty?rf(marty+0x80):0,doc?rf(doc+0x80):0,car?rf(car+0x80):0,car?(int16_t)DebugMemRead16(car+0xb4):0,car?(int16_t)DebugMemRead16(car+0xb8):0);

   uint32_t talon=actor(0x84),malon=actor(0xe7),gfx=r32(play);
   printf("NATIVE_CAST f=%u talon=%08x malon=%08x event1=%04x trade=%02x\n",f,talon,malon,DebugMemRead16(savebase+0xed6),DebugMemRead8(savebase+0x8b));
   for(unsigned k=0;k<4;k++){
    unsigned offs[4]={0x2b8,0x2c8,0x2a8,0x1b4};uint32_t ctx=gfx+offs[k],size=r32(ctx),head=r32(ctx+8),tail=r32(ctx+12);
    printf("GFX_BANK f=%u kind=%u size=%u free=%d\n",f,k,size,(int)(tail-head));
    if(f>=50&&size&&(head>tail||tail-head>size)){fprintf(stderr,"GFX_BANK_OVERFLOW\n");exit(94);}
   }
   uint32_t pool=r32(gfx)-8;
   printf("GFX_MAGIC f=%u head=%04x tail=%04x\n",f,DebugMemRead16(pool),DebugMemRead16(pool+0x12408));
   if(f>=50&&(DebugMemRead16(pool)!=0x1234||DebugMemRead16(pool+0x12408)!=0x5678)){fprintf(stderr,"GFX_POOL_CORRUPT\n");exit(94);}
   if(fan&&chum){fprintf(stderr,"HERO_COLOAD_ERROR\n");exit(95);}
   if(sprout)printf("SPROUT f=%u cs=%u rising=%u state=%u anim=%08x frame=%.1f limbs=%u pos=(%.1f %.1f %.1f) yaw=%x\n",f,DebugMemRead8(play+0x1d6c),DebugMemRead8(sprout+0x18b),DebugMemRead8(sprout+0x18c),r32(sprout+0x19c),rf(sprout+0x1ac),DebugMemRead8(sprout+0x194),rf(sprout+0x24),rf(sprout+0x28),rf(sprout+0x2c),DebugMemRead16(sprout+0xb6));
   if(ruto)printf("RUTO f=%u action=%u draw=%u anim=%08x frame=%.1f pos=(%.1f %.1f %.1f)\n",f,r32(ruto+0x2d4),r32(ruto+0x2d8),r32(ruto+0x144),rf(ruto+0x154),rf(ruto+0x24),rf(ruto+0x28),rf(ruto+0x2c));
   uint32_t ctx=play+0x117a4,begin=r32(ctx),end=r32(ctx+4),last=begin;int entries=DebugMemRead8(ctx+8);
   for(int i=0;i<entries && i<19;i++){uint32_t slot=ctx+12+i*0x44;int obj=(int16_t)DebugMemRead16(slot);if(obj<0)obj=-obj;if(obj>0 && obj<0x194){uint32_t e=r32(slot+4)+r32(OBJECTTABLE+obj*8+4)-r32(OBJECTTABLE+obj*8);if(e>last)last=e;}}
   printf("OBJECT_BANK f=%u entries=%d used=%u capacity=%u remaining=%d\n",f,entries,last-begin,end-begin,(int)(end-last));if(last>end){fprintf(stderr,"OBJECT_BANK_OVERFLOW\n");exit(96);}
   printf("ROOM_BANK f=%u capacity=%u\n",f,r32(play+0x11ce8)-r32(play+0x11ce4));
   printf("STATE f=%u scene=%x id=%04x msg=%x RAM=%u player=(%.1f %.1f %.1f)\n",f,DebugMemRead16(play+0xa4),id,mode,r32(0x80000318),rf(player+0x24),rf(player+0x28),rf(player+0x2c));
   if(!strstr(scenario,"record") && f>100 && f%200==0)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
  }
 }
'''
s=s[:a]+body.replace('OBJECTTABLE',hex(syms['gObjectTable']))+s[b:];s=s.replace('0x800ef7c0+3*0x30',hex(syms['gGameStateOverlayTable'])+'+3*0x30').replace('0x800ef6a0',hex(syms['gGameStateOverlayTable']));s=s.replace('signal(SIGSEGV,crash);','signal(SIGSEGV,crash);signal(SIGILL,crash);');s=s.replace('/workspace/bean-rider/test_input.so','/workspace/wallace-cheer/record_input.so')
(W/'runner.c').write_text(s)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner.new'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
(W/'runner.new').replace(W/'runner')
base=Path('/workspace/pepsiman-water/man-30.save').read_bytes()
def fixture(name,ent,scene,room,pos,yaw,age=0,lang=1,level=30,cleared=False):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,room);b[0x1409]=lang;struct.pack_into('>HH',b,0x2e,160,160);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);b[0x34]=1;struct.pack_into('>H',b,0x0c,0x8000);off=0xd4+scene*0x1c;b[off:off+0x1c]=bytes(0x1c);struct.pack_into('>H',b,0x70,0x1122 if not age else 0x1111);b[0x4a:0x54]=b[0x68:0x72]
 if scene==5:struct.pack_into('>I',b,off+4,1<<level)
 if cleared:struct.pack_into('>I',b,off+8,1<<room)
 (W/(name+'.save')).write_bytes(b)
for level in [28,29,30]:
 fixture('water-fan-'+str(level),0x10,5,7,(-3240.,1060.,-3970.),-16384,level=level)
 fixture('water-chum-'+str(level),0x10,5,19,(1650.,780.,180.),16384,level=level,cleared=True)
fixture('water-chum-uncleared',0x10,5,19,(1650.,780.,180.),16384,cleared=False)
fixture('water-fan-en',0x10,5,7,(-3240.,1060.,-3970.),-16384,lang=0)
fixture('kakariko',0xdb,0x52,0,(1104.,80.,230.),-32768)
for name,src in [('sahur','/workspace/forest-temple/sprout.save'),('rise','/workspace/forest-temple/rise.save'),('before-sprout','/workspace/forest-temple/before-sprout.save'),('child-sprout','/workspace/forest-temple/child-sprout.save'),('sahur-en','/workspace/forest-temple/sprout-en.save'),('forest-chum','/workspace/fanboy-chumchum/chumchum.save'),('ruto','/workspace/water-spirit-sages/water.save')]:shutil.copyfile(src,W/(name+'.save'))
# Existing Morpha arena fixture, only player/progress starting state.
for p in Path('/workspace').glob('*/flatsquid.save'):
 shutil.copyfile(p,W/'flat.save');break
print('Prepared latest-symbol 4 MiB probes and native player/progress fixtures.')

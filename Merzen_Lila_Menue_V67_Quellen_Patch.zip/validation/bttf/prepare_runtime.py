from pathlib import Path
import re,struct
W=Path('/workspace/back-to-future');O=Path('/workspace/oot-burns-pal')
s=Path('/workspace/jabba-face/runtime_source.py').read_text().replace('/workspace/jabba-face','/workspace/back-to-future').replace('obj<0x193','obj<0x194')
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();arena=int(re.search(r'0x([0-9a-f]+)\s+sZeldaArena\s*$',mp,re.M)[1],16)
s=s.replace('0x8011a700',hex(arena))
extra=r'''
   uint32_t marty=actor_type(0x173,2),doc=actor_type(0x173,3),car=actor_type(0x173,4),speaker=r32(m+0xe408);
   printf("BTTF f=%u marty=%08x doc=%08x car=%08x speaker=%04x martyFloor=%.1f docFloor=%.1f carFloor=%.1f carPitch=%d carRoll=%d\n",f,marty,doc,car,speaker?DebugMemRead16(speaker+0x1c):0,marty?rf(marty+0x80):0,doc?rf(doc+0x80):0,car?rf(car+0x80):0,car?(int16_t)DebugMemRead16(car+0xb4):0,car?(int16_t)DebugMemRead16(car+0xb8):0);
'''
s=s.replace('   if(fan&&chum)',extra+'   if(fan&&chum)')
monitor=r'''
   uint32_t talon=actor(0x84),malon=actor(0xe7),gfx=r32(play);
   printf("NATIVE_CAST f=%u talon=%08x malon=%08x event1=%04x trade=%02x\n",f,talon,malon,DebugMemRead16(savebase+0xed6),DebugMemRead8(savebase+0x8b));
   for(unsigned k=0;k<4;k++){
    unsigned offs[4]={0x2b8,0x2c8,0x2a8,0x1b4};uint32_t ctx=gfx+offs[k],size=r32(ctx),head=r32(ctx+8),tail=r32(ctx+12);
    printf("GFX_BANK f=%u kind=%u size=%u free=%d\n",f,k,size,(int)(tail-head));
    if(f>=50&&size&&(head>tail||tail-head>size)){fprintf(stderr,"GFX_BANK_OVERFLOW\n");exit(94);}
   }
   uint32_t pool=r32(gfx)-8;
   printf("GFX_MAGIC f=%u head=%04x tail=%04x\n",f,DebugMemRead16(pool),DebugMemRead16(pool+0x12408));
   if(f>=50&&(DebugMemRead16(pool)!=0x1234||DebugMemRead16(pool+0x12408)!=0x5678)){fprintf(stderr,"GFX_POOL_CORRUPT\n");exit(94);}
'''
s=s.replace('   if(fan&&chum)',monitor+'   if(fan&&chum)')
s=s.replace('  if(strstr(scenario,"still"))value=0;', '  if(strstr(scenario,"talon-wake")&&f<175){value=f>=150?0x20:0;if(f>=165&&f<170)value|=0x200;}\n  if(strstr(scenario,"still"))value=0;')
s=s.replace('  if(f>150 && mode==0){value=0x20;', '  static int bttStarted=0,bttLast=0,bttFinished=0;\n  if(id>=0x71b4&&id<=0x71b7&&mode)bttStarted=1;\n  if(id==0x71b7)bttLast=1;\n  if(bttStarted&&bttLast&&mode==0)bttFinished=1;\n  if(bttFinished&&f%50==0)printf("BTTF_CONVERSATION_FINISHED f=%u playerFlags=%08x\\n",f,r32(player+0x66c));\n  if(f>150 && mode==0&&!bttStarted){value=0x20;')
s=s.replace('  if(strstr(scenario,"still"))value=0;', '  if(bttFinished&&f>620&&f<680)value=0x40000000;\n  if(strstr(scenario,"still"))value=0;')
(W/'runtime_source.py').write_text(s);exec(compile(s,str(W/'runtime_source.py'),'exec'))
fixture('marty',0x138,0x5f,0,(-360.,1410.,2405.),-28672,age=1)
fixture('doc',0x138,0x5f,0,(-550.,1420.,2355.),24576,age=1)
fixture('group-still',0x138,0x5f,0,(-450.,1405.,2500.),-32768,age=1)
fixture('yellow',0x138,0x5f,0,(-425.,1085.,3610.),-32768,age=1)
fixture('english',0x138,0x5f,0,(-360.,1410.,2405.),-28672,age=1,lang=0)
fixture('adult',0x138,0x64,0,(300.,1307.,1810.),-32768,age=0)
b=bytearray((W/'marty.save').read_bytes());struct.pack_into('>H',b,0xc,0);struct.pack_into('>I',b,0x10,1);(W/'night.save').write_bytes(b)
for name,pos,yaw in [('malon',(-15.,1090.,3332.),16384),('talon-wake',(860.,1571.,-245.),-32768),('early',(-360.,1410.,2405.),-28672)]:
 fixture(name,0x138,0x5f,0,pos,yaw,age=1);p=W/(name+'.save');b=bytearray(p.read_bytes())
 struct.pack_into('>H',b,0xed6,struct.unpack_from('>H',b,0xed6)[0]&~0x7f)
 struct.pack_into('>H',b,0xf08,struct.unpack_from('>H',b,0xf08)[0]|(1<<11)|(1<<4))
 struct.pack_into('>I',b,0xa4,1<<18);b[0x8b]=0xff
 if name=='malon':
  # A normal return visit after the castle owl has finished speaking.
  off=0xd4+0x5f*0x1c+4;struct.pack_into('>I',b,off,struct.unpack_from('>I',b,off)[0]|(1<<5))
 if name=='talon-wake':
  b[0x8b]=0x22;b[0x69]=0x22;b[0x6c]=23;b[0x4a:0x54]=b[0x68:0x72]
 p.write_bytes(b)
r=Path('/workspace/jabba-face/run.py').read_text().replace('/workspace/jabba-face','/workspace/back-to-future').replace("'jabba-'","'bttf-'");(W/'run.py').write_text(r)
print('Prepared latest-symbol child castle probes, shared conversation inputs, 4 MiB.')

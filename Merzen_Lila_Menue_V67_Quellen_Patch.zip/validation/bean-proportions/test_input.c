#include "m64p_plugin.h"
static unsigned buttons;
EXPORT m64p_error CALL PluginStartup(m64p_dynlib_handle core, void* ctx, void (*cb)(void*,int,const char*)) { return M64ERR_SUCCESS; }
EXPORT m64p_error CALL PluginShutdown(void) { return M64ERR_SUCCESS; }
EXPORT m64p_error CALL PluginGetVersion(m64p_plugin_type* type, int* version, int* api, const char** name, int* caps) {
    if(type)*type=M64PLUGIN_INPUT; if(version)*version=0x10000; if(api)*api=0x020100;
    if(name)*name="Project scripted controller"; if(caps)*caps=0; return M64ERR_SUCCESS;
}
EXPORT void CALL InitiateControllers(CONTROL_INFO info) {
    for(int i=0;i<4;i++){info.Controls[i].Present=i==0;info.Controls[i].RawData=0;info.Controls[i].Plugin=PLUGIN_NONE;info.Controls[i].Type=CONT_TYPE_STANDARD;}
}
EXPORT void CALL GetKeys(int controller, BUTTONS* keys) { keys->Value=controller==0?buttons:0; }
EXPORT void TestSetButtons(unsigned value) { buttons=value; }
EXPORT void CALL ControllerCommand(int controller, unsigned char* command) {}
EXPORT void CALL ReadController(int controller, unsigned char* command) {}
EXPORT int CALL RomOpen(void) { return 1; }
EXPORT void CALL RomClosed(void) {}
EXPORT void CALL SDL_KeyDown(int mod, int key) {}
EXPORT void CALL SDL_KeyUp(int mod, int key) {}

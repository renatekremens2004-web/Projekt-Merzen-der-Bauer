# Nachweise zur Proportionsrevision

`build-verification.json` prüft den aktuellen ROM-Hash, alle komprimierten Blöcke, Relokationen, Modellbudget, Textpuffer und die zulässigen Quelltextänderungen. `binding-report.json` dokumentiert die Originalmaße. `patch-verification.json` stammt vom bytegenauen Anwenden mit RomPatcher.js. `reproducibility.json` hält den erneuten Generator-/Build-Lauf fest. `runtime-checks.json` ordnet die aktuellen Emulatorprotokolle den wirklich durchlaufenen Fällen zu.

Die C-Frontend- und Fixture-Werkzeuge sind Prüfwerkzeuge dieser Cloud-Maschine mit absoluten Pfaden. Sie gehören nicht zur Produktions-ROM. Die Fixtures stellen die ursprüngliche Startfunktion nach dem Bauen im finally-Block wieder her. Die native Noteneingabe erfolgt über das Controller-Plugin; Lied- und Medaillonflags werden nicht während der Sequenz von außen geschrieben.

Die aktuelle Cloud verwendet `/workspace/Projekt-Merzen-der-Bauer`, `/workspace/oot-burns-pal` und `source /workspace/toolchain/activate.sh`. Make-Aufrufe benötigen hier `VENV=/workspace/toolchain/venv`. Für zukünftige Aufgaben die vorhandenen Checkouts verwenden; die Cloud-Aufgabe ist bereits isoliert, ein zusätzliches Git-Worktree ist nicht nötig. Laufende Emulator-/X-Prozesse werden nicht als dauerhafter Zustand vorausgesetzt.

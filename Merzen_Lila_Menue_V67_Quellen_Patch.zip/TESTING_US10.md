# Prüfung und bekannte Grenzen

Getestet mit Mupen64Plus 2.6.0, Rice-Grafik und HLE-RSP. Die Szenentests liefen mit separaten, vorübergehend erzeugten Test-ROMs; die Download-ROM verwendet den unveränderten normalen Spielstart.

## Beobachtete Szenen und Abläufe

- Reiten: junge Ganondorf-Variante als Burns auf dem originalen Pferd, wechselnde Gelenkstellungen der nativen Reitanimation.
- Schlosshof: Wechsel von Geh- zu Knien- und Seitwärtsblick-Animation anhand der originalen Actor-Cues. Der direkte Teststart zeigte eine diagonale verdeckende Fläche. Dieselbe Fläche trat im Kontrollbuild mit unveränderten Originalmodellen auf. Dieser Test belegt die Animationswechsel, aber keine fehlerfreie Bilddarstellung des regulären Storyablaufs an dieser Stelle.
- Vision: verschränkte Arme, Übergang zum Lachen und laufende Lachanimation. Burns' andere Kopfproportionen führen in der extremen Nahaufnahme zu Bildbeschnitt.
- Orgel und Kampfintro: Burns an der Orgel, Übergang über die originalen Dialoge in den Kampf.
- Kampf: native Bewegungs- und Angriffsanimationen, Kamera über Z-Anvisieren und simulierte Schwerteingaben; Angriffe verletzten Link. Kampfwerte und Kollisionslogik wurden nicht geändert. Kein vollständiger Siegtest dieser Fassung.
- Versiegelung: laufende originale Schlussanimation mit Burns.
- Verwandlung: Burns steigt aus den Trümmern auf, spielt die menschlichen Animationen und wechselt anschließend in das originale Ganon-Modell; danach begann der Monsterkampf. Für diesen gezielten Test wurde Link im Emulator einmal zu den Trümmern versetzt, um den normalen Abstandsauslöser zu erreichen. Der Test änderte ausschließlich Emulator-RAM.
- Komprimierte Download-ROM: Start nach dem Nintendo-Logo über die normale Titelsequenz und Dateiauswahl geprüft.

In den Emulatorprotokollen wurden Modelladressen, Animationsadressen, aktuelle Animationsframes und wechselnde Prüfsummen der Gelenktabellen erfasst. Gesicht und Pupillen wurden zusätzlich in Nahaufnahmen kontrolliert.

## Prüfung der Daten

- Alle 1.508 regulären DMA-Segmente der komprimierten ROM wurden dekomprimiert und mit dem unkomprimierten Build verglichen. Nur Header-Prüfsummen und DMA-Kompressionsadressen unterscheiden sich erwartungsgemäß.
- Phantom-Ganons Objekt `object_gnd` und Ganons Monsterobjekt `object_ganon2` stimmen bytegenau mit der Original-ROM überein.
- Die drei Ganondorf-Animationsbanken `object_ganon_anime1`, `object_ganon_anime2` und `object_ganon_anime3` stimmen bytegenau mit der Original-ROM überein.
- Die beiden veränderten Modellobjekte sind kleiner als ihre Originale. Es wurde kein zusätzlicher Modell-Speicherbereich benötigt.
- Startlogik, normale Ganondorf- und Ganon-Kampfquellen, Phantom-Ganons Kampfquelle und normales Pause-Menü stimmen mit dem Decompilation-Ausgangsstand überein. Die einzige geänderte Actor-Quelldatei blendet Ganondorfs separates Cape aus; der Actor bleibt für native Verknüpfungen bestehen.
- Der mitgelieferte Generator und die mitgelieferten Modell-Daten wurden zum Bau der ROM benutzt.

Maschinenlesbare Ergebnisse: [ROM-Prüfung](validation/rom-verification.json) und [Umfangsprüfung](validation/scope-verification.json).

## Offene Einschränkungen

Kein vollständiger Story-Durchlauf, keine Prüfung auf echter N64-Hardware und keine Gewähr für jeden Emulator. Fingerstellungen und Augen-/Gesichtsvarianten sind vereinfacht. Die originale Kameraführung wurde nicht für Burns' andere Proportionen neu inszeniert; Nahaufnahmen und überschlagene Körperteile können deshalb überschneiden. Bei Darstellungsfehlern empfiehlt sich ein aktueller Emulator mit einem anderen Grafik-Plugin; andere Plugins wurden hier nicht geprüft.

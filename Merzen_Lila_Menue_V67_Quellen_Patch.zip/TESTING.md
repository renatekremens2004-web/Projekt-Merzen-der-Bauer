> Dieser Bericht gehört zur früheren Bean-Fassung. Die aktuelle Proportionskorrektur wird in [TESTING_PROPORTIONEN.md](TESTING_PROPORTIONEN.md) geprüft.

# Prüfung: Mr. Bean ersetzt Impa

Grundlage: Europa/PAL 1.0 mit der bereits geprüften deutschen Burns-/Kokiri-Fassung. Deren ROM-SHA256 ist `deb863379b007e3a54c3f5d652af12c5353b1a32619dc5b5ec08532405332bfc`. Die vorherigen Prüfberichte bleiben in [TESTING_KOKIRI.md](TESTING_KOKIRI.md) und [TESTING_PAL_V2.md](TESTING_PAL_V2.md) erhalten.

## ROM-Vergleich

- 32-MiB-Produktions-ROM, SHA256 `2c33901bb6f34e66a84ce2cfecca84bdaf4469d01528f4898950fa19425f76d3`, CIC-6105-Header `B0BD19C9 EF96A3C8`.
- Alle 1.509 regulären DMA-Datenblöcke der komprimierten ROM gegen den unkomprimierten Build geprüft. Originaler Spielstart wiederhergestellt.
- 1.076 Segmente gegenüber der Kokiri-Fassung bytegenau identisch. Bei 430 weiteren Segmenten sind die Unterschiede ausschließlich durch ELF-Relokationen gedeckt: neue ROM-/Overlay-Adressen, unveränderte Instruktionscodes. Im Hauptprogramm kommt die deutsche Nachrichten-Zeigertabelle hinzu.
- Beabsichtigt geändert: deutsche Nachrichten, Impas Modell-/Animationsobjekt, dessen Schauspieler-Overlay, DMA-Verzeichnis und ROM-Header. Das Impa-Overlay entfernt nur das Anhalten der sichtbaren Tanzanimation; dies ist durch exakten Quelltextvergleich geprüft.
- Keine zusätzlichen Änderungen an Item-, Alters-, Shop-, Kampf- oder Questquellen. Bereits vorhandene Burns- und deutsche Sprachvoreinstellungsänderungen bleiben bestehen. Kein Inventarfilter oder Reparaturcode hinzugefügt.

## Text und Modelle

Die bisherigen 152 Kokiri-Nachrichten sind unverändert erhalten. Hinzu kommen 30 Bean-Nachrichten und Verweise auf ihn. Alle deutschen Namensnennungen Impas sowie die erfaßten indirekten Beschreibungen ihrer Rolle sind umgeschrieben. Bean spricht Englisch; die anderen Figuren sprechen weiterhin Deutsch.

Alle 182 geänderten Nachrichten behalten IDs, Box-Typen, Positionen, funktionale Steuerzeichen, Folge-IDs, Seitenzahlen und Seitenwechseltypen. Native NAME- und TIME-Befehle bleiben erhalten. Bei Breitenprüfungen werden acht breite Namenszeichen reserviert. Größte Nachricht: 704 von 1.280 Rohbytes; größte konservativ berechnete dekodierte Seite: 102 von 200 Bytes.

Das Bean-Modell enthält alle 1.258 Quelldreiecke und eine 128×128-CI8-Textur mit 256 Farben aus dem eingebetteten 256×256-Atlas. Alle 16 ursprünglichen Skelettglieder, deren Matrixplätze und die nicht ersetzten Animationen bleiben erhalten. Auch die alternative Kopf-Display-List der Reitfigur ist ersetzt. Das Objekt benötigt 69.568 statt 74.288 Bytes und bleibt damit innerhalb des ursprünglichen Objektbudgets. Normalen, Nebel, Umgebungslicht und Transparenz beim Weisen-Auftritt werden verwendet.

Samba und Swing ersetzen nur die beiden sichtbaren Pfeifanimationen. Ihre ursprünglichen 40-/55-Frame-Header bleiben erhalten. Die Tanzschleife läuft während der nativen Notendemonstration und Spielereingabe weiter. Notenfolge, Okarina-Zustände, Erwerbstext, Liedflag und Questfortsetzung bleiben nativ.

## Tatsächlich ausgeführte Tests

Mupen64Plus 2.6.0 mit HLE-RSP und GLideN64 aus RMG 0.6.0, Quellstand `4972e76aea6b327959d1761c786077fd96b6cb30`. Die RMG-Oberfläche selbst wurde nicht ausgeführt. Controller-Eingaben erfolgen über ein Testplugin, Screenshots stammen aus dem echten Spielbild. Ohne Audioplugin wurde kein Hörtest durchgeführt.

| Fall | Beobachtung |
| --- | --- |
| Zeldas Wiegenlied, 8 MB | Aktuelle Bean-Dialoge, Samba-Übergang und Swing während der Notenfolge. Sechs echte C-Tasten-Eingaben: Links, Oben, Rechts, Links, Oben, Rechts. Native Erfolgserkennung, deutscher Erwerbstext, Übergang ins Feld und normale Steuerung erreicht; Liedbit vom Spiel gesetzt. |
| Zeldas Wiegenlied, 4 MB | Derselbe Ablauf mit tatsächlich vom Spiel erkannten 4.194.304 Bytes; aktuelle Dialoge und unveränderte Controllerfolge. |
| Halle der Weisen | Erweiterte englische Bean-Texte vollständig durchlaufen. Schatten-Medaillon über den Originalablauf erhalten; Rückkehr auf den Friedhof und normale Steuerung erreicht. |
| Flucht mit Zelda | Native Hyrule-Feld-Fluchtsequenz mit Bean als Reiter durchlaufen; Sitzposition und gemeinsames Pferd geprüft. |
| Reit-Rückblende | Native Schwarzweiß-Nahaufnahme mit Zelda und Bean geprüft, einschließlich des alternativen Reiterkopfes. |
| Versiegelung | Tatsächliche Impa-Weisenfigur mit Parametern 2 geprüft: Deckkraft 0→255→0, ursprüngliche Posen und Übergang in die nächste Endsequenz. |
| Normaler Start, 4/8 MB | Unveränderte komprimierte Produktions-ROM jeweils bis zur deutschen Dateiauswahl/Namenseingabe gestartet; RAM-Größe im laufenden Spiel kontrolliert. |

Die direkten Szenentests verwenden getrennte Test-ROMs mit einer vorübergehenden Startfunktion. Sie setzen nur die jeweiligen Voraussetzungen, etwa Zeldas bereits erhaltenen Brief für den Liedtest oder den Schatten-Weisen-Auftritt. Der Testname LUKAS ist frei gewählt. Beim Liedtest wird der Spieler einmal zum Gesprächspunkt bewegt; danach laufen Annäherung, Cutscene, Controller-Eingabe und Itemvergabe durch das originale Spiel. Es werden keine Lied- oder Medaillonflags während dieser Abläufe von außen gesetzt.

Die veröffentlichte ROM enthält keine Teststartfunktion. Echte 4 MB werden mit dem Cached Interpreter geprüft; der Dynarec erkannte bei der Speicherprobe trotz deaktivierter Erweiterung 8 MB. Kontrollwert ist `osMemSize`, nicht nur die Emulator-Einstellung.

## Abdeckung und Grenzen

Die gemeinsame Impa-Geometrie wird sowohl vom normalen Schauspieler `Demo_Im` als auch von der Reitfigur `En_Viewer` verwendet. Damit sind auch die modellseitigen Abspann-Varianten ersetzt; deren ursprüngliche Animationsdaten bleiben erhalten. Nicht jede einzelne Abspannkamera wurde separat abgespielt.

Die bereitgestellten Charaktere haben andere Proportionen als die Originale. Der Kopf wurde für die engen Kameras verkleinert; einzelne Einstellungen können trotzdem Teile des Kopfes beschneiden. N64-Hautgewichte, Finger und Gesichtsbewegungen sind vereinfacht. Die neue Textur ist kleiner als das Quellbild. Tests auf echter Hardware und ein vollständiger Spieldurchlauf stehen aus; die beschriebenen Prüfungen decken gezielte Abläufe ab.

Die [Prüfdaten und Emulatorprotokolle](validation/bean-de) sowie [ausgewählte Spielbilder](previews/bean) sind enthalten. Die allgemeine neue Handlung außerhalb des Kokiri-Kapitels und der Bean-Verweise ist noch nicht geschrieben.

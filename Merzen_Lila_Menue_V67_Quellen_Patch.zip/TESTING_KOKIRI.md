# Prüfung des deutschen Kokiri-Textkapitels

Grundlage ist die deutsche Burns-Modellfassung v2 (ROM-SHA256 `67b4068e3afb857907ba9c4a6a08d4363b62a88a275637fc7bfb57697b7728c2`) auf Europa/PAL 1.0. Die Prüfung dieser Modellgrundlage bleibt in [TESTING_PAL_V2.md](TESTING_PAL_V2.md) erhalten.

## Vergleich mit dem bisherigen Build

- 152 deutsche Nachrichten geändert; alle Nachrichten-IDs, Box-Typen und Positionstypen erhalten. Nicht bearbeitete Nachrichten und die englischen/französischen Quelltexte bleiben identisch.
- Je Nachricht dieselbe Folge funktionaler Steuerzeichen: Folge-IDs, Ereignis-Enden, dauerhafte Ladentexte, Auswahltypen, Sound- und Item-Icon-Befehle. Seitenzahlen und Seitenwechseltypen einschließlich zeitgesteuerter Wechsel bleiben erhalten. Antwortoptionen behalten ihre ursprüngliche Bedeutung und Reihenfolge.
- Der gesamte ausführbare Hauptprogramm-Code (868.128 Bytes) ist bytegenau identisch mit der bisherigen deutschen Burns-Fassung. Alle geänderten Bytes im Hauptprogramm-Datenbereich liegen ausschließlich in der deutschen Nachrichten-Zeigertabelle.
- 1.507 weitere Datenblöcke sind identisch mit dem bisherigen Build: darunter Pausemenü, Items, Item-Icons, Shop- und NPC-Overlays, Szenen, Modelle und Animationen. Neben deutschen Nachrichten und ihren Zeigern ändern sich nur ROM-Header-Prüfsumme und DMA-Verzeichnis.
- Alle 1.509 regulären DMA-Datenblöcke der komprimierten Download-ROM wurden wieder entpackt und mit dem unkomprimierten Build verglichen. Die CIC-6105-Prüfsumme stimmt; die normale Startfunktion ist gegen den ursprünglichen Decompilation-Stand geprüft.

## Textdarstellung

Zeilenbreiten werden aus der tatsächlichen PAL-Schrift berechnet. Für den eingesetzten Spielernamen werden acht breite „W“ reserviert. Normale Texte verwenden höchstens vier Zeilen pro Seite; Boxen mit Item-Icon haben ein kleineres Textbudget. Antwortoptionen stehen auf den Zeilen, auf denen das Originalspiel den Auswahlpfeil zeichnet.

Die längste neue Nachricht benötigt 704 von 1.280 Bytes im rohen Nachrichtenpuffer. Die konservative Obergrenze je dekodierter Seite beträgt 102 von 200 Bytes, einschließlich einer möglichen Erweiterung des Spielernamens. Der native NAME-Befehl wird verwendet. Häufige Schreibungen nach der Rechtschreibreform und ein festgeschriebener Heldenname werden vom Generator abgefangen.

## Tatsächlich ausgeführte Dialogtests

Emulator: Mupen64Plus 2.6.0 mit HLE-RSP und dem GLideN64-Quellstand aus RMG 0.6.0 (`4972e76aea6b327959d1761c786077fd96b6cb30`). Die RMG-Oberfläche selbst wurde nicht ausgeführt. Die Testeingaben gehen über ein Controllerplugin an das originale Spiel.

| Fall | Beobachtung |
| --- | --- |
| Weckszene | Navi-Texte einschließlich mehrseitiger Vorstellung bis zum normalen Spielzustand durchlaufen; frei gewählter Name LUKAS korrekt eingesetzt. |
| Spielanfang | Automatische Introtexte, Szenenwechsel und Deku-Baum/Navi-Dialoge mit dem Testnamen WWWWWWWW gelesen und umgeblättert; kein sichtbarer Überlauf. |
| Deku-Baum: Ja | Native Gesprächskette und Auswahl durchlaufen; Mundöffnung 1,0, ursprüngliches Zugangsflag gesetzt. |
| Deku-Baum: Nein | Originaler Ablehnungszweig 0x1018 erreicht; Mundöffnung 0,0, Zugangsflag bleibt aus. |
| Mido ohne Ausrüstung | Ursprüngliche Ablehnung und Folge-ID-Kette erreicht; Mido bleibt im Durchgang. |
| Mido mit angelegtem Kokiri-Schwert und Deku-Schild | Gesprächskette bis zum Ende durchlaufen; Mido läuft zur Seite. |
| Schild kaufen | 99 auf 59 Rubine; Deku-Schild im Ausrüstungsbesitz, alle 24 normalen Inventarplätze weiter ITEM_NONE. Anschließende Weiterkaufen-Auswahl funktioniert. |
| Schildkauf ablehnen | Auswahlindex 1 führt zurück zur Warenansicht; weiterhin 99 Rubine, kein Schild vergeben. |
| Zu wenig Rubine | Mit 10 Rubinen native Ablehnung 0x0085 erreicht; Rubine und Ausrüstung unverändert. |
| Nach dem Dungeon | Dank, erneute Auswahl, Erklärung des Fluchs und Übergang in die native Rückblende erreicht. |
| Abschied | Dialog 0x1029, Folge 0x1093, Smaragdtext 0x0080 und Abschiedstexte 0x102A–0x102C bis zur regulären Rückkehr in den Kokiri-Wald durchlaufen. |
| 4 MB | Neue Navi-Begrüßung beim Baum und erste Seiten des Baumgesprächs mit tatsächlich erkannten 4.194.304 Bytes gelesen. |
| Produktions-ROM | Regulärer komprimierter Build mit 4.194.304 und 8.388.608 Bytes bis zur deutschen Dateiauswahl/Namenseingabe gestartet. |

Die direkten Szenentests verwenden getrennte Test-ROMs mit einer vorübergehenden Startfunktion. Testname, Rubine, Startort und gegebenenfalls Ausrüstung werden nur dort gesetzt; beim Mido-Test wird die Figur zusätzlich im Emulator-RAM zum Gesprächspunkt bewegt. Für den Abschied sind die normalen Nach-Gohma-Voraussetzungen einschließlich des bereits vom Boss-Warp vergebenen Smaragds gesetzt. Das ist kein eigenständiger Test der Itemvergabe durch den Gohma-Warp.

Die veröffentlichte ROM enthält die originale Startfunktion und die ursprünglichen Startgegenstände. Für echte 4 MB wird der Cached Interpreter verwendet: Der Dynarec erkannte beim Speicherprobeverfahren trotz deaktivierter Erweiterung 8 MB. Die RAM-Größe wird im laufenden Spiel über `osMemSize` kontrolliert.

## Nachweise und Grenzen

[Validierungsdaten und Testprotokolle](validation/kokiri-de) enthalten den automatischen ROM-Vergleich, Layoutdaten, Emulatorprotokolle und Testwerkzeuge. Die [ausgewählten Screenshots](previews/kokiri) zeigen echte Textboxen aus den direkten Szenentests.

Dies ist eine gezielte Prüfung des ersten Textkapitels. Nicht jeder einzelne NPC-Zustand und spätere Questzweig wurde gespielt; ein vollständiger Story-Durchlauf und Tests auf echter N64-Hardware fehlen. Die späteren Gebiete sind noch nicht als neue Textkapitel umgesetzt. Die ursprünglichen Item-, Alters-, Quest- und Kampfregeln bleiben erhalten.

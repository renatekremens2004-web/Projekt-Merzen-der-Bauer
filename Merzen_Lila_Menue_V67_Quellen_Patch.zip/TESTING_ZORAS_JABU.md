# Zoras, Jabu-Jabu und Navi-Roasts

59 Nachrichten im Zora-/Jabu-Kapitel und 93 Zieltextplätze von Navi neu gefaßt. Zehn zuvor bearbeitete IDs ersetzt; insgesamt 564 deutsche Nachrichten. Alte Rechtschreibung und dynamischer Spielername bleiben erhalten. Die 93 Zieltexte decken lückenlos 0600–065C ab, einschließlich der ursprünglich leeren Plätze und Sonderziele. Sie enthalten Roasts statt Kampfhinweisen. Es wurde nicht jeder Gegner einzeln durchgespielt.

## Geschichte und Eingriffe

Zora-König: Klimaanlagen-Deal mit Merz gegen den Saphir, verschwundene Tochter, anschließendes Vertrösten. Flaschenpost: Ruto versteckt sich vor Merz im schleimigen Wal. Ruto erklärt das Herumlaufen im Fisch für normal; die Frage nach „Vore“ bleibt eine nichtsexuelle, ratlose Bemerkung. Nach Übergabe des Steins will sie untertauchen. Ihr deutscher Auftritt neben dem König entfällt deshalb erst nach dem tatsächlich erhaltenen Saphir. Alle übrigen Ruto-Szenen und die erwachsene Ruto bleiben nativ.

Wundererbsen: Angebots- und Folgetexte geändert, Quellen von Preisleiter, Kaufbedingungen und Warenvergabe unverändert. 10 bis 100 Rubine, maximal zehn Käufe. Der Laubkerl in Jabu-Jabu erhält nur dort die private Nachricht 0130. Kontrollfolge und Weiterleitung nach 10A3 entsprechen 10A0; fünf Deku-Nüsse für 20 Rubine bleiben nativ. Andere Laubkerle behalten ihre bestehenden Texte.

Kartenmeldung: `Message_StartTextbox` leitet nur die deutsche Nachricht 0066 in Szene Jabu-Jabu auf 013E um. Originale Karte, Itemvergabe und alle anderen Kartenmeldungen bleiben unverändert. 013E übernimmt alle drei Item-Icon-Seiten der ursprünglichen Meldung.

Barinade: Eine zusätzliche, manuell weiterklickbare Box 013C erscheint am Ende des Intros. Solange sie offen ist, bleibt der abschließende Intro-Zustand stehen. Danach folgen die ursprünglichen Kamera-Aufräumarbeiten, Freigabe des Spielers, Beginn-Flag und Kampfzustände. Titel- und Kameratimer vor dieser neuen Box sind unverändert. Für die zusätzliche Box wird die Subkamera einmal frontal innerhalb des Raumes auf Barinade gesetzt; die nachfolgende native Kamerafreigabe bleibt erhalten. Andere Sprachen erhalten keine zusätzliche Box. Keine Änderung an Schaden, Kollidern oder Kampfphasen.

Navi: Die mitgeführte Ruto-Flaschenpost macht den überarbeiteten Hinweis 014A im Overworld-Guide verfügbar. 013F benötigt den Zora-Saphir und erscheint vor Zeldas Flucht. Es wird kein Kommentar über ein bereits zerstörtes Jabu-Herz vorzeitig ausgegeben. Die natürliche C-Up-Hinweisverfügbarkeit und Navis Abklingzeiten bleiben bestehen. Der Deku- und Dodongo-Mundwitz aus den früheren Fassungen bleibt erhalten.

## Prüfungen

Generator: Alle funktionalen Kontrollfolgen der 152 Einträge gegen die Retail-Vorlagen geprüft. Native Events, Textverkettungen, Auswahlreihenfolgen, Item-Icons und feste Fade-/Verzögerungswerte bleiben erhalten. 0066 ist weiterhin unverändert als allgemeine Kartenmeldung vorhanden. Textpuffer und Zeilenbreiten geprüft.

Build und Vergleich gegen die veröffentlichte Thaddäus-Fassung: PAL-Prüfsumme, Kompression aller 1509 Segmente, normale Startsequenz und wiederhergestellter Play_Main. Änderungen auf deutsche Nachrichten/Adressdaten, die drei Kapitel-Hooks sowie den einzelnen Ruto-Auftritt begrenzt. Bean- und Thaddäus-Modellobjekte sind bytegleich mit der vorherigen Fassung. BPS mit RomPatcher.js und aktivierter Originalprüfung bytegenau gegen den Produktionsbuild angewandt.

Gezielte 4-MB-Prüfungen in Mupen64Plus/GLideN64: Königs-Dialog vor/nach dem Stein, Navi mit Flaschenpost vor dem Saphir und danach, Barinade-Begrüßung mit anschließender nativer Kampffreigabe, Wundererbsen-Angebot/Kauf, Kartenmeldung in Jabu und als Gegenprüfung im Deku-Baum, ein echter Navi-Zieltext über Z-Target/C-Up. Für den Zieltext wird eine Skullwandula vor den Spieler versetzt und kurz eingefroren; Auswahl und Textaufruf laufen über die normalen Tasten.

Test-Fixtures setzen Alter, Szene, Tageszeit und Fortschritt. Figuren-/Spielerpositionierung ist nur eine Aufnahmehilfe. Die Karten-Gegenprüfung ruft im Teststart dieselbe native `Message_StartTextbox(0066)`-Route direkt auf; sie ist kein Nachweis eines manuell geöffneten Kartenkastens. Barinades Einleitung läuft ohne gesetztes Beginn-Flag nativ ab. Nach der Box wird das native Beginn-Flag beobachtet. Die Königs-Nachprüfung prüft zugleich, daß Ruto nicht mehr neben ihm steht. Protokolle und Helfer unter `validation/zoras-jabu/`.

Kein vollständiger Dungeon- oder Spieldurchlauf, keine manuelle Prüfung aller 93 Zieltypen und keine echte N64-Hardware. Rutos komplette Tragelogik, Saphir-Schlußsequenz und der komplette Weg zum Laubkerl wurden in dieser Revision nicht durchgespielt; ihre ursprünglichen Event-/Item-/Szenenabläufe bleiben abgesehen vom beschriebenen Thronsaal-Auftritt im Quellcode erhalten. Screenshots sind unbearbeitete Emulatoraufnahmen; Test-ROMs und vollständige ROMs werden nicht veröffentlicht.

## Nachträgliche Grafikprüfung

Original und aktueller Patch wurden zusätzlich an allen fünf gemeldeten Fundstellen verglichen; siehe [TESTING_GRAFIK.md](TESTING_GRAFIK.md). Die Aufnahme-Konfiguration verwendet nun Software-Clipping. Das aktuelle Händlerbild stammt von seinem normalen Standort. BPS und Produktions-ROM sind unverändert geblieben.

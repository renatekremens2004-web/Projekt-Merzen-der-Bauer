# Vorgaben für neue Funde und Figuren

Neue Gegenstände oder NPCs nicht routinemäßig gleich in den ersten Raum eines Dungeons stellen. Sie sollen beim Erkunden an einem passenden Ort auftauchen. Gelände, Wasser, Zugänglichkeit, Gegner, Kamera und Maßstab gehören zur Plazierungsprüfung. Demonstrationsbilder zeigen die tatsächliche Produktionsposition.

Aktuell: Majoras Maske liegt im westlichen inneren Gang unter dem verdrehten Korridor (Bmori1 Raum 21), nicht in Eingang oder Fackelhalle. Natives Bodenpolygon Y=443; Objekt bei (-1940,444,-3220), 22 Spieleinheiten breit. Mit Z/C-oben wiederholt untersuchbar. Die beiden ursprünglichen Blauen Blasen bleiben im Gang.

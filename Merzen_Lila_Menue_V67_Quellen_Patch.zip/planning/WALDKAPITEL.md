# Waldkapitel: verbindliche Ideen und spätere Umsetzung

## Bereits aktive Dialoge

wald_auftakt_de.json (Boris 502D/502E in goronen_kakariko_de.json): derselbe entspannte Kokiri (Kind 100A, erwachsen 105F, nach Waldtempel 1076); Boris als Geist 5041/502D/502E; Shiek in der Zitadelle und Lichtung 7056/7057/7077–707A/700F/7010/106C/106D. Kokiri-Auswahl EnKo_GetTextIdAdult, CHILD_4. Rennablauf, Rennzeit 502F und Belohnung bleiben nativ. Boris behauptet eine seit jeher bekannte Rennsportbiographie. Diese wird ausdrücklich NICHT rückwirkend bei Kind-Boris oder dem Friedhofsjungen eingebaut.

## Waldweise: Modell und Enthüllung umgesetzt

Die Krabbelminen-Bowling-Frau übernimmt Salias Weisenrolle. Ihre erste Enthüllung erfolgt nach dem Waldtempel in der Halle der Weisen. Sie hat ein eigenes Skelett mit 15 Gelenken und 7 Animationen, volle erwachsene Proportionen und dieselbe Körpergröße in der Halle, bei Siegel-/Prüfungsszenen und auf Darunias Schultern in den Credits. Die Kameras der Enthüllung und der gemeinsamen Credits-Einstellung sind angepaßt; Cue- und Textzeiten bleiben erhalten.

Junge Salia, ihr Brückenauftritt, Geschichte, Lied und Handlungen bleiben erhalten. Die späteren Okarina-Nachrichten 016B/C/D erklären ihre Freundschaft und die neue Waldweise. Shieks zweideutige Hinweise bleiben bis zur Enthüllung bestehen. Die acht neuen Nachrichten stehen in bowling_waldweise_de.json; insgesamt 706 eigene Nachrichten.

## Weitere Weisen: geplant, noch nicht ersetzt

Thaddäus ist derzeit der Tauchspiel-Leiter. Als Weiser des Wassers ersetzt er die erwachsene Ruto erst in einer späteren Umsetzung; junge Ruto bleibt erhalten.

Nabooru wird später durch Waluigi ersetzt. Der Nutzer hat ausdrücklich noch keinen Einbau beauftragt. Von den beiden gelieferten Paketen wird Mario Party 3 empfohlen: 420 Dreiecke, drei CI4-geeignete Basistexturen, vorhandenes Skelett. [Modellvergleich und Ruto-Speicherrechnung](WALUIGI_MODELLVERGLEICH.md). Vor Einbau müssen Geometrie, Animationen, Beleuchtung und gleichzeitig geladene Modelle jeder betroffenen Szene geprüft werden. Die gegenwärtige Credits-Szene hat im unvergrößerten Modellbereich nur 1472 Bytes frei. Ein zusätzlicher größerer Ersatz braucht daher eine neue Speicheroptimierung bzw. ein geprüftes anderes Ladeschema; kein pauschales Versprechen beliebig vieler Modelle.

## Phantom-Ganon später

Phantom-Ganon wird Philipp Amthor mit einem vom Nutzer noch zu liefernden Smithers-Modell. „Zunivas“ war ein Versprecher, vom Nutzer ausdrücklich zu Smithers korrigiert. Modell und Kampfdialoge jetzt nicht ändern. Pferd, Gemälde, Reit- und Kampfanimationen erst am gelieferten Modell prüfen. Friedrich Merz bleibt der echte Ganondorf. Wenn er Mr Bean erwähnt, nennt er ihn immer Herr Bohne.

Boris behauptet außerdem, „Uga Paluga“ sei schon immer seine Catchphrase gewesen. Ebenfalls keine rückwirkende Bestätigung bei Kind-Boris einbauen.

Mido als Erwachsener: 1060/1061/1068 findet den Spieler selbst nach sieben Jahren immer noch scheiße und ist mit König Zora für eine mögliche Siegesfeier nach Merz’ Niederlage verabredet. Spielername dynamisch. Liedprüfung, Durchgang und Flags unverändert.

Waldweise v2: Sitz am hinteren Schulter-/Halsansatz statt auf der Haarspitze; eigene Sitzkanäle und gemeinsame Credits-Kamera angepaßt. 106A/108F/1090/106B erzählen Tod beim Einsturz unter Merz und Bitte um Warnung in der Vergangenheit. Kein neuer Questablauf. Feste Textzeiten erhalten, wichtige Warnung manuell.

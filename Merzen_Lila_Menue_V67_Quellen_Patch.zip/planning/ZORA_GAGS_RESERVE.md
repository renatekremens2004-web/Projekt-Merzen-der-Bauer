# Zora-Gags in Reserve

Im Erwachsenen-Zora-Reich sind die normalen Zoras eingefroren und fehlen als NPCs. Ergänzt wurde nur das ausdrücklich gewünschte Wiedersehen mit der Zora-Frau. Der Abfluß-Spruch ist bereits beim König und bei Sheik eingebaut. Für zwei weitere eigene Zora-Stimmen sind diese Nutzerideen vorgemerkt:

- „Ich find Morpha mega geil und sexy und heiß, und ich bleib bei diesem Standpunkt, den ich hier vertrete.“
- „Mann, da hat der King echt reife Arbeit geleistet. Ich wollte mir schon immer die Kloake abfrieren.“

Noch keine zusätzlichen NPCs oder Texte für diese beiden optionalen Ideen eingebaut.

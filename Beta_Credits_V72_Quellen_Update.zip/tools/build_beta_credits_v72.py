"""After V71: place the plain beta Goron on the center of Darunia's front carpet in credits."""
from pathlib import Path
import sys
O=Path(sys.argv[1]);p=next((O/'extracted/pal-1.0/assets/scenes/overworld/spot18').glob('*room_1*03000348_ActorEntryList.inc.c'));s=p.read_text();old='{ACTOR_EN_GO2,{-100,40,-1430},{0,0,0},0x7F5C}';new='{ACTOR_EN_GO2,{92,40,-1450},{0,0,0},0x7F5C}';assert old in s or new in s
if old in s:p.write_text(s.replace(old,new))
print('Beta credits: center of front carpet, (92,40,-1450); native cameras unchanged.')

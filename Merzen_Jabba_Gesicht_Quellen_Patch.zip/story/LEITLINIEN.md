# Kokiri-Kapitel: verbindlicher Stand

## Dauerhafte Speicher- und Durchspielbarkeitsvorgabe

Zusätzlich importierte Figuren/Fundstücke vor dem Einbau reduzieren: kleine CI4-Texturen, sparsame Geometrie, eigene unverzerrte Proportionen. Nur zusammen mit dem tatsächlich benötigten Raum laden; bei jeder Ergänzung die gleichzeitige Belegung berücksichtigen. Weiter mit echten 4 MiB testen. Türen, Fluchtwege, Rätsel, Questzustände und native Boßabläufe erhalten. Ziel ist ein vollständiger normaler Spieldurchlauf. Einzelne bestandene Szenenproben als solche benennen; sie ersetzen keinen vollständigen Durchlauf oder Hardwaretest.

Wawario/Wawaluigi: getrennte Modelle aus WawarioBros.glb. Orange Figur in der Festungszelle, blaue Figur außerhalb beim Zelt im Gerudotal, beide nur Erwachsene und Deutsch. Nicht in Kind-/Abspann-Akteurslisten eintragen. Wawaluigi steht seitlich neben dem Zelt, nicht vor dem Eingang. Triangle Guy: alle modellbildenden Mirror-Modifikatoren vor dem Export anwenden; sonst fehlen Gesichtsteile. Frau im erwachsenen Kakariko-Gasthaus bekommt in ihren bislang unveränderten drei Erwachsenenzuständen den Mario/Luigi/Wario/Waluigi/Wawario/Wawaluigi-Kommentar. Stand vor Yellow Guy/Wario: 1.010 eigene deutsche Nachrichten.

Der vollständige Textumbau erfolgt Gebiet für Gebiet. Dieses Kapitel umfaßt den Spielanfang, das Kokiri-Dorf und den Deku-Baum einschließlich der dortigen Tutorials und ersten Reaktionen auf den Tod des Baumes. Spätere Gebiete folgen getrennt.

- Alte Rechtschreibung vor 1996; Anrede Du/Dir/Dich/Dein.
- Der vom Spieler gewählte Name wird über das originale NAME-Steuerzeichen eingesetzt. Keine Festschreibung auf „Link“.
- Fiktive Hyrule-Satire: Mr. Burns verkörpert Friedrich Merz, der durch Geld und unsoziale Politik die Macht gewinnen will. Seine Herkunft ist noch nicht erklärt. Hyrule bleibt Hyrule.
- Friedrich Merz hat den Deku-Baum persönlich verflucht, nachdem dieser ihm den Kokiri-Smaragd verweigert hat. Der Fluch wird im Dungeon gebrochen; seine Folgen sind für den Baum bereits tödlich.
- Der Deku-Baum setzt seine Hoffnung auf den jungen Helden. Seine gemeinschaftlichen Vorstellungen werden mit wenigen leisen Anspielungen dargestellt, ohne politische Lehrrede.
- Navi ist bissig, ungeduldig und spöttisch. Ihre Hinweise bleiben sachlich brauchbar.
- Die Dorfbewohner behalten unterscheidbare Stimmen. Salia steht dem Helden nahe. Midos spätere Beschuldigung ist sein ungerechter Verdacht, keine Aussage des Erzählers über die tatsächliche Ursache.
- Kenntnisse berücksichtigen: Der Baum und Navi wissen mehr als die Dorfbewohner. Nicht jeder NPC kennt bereits Merz' Plan.
- Native Message-IDs, Folge-IDs, Ereignis-Markierungen, Auswahlreihenfolgen, Item-Übergaben, Preise, Questbedingungen, Controllerbelegung und Altersregeln erhalten.
- Textbreiten mit der PAL-Schrift und acht breiten Namenszeichen prüfen. Auswahlfelder an den nativen Cursor-Zeilen ausrichten. Zeitgesteuerte Textboxen behalten ihre Verzögerungs-/Ausblendwerte.
- Vor der Auslieferung echte Textboxen und funktionale Interaktionen im Emulator prüfen. Dem Nutzer ausgewählte Ingame-Beispiele zeigen; keine komplette Pointenliste im Chat oder auf der Download-Seite.

## Mr. Bean anstelle Impas

- Sämtliche Impa-Modelle verwenden Bean, einschließlich Reiterkopf, Weiser und Abspann-Varianten. Die übrigen Rollen und Questbedingungen bleiben erhalten.
- Andere Figuren beschreiben ihn als mutig, kompetent und vertrauenswürdig. Ihre benötigten Weg- und Questhinweise bleiben verständlich.
- Bean kommentiert das Geschehen knapp auf Englisch. Er darf mehr sagen als bloße Ausrufe; der Witz entsteht aus trockenen Bemerkungen, eigenwilligen Schlüssen und seiner unbeholfenen Art.
- In der Halle der Weisen spricht er ausführlicher. Er hat Zelda tatsächlich gerettet, nimmt Verantwortung an und hilft dem Helden bewußt. Er ist selbst ein Held auf seine komische Art.
- Seine englischen Texte sind eigene Formulierungen. Ungeprüfte Zeilen nicht als echte Mr.-Bean-Zitate kennzeichnen.
- Beim Wiegenlied tanzt er anstelle des Pfeifens. Lieddemonstration, Eingabe, Erwerb und Questfortsetzung bleiben original.
- Normale deutsche Sprachfassungs-Texte außerhalb dieses Rollenwechsels werden weiter Gebiet für Gebiet bearbeitet. Bean-Verweise dürfen bereits mehrere spätere Gebiete betreffen.

## Erweiterung: Stadt, Farm und Methusa

- Alte Rechtschreibung gilt auch für neue Alltagsgespräche. Stadtbewohner haben unterschiedliche Themen und berücksichtigen ihre nativen Erst-/Wiederholungsgespräche.
- Methusa (deutscher Name von Kaepora Gaebora) spricht nachdenklich, abwägend, mit Selbstkorrekturen und konkreter Wegweisung; sie verrät ihre Identität erst bei der späteren Begegnung in der Halle der Weisen.
- Der Maskenhändler spielt auffällig auf Majoras Maske und ein Waldportal an. Tatsächliche Leihmasken, Shopregeln und Belohnungen bleiben original.
- Navis Deku-Baum-Kommentar beginnt einen Running Gag. Keine Vorwegnahme von Dodongos Höhle oder Jabu-Jabu.
- Thaddäus ist vorläufig nur ein Gerücht aus Zoras Reich. Später soll er die erwachsene Ruto als Weiser des Wassers ersetzen. Junge Ruto bleibt als eigene Figur erhalten. Noch kein Modellaustausch in diesem Kapitel.
- Ein einzelner unbedeutender Bewohner mit Bart (Nachtdialog 7089) bricht den Ton mit einer ausgiebigen Schimpftirade.

## Goronen und Kakariko

- Merz' Kohleabbau ließ den Höhleneingang einstürzen. Dieser narrative Grund ersetzt die frühere Erklärung der Sperre, ohne die Höhlen-/Bombenregeln zu ändern.
- Darunia ist der Goronenführer in Ocarina of Time. Darmani ist hier nicht gemeint.
- Navis Hinweise äußern ihre Meinung zum jeweiligen Geschehen; notwendige Orientierung bleibt enthalten. Der Mund-Rückblick folgt erst nach erhaltenem Goronen-Opal.
- Explizite Nutzerpräferenz: Keine Lesezeiten für Pointen ändern. Statt dessen die Idee kürzen oder in einen vorhandenen normalen Dialog verlegen. Das gilt auch für spätere Kapitel.

## Mario und Luigi

Talon wird durchgängig als Mario, Basil als Luigi angesprochen, auch von anderen Figuren und auf Schildern. Hauptsprache Deutsch in alter Rechtschreibung; Mario hat „Mamma mia!“, „Wahoo!“ und „It's-a me!“, Luigi „Oh, yeah!“, „Luigi-Time!“ und „Let's-a go!“. Keine lautmalerisch verstümmelte deutsche Grammatik. Luigi deutet sämtliche früheren Bosheiten übermäßig positiv um; andere Figuren beschreiben seine aufdringliche Begeisterung. Preise, Auswahlreihenfolge, Rennzustände, Pferdebesitz und Torereignisse bleiben nativ. Zeitgesteuerte Seiten und Ausblendzeiten bleiben erhalten; für einen Witz wird der Text gekürzt, niemals die Szenenzeit verlängert.

## Thaddäus beim Tauchspiel

Nur der Tauchspiel-Leiter ist hier bereits Thaddäus. Er ist ein eingebildeter, genervter Künstler und Klarinettist; Merz ist für ihn ein Geizkragen, der Kunst nicht respektiert. Bei einer Niederlage nennt er den Spieler einen traurigen Clown. Seine privaten deutschen Texte 0136/0138/013B klonen die originalen Steuerzeichen ausschließlich in unbenutzte Textplätze; Schießbuden und andere Händler behalten ihre gemeinsam genutzten Texte. Einstiegspreis 20 Rubine, 50 Sekunden, fünf Rubine vor der Schuppe und zehn danach, native Belohnung und Speicherflags bleiben bestehen. Feste Lesezeiten niemals für einen Gag verlängern. Rutos spätere Ablösung wird erst in einer späteren Revision umgesetzt.

## Zoras und Jabu-Jabu

König Zora ist ein ahnungsloser Herrscher, der Merz den Saphir für Klimaanlagen versprochen hat. Ruto flieht mit dem Stein vor dem Deal, versteckt sich in Jabu-Jabu und taucht nach der Übergabe unter. Ihr späterer Thronsaal-Auftritt entfällt nur in der deutschen Fassung nach erhaltenem Saphir; die übrigen jungen und erwachsenen Ruto-Auftritte bleiben. Der Wundererbsenhändler ist ein Merz verehrender Scalper; die native Preisleiter von 10 bis 100 Rubinen bleibt unverändert. Navis Zieltexte 0600 bis 065C sind durchgehend individuelle Beleidigungen und enthalten keine taktischen Anweisungen. Die harmlose, ratlose Frage „Vore? Was soll das sein?“ wird nicht sexuell ausgeführt.

Privattexte: 0130 ist der Laubkerl in Jabu-Jabu (Vorlage 10A0), 013C Barinades neue Begrüßung (002D), 013E die dortige Kartenmeldung (0066) und 013F Navis Nachspiel-Kommentar. Der bestehende Guidehinweis 014A reagiert auch schon auf eine mitgeführte Flaschenpost. 013F benötigt den tatsächlich erhaltenen Saphir und ist als Guidehinweis bis zu Zeldas Flucht verfügbar. Navis gewöhnliche Gelegenheiten und Abklingzeiten bleiben nativ. Barinades neue Box ist frei weiterklickbar; bestehende Text-, Titel- und Szenenzeiten werden nicht verlängert.

## Drei Steine, Flucht und Masterschwert

Merz nennt das Kind einen kleinen Pascha, fordert später die CDU-Stimme und rechtfertigt sein Handeln mit dessen Zukunft. Nach dem Schwertziehen sagt er, er habe Mr. Bean ermordet, Bean habe gut gekämpft und sei mit Ehre gestorben; Zelda sei entkommen. Diese neue Aussage wird nur in Merz' bestehender Rede 700A eingefügt. Ihre vier festen Seiten behalten BOX_BREAK_DELAYED(60/90/80) und FADE(50). Andere Bean-Auftritte werden hier nicht umgebaut.

Neue Stadtreaktionen verwenden die nativen Nach-Flucht-IDs 7044/7046–704B/704D/70EB. Der verschachtelte Jabu-/Maskenmiet-Gag gehört dem Mann mit alternativem Schnurrbart (Typ 12), die Volkshelden-Aussage dem alten Mann (Typ 7). Der sterbende Soldat ist nur im nativen Zeitfenster nach der Flucht und vor dem Masterschwert ansprechbar; Event-Markierung und Tod bleiben erhalten. Der Krugraum-Soldat bekommt tags und nachts denselben Zerstörungshumor.

Navi: Privattext 0120 mit nativen Guide-Steuerzeichen aus 0148. Nur deutsch, nur erwachsen und mit erhaltenem Masterschwert, nur über normale Guide-Gelegenheiten. Nach Gesprächsbeginn markiert der Navi-Akteur das reservierte freie Bit 0x1CF in infTable-Wort 28 als gehört; kein Eingriff in normale Hinweiszeiten. Nicht für andere Zwecke wiederverwenden. Alte Rechtschreibung; keine Verlängerung fester Lesezeiten.

## Robert Habeck in der Halle der Weisen

Rauru ist Robert Habeck, durch Merz vom Todesberg gestoßen und bereits tot. Die bisherige Methusa war seine solarbetriebene Geistereule. Er betont diesen Umstand umständlich. Hyrule-Zeitung, örtlich begrenzte Energieinseln, Merz' Sperren, Hallenmagie, Stasis von Held und Navi, mitwachsende Kleidung, Muskelerhalt, schimmelige Ausrüstung, die an exakt sieben Jahre gebundene Zeitreise und die betonfeste Zitadelle werden ausdrücklich erklärt. Die Aussage „Friedrich Merz erzählt“ in der Nutzeranweisung wird im Zusammenhang als Habecks Rede verstanden.

704F läuft über die freien Textplätze 0121 → 0122 → 0123 weiter. Jede Fortsetzung bleibt innerhalb des Textpuffers. Keine zusätzlichen Text-/Kameratimer; die vorhandene Cutscene wartet auf das manuelle Abschließen der Textkette. 7051 behält Ja/Nein und 7052 den Rücksprung auf 7051. Questhinweise, Lichtamulett, Rückkehr und spätere Freigabe der Zeitreise bleiben nativ.

Der Turmbewohner EnHy Typ 12 ist in Kakariko nur erwachsen vorhanden. Als erlaubter Ersatz fungiert der Dachbewohner En_Ani: 5050/5051 erzählen in der Kindheit tags/nachts vom beobachteten Sturz des Mannes im schwarzen Anzug. Seine Erwachsenen-, Masken- und Herzteil-Zweige bleiben unangetastet. 0124 bleibt Navis ursprünglicher Wüstenkoloss-Text und wird keinesfalls überschrieben.

## Nintendo 64 in Jabu-Jabus Innerem

Genau ein kleines Dekoobjekt auf der unteren Plattform von Raum 3, bei der ersten Wiederbegegnung mit Ruto nach dem Sturz. Gehäusebreite 10 Spieleinheiten, etwa ein Viertel der Körperhöhe von Kinder-Link; Controller, Kabel und Kassette mit einheitlichem Faktor. Der vorhandene Zelda-Aufkleber bleibt erhalten. Kein Riesenmodell.

Privater Text 0125 mit Vorlage 0148, hellblau: „Ein Nintendo 64 mit Zelda Ocarina of Time... Ich tu mal so, als hätte ich das nicht gesehen.“ Native Zielerfassung mit Z und Lesen mit C-Up über Elf_Msg2. Kein globales Überschreiben eines Gegnertextes. Keine Schalter-/Itemwirkung, wiederholt untersuchbar, andere Sprachen ohne diese neue Instanz. Bisherige Szenen und Habecks TEXTID-Kette unverändert erhalten.

LEGO X-Wing: kleines Spielzeug im Schattentempel, 24 Einheiten Spannweite; Mann im blauen Hemd im erwachsenen Kakariko bekommt 507B/507C. Dachbewohner unverändert. 599 Nachrichten insgesamt, beide vorhandenen manuellen Seiten bleiben erhalten.

Navi-Gegner-Roasts: direkt, konkret auf gegnerisches Verhalten bezogen und deutlich derber. Nicht jeder Text muß fluchen. Keine beliebigen Persönlichkeits-/Konzeptvergleiche; natürliche Wut, kurze Drohungen gegen die fiktiven Monster und Spott über ihre dummen Angriffe. Alle 93 Seitenzahlen und 599 Nachrichten insgesamt bleiben erhalten.

Zora-Gags: 402D/402E nach Jabu-Jabu verwenden jetzt die Nutzerideen Mido-Haß und den kurzen merkwürdigen Musikklang beim Verlassen der Höhle. Ersetzt werden nur meine allgemeinen Ruto-/Tierarzt-Zusätze. Eigene Ideen des Nutzers haben Vorrang. 599 Nachrichten insgesamt.

Texttempo: Die zuletzt ausdrücklich gewünschte Verdoppelung betrifft nur den Schriftaufbau gewöhnlicher deutscher Seiten; feste Lese-/Szenenzeiten bleiben nativ.

Hyrule-Stadt-Nachschlag: 27 vorher originale Nachrichten ersetzt; 7017 auf Wunsch um den Gesichts-Gag der En_Hy-Typ-1-Frau erweitert, ihren Farmwegweiser erhalten. 28 Änderungen dieser Revision, insgesamt 626. Alle anderen bisherigen Nutzertexte erhalten. En_Mu verwendet seinen nativen Fünferpool; Bettler- und Hundezustände behalten Item-/Belohnungsregeln. Keine Änderung der NPC-Sichtbarkeit oder Marktplatzkamera.

Alltagsgags: sechs neue Nutzerideen, neun vorher originale Textzustände (506A/B, 5077/78, 7002/03/06, 7120/21). Zimmerleute Typ 2/3, Hyrule-Nachtwachen, Schloßtorwache und zwei Ladenbesucher. Insgesamt 635; bisherige 626 eigene Texte erhalten. Native Zeit-/Zoll-/Torregeln erhalten.

NPC-Stimmen: Deku-Ball beim alten Mann, Bartwachs beim roten Schnurrbart und Zuständigkeitsfragen bei der Todesberg-Wache. Spinnenfamilie mit ratlosem Fluchdialog ohne das ausdrücklich zurückgenommene ‚fucking‘. Irrlichtsammler ist erzählerisch die frühere Krugraum-Wache; zerstörte Stadt als bitterer Rückbezug. Private deutsche Begrüßungen 0127/012C/012D für Basar/Tränke/Krabbelminen, 012E für Schießbuden. Originale Preise/Quests/Belohnungen und dynamische Zähler erhalten. 46 zusätzliche Einträge und Kokiri-Nachtrag 100A, insgesamt 681.


Eule/Tagesgags: alle 34 En_Owl-Textplätze samt TEXTID-Fortsetzungen haben eigene Dialoge; 33 Stimmen nochmals geschärft. Keine Identitätsenthüllung vor der Halle der Weisen, bestehende Kontrollsequenzen/Zeiten erhalten. Zitteraal-Gag nun ältere Marktfrau Typ 6 (7021/22/704A), Bean-Rettungsgag Mann im schwarzen Oberteil Typ 4 (7023/24/704B), beide tagsüber auch in Wiederholungen ohne Flasche erreichbar. Nachtwachen 7003 betonen ihren Nachtdienst. Kerngag aus bedingtem Flaschenkäufertext 700C entfernt; Handel/Preise erhalten. Merz nennt Bean bei jeder Erwähnung „Herr Bohne“ (2019/201E/700A), alle anderen Figuren bleiben bei Mr. Bean. Weiterhin 681.

Okto, der Oktorok: zusätzlicher friedlicher NPC rechts im Jabu-Jabu-Eingangsraum, Parameter 7F00. Dialog 00F8 klont den normalen 0022-Typ; Vorstellung, Vorurteils-Gag und Distanzierung vom großen Oktorok. Wiederholbar, ohne Quest/Bezahlung. Nur Okto ist NPC, kein Gegner, keine Angriffs- oder Trefferkollision, kein Raum-Clear-Gegner. Normale Gegner und großer Oktorok unverändert. Auch nach geräumtem Raum vorhanden. Vorherige 681 Texte erhalten, jetzt 682.

Platzkorrektur Okto: tatsächliche Wasseroberfläche in Raum 0, (140,-330,0), statt trockenem alten Standort. Nativer Wasserpegel und Wasserringe; vom trockenen Ufer ansprechbar, vor und nach Raum-Clear. Alle 682 Texte bytegleich erhalten.

Wald-Auftakt: gleicher entspannter Kokiri als Erwachsener 105F/1076; Boris erst vorgestern Treppe an Windmühle heruntergestürzt, behauptet langjährige Rennsportkarriere und Catchphrase Uga Paluga. Nicht rückwirkend bestätigen! Shiek alte Freundin mehrdeutig, mit Arbeits-/Rollen-/Glückshinweisen. Waldweise später Krabbelminen-Frau nach Modellimport; Phantom-Ganon später Amthor mit Smithers-Modell. Details planning/WALDKAPITEL.md. 695 eigene Nachrichten.

Mido Zukunft 1060/1061/1068: findet Spieler nach sieben Jahren weiter scheiße, dynamischer Name, Verabredung mit König Zora für mögliche Siegesfeier nach Merz-Niederlage. Native Liedprüfung/Wegfreigabe erhalten. Jetzt 698 eigene Nachrichten.

Waldweise: Krabbelminen-Frau erst nach Waldtempel enthüllen. Erwachsene Proportionen mit eigenem Skelett, später Siegel und Credits auf Darunias Schultern. Junge Salia bleibt. 706 eigene Nachrichten. Thaddäus als Wasserweiser und Nabooru-Ersatz weiterhin Zukunftspläne, vor jedem Modell neue Szenenspeicherprüfung.

Aktueller Nachtrag: Phantom Ganon ist Philipp Amthor, dargestellt durch Smithers' Kopf auf dem nativen Bosskörper. Die erste Enthüllung zeigt zunächst Burns' Kopf. Neue Begrüßung 209B: „Sooo, genug Schabernack!“. Navi 061A/062B zweifelt an 15 oder 55; 108E nennt Amthor. Nur deutsche Bossnamens-Platte ersetzt, Pferd/Körper/Skelett/Kampf behalten.

Bean 5022/5025/5026/502B behält seine knappe englische Stimme. Tatsächlicher Tod: Kopf bleibt beim Reiten an einem Ast hängen, Sturz, Genickbruch. Kein Kniebruch. Merz' Behauptung eines ehrenvollen Kampfes wird von Bean beiläufig als schmeichelhaft zurückgewiesen.

Darunia rechtfertigt Chefposten und spätere Weisenrolle durch Stärke, Steineessen, Rollen und Hitze-/Lavabeständigkeit: Fähigkeiten aller Goronen. Goronen und Sohn stellen die behauptete Einzigartigkeit in Frage. Eigene frühere Nutzerideen, insbesondere Umarmungs-Warnung, bleiben erhalten.

Marktplatz nach Zeldas Flucht: langer unveränderter Jabu-Einkaufsdialog 7044 beim blauen Mann mit Schnurrbart am Brunnen; kürzerer bisheriger 7046 beim Mann auf der hohen Plattform. Nur deutsche Nachrichtenwahl tauschen, keine NPCs versetzen; vorherige Stadtdialoge und Maskenreaktionen erhalten.

Deku-Baum 1091/1029/102A: nach beseitigtem Parasiten völlig zuversichtlich; letzter Satz vor nativem Tod „Nichts kann diesen Tag ruinieren!“. Seine Zuversicht ist der Gag, keine Änderung an der Todesursache oder Szene. Mido 1045: Kompost-Geruch, geschrotteter DEKU-BAUM, schlimmster Tag der Kokiri-Geschichte und alle sehen aus wie sieben. Die Transkriptkorrektur des Nutzers gilt: Deku-Baum. Insgesamt 962 eigene deutsche Nachrichten.

Okto-Nachtrag: 00F8 enthält Hola/Amigo/Muchacho/Compadre und den bisherigen Vorurteils-/großer-Oktorok-Gag. Neue private Nachricht 209C für Wiedersehen, Fischmaul-Erinnerung und Ehren-Oktorok im Wassertempel; 00F9 als Nachtschwärmer-Itemtext bleibt erhalten. Native Instanz am festen Eingangsbecken (−195/765/810), alle drei Hallenpegel lassen Wasserbox 0 unverändert. Nur erwachsener Spieler, Deutsch; wiederholbar, kein Kampf oder Inventargegenstand für den Ehrentitel. 963 eigene deutsche Nachrichten.

Phantom-Köpfe v2: Burns aus dem vertrauten CC-BY-Merz-Modell, nur Kopf/Hals ohne Jacke und hinteren weißen Kragen. Keine zusätzliche Verformung der ursprünglichen Gesichtsgeometrie. Smithers ohne Polygonreduktion im Gesicht, mit grauem Haar/Brauen, eigener scharfer Farbpalette und ursprünglichen Augen/Brillen. Beide Köpfe 1650 Modelleinh. hoch statt 1800; Größenänderung gleichmäßig.

## Feuertempel und Wallace

Der namensgleiche Gorone beklagt den Bombenwurf und beleidigt zunächst seinen eigenen Namen. Er entschuldigt sich beim Spieler und übergibt Wallaces feuerfestes Gewand. Merz zwingt Goronen zur unterbezahlten Schichtarbeit im Tempel. Wallace als Erwachsener ersetzt einen Gefangenen im inneren Felslabyrinth; normale Befreiung und Flucht bleiben erhalten. Wallace Hammer ersetzt den deutschen Itemnamen in Fund-/Beschreibungstext und Pausenmenü. Orange Tunika behält Hitzeschutz und Ausrüstungs-ID; das ursprüngliche rote Icon bleibt.

Darunia bleibt bis zu seinem Feuertempelauftritt Darunia. Erst die Feuerweisenrolle und deren spätere Auftritte übernimmt Wallace, mit eigenen Proportionen und kleinen Bewegungen. Die Krabbelminen-Frau sitzt in den Credits auf seinem Schulter-/Rückenansatz. Der zuvor unbeschriebene bärtige Mann im Kakariko-Gasthaus schwärmt unangenehm von Volvagia; Navi verweist im Boss-Zieltext darauf. Sheiks Bolero-Gedicht verwendet die Nutzerreime über Feuer/Einkauf, Wallace/Todesberg, Bean/Flieger und den Teleport-Song gegen Hochlatschen. Native Liedsteuerung und feste Zeiten bleiben erhalten.


Erwachsene Zoras: Die Typ-6-Zora vom Hylia-See identifiziert sich nun als Frau und dankt dem Spieler; gleicher nativer Körper ohne Klischee-Umbau. Nur für erwachsenen deutschen Spielstand ergänzt sie die trockene alte Stand-Zora-Position in Raum 1. Die drei optionalen Zusatzgags brauchen spätere Gesprächspartner; keine beliebig hinzugefügte Gruppe im eingefrorenen Reich. König: Klimaanlagen-/Fischnasen-/Ruto-Wartegag vor der Rüstung (4012/401F), Abfluß-Hinweise 4013/4045, erst nach Wasseramulett und Dank-/Rüstungsflag der endlose Auftauoptimismus 4044. Rüstung und Rezept-Tausch haben Vorrang. Sheik: Eis/Fleiß, Merz/Bockshorn, Erz, faltbare Harfe in Arschtasche, gute Hosentaschen seit seiner Männerrolle. Alle nativen Lied-Cues bleiben.

Navi 0180: Silberrubine sind wertloser Rätselschrott. 0189: zunächst falsche Auftauprognose nach dem Tempel, danach ausdrücklicher Widerruf („nur für den Gag“, Fischkönig wirklich auftauen). 01AB: Wasserschlangen-Karte, übertriebene Boss-Vorfreude; nativer Spielername bleibt. 0154: zurück nach Kakariko und Mühle versauen. 0152, 0153, 0105 und 015F unverändert. Sonnenrätsel 021F sagt unmittelbar, bei Sonnenaufgang einen Pfeil in die Sonne zu schießen.

Zora-Rüstung getragen RGB 110/195/240 (Himmelblau), übrige Tunika-Farben einschließlich Wallace-Orange unverändert. Kein Umbau der Gerudo-Renderer; deren ursprüngliche PAL-1.0-Vererbung der Zeichenfarbe bleibt. Steuerkreuz unten schaltet nach Besitz der Eisenstiefel als Erwachsener zwischen Eisen/Kokiri um. Native Inventory_ChangeEquipment, Player_SetEquipmentData und Player_SetBootData; der ursprüngliche currentBoots/prevBoots-Wechsel verarbeitet Sinken/Schwimmen. Nur Druckflanke, kein Wechsel im Dialog/Pause/Game-over/Cutscene/Übergang oder beim Reiten. Keine neuen Inventar-IDs.

Wawario-Nachtrag: Verliebtes Paar 7025/7026 (Kind, Markt) und 5089/508A (Erwachsene, Kakariko) lästert über Waluigis Schulverweis und sieben Jahre ohne Fortschritt. Überschreibt ausdrücklich deren bisherige Marktsprüche. Fanboy/Chum-Chum-Arbeitsverweigerung 505C nur erwachsener Tages-Wiederholungsdialog des grün gekleideten Mannes in Mr. Beans Haus. Rock and Ball Torture 507D beim blauen Mann im selben Haus nachts, Horrorkid 5088 beim alten Mann im Gasthaus nachts. Alle fünf vorher originalen Textplätze neu, keine Ersatzmodelle. Wallace 019A in Dodongos Höhle und 209D/209E im Feuertempel mit Käse, Wensleydale, Gouda, Erfindergeist und altbackenen Sprichwörtern geschärft. Forschung/Kohleabbau, Zellschalter und Hammerwegweiser erhalten. Halle der Weisen unverändert.


## Yellow Guy und Wario

Normaler Yellow Guy als Kind am Hyrule-Schloßweg direkt nach dem Marktausgang; Punk Yellow Guy als Erwachsener vor Ganons Schloß. Gleiche naive, wörtliche Denkweise mit gelegentlich schiefer Grammatik. Punk haßt ausdrücklich „Frimdrich Merz“ (absichtlich falsch) und will das System zerstören. KEIN Metall-Onkel: Nutzer hat diese Anspielung ausdrücklich verworfen. Eigene Dialoge auf Basis geprüfter Stilmerkmale, keine langen Originalzitate.

Wario ausschließlich in der KIND-Zeitebene Kakarikos, auch nachts. Die anfängliche Erwachsenen-Angabe wurde vom Nutzer korrigiert. Waluigis erster Geistertempelauftritt ist in der Vergangenheit. Wario sorgt sich um den Freund, der sich wegen des Spotts aller beweisen will. „WAH! IT'S A ME, WARIO!“ und „HAVE A ROTTEN DAY!“ erhalten. Wawario/Wawaluigi bleiben unverändert nur erwachsen.

Normales Yellow-Guy-Modell 1.393 Dreiecke aus 17.326, Punk 1.463 aus 8.712 nichtdegenerierten Dreiecken, Wario vollständig mit 460. Eigene Proportionen, dezente vierteilige Bewegung, native Beleuchtung/Nebel/Tiefentest, nur raumlokale Daten, keine zusätzlichen Objekt-Slots. Pupillen des normalen Yellow Guy durch zwei kleine Ausschnitte des Originalatlas erhalten. Texte 608F/6073/601C klonen unbenutzte Standardtextplätze, alle bisherigen 1.010 Nachrichten bleiben erhalten; jetzt insgesamt 1.013.


Yellow Guy, Korrektur v2: Er stellt sich NICHT als Yellow Guy vor. Nur diese Selbstbenennung aus 608F entfernt. Punk-Outfit mit den originalen UVs statt schwarzer Ersatzflächen: farbige Ärmel, Haut und Aufnäher aus yp.png. Schwarze Kleidung behält einen kleinen dunklen Reflexionswert, damit native N64-Beleuchtung ihre Form zeigen kann. Eigene Proportionen, Geometrie, Normalen, Standorte und Animation bleiben unverändert; keine zusätzliche Geometrie.


Punk-Arme v3: Cube.008 enthält Jacke UND Arme. Nur außenliegende Armflächen bewegen; Jacke am Körper belassen. Schulterpunkte ±0,72 / Höhe −1,28 in den Quellen, 45 Grad Ruhepose. UV-Vereinfachung darf gelbe Arme nicht in schwarze Atlasbereiche verschieben; Hautfarbe stabil zuordnen, Jackenfarben vor Reduktion sichern. Insgesamt 1.464 Dreiecke statt 1.463, gleiche Größe. Selbstvorstellung weiterhin entfernt; Wario unverändert nur Kind.

Die dünnen Arme vor der Reduktion vom Jackenmesh trennen; sonst kollabiert ihre Silhouette. Endstand 1.464 Dreiecke, praktisch gleiches Gesamtbudget wie vorher. Blender immer mit --python-exit-code 1 für Konvertierungsfehler starten.


Größenkorrektur: Blauer Wawaluigi beim erwachsenen Gerudo-Zelt 125 auf 100, Zukunfts-Wallace im Feuertempel und ab Feuerweisenrolle 110 auf 90 Spieleinheiten. Alle Achsen und eigenen Drehpunkte gleichmäßig skalieren; keine Topologie-, Textur- oder Normalenänderung. Kind-Wallace bleibt unverändert bei 90. Orange Wawario, normaler Wario und Weiser Waluigi bleiben gleich. Fokus/Zylinder passend zur kleineren Figur. Krabbelminenfrau behält ihre Größe und ihre Knochenlängen; ausschließlich drei Credits-Sitzanimationen tiefer/enger auf neue Schulterbreite abstimmen. Native Credits-Kameras, Cues und Zeiten erhalten. Gewünschte Nachweise: echte MP4 der vollständigen Befreiung mit nativem Schalter und Fluchtweg sowie gemeinsame Todesberg-Credits, jeweils 4 MiB.

Wallaces private Befreiungskamera im Feuertempel weiter zurück (×1,9 horizontal, Auge +40, Ziel +48), ausschließlich EnGo2_IsAdultWallace; Fluchtweg und Zustandszeiten unverändert. Credits-Kamera unverändert. Triangle Guy 608A behält seine Begrüßung und erhält danach drei normale Textseiten zum Triforce des Mutes, echtem NAME-Platzhalter und Unkäuflichkeit.

Laufkorrektur: Zukunfts-Wallace bleibt Höhe 90, bekommt zehn starre Matrixgruppen mit Hüften/Knien/Füßen und eine rein visuelle IK-Laufbewegung im nativen Fluchtzustand 2. Seine AI, Zeiten, Schalter, Fluchtweg und Belohnungen bleiben gleich. Bowling-Schultersitz bleibt auf Höhe 90 angepaßt. Weisen-Waluigi jetzt Faktor 0,75 (vergleichbare Standpose 73 statt 98, Naboru 65); blaue Wawaluigi-Figur unverändert. Zugehörige Nahaufnahmen in Enthüllung, Halle, Finale und Credits auf die Größe abstimmen, ausschließlich Kamerakoordinaten. Alle Dialoge, einschließlich Triangle Guys alter Begrüßung plus Zusatz, unverändert. `build_walk_followup.py` folgt zuletzt auf `build_character_sizes.py`.

Wallaces Befreiung lebhafter: eigene Ellbogengruppen ergänzen (jetzt zwölf Matrizen), abwechselnd mit den Armen gestikulieren, Kopf und Körper leicht wippen lassen, beim Weggehen federnder auftreten. Nur Gefangenenrolle im Feuertempel; Weise/Finale/Credits behalten ihre bisherige Bewegung und den bestehenden Schultersitz. Keine zusätzlichen Dreiecke, gleiche Höhe 90. Native Befreiung, Weg, Zeiten, Kameras und Dialoge unverändert. `build_wallace_cheer.py` ist jetzt der letzte Schritt nach `build_walk_followup.py`. Echte MP4 der Befreiung und erneute gemeinsame Credits mit 4 MiB prüfen.

Brunnen-/Schattentempel-Dialoge: 19 deutsche Textstellen nach Nutzervorlage ersetzt. Verrutschte IDs 01526/01528/01529/0152B/01591 bedeuten 0126/0128/0129/012B/0191; 0191 ausdrücklich unverändert. 0535/058E/051D sind 5035/508E/501D. Guru-Gurus wütende Schuhe gehören zu 5034. Den Oben-/Tiefe-Witz auf 0129 und 012A verteilen. Sheik rechtfertigt Hyrules Foltervergangenheit umständlich; seine lange Rede auf einen nativen Textpuffer gekürzt, wichtige Tempelzugangs-/Weiseninformation erhalten. Keine festen Lesezeiten ändern, nur manuell weitergeklickte Seiten. Alte Rechtschreibung. Alle anderen Nachrichten, Kopf-/Textboxeigenschaften, Spielername, Fortsetzungen, Quests, Kameras und Modelle erhalten. `build_shadow_dialogue.py` als letzten Textschritt nach den bestehenden Kapitel-/Modell-Buildern ausführen; er ersetzt ausschließlich die 19 deutschen Textkörper und bewahrt insbesondere Habecks vorhandene TEXTID-Kette.

Tripple T durch die neue Shuffling-Vorlage ersetzen: 2.000 Dreiecke, 22 eigene Knochen, eigene Proportionen und Gesichtskacheln. Während der nativen Auftauch-Cutscene ruhig halten; erst danach tanzen, Wurzel X/Z fest. Größe 60 und ursprüngliche Blickrichtung erhalten. Keine neuen Sahur-Texte. Den allgemeinen Windmühlen-Spruch 5085 beim tagsüber erreichbaren bärtigen Mann im erwachsenen Kakariko durch die Zigaretten-/Krabbelminen-Explosion ersetzen; andere Nutzertexte erhalten.

Fanboy unverändert zusätzlich in Wassertempel-Raum 7, Chum Chum in Raum 19, getrennt und auf festen trockenen Böden. Comic-Gegenstück: Fanboy schwärmt von seinem Lieblingscomic, den er Chum gegen Langeweile gegeben hat; Chum hat ihn im Wasser versenkt. Neue unbenutzte Textplätze 7068/7069. 608D/608E gehören Wawario/Wawaluigi und bleiben zwingend erhalten. Chums Augen in beiden Tempeln mit Originalflächen und leicht vorgezogenen Pupillen korrigieren; Größe/Proportionen unverändert. Flachen Thaddäus nur etwas weiter reduzieren: 1.145 auf 972 Dreiecke, weiterhin statisch, ohne Kollision. Gewünschte MP4: lebendiger Thaddäus im Wassertempel, vollständig nativer Auftritt einschließlich Animationen. Neue letzte Modellschritte: `build_sahur_shuffle.py`, `build_water_comic_heroes.py` nach den bisherigen Buildern. Keine globalen Text-/Modellresets danach ohne die vollständige Folge erneut anzuwenden.


Ben/Eishöhle: Chum erst mit blauem Feuer aus kleinem rotem Eis befreien; permanenter freier Schalter 30. 706A Ben, 403D Fanboy, 4040 Chum, 706B Plastik-Zora. Wald-/Wasser-Comic-Gags bleiben erhalten. Letzter Builder build_ben_ice.py nach build_water_comic_heroes.py. Ben nur erwachsen außerhalb Feuertempel; eigene Proportionen/leichte Rotationen, Ice-Helden getrennt, keine Rätselwege blockieren.


Jabba: 71B3, Kinder-Hyrule-Feld. Immer erst den vorgegebenen huttischen Satz, danach die deutsche Klammerübersetzung. Eigenes Objekt 0x0192 am Ende der DMA-Liste; nur normale Kinder-Listen vor/nach den drei Steinen, niemals Flucht-/Abspann-Listen. Eigene Proportionen und native Beleuchtung. build_jabba.py als letzten Builder nach build_ben_ice.py anwenden.

Jabbas Gesicht hat Vorrang vor Körperdetails: eigene Gesichts-Texturfläche und mehr Geometrie an Lidern, Nase, Mund und Wangen; Bauch/Schwanz dafür vereinfachen, Gesamtbudget erhalten.

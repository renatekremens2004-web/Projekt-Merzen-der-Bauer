# Merzen der Bauer – Mr. Burns und Mr. Bean in Hyrule

Deutsche Europa/PAL-1.0-Modifikation von **Ocarina of Time**. Mr. Burns verkörpert Friedrich Merz und ersetzt die menschlichen Ganondorf-Gestalten; Mr. Bean übernimmt Impas Rolle. Das Smithers-Bosskampfprojekt ist ein getrenntes Projekt.

## Aktuelle Fassung: Beans ursprüngliche Proportionen

Bean wurde aus dem bereitgestellten Wii-FBX neu gebunden. Sein Modell wird einheitlich skaliert und verwendet jetzt die Gelenkabstände des Originalmodells. Die langen Impa-Beine und -Arme werden nicht mehr in Beans Körper hineingezogen. Alle **1.258 Quelldreiecke**, die Kopf- und Gesichtsform sowie der 128×128-Texturatlas bleiben erhalten.

Die ursprünglichen Animationswinkel werden mit den passenden Körpermaßen abgespielt. Bei normalen Auftritten und als Weiser paßt die rein visuelle Wurzelbewegung zu seiner Hüfthöhe. Beim Reiten bleibt der ursprüngliche Sattelpunkt erhalten. Einige Kameraeinstellungen beim Wiegenlied und beim Reiten wurden neu eingerahmt. Szenenlicht, Oberflächennormalen, Nebel und Ein-/Ausblenden bleiben wirksam.

## Spielen mit BPS-Patch

Es werden **keine vollständigen ROMs** veröffentlicht.

1. Die eigene unveränderte Europa/PAL-1.0-ROM als `.z64` entpacken. Erwartete MD5: `e040de91a74b61e3201db0e2323f768a`.
2. In [RomPatcher.js](https://www.marcrobledo.com/RomPatcher.js/) die Original-ROM und [den aktuellen BPS-Patch](patches/Mr_Burns_Mr_Bean_DE_PAL10_Proportionen.bps) auswählen.
3. Das erzeugte Spiel im N64-Emulator öffnen. Normale PAL-Spielstände verwenden; ältere Emulator-Save-States enthalten noch die alten Modelldaten.

Die Patch-Ausgabe wird mit RomPatcher.js bytegenau gegen die gebaute ROM geprüft. Prüfsummen stehen in [SHA256SUMS.txt](SHA256SUMS.txt). Das Spiel benötigt weiterhin **4 MB RAM** und funktioniert auch mit 8 MB. Eine zusätzliche Detailstufe durch das Expansion Pak gibt es nicht.

## Handlung und Spielregeln

152 Kokiri-/Deku-Baum-Nachrichten und 30 Bean-Nachrichten beziehungsweise Verweise auf ihn sind überarbeitet: insgesamt **182 deutsche Nachrichten**. Weitere Gebiete enthalten überwiegend die Originaltexte. Die gesamte Merz-Handlung ist noch nicht fertig.

Bean spricht selbst geschriebene englische Kommentare und tanzt beim Beibringen von Zeldas Wiegenlied. Andere Figuren sprechen Deutsch in alter Rechtschreibung. Der vom Spieler gewählte Name wird weiterhin nativ eingesetzt. Item-, Alters-, Ausrüstungs-, Shop-, Lied- und Questregeln bleiben erhalten. Es gibt keinen Inventarfilter oder Reparaturcode. Phantom-Ganon und die große Ganon-Monsterform bleiben unverändert.

## Ingame-Beispiele und Prüfung

Aktuelle, unveränderte Emulatoraufnahmen: [Bean im Schloßhof](previews/bean-proportions/Schlosshof.png), [beim Wiegenlied](previews/bean-proportions/Wiegenlied.png), [auf dem Pferd](previews/bean-proportions/Pferd.png), [in der Rückblende](previews/bean-proportions/Pferd_Rueckblende.png) und [in der Halle der Weisen](previews/bean-proportions/Halle_der_Weisen.png).

[Prüfung dieser Revision](TESTING_PROPORTIONEN.md) und [maschinelle Nachweise](validation/bean-proportions/). Ein vollständiger Spieldurchlauf und echte N64-Hardware sind weiterhin nicht geprüft. Finger und Gesicht verwenden vereinfachte Animationen.

Die früheren Berichte [TESTING.md](TESTING.md), [TESTING_KOKIRI.md](TESTING_KOKIRI.md) und [TESTING_PAL_V2.md](TESTING_PAL_V2.md) dokumentieren die jeweiligen früheren Fassungen.

## Selbst bauen

Grundlage: [zeldaret/oot](https://github.com/zeldaret/oot), Commit `14759abf9abb4295de142cdc1452998630ea70fb`. Die vorbereiteten Modelldaten und Tänze sind enthalten; für einen normalen Neubau ist Blender nicht erforderlich.

1. Die eigene PAL-1.0-ROM nach `baseroms/pal-1.0/baserom.z64` im OOT-Verzeichnis legen und `make setup VERSION=pal-1.0 N_THREADS=4 -j4` mit den im OOT-README beschriebenen Werkzeugen ausführen.
2. Im Mod-Projekt nacheinander ausführen:

```sh
python3 tools/build_mod.py /pfad/zum/oot pal-1.0
python3 tools/build_story.py /pfad/zum/oot
python3 tools/build_bean.py /pfad/zum/oot
```

3. Im OOT-Verzeichnis ausführen:

```sh
make VERSION=pal-1.0 COMPARE=0 N_THREADS=4 -j4
make compress VERSION=pal-1.0 COMPARE=0 N_THREADS=4 -j4
```

4. Mit der OOT-Python-Umgebung und MIPS-binutils auf PATH: `python tools/verify_bean_revision.py /pfad/zum/oot /pfad/zur/vorherigen/Bean-ROM.z64`. Als Vergleich dient die bisherige Bean-Produktionsfassung mit SHA256 `2c33901bb6f34e66a84ce2cfecca84bdaf4469d01528f4898950fa19425f76d3`. Diese Vergleichs-ROM bleibt lokal und ist nicht im Projekt enthalten. Die älteren Vergleichswerkzeuge benötigen andere, ebenfalls lokale frühere ROM-Fassungen.

Ausgabe: `build/pal-1.0/oot-pal-1.0-compressed.z64`. Test-ROMs mit direktem Szenenstart werden niemals als Produktionsfassung ausgegeben. Lokale Sicherungen unter `tools/originals/` gehören nicht in Veröffentlichungen.

### Modellvorbereitung wiederholen

Die Originaldateien liegen unter `models/bean/`. Nur zur erneuten Vorbereitung werden Blender und NumPy benötigt:

```sh
blender -b --python tools/export_bean_fbx.py -- models/bean/Mr_Bean.fbx tools/bean_source.json
python3 tools/rebind_bean.py
```

Anschließend die drei Generatoren wie oben ausführen. [Modellnachweise](CREDITS.md) und [Handlungsleitlinien](story/LEITLINIEN.md).

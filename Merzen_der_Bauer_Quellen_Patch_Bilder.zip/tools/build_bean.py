from pathlib import Path
import json,re,collections,math,sys
ROOT=Path(__file__).resolve().parent
if len(sys.argv)!=2:raise SystemExit('Usage: python3 tools/build_bean.py /path/to/oot')
R=ROOT;O=Path(sys.argv[1]).resolve();A=O/'extracted/pal-1.0/assets/objects/object_im';B=ROOT/'originals/bean'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
m=json.loads((R/'bean_bound.json').read_text());vs=m['vertices'];palette={b:i for i,b in enumerate(m['palette'])}
def rect(t):
 u=[vs[v]['uv'][0]/32 for v in t];v=[vs[v]['uv'][1]/32 for v in t]
 return [max(0,int(math.floor(min(u)))-1)//8*8,max(0,int(math.floor(min(v)))-1),min(127,int(math.ceil(max(u)))+1),min(127,int(math.ceil(max(v)))+1)]
def union(a,b):return [min(a[0],b[0]),min(a[1],b[1]),max(a[2],b[2]),max(a[3],b[3])]
def area(a):return ((a[2]-a[0]+8)//8*8)*(a[3]-a[1]+1)
groups=[]
for tri in sorted(m['triangles'],key=lambda t:(rect(t)[1]//24,rect(t)[0],rect(t)[1])):
 box=rect(tri);assert area(box)<=2048,box
 fitting=[(area(union(g['rect'],box))-area(g['rect']),i) for i,g in enumerate(groups) if area(union(g['rect'],box))<=2048]
 if fitting:
  _,i=min(fitting);g=groups[i];g['rect']=union(g['rect'],box);g['tris'].append(tri)
 else:groups.append({'rect':box,'tris':[tri]})
lines=['/* User-supplied Mr. Bean Wii model, adapted to the native Impa rig. */']
def u64array(name,values,size):
 data=b''.join(int(v).to_bytes(size,'big') for v in values);data+=bytes((-len(data))%8)
 lines.append('static u64 '+name+'[] = {');lines.extend('0x'+data[i:i+8].hex().upper()+',' for i in range(0,len(data),8));lines.append('};')
pal=m['texture_palette'];rgba=[((pal[i]>>3)<<11)|((pal[i+1]>>3)<<6)|((pal[i+2]>>3)<<1)|1 for i in range(0,768,3)]
u64array('gBeanTextureTLUT',rgba,2);u64array('gBeanTexture',m['texture'],1)
packed=[];commands=[]
for g in groups:
 box=g['rect'];commands+=['gsDPPipeSync(),','gsDPLoadTextureTile(gBeanTexture, G_IM_FMT_CI, G_IM_SIZ_8b, 128, 128, %d, %d, %d, %d, 0, G_TX_CLAMP, G_TX_CLAMP, G_TX_NOMASK, G_TX_NOMASK, G_TX_NOLOD, G_TX_NOLOD),'%tuple(box)]
 adjacent=collections.defaultdict(set)
 for i,t in enumerate(g['tris']):
  for v in t:adjacent[v].add(i)
 remaining=set(range(len(g['tris'])))
 while remaining:
  cache=set();front=set();batch=[]
  while True:
   candidates=front&remaining
   if not candidates:
    if batch:break
    candidates={min(remaining)}
   fitting=[i for i in candidates if len(cache|set(g['tris'][i]))<=32]
   if not fitting:break
   i=min(fitting,key=lambda i:(len(set(g['tris'][i])-cache),i));t=g['tris'][i];batch.append(t);remaining.remove(i);cache.update(t)
   for v in t:front.update(adjacent[v])
  ordered=sorted(cache,key=lambda v:vs[v]['bone']);slot={v:i for i,v in enumerate(ordered)}
  for bone,itr in __import__('itertools').groupby(ordered,key=lambda v:vs[v]['bone']):
   group=list(itr);offset=len(packed);packed.extend(vs[v] for v in group)
   commands+=['gsSPMatrix((Mtx*)0x%08X, G_MTX_NOPUSH | G_MTX_LOAD | G_MTX_MODELVIEW),'%(0x0D000000+palette[bone]*64),'gsSPVertex(&gBeanVertices[%d], %d, %d),'%(offset,len(group),slot[group[0]])]
  for i in range(0,len(batch),2):
   a=[slot[v] for v in batch[i]]
   if i+1<len(batch):commands.append('gsSP2Triangles(%d,%d,%d,0,%d,%d,%d,0),'%tuple(a+[slot[v] for v in batch[i+1]]))
   else:commands.append('gsSP1Triangle(%d,%d,%d,0),'%tuple(a))
lines.append('static Vtx gBeanVertices[] = {')
for v in packed:lines.append('{{{%d,%d,%d},0,{%d,%d},{%d,%d,%d,255}}},'%tuple(v['position']+v['uv']+[n&255 for n in v['normal']]))
lines+=['};','static Gfx gBeanBodyDL[] = {','gsDPPipeSync(),','gsDPSetCycleType(G_CYC_2CYCLE),','gsDPSetRenderMode(G_RM_FOG_SHADE_A, G_RM_AA_ZB_OPA_SURF2),','gsSPDisplayList(0x0C000000),','gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, 0, 0, 0, TEXEL0, PRIMITIVE, 0, COMBINED, 0, COMBINED, 0, ENVIRONMENT, 0),','gsDPSetPrimColor(0, 0x80, 255, 255, 255, 255),','gsSPClearGeometryMode(G_CULL_BACK | G_CULL_FRONT | G_TEXTURE_GEN | G_TEXTURE_GEN_LINEAR),','gsSPSetGeometryMode(G_LIGHTING | G_SHADE | G_SHADING_SMOOTH | G_ZBUFFER | G_FOG),','gsDPSetTextureLUT(G_TT_RGBA16),','gsDPLoadTLUT_pal256(gBeanTextureTLUT),','gsDPSetTextureFilter(G_TF_BILERP),','gsSPTexture(0xFFFF,0xFFFF,0,G_TX_RENDERTILE,G_ON),']+commands+['gsSPEndDisplayList(),','};']
(A/'bean_model.inc.c').write_text('\n'.join(lines)+'\n')
cpath=A/'object_im.c';hpath=A/'object_im.h';c=original(cpath);h=original(hpath)
dls={b['dl'] for b in m['bones'] if b['dl']!='NULL'}|{'gImpaHeadMaskedDL','gImpaHandPointingDL'}
for dl in sorted(dls):
 p=A/(dl+'.inc.c');original(p);p.write_text(('    gsSPDisplayList(gBeanBodyDL),\n' if dl=='gImpaTorsoDL' else '')+'    gsSPEndDisplayList(),\n')
 c=re.sub(r'\bGfx '+re.escape(dl)+r'\[\d+\]','Gfx '+dl+'[]',c);h=re.sub(r'\bGfx '+re.escape(dl)+r'\[\d+\]','Gfx '+dl+'[]',h)
c=c.replace('#include "ultra64.h"','#include "ultra64.h"\n#include "bean_model.inc.c"',1)
src='\n'.join(p.read_text(errors='replace') for p in (O/'src').rglob('*.c'))
refs=[]
for inc in re.findall(r'#include "([^"\n]+)"',c):
 if not inc.endswith('.inc.c'):continue
 for base in [O/'extracted/pal-1.0',A]:
  p=base/inc
  if p.exists():refs.append(p.read_text());break
refs='\n'.join(refs)+'\n'+src
for d in reversed(list(re.finditer(r'(?m)^(?:Vtx|u64|u16|u8) (\w+)\[[^\]]*\] = \{\n#include "([^"\n]+)"\n\};\n',c))):
 if not re.search(r'\b'+re.escape(d[1])+r'\b',refs):c=c[:d.start()]+c[d.end():]
cpath.write_text(c);hpath.write_text(h)
print('tiles',len(groups),'largest TMEM tile',max(area(g['rect']) for g in groups),'packed vertices',len(packed),'vertex bytes',len(packed)*16,'commands',len(commands))

# Keep Bean's original segment lengths. Animation rotations still use the
# native Impa hierarchy, limb count and matrix slots.
for bone in m['bones']:
 p=A/(bone['name']+'.inc.c');original(p)
 p.write_text('    { %d, %d, %d },\n    %d,\n    %d,\n    %s,\n'%tuple(bone['p']+[bone['child'],bone['sibling'],bone['dl']]))

# Baked retargeted dances preserve the native 40/55-frame animation headers.
for spec in json.loads((R/'bean_dances.json').read_text()).values():
 for name,text in spec['files'].items():
  p=A/name;original(p);p.write_text(text)
p=O/'src/overlays/actors/ovl_Demo_Im/z_demo_im.c';s=original(p)
a=s.index('void func_80985EF4(');b=s.index('\n}',a)+2
s=s[:a]+'''void func_80985EF4(DemoIm* this) {
    /* Keep Bean dancing during native song playback and player input. */
    DemoIm_UpdateSkelAnime(this);
}'''+s[b:];p.write_text(s)
print('Only the visual animation hold is removed; native song and quest logic remain.')

# Standing and sage poses use Bean's hip height; riders keep the original
# animated saddle position. Only the temporary drawing pose is adjusted.
ratio=m['root_translation_scale']
for func in ['DemoIm_DrawSolid','DemoIm_DrawTranslucent']:
 start=s.index('void '+func+'(DemoIm* this, PlayState* play) {');end=s.index('\n}',start)
 body=s[start:end]
 marker='    SkelAnime* skelAnime = &this->skelAnime;'
 assert body.count(marker)==1
 body=body.replace(marker,marker+'\n    Vec3s beanRoot = skelAnime->jointTable[0];')
 marker='    OPEN_DISPS('
 adjust='\n'.join('    skelAnime->jointTable[0].%s = (s16)(beanRoot.%s * %.10ff);'%(axis,axis,ratio) for axis in ['x','y','z'])+'\n\n'
 body=body.replace(marker,adjust+marker,1)
 body=body.replace('    CLOSE_DISPS(', '    skelAnime->jointTable[0] = beanRoot;\n\n    CLOSE_DISPS(',1)
 s=s[:start]+body+s[end:]
p.write_text(s)
print('Source skeleton proportions installed; drawing root scale',ratio,'horse root unchanged.')

from frame_bean import apply as frame_bean
frame_bean(O, original)

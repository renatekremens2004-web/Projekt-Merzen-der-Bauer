"""Frame the source-sized Bean in selected native cutscene camera shots.

Only camera point coordinates and FOV change. Timings, text, actor/player
cues, notes, event commands and scene transitions remain byte-for-byte text.
"""
from pathlib import Path
import re
import struct

POINT = re.compile(r'(CS_CAM_POINT\([^,]+,\s*[^,]+,\s*[^,]+,\s*)CS_FLOAT\([^,]+,\s*[^)]+\)(,\s*)(-?\d+)(,\s*)(-?\d+)(,\s*)(-?\d+)(,\s*[^)]+\))')


def cameras(source, callback):
    header = re.compile(r'^CS_CAM_(EYE|AT)_SPLINE(?:_REL_TO_PLAYER)?\((\d+),[^\n]+', re.M)
    matches = list(header.finditer(source))
    for i, match in reversed(list(enumerate(matches))):
        start = match.end()
        end = matches[i+1].start() if i+1 < len(matches) else len(source)
        kind, frame = match[1], int(match[2])
        def point(m):
            x,y,z=map(int,(m[3],m[5],m[7]))
            replacement=callback(kind,frame,(x,y,z))
            if replacement is None:
                return m[0]
            fov,xyz=replacement
            bits=struct.unpack('>I',struct.pack('>f',fov))[0]
            return m[1]+'CS_FLOAT(0x%08X, %.6ff)'%(bits,fov)+m[2]+str(xyz[0])+m[4]+str(xyz[1])+m[6]+str(xyz[2])+m[8]
        source=source[:start]+POINT.sub(point,source[start:end])+source[end:]
    return source


def apply(oot, original):
    root=Path(oot)/'extracted/pal-1.0/assets/scenes'
    files={
      'indoors/nakaniwa/gZeldasCourtyardLullabyCs.csdata.inc.c':
          lambda kind,frame,xyz: (48.0,(250,80,75) if kind=='EYE' else (336,76,0)) if frame in {0,140,230,250} else None,
      'overworld/spot00/gHyruleFieldZeldaFlashbackCs.csdata.inc.c':
          lambda kind,frame,xyz: (60.0,xyz) if frame==181 else None,
      'overworld/spot00/gHyruleFieldZeldaEscapeCs.csdata.inc.c':
          lambda kind,frame,xyz: (68.0,xyz) if frame in {770,830} else None,
    }
    for name,callback in files.items():
        path=root/name
        before=original(path)
        after=cameras(before,callback)
        assert before!=after,name
        # Removing camera points must leave the complete script unchanged.
        assert POINT.sub('',before)==POINT.sub('',after),name
        path.write_text(after)
    print('Bean camera framing installed: lullaby, horseback escape and flashback. Native cue timing unchanged.')

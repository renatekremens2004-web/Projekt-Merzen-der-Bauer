from pathlib import Path
import sys,shutil
root=Path(__file__).resolve().parent;target=Path(sys.argv[1]).resolve()
assert (target/'Makefile').is_file(),target
for p in (root/'production').rglob('*'):
 if p.is_file():
  q=target/p.relative_to(root/'production');q.parent.mkdir(parents=True,exist_ok=True)
  if q.is_symlink():q.unlink()
  shutil.copy2(p,q)
print('V84 production files and native stream source assets installed.')

from pathlib import Path
import os,sys,subprocess,json,hashlib,io,zipfile,re
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];romfd=int(rom.rsplit('/',1)[1]);base=O/'baseroms/pal-1.0/baserom.z64'
assert hashlib.md5(base.read_bytes()).hexdigest()=='e040de91a74b61e3201db0e2323f768a'
fd=os.memfd_create('title-v84-'+mode+'-bps');out='/proc/self/fd/'+str(fd);fds=(romfd,fd)
subprocess.run(['/workspace/toolchain/Flips/flips','--create','--bps',str(base),rom,out],pass_fds=fds,check=True)
js="const fs=require('fs'),c=require('crypto');global.BinFile=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/modules/BinFile');const p=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/RomPatcher');const actual=Buffer.from(p.applyPatch(new BinFile(process.argv[1]),p.parsePatchFile(new BinFile(process.argv[2])),{requireValidation:true})._u8array);const expected=fs.readFileSync(process.argv[3]);if(!actual.equals(expected))throw Error('Mismatch');console.log(c.createHash('sha256').update(actual).digest('hex'));"
sha=subprocess.check_output(['node','-e',js,str(base),out,rom],pass_fds=fds,text=True).strip();patch=Path(out).read_bytes();name='Mr_Burns_Mr_Bean_DE_PAL10_'+('DEBUG_'if mode=='debug'else'')+'Titel_Triangle_V84.bps';proof=dict(mode=mode,file=name,rom_sha256=sha,patch_sha256=hashlib.sha256(patch).hexdigest(),source_md5='e040de91a74b61e3201db0e2323f768a',byte_identical_after_independent_apply=True,patch_bytes=len(patch),rom_bytes=Path(rom).stat().st_size);(W/f'patch-{mode}-verification.json').write_text(json.dumps(proof,indent=2))
files={name:patch};prefix=''
if mode=='normal':
 guide='''V84 — Titelmusik, Schloss-Einsturz und Triangle Guy

Kumulativer BPS-Patch auf Basis des bisherigen Spielstands V79; enthält alle dort vorhandenen Änderungen. Auf eine SAUBERE Ocarina-of-Time-PAL-1.0-ROM anwenden, nicht auf eine bereits gepatchte Datei. Basis-MD5:e040de91a74b61e3201db0e2323f768a. Normale und DEBUG-Fassung haben denselben Spielinhalt; DEBUG enthält weiterhin die bisherigen Testfunktionen.

MUSIK
Die zuvor leisen Holzbläser-Gegenstimmen wurden angehoben. Orgel während Malons Gesang rund2dB lauter, weitere leisere Streicher-/Chor-/Gegenstimmen ab dem späteren Gesangsteil etwa1dB präsenter. Klavier, Malon und die bereits gut hörbaren Stimmen wurden nicht abgesenkt. Die Registerkorrekturen aus V82 bleiben erhalten. Das Stück blendet von5:00 bis5:15 langsam vollständig aus und beginnt im Titelbildschirm neu. Titelkameras und Demo-Szenen bleiben bestehen; Musik läuft über deren Wechsel hinweg weiter. Beim Wechsel ins Dateimenü wird sie normal beendet.

Beim tatsächlichen vollständigen Schloss-Einsturz beginnt dieselbe Fassung bei0:25.25 mit1.25s Einblendung. Sie läuft über den internen Szenenwechsel bis zum Ende der nachfolgenden Szene weiter. Erst wenn Link wieder steuerbar wird, wird sie ohne Ausblende gestoppt. Die bisherige Wallace-Fluchtmusik beim Folgen von Zelda im einstürzenden Turm bleibt erhalten.

Die Orchesterfassung wird aus der nativen OoT-Aufnahme als zwei Stereo-ADPCM-Stimmen aus der ROM gestreamt. Es werden keine21MB in den RAM geladen. Ursprünglicher Audioheap0x38000 und die jeweiligen originalen Stimmenbudgets bleiben bestehen. Das erweiterte Aufnahme-Orchester mit36Stimmen wird nicht global ins Spiel übernommen. Die erzeugte ROM ist64MiB groß; getestet weiterhin mit4MiB Arbeitsspeicher. Die zusätzliche ADPCM-Codierung hat im gemessenen linken Kanal39.67dB Signal-Rausch-Abstand.

TRIANGLE GUY
Während der bisherigen Einsturz-Aufnahmen unsichtbar einschließlich Schatten. Nach Zeldas Dialog und dem bisherigen Schluss der Kamerafahrt folgt ein eigener Kamera-Schnitt. Triangle Guy steht sichtbar auf dem Boden innerhalb der späteren Feuerarena, in der Nähe von Link und Zelda. Text: »Hey, gute Arbeit, Leute! Ich hätte es nicht besser hinbekommen. Darf ich vorstellen: Ich bin das Triforce des Mutes!« Erst danach werden Kamera und Steuerung freigegeben. Sein anschließendes freiwilliges Gespräch behält den bisherigen Ankunftsgag, Spielername und Merz-/Triforce-Text, ohne erneute Vorstellung. Seine Gesten und Schockpose bei der Verwandlung bleiben erhalten. Es gibt keinen neuen Actor, Object-Slot, Collider oder dauerhaften Spielstand-Flag. Falls der optionale Actor nicht vorhanden sein sollte, wird die native Szene trotzdem sauber freigegeben.

PRÜFUNG
Native Engine mit4MiB: Titelmusik über mehrere ursprüngliche Demo-Szenen, echte Sample-Schleife bei315.002s, Stereoausrichtung, Wechsel ins Dateimenü. Vollständiger tatsächlicher Schloss-Einsturz bis Kamera-Schnitt, neuer Dialog, abrupter Musikstopp bei Steuerungsfreigabe, freiwilliger Folgedialog und originale Verwandlung bis zum kampfbereiten Ganon. Normal und DEBUG werden separat geprüft; Details in den Logs. Objekt-/Actor-Budgetwächter ohne Ablehnung. Das ist kein behaupteter vollständiger Spieldurchlauf.

QUELLEN-UPDATE
Das Quellen-Archiv wird auf die zuvor veröffentlichten V79-Quellen angewendet. Enthalten sind die geänderten Produktionsdateien und die vier fertig codierten nativen Musik-Assets. Nach dem Entpacken ausführen:
python3 apply_sources_v84.py /PFAD/ZUR/oot-burns-pal
Danach mit der bisherigen Toolchain regulär PAL1.0 bauen. Zum Wechsel Normal/DEBUG den bisherigen tools/build_debug_version.py verwenden. Die AIFC-Dateien liegen als Quell-Assets vor und werden durch die ergänzte Makefile-Regel auch nach make clean wieder kopiert. Die Musikquelle sowie Misch-/Aufnahmeskripte liegen zur Dokumentation ebenfalls bei; die vom Nutzer bereitgestellte Complete-MIDI und Basis-ROM sind nicht enthalten.
'''
 files['V84_Titel_Triangle_Hinweise.txt']=guide.encode()
 # Production files only: debug builder's five unrelated toggle files are deliberately not overwritten.
 rels=[str(p.relative_to(W/'original'))for p in(W/'original').rglob('*')if p.is_file()]
 rels+=['assets/audio/soundfonts/Soundfont_40.xml','assets/audio/sequences/seq_112.seq','assets/audio/sequences/seq_113.seq']
 rels+=[str(p.relative_to(O))for p in(O/'assets/audio/samples/SampleBank_0').glob('MalonV84_*.aifc')]
 apply='''from pathlib import Path
import sys,shutil
root=Path(__file__).resolve().parent;target=Path(sys.argv[1]).resolve()
assert (target/'Makefile').is_file(),target
for p in (root/'production').rglob('*'):
 if p.is_file():
  q=target/p.relative_to(root/'production');q.parent.mkdir(parents=True,exist_ok=True)
  if q.is_symlink():q.unlink()
  shutil.copy2(p,q)
print('V84 production files and native stream source assets installed.')
'''
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  z.writestr('LIESMICH_V84.txt',guide);z.writestr('apply_sources_v84.py',apply)
  for rel in sorted(set(rels)):z.write(O/rel,'production/'+rel)
  for folder,prefix2 in [(W,'verification'),(Path('/tmp/malon-mix-v84'),'music-arrangement')]:
   for p in folder.iterdir():
    if p.is_file()and p.suffix in('.py','.json','.log','.seq','.xml')and p.stat().st_size<1500000:z.write(p,prefix2+'/'+p.name)
 files['Merzen_Titel_Triangle_V84_Quellen_Update.zip']=buf.getvalue()
 prefix='''## V84 — Titelmusik und neuer Triangle-Guy-Auftritt

Komm, süßer Tod mit präsenteren Begleitstimmen und langsamer Ausblende bis5:15. Im Titelbildschirm als Stereo-Stream mit nativem315-Sekunden-Loop. Beim vollständigen Schloss-Einsturz Einstieg bei0:25 und harter Stopp mit Rückgabe der Steuerung. Triangle Guy erscheint in einem neuen Kamera-Schnitt, stellt sich dort einmal vor und bleibt anschließend ansprechbar. Ursprünglicher Audioheap und4MiB-RAM-Betrieb bleiben erhalten.

- [Normaler kumulativer BPS-Patch](Mr_Burns_Mr_Bean_DE_PAL10_Titel_Triangle_V84.bps)
- [DEBUG-BPS-Patch](Mr_Burns_Mr_Bean_DE_PAL10_DEBUG_Titel_Triangle_V84.bps)
- [MP4: vollständiger Einsturz und Triangle Guys Auftritt](Schlosseinsturz_Triangle_Guy_V84.mp4)
- [MP4: Titelmusik und tatsächlicher Loop](Titelscreen_Musik_Loop_V84.mp4)
- [Hörprobe mit Ausblende bis5:15](Komm_Suesser_Tod_Malon_5m15_V84.mp3)
- [Hinweise](V84_Titel_Triangle_Hinweise.txt)
- [Quellen-Update auf V79](Merzen_Titel_Triangle_V84_Quellen_Update.zip)

BPS jeweils auf die saubere PAL1.0-Basis anwenden.

---

'''
import publish_ram_artifacts as pub
report=pub.publish(files,'V84 cumulative '+mode+' patch: native stereo title loop, collapse score, triangle reveal and verified progression',prefix);(W/f'public-{mode}.json').write_text(json.dumps(report,indent=2));print('PATCH_PUBLIC',mode,report,flush=True)

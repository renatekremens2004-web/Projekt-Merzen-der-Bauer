from pathlib import Path
import json,struct,subprocess,concurrent.futures,xml.etree.ElementTree as E,shutil,numpy as np
W=Path(__file__).resolve().parent;M=Path('/tmp/malon-mix-v84');O=Path('/workspace/oot-burns-pal');B=W/'original'

def backup(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(O/rel,p)
 return p
rateinfo=json.loads((M/'recording.json').read_text());rate=rateinfo['rate'];first=rateinfo['first_sample'];count=round(315*rate)
raw=np.memmap(M/'native-full.pcm',dtype='<i2',mode='r').reshape(-1,2);audio=np.array(raw[first:first+count],dtype=float);assert len(audio)==count
peak=float(np.max(abs(audio)));gain=min(1.6,27500/peak);audio*=gain
# A fifteen-second musical fade; fully silent by5:15. Preserve the relative mix.
n=round(15*rate);audio[-n:]*=np.cos(np.linspace(0,np.pi/2,n))[:,None]**2;audio[-1]=0
native=np.round(audio).clip(-32767,32767).astype('<i2');(W/'master-5m15.pcm').write_bytes(native.tobytes())
entry=round(25.25*rate);collapse=native[entry:].astype(float);fade=round(1.25*rate);collapse[:fade]*=np.sin(np.linspace(0,np.pi/2,fade))[:,None]**2;collapse[0]=0;collapse=np.round(collapse).astype('<i2')
# MIDI orchestration was rendered by OoT; only two streaming ADPCM voices are
# required in the shipping game. No private orchestra heap/spec is carried over.
samples=[]
def chunk(k,d):return k+struct.pack('<I',len(d))+d+(b'\0'if len(d)&1 else b'')
for ix,(tag,data)in enumerate([('TITLE_L',native[:,0]),('TITLE_R',native[:,1]),('COLLAPSE_L',collapse[:,0]),('COLLAPSE_R',collapse[:,1])]):
 filename='MalonV84_'+tag;wav=W/(filename+'.wav');aifc=W/(filename+'.aifc');N=len(data)
 fmt=struct.pack('<HHIIHH',1,1,32000,64000,2,16);inst=bytes([60,0,0,0,127,0,127,0]);smpl=struct.pack('<9I',0,0,31250,60,0,0,0,1,0)+struct.pack('<6I',0,0,0,N-1,0,0xFFFFFFFF)
 payload=b'WAVE'+chunk(b'fmt ',fmt)+chunk(b'fact',struct.pack('<I',N))+chunk(b'data',data.tobytes())+chunk(b'inst',inst)+chunk(b'smpl',smpl);wav.write_bytes(b'RIFF'+struct.pack('<I',len(payload))+payload)
 for ext,target in [('wav',wav),('aifc',aifc)]:
  p=O/('assets'if ext=='wav'else'build/pal-1.0/assets')/'audio/samples/SampleBank_0'/(filename+'.'+ext)
  assert not p.exists() and not p.is_symlink(),p
  p.symlink_to(target)
 samples.append(dict(index=1400+ix,name=f'SAMPLE_0_{1400+ix}',filename=filename,wav=str(wav),aifc=str(aifc),frames=N))
def encode(s):
 log=W/(s['filename']+'-encode.log')
 with log.open('w')as f:subprocess.run([str(O/'tools/audio/sampleconv/sampleconv'),'vadpcm',s['wav'],s['aifc']],stdout=f,stderr=subprocess.STDOUT,check=True)
 return Path(s['aifc']).stat().st_size
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:sizes=list(pool.map(encode,samples))
for s,size in zip(samples,sizes):s['encoded_bytes']=size
rel='extracted/pal-1.0/assets/audio/samplebanks/SampleBank_0.xml';p=backup(rel);root=E.parse(p).getroot()
for s in samples:root.append(E.Element('Sample',Name=s['name'],Path='$(BUILD_DIR)/assets/audio/samples/SampleBank_0/'+s['filename']+'.aifc'))
E.indent(root,space='    ');(O/rel).write_text(E.tostring(root,encoding='unicode')+'\n')
font=E.Element('Soundfont',Name='Soundfont_40',Index='40',Medium='MEDIUM_CART',CachePolicy='CACHE_LOAD_TEMPORARY',SampleBank='$(BUILD_DIR)/assets/audio/samplebanks/SampleBank_0.xml',Indirect='1');envs=E.SubElement(font,'Envelopes');env=E.SubElement(envs,'Envelope',Name='STREAM',Release='255')
E.SubElement(env,'Point',Delay='1',Arg='32700');E.SubElement(env,'Hang')
sps=E.SubElement(font,'Samples');insts=E.SubElement(font,'Instruments')
for ix,s in enumerate(samples):E.SubElement(sps,'Sample',Name=s['name']);E.SubElement(insts,'Instrument',ProgramNumber=str(ix),Name=s['filename'],Envelope='STREAM',Sample=s['name'])
E.indent(font,space='    ');text=E.tostring(font,encoding='unicode')+'\n';(W/'Soundfont_40.xml').write_text(text);(O/'assets/audio/soundfonts/Soundfont_40.xml').write_text(text)
# Hold the same two notes legato. Native sample loops, rather than approximate
# tempo delays, determine the exact315-second restart and stereo alignment.
for seq,programs in [(113,[0,1]),(112,[2,3])]:
 lines=['#include "aseq.h"','#include "Soundfont_40.h"',f'.startseq Sequence_{seq}','.sequence MAIN','mutebhv 0x20','mutescale 50','initchan 3','vol 127','tempo 120','ldchan 0, LEFT','ldchan 1, RIGHT','SEQ_WAIT:','delay 30000','jump SEQ_WAIT']
 for ci,(name,prg,pan)in enumerate(zip(['LEFT','RIGHT'],programs,[0,127])):
  lines +=[f'.channel {name}','noshort','vol 127',f'pan {pan}','notepri 0, 15','reverb 0',f'instr {prg}',f'ldlayer 0, L_{name}',f'WAIT_{name}:','delay 30000',f'jump WAIT_{name}',f'.layer L_{name}',f'instr {prg}','legato',f'NOTE_{name}:','notedv 39, 30000, 127',f'jump NOTE_{name}']
 lines +=[f'.endseq Sequence_{seq}'];text='\n'.join(lines)+'\n';(W/f'seq_{seq}.seq').write_text(text);(O/f'assets/audio/sequences/seq_{seq}.seq').write_text(text)
rel='include/tables/sequence_table.h';p=backup(rel);text=p.read_text();assert 'NA_BGM_MALON_TITLE_V84'not in text;text+='\nDEFINE_SEQUENCE(Sequence_112, NA_BGM_MALON_COLLAPSE_V84, MEDIUM_CART, CACHE_LOAD_TEMPORARY, 0)\nDEFINE_SEQUENCE(Sequence_113, NA_BGM_MALON_TITLE_V84, MEDIUM_CART, CACHE_LOAD_TEMPORARY, 0)\n';(O/rel).write_text(text)
report=dict(source_native_recording=rateinfo,rate=rate,seconds=315,fade_start=300,fade_end=315,collapse_entry=25.25,collapse_fade_in=1.25,gain=gain,source_peak=peak,peak=int(np.max(np.abs(native.astype(np.int32)))),samples=samples,shipping_audio_heap=0x38000,shipping_music_notes=2)
(W/'stream-assets.json').write_text(json.dumps(report,indent=2));print('STREAM_ASSETS_READY',sum(sizes),'bytes',flush=True)

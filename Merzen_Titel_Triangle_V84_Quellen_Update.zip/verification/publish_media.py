from pathlib import Path
import json
import publish_ram_artifacts as pub
W=Path(__file__).resolve().parent
names=['Komm_Suesser_Tod_Malon_5m15_V84.mp3','Schlosseinsturz_Triangle_Guy_V84.mp4','Titelscreen_Musik_Loop_V84.mp4']
r=pub.publish({n:(W/n).read_bytes()for n in names},'V84 media: final5:15 mix, original-title demo loop and full castle-collapse triangle introduction');(W/'public-media.json').write_text(json.dumps(r,indent=2));print(r)

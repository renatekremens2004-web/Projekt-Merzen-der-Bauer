from pathlib import Path
import subprocess,json,re,concurrent.futures
W=Path(__file__).resolve().parent

def mux(case,name):
 log=(W/f'normal-{case}.log').read_text();rate=31995;silent=W/f'normal-{case}-silent.mp4';m=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=nb_frames,duration','-of','json',str(silent)]))['streams'][0];frames=int(m['nb_frames']);duration=frames/50
 if case=='collapse':last=int(re.search(r'VIDEO_END sample=(\d+)',log)[1])
 else:last=int(re.search(r'TITLE_LOOP_QA_PASSED sample=(\d+)',log)[1])
 first=last-duration*rate;out=W/name
 subprocess.run(['ffmpeg','-y','-v','error','-f','s16le','-ar',str(rate),'-ac','2','-ss',str(first/rate),'-i',str(W/f'normal-{case}.pcm'),'-i',str(silent),'-map','1:v:0','-map','0:a:0','-t',str(duration),'-c:v','copy','-c:a','aac','-b:a','192k','-movflags','+faststart',str(out)],check=True)
 return dict(case=case,file=out.name,seconds=duration,audio_first_sample=first,audio_last_sample=last,first_sample_method='inferred from synchronized50fps capture end and frame count; precision10ms')
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:r=list(pool.map(lambda args:mux(*args),[('collapse','Schlosseinsturz_Triangle_Guy_V84.mp4'),('title-loop','title-full-mux.mp4')]))
# Concise proof of the beginning, fade and actual native sample restart.
subprocess.run(['ffmpeg','-y','-v','error','-i',str(W/'title-full-mux.mp4'),'-filter_complex','[0:v]trim=0:20,setpts=PTS-STARTPTS[v0];[0:a]atrim=0:20,asetpts=PTS-STARTPTS[a0];[0:v]trim=295:325,setpts=PTS-STARTPTS[v1];[0:a]atrim=295:325,asetpts=PTS-STARTPTS[a1];[v0][a0][v1][a1]concat=n=2:v=1:a=1[v][a]','-map','[v]','-map','[a]','-c:v','libx264','-threads','2','-preset','fast','-crf','20','-c:a','aac','-b:a','192k','-movflags','+faststart',str(W/'Titelscreen_Musik_Loop_V84.mp4')],check=True)
(W/'video-verification.json').write_text(json.dumps(r,indent=2));print('TWO_MUSIC_VIDEOS_READY')

from pathlib import Path
import sys,re
O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer');W=Path(__file__).resolve().parent;B=W/'original';sys.path.insert(0,str(R/'tools'))
from build_story import messages,Layout,rewrite

def original(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((O/rel).read_bytes())
 return p.read_text()
def put(rel,text):(O/rel).write_text(text)
# Fixed scene-local actor, within the eventual ring and near the two protagonists.
rel='extracted/pal-1.0/assets/scenes/dungeons/ganon_demo/ganon_demo_room_0_03000068_ActorEntryList.inc.c';s=original(rel);old='{ ACTOR_ELF_MSG2, { 440, 1086, -340 }, { 0, -16384, 0 }, 0x3F78 }';assert s.count(old)==1;s=s.replace(old,'{ ACTOR_ELF_MSG2, { 560, 1086, -330 }, { 0, 12000, 0 }, 0x3F78 }');put(rel,s)
# Hide the triangle through the original collapse shots; reveal at phase6, retain its later gestures.
rel='src/overlays/actors/ovl_Elf_Msg2/z_elf_msg2.c';s=original(rel);a=s.index('static void ElfMsg2_DrawTriangleGuy(');b=s.index('static void ElfMsg2_InitTriangleGuy',a);part=s[a:b];needle='s16 phase=((BossGanon2*)boss)->unk_39C;';assert needle in part;part=part.replace('    s32 i;','    s32 i;\n    if(actor->home.rot.z==0)return;');s=s[:a]+part+s[b:];s=s.replace('actor->draw = ElfMsg2_DrawTriangleGuy;', 'actor->draw = ElfMsg2_DrawTriangleGuy;\n    actor->shape.shadowAlpha=0;');put(rel,s)
# One new introductory message; preserve arrival gag, NAME and all following lines.
rel='extracted/pal-1.0/text/message_data.h';s=original(rel)
old='COLOR(DEFAULT) "Ich bin das Triforce des Mutes und\\nich bin da für dich,\\n" NAME "!"';new='COLOR(DEFAULT) "Ich bin da für dich,\\n" NAME "!"';assert s.count(old)==1;s=s.replace(old,new)
L=Layout(O);text='Hey, gute Arbeit, Leute! Ich hätte es nicht besser hinbekommen. Darf ich vorstellen: Ich bin das Triforce des Mutes!';lines=L.wrap(text,210);body,_=rewrite('COLOR(DEFAULT) ""',dict(pages=['\n'.join(lines[i:i+4])for i in range(0,len(lines),4)]),L,'723C');assert '723C'not in messages(s)
block=f'DEFINE_MESSAGE(0x723C, TEXTBOX_TYPE_BLACK, TEXTBOX_POS_BOTTOM,\nMSG(/* MISSING */),\nMSG("Good work! I am the Triforce of Courage!"),\nMSG({body}),\nMSG("Bravo !")\n)\n';at=re.search(r'DEFINE_MESSAGE\(0x(?:FFFC|FFFD)',s);at=at.start()if at else len(s);put(rel,s[:at]+block+s[at:])
# Continue the native first collapse cinematic with one additional, guarded shot.
rel='src/overlays/actors/ovl_Boss_Ganon2/z_boss_ganon2.c';s=original(rel);a=s.index('void func_808FD5C4(')
helper='''/* V84: scene-local reveal; no object allocation, new actor or persistent flag. */
static Vec3f sTriangleReturnEyeV84;
static Vec3f sTriangleReturnAtV84;
static Actor* Ganon2_TriangleV84(PlayState* play) {
    Actor* actor=play->actorCtx.actorLists[ACTORCAT_NPC].head;
    while(actor!=NULL) {
        if(actor->id==ACTOR_ELF_MSG2 && actor->params==0x3F78 && actor->update!=NULL)return actor;
        actor=actor->next;
    }
    return NULL;
}
'''
s=s[:a]+helper+s[a:];a=s.index('void func_808FD5F4(BossGanon2* this, PlayState* play) {');b=s.index('\nvoid func_808FF898(',a);part=s[a:b]
needle='                this->unk_39C = 1;';assert part.count(needle)==1;part=part.replace(needle,needle+'\n                SEQCMD_PLAY_SEQUENCE(SEQ_PLAYER_BGM_MAIN, 0, 0, NA_BGM_MALON_COLLAPSE_V84);')
needle='                SEQCMD_STOP_SEQUENCE(SEQ_PLAYER_BGM_MAIN, 0);';assert part.count(needle)==1;part=part.replace(needle,'                /* The new score continues until control is returned. */')
a4=part.index('        case 4:');b4=part.index('        case 5:',a4);case4=part[a4:b4]
aend=case4.index('                Camera* camera = Play_GetCamera');case4=case4[:aend]+'''                sTriangleReturnEyeV84=this->subCamEye;
                sTriangleReturnAtV84=this->subCamAt;
                this->unk_39C=6;
                this->unk_398=0;
            }
            break;
        case 6: {
            Actor* triangle=Ganon2_TriangleV84(play);
            this->unk_339=4;
            if(triangle!=NULL) {
                triangle->home.rot.z=1;
                triangle->shape.shadowAlpha=255;
                triangle->shape.rot.y=Actor_WorldYawTowardActor(triangle,&player->actor);
                this->subCamEye.x=triangle->world.pos.x+145.0f;
                this->subCamEye.y=triangle->world.pos.y+68.0f;
                this->subCamEye.z=triangle->world.pos.z+115.0f;
                this->subCamAt.x=triangle->world.pos.x;
                this->subCamAt.y=triangle->world.pos.y+45.0f;
                this->subCamAt.z=triangle->world.pos.z;
                if(this->unk_398==14)Message_StartTextbox(play,0x723C,triangle);
            }
            /* A missing optional flavor actor can never trap the native boss intro. */
            if((triangle==NULL || this->unk_398>25) && Message_GetState(&play->msgCtx)==TEXT_STATE_NONE) {
                Camera* camera=Play_GetCamera(play,CAM_ID_MAIN);
                this->subCamEye=sTriangleReturnEyeV84;
                this->subCamAt=sTriangleReturnAtV84;
                Play_SetCameraAtEye(play,this->subCamId,&this->subCamAt,&this->subCamEye);
                camera->eye=this->subCamEye;
                camera->eyeNext=this->subCamEye;
                camera->at=this->subCamAt;
                Play_ReturnToMainCam(play,this->subCamId,0);
                this->subCamId=SUB_CAM_ID_DONE;
                SEQCMD_STOP_SEQUENCE(SEQ_PLAYER_BGM_MAIN,0);
                Cutscene_StopManual(play,&play->csCtx);
                Player_SetCsActionWithHaltedActors(play,&this->actor,PLAYER_CSACTION_7);
                this->unk_39C=5;
                this->unk_398=0;
            }
            break;
        }
'''
part=part[:a4]+case4+part[b4:];s=s[:a]+part+s[b:];put(rel,s)
# Start at the actual tower-collapse scene, then retain the same sample position
# across the native respawn into the actor-controlled aftermath.
rel='src/code/z_scene.c';s=original(rel);needle='    play->sceneSequences.seqId = cmd->soundSettings.seqId;';assert s.count(needle)==1;s=s.replace(needle,needle+'\n    if(play->sceneId==SCENE_GANON_BOSS && gSaveContext.gameMode==GAMEMODE_NORMAL && LINK_IS_ADULT)\n        play->sceneSequences.seqId=NA_BGM_MALON_COLLAPSE_V84;');put(rel,s)
rel='include/tables/entrance_table.h';s=original(rel);s,n=re.subn(r'(DEFINE_ENTRANCE\(ENTR_GANON_BOSS_0(?:_[1-4])?, SCENE_GANON_BOSS, 0, )false,',r'\1true,',s);assert n==5,n;put(rel,s)
rel='src/audio/game/general.c';s=original(rel);needle='void Audio_PlaySceneSequence(u16 seqId) {';assert s.count(needle)==1;start=s.index(needle);at=s.index('    if (Audio_GetActiveSeqId(SEQ_PLAYER_BGM_MAIN)',start);s=s[:at]+'    if(seqId==NA_BGM_MALON_COLLAPSE_V84 && Audio_GetActiveSeqId(SEQ_PLAYER_BGM_MAIN)==seqId)return;\n\n'+s[at:];put(rel,s)
# Keep the native title cameras and demo destinations, but do not interrupt/restart
# the title score when the title's existing attract-mode scenes change.
rel='src/audio/game/sequence.c';s=original(rel);needle='#include "audio.h"';s=s.replace(needle,needle+'\n#include "save.h"\n#include "sequence.h"')
needle='    if (!gStartSeqDisabled || (seqPlayerIndex == SEQ_PLAYER_SFX)) {';assert s.count(needle)==1;s=s.replace(needle,'''    if(gSaveContext.gameMode==GAMEMODE_TITLE_SCREEN && seqPlayerIndex==SEQ_PLAYER_BGM_MAIN) {
        seqId=NA_BGM_TITLE;
        if(gActiveSeqs[seqPlayerIndex].seqId==NA_BGM_TITLE && gAudioCtx.seqPlayers[seqPlayerIndex].enabled)return;
    }
'''+needle)
needle='void Audio_StopSequence(u8 seqPlayerIndex, u16 fadeOutDuration) {';s=s.replace(needle,needle+'''\n    if(gSaveContext.gameMode==GAMEMODE_TITLE_SCREEN && seqPlayerIndex==SEQ_PLAYER_BGM_MAIN &&
       gActiveSeqs[seqPlayerIndex].seqId==NA_BGM_TITLE)return;
''')
needle='    op = cmd >> 28;';assert s.count(needle)==1;s=s.replace(needle,needle+'''
    /* Old attract-demo fade commands must not fade the continuous new title track. */
    if(gSaveContext.gameMode==GAMEMODE_TITLE_SCREEN) {
        if(op==SEQCMD_OP_SET_SEQPLAYER_VOLUME && ((cmd>>24)&15)==SEQ_PLAYER_BGM_MAIN &&
           gActiveSeqs[SEQ_PLAYER_BGM_MAIN].seqId==NA_BGM_TITLE)return;
        if(op==SEQCMD_OP_RESET_AUDIO_HEAP) {
            cmd=(cmd&~0xFFu)|10u;
            if(gAudioSpecId==10)return;
        }
    }
''');s=s.replace('NA_BGM_TITLE','NA_BGM_MALON_TITLE_V84')
s=s.replace('    if (!gStartSeqDisabled || (seqPlayerIndex == SEQ_PLAYER_SFX)) {','    if(seqPlayerIndex==SEQ_PLAYER_BGM_MAIN && seqId==NA_BGM_MALON_COLLAPSE_V84 && gActiveSeqs[seqPlayerIndex].seqId==seqId && gAudioCtx.seqPlayers[seqPlayerIndex].enabled)return;\n    if (!gStartSeqDisabled || (seqPlayerIndex == SEQ_PLAYER_SFX)) {')
put(rel,s)
print('V84 collapse shot, dialogue, reveal and title audio continuity installed.')

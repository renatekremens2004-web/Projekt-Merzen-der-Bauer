from pathlib import Path
import sys,json,re
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');D=Path('/workspace/bean-download-delivery')
sys.path.insert(0,str(R/'tools'));import build_story as b
m=b.messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
def plain(raw):return re.sub(r'\s+',' ',b.plain(raw).replace('{name}','{Spielername}')).strip()
def export(title,ids):
 out=['# '+title,'','Aus dem tatsächlich gebauten deutschen Textbestand. Absätze entsprechen Textseiten; feste Szenenzeiten bleiben erhalten. {Spielername} wird im Spiel ersetzt.','']
 for i in ids:
  raw=m[i]['parts'][2][2];out+=['## '+i,'']+['> '+plain(p)+'\n' for p in b.split_pages(raw)[0]]
  links=[x for x in b.controls(raw) if x.startswith('TEXTID')]
  if links:out+=['Textkette: '+', '.join(links),'']
 return '\n'.join(out)+'\n'
sage=json.loads((R/'story/weise_thaddaeus_waluigi_de.json').read_text())['messages'];ctx=json.loads((R/'story/weise_masken_kontext_de.json').read_text())['messages']
ids=list(dict.fromkeys(['4053','4054','405A','405B','0136','0138','013B','4055','4056','405C','405D']+list(sage)+list(ctx)))
s=export('Thaddäus und Waluigi: eingebaute Dialoge',ids)
(D/'Thaddaeus_Waluigi_Dialoge_Aktuell.md').write_text(s);(R/'planning/THADDAEUS_WALUIGI_DIALOGE_AKTUELL.md').write_text(s)
cat=json.loads((R/'planning/MASKEN_ZUORDNUNG.json').read_text());mask=json.loads((R/'story/masken_reaktionen_de.json').read_text())['messages']
s=export('Maskenreaktionen: eingebaute Texte',mask)
s+='\n## Zuordnung der Reaktionsgruppen\n\nSpalten: keine Maske, Fuchs, Schädel, Grusel, Hase, Gorone, Zora, Gerudo, Wahrheit. 0000 bedeutet ursprünglichen Standardtext beziehungsweise besondere Questbehandlung. Nicht jede Gruppe entspricht genau einem NPC.\n\n'
s+='| Gruppe | Nachrichten je Maske |\n|---|---|\n'
for k,v in cat['german_rows'].items():s+='| '+k+' | '+', '.join(f'{x:04X}' for x in v)+' |\n'
s+='\n58 Gerudo-Reaktionsgruppen mit eigenen unterstützenden Antworten; Thaddäus hat zusätzlich eine eigene Antwort. Der Wal-Spruch setzt den Zora-Saphir voraus. Der Schulden-Spruch gehört zum einzelnen Kokiri CHILD_3 mit der Maske des Wissens.\n'
(D/'Masken_Reaktionen_Aktuell.md').write_text(s);(R/'planning/MASKEN_REAKTIONEN_AKTUELL.md').write_text(s)
p=R/'README.md';s=p.read_text();s=s.replace('python3 tools/build_sage_names.py /pfad/zum/oot','python3 tools/build_mask_reactions.py /pfad/zum/oot\npython3 tools/build_sage_names.py /pfad/zum/oot');s+='\nDie neuen Weisen- und Maskentexte liegen in story/weise_thaddaeus_waluigi_de.json, story/weise_masken_kontext_de.json und story/masken_reaktionen_de.json. build_story.py liest sie automatisch ein. Nach einem erneuten Textbau build_habeck.py und abschließend build_sage_names.py anwenden. Der Namensbau überspringt ausdrücklich verfaßte Storytexte, damit die weiterhin junge Prinzessin Ruto korrekt erwähnt bleibt. build_mask_reactions.py ergänzt die sprachabhängige Tabelle und die begrenzten Kokiri-/Tauchspiel-Ausnahmen.\n';p.write_text(s)
print('Exported',len(ids),'sages/context and',len(mask),'mask messages')

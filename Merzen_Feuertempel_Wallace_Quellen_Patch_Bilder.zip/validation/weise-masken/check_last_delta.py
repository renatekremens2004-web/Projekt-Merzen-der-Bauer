from pathlib import Path
import sys,re,struct,csv,json,hashlib
R=Path('/workspace/Projekt-Merzen-der-Bauer');W=Path('/workspace/dialoge-masken');O=Path('/workspace/oot-burns-pal');sys.path.insert(0,str(R/'tools'));from verify_story import segment
names=[r['Name'] for r in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())]
def read(path,mp):
 syms={}
 for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp.read_text()):syms.setdefault(n,int(a,16))
 rom=path.read_bytes();_,_,code=segment(rom,names.index('code'));_,_,data=segment(rom,names.index('ger_message_data_static'));base=syms['_codeSegmentStart'];off=syms['sNesMessageEntryTable']-base;ids=[]
 while True:
  i=struct.unpack_from('>H',code,off)[0];off+=8
  if i==65535:break
  if i!=65532:ids.append(i)
 tab=syms['sGerMessageEntryTable']-base;starts=[struct.unpack_from('>I',code,tab+4*n)[0]&0xffffff for n in range(len(ids))]+[len(data)]
 return rom,{f'{i:04X}':data[starts[n]:starts[n+1]].rstrip(b'\0') for n,i in enumerate(ids)}
a,old=read(W/'before_witch_corrections.z64',W/'before_witch_corrections.map');b,new=read(O/'build/pal-1.0/oot-pal-1.0-compressed.z64',O/'build/pal-1.0/oot-pal-1.0.map');changed=[i for i in old if old[i]!=new[i]];assert set(changed)=={'6031','6032','6033','6034'},changed
r=dict(before_sha256=hashlib.sha256(a).hexdigest(),final_sha256=hashlib.sha256(b).hexdigest(),last_changed_german_messages=changed)
(W/'last-wording-delta.json').write_text(json.dumps(r,indent=2)+'\n');print(r)

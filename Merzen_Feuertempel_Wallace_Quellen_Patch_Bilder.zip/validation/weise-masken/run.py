from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys,hashlib
W=Path('/workspace/dialoge-masken');s=json.loads((W/'symbols.json').read_text())
def run(topic):
 case='dialoge-masken-'+topic+os.environ.get('WALD_RUN','-proof')+'-direct-clip-on';limit=int(os.environ.get('FRAME_LIMIT',3400 if topic=='minuet' else 1800));rom=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64')
 (W/(case+'.json')).write_text(json.dumps({'rom_sha256':hashlib.sha256(rom.read_bytes()).hexdigest(),'limit':limit,'fixture':topic,'prepared_progress_and_player_only':True},indent=2)+'\n')
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/'runner'),str(rom),case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=900)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:]))

from pathlib import Path
import re,json,struct
W=Path('/workspace/dialoge-masken');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text()
syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
s=Path('/workspace/wald-dialoge-feuer/runner.c').read_text().replace('strstr(scenario,"new-sages")','strstr(scenario,"dialoge-masken")').replace('0x800f7308',hex(syms['gObjectTable'])).replace('overlays+0x8e10+3*0x30',hex(syms['gGameStateOverlayTable'])+'+3*0x30')
s=s.replace('   if(strstr(scenario,"lab-"))npc=actor(0x14a);','   if(strstr(scenario,"thadmask"))npc=actor(0x124);\n   if(strstr(scenario,"lab-"))npc=actor(0x14a);')
marker='  if(f==300 && strstr(scenario,"navi"))'
helper='''  if(strstr(scenario,"spirit-child-hates") && id==0x6020 && mode==0x35 && age<12)value=(age>=2 && age<6)?0xc0000000:0;
  if(strstr(scenario,"spirit-child-decline")){
   static int declined=0;if(id==0x6027)declined=1;
   if(!declined && id==0x6024 && mode==0x35 && age<12)value=(age>=2 && age<6)?0xc0000000:0;
  }
  if(strstr(scenario,"-mask-") && f>=120 && f<128 && mode==0)value=0x200;
  if(strstr(scenario,"dialoge-masken") && f%100==0)printf("MASK f=%u worn=%u item=%u choice=%u lang=%u\\n",f,DebugMemRead8(player+0x14f),DebugMemRead8(savebase+0x69),DebugMemRead8(m+0xe3e5),DebugMemRead8(savebase+0x1409));
''';assert marker in s;s=s.replace(marker,helper+marker);(W/'runner.c').write_text(s)
for topic in ['water','hall-water','hall-spirit','spirit-child','kidnap','knuckle-reveal','trial-water','trial-spirit']:(W/(topic+'.save')).write_bytes((Path('/workspace/water-spirit-sages')/(topic+'.save')).read_bytes())
for topic in ['spirit-child-hates','spirit-child-decline']:(W/(topic+'.save')).write_bytes((W/'spirit-child.save').read_bytes())
base=Path('/workspace/eule-tagesgags/eels-before.save').read_bytes()
maskitems={'gerudo':0x2a,'goron':0x28,'zora':0x29,'truth':0x2b,'bunny':0x27,'none':None}
def equip(b,mask):
 if mask!='none':
  item=maskitems[mask];b[0x69]=item;b[0x6c]=23;b[0x8b]=item
for topic,mask,src in [('market-6-mask-gerudo','gerudo',base),('market-6-mask-zora','zora',base),('market-3-mask-goron','goron',base),('market-2-mask-zora-post','zora',base),('market-2-mask-zora-before','zora',base),('market-6-mask-gerudo-english','gerudo',base),('market-6-unmasked','none',base),('lab-child-mask-truth','truth',Path('/workspace/wald-dialoge-feuer/lab-child.save').read_bytes()),('kokiri-type3-mask-truth','truth',Path('/workspace/wald-dialoge-feuer/kokiri-type3.save').read_bytes())]:
 b=bytearray(src);struct.pack_into('>I',b,4,1);equip(b,mask);b[0x1409]=0 if topic.endswith('english') else 1
 if 'zora-post' in topic:struct.pack_into('>I',b,0xa4,struct.unpack_from('>I',b,0xa4)[0]|1<<20)
 if 'zora-before' in topic:struct.pack_into('>I',b,0xa4,struct.unpack_from('>I',b,0xa4)[0]&~(1<<20))
 if topic.startswith('market-'):
  import math
  typ=int(topic.split('-')[1]);x,y,z,yaw={6:(-160,0,-133,0x25b0),3:(289,0,488,0x4000),2:(393,0,264,-0x549f)}[typ]
  face=((yaw+0x8000+32768)%65536)-32768
  struct.pack_into('>fffh',b,0x1368,x+45*math.sin(yaw*math.pi/32768),y,z+45*math.cos(yaw*math.pi/32768),face)
 if topic.startswith('market-') and typ==3:struct.pack_into('>fffh',b,0x1368,-22.,2.,420.,-32768)
 (W/(topic+'.save')).write_bytes(b)
b=bytearray(base);struct.pack_into('>III',b,0,0x108,1,0);struct.pack_into('>fffhHhB',b,0x1368,-186.,857.,-1046.,0x22d8,0xdff,0x108,0);equip(b,'gerudo');(W/'thadmask-mask-gerudo.save').write_bytes(b)
# run.py/select_shot.py are versioned alongside this generator; do not overwrite them.
for topic in ['spirit-child-quest','spirit-child-decline']:
 b=bytearray((Path('/workspace/water-spirit-sages')/'spirit-child-quest.save').read_bytes())
 off=0xef8+(0x16c>>4)*2
 struct.pack_into('>H',b,off,struct.unpack_from('>H',b,off)[0]|(1<<(0x16c&15)))
 (W/(topic+'.save')).write_bytes(b)
print(syms)

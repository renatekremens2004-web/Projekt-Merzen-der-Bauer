from pathlib import Path
import json,re,struct
W=Path('/workspace/water-spirit-sages');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gObjectTable']};(W/'symbols.json').write_text(json.dumps(syms));old=json.loads(Path('/workspace/forest-temple/symbols.json').read_text());s=Path('/workspace/forest-temple/runner.c').read_text().replace(hex(old['gObjectTable']),hex(syms['gObjectTable']));s=s.replace('strstr(scenario,"forest-temple")','strstr(scenario,"new-sages")')
a=s.index('  if(strstr(scenario,"new-sages") && f%25==0){');b=s.index('  if(f==300 && strstr(scenario,"navi"))',a)
s=s[:a]+'''  if(strstr(scenario,"new-sages") && f%25==0){
   for(int j=0;j<2;j++){uint32_t n=actor(j?0xc3:0xd2);printf("SAGE f=%u role=%s actor=%08x type=%x limbs=%u anim=%08x frame=%.1f action=%u draw=%u alpha=%u pos=(%.1f %.1f %.1f) yaw=%x\\n",f,j?"waluigi":"squid",n,n?DebugMemRead16(n+0x1c):0,n?DebugMemRead8(n+0x13c):0,n?r32(n+0x144):0,n?rf(n+0x154):0,n?r32(n+(j?0x238:0x2d4)):0,n?r32(n+(j?0x23c:0x2d8)):0,n?r32(n+(j?0x244:0x2e0)):0,n?rf(n+0x24):0,n?rf(n+0x28):0,n?rf(n+0x2c):0,n?DebugMemRead16(n+0xb6):0);}
  }
'''+s[b:]
s=s.replace('  if(f==300 && strstr(scenario,\"navi\"))', '  if(strstr(scenario,\"-water-\") && mode==0)value=(f>300 && f<550)?0x40000000:0;\n  if(f==300 && strstr(scenario,\"navi\"))')
s=s.replace('strstr(scenario,"credits") && f<=160','(strstr(scenario,"credits") || strstr(scenario,"reveal") || strstr(scenario,"sealing")) && f<=160')
s=s.replace('  if(f==300 && strstr(scenario,"navi"))', '  if(f>=300 && f<=330 && strstr(scenario,"trial-")){uint32_t barrier=actor_type(0x1a7,strstr(scenario,"trial-water")?1:5);if(barrier){DebugMemWrite8(barrier+0x188+0x11,DebugMemRead8(barrier+0x188+0x11)|2);printf("PREPARED_COLLISION_HIT f=%u barrier=%08x\\n",f,barrier);}}\n  if(f==300 && strstr(scenario,"navi"))')
s=s.replace('  if(f==300 && strstr(scenario,"navi"))', '  if(strstr(scenario,"spirit-child") && id==0x601d && mode==0x35 && age<12)value=((age>=2 && age<6)||(age>=8 && age<12))?0xc0000000:0;\n  if(f==300 && strstr(scenario,"navi"))')
s=s.replace('strstr(scenario,"new-sages") && f%25==0','strstr(scenario,"new-sages") && f%(strstr(scenario,"sealing-fade")?5:25)==0')
(W/'runner.c').write_text(s)
base=Path('/workspace/forest-dialogue/house.save').read_bytes()
for name,chamber in [('hall-water',2),('hall-spirit',3)]:
 b=bytearray(Path('/workspace/forest-sage/hall2.save').read_bytes());b[0x1415]=chamber;(W/(name+'.save')).write_bytes(b)
for name,ent,room,pos,yaw,age in [('water',0x10,17,(700.,0.,180.),16384,0),('spirit-child',0x82,0,(-440.,-50.,-1.),-16384,1)]:
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,0);struct.pack_into('>I',b,0x1360,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,room);struct.pack_into('>HH',b,0x2e,160,160);b[0x1409]=1;struct.pack_into('>H',b,0xf30,struct.unpack_from('>H',b,0xf30)[0]|0x8000)
 if name=='water':
  struct.pack_into('>H',b,0x70,(struct.unpack_from('>H',b,0x70)[0]&0xff)|0x2300);struct.pack_into('>H',b,0x9c,struct.unpack_from('>H',b,0x9c)[0]|0x2400)
  struct.pack_into('>I',b,0xd4+5*0x1c+4,0)
 else:
  struct.pack_into('>H',b,0xee6,struct.unpack_from('>H',b,0xee6)[0]&~0x30);b[0x68]=0x3b;struct.pack_into('>H',b,0x70,0x1111)
 (W/(name+'.save')).write_bytes(b)
for name,src in [('credits','credits'),('sealing','sealing'),('latehall','latehall'),('child-ruto','child')]:
 if (Path('/workspace/forest-sage')/(src+'.save')).exists():(W/(name+'.save')).write_bytes((Path('/workspace/forest-sage')/(src+'.save')).read_bytes())
(W/'sahur.save').write_bytes(Path('/workspace/forest-temple/sprout.save').read_bytes())
print(syms)

for name,ent,cs,age in [('knuckle-reveal',0x8d,0xfff1,0),('kidnap',0x123,0xfff1,1)]:
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,cs);struct.pack_into('>I',b,0x1364,0);struct.pack_into('>I',b,0x1360,0);struct.pack_into('>HH',b,0x2e,160,160);b[0x1409]=1;(W/(name+'.save')).write_bytes(b)

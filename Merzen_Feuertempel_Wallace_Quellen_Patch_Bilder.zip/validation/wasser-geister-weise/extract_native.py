from pathlib import Path
import sys,json,re,struct,csv
R=Path('/workspace/Projekt-Merzen-der-Bauer');W=Path('/workspace/water-spirit-sages');O=Path('/workspace/oot-burns-pal');sys.path.insert(0,str(R/'tools'));from verify_story import segment
mp=(W/'baseline.map').read_text();sym={n:int(a,16) for a,n in re.findall(r'0x([0-9a-f]+)\s+(\w+)\b',mp)};names=[x['Name'] for x in csv.DictReader((O/'baseroms/pal-1.0/segments.csv').open())];rom=(W/'baseline.z64').read_bytes()
for name,skel in [('object_ru2','gAdultRutoSkel'),('object_nb','gNabooruSkel')]:
 data=segment(rom,names.index(name))[2];ptr=sym[skel]&0xffffff;array,count=struct.unpack_from('>IB',data,ptr);arr=struct.unpack_from('>'+str(count)+'I',data,array&0xffffff);bones=[]
 for a in arr:
  p=list(struct.unpack_from('>3h',data,a&0xffffff));child,sibling,dl=struct.unpack_from('>BBI',data,(a&0xffffff)+6);label=next((n for n,v in sym.items() if v==a and n.endswith('Limb')),hex(a));bones.append({'position':p,'child':child,'sibling':sibling,'dl':dl,'name':label,'parent':-1})
 def parents(i,p):
  bones[i]['parent']=p
  if bones[i]['child']!=255:parents(bones[i]['child'],i)
  if bones[i]['sibling']!=255:parents(bones[i]['sibling'],p)
 parents(0,-1)
 anims={}
 for label,addr in sym.items():
  if not label.endswith('Anim') or not 0x06000000<=addr<0x06000000+len(data):continue
  # Select only symbols declared by this object; VMA is shared by other objects.
  if not re.search(r'extern AnimationHeader '+label+r';',(O/f'extracted/pal-1.0/assets/objects/{name}/{name}.h').read_text()):continue
  fc,fd,ji,static=struct.unpack_from('>h2xIIH',data,addr&0xffffff);indices=struct.unpack_from('>'+str(3*(count+1))+'H',data,ji&0xffffff);frames=[]
  for f in range(fc):
   v=[struct.unpack_from('>h',data,(fd&0xffffff)+2*(i if i<static else i+f))[0] for i in indices];frames.append({'root':v[:3],'rotation':[v[i:i+3] for i in range(3,len(v),3)]})
  anims[label]=frames
 # Capture actual limb geometry for grounding and diagnostics, including matrix-switched seams.
 palette=[i for i,b in enumerate(bones) if b['dl']];vertices=set()
 def dl(addr,state,cache,depth=0):
  assert depth<12
  addr&=0xffffff
  for off in range(addr,len(data),8):
   a,b=struct.unpack_from('>II',data,off);op=a>>24
   if op==0xdf:return
   if op==0xde:
    if b>>24==6:dl(b,state,cache,depth+1)
   elif op==0xda:
    if b>>24==13:state[0]=palette[(b&0xffffff)//64]
   elif op==1:
    num=(a>>12)&0xff;end=(a>>1)&0x7f;start=end-num
    if b>>24!=6:continue
    for j in range(num):cache[start+j]=(state[0],*struct.unpack_from('>3h',data,(b&0xffffff)+16*j))
   elif op in [5,6]:
    words=[a&0xffffff]+([b&0xffffff] if op==6 else [])
    for word in words:
     for shift in [16,8,0]:
      v=cache[(word>>shift&0xff)//2];vertices.add(v)
 for i,b in enumerate(bones):
  if b['dl']:dl(b['dl'],[i],{})
 out={'name':name,'bones':bones,'animations':anims,'vertices':[list(v) for v in sorted(vertices)]};(W/(name+'_native.json')).write_text(json.dumps(out,separators=(',',':'))+'\n');print(name,'bones',count,'geometry',len(vertices),'animations',{k:len(v) for k,v in anims.items()})
 for i,b in enumerate(bones):print(i,b['name'],b['parent'],b['position'])

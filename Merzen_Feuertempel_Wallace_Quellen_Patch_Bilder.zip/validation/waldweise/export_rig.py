"""Reconstruct own rigid bones from the supplied SoH rig and original Collada mesh.
No Saria joint distances or scales are used. Geometry is from the supplied DAE.
"""
from pathlib import Path
import bpy,json,math,hashlib
import numpy as np
from mathutils import Matrix,Vector
R=Path('/workspace/Projekt-Merzen-der-Bauer');W=Path('/workspace/forest-sage');raw=json.loads((W/'parsed.json').read_text());fit=json.loads((W/'fits.json').read_text());ids=[1,3,4,5,6,7,8,20,10,13,14,15,16,17,18];idx={b:i for i,b in enumerate(ids)};parents={1:None,3:1,4:3,5:4,6:1,7:6,8:7,20:1,10:20,13:20,14:13,15:14,16:20,17:16,18:17};rest=[]
for b in ids:
 f=fit[str(b)];r=np.array(f['rotation'])/f['scale'];u,_,v=np.linalg.svd(r);r=u@v;t=np.array(f['translation']);m=np.eye(4);m[:3,:3]=r;m[:3,3]=t;rest.append(Matrix(m.tolist()))
# Recover the original rigid assignments by position. All original Collada
# triangles/UVs/normals remain; thus no resized body segments are introduced.
cloud=[];labels=[]
for t in raw['triangles']:
 if t['bone'] not in ids:continue
 f=fit[str(t['bone'])]
 for c in t['corners']:cloud.append(np.array(f['rotation'])@np.array(c['position'])+f['translation']);labels.append(t['bone'])
cloud=np.array(cloud);height=max(c['position'][1] for t in raw['dae_triangles'] for c in t['corners']);scale=6200/height
out={'model':'Bombchu Bowling Lady, forest sage only','source_sha256':hashlib.sha256((R/'models/bowling_sage/treasure_girl.dae').read_bytes()).hexdigest(),'source_triangles':986,'height_model_units':6200,'actor_uniform_scale':.01,'uniform_scale':scale,'bones':[],'materials':[{'name':s,'texture':s+'.png'} for s in ['treasure_girl_e_2800','treasure_girl_0_2000','treasure_girl_0_0']],'vertices':[],'triangles':[],'animations':{},'binding_max_source_distance':0}
def ints(v):return [round(float(x)) for x in v]
def angles(m):return [round(a*32768/math.pi)%65536 for a in m.to_euler('XYZ')]
for b in ids:
 i=idx[b];p=idx[parents[b]] if parents[b] is not None else -1;m=rest[p].inverted()@rest[i] if p>=0 else rest[i]
 out['bones'].append({'name':'source_'+str(b),'parent':p,'position':ints(m.translation*scale),'rest_rotation':angles(m.to_3x3()),'rest_matrix':[list(row) for row in rest[i]]})
vertices={};distances=[]
for t in raw['dae_triangles']:
 cs=[]
 for c in t['corners']:
  pw=np.array(c['position']);nearest=int(np.argmin(np.linalg.norm(cloud-pw,axis=1)));b=labels[nearest];i=idx[b];d=float(np.linalg.norm(cloud[nearest]-pw));distances.append(d)
  # The continuous neck belongs to the torso; only the head rotates above it.
  if 5400<pw[1]<5570 and abs(pw[0])<220:b=20;i=idx[b]
  k=tuple(c['position'])
  if k not in vertices:
   vertices[k]=len(out['vertices']);local=rest[i].inverted()@Vector(c['position']);out['vertices'].append({'bone':i,'position':ints(local*scale),'source_position':c['position']})
  vi=vertices[k];i=out['vertices'][vi]['bone'];n=(rest[i].to_3x3().inverted()@Vector(c['normal'])).normalized();cs.append({'vertex':vi,'normal':ints(n*127),'uv':c['uv']})
 out['triangles'].append({'material':next(j for j,m in enumerate(out['materials']) if m['name']==t['material']),'corners':cs})
out['binding_max_source_distance']=max(distances);out['binding_distance_percentiles']=np.percentile(distances,[50,90,99,100]).tolist()
# Full-size proportions with rotations only. Match native cue animation lengths.
local_rest=[(rest[b['parent']].inverted()@rest[i]).to_3x3() if b['parent']>=0 else rest[i].to_3x3() for i,b in enumerate(out['bones'])]
for label,count in [('idle',24),('raise',30),('hold',30)]:
 frames=[]
 for f in range(count):
  t=0 if label=='idle' else (.5-.5*math.cos(math.pi*f/(count-1)) if label=='raise' else 1)
  r=[m.copy() for m in local_rest]
  # Source A-pose arms slope downward. Idle lowers them; blessing raises them.
  for b,sign in [(13,1),(16,-1)]:
   i=idx[b];p=out['bones'][i]['parent'];rot=Matrix.Rotation(math.radians(sign*(-28+95*t)),3,'Z');r[i]=rest[p].to_3x3().inverted()@rot@rest[i].to_3x3()
  r[idx[20]]=r[idx[20]]@Matrix.Rotation(math.radians(.25*math.sin(2*math.pi*f/count)),3,'Z')
  r[idx[10]]=r[idx[10]]@Matrix.Rotation(math.radians(.5*math.sin(2*math.pi*f/count)),3,'Z')
  frames.append({'root':ints(rest[0].translation*scale),'rotation':[angles(m) for m in r]})
 out['animations'][label]=frames
(R/'tools/bowling_sage_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n');print('BOWLING SAGE',len(out['vertices']),'vertices',len(out['triangles']),'triangles',len(ids),'bones, height 62; source distances',out['binding_distance_percentiles'])

from pathlib import Path
import struct,re,json
W=Path('/workspace/forest-sage');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable','gObjectTable']};(W/'symbols.json').write_text(json.dumps(syms))
s=(W/'runner.c').read_text();needle='  if(strstr(scenario,"hostile")){static'
extra='''  if(strstr(scenario,"bowling-sage") && f%50==0){uint32_t ctx=play+0x117a4,begin=r32(ctx),end=r32(ctx+4),last=begin;int count=DebugMemRead8(ctx+8);for(int i=0;i<count && i<19;i++){uint32_t slot=ctx+12+i*0x44;int id=(int16_t)DebugMemRead16(slot);if(id<0)id=-id;if(id>0 && id<0x192){uint32_t e=r32(slot+4)+r32(OBJECT_TABLE+id*8+4)-r32(OBJECT_TABLE+id*8);if(e>last)last=e;}}printf("OBJECT_BANK f=%u entries=%d used=%u capacity=%u remaining=%d\\n",f,count,last-begin,end-begin,(int)(end-last));if(last>end){fprintf(stderr,"OBJECT_BANK_OVERFLOW\\n");exit(96);}}
  if(strstr(scenario,"bowling-sage") && f%50==0){uint32_t y=actor(0x146);printf("YOUNG_SARIA f=%u actor=%08x limbs=%u skeleton=%08x\\n",f,y,y?DebugMemRead8(y+0x13c):0,y?r32(y+0x140):0);}
  if(strstr(scenario,"credits") && f<=160 && f%10==0){printf("SHOT f=%u\\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
'''.replace('OBJECT_TABLE',hex(syms['gObjectTable']))
s=s.replace(needle,extra+needle);(W/'runner-final.c').write_text(s)
b=bytearray((W/'hall2.save').read_bytes());b[0x1409]=0;(W/'english.save').write_bytes(b)
b=bytearray(Path('/workspace/npc-stimmen/kokiri-happy.save').read_bytes());struct.pack_into('>III',b,0,0x437,1,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,-45.,0.,-4.,16384,0xdff,0x437,0);b[0x74+7]=7;o=0xed4+2*(0x40>>4);struct.pack_into('>H',b,o,struct.unpack_from('>H',b,o)[0]&~1);(W/'childhouse.save').write_bytes(b)
p=W/'run.py';s=p.read_text().replace("str(W/'runner')","str(W/'runner-final')");p.write_text(s)
p=W/'select_shot.py';s=Path('/workspace/forest-dialogue/select_shot.py').read_text().replace('/workspace/forest-dialogue','/workspace/forest-sage').replace('(?:TEXT|PHOTO)','(?:TEXT|PHOTO|SHOT)');p.write_text(s)

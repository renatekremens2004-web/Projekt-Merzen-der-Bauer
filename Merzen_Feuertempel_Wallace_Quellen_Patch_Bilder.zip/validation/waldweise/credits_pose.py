from pathlib import Path
import bpy,json,math
from mathutils import Matrix,Vector
R=Path('/workspace/Projekt-Merzen-der-Bauer');p=R/'tools/bowling_sage_source.json';m=json.loads(p.read_text());rest=[Matrix(b['rest_matrix']) for b in m['bones']];idx={int(b['name'].split('_')[1]):i for i,b in enumerate(m['bones'])}
def angles(mat):return [round(a*32768/math.pi)%65536 for a in mat.to_euler('XYZ')]
for label,count in [('sit_idle',24),('sit_down',19),('sit_up',43),('seal',75)]:
 frames=[]
 for f in range(count):
  t=f/(count-1);ease=.5-.5*math.cos(math.pi*t);tilt=0 if label=='sit_idle' else (25*ease if label=='sit_down' else 25*(1-ease));sitting=label.startswith('sit_');world=[r.to_3x3().copy() for r in rest]
  amount=(-28+95*ease) if label=='seal' else -28
  for b,sgn in [(13,1),(16,-1)]:world[idx[b]]=Matrix.Rotation(math.radians(sgn*amount),3,'Z')@rest[idx[b]].to_3x3()
  # Parent movement carries forearms and hands with no length/scale changes.
  for upper,lower,hand in [(13,14,15),(16,17,18)]:
   delta=world[idx[upper]]@rest[idx[upper]].to_3x3().inverted();world[idx[lower]]=delta@rest[idx[lower]].to_3x3();world[idx[hand]]=delta@rest[idx[hand]].to_3x3()
  if sitting:
   for thigh,knee,foot,sgn in [(3,4,5,-1),(6,7,8,1)]:
    a=idx[thigh];k=idx[knee];ft=idx[foot];d=(rest[k].translation-rest[a].translation).normalized();target=Vector((sgn*.80,-.22,.56)).normalized();q=d.rotation_difference(target);world[a]=q.to_matrix()@rest[a].to_3x3()
    d=(rest[ft].translation-rest[k].translation).normalized();target=Vector((sgn*.025,-.985,.17)).normalized();world[k]=d.rotation_difference(target).to_matrix()@rest[k].to_3x3();world[ft]=Matrix.Rotation(math.radians(-8),3,'X')@rest[ft].to_3x3()
   world[idx[10]]=Matrix.Rotation(math.radians(tilt),3,'X')@rest[idx[10]].to_3x3()
  rotations=[]
  for i,b in enumerate(m['bones']):rotations.append(angles(world[b['parent']].inverted()@world[i] if b['parent']>=0 else world[i]))
  root=[0,8300,0] if sitting else m['animations']['idle'][0]['root']
  frames.append({'root':root,'rotation':rotations})
 m['animations'][label]=frames
m['credits']={'root_model_units':[0,8300,0],'thigh_direction':[-.8,-.22,.56],'shin_direction':[0,-.985,.17],'same_body_scale_as_hall':True,'source_native_frame_counts':{'sit_down':19,'sit_up':43,'sit_idle':24,'seal':75}}
p.write_text(json.dumps(m,separators=(',',':'))+'\n');print('Credits/sealing own poses generated; all bone translations and scale remain fixed.')

from pathlib import Path
import json,collections,numpy as np,itertools
W=Path('/workspace/forest-sage');m=json.loads((W/'parsed.json').read_text());source=collections.defaultdict(list)
for t in m['dae_triangles']:
 for c in t['corners']:
  k=(t['material'],tuple(round(x,2) for x in c['uv']));p=c['position']
  if p not in source[k]:source[k].append(p)
def align(x,y):
 xc=x.mean(0);yc=y.mean(0);u,s,v=np.linalg.svd((x-xc).T@(y-yc));r=v.T@u.T
 if np.linalg.det(r)<0:v[-1]*=-1;r=v.T@u.T
 scale=np.sum(s)/np.sum((x-xc)**2);r=r*scale
 return r,yc-r@xc
fits={}
for bone in sorted(set(t['bone'] for t in m['triangles'])):
 if bone==11:continue
 points={}
 for t in m['triangles']:
  if t['bone']!=bone:continue
  for c in t['corners']:
   k=(t['material'],(round((c['st'][0]+16)/1024,2),round(1-(c['st'][1]+16)/1024,2)))
   if k in source:points[tuple(c['position'])]=source[k]
 unique=[(x,ys[0]) for x,ys in points.items() if len(ys)==1]
 print('bone',bone,'points',len(points),'unique',len(unique))
 if len(unique)>=3:
  x=np.array([p[0] for p in unique]);y=np.array([p[1] for p in unique]);r,t=align(x,y)
 else:
  # Source UVs on mirrored limbs can have two candidates. RANSAC chooses the proper rigid mapping.
  rng=np.random.default_rng(bone);best=None;ps=list(points.items())
  for _ in range(800):
   sel=rng.choice(len(ps),3,replace=False);x=np.array([ps[i][0] for i in sel]);y=np.array([ps[i][1][rng.integers(len(ps[i][1]))] for i in sel]);rr,tt=align(x,y);errs=[min(np.linalg.norm(rr@np.array(p)+tt-q) for q in qs) for p,qs in ps];score=np.median(errs)
   if best is None or score<best[0]:best=score,rr,tt
  _,r,t=best
 # Refine by nearest source choices, retain only good correspondences to avoid UV ambiguity.
 for _ in range(4):
  pairs=[]
  for x,ys in points.items():
   x=np.array(x);yy=min(ys,key=lambda y:np.linalg.norm(r@x+t-y));err=np.linalg.norm(r@x+t-yy)
   if err<80:pairs.append((x,yy))
  if len(pairs)>=3:r,t=align(np.array([p[0] for p in pairs]),np.array([p[1] for p in pairs]))
 errors=[min(np.linalg.norm(r@np.array(p)+t-q) for q in qs) for p,qs in points.items()]
 print(' fit',np.percentile(errors,[0,50,90,100]),'translation',t.tolist())
 fits[bone]={'rotation':r.tolist(),'translation':t.tolist(),'median_error':float(np.median(errors)), 'scale':float(np.linalg.det(r)**(1/3))}
(W/'fits.json').write_text(json.dumps(fits,indent=2))

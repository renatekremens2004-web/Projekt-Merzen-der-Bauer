from pathlib import Path
import struct,re,json
W=Path('/workspace/forest-sage');O=Path('/workspace/oot-burns-pal')
s=Path('/workspace/forest-dialogue/runner.c').read_text();needle='  if(strstr(scenario,"hostile")){static'
extra='''  if(strstr(scenario,"bowling-sage") && f%25==0){uint32_t n=actor(0xc9);printf("FOREST_SAGE f=%u actor=%08x limbs=%u skeleton=%08x anim=%08x animframe=%.1f action=%u draw=%u yOffset=%.1f pos=(%.1f %.1f %.1f) medal=%x room=%d\\n",f,n,n?DebugMemRead8(n+0x13c):0,n?r32(n+0x140):0,n?r32(n+0x144):0,n?rf(n+0x154):0,n?r32(n+0x188):0,n?r32(n+0x18c):0,n?rf(n+0xbc):0,n?rf(n+0x24):0,n?rf(n+0x28):0,n?rf(n+0x2c):0,r32(savebase+0xa4)&1,(int8_t)DebugMemRead8(play+0x11df0));}
  if(strstr(scenario,"bowling-sage") && f%20==0 && f>300 && DebugMemRead16(play+0xa4)==0x55 && (r32(savebase+0xa4)&1)){printf("NATIVE_FOREST_RETURN f=%u medal=1\\n",f);CoreDoCommand(M64CMD_STOP,0,NULL);}
  if(strstr(scenario,"bowling-sage") && f>=1350 && f<=1550 && f%10==0)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
'''
s=s.replace(needle,extra+needle);(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
for name,lang in [('hall',1),('english',0)]:
 b=bytearray(Path('/workspace/forest-dialogue/house.save').read_bytes());struct.pack_into('>III',b,0,0x6b,0,0);struct.pack_into('>I',b,0x1364,0);struct.pack_into('>I',b,0x1360,0);b[0x1409]=lang;b[0x1415]=0;struct.pack_into('>I',b,0xa4,struct.unpack_from('>I',b,0xa4)[0]&~1);(W/(name+'.save')).write_bytes(b)
# Original child Saria greeting, on the retail entrance and progress branch.
b=bytearray(Path('/workspace/npc-stimmen/kokiri-happy.save').read_bytes());struct.pack_into('>I',b,0x1364,0);(W/'child.save').write_bytes(b)

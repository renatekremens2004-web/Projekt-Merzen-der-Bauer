from pathlib import Path
import xml.etree.ElementTree as E,zipfile,json
W=Path('/workspace/forest-sage');R=Path('/workspace/Projekt-Merzen-der-Bauer');root=E.parse(W/'assets/treasure/treasure_girl.dae').getroot();ns={'c':root.tag.split('}')[0][1:]};mesh=root.find('.//c:geometry/c:mesh',ns);arrays={}
for src in mesh.findall('c:source',ns):
 v=list(map(float,src.find('c:float_array',ns).text.split()));st=int(src.find('c:technique_common/c:accessor',ns).attrib['stride']);arrays[src.attrib['id']]=[v[i:i+st] for i in range(0,len(v),st)]
positions=arrays[mesh.find('c:vertices/c:input',ns).attrib['source'][1:]];dae=[];mats={'material-02DE7A4B-material':'treasure_girl_e_2800','material-01352A08-material':'treasure_girl_0_2000','material-01E97672-material':'treasure_girl_0_0'}
for poly in mesh.findall('c:polylist',ns):
 links={i.attrib['semantic']:(int(i.attrib['offset']),i.attrib['source'][1:]) for i in poly.findall('c:input',ns)};st=max(i[0] for i in links.values())+1;vals=list(map(int,poly.find('c:p',ns).text.split()));cs=[vals[i:i+st] for i in range(0,len(vals),st)]
 for start in range(0,len(cs),3):dae.append({'material':mats[poly.attrib['material']],'corners':[{'position':positions[c[links['VERTEX'][0]]],'uv':arrays[links['TEXCOORD'][1]][c[links['TEXCOORD'][0]]],'normal':arrays[links['NORMAL'][1]][c[links['NORMAL'][0]]]} for c in cs[start:start+3]]})
z=zipfile.ZipFile(W/'assets/bowling/bombchu_lady.o2r');bones=[];tris=[];cache={};material=None
for i in range(21):
 e=E.fromstring(z.read('alt/objects/object_link_boy/gLinkAdultSkelLimb_%03d'%i));a=e.attrib;bones.append({'name':str(i),'parent':-1,'position':[int(a['LegTrans'+c]) for c in 'XYZ'],'child':int(a['ChildIndex']),'sibling':int(a['SiblingIndex']),'display':a['DisplayList1']})
def hierarchy(i,parent=-1):
 bones[i]['parent']=parent
 if bones[i]['child']!=255:hierarchy(bones[i]['child'],i)
 if bones[i]['sibling']!=255:hierarchy(bones[i]['sibling'],parent)
hierarchy(0)
def display(path,bone):
 global material
 if path=='gEmptyDL':return
 e=E.fromstring(z.read('alt/'+path))
 for cmd in e:
  a=cmd.attrib
  if cmd.tag=='CallDisplayList':display(a['Path'],bone)
  elif cmd.tag=='SetTextureImage':material=Path(a['Path']).name
  elif cmd.tag=='LoadVertices':
   ve=E.fromstring(z.read('alt/'+a['Path']));vs=list(ve);offset=int(a['VertexOffset']);start=int(a['VertexBufferIndex'])
   for j in range(int(a['Count'])):
    v=vs[offset+j].attrib;cache[start+j]={'position':[int(v[k]) for k in 'XYZ'],'st':[int(v[k]) for k in ['S','T']],'normal':[(int(v[k])+128)%256-128 for k in ['R','G','B']]}
  elif cmd.tag in ['Triangle1','Triangle2']:
   for t in range(1 if cmd.tag=='Triangle1' else 2):tris.append({'bone':bone,'material':material,'corners':[cache[int(a['V%d%d'%(t,k)])].copy() for k in range(3)]})
for i,b in enumerate(bones):
 if i!=19:display(b['display'],i)
(W/'parsed.json').write_text(json.dumps({'bones':bones,'triangles':tris,'dae_triangles':dae},separators=(',',':')))
from collections import Counter
print('DAE',len(dae),'O2R body',len(tris));print(Counter((t['bone'],t['material']) for t in tris))

import bpy,json,math,sys
from pathlib import Path
from mathutils import Vector,Matrix
R=Path('/workspace/Projekt-Merzen-der-Bauer');D=R/'models/wallace';D.mkdir(exist_ok=True)
try:bpy.ops.wm.open_mainfile(filepath='/workspace/wallace/source/blend/source/wallacerig.blend')
except RuntimeError as exc:print('Source contains broken optional shape key; mesh remains readable:',exc)
o=next(x for x in bpy.data.objects if x.type=='MESH' and len(x.data.polygons)>100)
for mod in list(o.modifiers):o.modifiers.remove(mod)
if o.data.shape_keys:o.shape_key_clear()
bpy.context.view_layer.objects.active=o
mod=o.modifiers.new('N64 mesh reduction','DECIMATE');mod.ratio=0.34;bpy.ops.object.modifier_apply(modifier=mod.name)
mesh=o.data;mesh.calc_loop_triangles()
low=min(v.co.y for v in mesh.vertices);high=max(v.co.y for v in mesh.vertices);scale=9000/(high-low)
shoulders=[Vector((.4,2.7,-.25)),Vector((-.4,2.7,-.25))]
def group_weights(v):
 scores=[0.,0.,0.,0.]
 for g in v.groups:
  n=o.vertex_groups[g.group].name
  if not n.startswith('mixamorig:'):continue
  kind=1 if n.endswith(('Head','Neck')) else 2 if 'Left' in n and any(s in n for s in ['Arm','Hand']) else 3 if 'Right' in n and any(s in n for s in ['Arm','Hand']) else 0
  scores[kind]+=g.weight
 return scores
def adjusted(v):
 scores=group_weights(v);p=v.co.copy();rot=Matrix.Identity(3)
 for side,sign in [(2,-1),(3,1)]:
  if scores[side]>.001:
   angle=math.radians(65)*sign*min(1,scores[side]);rot=Matrix.Rotation(angle,3,'Z');pivot=shoulders[side-2];p=pivot+rot@(p-pivot)
 return p,rot,scores.index(max(scores))
pivots=[Vector((0,low,0)),Vector((0,2.99,-.12)),*shoulders]
model={'bones':[{'name':n,'parent':-1,'position':[round(v.x*scale),round((v.y-low)*scale),round(v.z*scale)]} for n,v in zip(['body','head','left_arm','right_arm'],pivots)],'materials':[],'vertices':[],'triangles':[]}
for m in mesh.materials:
 im=next(n.image for n in m.node_tree.nodes if n.type=='TEX_IMAGE' and n.image);name=im.name.split('.png')[0]+'.png';im.filepath_raw=str(D/name);im.file_format='PNG';im.save()
 model['materials'].append({'name':name[:-4],'texture':name,'size':list(im.size)})
rotations=[]
for v in mesh.vertices:
 p,rot,bone=adjusted(v);p=(p-pivots[bone])*scale
 model['vertices'].append({'bone':bone,'position':[round(x) for x in p]});rotations.append(rot)
uv=mesh.uv_layers.active.data
for tri in mesh.loop_triangles:
 cs=[]
 for vi,li in zip(tri.vertices,tri.loops):
  n=rotations[vi]@mesh.loops[li].normal;n.normalize();cs.append({'vertex':vi,'uv':list(uv[li].uv),'normal':[round(x*127) for x in n]})
 model['triangles'].append({'material':tri.material_index,'corners':cs})
(R/'tools/wallace_source.json').write_text(json.dumps(model,separators=(',',':'))+'\n')
(D/'conversion.json').write_text(json.dumps({'source':'wallace.zip/source/wallacerig.blend','source_triangles':4249,'triangles':len(model['triangles']),'height_game_units':90,'own_rigid_bones':4,'source_modifiers_removed':True,'shape_key_warning':'Invalid optional source shapekey discarded; source scripts never executed.','no_translation_scale_or_shear_animation':True},indent=2)+'\n')
print('Exported',len(mesh.vertices),'vertices',len(model['triangles']),'triangles','pivots',[b['position'] for b in model['bones']])

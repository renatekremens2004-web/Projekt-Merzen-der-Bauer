from pathlib import Path
import json,re,struct
W=Path('/workspace/wallace');source=Path('/workspace/wald-dialoge-feuer/runner.c').read_text()
source=source.replace('if(strstr(scenario,"new-sages") && f%50==0)','if((strstr(scenario,"new-sages") || strstr(scenario,"wallace")) && f%50==0)')
marker='  if(f%100==0)printf("RACE'
idx=source.index(marker)
source=source[:idx]+'''  if(strstr(scenario,"wallace") && f%50==0){uint32_t npc=actor(0x173);printf("WALLACE f=%u present=%u category=%u params=%04x pos=(%.1f %.1f %.1f) focus=%.1f draw=%08x room=%d\\n",f,npc!=0,npc?DebugMemRead8(npc+2):255,npc?DebugMemRead16(npc+0x1c):0,npc?rf(npc+0x24):0,npc?rf(npc+0x28):0,npc?rf(npc+0x2c):0,npc?rf(npc+0x3c):0,npc?r32(npc+0x134):0,(int8_t)DebugMemRead8(play+0x11cbc));}
'''+source[idx:]
(W/'runner.c').write_text(source)
mp=Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0.map').read_text();symbols={}
for n in ['gSaveContext','gActorOverlayTable','gObjectTable']:
 symbols[n]=int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\b',mp)[1],16)
(W/'symbols.json').write_text(json.dumps(symbols)+'\n')
base=Path('/workspace/post-jabu-test/guard.save').read_bytes()
for name,age,lang,cleared in [('child',1,1,False),('cleared',1,1,True),('adult',0,1,False),('english',1,0,False)]:
 b=bytearray(base);struct.pack_into('>III',b,0,4,age,0);struct.pack_into('>II',b,0x1360,0,1);struct.pack_into('>fffhHhB',b,0x1368,-2250.,0.,-1250.,0,0xdff,4,2);b[0x1409]=lang
 struct.pack_into('>HH',b,0x2e,160,160)
 struct.pack_into('>I',b,0xd4+1*0x1c+0x08,(1<<2) if cleared else 0)
 (W/(name+'.save')).write_bytes(b)
s=Path('/workspace/wald-dialoge-feuer/run.py').read_text().replace("W=Path('/workspace/wald-dialoge-feuer')","W=Path('/workspace/wallace')").replace("case='wald-dialoge-'+topic","case='wallace-'+topic")
(W/'run.py').write_text(s)

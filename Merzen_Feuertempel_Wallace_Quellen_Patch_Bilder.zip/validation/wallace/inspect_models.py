import bpy,json
from pathlib import Path
for label,path in [('rigged','/workspace/wallace/source/blend/source/wallacerig.blend'),('game','/workspace/wallace/source/game/unpacked/Wallace/Wallace.obj')]:
 if path.endswith('.blend'):
  try:bpy.ops.wm.open_mainfile(filepath=path)
  except RuntimeError as e:print('SOURCE_LOAD_WARNING',str(e))
 else:
  bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.wm.obj_import(filepath=path)
 result=[]
 for o in bpy.context.scene.objects:
  if o.type=='MESH':
   o.data.calc_loop_triangles();result.append(dict(name=o.name,type=o.type,vertices=len(o.data.vertices),triangles=len(o.data.loop_triangles),dimensions=list(o.dimensions),groups=[g.name for g in o.vertex_groups],materials=[m.name if m else '' for m in o.data.materials]))
  elif o.type=='ARMATURE':result.append(dict(name=o.name,type=o.type,bones=[dict(name=b.name,head=list(b.head_local),tail=list(b.tail_local)) for b in o.data.bones]))
 images=[dict(name=i.name,path=i.filepath,size=list(i.size),packed=bool(i.packed_file)) for i in bpy.data.images]
 Path('/workspace/wallace/'+label+'-inspection.json').write_text(json.dumps(dict(objects=result,images=images),indent=2))
 print('MODEL',label,'triangles',sum(x.get('triangles',0) for x in result),'meshes',len(result))

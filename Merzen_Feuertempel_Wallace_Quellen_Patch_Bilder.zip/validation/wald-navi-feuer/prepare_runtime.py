from pathlib import Path
import json,re,struct
W=Path('/workspace/wald-dialoge-feuer');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();sym={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gObjectTable']};(W/'symbols.json').write_text(json.dumps(sym))
s=Path('/workspace/water-spirit-sages/runner.c').read_text();s=s.replace('  if(f==300){\n   uint32_t npc=0;', '  if(f==300){\n   uint32_t npc=0;\n   if(strstr(scenario,"lab-"))npc=actor(0x14a);\n   if(strstr(scenario,"kokiri-type"))npc=actor_type(0x163,atoi(strstr(scenario,"kokiri-type")+11));')
s=s.replace('  if(f==300 && strstr(scenario,"navi"))', '''  if(strstr(scenario,"saria-call")){
    static unsigned note=0,beat=0;
    if(mode==0)value=0;
    if(f>=320 && f<328 && mode==0)value=0x200;
    if(mode==0x0c){const unsigned song[]={0x400,0x100,0x200,0x400,0x100,0x200};value=0;if(note<6 && beat%24<8)value=song[note];beat++;if(beat%24==0)note++;}
    if(f%100==0)printf("SONG_INPUT f=%u mode=%x ocarinaMode=%x note=%u\\n",f,mode,DebugMemRead16(m+0xe3ee),note);
  }
  if(f==300 && strstr(scenario,"navi"))''')
# Native Minuet follow-along uses A, up, left, right, left, right, in its own check mode.
s=s.replace('  if(strstr(scenario,"lesson")){','  if(strstr(scenario,"lesson") || strstr(scenario,"minuet")){').replace('static const unsigned song[]={0x200,0x800,0x100,0x200,0x800,0x100};','static const unsigned song[]={0x200,0x800,0x100,0x200,0x800,0x100}; static const unsigned minuet[]={0x80,0x800,0x200,0x100,0x200,0x100};').replace('value=song[note];\n    clock++','value=(strstr(scenario,"minuet")?minuet[note]:song[note]);\n    clock++')
# All generated screenshots follow only normal controller input and production NPC positions.
s=s.replace('    static unsigned note=0,beat=0;', '    static unsigned note=0,beat=0;\n    if(f==300){DebugMemWrite8(savebase+0x69,8);DebugMemWrite8(savebase+0x6c,7);DebugMemWrite8(savebase+0x7b,8);}')
s=s.replace('  if(strstr(scenario,"navi") && f>500 && mode==0 && f%60<8)value=0x800;', '  if(strstr(scenario,"navi") && f>500 && mode==0 && f%60<8)value=0x800;\n  if(strstr(scenario,"navi-statue")){if(f==300)position(player,rf(player+0x24),rf(player+0x28)+18,rf(player+0x2c),DebugMemRead16(player+0xb6));if(f>=302 && f<310 && mode==0)value=0x800;}')
(W/'runner.c').write_text(s)
base=Path('/workspace/forest-dialogue/house.save').read_bytes()
def flag(b,x,v):
 o=0xed4+2*(x>>4);n=struct.unpack_from('>H',b,o)[0];struct.pack_into('>H',b,o,n|1<<(x&15) if v else n&~(1<<(x&15)))
def fixture(name,ent,age,pos,yaw,post=False,lang=1):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,0);struct.pack_into('>II',b,0x1360,0,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,0);b[0x1409]=lang
 flag(b,0x48,post);flag(b,0x50,False);q=struct.unpack_from('>I',b,0xa4)[0];struct.pack_into('>I',b,0xa4,q|1 if post else q&~1)
 struct.pack_into('>H',b,0xf30,struct.unpack_from('>H',b,0xf30)[0]|0x8000)
 (W/(name+'.save')).write_bytes(b);return b
for name,age,lang in [('lab-adult',0,1),('lab-child',1,1),('lab-english',0,0)]:fixture(name,0x43,age,(-90.,0.,95.),-30000,lang=lang)
fixture('minuet',0xfc,0,(0.,480.,-2240.),-32768)
for typ in [0,1,2,3,6,7,9]:
 # Adult pre-clear Kokiri are inside Mido's house, except for the shop and separate house pair.
 ent={0:0x433,1:0x9c,2:0xee,3:0xee,6:0x437,7:0xc9,9:0x9c}[typ]
 fixture('kokiri-type'+str(typ),ent,0,(-60.,0.,88.),1000,post=typ in [2,3])
# Post-clear residents return to the native forest, no actor is relocated.
fixture('kokiri-type1-after',0xee,0,(669.,0.,570.),-32768,post=True)
b=fixture('saria-call',0xee,0,(-160.,0.,550.),0)
b[0x69]=8;b[0x6c]=7;b[0x74+7]=8
# Song possession and a free C-left slot for ordinary controller playback.
q=struct.unpack_from('>I',b,0xa4)[0];struct.pack_into('>I',b,0xa4,q|1<<18);(W/'saria-call.save').write_bytes(b)
print(sym)

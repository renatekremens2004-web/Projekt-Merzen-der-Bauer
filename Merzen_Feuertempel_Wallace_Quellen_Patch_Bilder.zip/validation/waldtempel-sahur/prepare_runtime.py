from pathlib import Path
import re,json,struct
W=Path('/workspace/forest-temple');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gObjectTable']};(W/'symbols.json').write_text(json.dumps(syms));old=json.loads(Path('/workspace/forest-sage-revision/symbols.json').read_text());c=Path('/workspace/forest-sage-revision/runner.c').read_text().replace(hex(old['gObjectTable']),hex(syms['gObjectTable']))
needle='  if(f==300 && strstr(scenario,"navi"))';assert needle in c
extra='''  if(strstr(scenario,"forest-temple") && f%25==0){
   uint32_t n=actor(0x11a); /* native Obj_Dekujr */
   uint32_t mask=actor_type(0x173,9);
   printf("SPROUT f=%u actor=%08x scale=%.4f pos=(%.1f %.1f %.1f) init=%d cue=%d anim=%08x frame=%.1f text=%x\\n",f,n,n?rf(n+0x50):0,n?rf(n+0x24):0,n?rf(n+0x28):0,n?rf(n+0x2c):0,n?DebugMemRead8(n+0x18b):0,n?DebugMemRead8(n+0x18c):0,n?r32(n+0x19c):0,n?rf(n+0x1ac):0,n?DebugMemRead16(n+0x10e):0);
   printf("MASK f=%u actor=%08x params=%x pos=(%.1f %.1f %.1f) focus=%08x text=%x room=%d\\n",f,mask,mask?DebugMemRead16(mask+0x1c):0,mask?rf(mask+0x24):0,mask?rf(mask+0x28):0,mask?rf(mask+0x2c):0,r32(player+0x654),mask?DebugMemRead16(mask+0x10e):0,(int8_t)DebugMemRead8(play+0x11cbc));
  }
  if(strstr(scenario,"corridor") && mode==0){value=0x20;if(f>20 && f%80<8)value|=0x800;}
'''
c=c.replace(needle,extra+needle)
c=c.replace('if(strstr(scenario,"bowling-sage") && f%50==0){uint32_t ctx','if(strstr(scenario,"forest-temple") && f%50==0){uint32_t ctx')
# Native sprout has actor id 0x165 (read from actor_table below, not guessed).
a=(O/'include/tables/actor_table.h').read_text();id=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ACTOR\(Obj_Dekujr,',a)[1],16);c=c.replace('actor(0x11a); /* native Obj_Dekujr */',f'actor(0x{id:x}); /* native Obj_Dekujr */')
(W/'runner.c').write_text(c)
base=bytearray(Path('/workspace/forest-dialogue/house.save').read_bytes())
for name,lang,room,pos,yaw,med,child in [('corridor',1,21,(-1940.,443.,-3160.),-32768,False,False),('corridor-cleared',1,21,(-1940.,443.,-3160.),-32768,True,False),('corridor-en',0,21,(-1940.,443.,-3160.),-32768,False,False),('sprout',1,1,(3650.,-179.,-1020.),-32768,True,False),('sprout-en',0,1,(3650.,-179.,-1020.),-32768,True,False),('before-sprout',1,1,(3650.,-179.,-1020.),-32768,False,False),('child-sprout',1,1,(3650.,-179.,-1020.),-32768,True,True)]:
 ent=0x169 if 'corridor' in name else 0xee;b=bytearray(base);struct.pack_into('>III',b,0,ent,int(child),0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>I',b,0x1360,0);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,room);b[0x1409]=lang;struct.pack_into('>H',b,0xf30,struct.unpack_from('>H',b,0xf30)[0]|0x8000);struct.pack_into('>HH',b,0x2e,160,160);q=struct.unpack_from('>I',b,0xa4)[0];struct.pack_into('>I',b,0xa4,q|1 if med else q&~1)
 if med:struct.pack_into('>H',b,0xedc,struct.unpack_from('>H',b,0xedc)[0]|0x100)
 if name=='corridor-cleared':struct.pack_into('>I',b,0xd4+3*0x1c+8,0xffffffff)
 (W/(name+'.save')).write_bytes(b)
(W/'rise.save').write_bytes(Path('/workspace/forest-sage/hall2.save').read_bytes())
print(syms,'Sprout ID',hex(id))

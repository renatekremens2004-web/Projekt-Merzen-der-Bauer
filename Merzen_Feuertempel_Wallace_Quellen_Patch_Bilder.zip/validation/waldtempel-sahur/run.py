from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/forest-temple');s=json.loads((W/'symbols.json').read_text())
def run(topic):
 case='forest-temple-'+topic+os.environ.get('TEMPLE_RUN','-v2-direct-clip-on');limit=int(os.environ.get('FRAME_LIMIT',6000 if topic=='rise' else 1700))
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/'runner'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:] or ['corridor','rise']))

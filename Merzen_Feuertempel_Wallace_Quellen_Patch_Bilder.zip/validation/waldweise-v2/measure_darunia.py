from pathlib import Path
import re,json,math,numpy as np
A=Path('/workspace/oot-burns-pal/extracted/pal-1.0/assets/objects/object_du');W=Path('/workspace/forest-sage-revision')
def clean(s):return re.sub(r'/\*.*?\*/|//[^\n]*','',s,flags=re.S)
def numbers(s):return [int(x,0) if 'x' in x.lower() else int(x) for x in re.findall(r'-?0x[0-9A-Fa-f]+|-?\d+',s)]
def transform(t,r):
 x,y,z=[v*math.pi/32768 for v in r];cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
 q=np.eye(4);q[:3,:3]=[[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]];q[:3,3]=t;return q
names=re.findall(r'&(\w+)',(A/'gDaruniaLimbs.inc.c').read_text());bones=[]
for name in names:
 s=(A/(name+'.inc.c')).read_text();cs=re.findall(r'/\*\s*(\d+)\s*\*/',s);pos=numbers(clean(s).split('}')[0]);dl=re.search(r'(\w+),\s*// dList',s)[1];bones.append({'pos':pos,'child':int(cs[0]),'sib':int(cs[1]),'dl':dl,'name':name})
frame=numbers(clean((A/'gDaruniaCreditsIdleFrameData.inc.c').read_text()));indices=numbers(clean((A/'gDaruniaCreditsIdleJointIndices.inc.c').read_text()));rot=[]
for i in range(0,len(indices),3):rot.append([frame[x] if x<8 else frame[x] for x in indices[i:i+3]])
world=[None]*len(bones)
def visit(i,parent):
 if i==255:return
 b=bones[i];world[i]=parent@transform(rot[0] if i==0 else b['pos'],rot[i+1]);visit(b['child'],world[i]);visit(b['sib'],parent)
visit(0,np.eye(4));vertices={}
for p in A.glob('*Vtx*.inc.c'):
 vertices[p.name[:-6]]=[numbers(x)[:3] for x in re.findall(r'VTX\((.*?)\)',clean(p.read_text()))]
points=[];bybone={}
for i,b in enumerate(bones):
 if b['dl']=='NULL':continue
 src=clean((A/(b['dl']+'.inc.c')).read_text());mat=world[i];pts=[]
 for cmd,body in re.findall(r'(gsSPMatrix|gsSPVertex)\((.*?)\)\s*,',src,re.S):
  if cmd=='gsSPMatrix':
   hx=re.search('0x[0-9A-Fa-f]+',body)
   if hx and (int(hx[0],16)>>24)==13:mat=world[(int(hx[0],16)&0xffffff)//64+1]
  else:
   name,j,n=re.search(r'&(\w+)\[(\d+)\],\s*(\d+)',body).groups()
   for v in vertices[name][int(j):int(j)+int(n)]:pts.append((mat@np.array([*v,1]))[:3]/100)
 if pts:
  arr=np.array(pts);bybone[i]={'dl':b['dl'],'joint':(world[i][:3,3]/100).tolist(),'bounds':list(zip(arr.min(0).tolist(),arr.max(0).tolist())),'points':arr.tolist()};points+=pts
(W/'darunia_pose.json').write_text(json.dumps({'bones':bybone,'world_matrices':[m.tolist() for m in world],'points':[p.tolist() for p in points]},indent=2))

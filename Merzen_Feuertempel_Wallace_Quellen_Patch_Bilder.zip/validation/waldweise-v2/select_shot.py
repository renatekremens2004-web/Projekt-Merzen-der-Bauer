from pathlib import Path
import re,sys
W=Path('/workspace/forest-sage-revision')
def select(case,limit,wanted):
 events=[]
 for line in (W/(case+'.log')).read_text().splitlines():
  m=re.match(r'(?:TEXT|PHOTO|SHOT) f=(\d+)',line)
  if m:events.append(int(m[1]))
  m=re.match(r'STATE f=(\d+)',line)
  if m and 300<=int(m[1]) and int(m[1])+50<limit:events.append(int(m[1]))
 events=sorted(set(events)|set(range(1350,min(limit,1551),10)));p=Path('/workspace/bean-rider')/('screens-'+case)/('the_legend_of_zelda-%03d.png'%events.index(wanted));return p
if __name__=='__main__':print(select(sys.argv[1],int(sys.argv[2]),int(sys.argv[3])))

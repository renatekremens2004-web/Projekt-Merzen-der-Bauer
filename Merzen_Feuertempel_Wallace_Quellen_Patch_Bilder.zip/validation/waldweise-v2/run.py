from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/forest-sage-revision');s=json.loads((W/'symbols.json').read_text());B=Path('/workspace/forest-sage')
def run(topic):
 case='bowling-sage-'+topic+os.environ.get('SAGE_RUN','-seat-v1')+'-direct-clip-on';limit=int(os.environ.get('FRAME_LIMIT',2900 if topic.startswith('hall') else (700 if topic=='credits' else 1800)))
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/'runner'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(B/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:] or ['credits','hall2']))

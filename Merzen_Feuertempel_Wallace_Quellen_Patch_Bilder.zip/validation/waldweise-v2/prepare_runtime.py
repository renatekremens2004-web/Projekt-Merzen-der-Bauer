from pathlib import Path
import re,json
W=Path('/workspace/forest-sage-revision');B=Path('/workspace/forest-sage');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();s={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable','gObjectTable']};(W/'symbols.json').write_text(json.dumps(s));old=json.loads((B/'symbols.json').read_text());c=(B/'runner-final.c').read_text().replace(hex(old['gObjectTable']),hex(s['gObjectTable']))
needle='  if(strstr(scenario,"credits") && f<=160 && f%10==0)'
c=c.replace(needle,'  if(strstr(scenario,"credits") && f%25==0){uint32_t d=actor(0xa8);printf("DARUNIA f=%u actor=%08x pos=(%.2f %.2f %.2f) anim=%08x frame=%.1f\\n",f,d,d?rf(d+0x24):0,d?rf(d+0x28):0,d?rf(d+0x2c):0,d?r32(d+0x144):0,d?rf(d+0x154):0);}\n'+needle)
(W/'runner.c').write_text(c)
(W/'select_shot.py').write_text((B/'select_shot.py').read_text().replace('/workspace/forest-sage','/workspace/forest-sage-revision'))

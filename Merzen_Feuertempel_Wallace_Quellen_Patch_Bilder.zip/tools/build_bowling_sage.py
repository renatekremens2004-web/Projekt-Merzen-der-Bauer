"""Build the supplied Bowling Lady only for the German forest medallion reveal."""
from pathlib import Path
import sys,json,math,itertools,re
from PIL import Image
ROOT=Path(__file__).resolve().parent;O=Path(sys.argv[1]).resolve();A=O/'extracted/pal-1.0/assets/objects/object_sa';B=ROOT/'originals/bowling_sage'
def original(p):
 b=B/p.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes(p.read_bytes())
 return b.read_text()
m=json.loads((ROOT/'bowling_sage_source.json').read_text());n=len(m['bones']);assert n==15;lines=['/* Supplied BowlingSage avatar: own proportions and unit-scale poses. */']
def u64(name,data):
 data+=bytes((-len(data))%8);lines.append('static u64 '+name+'[]={');lines.extend('0x'+data[i:i+8].hex().upper()+',' for i in range(0,len(data),8));lines.append('};')
def rgba16(c):
 r,g,b=c[:3];return ((r>>3)<<11)|((g>>3)<<6)|((b>>3)<<1)|1
texspec=[]
for i,mat in enumerate(m['materials']):
 im=Image.open(ROOT.parent/'models/bowling_sage/textures'/mat['texture']).convert('RGB').resize((32,32) if mat['name']=='treasure_girl_e_2800' else (64,64),Image.Resampling.LANCZOS)
 im=im.quantize(colors=16,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE);pal=im.getpalette();data=list(im.getdata());u64('gBowlingSagePalette%d'%i,b''.join(rgba16(pal[j:j+3]).to_bytes(2,'big') for j in range(0,48,3)));u64('gBowlingSageTex%d'%i,bytes((data[j]<<4)|data[j+1] for j in range(0,len(data),2)));texspec.append(im.size);im.save(ROOT.parent/'models/bowling_sage/textures'/('n64_'+mat['name']+'.png'))
vertices=[];commands=[]
for mat,(w,h) in enumerate(texspec):
 commands+=['gsDPPipeSync(),','gsDPSetTextureLUT(G_TT_RGBA16),','gsDPLoadTLUT_pal16(0,gBowlingSagePalette%d),'%mat,'gsDPLoadTextureBlock_4b(gBowlingSageTex%d,G_IM_FMT_CI,%d,%d,0,G_TX_WRAP,G_TX_WRAP,%d,%d,G_TX_NOLOD,G_TX_NOLOD),'%(mat,w,h,round(math.log2(w)),round(math.log2(h)))]
 tris=[t for t in m['triangles'] if t['material']==mat]
 batches=[];local=[];lookup={};faces=[]
 for t in tris:
  corners=[]
  for c in t['corners']:
   v=m['vertices'][c['vertex']];data={'bone':v['bone'],'position':v['position'],'normal':c['normal'],'uv':[round(c['uv'][0]*w*32-16),round((1-c['uv'][1])*h*32-16)]};key=(data['bone'],*data['position'],*data['normal'],*data['uv']);corners.append((key,data))
  if len(set(lookup)|{k for k,v in corners})>32:
   batches.append((local,faces));local=[];lookup={};faces=[]
  face=[]
  for key,data in corners:
   if key not in lookup:lookup[key]=len(local);local.append(data)
   face.append(lookup[key])
  faces.append(face)
 if faces:batches.append((local,faces))
 for local,faces in batches:
  assert len(local)<=32
  order=sorted(range(len(local)),key=lambda j:local[j]['bone']);slots={v:i for i,v in enumerate(order)}
  for bone,itr in itertools.groupby(order,key=lambda j:local[j]['bone']):
   group=list(itr);off=len(vertices);vertices.extend(local[j] for j in group);commands+=['gsSPMatrix((Mtx*)0x%08X,G_MTX_NOPUSH|G_MTX_LOAD|G_MTX_MODELVIEW),'%(0x0d000000+bone*64),'gsSPVertex(&gBowlingSageVertices[%d],%d,%d),'%(off,len(group),slots[group[0]])]
  for j in range(0,len(faces),2):
   if j+1<len(faces):commands+=['gsSP2Triangles(%d,%d,%d,0,%d,%d,%d,0),'%tuple(slots[k] for f in faces[j:j+2] for k in f)]
   else:commands+=['gsSP1Triangle(%d,%d,%d,0),'%tuple(slots[k] for k in faces[j])]
lines+=['static Vtx gBowlingSageVertices[]={']
for v in vertices:
 assert all(-32768<=x<=32767 for x in v['position']+v['uv']);lines.append('{{{%d,%d,%d},0,{%d,%d},{%d,%d,%d,255}}},'%tuple(v['position']+v['uv']+[x&255 for x in v['normal']]))
lines+=['};','static Gfx gBowlingSageEmptyDL[]={gsSPEndDisplayList()};','static Gfx gBowlingSageBodyDL[]={','gsDPPipeSync(),','gsDPSetCycleType(G_CYC_2CYCLE),','gsSPTexture(0xffff,0xffff,0,0,G_ON),','gsDPSetRenderMode(G_RM_FOG_SHADE_A,G_RM_AA_ZB_OPA_SURF2),','gsSPDisplayList(0x0c000000),','gsSPClearGeometryMode(G_CULL_FRONT|G_CULL_BACK|G_TEXTURE_GEN|G_TEXTURE_GEN_LINEAR),','gsSPSetGeometryMode(G_LIGHTING|G_SHADE|G_SHADING_SMOOTH|G_ZBUFFER|G_FOG),','gsDPSetCombineLERP(TEXEL0,0,SHADE,0,0,0,0,TEXEL0,PRIMITIVE,0,COMBINED,0,COMBINED,0,ENVIRONMENT,0),','gsDPSetPrimColor(0,0,255,255,255,255),','gsDPSetTextureFilter(G_TF_BILERP),']+commands+['gsSPEndDisplayList(),','};']
for i,b in enumerate(m['bones']):
 children=[j for j,x in enumerate(m['bones']) if x['parent']==i];siblings=[j for j,x in enumerate(m['bones']) if x['parent']==b['parent']];sib=siblings[siblings.index(i)+1] if siblings.index(i)+1<len(siblings) else 255
 lines+=['static StandardLimb gBowlingSageLimb%d={{%d,%d,%d},%d,%d,%s};'%tuple([i]+b['position']+[children[0] if children else 255,sib,'gBowlingSageBodyDL' if i==n-1 else 'gBowlingSageEmptyDL'])]
lines+=['static void* gBowlingSageLimbs[]={'+','.join('&gBowlingSageLimb%d'%i for i in range(n))+'};','FlexSkeletonHeader gBowlingSageSkel={{gBowlingSageLimbs,%d},%d};'%(n,n)]
for name,label in [('Idle','idle'),('Raise','raise'),('Hold','hold'),('Seal','seal'),('SitDown','sit_down'),('SitUp','sit_up'),('SitIdle','sit_idle')]:
 frames=m['animations'][label];channels=[[p['root'][k] for p in frames] for k in range(3)]+[[p['rotation'][b][k] for p in frames] for b in range(n) for k in range(3)];constants=[]
 for ch in channels:
  if len(set(ch))==1 and ch[0]%65536 not in constants:constants.append(ch[0]%65536)
 data=list(constants);indices=[]
 for ch in channels:
  if len(set(ch))==1:indices.append(constants.index(ch[0]%65536))
  else:indices.append(len(data));data.extend(x%65536 for x in ch)
 lines+=['static s16 gBowlingSage%sFrames[]={%s};'%(name,','.join('0x%04X'%v for v in data)),'static JointIndex gBowlingSage%sJoints[]={'%name];lines+=['{%d,%d,%d},'%tuple(indices[i:i+3]) for i in range(0,len(indices),3)];lines+=['};','AnimationHeader gBowlingSage%sAnim={{%d},gBowlingSage%sFrames,gBowlingSage%sJoints,%d};'%(name,len(frames),name,name,len(constants))]
(A/'bowling_sage_model.inc.c').write_text('\n'.join(lines)+'\n')
p=A/'object_sa.c';p.write_text(original(p)+'\n#include "bowling_sage_model.inc.c"\n');p=A/'object_sa.h';p.write_text(original(p)+'\nextern FlexSkeletonHeader gBowlingSageSkel;\nextern AnimationHeader gBowlingSageIdleAnim;\nextern AnimationHeader gBowlingSageRaiseAnim;\nextern AnimationHeader gBowlingSageHoldAnim;\nextern AnimationHeader gBowlingSageSealAnim;\nextern AnimationHeader gBowlingSageSitDownAnim;\nextern AnimationHeader gBowlingSageSitUpAnim;\nextern AnimationHeader gBowlingSageSitIdleAnim;\n')
p=O/'src/overlays/actors/ovl_Demo_Sa/z_demo_sa.c';s=original(p)
HELPER = """/* This replacement belongs only to the first German forest-sage reveal. */
static s32 DemoSa_IsBowlingSage(DemoSa* this, PlayState* play) {
    return gSaveContext.language == LANGUAGE_GER &&
           ((play->sceneId == SCENE_CHAMBER_OF_THE_SAGES && this->actor.params == 0 &&
             gSaveContext.chamberCutsceneNum == CHAMBER_CS_FOREST) || this->actor.params == 2 || this->actor.params == 4);
}

static s32 DemoSa_UsesBowlingModel(DemoSa* this) {
    FlexSkeletonHeader* header = SEGMENTED_TO_VIRTUAL(&gBowlingSageSkel);
    return this->skelAnime.skeleton == SEGMENTED_TO_VIRTUAL(header->sh.segment);
}

"""
marker='void DemoSa_InitChamberOfSages(DemoSa* this, PlayState* play) {'
assert s.count(marker)==1;s=s.replace(marker,HELPER+marker)
old='    SkelAnime_InitFlex(play, &this->skelAnime, &gSariaSkel, &gSariaWaitArmsToSideAnim, NULL, NULL, 0);'
new='    SkelAnime_InitFlex(play, &this->skelAnime,\n                       DemoSa_IsBowlingSage(this, play) ? &gBowlingSageSkel : &gSariaSkel,\n                       DemoSa_IsBowlingSage(this, play) ? &gBowlingSageIdleAnim : &gSariaWaitArmsToSideAnim,\n                       NULL, NULL, 0);'
assert s.count(old)==2;s=s.replace(old,new,1)
# These native animation references occur only in the forest-medallion cue routines.
for old,new in [('gSariaGiveForestMedallionAnim','gBowlingSageRaiseAnim'),('gSariaGiveForestMedallionStandAnim','gBowlingSageHoldAnim')]:
    needle='&'+old;assert s.count(needle)==2
    s=s.replace(needle,'(DemoSa_UsesBowlingModel(this) ? &'+new+' : &'+old+')')
needle='                          DemoSa_OverrideLimbDraw, NULL, &this->actor);'
assert s.count(needle)==1;s=s.replace(needle,'                          DemoSa_IsBowlingSage(this, play) ? NULL : DemoSa_OverrideLimbDraw, NULL, &this->actor);')
# Sealing/trial role and the credits use the same character, with own motion.
needle='    SkelAnime_InitFlex(play, skelAnime, &gSariaSkel, NULL, NULL, NULL, 0);'
assert s.count(needle)==1;s=s.replace(needle,'    SkelAnime_InitFlex(play, skelAnime, DemoSa_IsBowlingSage(this, play) ? &gBowlingSageSkel : &gSariaSkel, NULL, NULL, NULL, 0);')
needle='    SkelAnime_InitFlex(play, &this->skelAnime, &gSariaSkel, &gSariaSitting3Anim, NULL, NULL, 0);'
assert s.count(needle)==1;s=s.replace(needle,'    SkelAnime_InitFlex(play, &this->skelAnime, DemoSa_IsBowlingSage(this, play) ? &gBowlingSageSkel : &gSariaSkel, DemoSa_IsBowlingSage(this, play) ? &gBowlingSageSitIdleAnim : &gSariaSitting3Anim, NULL, NULL, 0);')
for old,new in [('gSariaSealGanonAnim','gBowlingSageSealAnim'),('gSariaSitting1Anim','gBowlingSageSitDownAnim'),('gSariaSitting2Anim','gBowlingSageSitUpAnim'),('gSariaSitting3Anim','gBowlingSageSitIdleAnim')]:
 # Do not nest the ternary in the special initializer above.
 needle='&'+old
 if old=='gSariaSitting3Anim':
  needle='DemoSa_AnimationChange(this, &'+old
  assert s.count(needle)==1;s=s.replace(needle,'DemoSa_AnimationChange(this, (DemoSa_UsesBowlingModel(this) ? &'+new+' : &'+old+')')
 elif old=='gSariaSealGanonAnim':
  # Initial frameCount is queried before the skeleton is initialized.
  s=s.replace('Animation_GetLastFrame(&'+old+')','Animation_GetLastFrame(DemoSa_IsBowlingSage(this, play) ? &'+new+' : &'+old+')')
  s=s.replace('Animation_Change(skelAnime, &'+old+',','Animation_Change(skelAnime, (DemoSa_UsesBowlingModel(this) ? &'+new+' : &'+old+'),')
 else:s=s.replace(needle,'(DemoSa_UsesBowlingModel(this) ? &'+new+' : &'+old+')')
# Private camera scripts keep the adult figure in frame; all native cues and times stay intact.
cs_path=O/'src/overlays/actors/ovl_Demo_Sa/bowling_sage_cutscene_data.inc.c'
cs_path.write_bytes((ROOT/'bowling_sage_cutscene_data.inc.c').read_bytes())
needle='#include "z_demo_sa_cutscene_data.inc.c"'
assert s.count(needle)==1;s=s.replace(needle,needle+'\n#include "bowling_sage_cutscene_data.inc.c"')
needle='        play->csCtx.script = gForestMedallionCs;'
assert s.count(needle)==1;s=s.replace(needle,'        play->csCtx.script = DemoSa_IsBowlingSage(this, play) ? gBowlingForestMedallionCs : gForestMedallionCs;')
needle='void DemoSa_InitCredits(DemoSa* this, PlayState* play) {'
assert s.count(needle)==1;s=s.replace(needle,needle+'\n    if (DemoSa_IsBowlingSage(this, play)) {\n        play->csCtx.script = gBowlingCreditsCs;\n    }')
p.write_text(s)
# The later all-sage room layers also load Habeck and need their own measured budget.
p=O/'src/code/z_scene.c';s=original(p)
old='    } else if (play2->sceneId == SCENE_CHAMBER_OF_THE_SAGES) {\n        spaceSize = 1050 * 1024 - OBJECT_SPACE_ADJUSTMENT;'
new='    } else if (play2->sceneId == SCENE_CHAMBER_OF_THE_SAGES) {\n        spaceSize = (gSaveContext.sceneLayer >= 5 ? 1226 : 1050) * 1024 - OBJECT_SPACE_ADJUSTMENT;'
assert s.count(old)==1;p.write_text(s.replace(old,new))
print('Bowling sage:',len(m['triangles']),'triangles,',n,'own bones; German sage roles; original child/bridge Saria untouched, native cues/medallion preserved.')

/* Own proportions, fixed unit-scale head/arm pivots. No native Goron limb lengths. */
static Gfx* WallaceAdult_Draw(Actor* actor, PlayState* play, Gfx* gfx, Gfx* displayList, f32 arm, f32 head) {
    static Vec3f pivots[] = { {0,12,0}, {0,8589,0}, {1001,8446,0}, {-1001,8446,0} };
    Mtx* matrices = GRAPH_ALLOC(play->state.gfxCtx, sizeof(Mtx) * 4);
    s32 i;
    f32 idle = Math_SinS((s16)(play->gameplayFrames * 470));
    if (matrices == NULL) return gfx;
    Matrix_Push();
    Matrix_Translate(actor->world.pos.x, actor->world.pos.y + actor->shape.yOffset * 0.01f, actor->world.pos.z, MTXMODE_NEW);
    Matrix_RotateY(actor->shape.rot.y * (3.14159265358979323846f / 32768.0f), MTXMODE_APPLY);
    Matrix_Scale(0.01f, 0.01f, 0.01f, MTXMODE_APPLY);
    for (i = 0; i < 4; i++) {
        Matrix_Push();
        Matrix_Translate(pivots[i].x, pivots[i].y, pivots[i].z, MTXMODE_APPLY);
        if (i == 1) Matrix_RotateX(head + idle * 0.015f, MTXMODE_APPLY);
        if (i > 1) Matrix_RotateZ((arm + idle * 0.015f) * (i == 2 ? 1 : -1), MTXMODE_APPLY);
        Matrix_Translate(-pivots[i].x, -pivots[i].y, -pivots[i].z, MTXMODE_APPLY);
        MATRIX_TO_MTX(&matrices[i], "wallace adult", 1);
        Matrix_Pop();
    }
    Matrix_Pop();
    gSPSegment(gfx++, 0x0D, matrices);
    gSPDisplayList(gfx++, displayList);
    gSPSegment(gfx++, 0x0D, OS_PHYSICAL_TO_K0(gSegments[13]));
    return gfx;
}

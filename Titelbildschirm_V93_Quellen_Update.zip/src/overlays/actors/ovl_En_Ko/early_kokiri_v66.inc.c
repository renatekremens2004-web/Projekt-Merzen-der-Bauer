#include "fast_run_v66.h"
#include "effect.h"
#include "assets/objects/object_oE9/object_oE9.h"
static s32 EnKo_IsEarlyV66(Actor* a){return (u16)a->params==0x7E00;}
static void EnKo_UpdateEarlyV66(EnKo* this,PlayState* play) {
    Player* player=GET_PLAYER(play);
    if(this->actionFunc==func_80A99048){
        func_80A99048(this,play);
        if(this->actionFunc!=func_80A99048){
            gSegments[6]=OS_K0_TO_PHYSICAL(play->objectCtx.slots[this->osAnimeObjectSlot].segment);
            this->modelAlpha=255;this->appearDist=1200;this->blinkTimer=0;this->interactInfo.talkState=0;
            Animation_ChangeByInfo(&this->skelAnime,sAnimationInfo,gSaveContext.gameMode==GAMEMODE_END_CREDITS?ENKO_ANIM_STANDING_RIGHT_ARM_UP:ENKO_ANIM_STANDING);
        }
        return;
    }
    this->modelAlpha=255;
    gSegments[6]=OS_K0_TO_PHYSICAL(play->objectCtx.slots[this->osAnimeObjectSlot].segment);
    SkelAnime_Update(&this->skelAnime);
    Actor_UpdateBgCheckInfo(play,&this->actor,0,0,0,UPDBGCHECKINFO_FLAG_2);
    if(this->actor.floorHeight>BGCHECK_Y_MIN+10)this->actor.world.pos.y=this->actor.floorHeight;
    if (gSaveContext.gameMode==GAMEMODE_END_CREDITS || TitleMontage_IsActiveV92()) {
        this->actor.flags &= ~(ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_FRIENDLY);
        return;
    }
    if (LINK_IS_ADULT) {
        this->actor.textId=0x7235;
        if (Actor_TalkOfferAccepted(&this->actor,play)) this->interactInfo.talkState=1;
        if (this->interactInfo.talkState && Message_GetState(&play->msgCtx)==TEXT_STATE_CLOSING)
            this->interactInfo.talkState=0;
        if (!this->interactInfo.talkState) Actor_OfferTalk(&this->actor,play,100);
    } else {
    this->actor.textId=FAST_RUN_UNLOCKED()?0x7232:0x7231;
    if(this->blinkTimer>0){
        Vec3f p=player->actor.world.pos,v={0,.9f,0},a={0,.015f,0};
        Color_RGBA8 prim={180,255,220,255},env={30,90,60,0};
        s16 angle=this->blinkTimer*7000;
        if(this->blinkTimer%2==0){p.x+=Math_SinS(angle)*28;p.z+=Math_CosS(angle)*28;p.y+=12+(45-this->blinkTimer)*.9f;
            EffectSsKiraKira_SpawnDispersed(play,&p,&v,&a,&prim,&env,1000,18);}
        if(--this->blinkTimer==0){
            SET_INFTABLE(FAST_RUN_UNLOCK_FLAG);CLEAR_INFTABLE(FAST_RUN_ACTIVE_FLAG);
            Animation_ChangeByInfo(&this->skelAnime,sAnimationInfo,ENKO_ANIM_STANDING);
            Sfx_PlaySfxCentered(NA_SE_SY_CORRECT_CHIME);Message_StartTextbox(play,0x7233,&this->actor);
        }
    }else{
        if(Actor_TalkOfferAccepted(&this->actor,play))this->interactInfo.talkState=1;
        if(this->interactInfo.talkState&&Message_GetState(&play->msgCtx)==TEXT_STATE_CLOSING){
            this->interactInfo.talkState=0;
            if(!FAST_RUN_UNLOCKED()){
                this->blinkTimer=45;player->actor.freezeTimer=45;
                Animation_ChangeByInfo(&this->skelAnime,sAnimationInfo,ENKO_ANIM_STANDING_RIGHT_ARM_UP);
                Actor_PlaySfx(&this->actor,NA_SE_EV_GREAT_FAIRY_APPEAR);
            }
        }
        if(!this->interactInfo.talkState)Actor_OfferTalk(&this->actor,play,100);
    }
    }
    if(this->actor.xzDistToPlayer<180)Math_SmoothStepToS(&this->actor.shape.rot.y,this->actor.yawTowardsPlayer,4,600,0);
    Collider_UpdateCylinder(&this->actor,&this->collider);CollisionCheck_SetOC(play,&play->colChkCtx,&this->collider.base);
}

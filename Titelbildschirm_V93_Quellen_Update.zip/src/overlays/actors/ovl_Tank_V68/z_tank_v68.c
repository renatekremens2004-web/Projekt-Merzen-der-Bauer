#include "title_montage_v92.h"
#include "ultra64.h"
#include "actor.h"
#include "play_state.h"
#include "player.h"
#include "object.h"
#include "gfx.h"
#include "gfx_setupdl.h"
#include "segmented_address.h"
#include "sys_matrix.h"
#include "z_lib.h"
#include "save.h"
typedef struct TankV68 { Actor actor; ColliderCylinder wallaceCollider; u8 tankCollidersReady; } TankV68;
static ColliderCylinderInit sWallaceCylinderInit = {
 {COL_MATERIAL_NONE,AT_NONE,AC_NONE,OC1_ON|OC1_TYPE_ALL,OC2_TYPE_1,COLSHAPE_CYLINDER},
 {ELEM_MATERIAL_UNK0,{0,HIT_SPECIAL_EFFECT_NONE,0},{0,HIT_BACKLASH_NONE,0},ATELEM_NONE,ACELEM_NONE,OCELEM_ON},
 {80,65,0,{0,0,0}}
};
static void* TankV68_RoomSegment(Actor* actor, PlayState* play) {
 if(actor->room==play->roomCtx.curRoom.num)return play->roomCtx.curRoom.segment;
 if(actor->room==play->roomCtx.prevRoom.num)return play->roomCtx.prevRoom.segment;
 return NULL;
}
static void TankV68_TankCollisionV42(TankV68* this, PlayState* play) {
    if (!this->tankCollidersReady) return;
    Collider_UpdateCylinder(&this->actor,&this->wallaceCollider);
    CollisionCheck_SetOC(play,&play->colChkCtx,&this->wallaceCollider.base);
}
static void TankV68_InitTankCollisionV42(TankV68* this,PlayState* play) {
    if (gSaveContext.gameMode!=GAMEMODE_NORMAL) return;
    this->actor.colChkInfo.mass=MASS_IMMOVABLE;
    Collider_InitCylinder(play,&this->wallaceCollider);
    Collider_SetCylinder(play,&this->wallaceCollider,&this->actor,&sWallaceCylinderInit);
    this->wallaceCollider.dim.radius=80;
    this->wallaceCollider.dim.height=65;
    this->tankCollidersReady=true;
}

extern Gfx gTankGreenV42DL[];
extern Gfx gKakarikoTankV42DL[];
extern Gfx gTankV40DL[];
static s32 TankV68_IsTankV40(Actor* actor) {
    return (u16)actor->params>=0x7FA0 && (u16)actor->params<=0x7FA9;
}
static void TankV68_DrawTankV40(Actor* actor,PlayState* play) {
    s32 village=(u16)actor->params==0x7FA8;
    s32 green=(u16)actor->params==0x7FA9;
    s32 slot=village?-1:Object_GetSlot(&play->objectCtx,green?OBJECT_TANK_GREEN_V42:OBJECT_TANK_V40);
    void* segment=village?TankV68_RoomSegment(actor,play):NULL;
    if (village ? segment==NULL : (slot<0 || !Object_IsLoaded(&play->objectCtx,slot))) return;
    OPEN_DISPS(play->state.gfxCtx,"tank_v40",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    if (village) { gSPSegment(POLY_OPA_DISP++,3,segment); }
    else { gSPSegment(POLY_OPA_DISP++,6,play->objectCtx.slots[slot].segment); }
    Matrix_RotateX(BINANG_TO_RAD(actor->home.rot.x),MTXMODE_APPLY);
    Matrix_RotateZ(BINANG_TO_RAD(actor->home.rot.z),MTXMODE_APPLY);
    gSPMatrix(POLY_OPA_DISP++,MATRIX_FINALIZE(play->state.gfxCtx,"tank_v40",2),G_MTX_LOAD|G_MTX_MODELVIEW|G_MTX_NOPUSH);
    gSPDisplayList(POLY_OPA_DISP++,village?gKakarikoTankV42DL:(green?gTankGreenV42DL:gTankV40DL));
    if (village) gSPSegment(POLY_OPA_DISP++,3,OS_PHYSICAL_TO_K0(gSegments[3]));
    gSPSegment(POLY_OPA_DISP++,6,OS_PHYSICAL_TO_K0(gSegments[6]));
    CLOSE_DISPS(play->state.gfxCtx,"tank_v40",3);
}
static void TankV68_UpdateTankV40(Actor* actor,PlayState* play) {
    s32 slot=(u16)actor->params==0x7FA8?-1:Object_GetSlot(&play->objectCtx,(u16)actor->params==0x7FA9?OBJECT_TANK_GREEN_V42:OBJECT_TANK_V40);
    TankV68_TankCollisionV42((TankV68*)actor,play);
    if (slot>=0 && Object_IsLoaded(&play->objectCtx,slot)) {
        actor->objectSlot=slot;
        Actor_SetObjectDependency(play,actor);
    }
}
static void TankV68_InitTankV40(Actor* actor,PlayState* play) {
    s32 index=(u16)actor->params-0x7FA0;
    s32 credit=index==7 && play->sceneId==SCENE_GERUDO_VALLEY && gSaveContext.gameMode==GAMEMODE_END_CREDITS && gSaveContext.sceneLayer==6;
    s32 normal=(index<3 && play->sceneId==SCENE_DEATH_MOUNTAIN_TRAIL) ||
        (index>=3 && index<5 && play->sceneId==SCENE_GERUDO_VALLEY) ||
        (index>=5 && index<7 && play->sceneId==SCENE_HYRULE_FIELD) ||
        (index==8 && play->sceneId==SCENE_KAKARIKO_VILLAGE) ||
        (index==9 && play->sceneId==SCENE_LOST_WOODS && actor->room==6);
    ((TankV68*)actor)->tankCollidersReady=false;
    if(!TankV68_IsTankV40(actor)){Actor_Kill(actor);return;}
    if (!TitleMontage_IsActiveV92() && !credit && (!normal || LINK_IS_CHILD || gSaveContext.gameMode!=GAMEMODE_NORMAL)) {
        Actor_Kill(actor);return;
    }
    actor->flags=ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    actor->shape.rot.x=actor->shape.rot.z=0;
    Actor_SetScale(actor,.01f);
    actor->cullingVolumeDistance=4500.0f;
    actor->cullingVolumeScale=330.0f;
    actor->cullingVolumeDownward=200.0f;
    actor->draw=TankV68_DrawTankV40;
    TankV68_InitTankCollisionV42((TankV68*)actor,play);
    TankV68_UpdateTankV40(actor,play);
}


static void TankV68_Destroy(Actor* a, PlayState* play) {
 TankV68* t=(TankV68*)a;
 if(t->tankCollidersReady)Collider_DestroyCylinder(play,&t->wallaceCollider);
}
ActorProfile Tank_V68_Profile = {
 ACTOR_TANK_V68, ACTORCAT_BG, ACTOR_FLAG_UPDATE_CULLING_DISABLED,
 OBJECT_GAMEPLAY_KEEP, sizeof(TankV68), TankV68_InitTankV40,
 TankV68_Destroy, TankV68_UpdateTankV40, TankV68_DrawTankV40,
};

/* One resident title scene; all placements and runner logic are title-only. */
#include "cutscene_commands.h"
#include "audio.h"
#include "environment.h"
static u8 sTitleEnabledV92;
static u8 sTitleBackgroundV92;
static u8 sTitleShotV92 = 4;
static s8 sTitlePendingV92 = -1;
static ActorEntry sTitleActorsV92[16];
static s16 sTitleObjectsV92[]={OBJECT_MAG,OBJECT_TITLE_MAUZI_V93,OBJECT_TANK_V40,OBJECT_OS_ANIME,OBJECT_KM1,OBJECT_OE9,OBJECT_OF1D_MAP,OBJECT_GORON_SOLDIERS_V39,OBJECT_SPECIAL_SOLDIERS_V57};
static CutsceneData sTitleCameraV93[]={
CS_HEADER(4, 1800),
CS_MISC_LIST(1),
 CS_MISC(CS_MISC_SET_CSFLAG_3,1,2,0,0,0,0,0,0,0,0,0,0,0),
CS_CAM_EYE_SPLINE(0, 1780),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,245,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,245,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,195,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,130,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,100,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,100,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,0,CS_FLOAT(0x425C0000,55.0f),1286,100,-300,0),
 CS_CAM_POINT(CS_CAM_STOP,0,0,CS_FLOAT(0x425C0000,55.0f),1286,100,-300,0),
CS_CAM_AT_SPLINE(0,1780),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,90,CS_FLOAT(0x425C0000,55.0f),600,370,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,90,CS_FLOAT(0x425C0000,55.0f),600,370,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,90,CS_FLOAT(0x425C0000,55.0f),600,320,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,90,CS_FLOAT(0x425C0000,55.0f),600,255,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,90,CS_FLOAT(0x425C0000,55.0f),600,225,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,90,CS_FLOAT(0x425C0000,55.0f),600,225,-300,0),
 CS_CAM_POINT(CS_CAM_CONTINUE,0,90,CS_FLOAT(0x425C0000,55.0f),600,225,-300,0),
 CS_CAM_POINT(CS_CAM_STOP,0,90,CS_FLOAT(0x425C0000,55.0f),600,225,-300,0),
CS_DESTINATION(CS_DEST_TITLE_SCREEN_DEMO,1600,1601),
CS_END_OF_SCRIPT(),
};
/* En_Mag changes mode before the outgoing title actors have been destroyed. */
s32 TitleMontage_IsActiveV92(void){return (gSaveContext.gameMode==GAMEMODE_TITLE_SCREEN||gSaveContext.gameMode==GAMEMODE_FILE_SELECT)&&sTitleEnabledV92&&sTitleBackgroundV92;}
s32 TitleMontage_ShotV92(void){return sTitleShotV92;}
s32 TitleMontage_LayerV92(void){return SCENE_LAYER_ADULT_DAY;}
void* TitleMontage_ScriptV92(void){return sTitleCameraV93;}
static void TitleMontage_TimeV92(void){
 gSaveContext.save.linkAge=LINK_AGE_ADULT;
 gSaveContext.save.dayTime=gSaveContext.skyboxTime=CLOCK_TIME(12,0);
 gSaveContext.save.nightFlag=false;gSaveContext.nextDayTime=NEXT_TIME_NONE;
 gSaveContext.forceRisingButtonAlphas=true;
}
void TitleMontage_StartV92(void){
 sTitleEnabledV92=true;sTitleBackgroundV92=true;sTitleShotV92=4;sTitlePendingV92=-1;
 gSaveContext.save.entranceIndex=ENTR_GERUDO_VALLEY_0;TitleMontage_TimeV92();
}
void TitleMontage_BeginSceneV92(void){
 if(gSaveContext.gameMode!=GAMEMODE_TITLE_SCREEN||!sTitleEnabledV92)return;
 if(sTitlePendingV92>=0){sTitleBackgroundV92=sTitlePendingV92;sTitlePendingV92=-1;if(sTitleBackgroundV92)TitleMontage_TimeV92();}
 if(sTitleBackgroundV92)gSaveContext.showTitleCard=false;
}
s32 TitleMontage_ReturnV92(PlayState* play){
 if(gSaveContext.gameMode!=GAMEMODE_TITLE_SCREEN||!sTitleEnabledV92)return false;
 sTitlePendingV92=1;play->nextEntranceIndex=ENTR_GERUDO_VALLEY_0;
 gSaveContext.save.cutsceneIndex=CS_INDEX_0;play->transitionTrigger=TRANS_TRIGGER_START;
 play->transitionType=gSaveContext.nextTransitionType=TRANS_TYPE_FADE_BLACK;return true;
}
s32 TitleMontage_AdvanceV92(PlayState* play){
 if(!TitleMontage_IsActiveV92())return false;
 sTitlePendingV92=0;return false; /* Original rotating attract-demo destination. */
}
static void TitleMontage_PlayerIdleV92(UNUSED Actor* actor,UNUSED PlayState* play){}
void TitleMontage_UpdateV92(PlayState* play){
 Player* player;s32 f;
 if(!TitleMontage_IsActiveV92())return;
 play->csCtx.script=TitleMontage_ScriptV92();
 play->actorCtx.titleCtx.durationTimer=0;play->actorCtx.titleCtx.delayTimer=0;play->actorCtx.titleCtx.alpha=0;
 f=CLAMP(play->csCtx.curFrame,0,1600);
 gSaveContext.save.dayTime=gSaveContext.skyboxTime=(u16)(CLOCK_TIME(12,0)+(f*65536)/1600);
 gSaveContext.save.nightFlag=gSaveContext.save.dayTime>CLOCK_TIME(18,0)||gSaveContext.save.dayTime<CLOCK_TIME(6,30);
 player=GET_PLAYER(play);
 if(player!=NULL){player->actor.draw=NULL;player->actor.update=TitleMontage_PlayerIdleV92;player->actor.shape.shadowDraw=NULL;}
}
s16* TitleMontage_ObjectsV92(s32* count){*count=ARRAY_COUNT(sTitleObjectsV92);return sTitleObjectsV92;}
u32 TitleMontage_ObjectSpaceV92(void){
 s32 count,i;u32 size=0,extra;s16* list=TitleMontage_ObjectsV92(&count);
 s16 keep[]={OBJECT_GAMEPLAY_KEEP,OBJECT_GAMEPLAY_FIELD_KEEP,OBJECT_LINK_BOY};
 for(i=0;i<3;i++){extra=gObjectTable[keep[i]].vromEnd-gObjectTable[keep[i]].vromStart;size+=ALIGN16(extra);}
 for(i=0;i<count;i++){extra=gObjectTable[list[i]].vromEnd-gObjectTable[list[i]].vromStart;size+=ALIGN16(extra);}
 return ALIGN16(size+32*1024);
}
void TitleMontage_ActorsV92(PlayState* play){
 static s16 roles[]={0x7F67,0x7F6E,0x7F70,0x7F71};
 s32 i,n=0;ActorEntry* src=play->actorEntryList;ActorEntry a;
 for(i=0;i<play->numActorEntries&&n<8;i++){
  /* Title stage supplies its own props; no tent or unused bridge actor/model bank. */
 }
 a.id=ACTOR_TANK_V68;a.params=0x7FA7;
 a.pos.x=-1200;a.pos.y=15;a.pos.z=-600;a.rot.x=0;a.rot.y=4000;a.rot.z=0;sTitleActorsV92[n++]=a;
 a.pos.x=-1550;a.pos.y=52;a.pos.z=-300;a.rot.x=-880;a.rot.y=-2000;a.rot.z=-1360;sTitleActorsV92[n++]=a;
 a.pos.x=-1700;a.pos.y=40;a.pos.z=-850;a.rot.x=1149;a.rot.y=14000;a.rot.z=-927;sTitleActorsV92[n++]=a;
 a.pos.x=a.pos.y=a.pos.z=0;a.rot.x=a.rot.y=a.rot.z=0;a.params=0;a.id=ACTOR_EN_MAG;sTitleActorsV92[n++]=a;
 a.id=ACTOR_ELF_MSG2;a.params=0x7F50;a.pos.x=940;a.pos.y=39;a.pos.z=-400;a.rot.y=-16384;sTitleActorsV92[n++]=a;
 a.id=ACTOR_EN_KO;a.params=0x7E00;a.pos.z=-200;sTitleActorsV92[n++]=a;
 for(i=0;i<4;i++){a.id=ACTOR_EN_GO2;a.params=roles[i];a.pos.x=600-i*25;a.pos.y=50;a.pos.z=-800+i*300;sTitleActorsV92[n++]=a;}
 play->actorEntryList=sTitleActorsV92;play->numActorEntries=n;
}

#ifndef TITLE_MONTAGE_V92_H
#define TITLE_MONTAGE_V92_H
#include "ultra64.h"
struct PlayState;
s32 TitleMontage_IsActiveV92(void);
s32 TitleMontage_LayerV92(void);
s32 TitleMontage_ShotV92(void);
void TitleMontage_StartV92(void);
void TitleMontage_BeginSceneV92(void);
s32 TitleMontage_ReturnV92(struct PlayState* play);
s32 TitleMontage_AdvanceV92(struct PlayState* play);
void TitleMontage_UpdateV92(struct PlayState* play);
u32 TitleMontage_ObjectSpaceV92(void);
s16* TitleMontage_ObjectsV92(s32* count);
void TitleMontage_ActorsV92(struct PlayState* play);
void* TitleMontage_ScriptV92(void);
#endif

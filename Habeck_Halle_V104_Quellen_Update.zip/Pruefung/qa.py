from pathlib import Path
import sys,json,subprocess,os,re,struct,runpy
W=Path(__file__).resolve().parent;rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1])
if (W/'qa-case.txt').exists()and(W/'qa-case.txt').read_text().strip()=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit()
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned began=0,seen=0,sawno=0,seenquestion=0,lastid=0,returned=0;
static unsigned bit(unsigned id){switch(id){case 0x704e:return 1;case 0x704f:return 2;case 0x121:return 4;case 0x122:return 8;case 0x123:return 16;case 0x7050:return 32;case 0x7051:return 64;case 0x7053:return 128;case 0x40:return 256;case 0x7212:return 512;case 0x7213:return 1024;case 0x7214:return 2048;case 0x7215:return 4096;case 0x70e9:return 8192;default:return 0;}}
static void onframe(unsigned f){
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 unsigned scene=DebugMemRead16(play+0xa4),cs=DebugMemRead16(play+0x1d74),m=play+0x20d8,id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304);
 if(f%200==0)printf("HALL f=%u scene=%x cs=%u id=%04x mode=%x seen=%x sun=%x\n",f,scene,cs,id,mode,seen,DebugMemRead16(savebase+0xf30));
 if(scene==0x44){
  if(!began){began=1;bank();}
  if(id&&mode&&id!=lastid){printf("HALL_TEXT %04X len=%u\n",id,r32(m+0xe300));lastid=id;}
  if(mode){seen|=bit(id);if(id==0x7052)sawno=1;}
  if(id==0x7051&&mode==0x35&&DebugMemRead8(m+0xe3e6)==2){seenquestion=1;DebugMemWrite8(m+0xe3e5,REPEAT_TEST&&!sawno?1:0);}
  need(r32(m+0xe300)<0x500,"whole message stays inside native text buffer");need(DebugMemRead16(m+0xe3d4)<=200,"decoded page fits native buffer");
  if(id==0x7212&&mode){need(seen&256,"medallion message precedes replay");need(r32(savebase+0xa4)&0x20,"light medallion awarded before replay");need(!(DebugMemRead16(savebase+0xf30)&0x2000),"light tunic not awarded before second animation");}
  if(id==0x7213&&mode)need(seen&512,"light tunic follows replay announcement");
  if(id==0x7214&&mode)need(seen&1024,"frog announcement follows tunic");
  if(id==0x7215&&mode)need(seen&2048,"frog follows third-animation announcement");
 }else if(began){
  if(!returned)returned=f;
  if(f>returned+80){need(scene==0x43,"native return to Temple of Time");need(seen==0x3fff,"all opening, linked and gift messages traversed");need(seenquestion&&(!REPEAT_TEST||sawno),"question and requested choice path works");need((DebugMemRead16(savebase+0xf30)&0x6000)==0x2000,"light tunic retained without shadow upgrade");need(r32(savebase+0xa4)&0x20,"light medallion retained");bank();puts("HABECK_HALL_NATIVE_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(buttons)buttons((f>450&&f%12<2&&(mode==0||mode==6||mode==7||mode==0x34||mode==0x35))?0x80:0);
 need(f<9000,"Habeck opening and return complete");
}
'''.replace('REPEAT_TEST',str(int(mode=='normal')))
c=W/f'probe-{mode}.c';c.write_text(base[:a]+body+base[b:]);exe=W/f'probe-{mode}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0x6b,0,0xfff0);q[0xed4:0xf34]=bytes(0x60);struct.pack_into('>I',q,0xa4,0);struct.pack_into('>i',q,0x1364,0);q[0x1409]=1;save=W/'hall.save';save.write_bytes(q)
with(W/f'qa-{mode}.log').open('w')as log:r=subprocess.run([str(exe),rom,f'habeck-hall-v104-direct-{mode}','9200','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH=str(W/(mode+'.pcm'))),stdout=log,stderr=subprocess.STDOUT,timeout=650)
log=(W/f'qa-{mode}.log').read_text();assert r.returncode==0 and'HABECK_HALL_NATIVE_PASSED'in log,(r.returncode,log[-2500:]);print('NATIVE_HABECK_HALL_VERIFIED',mode,flush=True)

"""Export the offline reduced/baked supplied Jabba, retaining own proportions."""
import bpy,json,sys,shutil
from pathlib import Path
from mathutils import Vector,Matrix
R=Path(__file__).resolve().parent.parent;W=Path(sys.argv[sys.argv.index('--')+1]);D=R/'models/jabba';D.mkdir(exist_ok=True,parents=True);bpy.ops.wm.open_mainfile(filepath=str(W/'baked.blend'),load_ui=False)
objects=[o for o in bpy.context.scene.objects if o.type=='MESH'];T=Matrix(((-1,0,0),(0,0,1),(0,1,0)));points=[o.matrix_world@v.co for o in objects for v in o.data.vertices];bottom=min(p.z for p in points);top=max(p.z for p in points);height=78;scale=height*100/(top-bottom);center=Vector((.25,0,bottom));pivots=[Vector((0,0,0)),T@(Vector((.25,.8,5.1))-center)]
for src,dst in [('JabbaBody.png','body.png'),('JabbaHead.png','head.png'),('input/textures/Sphere Base Color_1.png','eyes.png')]:shutil.copyfile(W/src,D/dst)
m=dict(bones=[dict(name=n,parent=-1,position=[round(x*scale)for x in p])for n,p in zip(['body','head'],pivots)],materials=[dict(name=n,texture=n+'.png',size=[64,64])for n in ['body','head','eyes']],vertices=[],triangles=[],height_game_units=height,uniform_scale=True,native_lighting=True,original_triangles=493466,color_bake='Original dense mesh diffuse colors baked onto separate reduced body/head UV atlases. Original eye UV retained.',source_sha256=__import__('hashlib').sha256((W/'input/source/jabba.glb').read_bytes()).hexdigest())
for o in objects:
 me=o.data;me.calc_loop_triangles();bone=0 if o.name=='JabbaBody'else 1;mat=0 if o.name=='JabbaBody'else 1 if o.name=='JabbaHead'else 2;off=len(m['vertices']);rot=T@o.matrix_world.to_3x3()
 for v in me.vertices:m['vertices'].append(dict(bone=bone,position=[round(x*scale)for x in T@(o.matrix_world@v.co-center)]))
 for t in me.loop_triangles:
  cs=[]
  for vi,li in zip(t.vertices,t.loops):cs.append(dict(vertex=off+vi,uv=list(me.uv_layers.active.data[li].uv),normal=[round(x*127)for x in (rot@me.vertices[vi].normal).normalized()]))
  m['triangles'].append(dict(material=mat,corners=cs))
(R/'tools/jabba_source.json').write_text(json.dumps(m,separators=(',',':'))+'\n');print('Jabba:',len(m['triangles']),'triangles, 2 own rigid groups, height',height,'bounds',[(min(v['position'][k]for v in m['vertices'])/100,max(v['position'][k]for v in m['vertices'])/100)for k in range(3)],'pivots',m['bones'])

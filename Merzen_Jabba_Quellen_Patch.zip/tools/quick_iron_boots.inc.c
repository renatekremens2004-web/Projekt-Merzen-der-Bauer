/* D-pad Down uses the same inventory/equipment path as the pause menu.
 * Called before native currentBoots/prevBoots processing, including swimming.
 */
static void Player_TryQuickIronBoots(Player* this, PlayState* play, Input* input) {
    s32 nextBoots;

    if (!CHECK_BTN_ALL(input->press.button, BTN_DDOWN) || !LINK_IS_ADULT ||
        !CHECK_OWNED_EQUIP(EQUIP_TYPE_BOOTS, EQUIP_INV_BOOTS_IRON) ||
        IS_PAUSED(&play->pauseCtx) || play->gameOverCtx.state != GAMEOVER_INACTIVE ||
        play->msgCtx.msgMode != MSGMODE_NONE || Player_InCsMode(play) ||
        play->transitionTrigger != TRANS_TRIGGER_OFF || play->transitionMode != TRANS_MODE_OFF ||
        (this->stateFlags1 & (PLAYER_STATE1_DEAD | PLAYER_STATE1_5 | PLAYER_STATE1_23 | PLAYER_STATE1_29))) {
        return;
    }

    nextBoots = CUR_EQUIP_VALUE(EQUIP_TYPE_BOOTS) == EQUIP_VALUE_BOOTS_IRON
                    ? EQUIP_VALUE_BOOTS_KOKIRI
                    : EQUIP_VALUE_BOOTS_IRON;
    Inventory_ChangeEquipment(EQUIP_TYPE_BOOTS, nextBoots);
    Player_SetEquipmentData(play, this);
    Sfx_PlaySfxCentered(NA_SE_SY_DECIDE);
    input->press.button &= ~BTN_DDOWN;
}

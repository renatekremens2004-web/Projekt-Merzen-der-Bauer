import bpy,bmesh,json,sys
from pathlib import Path
from mathutils import Matrix
W=Path(sys.argv[sys.argv.index('--')+1]);bpy.ops.wm.read_factory_settings(use_empty=True);bpy.ops.import_scene.gltf(filepath=str(W/'input/source/jabba.glb'));bpy.ops.wm.save_as_mainfile(filepath=str(W/'import.blend'));o=next(o for o in bpy.context.scene.objects if o.type=='MESH'and len(o.data.vertices)>10000);bpy.context.view_layer.objects.active=o;bpy.ops.object.select_all(action='DESELECT');o.select_set(True)
o.data.transform(o.matrix_world);o.matrix_world=Matrix.Identity(4)
# Dense source UV seams must not dictate the low-poly silhouette. Rebuild a
# closed evenly sampled surface; original diffuse colors are baked separately.
o.data.remesh_voxel_size=.085;o.data.remesh_voxel_adaptivity=0.;bpy.ops.object.voxel_remesh();o.data.calc_loop_triangles();before=len(o.data.loop_triangles);mod=o.modifiers.new('N64 silhouette budget','DECIMATE');mod.ratio=2200/before;bpy.ops.object.modifier_apply(modifier=mod.name)
for p in o.data.polygons:p.use_smooth=True
o.data.calc_loop_triangles();report=[dict(object=o.name,original=491546,voxel_triangles=before,after=len(o.data.loop_triangles),voxel_size=.085)]
for eye in list(bpy.context.scene.objects):
 if eye.type!='MESH'or eye==o:continue
 bpy.context.view_layer.objects.active=eye;eye.select_set(True);eye.data.transform(eye.matrix_world);eye.matrix_world=Matrix.Identity(4);eye.data.calc_loop_triangles();mod=eye.modifiers.new('Eye silhouette','DECIMATE');mod.ratio=.1;bpy.ops.object.modifier_apply(modifier=mod.name);eye.data.calc_loop_triangles();report.append(dict(object=eye.name,after=len(eye.data.loop_triangles)))
(W/'reduction.json').write_text(json.dumps(report,indent=2)+'\n');bpy.ops.wm.save_as_mainfile(filepath=str(W/'reduced.blend'));print(report)

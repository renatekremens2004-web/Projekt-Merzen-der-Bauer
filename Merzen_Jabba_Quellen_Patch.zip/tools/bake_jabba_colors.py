import bpy,bmesh,json,sys
from pathlib import Path
from mathutils import Matrix
W=Path(sys.argv[sys.argv.index('--')+1]);bpy.ops.wm.open_mainfile(filepath=str(W/'reduced.blend'),load_ui=False)
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.samples=1;scene.cycles.use_denoising=False
low=[o for o in scene.objects if o.type=='MESH'and not o.name.startswith('Sphere')]
bpy.ops.object.select_all(action='DESELECT')
for o in low:o.select_set(True)
bpy.context.view_layer.objects.active=low[0];bpy.ops.object.join();joined=bpy.context.object;joined.name='JabbaLow'
parts=[]
for label,upper in [('JabbaBody',False),('JabbaHead',True)]:
 o=joined.copy();o.data=joined.data.copy();o.name=label;scene.collection.objects.link(o);bm=bmesh.new();bm.from_mesh(o.data);remove=[f for f in bm.faces if (f.calc_center_median().z>5.1)!=upper];bmesh.ops.delete(bm,geom=remove,context='FACES');bm.to_mesh(o.data);bm.free();parts.append(o)
bpy.data.objects.remove(joined,do_unlink=True)
# Bring the untouched dense source into the same world coordinates for color-only baking.
with bpy.data.libraries.load(str(W/'import.blend'),link=False)as(src,dst):dst.objects=['Object_6']
high=dst.objects[0];scene.collection.objects.link(high);high.name='JabbaHigh';high.data.transform(high.matrix_world);high.matrix_world=Matrix.Identity(4)
scene.render.bake.use_selected_to_active=True;scene.render.bake.use_pass_direct=False;scene.render.bake.use_pass_indirect=False;scene.render.bake.use_pass_color=True;scene.render.bake.cage_extrusion=.12;scene.render.bake.max_ray_distance=.6;scene.render.bake.margin=12
for o in parts:
 bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
 bpy.ops.object.mode_set(mode='EDIT');bpy.ops.mesh.select_all(action='SELECT');bpy.ops.uv.smart_project(angle_limit=1.15,island_margin=.02);bpy.ops.object.mode_set(mode='OBJECT')
 # One target material so every low face writes into the one active image.
 image=bpy.data.images.new(o.name+'Baked',width=512,height=512,alpha=False);image.generated_color=(.25,.3,.12,1)
 mat=bpy.data.materials.new(o.name+'Mat');mat.use_nodes=True;node=mat.node_tree.nodes.new('ShaderNodeTexImage');node.image=image;mat.node_tree.nodes.active=node;o.data.materials.clear();o.data.materials.append(mat)
 for p in o.data.polygons:p.material_index=0
 high.select_set(True);bpy.context.view_layer.objects.active=o;bpy.ops.object.bake(type='DIFFUSE',use_selected_to_active=True,use_clear=True,cage_extrusion=.12,max_ray_distance=.6,pass_filter={'COLOR'});mat.node_tree.links.new(node.outputs['Color'],mat.node_tree.nodes.get('Principled BSDF').inputs['Base Color']);image.filepath_raw=str(W/(o.name+'.png'));image.file_format='PNG';image.save();high.select_set(False)
bpy.data.objects.remove(high,do_unlink=True);bpy.ops.wm.save_as_mainfile(filepath=str(W/'baked.blend'));print('Baked original colors onto separate head/body atlases.')

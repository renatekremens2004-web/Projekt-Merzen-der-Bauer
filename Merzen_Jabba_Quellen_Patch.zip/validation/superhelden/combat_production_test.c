#include "collision_check.h"
#include "actor.h"
#include "attributes.h"
#include "play_state.h"
s32 CollisionCheck_IsPlayerMasterSwordHit(ColliderElement* elem) {
    Actor* attacker;
    if (elem == NULL || elem->acHit == NULL || elem->acHitElem == NULL) return false;
    attacker = elem->acHit->actor;
    return attacker != NULL && (attacker->id == ACTOR_PLAYER || attacker->id == ACTOR_EN_M_THUNDER) &&
           (elem->acHitElem->atDmgInfo.dmgFlags & (DMG_SLASH_MASTER | DMG_SPIN_MASTER | DMG_JUMP_MASTER));
}
void CollisionCheck_ApplyDamage(UNUSED PlayState* play, UNUSED CollisionCheckContext* colChkCtx, Collider* col,
                                ColliderElement* elem) {
    DamageTable* tbl;
    f32 damage;

    if (col->actor == NULL || !(col->acFlags & AC_HIT)) {
        return;
    }
    if (!(elem->acElemFlags & ACELEM_HIT) || elem->acElemFlags & ACELEM_NO_DAMAGE) {
        return;
    }

    ASSERT(elem->acHitElem != NULL, "pclobj_elem->ac_hit_elem != NULL", "../z_collision_check.c", 6493);
    tbl = col->actor->colChkInfo.damageTable;
    if (tbl == NULL) {
        damage = (f32)elem->acHitElem->atDmgInfo.damage - elem->acDmgInfo.defense;
        if (damage < 0) {
            damage = 0;
        }
    } else {
        s32 i;
        u32 flags = elem->acHitElem->atDmgInfo.dmgFlags;

        for (i = 0; i < 32; i++, flags >>= 1) {
            if (flags == 1) {
                break;
            }
        }

        damage = tbl->table[i] & 0xF;
        col->actor->colChkInfo.damageReaction = tbl->table[i] >> 4 & 0xF;
    }
    if (!(col->acFlags & AC_HARD)) {
        if (damage > 0.0f && col->actor->category == ACTORCAT_ENEMY && col->actor->colChkInfo.health != 0 &&
            !(col->actor->id == ACTOR_EN_IK && (col->actor->params & 0xFF) == 0) &&
            CollisionCheck_IsPlayerMasterSwordHit(elem)) {
            /* Assign remaining HP, avoiding u8 overflow from multiple collider elements. */
            col->actor->colChkInfo.damage = col->actor->colChkInfo.health;
        } else {
            col->actor->colChkInfo.damage += damage;
        }
    }
}
u8 Actor_ApplyDamage(Actor* actor) {
    if (actor->colChkInfo.health <= actor->colChkInfo.damage) {
        actor->colChkInfo.health = 0;
    } else {
        actor->colChkInfo.health -= actor->colChkInfo.damage;
    }

    return actor->colChkInfo.health;
}
static Actor target, source;
static Collider ac, at;
static ColliderElement recv, send;
static DamageTable table;
static unsigned checks;
static void check(s32 condition) {
 checks++;
 if (!condition) { __asm__ volatile("syscall" : : "a"(60),"D"(checks) : "memory");for(;;); }
}
static void setup(u32 flags) {
 s32 i;
 for(i=0;i<32;i++)table.table[i]=0x32;
 target.id=ACTOR_EN_TEST;target.category=ACTORCAT_ENEMY;target.params=-1;
 target.colChkInfo.health=30;target.colChkInfo.damage=0;target.colChkInfo.damageReaction=0;
 target.colChkInfo.damageTable=&table;
 source.id=ACTOR_PLAYER;source.category=ACTORCAT_PLAYER;
 ac.actor=&target;ac.acFlags=AC_HIT;at.actor=&source;
 recv.acElemFlags=ACELEM_HIT;recv.acHit=&at;recv.acHitElem=&send;recv.acDmgInfo.defense=0;
 send.atDmgInfo.dmgFlags=flags;send.atDmgInfo.damage=2;
}
static void hit(void){CollisionCheck_ApplyDamage(0,0,&ac,&recv);}
void _start(void) {
 s32 i;u32 masters[]={DMG_SLASH_MASTER,DMG_SPIN_MASTER,DMG_JUMP_MASTER};
 for(i=0;i<3;i++) { setup(masters[i]);hit();check(target.colChkInfo.damage==30);check(target.colChkInfo.damageReaction==3);check(Actor_ApplyDamage(&target)==0); }
 setup(DMG_SLASH_MASTER);source.id=ACTOR_EN_TORCH2;hit();check(target.colChkInfo.damage==2);check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SPIN_MASTER);source.id=ACTOR_EN_M_THUNDER;hit();check(Actor_ApplyDamage(&target)==0);
 setup(DMG_SLASH_MASTER);target.category=ACTORCAT_BOSS;hit();check(target.colChkInfo.damage==2);check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_MASTER);target.category=ACTORCAT_NPC;hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_MASTER);target.id=ACTOR_EN_IK;target.params=0;hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_MASTER);target.id=ACTOR_EN_IK;target.params=2;hit();check(Actor_ApplyDamage(&target)==0);
 setup(DMG_ARROW_NORMAL);hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_KOKIRI);hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_GIANT);hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_MASTER);ac.acFlags|=AC_HARD;hit();check(target.colChkInfo.damage==0);check(Actor_ApplyDamage(&target)==30);
 setup(DMG_SLASH_MASTER);recv.acElemFlags|=ACELEM_NO_DAMAGE;hit();check(target.colChkInfo.damage==0);
 setup(DMG_SLASH_MASTER);table.table[9]=0x30;hit();check(target.colChkInfo.damage==0);
 setup(DMG_SLASH_MASTER);target.colChkInfo.health=200;hit();hit();check(target.colChkInfo.damage==200);check(Actor_ApplyDamage(&target)==0);
 setup(DMG_SLASH_MASTER);target.colChkInfo.damageTable=0;hit();check(Actor_ApplyDamage(&target)==0);
 setup(DMG_SLASH_MASTER);target.colChkInfo.damageTable=0;recv.acDmgInfo.defense=2;hit();check(Actor_ApplyDamage(&target)==30);
 setup(DMG_SLASH_MASTER);recv.acHit=0;check(!CollisionCheck_IsPlayerMasterSwordHit(&recv));
 check(!CollisionCheck_IsPlayerMasterSwordHit(0));
 { char out[12];s32 len=0;unsigned n=checks;do{out[len++]='0'+n%10;n/=10;}while(n);for(i=0;i<len/2;i++){char c=out[i];out[i]=out[len-1-i];out[len-1-i]=c;}out[len++]='\n';__asm__ volatile("syscall" : : "a"(1),"D"(1),"S"(out),"d"(len) : "memory"); }
 __asm__ volatile("syscall" : : "a"(60),"D"(0) : "memory");for(;;);
}

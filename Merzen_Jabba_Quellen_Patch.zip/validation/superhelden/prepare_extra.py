from pathlib import Path
import struct
W=Path('/workspace/fanboy-chumchum')
for key,pos,yaw in [('fanboy-view',(1470.,463.,-1470.),1200),('chumchum-view',(-1220.,383.,-1410.),-30000)]:
 src='fanboy'if key.startswith('fanboy')else'chumchum';b=bytearray((W/(src+'.save')).read_bytes());struct.pack_into('>fffh',b,0x1368,*pos,yaw);(W/(key+'.save')).write_bytes(b)
b=bytearray((W/'combat-stalfos.save').read_bytes());struct.pack_into('>III',b,0,0x82,0,0);struct.pack_into('>fffhHhB',b,0x1368,1425.,1003.,1473.,16384,0xdff,0x82,20);b[0xd4+6*0x1c:0xd4+7*0x1c]=bytes(0x1c);(W/'combat-iron.save').write_bytes(b)
struct.pack_into('>fffh',b,0x1368,1555.,1003.,1473.,-16384);(W/'combat-iron-close.save').write_bytes(b)

from pathlib import Path
import re,json,struct,subprocess
W=Path('/workspace/fanboy-chumchum');O=Path('/workspace/oot-burns-pal');mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16)for n in ['gSaveContext','gActorOverlayTable','gObjectTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms)+'\n')
s=Path('/workspace/pepsiman-water/runner.c').read_text();a=s.index(' if(play){',s.index('if(f%50==0)findplay();unsigned value=0;'));z=s.index('\n if(buttons)buttons(value);',a)
body=r''' if(play){
  uint32_t m=play+0x20d8;unsigned id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304),pos=DebugMemRead16(m+0xe3ce);
  static unsigned oldkey=0,age=0;unsigned key=id*1024+pos;
  if(key!=oldkey || (mode!=7 && mode!=0x34 && mode!=0x35)){oldkey=key;age=0;}else age++;
  if((mode==7 || mode==0x34 || mode==0x35) && age==8){printf("TEXT f=%u id=%04x pos=%u mode=%x len=%u\n",f,id,pos,mode,r32(m+0xe300));printf("PHOTO f=%u kind=text\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f==100){printf("PHOTO f=%u kind=scene\n",f);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f>150 && mode==0 && !strstr(scenario,"combat") && !strstr(scenario,"dark")){value=0x20;if(f%30<4)value|=0x80;}
  else if(f>100 && (mode==6 || mode==7 || mode==0x34 || mode==0x35) && age>15 && f%20<4)value=0x80;
  if(strstr(scenario,"combat") || strstr(scenario,"dark")){
   static unsigned lastHp[0x200]={0};
   for(int cat=0;cat<12;cat++)for(uint32_t q=r32(play+0x1c34+cat*8),n=0;q>=0x80000000 && q<0x80400000 && n<100;q=r32(q+0x124),n++) {
    unsigned typ=DebugMemRead16(q),hp=DebugMemRead8(q+0xaf),dmg=DebugMemRead8(q+0xb0);if(typ==2 || typ==0x33 || typ==0x113 || typ==0x55){unsigned idx=(q>>4)&511;if(lastHp[idx]!=hp || dmg){printf("HIT f=%u actor=%08x id=%x oldhp=%u hp=%u dmg=%u category=%u live=%08x pos=(%.1f %.1f %.1f) maxlink=%u playerhp=%u\n",f,q,typ,lastHp[idx],hp,dmg,DebugMemRead8(q+2),r32(q+0x130),rf(q+0x24),rf(q+0x28),rf(q+0x2c),DebugMemRead16(savebase+0x2e),DebugMemRead16(savebase+0x30));lastHp[idx]=hp;}}
   }
   value=0;
   uint32_t enemy=actor(strstr(scenario,"dark")?0x33:strstr(scenario,"iron")?0x113:2);
   float dx=0,dz=0;
   if(f>120 && enemy){
    dx=rf(enemy+0x24)-rf(player+0x24);dz=rf(enemy+0x2c)-rf(player+0x2c);float dist=sqrtf(dx*dx+dz*dz);value=0x20;
    if(!strstr(scenario,"hp-only") && f%26<4)value|=0x40;
    if(dist<65){dx=dz=0;}
   }else if(strstr(scenario,"dark") && f>120 && !enemy){dx=-3120-rf(player+0x24);dz=-1900-rf(player+0x2c);}
   if((dx*dx+dz*dz)>50 && f>120){uint32_t cam=r32(play+0x790+DebugMemRead16(play+0x7a0)*4);float fx=rf(cam+0x50)-rf(cam+0x5c),fz=rf(cam+0x58)-rf(cam+0x64),c=sqrtf(fx*fx+fz*fz),d=sqrtf(dx*dx+dz*dz);if(c>1 && d>1){fx/=c;fz/=c;dx/=d;dz/=d;int x=roundf((dx*fz-dz*fx)*60),y=roundf((dx*fx+dz*fz)*60);value|=((unsigned)(uint8_t)x<<16)|((unsigned)(uint8_t)y<<24);}}
  }
  if(f%100==0){
   uint32_t fan=actor_type(0x173,0x75),chum=actor_type(0x173,0x76),crock=actor_type(0x173,0x77);
   printf("HERO f=%u fan=%08x chum=%08x crocker=%08x room=%d prev=%d fan_floor=%.1f chum_floor=%.1f crocker_floor=%.1f flags=%08x\n",f,fan,chum,crock,(int8_t)DebugMemRead8(play+0x11cbc),(int8_t)DebugMemRead8(play+0x11cd0),fan?rf(fan+0x80):0,chum?rf(chum+0x80):0,crock?rf(crock+0x80):0,r32(play+0x1d28));
   if(fan&&chum){fprintf(stderr,"HERO_COLOAD_ERROR\n");exit(95);}
   uint32_t ctx=play+0x117a4,begin=r32(ctx),end=r32(ctx+4),last=begin;int entries=DebugMemRead8(ctx+8);
   for(int i=0;i<entries && i<19;i++){uint32_t slot=ctx+12+i*0x44;int obj=(int16_t)DebugMemRead16(slot);if(obj<0)obj=-obj;if(obj>0 && obj<0x192){uint32_t e=r32(slot+4)+r32(OBJECTTABLE+obj*8+4)-r32(OBJECTTABLE+obj*8);if(e>last)last=e;}}
   printf("OBJECT_BANK f=%u entries=%d used=%u capacity=%u remaining=%d\n",f,entries,last-begin,end-begin,(int)(end-last));if(last>end){fprintf(stderr,"OBJECT_BANK_OVERFLOW\n");exit(96);}
   printf("ROOM_BANK f=%u start=%08x end=%08x current=%08x previous=%08x capacity=%u\n",f,r32(play+0x11ce4),r32(play+0x11ce8),r32(play+0x11cc8),r32(play+0x11cdc),r32(play+0x11ce8)-r32(play+0x11ce4));
   printf("STATE f=%u scene=%x id=%04x msg=%x RAM=%u player=(%.1f %.1f %.1f)\n",f,DebugMemRead16(play+0xa4),id,mode,r32(0x80000318),rf(player+0x24),rf(player+0x28),rf(player+0x2c));
  }
 }
'''
s=s[:a]+body.replace('OBJECTTABLE',hex(syms['gObjectTable']))+s[z:];s=s.replace('0x800ef6a0',hex(syms['gGameStateOverlayTable']));(W/'runner.c').write_text(s)
base=bytearray(Path('/workspace/pepsiman-water/man-30.save').read_bytes())
def fixture(name,ent,scene,room,pos,yaw=0,age=0,lang=1):
 b=bytearray(base);struct.pack_into('>III',b,0,ent,age,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,ent,room);b[0x1409]=lang;struct.pack_into('>HH',b,0x2e,160,160);b[0x13e2:0x13e7]=bytes(5);b[0x137c:0x1384]=bytes(8);b[0x34]=1;struct.pack_into('>H',b,0x0c,0x8000);off=0xd4+scene*0x1c;b[off:off+0x1c]=bytes(0x1c);struct.pack_into('>H',b,0x70,0x1122 if not age else 0x1111);b[0x4a:0x54]=b[0x68:0x72];(W/(name+'.save')).write_bytes(b);return b
fixture('fanboy',0x169,3,3,(1410.,463.,-1388.),16384)
fixture('chumchum',0x169,3,5,(-1170.,383.,-1498.),-16384)
fixture('crocker',0x37,7,12,(-5230.,-1363.,-1840.),-32768)
fixture('fanboy-english',0x169,3,3,(1410.,463.,-1388.),16384,lang=0)
fixture('okto-colleague',0x39c,0x37,0,(55.,0.,-4.),16384,age=1)
fixture('combat-stalfos',0x169,3,6,(273.,467.,-3280.),-32768)
for name,maxhp in [('dark-hp-only-10',160),('dark-hp-only-3',48)]:
 b=fixture(name,0x10,5,13,(-3120.,1040.,-2580.),0);struct.pack_into('>HH',b,0x2e,maxhp,maxhp);(W/(name+'.save')).write_bytes(b)
for topic,src in [('lab-child','/workspace/wald-dialoge-feuer/lab-child.save'),('lab-adult','/workspace/wald-dialoge-feuer/lab-adult.save')]:
 b=bytearray(Path(src).read_bytes());b[0x4a:0x54]=b[0x68:0x72];(W/(topic+'.save')).write_bytes(b)
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(W/'runner.c'),'-o',str(W/'runner'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)

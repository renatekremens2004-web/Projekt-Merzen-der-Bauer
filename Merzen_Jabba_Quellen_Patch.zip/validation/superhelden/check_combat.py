"""Host semantic checks of exact production C damage functions with engine headers; runtime ABI tested separately."""
from pathlib import Path
import re,subprocess,json
O=Path('/workspace/oot-burns-pal');W=Path('/workspace/fanboy-chumchum')
def function(path,name):
 s=path.read_text();m=re.search(r'(?:s32|u8|void) '+name+r'\([^;]+?\) \{',s);assert m,name;a=m.start();i=s.index('{',a)+1;depth=1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
functions='\n'.join([function(O/'src/code/z_collision_check.c',n)for n in ['CollisionCheck_IsPlayerMasterSwordHit','CollisionCheck_ApplyDamage']]+[function(O/'src/code/z_actor.c','Actor_ApplyDamage')])
s='''#include "collision_check.h"
#include "actor.h"
#include "attributes.h"
#include "play_state.h"
'''+functions+r'''
static Actor target, source;
static Collider ac, at;
static ColliderElement recv, send;
static DamageTable table;
static unsigned checks;
static void check(s32 condition) {
 checks++;
 if (!condition) { __asm__ volatile("syscall" : : "a"(60),"D"(checks) : "memory");for(;;); }
}
static void setup(u32 flags) {
 s32 i;
 for(i=0;i<32;i++)table.table[i]=0x32;
 target.id=ACTOR_EN_TEST;target.category=ACTORCAT_ENEMY;target.params=-1;
 target.colChkInfo.health=30;target.colChkInfo.damage=0;target.colChkInfo.damageReaction=0;
 target.colChkInfo.damageTable=&table;
 source.id=ACTOR_PLAYER;source.category=ACTORCAT_PLAYER;
 ac.actor=&target;ac.acFlags=AC_HIT;at.actor=&source;
 recv.acElemFlags=ACELEM_HIT;recv.acHit=&at;recv.acHitElem=&send;recv.acDmgInfo.defense=0;
 send.atDmgInfo.dmgFlags=flags;send.atDmgInfo.damage=2;
}
static void hit(void){CollisionCheck_ApplyDamage(0,0,&ac,&recv);}
void _start(void) {
 s32 i;u32 masters[]={DMG_SLASH_MASTER,DMG_SPIN_MASTER,DMG_JUMP_MASTER};
 for(i=0;i<3;i++) { setup(masters[i]);hit();check(target.colChkInfo.damage==30);check(target.colChkInfo.damageReaction==3);check(Actor_ApplyDamage(&target)==0); }
 setup(DMG_SLASH_MASTER);source.id=ACTOR_EN_TORCH2;hit();check(target.colChkInfo.damage==2);check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SPIN_MASTER);source.id=ACTOR_EN_M_THUNDER;hit();check(Actor_ApplyDamage(&target)==0);
 setup(DMG_SLASH_MASTER);target.category=ACTORCAT_BOSS;hit();check(target.colChkInfo.damage==2);check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_MASTER);target.category=ACTORCAT_NPC;hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_MASTER);target.id=ACTOR_EN_IK;target.params=0;hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_MASTER);target.id=ACTOR_EN_IK;target.params=2;hit();check(Actor_ApplyDamage(&target)==0);
 setup(DMG_ARROW_NORMAL);hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_KOKIRI);hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_GIANT);hit();check(Actor_ApplyDamage(&target)==28);
 setup(DMG_SLASH_MASTER);ac.acFlags|=AC_HARD;hit();check(target.colChkInfo.damage==0);check(Actor_ApplyDamage(&target)==30);
 setup(DMG_SLASH_MASTER);recv.acElemFlags|=ACELEM_NO_DAMAGE;hit();check(target.colChkInfo.damage==0);
 setup(DMG_SLASH_MASTER);table.table[9]=0x30;hit();check(target.colChkInfo.damage==0);
 setup(DMG_SLASH_MASTER);target.colChkInfo.health=200;hit();hit();check(target.colChkInfo.damage==200);check(Actor_ApplyDamage(&target)==0);
 setup(DMG_SLASH_MASTER);target.colChkInfo.damageTable=0;hit();check(Actor_ApplyDamage(&target)==0);
 setup(DMG_SLASH_MASTER);target.colChkInfo.damageTable=0;recv.acDmgInfo.defense=2;hit();check(Actor_ApplyDamage(&target)==30);
 setup(DMG_SLASH_MASTER);recv.acHit=0;check(!CollisionCheck_IsPlayerMasterSwordHit(&recv));
 check(!CollisionCheck_IsPlayerMasterSwordHit(0));
 { char out[12];s32 len=0;unsigned n=checks;do{out[len++]='0'+n%10;n/=10;}while(n);for(i=0;i<len/2;i++){char c=out[i];out[i]=out[len-1-i];out[len-1-i]=c;}out[len++]='\n';__asm__ volatile("syscall" : : "a"(1),"D"(1),"S"(out),"d"(len) : "memory"); }
 __asm__ volatile("syscall" : : "a"(60),"D"(0) : "memory");for(;;);
}
'''
p=W/'combat_production_test.c';p.write_text(s)
cmd=['gcc','-m64','-O1','-fno-builtin','-fno-pie','-no-pie','-nostdlib','-nostdinc','-static','-fno-stack-protector','-Iinclude/libc','-Iinclude','-I.','-Iextracted/pal-1.0','-DNDEBUG','-DF3DEX_GBI_2','-DOOT_VERSION=PAL_1_0','-DOOT_REVISION=0','-DOOT_REGION=REGION_EU','-D_LANGUAGE_C',str(p),'-o',str(W/'combat_production_test')]
subprocess.run(cmd,cwd=O,check=True);r=subprocess.run([str(W/'combat_production_test')],capture_output=True,text=True);assert r.returncode==0,('native production C damage test failed at assertion',r.returncode)
report=dict(production_functions_extracted_without_rewriting=True,host_64bit_semantic_test_using_engine_headers=True,checks=int(r.stdout.strip()),master_slash_spin_jump=True,damage_reaction_retained=True,real_player_and_charge_only=True,npc_boss_shadow_attacker_protected=True,nabooru_armor_story_protected=True,immunity_other_weapons_preserved=True,multiple_elements_200hp_no_overflow=True)
(W/'combat_production_test.json').write_text(json.dumps(report,indent=2)+'\n');print('Exact production C damage checks passed.')

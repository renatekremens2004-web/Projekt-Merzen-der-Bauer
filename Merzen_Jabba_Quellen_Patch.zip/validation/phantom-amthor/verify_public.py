from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import urllib.request,urllib.parse,hashlib,json,subprocess
D=Path('/workspace/bean-download-delivery');W=Path('/workspace/phantom-amthor');commit=subprocess.check_output(['git','-C',str(D),'rev-parse','HEAD'],text=True).strip();base='https://raw.githubusercontent.com/renatekremens2004-web/Projekt-Merzen-der-Bauer/'+commit+'/'
names=['Mr_Burns_Mr_Bean_DE_PAL10_Amthor_Bean_Darunia_Deku.bps','Amthor_Bean_Darunia_Deku_Ingame_Bilder.zip','Merzen_Amthor_Quellen_Patch_Bilder.zip','Amthor_Bean_Darunia_Deku_Dialoge_Aktuell.md','Amthor_Bean_Darunia_Deku_Beispielbilder/Smithers_Schabernack.png','Amthor_Bean_Darunia_Deku_Beispielbilder/Deku_Baum_Letzter_Satz.png','Amthor_Bean_Darunia_Deku_Beispielbilder/Mido_Deku_Baum.png']
def check(n):
 with urllib.request.urlopen(base+urllib.parse.quote(n),timeout=120) as response:
  h=hashlib.sha256();size=0
  while chunk:=response.read(1024*1024):h.update(chunk);size+=len(chunk)
  assert response.status==200
 assert h.hexdigest()==hashlib.sha256((D/n).read_bytes()).hexdigest(),n
 return dict(file=n,status=200,bytes=size,sha256=h.hexdigest(),url=base+n)
with ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(check,names))
(W/'public-downloads.json').write_text(json.dumps(dict(commit=commit,downloads=results),indent=2)+'\n')
for r in results:print(r['status'],r['bytes'],r['file'],'SHA256 matches')

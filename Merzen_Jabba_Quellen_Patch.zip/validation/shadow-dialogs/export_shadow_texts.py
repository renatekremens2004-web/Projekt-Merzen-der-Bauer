from pathlib import Path
import sys,json,re,hashlib
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/shadow-dialogs');D=Path('/workspace/bean-download-delivery')
sys.path.insert(0,str(R/'tools'));from build_story import messages,plain,split_pages,tokens
m=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());edits={i:(e,p.name)for p in sorted((R/'story').glob('*.json'))for i,e in json.loads(p.read_text())['messages'].items()};origin={};local=set()
for scene in ['HAKAdan','HAKAdanCH']:
 for p in (O/'extracted/pal-1.0/assets/scenes/dungeons'/scene).glob('*ActorEntryList*.c'):
  for a in re.finditer(r'ACTOR_ELF_MSG2?,.*?0x([0-9A-Fa-f]+), // params',p.read_text(),re.S):
   v=int(a[1],16)
   if v in [0x3F77,0x3F79]:continue
   ident=f'{(v&255)+0x100:04X}';local.add(ident);origin.setdefault(ident,set()).add(scene+' Raum '+re.search(r'_room_(\d+)',p.name)[1])
items=['0060','0067','00C7']
for k,e in m.items():
 body=e['parts'][2][2];t=plain(body)
 if int(k,16)<0x100 and any(x in body for x in ['ITEM_LENS_OF_TRUTH','ITEM_BOOTS_HOVER','ITEM_MEDALLION_SHADOW','ITEM_DUNGEON_MAP','ITEM_COMPASS','ITEM_KEY_SMALL','ITEM_KEY_BOSS']):items.append(k)
 if int(k,16)<0x100 and any(x in t for x in ['Nocturne','Hymne des Sturms']):items.append(k)
groups=[('Navis Story-Kommentare vor und während des Kapitels',['0154','0155','0157','0156','015F']),('Navis örtliche Untersuchungen in Brunnen und Schattentempel',sorted(local)),('Guru-Guru / Windmühle und Hymne des Sturms',['5034','5035','508E','5032','5033']),('Sheik: brennendes Kakariko, Befreiung Bongo Bongos und Nocturne',['5030','501C','5031','501D']),('Tempelwände, Statue und Warnungen',['0208','0209','020A','0224','0181','5071']),('Neue Begegnungen: Crocker und Brunnenfund',['6089','608B']),('Schätze und erlernte Lieder',sorted(set(items))),('Mr. Bean nach Bongo Bongo: Halle der Weisen',['5022','5023','5025','5026','502B','502C']),('Kakariko: wichtige Hinweise und Reaktionen',['505B','505F','5087','507B','507C']),('Navi: Gegner und Endboß im Kapitel',['0604','0605','0607','0608','0611','0612','061B','061C','061D','061E','061F','0620','0624','0629','062A','062D','062E','062F','0630','0631','0637','0639']),('Späterer Rückbezug und Übergang',['70E3','5024','0158'])]
seen=set();out=['# Brunnen / Schattentempel — vollständiger relevanter Textbestand','', 'Ausgelesen aus dem aktuellen deutschen Build nach Einbau Deiner neuen Kapiteltexte. `{name}` ist der echte Spielername; `[A]`, `[C]`, `[Z]` sind Spielsymbole. Seiten bleiben in der vorhandenen Reihenfolge. „Original“ bedeutet: noch kein eigener Ersatz in unseren Story-Dateien. Diese Liste zeigt die tatsächlich eingebauten Texte.','', 'Einige Nachrichten sind optionale Untersuchungen, wiederholte Ansprachen oder spätere Rückbezüge. Navi meldet sie nicht alle automatisch. Gemeinsam verwendete Schatz- und Gegnertexte gelten auch in anderen Gebieten. Nicht bearbeitete Originaltexte können weiterhin ihre bisherige Schreibung enthalten.','']
manifest=[]
for title,ids in groups:
 out+=['## '+title,'']
 for ident in ids:
  if ident in seen or ident not in m:continue
  seen.add(ident);body=m[ident]['parts'][2][2];status='bereits bearbeitet — '+edits[ident][1]if ident in edits else'Original'
  label=' / '.join(sorted(origin.get(ident,[])))
  out+=['### '+ident+(' — '+label if label else''),'',status+'.','']
  pages=split_pages(body)[0]
  for n,page in enumerate(pages,1):
   t=plain(page).strip();out+=['**Seite '+str(n)+'**'if len(pages)>1 else'',''] if len(pages)>1 else[]
   out+=['> '+line if line else'>'for line in t.splitlines()]+['']
  manifest.append(dict(id=ident,section=title,custom=ident in edits,pages=[plain(x)for x in pages],locations=sorted(origin.get(ident,[]))))
out+=['---','',str(len(seen))+' verschiedene Nachrichten. Lokale Navi-Auslöser aus den Akteurslisten beider Dungeons ermittelt. Die Gegnertexte sind gesondert aufgeführt; sie sind keine Story-Rufe.','']
text='\n'.join(out);p=R/'planning/BRUNNEN_SCHATTENTEMPEL_TEXTE_AKTUELL.md';p.write_text(text);(D/'Brunnen_Schattentempel_Texte_Aktuell.md').write_text(text);(W/'shadow-texts.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print('Exported',len(seen),'messages; local IDs:',sorted(local),'items',items)

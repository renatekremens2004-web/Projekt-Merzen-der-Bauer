from pathlib import Path
import hashlib, json, shutil, sys, zipfile
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/shadow-dialogs');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts')
sys.path.insert(0,str(R/'tools'));from build_story import messages,plain,split_pages
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((O/'build/pal-1.0/shadow-dialogue-verification.json').read_text());pr=json.loads((W/'patch-verification.json').read_text());romsha=sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64');assert romsha==report['rom_sha256']==pr['target_sha256']
V=R/'validation/shadow-dialogs';V.mkdir(parents=True,exist_ok=True)
for name in ['verification.log','export_shadow_texts.py','shadow-texts.json','check_patch.js','patch-verification.json','package.py']:shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/shadow-dialogue-verification.json',V/'shadow-dialogue-verification.json')
chapter=json.loads((R/'story/schatten_brunnen_de.json').read_text());m=messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
intro='''# Neue Brunnen-/Schattentempel-Dialoge

19 tatsächlich eingebaute deutsche Textstellen. Alte Rechtschreibung; `{name}` ist der echte Spielername. Jede hier getrennte Seite wird normal weitergeklickt. Feste Lesezeiten, Okarina-/Liedabläufe und Quests bleiben unverändert. Sheiks sehr lange Rede wurde auf einen Textpuffer gekürzt; ihre Ausflüchte über Hyrules Vergangenheit, Mr. Beans Geschichte und Tempelzugang bleiben enthalten.

Zuordnung der Nummern aus der Vorlage:

| Vorlage | Im Spiel |
| --- | --- |
| 01526 / 01528 / 01529 / 0152B | 0126 / 0128 / 0129 / 012B |
| 01591 | 0191, ausdrücklich unverändert |
| Guru-Guru, wütende Schuhe | 5034 |
| 0535 / 058E / 051D | 5035 / 508E / 501D |
| Mauer: Tiefe / Giant Squid | 012A, getrennt vom Oben-Spruch 0129 |

'''
out=[intro]
for ident in chapter['messages']:
    out+=['## '+ident,'']
    pages=split_pages(m[ident]['parts'][2][2])[0]
    for i,p in enumerate(pages,1):
        if len(pages)>1:out+=['**Seite '+str(i)+'**','']
        out+=['> '+line if line else'>'for line in plain(p).strip().splitlines()]+['']
newdoc='\n'.join(out);(R/'planning/BRUNNEN_SCHATTENTEMPEL_NEUE_DIALOGE.md').write_text(newdoc);(D/'Brunnen_Schattentempel_Neue_Dialoge.md').write_text(newdoc)
doc=f'''# Prüfung: Brunnen-/Schattentempel-Dialoge

Gesamtpatch für unveränderte Europa/PAL 1.0. Original-MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{romsha}`, 40 MiB. Alle bisherigen Änderungen enthalten, einschließlich Wallaces neuer Arm-/Laufbewegung, kleinerem Waluigi und Schultersitz in den Credits.

19 deutsche Textkörper geändert, jetzt insgesamt 1.024 eigene Nachrichten. 0191 bleibt ausdrücklich unverändert. Alle sonstigen deutschen Nachrichten, sämtliche anderen Sprachen und alle Textboxkopf-/Positionseigenschaften exakt wie in der vorigen Veröffentlichung. Echte Spielernamen und funktionale Steuerzeichen einschließlich EVENT, TEXTID, Liedabläufen, Auswahlfeldern und festen Verzögerungen erhalten. Zusätzliche Seiten verwenden nur normales BOX_BREAK; keine festen Lesezeiten angepaßt.

Die verrutschten Nummern sind in der neuen Dialogliste zugeordnet; Oben-/Tiefe-Witze auf die beiden Mauern 0129/012A verteilt. Guru-Gurus erste Erwachsenenrede ist 5034. Alte Rechtschreibung, einschließlich daß, muß, Schloß, Haß, unfaßbar und wißt.

## Prüfung des Neubaus

- Layout aller eigenen Nachrichten mit den echten PAL-Schriftbreiten geprüft, höchstens vier Zeilen pro Seite. Spielernamen werden konservativ mit acht breiten Buchstaben berechnet.
- Alle 1.024 kompilierten eigenen Nachrichten unter 1.280 Rohbytes und unter 200 decodierten Zeichen pro Seite. Größte Nachricht unverändert 1.146 Bytes. Sheiks neue 5031: 944 Bytes, neun manuell weitergeklickte Seiten, höchstens 137 decodierte Zeichen pro Seite.
- Alle 1.509 komprimierten Segmente gegen den unkomprimierten Neubau geprüft; CIC-6105-Prüfsumme gültig.
- Nur deutsche Textdaten sowie notwendige Text-/Dateiadressen, ROM-Header und DMA-Daten ändern sich. Alle anderen Segmente sind bytegleich oder enthalten ausschließlich geprüfte Linker-Adreßanpassungen. Modelle, Animationen, native Akteurslogik, Cutscenes, Kameras, Quests und Navis Auslöser erhalten.
- RomPatcher.js mit Quellvalidierung erzeugt aus Vanilla und BPS bytegenau den oben genannten Neubau.

Dies ist ein Textschritt. Keine erneute Emulatoraufnahme oder vollständiger Durchlauf in diesem Schritt; vorige Modell-/Credits-Aufnahmen gehören weiterhin zu ihrem damaligen Build. Keine neue Performance- oder RAM-Zusage aus diesem Test abgeleitet. Keine ROMs, Spielstände, Savestates, RAM-Abzüge oder ausführbaren Dateien veröffentlicht.

## Quellen / Neubau

Neue Einträge: `story/schatten_brunnen_de.json`; bisherige Einträge mit denselben IDs aus `goronen_kakariko_de.json` und `bean_impa_de.json` dorthin verschoben, damit es keine doppelten IDs gibt. `build_shadow_dialogue.py <oot>` als letzten Textschritt nach der bestehenden Modell-/Kapitelfolge ausführen; anschließend normal bauen und komprimieren. Es ersetzt ausschließlich die 19 deutschen Textkörper im vorhandenen fertigen Tabellenstand. Alle anderen Kopf-/Sprach-/Fortsetzungsdaten bleiben erhalten, insbesondere Habecks TEXTID-Kette und private NPC-Textboxeinstellungen. Ein erneuter allgemeiner `build_story.py`-Lauf danach erfordert wie bisher die nachgelagerten Kapitel-Builder.

Der Vergleichsprüfer benötigt die vorige Produktions-ROM, deren Map, Texttabellenquelle und Navi-Hinweisquelle lokal; diese ROM-Vergleichsdaten sind nicht im Quellenpaket. Vollständiger Ergebnisbericht in `validation/shadow-dialogs/`.
'''
(R/'TESTING_BRUNNEN_SCHATTENTEMPEL_DIALOGE.md').write_text(doc);(D/'Pruefung_Brunnen_Schattentempel_Dialoge.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Brunnen_Schattentempel_Dialoge.bps';shutil.copyfile(patch,R/'patches'/patch.name)
heading='# Neue Brunnen-/Schattentempel-Dialoge';p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [19 neue Texte](planning/BRUNNEN_SCHATTENTEMPEL_NEUE_DIALOGE.md) · [Vollständiger Kapitelbestand](planning/BRUNNEN_SCHATTENTEMPEL_TEXTE_AKTUELL.md) · [Prüfung](TESTING_BRUNNEN_SCHATTENTEMPEL_DIALOGE.md)\n\n1.024 eigene Nachrichten; alle bisherigen Änderungen enthalten. 0191 bleibt unverändert. `build_shadow_dialogue.py` als letzten Textschritt nach den bestehenden Kapitel-/Modell-Buildern ausführen.\n\n'+p.read_text())
archive=A/'Merzen_Brunnen_Schattentempel_Dialoge_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
    for p in sorted(R.rglob('*')):
        rel=p.relative_to(R);allowed_original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
        allowed_original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
        if not p.is_file()or(any(x in exclude for x in rel.parts)and not allowed_original)or p.suffix.lower()not in suffixes:continue
        if rel.parts[0]=='patches'and p.name!=patch.name:continue
        if rel.parts[0]=='previews':continue
        with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
        z.write(p,rel)
with zipfile.ZipFile(archive)as z:
    assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st','.mp4'}for n in z.namelist())
instruction=A/'Anleitung_Brunnen_Schattentempel_Dialoge.txt';instruction.write_text('Gesamtpatch mit 19 neuen Brunnen-/Schattentempel-Texten. Alle bisherigen Änderungen enthalten.\n\nMit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte, unveränderte Europa/PAL-1.0-ROM anwenden, nicht auf eine bereits gepatchte Fassung. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände weiterverwenden. Alte Emulator-Savestates können alte Texttabellen im RAM enthalten.\n')
files=[patch,archive,instruction,D/'Brunnen_Schattentempel_Neue_Dialoge.md',D/'Brunnen_Schattentempel_Texte_Aktuell.md',D/'Pruefung_Brunnen_Schattentempel_Dialoge.md']
for p in [patch,archive,instruction]:shutil.copyfile(p,D/p.name)
sums=D/'SHA256SUMS_Brunnen_Schattentempel_Dialoge.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files))
p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [19 neue Dialoge](Brunnen_Schattentempel_Neue_Dialoge.md) · [Vollständige 74 Texte](Brunnen_Schattentempel_Texte_Aktuell.md) · [Quellen]('+archive.name+'?raw=true) · [Prüfung](Pruefung_Brunnen_Schattentempel_Dialoge.md)\n\nNavi, Guru-Guru, Sheik und Tempelmauer nach Nutzervorlage. Alte Rechtschreibung, 0191 unverändert, keine festen Lesezeiten geändert. Alle bisherigen Änderungen enthalten, einschließlich Wallaces lebhafterer Bewegung. BPS auf unveränderte Vanilla Europa/PAL 1.0 anwenden.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=romsha,files=[p.name for p in files+[sums]]),indent=2)+'\n')
print('Packaged',romsha,'source ZIP bytes',archive.stat().st_size)

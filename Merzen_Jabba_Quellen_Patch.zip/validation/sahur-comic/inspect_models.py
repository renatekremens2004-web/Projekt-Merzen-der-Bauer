import bpy,json,sys
from pathlib import Path
from mathutils import Vector
W=Path('/workspace/sahur-dance');out={}
for name,rel in [('shuffle','shuffle/source/Shuffling (8).fbx'),('not-ai','not-ai/source/ZAHUR.fbx')]:
 bpy.ops.wm.read_factory_settings(use_empty=True)
 bpy.ops.import_scene.fbx(filepath=str(W/rel))
 meshes=[o for o in bpy.context.scene.objects if o.type=='MESH'];rigs=[o for o in bpy.context.scene.objects if o.type=='ARMATURE']
 d={'meshes':[],'rigs':[],'actions':[],'images':[]}
 for o in meshes:
  o.data.calc_loop_triangles();ps=[o.matrix_world@v.co for v in o.data.vertices]
  d['meshes'].append(dict(name=o.name,vertices=len(o.data.vertices),triangles=len(o.data.loop_triangles),bounds=[[min(p[k]for p in ps),max(p[k]for p in ps)]for k in range(3)],materials=[m.name if m else None for m in o.data.materials],groups=[g.name for g in o.vertex_groups]))
 for o in rigs:d['rigs'].append(dict(name=o.name,scale=list(o.scale),bones=[dict(name=b.name,parent=b.parent.name if b.parent else None,head=list(b.head_local),tail=list(b.tail_local))for b in o.data.bones],active_action=o.animation_data.action.name if o.animation_data and o.animation_data.action else None))
 for a in bpy.data.actions:d['actions'].append(dict(name=a.name,frame_range=list(a.frame_range),curves=len(a.fcurves)))
 for im in bpy.data.images:d['images'].append(dict(name=im.name,path=im.filepath,size=list(im.size)))
 bpy.ops.wm.save_as_mainfile(filepath=str(W/(name+'-import.blend')))
 out[name]=d
(W/'inspection.json').write_text(json.dumps(out,indent=2)+'\n')
print('MODEL_INSPECTION',json.dumps({n:{'meshes':[(m['name'],m['triangles'])for m in d['meshes']],'bones':[len(r['bones'])for r in d['rigs']],'actions':d['actions']}for n,d in out.items()}))

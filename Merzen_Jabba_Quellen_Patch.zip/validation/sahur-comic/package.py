from pathlib import Path
import hashlib,json,re,shutil,sys,zipfile,subprocess
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/sahur-dance');D=Path('/workspace/bean-download-delivery');A=Path('/workspace/artifacts')
sys.path.insert(0,str(R/'tools'));from build_story import messages,plain,split_pages
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
romsha=sha(O/'build/pal-1.0/oot-pal-1.0-compressed.z64');report=json.loads((O/'build/pal-1.0/sahur-comic-verification.json').read_text());patchreport=json.loads((W/'patch-verification.json').read_text());assert romsha==report['rom_sha256']==patchreport['target_sha256']
V=R/'validation/sahur-comic';P=R/'previews/sahur-comic';V.mkdir(parents=True,exist_ok=True);P.mkdir(parents=True,exist_ok=True)
records={}
for topic,run in [('rise','v2'),('ruto','v2'),('dance','final')]:
 name=topic+'-record-'+run;m=json.loads((W/(name+'.json')).read_text());log=(W/(name+'.log')).read_text();assert m['rom_sha256']==romsha and m['ram_bytes']==4194304 and 'completed: 0'in log and sha(A/m['mp4'])==m['mp4_sha256'];records[topic]=m
 for ext in ['.json','.log']:shutil.copyfile(W/(name+ext),V/(name+ext))
def good_log(topic):
 p=W/f'sahur-comic-{topic}-final-direct-clip-on.log';s=p.read_text();assert 'completed: 0'in s and 'RAM=4194304'in s
 assert not any(x in s for x in ['OBJECT_BANK_OVERFLOW','HERO_COLOAD_ERROR','UNKNOWN GBI COMMAND','Using Vertex outside buffer'])
 shutil.copyfile(p,V/p.name);return s
checks={}
for topic in ['water-fan-28','water-chum-28','water-fan-29','water-chum-29','water-fan-30','water-chum-30','forest-chum','flat','kakariko','flat-battle']:checks[topic]=good_log(topic)
for topic in checks:
 if topic.startswith('water-fan'):assert 'id=7068'in checks[topic]and 'fan_floor=1060.0'in checks[topic]
 if topic.startswith('water-chum'):assert 'id=7069'in checks[topic]and 'chum_floor=780.0'in checks[topic]
assert 'id=5085'in checks['kakariko']and 'id=6088'in checks['forest-chum']
# Native rise: animation is held at frame zero until normal play; afterwards
# it advances through the new loop while actor position and facing stay fixed.
rise=(W/'rise-record-v2.log').read_text();samples=re.findall(r'SPROUT f=(\d+) cs=(\d+) rising=(\d+) state=(\d+) anim=([0-9a-f]+) frame=([\d.]+).*?pos=\(([^)]+)\) yaw=([^\s]+)',rise)
idle=[s for s in samples if s[1]!='0'or s[2]!='0'];dance=[s for s in samples if s[1]=='0'and s[2]=='0'];assert idle and dance
assert len({s[4]for s in idle})==1 and all(float(s[5])==0 for s in idle)
assert len({s[4]for s in dance})==1 and idle[0][4]!=dance[0][4]and len({s[5]for s in dance})>=3 and len({(s[6],s[7])for s in dance})==1
runtime=dict(rom_sha256=romsha,all_probes_ram_bytes=4194304,completed_probes=list(checks),rise_idle_then_dance_verified=True,dance_actor_position_and_yaw_constant=True,minimum_object_bank_remaining=min(int(x)for log in checks.values()for x in re.findall(r'remaining=(\d+)',log)),water_room_capacity_bytes=sorted({int(x)for t,log in checks.items()if t.startswith('water-')for x in re.findall(r'ROOM_BANK[^\n]*capacity=(\d+)',log)}))
(V/'runtime-verification.json').write_text(json.dumps(runtime,indent=2)+'\n')
for name in ['prepare_runtime.py','prepare_recording.py','runner.c','record_runner.c','record.py','run.py','export_sahur.py','inspect_models.py','inspection.json','chum-components.json','chum-fix.log','flat-reduce.log','export.log','verification.log','check_patch.js','patch-verification.json','package.py','sprout_before.c','sprout_before.h','elf_before.c','fanboy_before.json','chumchum_before.json','flatsquid_before.json']:
 shutil.copyfile(W/name,V/name)
shutil.copyfile(O/'build/pal-1.0/sahur-comic-verification.json',V/'sahur-comic-verification.json')
shots=[]
def photo(source,name,case):
 from PIL import Image
 im=Image.open(source).convert('RGB');im.save(P/name);assert im.tobytes()==Image.open(P/name).convert('RGB').tobytes();shots.append(dict(file=name,source=str(source),case=case,rom_sha256=romsha,unaltered_emulator_image=True))
for topic,index,name in [('dance',0,'Tripple_T_Tanz_1.png'),('dance',1,'Tripple_T_Tanz_2.png'),('rise',4,'Tripple_T_Cutscene.png'),('ruto',2,'Thaddaeus_Gespraech.png'),('ruto',6,'Thaddaeus_Schwimmen.png')]:
 m=records[topic];photo(Path(m['photos'][index]['file']),name,m['case'])
for topic,index,name in [('water-fan-30',3,'Fanboy_Lieblingscomic.png'),('water-chum-30',3,'Chum_Comic_abgesoffen.png'),('forest-chum',2,'Chum_Augen_Waldtempel.png'),('flat',0,'Flacher_Thaddaeus_972.png'),('kakariko',2,'Krabbelminen_Zigaretten.png')]:
 case=f'sahur-comic-{topic}-final-direct-clip-on';source=Path('/workspace/bean-rider')/('screens-'+case)/f'the_legend_of_zelda-{index:03d}.png';photo(source,name,case)
(P/'Aufnahmen.json').write_text(json.dumps(shots,ensure_ascii=False,indent=2)+'\n')
m=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());text=['# Neue Texte: Comic und Krabbelminen','', 'Alte Rechtschreibung; alle anderen Dialoge bleiben erhalten. Sahurs Rede und Thaddäus-Texte sind in diesem Schritt unverändert.','']
for ident,label in [('5085','Bärtiger Mann, erwachsenes Kakariko, tagsüber'),('7068','Fanboy, Wassertempel-Raum 7'),('7069','Chum Chum, Wassertempel-Raum 19')]:
 text+=['## '+ident+' — '+label,'']
 for j,body in enumerate(split_pages(m[ident]['parts'][2][2])[0],1):text+=['**Seite '+str(j)+'**','']+['> '+s for s in plain(body).strip().splitlines()]+['']
dialog='\n'.join(text);(R/'planning/SAHUR_WASSER_COMIC_DIALOGE.md').write_text(dialog);(D/'Sahur_Wasser_Comic_Dialoge.md').write_text(dialog)
doc=f'''# Prüfung: neuer Sahur, Comic im Wassertempel und Augen

Gesamtpatch für unveränderte Europa/PAL 1.0, Vanilla-MD5 `e040de91a74b61e3201db0e2323f768a`. Ziel-SHA256 `{romsha}`, weiterhin 40 MiB. Alle bisherigen Änderungen enthalten, einschließlich der 19 Brunnen-/Schattentempel-Texte und Wallaces lebhafterer Befreiung.

## Modelle und Auftritte

Tripple T verwendet die neue Shuffling-Vorlage: 35.818 auf 2.000 Dreiecke, 22 eigene Knochen, Höhe 60. Eigene Proportionen und gleichmäßige Skalierung; drei kleine CI4-Kacheln bewahren das Gesicht. Die Not-AI-Vorlage wurde ebenfalls untersucht; das große Roblox-Archiv war wegen der 32-MiB-Transfergrenze nicht zugänglich. Der vorhandene Tanz ist auf 108 eigene Rotationsposen einschließlich Übergang zum Schleifenanfang vorbereitet. Wurzel X/Z fest, keine Skalierung oder Scherung. Native Beleuchtung, Nebel und Tiefentest.

Im vollständigen nativen Ablauf bleibt seine Animation während der Cutscene auf der ruhigen Pose. Erst bei ruhendem Cutscene-Kontext und beendetem Auftauchen läuft die Tanzanimation. Protokolle zeigen wechselnde Animationsframes bei gleicher Akteursposition und Blickrichtung. Native Auftauchbewegung, Kameras, Cutscene-Daten, Medaillon-/Altersbedingungen und Dialoge bleiben erhalten. Der kurze Tanzclip zeigt ihn nach dem abgeschlossenen Waldkapitel ohne Eingaben und ohne Textbox; A bietet weiterhin das normale Gespräch an.

Fanboy: gleiche 1.463 Dreiecke, gleiche Größe 78, Originaltextur und unveränderter Waldtempel-Raum 3. Zusätzlich im Wassertempel-Raum 7 bei −3320/1060/−3970. Dieser feste Boden wird von keiner Wasserbox überdeckt. Chum Chum zusätzlich in Raum 19 bei 1730/780/180; die relevante höchste Wasseroberfläche liegt bei 765. Andere unabhängige Becken, etwa bei Schattenlink, sind für diese Positionen nicht maßgeblich. Räume 7/19 sind kein direkt verbundenes Raumpaar. Native Türen, Truhen, Gegner, Schalter und Wege bleiben erhalten. Normale OC-Körperkollision, keine Angriffs-/Trefferkollision oder Questflag-Änderung. Keine zusätzlichen Objekt-Slots.

Chums Augenkorrektur gilt in beiden Tempeln: 408 ursprüngliche Augen-/Pupillendreiecke erhalten, Pupillen etwa 0,205 Spieleinheiten vorgezogen, damit sie nicht in den vereinfachten Augapfelflächen verschwinden. Jetzt 1.573 statt 1.287 Dreiecke, weiterhin Höhe 49, gleiche Drehpunkte, Körperproportionen und Originalatlas. Die runden vollständigen Pupillen sind im Waldtempel und beim Wasserauftritt geprüft.

Flacher Thaddäus: 1.145 auf 972 Dreiecke, rund 15 Prozent weniger. Außenmaße ändern sich um weniger als eine Spieleinheit je Rand; Atlas und UV-Zuordnung bleiben erhalten. Weiterhin statisch ohne Physik oder Kollision, gleiche Stelle auf Morphas festem Randboden, gleicher Navi-Spruch. Lebendiger Thaddäus und sämtliche anderen Figuren/Weisen sind unverändert.

## Dialoge

5085 ersetzt ausschließlich die allgemeine Windmühlen-Bemerkung des bärtigen Mannes im erwachsenen Kakariko durch die Zigaretten-/Krabbelminen-Explosion. 7068/7069 sind bisher freie Platzhalter für die beiden Comic-Gespräche. 608D/608E gehören Wawario/Wawaluigi und bleiben erhalten. Insgesamt 1.026 eigene Nachrichten; alle anderen deutschen Texte, alle anderen Sprachen und alle Textbox-Kopf-/Positionseigenschaften bytegleich zur vorigen Veröffentlichung. Funktionale Steuerzeichen, Spielername, Fortsetzungen und feste Zeiten bleiben erhalten. Alle kompilierten Textpuffer und Schriftbreiten geprüft.

## MP4s und Laufzeit

| Video | Dauer | Frames |
| --- | ---: | ---: |
| Tripple_T_Tanz.mp4 | 24,00 s | 400 |
| Tripple_T_Auftauchen_und_Tanz.mp4 | 206,16 s | 3436 |
| Thaddaeus_Wassertempel_Animationen.mp4 | 88,38 s | 1473 |

Alle drei sind fortlaufende echte Emulatoraufnahmen desselben oben angegebenen Builds, 640×480 H.264, PAL 50/3 Bilder pro Sekunde, ohne Ton, tatsächliche 4 MiB N64-RAM. Der lange Sahur-Clip enthält auch die native Zwischensequenz zur Waldgeschichte. Thaddäus zeigt Begegnung, vollständiges Gespräch und anschließendes Hochschwimmen; native Aktionswechsel und beide Animationen protokolliert. Lokale Start-Spielstände bereiten die Kapitel vor; anschließend native Steuerung und normale Controller-Eingaben. Keine für die Vorschau versetzten NPCs, umgeschalteten Animationszustände oder geänderten Kameras. Video-Framezahl und fortlaufende Render-Erfassung geprüft; PNGs unveränderte native Screenshots.

Zusätzlich zehn abgeschlossene Proben: beide Comic-NPCs bei allen drei Wasserständen, Chums Augen im Waldtempel, der Kakariko-Spruch sowie das flache Modell nach Morpha und im regulären Kampf. In diesen Proben kein beobachteter Absturz, ungültiger Grafikbefehl oder Objektpufferüberlauf. Mindestens {runtime['minimum_object_bank_remaining']:,} Bytes Objektpuffer verbleiben in den Proben. Wassertempel-Raumpuffer unverändert 131.728 Bytes; Waldtempel 161.184. Die vollständige Auftauchsequenz prüft auch die nativen Szenenübergänge. Ein kompletter normaler Spieldurchlauf und echte Hardware sind damit nicht geprüft.

## Neubau / Nachweise

Alle 1.509 komprimierten Segmente gegen den unkomprimierten Neubau und CIC-6105-Prüfsumme geprüft. Sämtliche Objektsegmente außer object_dekujr bytegleich; Fanboys Waldtempelraum und Morphas Boß-Overlay ebenfalls bytegleich. Anderenorts nur geprüfte Linker-Adressen verändert. Im Sproß-Akteur ändern sich Initialskalierung und private Animationsauswahl; native Bewegung, Draw-Fallback, Kameras, Zerstörung und Zustandsfelder erhalten. Elf_Msg2 ändert nur die vier vorhandenen Superhelden-Helfer für die zusätzlichen Räume/Modelle/Textnummern; andere eigene NPCs und native Funktionen bleiben erhalten. RomPatcher.js mit Quellvalidierung erzeugt bytegenau die Produktions-ROM.

Nach den bisherigen Kapitel-/Modell-Buildern `build_sahur_shuffle.py <oot>` und `build_water_comic_heroes.py <oot>` ausführen, anschließend normal bauen/komprimieren. Vorbereitete JSONs und Texturen enthalten; Blender nur für neue Ableitungen nötig. `verify_sahur_comic.py` benötigt die vorige Produktions-ROM und lokale Vergleichsdaten, die ROM bleibt privat. Keine ROM, Saves, Savestates, RAM-Abzüge oder ausführbaren Dateien veröffentlicht. MP4s liegen getrennt vom Quellenarchiv.
'''
(R/'TESTING_SAHUR_COMIC_AUGEN.md').write_text(doc);(P/'Pruefbericht.md').write_text(doc)
patch=A/'Mr_Burns_Mr_Bean_DE_PAL10_Sahur_Comic_Augen.bps';shutil.copyfile(patch,R/'patches'/patch.name)
heading='# Tripple T tanzt; Comic im Wassertempel';p=R/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch](patches/'+patch.name+') · [Neue Texte](planning/SAHUR_WASSER_COMIC_DIALOGE.md) · [Prüfung](TESTING_SAHUR_COMIC_AUGEN.md) · [Echte Bilder](previews/sahur-comic/)\n\nNeuer Sahur mit eigenem Tanz erst nach der Auftauchsequenz. Fanboy und Chum getrennt im trockenen Wassertempel; Chums Augen auch im Waldtempel korrigiert. Flacher Thaddäus jetzt 972 Dreiecke. Neuer Kakariko-Spruch. Alle bisherigen Änderungen enthalten, 1.026 eigene Nachrichten. Neue letzte Schritte: `build_sahur_shuffle.py`, `build_water_comic_heroes.py`.\n\n'+p.read_text())
archive=A/'Merzen_Sahur_Wasser_Comic_Quellen_Patch.zip';suffixes={'.md','.py','.json','.c','.h','.txt','.png','.bps','.fbx','.js','.cfg','.jpeg','.jpg','.log','.dae','.obj','.smd','.mtl'};exclude={'.git','originals','downloads','build','baseroms','__pycache__','.codex','.agents','.aws'}
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(R.rglob('*')):
  rel=p.relative_to(R);allowed_original=rel.parts[:3]==('tools','originals','character_sizes')and p.suffix=='.c'
  allowed_original|=rel.parts[:3]==('tools','originals','water_spirit_sages')and p.name in ['gSpiritBossNabooruKnuckleDefeatCs.csdata.inc.c','gChamberOfSagesSealOpeningCs.csdata.inc.c']
  allowed_original|=rel.parts[:3]==('tools','originals','water-comic-heroes')and p.suffix in ['.c','.h']
  if not p.is_file()or(any(x in exclude for x in rel.parts)and not allowed_original)or p.suffix.lower()not in suffixes:continue
  if rel.parts[0]=='patches'and p.name!=patch.name:continue
  if rel.parts[0]=='previews'and len(rel.parts)>1 and rel.parts[1]!='sahur-comic':continue
  with p.open('rb')as f:assert f.read(4)not in[bytes.fromhex(x)for x in ['80371240','37804012','40123780','7f454c46']]
  z.write(p,rel)
with zipfile.ZipFile(archive)as z:assert z.testzip()is None and not any(Path(n).suffix.lower()in{'.z64','.n64','.v64','.rom','.bin','.save','.sav','.sra','.eep','.fla','.elf','.st','.mp4'}for n in z.namelist())
instruction=A/'Anleitung_Sahur_Wasser_Comic.txt';instruction.write_text('Gesamtpatch mit neuem tanzenden Sahur, Comic-NPCs, Augenkorrektur und schlankerem flachen Thaddäus. Alle bisherigen Änderungen enthalten.\n\nMit https://www.marcrobledo.com/RomPatcher.js/ auf die entpackte, unveränderte Europa/PAL-1.0-ROM anwenden, nicht auf eine bereits gepatchte Fassung. Original-MD5 e040de91a74b61e3201db0e2323f768a. Normale Spielstände verwenden; alte Emulator-Savestates können alte Overlays/Modelle im RAM enthalten. Videos ohne Ton, tatsächliche 4 MiB.\n')
files=[patch,archive,instruction,D/'Sahur_Wasser_Comic_Dialoge.md']+[A/m['mp4']for m in records.values()]
for p in [patch,archive,instruction]+[A/m['mp4']for m in records.values()]:shutil.copyfile(p,D/p.name)
sums=D/'SHA256SUMS_Sahur_Wasser_Comic.txt';sums.write_text(''.join(sha(p)+'  '+p.name+'\n'for p in files))
G=D/'Sahur_Wasser_Comic_Beispielbilder';G.mkdir(exist_ok=True)
for p in P.iterdir():shutil.copyfile(p,G/p.name)
p=D/'README.md'
if not p.read_text().startswith(heading):p.write_text(heading+'\n\n[Gesamtpatch]('+patch.name+'?raw=true) · [Tripple T tanzt: 24 s](Tripple_T_Tanz.mp4?raw=true) · [Vollständiger Auftritt](Tripple_T_Auftauchen_und_Tanz.mp4?raw=true) · [Thaddäus im Wassertempel](Thaddaeus_Wassertempel_Animationen.mp4?raw=true)\n\n[Neue Dialoge](Sahur_Wasser_Comic_Dialoge.md) · [Bilder und Prüfung](Sahur_Wasser_Comic_Beispielbilder/) · [Quellen]('+archive.name+'?raw=true)\n\nNeuer Sahur mit Tanz erst nach dem Auftauchen. Fanboy und Chum getrennt auf festen trockenen Böden im Wassertempel. Chums Augen in beiden Tempeln korrigiert. Flacher Thaddäus 972 statt 1.145 Dreiecke. Neuer Kakariko-Spruch. Alle bisherigen Änderungen enthalten. BPS auf unveränderte Vanilla PAL 1.0 anwenden. Videos ohne Ton, 4 MiB geprüft.\n\n'+p.read_text())
(W/'package-manifest.json').write_text(json.dumps(dict(rom_sha256=romsha,files=[p.name for p in files+[sums]],records=records,runtime=runtime),indent=2)+'\n');print('Packaged',romsha,'source ZIP bytes',archive.stat().st_size)

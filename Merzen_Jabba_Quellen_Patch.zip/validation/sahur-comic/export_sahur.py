"""Reduce supplied shuffling Sahur and retain his own rigid skeleton/dance."""
import bpy,sys,json,math,hashlib,shutil
from pathlib import Path
from mathutils import Matrix,Vector
W=Path('/workspace/sahur-dance');R=Path('/workspace/Projekt-Merzen-der-Bauer');D=R/'models/sahur-shuffle';D.mkdir(exist_ok=True)
bpy.ops.wm.open_mainfile(filepath=str(W/'shuffle-import.blend'))
rig=next(o for o in bpy.context.scene.objects if o.type=='ARMATURE');obj=next(o for o in bpy.context.scene.objects if o.type=='MESH');action=rig.animation_data.action
fps=bpy.context.scene.render.fps/bpy.context.scene.render.fps_base
rig.animation_data_clear()
for pb in rig.pose.bones:pb.matrix_basis=Matrix.Identity(4)
bpy.context.view_layer.update()
A=Matrix(((1,0,0),(0,0,1),(0,-1,0)))
bones=[b for b in rig.data.bones if not b.name.endswith(('_End','_end'))and 'HandIndex'not in b.name]
idx={b.name:i for i,b in enumerate(bones)}
def selected(name):
 b=rig.data.bones[name]
 while b.name not in idx:b=b.parent
 return idx[b.name]
rest=[]
for b in bones:
 matrix=A.to_4x4()@rig.matrix_world@b.matrix_local;t=matrix.translation.copy();matrix=matrix.to_3x3().normalized().to_4x4();matrix.translation=t;rest.append(matrix)
ps=[A@(obj.matrix_world@v.co)for v in obj.data.vertices];bottom=min(p.y for p in ps);height=max(p.y for p in ps)-bottom;scale=6000/height;offset=Vector((0,-bottom,0))
# Reduce once in the undeformed rest mesh; armature animation never enters the
# decimator. UV interpolation and original normals remain attached to geometry.
for modifier in list(obj.modifiers):
 if modifier.type=='ARMATURE':obj.modifiers.remove(modifier)
bpy.context.view_layer.objects.active=obj;mod=obj.modifiers.new('N64 budget','DECIMATE');mod.ratio=2000/35818;mod.use_collapse_triangulate=True;bpy.ops.object.modifier_apply(modifier=mod.name)
mesh=obj.data;mesh.calc_loop_triangles()
out=dict(model='User supplied Tung Tung Tung Sahur shuffling',source_sha256=hashlib.sha256((W/'shuffle/source/Shuffling (8).fbx').read_bytes()).hexdigest(),height=6000,height_game_units=60,actor_uniform_scale=.01,source_triangles=35818,bones=[],vertices=[],triangles=[],materials=[dict(name='wood',texture='shaded.png',size=[64,64])],animations={})
def ints(v):return [round(x)for x in v]
def angles(m):return [round(x*32768/math.pi)%65536 for x in m.to_euler('XYZ')]
for i,b in enumerate(bones):
 parent=selected(b.parent.name)if b.parent else -1;local=rest[parent].inverted()@rest[i]if parent>=0 else rest[i]
 out['bones'].append(dict(name=b.name,parent=parent,position=ints(local.translation*scale),rest_matrix=[list(r)for r in rest[i]]))
for v in mesh.vertices:
 p=A@(obj.matrix_world@v.co);weights={}
 for g in v.groups:
  name=obj.vertex_groups[g.group].name
  if name not in rig.data.bones:continue
  i=selected(name);weights[i]=weights.get(i,0)+g.weight
 i=max(weights,key=weights.get)if weights else 0
 out['vertices'].append(dict(bone=i,position=ints((rest[i].inverted()@p)*scale),source_world=ints((p+offset)*scale)))
for tri in mesh.loop_triangles:
 cs=[]
 for vi,li in zip(tri.vertices,tri.loops):
  i=out['vertices'][vi]['bone'];nw=A@obj.matrix_world.to_3x3().inverted().transposed()@mesh.corner_normals[li].vector;n=(rest[i].to_3x3().inverted()@nw).normalized()
  cs.append(dict(vertex=vi,uv=list(mesh.uv_layers.active.data[li].uv),normal=ints(n*127)))
 out['triangles'].append(dict(material=0,corners=cs))
rig.animation_data_create();rig.animation_data.action=action
frames=[];start,end=action.frame_range
# Pick one complete four-beat section. Root X/Z is fixed, but retain the
# dancer's height changes and every relative joint rotation without scale.
count=96;sample_start=1.;sample_end=145.
for f in range(count):
 source=sample_start+(sample_end-sample_start)*f/count;bpy.context.scene.frame_set(int(source),subframe=source%1);bpy.context.view_layer.update();world=[]
 for b in bones:
  mat=A.to_4x4()@rig.matrix_world@rig.pose.bones[b.name].matrix;world.append(mat)
 root=world[0].translation+offset
 if not frames:root_anchor=Vector((root.x,0,root.z))
 rotations=[]
 for i,b in enumerate(out['bones']):
  local=world[b['parent']].to_3x3().normalized().inverted()@world[i].to_3x3().normalized()if b['parent']>=0 else world[i].to_3x3().normalized();rotations.append(angles(local))
 frames.append(dict(root=[0,round(root.y*scale),0],rotation=rotations))
# Blend the end back to the first pose over 12 frames so the loop has no snap.
first=frames[0]
for j in range(12):
 q=(j+1)/12;src=frames[-1]if j==0 else tail;tail=dict(root=[round(x*(1-q)+y*q)for x,y in zip(frames[-1]['root'],first['root'])],rotation=[])
 for a,b in zip(frames[-1]['rotation'],first['rotation']):tail['rotation'].append([round(x+(((y-x+32768)%65536)-32768)*q)%65536 for x,y in zip(a,b)])
 if j==0:loop_tail=[]
 loop_tail.append(tail)
frames+=loop_tail
out['animations']['idle']=[first];out['animations']['dance']=frames
out['dance_metadata']=dict(source_fps=fps,source_range=[sample_start,sample_end],frames=len(frames),root_xz_locked=True,loop_blend_frames=12,unit_scale_rotations=True)
shutil.copyfile(W/'shuffle/textures/shaded.png',D/'shaded.png')
(R/'tools/sahur_shuffle_source.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
print('SAHUR_SHUFFLE',len(out['triangles']),'triangles',len(bones),'bones',len(frames),'frames; source fps',fps)

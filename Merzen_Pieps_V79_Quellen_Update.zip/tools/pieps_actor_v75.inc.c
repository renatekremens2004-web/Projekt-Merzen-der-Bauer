/* Private story role of the unused bird. Models live only in this overlay. */
#include "save.h"
#include "cutscene.h"
#include "player.h"
#include "camera.h"
#include "gfx.h"
#include "gfx_setupdl.h"
#include "sys_matrix.h"
#include "segmented_address.h"
#include "message.h"
#include "seqcmd.h"
#include "audio.h"
#include "pieps_bird_model_v75.inc.c"
#include "pieps_cage_model_v75.inc.c"
#define PIEPS_RESCUED_V75() GET_INFTABLE(0x1CA)
#define PIEPS_CAGE_V75 0x7501
#define PIEPS_FLIGHT_V75 0x7502
#define PIEPS_AFTER_V79 0x7503
static void Pieps_EndCameraV75(EnBird* this,PlayState* play){
 if(this->rotYStep>CAM_ID_MAIN){
  Play_ClearCamera(play,this->rotYStep);Play_ChangeCameraStatus(play,CAM_ID_MAIN,CAM_STAT_ACTIVE);
  Cutscene_StopManual(play,&play->csCtx);Player_SetCsActionWithHaltedActors(play,&this->actor,PLAYER_CSACTION_7);this->rotYStep=CAM_ID_NONE;
 }
}
static void Pieps_InitV75(EnBird* this,PlayState* play){
 u32 saved=gSegments[6];this->unk_194=0;this->rotYStep=CAM_ID_NONE;
 if((u16)this->actor.params==PIEPS_CAGE_V75&&(play->sceneId!=SCENE_DODONGOS_CAVERN||LINK_IS_ADULT||PIEPS_RESCUED_V75())){Actor_Kill(&this->actor);return;}
 if((u16)this->actor.params!=PIEPS_CAGE_V75&&(u16)this->actor.params!=PIEPS_FLIGHT_V75&&(u16)this->actor.params!=PIEPS_AFTER_V79){Actor_Kill(&this->actor);return;}
 gSegments[6]=OS_K0_TO_PHYSICAL(gPiepsNativeModelV75);
 SkelAnime_Init(play,&this->skelAnime,&gBirdSkel,&gBirdFlyAnim,NULL,NULL,0);gSegments[6]=saved;this->unk_194=1;
 if((u16)this->actor.params==PIEPS_AFTER_V79&&(!PIEPS_RESCUED_V75()||play->sceneId!=SCENE_DODONGOS_CAVERN_BOSS||!Flags_GetClear(play,play->roomCtx.curRoom.num))){Actor_Kill(&this->actor);return;}
 Actor_SetScale(&this->actor,(u16)this->actor.params==PIEPS_AFTER_V79?.02f:.01f);ActorShape_Init(&this->actor.shape,0,ActorShadow_DrawCircle,8);
 this->actor.flags=ACTOR_FLAG_UPDATE_CULLING_DISABLED|ACTOR_FLAG_DRAW_CULLING_DISABLED;this->scaleAnimSpeed=0;this->timer=5;
 this->actor.attentionRangeType=ATTENTION_RANGE_1;this->actor.naviEnemyId=0xFF;this->actor.textId=(u16)this->actor.params==PIEPS_AFTER_V79?0x723B:0x723A;
 if((u16)this->actor.params==PIEPS_AFTER_V79){this->scaleAnimSpeed=2;this->skelAnime.playSpeed=.4f;this->actor.flags|=ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_FRIENDLY;}
}
static void Pieps_UpdateV75(EnBird* this,PlayState* play){
 u32 saved=gSegments[6];Vec3f eye,at;f32 zoom;
 if(!this->unk_194)return;
 gSegments[6]=OS_K0_TO_PHYSICAL(gPiepsNativeModelV75);SkelAnime_Update(&this->skelAnime);gSegments[6]=saved;
 if((u16)this->actor.params==PIEPS_FLIGHT_V75)return;
 Actor_SetFocus(&this->actor,(u16)this->actor.params==PIEPS_AFTER_V79?6:20);
 if((u16)this->actor.params==PIEPS_AFTER_V79){
  this->actor.world.pos.y=this->actor.home.pos.y+sinf(play->gameplayFrames*.08f)*1.5f;
  if(this->actor.xzDistToPlayer<180)Math_SmoothStepToS(&this->actor.shape.rot.y,this->actor.yawTowardsPlayer,4,0x600,0x40);
  if(this->scaleAnimSpeed==2){if(Actor_TalkOfferAccepted(&this->actor,play))this->scaleAnimSpeed=3;else Actor_OfferTalk(&this->actor,play,110);}
  else if(Message_GetState(&play->msgCtx)==TEXT_STATE_CLOSING)this->scaleAnimSpeed=2;
  return;
 }
 if(this->scaleAnimSpeed==0){
  if(this->timer>0){this->timer--;return;}
  if(play->csCtx.state!=CS_STATE_IDLE)return;
  Cutscene_StartManual(play,&play->csCtx);Player_SetCsActionWithHaltedActors(play,&this->actor,PLAYER_CSACTION_1);
  this->rotYStep=Play_CreateSubCamera(play);if(this->rotYStep<=CAM_ID_MAIN){Cutscene_StopManual(play,&play->csCtx);Player_SetCsActionWithHaltedActors(play,&this->actor,PLAYER_CSACTION_7);this->scaleAnimSpeed=2;return;}Play_ChangeCameraStatus(play,CAM_ID_MAIN,CAM_STAT_WAIT);Play_ChangeCameraStatus(play,this->rotYStep,CAM_STAT_ACTIVE);this->scaleAnimSpeed=1;this->timer=45;
  Message_StartTextbox(play,0x7239,&this->actor);
 }
 if(this->scaleAnimSpeed==1){
  zoom=1.0f-this->timer/45.0f;at=this->actor.world.pos;at.y+=21;eye=at;eye.x+=100-45*zoom;eye.y+=35-21*zoom;eye.z+=125-60*zoom;
  Play_SetCameraAtEye(play,this->rotYStep,&at,&eye);
  if(this->timer>0)this->timer--;
  if(this->timer==0){if(play->msgCtx.textId==0x7239)Message_CloseTextbox(play);Pieps_EndCameraV75(this,play);this->scaleAnimSpeed=2;}return;
 }
 if(!Flags_GetSwitch(play,5))return;
 if((Audio_GetActiveSeqId(SEQ_PLAYER_BGM_MAIN)&0xFF)!=111)SEQCMD_PLAY_SEQUENCE(SEQ_PLAYER_BGM_MAIN,0,0,111);
 if(this->scaleAnimSpeed==2){
  this->actor.flags|=ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_FRIENDLY;
  if(Actor_TalkOfferAccepted(&this->actor,play))this->scaleAnimSpeed=3;
  else Actor_OfferTalk(&this->actor,play,100);
 }else if(this->scaleAnimSpeed==3&&Message_GetState(&play->msgCtx)==TEXT_STATE_CLOSING){
  SET_INFTABLE(0x1CA);this->scaleAnimSpeed=4;this->actor.flags&=~(ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_FRIENDLY);
 }
}
static void Pieps_DestroyV75(EnBird* this,PlayState* play){
 if(!this->unk_194)return;
 if((u16)this->actor.params==PIEPS_CAGE_V75){
  Pieps_EndCameraV75(this,play);
  if((Audio_GetActiveSeqId(SEQ_PLAYER_BGM_MAIN)&0xFF)==111)SEQCMD_PLAY_SEQUENCE(SEQ_PLAYER_BGM_MAIN,0,0,NA_BGM_DUNGEON);
 }
 SkelAnime_Free(&this->skelAnime,play);this->unk_194=0;
}
static void Pieps_DrawV75(EnBird* this,PlayState* play){
 u32 saved=gSegments[6];if(!this->unk_194)return;
 OPEN_DISPS(play->state.gfxCtx,"Pieps private model",0);
 Gfx_SetupDL_25Opa(play->state.gfxCtx);
 if((u16)this->actor.params==PIEPS_CAGE_V75){MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++,play->state.gfxCtx,"Pieps cage",0);gSPDisplayList(POLY_OPA_DISP++,sPiepsCageDLV75);Matrix_Translate(-300,1800,0,MTXMODE_APPLY);Matrix_Scale(1.6f,1.6f,1.6f,MTXMODE_APPLY);}
 gSegments[6]=OS_K0_TO_PHYSICAL(gPiepsNativeModelV75);gSPSegment(POLY_OPA_DISP++,6,gPiepsNativeModelV75);
 SkelAnime_DrawOpa(play,this->skelAnime.skeleton,this->skelAnime.jointTable,NULL,NULL,NULL);
 gSegments[6]=saved;gSPSegment(POLY_OPA_DISP++,6,OS_PHYSICAL_TO_K0(saved));
 CLOSE_DISPS(play->state.gfxCtx,"Pieps private model",1);
}

from pathlib import Path
import json,struct,hashlib
import crunch64
W=Path(__file__).parent;V=Path('/tmp/knocking-v109');allresults={}
for mode in ['normal','debug']:
 a=(V/(mode+'.z64')).read_bytes();b=(W/(mode+'.z64')).read_bytes();old=json.load(open(V/f'all-symbols-{mode}.json'));new=json.load(open(W/f'all-symbols-{mode}.json'));assert old==new,'symbol/address/size change';off=new['_dmadataSegmentRomStart'];changed=[];same=0
 for i in range(3000):
  va,ve,ps,pe=struct.unpack_from('>IIII',b,off+16*i)
  if ve==0:break
  def segment(rom):
   vs,ve,ps,pe=struct.unpack_from('>IIII',rom,off+16*i)
   if pe==0xffffffff:return None
   return bytes(rom[ps:ps+ve-vs]if pe==0 else crunch64.yaz0.decompress(rom[ps:pe]))
  x=segment(a);y=segment(b)
  if x==y:same+=1;continue
  name=next((k[1:-15]for k,v in new.items()if k.startswith('_')and k.endswith('SegmentRomStart')and v==va),hex(va));changed.append(name)
  if name=='object_ganon':
   lo=new['gGanondorfTitleCardTex']-new['_object_ganonSegmentStart']+128*56;hi=lo+128*24
   diffs=[j for j,(u,v)in enumerate(zip(x,y))if u!=v];assert len(x)==len(y)and all(lo<=j<hi for j in diffs);print(mode,'boss asset changes',len(diffs),'native bytes; heading and other languages identical')
 assert set(changed)<=set(['makerom','dmadata','object_ganon']),changed
 assert 'object_ganon'in changed
 allresults[mode]=dict(unchanged_segments=same,changed_segments=changed,all_symbol_addresses_and_sizes_identical=True,code_audio_dialogue_and_actor_overlays_byte_identical=True,only_german_name_pixels_changed=True)
(W/'Verifikation_V110.json').write_text(json.dumps(allresults,indent=2));print('BOSS_TITLE_VERIFIED',allresults)

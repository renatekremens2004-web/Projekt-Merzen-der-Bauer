from pathlib import Path
import json,struct,re,hashlib,sys
import crunch64
W=Path(__file__).parent;V=Path('/tmp/special-v112');O=Path('/workspace/oot-burns-pal');names=re.findall(r'DEFINE_DMA_ENTRY\(([^,]+),',(O/'build/pal-1.0/dmadata_table_spec.h').read_text());out={}
for mode in ['normal','debug']:
 a=(V/(mode+'.z64')).read_bytes();b=(W/(mode+'.z64')).read_bytes();old=json.load(open(V/f'all-symbols-{mode}.json'));new=json.load(open(W/f'all-symbols-{mode}.json'));dma=new['_dmadataSegmentRomStart'];checked=[]
 for name in names:
  if not(name in ['Audiobank','Audioseq','Audiotable','nes_message_data_static','ger_message_data_static','fra_message_data_static']or name.startswith('object_')or re.search('_room_[0-9]+$',name)):continue
  i=names.index(name)
  def seg(r):
   vs,ve,ps,pe=struct.unpack_from('>IIII',r,dma+i*16)
   if pe==0xffffffff:return None
   return bytes(r[ps:ps+ve-vs]if pe==0 else crunch64.yaz0.decompress(r[ps:pe]))
  x,y=seg(a),seg(b)
  if x!=y:
   assert len(x)==len(y),(mode,name,'asset size changed')
   for j in range(0,len(x),4):
    if x[j:j+4]!=y[j:j+4]:assert struct.unpack_from('>I',x,j)[0]==old['gIdentityMtx'] and struct.unpack_from('>I',y,j)[0]==new['gIdentityMtx'],(mode,name,j,'unexpected content change')
  checked.append(name)
 out[mode]=dict(checked_asset_segments=len(checked),audio_and_messages_identical=True,room_and_object_assets_identical_except_relocated_identity_matrix=True,code_growth_bytes=(new['_codeSegmentTextEnd']-new['_codeSegmentTextStart'])-(old['_codeSegmentTextEnd']-old['_codeSegmentTextStart']))
# All special content source snapshots are exactly those tested and released in V112.
manifest=json.load(open(V/'source-changes.json'))
for rel,meta in manifest['files'].items():assert hashlib.sha256((O/rel).read_bytes()).hexdigest()==meta['after'],rel
(W/'asset-verification.json').write_text(json.dumps(out,indent=2));print('V112_SPECIAL_CONTENT_PRESERVED',out)

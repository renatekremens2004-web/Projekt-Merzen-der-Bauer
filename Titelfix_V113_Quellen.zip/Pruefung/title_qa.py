from pathlib import Path
import os,sys,re,json,subprocess
W=Path(__file__).parent;V=Path('/tmp/special-v112');old=json.load(open('/workspace/yellow-poe-v70/symbols-normal.json'));base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
tag=sys.argv[1]if len(sys.argv)>1 else'early-a';mode='debug'if'--debug'in sys.argv else'normal';before='--before'in sys.argv;folder=V if before else W;sy=json.load(open(folder/f'all-symbols-{mode}.json'));rom=folder/(mode+'.z64')
s=base
for k in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:s=s.replace(hex(old[k]),hex(sy[k]))
s=re.sub(r'static void alarmcb\(int sig\).*?\nstatic uint32_t savebase=', 'static void alarmcb(int sig){printf("TIMEOUT pc=%08x",*(unsigned*)DebugGetCPUDataPtr(M64P_CPU_PC));_exit(99);}\nstatic uint32_t savebase=',s,flags=re.S)
a=s.index('static void capture_render(void){}');b=s.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned ready=0,hit=0,hit2=0,display=0,menu=0,initial=0;
static unsigned fileselect(void){unsigned p=GAMETABLE+5*0x30,loaded=r32(p),vram=r32(p+0xc),fn=r32(p+0x1c);if(!loaded)return 0;if(fn<loaded||fn>=loaded+0x40000)fn=fn-vram+loaded;for(unsigned a=0x80120000;a<0x803e0000;a+=4)if(r32(a+8)==fn&&r32(a+0x98)==1)return a;return 0;}
static void onframe(unsigned f){unsigned v=0,m=fileselect();if(m){if(!menu){menu=f;printf("FILESELECT f=%u state=%x\n",f,m);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}if(f>menu+100){printf("TITLE_QA_PASSED TAG mode=%u\n",r32(savebase+0x135c));CoreDoCommand(M64CMD_STOP,0,NULL);}if(buttons)buttons(0);return;}
 findplay();if(!play||!player){if(buttons)buttons(0);return;}unsigned scene=DebugMemRead16(play+0xa4),mag=actor(0x165),state=mag?DebugMemRead16(mag+0xe2cc):999,cs=DebugMemRead16(play+0x1d74);
 if(!ready&&scene==0x5a&&mag&&r32(savebase+0x135c)==1){ready=f;initial=scene;printf("TITLE_READY f=%u state=%u cs=%u\n",f,state,cs);}
 if(!ready)return;
 if(state==2&&!display)display=f;
 if(hit&&scene!=initial){printf("UNEXPECTED_DEMO scene=%x after_input=%u f=%u\n",scene,hit,f);exit(96);}
 if(EARLY&&!hit&&f>=ready+70){hit=f;v=BUTTON;printf("EARLY_PRESS f=%u mag=%u cs=%u\n",f,state,cs);}
 if(EARLY&&hit&&!hit2&&f>=hit+80){hit2=f;v=BUTTON;printf("SECOND_PRESS f=%u\n",f);}
 if(!EARLY&&!BOUNDARY&&!IDLE&&!hit&&display&&f>=display+35){hit=f;v=BUTTON;printf("DISPLAY_PRESS f=%u cs=%u\n",f,cs);}
 if((BOUNDARY||IDLE)&&display&&f==display+40){DebugMemWrite16(play+0x1d74,1599);if(BOUNDARY){hit=f;v=BUTTON;}printf("DESTINATION_BOUNDARY f=%u button=%x\n",f,v);}
 if(IDLE&&scene==0x17){printf("IDLE_DEMO_PASSED spirit_scene=%x f=%u\n",scene,f);CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(f%200==0 || (f>230&&f<330))printf("TITLE_STATE f=%u scene=%x mode=%u mag=%u cs=%u transition=%u\n",f,scene,r32(savebase+0x135c),state,cs,DebugMemRead8(play+0x11e15));
 if(buttons)buttons(v);if(f>3500||(hit&&f>hit+450)){puts("TITLE_QA_TIMEOUT");exit(97);}
}
'''
# actor table identifier for En_Mag is taken from the project's real table.
table=Path('/workspace/oot-burns-pal/include/tables/actor_table.h').read_text();ident=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ACTOR\(En_Mag,',table)[1],16);body=body.replace('actor(0x165)',f'actor({ident})')
for k,val in dict(GAMETABLE=hex(sy['gGameStateOverlayTable']),TAG=tag,EARLY='1'if tag.startswith('early')else'0',BOUNDARY='1'if tag.startswith('boundary')else'0',IDLE='1'if tag=='idle'else'0',BUTTON='0x80'if tag.endswith('-a')else'0x10').items():body=body.replace(k,val)
s=(s[:a]+body+s[b:]).replace('/workspace/bean-rider/config-%s',str(W/'config-%s')).replace('/workspace/bean-rider/screens-%s',str(W/'screens-%s')).replace('alarm(30)','alarm(240)').replace('alarm(15)','alarm(240)');c=W/('qa-'+tag+'-'+mode+'.c');c.write_text(s);runner=c.with_suffix('');subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
log=W/((('before-'if before else'')+tag+'-'+mode)+'.log')
with log.open('w')as f:r=subprocess.run([str(runner),str(rom),tag+'-'+mode+'-'+('before'if before else'fixed'),'4000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable'])],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=300)
print('RESULT',tag,mode,r.returncode,log.read_text()[-1500:]);sys.exit(r.returncode)

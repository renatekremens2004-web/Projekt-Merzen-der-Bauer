void BossSst_HeadSetupDeath(BossSst*,PlayState*);
void BossSst_HandSetupDamage(BossSst*);
/* Private to this boss overlay: one bird reused for flight and conversation. */
static Actor* sPiepsBongoBirdV96;
static s16 sPiepsBongoCamV96;
static s16 sPiepsBongoFrameV96;
static u8 sPiepsBongoFlightV96;
static u8 sPiepsBongoAssistedV96;
static Vec3f sPiepsBongoTargetV96;
static Vec3f sPiepsBongoEyeOffsetV96;
static s32 Pieps_BongoBeginV96(BossSst* this,PlayState* play){
 Vec3f at={-50,1020,0},eye;f32 length;
 if(sPiepsBongoAssistedV96||play->csCtx.state!=CS_STATE_IDLE)return false;
 sPiepsBongoBirdV96=Actor_Spawn(&play->actorCtx,play,ACTOR_EN_BIRD,-50,1180,0,0,0,0,0x7504);
 if(sPiepsBongoBirdV96==NULL)return false;
 sPiepsBongoCamV96=Play_CreateSubCamera(play);
 if(sPiepsBongoCamV96<=CAM_ID_MAIN){Actor_Kill(sPiepsBongoBirdV96);sPiepsBongoBirdV96=NULL;return false;}
 sPiepsBongoAssistedV96=true;sPiepsBongoFlightV96=true;sPiepsBongoFrameV96=0;
 sPiepsBongoTargetV96=this->actor.focus.pos;
 sPiepsBongoEyeOffsetV96=Play_GetCamera(play,CAM_ID_MAIN)->eye;
 sPiepsBongoEyeOffsetV96.x-=sPiepsBongoTargetV96.x;sPiepsBongoEyeOffsetV96.z-=sPiepsBongoTargetV96.z;
 length=sqrtf(SQ(sPiepsBongoEyeOffsetV96.x)+SQ(sPiepsBongoEyeOffsetV96.z));
 if(length<1)length=1;
 sPiepsBongoEyeOffsetV96.x*=350/length;sPiepsBongoEyeOffsetV96.z*=350/length;
 /* Focus is the eye position maintained by the native head draw. */
 Animation_MorphToLoop(&this->skelAnime,&gBongoHeadEyeOpenIdleAnim,0);
 this->vVanish=false;this->actor.flags&=~ACTOR_FLAG_REACT_TO_LENS;
 this->colliderCylinder.base.acFlags&=~AC_ON;this->colliderJntSph.base.atFlags&=~(AT_ON|AT_HIT);
 BossSst_HandReleasePlayer(sHands[LEFT],play,true);BossSst_HandReleasePlayer(sHands[RIGHT],play,true);
 Cutscene_StartManual(play,&play->csCtx);Player_SetCsActionWithHaltedActors(play,&this->actor,PLAYER_CSACTION_8);
 Play_ChangeCameraStatus(play,CAM_ID_MAIN,CAM_STAT_WAIT);Play_ChangeCameraStatus(play,sPiepsBongoCamV96,CAM_STAT_ACTIVE);
 eye.x=-50;eye.y=640;eye.z=270;Play_SetCameraAtEye(play,sPiepsBongoCamV96,&at,&eye);
 SEQCMD_PLAY_SEQUENCE(SEQ_PLAYER_BGM_MAIN,0,0,111);return true;
}
static void Pieps_BongoFlyV96(BossSst* this,PlayState* play){
 Vec3f at,eye={450,350,650};f32 t,s;Camera* camera;
 SkelAnime_Update(&this->skelAnime);
 sPiepsBongoTargetV96=this->actor.focus.pos;
 sPiepsBongoFrameV96++;
 /* Stay on the shaft axis until completely below the ceiling at Y=1020. */
 if(sPiepsBongoFrameV96<=45){
  t=CLAMP((sPiepsBongoFrameV96-10)/35.0f,0.0f,1.0f);s=t*t*(3-2*t);
  at.x=-50;at.y=1180-340*s;at.z=0;
 }else{
  t=CLAMP((sPiepsBongoFrameV96-45)/55.0f,0.0f,1.0f);s=t*t*(3-2*t);
  at.x=-50+(sPiepsBongoTargetV96.x+50)*s+sinf(t*M_PI)*90;
  at.y=840+(sPiepsBongoTargetV96.y-840)*s;at.z=sPiepsBongoTargetV96.z*s;
 }
 if(sPiepsBongoBirdV96!=NULL){
  sPiepsBongoBirdV96->world.pos=at;
  sPiepsBongoBirdV96->shape.rot.y=Math_Vec3f_Yaw(&at,&sPiepsBongoTargetV96);
  sPiepsBongoBirdV96->shape.rot.x=Math_Vec3f_Pitch(&at,&sPiepsBongoTargetV96);
  Actor_SetScale(sPiepsBongoBirdV96,.06f);
 }
 if(sPiepsBongoFrameV96<=45){
  Vec3f hole={-50,1020,0};
  eye.x=-50;eye.y=640;eye.z=270;
  Play_SetCameraAtEye(play,sPiepsBongoCamV96,&hole,&eye);
 }else{
  eye=at;eye.x+=sPiepsBongoEyeOffsetV96.x;eye.y=CLAMP_MAX(at.y+60,900);eye.z+=sPiepsBongoEyeOffsetV96.z;
  Play_SetCameraAtEye(play,sPiepsBongoCamV96,&at,&eye);
 }
 if(sPiepsBongoFrameV96>=100){
  camera=Play_GetCamera(play,CAM_ID_MAIN);camera->eye=eye;camera->eyeNext=eye;camera->at=at;
  Play_ReturnToMainCam(play,sPiepsBongoCamV96,0);sPiepsBongoFlightV96=false;
  if(sPiepsBongoBirdV96!=NULL){
   sPiepsBongoBirdV96->params=0x7505;sPiepsBongoBirdV96->world.pos.x=-340;sPiepsBongoBirdV96->world.pos.y=20;sPiepsBongoBirdV96->world.pos.z=220;
   sPiepsBongoBirdV96->home.pos=sPiepsBongoBirdV96->world.pos;
   sPiepsBongoBirdV96->shape.rot.x=0;Actor_SetScale(sPiepsBongoBirdV96,.025f);
  }
  this->actor.colChkInfo.health=0;
  Actor_RequestQuakeAndRumble(&this->actor,play,3,6);
  BossSst_HeadSetupDeath(this,play);BossSst_HandSetupDamage(sHands[LEFT]);BossSst_HandSetupDamage(sHands[RIGHT]);
 }
}

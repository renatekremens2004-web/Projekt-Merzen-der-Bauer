from pathlib import Path
import sys,json,hashlib
W=Path(__file__).resolve().parent;R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal')
sys.path.insert(0,str(R/'tools'));from build_story import messages,plain
B=R/'tools/originals/mint-story-v71'
a=messages((B/'extracted/pal-1.0/text/message_data.h').read_text());b=messages((O/'extracted/pal-1.0/text/message_data.h').read_text())
assert set(b)-set(a)=={'7238'}
assert all(a[k]['header']==b[k]['header'] and a[k]['parts']==b[k]['parts'] for k in a)
assert plain(b['7237']['parts'][2][2]).strip()=='Fass es bloß nicht an!'
assert 'revolutionär' in plain(b['7238']['parts'][2][2])
rel='src/overlays/actors/ovl_En_Ko/z_en_ko.c';old=(B/rel).read_text();now=(O/rel).read_text();guard='    if(EnKo_IsEarlyV66(thisx)&&LINK_IS_ADULT&&gSaveContext.gameMode==GAMEMODE_NORMAL&&CHECK_QUEST_ITEM(QUEST_MEDALLION_FOREST)){Actor_Kill(thisx);return;}\n'
assert now.replace(guard,'')==old
rel='extracted/pal-1.0/assets/scenes/overworld/spot00/spot00_room_0.c';assert (O/rel).read_bytes()==(B/rel).read_bytes()
private=(O/'src/overlays/actors/ovl_Sonichu_V70/z_sonichu_v70.c').read_text()
assert 'sizeof(EnKo)' in private and 'Actor_OfferGetItem' not in private and 'func_800359B8' in private
assert 'Collider_DestroyCylinder' in private
field=(O/'src/overlays/actors/ovl_Sonichu_V70/mint_field_v71.inc.c').read_text();assert 'AC_NONE' in field and 'AT_NONE' in field and 'Actor_OfferTalk' in field
scene=O/'extracted/pal-1.0/assets/scenes/overworld/spot00'
assert any('ACTOR_SONICHU_V70,{4750,200,8420}' in p.read_text() for p in scene.glob('*ActorEntryList.inc.c'))
party=next((O/'extracted/pal-1.0/assets/scenes/overworld/spot20').glob('*03000CB0_ActorEntryList.inc.c')).read_text();assert '{185,0,-318}' in party and '0x0071' in party
for mode in ['normal','debug']:
 s=json.loads((W/f'symbols-{mode}.json').read_text());assert s['_ovl_Elf_Msg2SegmentRomSize']==59088 and s['_ovl_Sonichu_V70SegmentRomSize']==37744 and s['_hakaana_ouke_room_2SegmentRomSize']==37680
report=dict(model=json.loads((W/'model-report.json').read_text()),room_bytes_before=39408,room_bytes_after=37680,private_overlay_bytes=37744,shared_elf_overlay_unchanged=59088,field_room_models_unchanged=True,field_object_slots_added=0,medallion_count_unchanged=True,medallion_navi_text='Fass es bloß nicht an!',new_message_only='7238',child_spell_code_unchanged=True,forest_credits_pose_unchanged=True,party_uses_existing_native_dancer=True,party_original_cameras_unchanged=True,medallion_position=[-110,41,-1155],field_kokiri_position=[4750,-160,8420],party_kokiri_position=[185,0,-318],message_table_sha256=hashlib.sha256((O/'extracted/pal-1.0/text/message_data.h').read_bytes()).hexdigest())
(W/'source-verification.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print('SOURCE_CHECKS_PASSED')

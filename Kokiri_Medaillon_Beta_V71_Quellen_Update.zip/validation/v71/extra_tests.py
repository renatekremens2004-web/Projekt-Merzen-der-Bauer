from pathlib import Path
import os,json,struct,re,subprocess,concurrent.futures,sys
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');mode=sys.argv[1]if len(sys.argv)>1 else'normal';sy=json.loads((W/f'symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());s=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:s=s.replace(hex(old[n]),hex(sy[n]))
a=s.index('static void capture_render(void){}');b=s.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned findmint(int party){
 if(!party){unsigned p=target(0x163,0x7e00);return p?p:target(0x161,0x7e00);}
 for(int cat=0;cat<12;cat++)for(unsigned p=r32(play+0x1c34+cat*8),n=0;p>=0x80000000&&p<0x80400000&&n<180;p=r32(p+0x124),n++)if(DebugMemRead16(p)==0x182&&DebugMemRead16(p+0x1c)==14&&DebugMemRead16(p+0x18)==0x71&&r32(p+0x130))return p;
 return 0;
}
static void onframe(unsigned f){
 static unsigned seen=0,text=0,moved=0,firstHash=0,transition=0;unsigned value=0;
 int party=strstr(scenario,"party")!=NULL,beta=strstr(scenario,"beta")!=NULL,bc=strstr(scenario,"beta-credits")!=NULL,forest=strstr(scenario,"forest")!=NULL,absent=strstr(scenario,"absent")!=NULL,credits=party||bc;
 baseframe(f);if(f==300&&credits)DebugMemWrite32(savebase+0x135c,3);if(f<340)return;findplay();if(!play||!player)return;
 unsigned g=beta?target(0x1ae,bc?0x7f5c:0x7f5b):findmint(party),msg=play+0x20d8,id=DebugMemRead16(msg+0xe2f8);
 if(g&&r32(g+0x134)){
  seen=1;float x=rf(g+0x24),y=rf(g+0x28),z=rf(g+0x2c);
  if(absent)need(0,"NPC absent in this story state");
  if(!credits){if(f<440)position(player,beta?x-85:(forest?x+60:x-60),y,beta?z-40:(forest?z+70:z+20),-24576);if(beta)photo(x+70,y+48,z+95,x,y+30,z);else if(forest)photo(x+100,y+65,z+150,x,y+30,z);else photo(x-130,y+75,z+60,x,y+30,z);}
  if(party){unsigned jp=r32(g+0x15c),hash=0;need(jp>=0x80000000&&jp<0x80400000,"native dancer joints");for(unsigned j=6*8;j<6*15;j+=2)hash=hash*31+DebugMemRead16(jp+j);if(!firstHash)firstHash=hash;else if(hash!=firstHash)moved=1;}
 }
 if(party&&seen&&r32(savebase+8)==0xfff4)transition=1;
 if(id==(forest?0x7235:(beta?0x7234:0x7238))&&DebugMemRead8(msg+0xe304))text=1;
 if(f==360||f==400||f==450||f==520||f==600){bank();CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);printf("EXTRA f=%u actor=%x scene=%x layer=%u cs=%x xyz=%.1f,%.1f,%.1f\n",f,g,DebugMemRead16(play+0xa4),r32(savebase+0x1360),r32(savebase+8),g?rf(g+0x24):0,g?rf(g+0x28):0,g?rf(g+0x2c):0);}
 if(!credits&&!absent&&f>450){value=0x20;if(f%15<2)value|=0x80;}if(buttons)buttons(value);
 if(f>(credits?720:750)){
  bank();need(absent?!seen:seen,"correct story-dependent presence");if(!credits&&!absent)need(text,"correct dialogue opens");if(party)need(moved&&transition,"native dance moves and credits continue to next shot");printf("EXTRA_PASSED seen=%u text=%u moved=%u transition=%u\n",seen,text,moved,transition);CoreDoCommand(M64CMD_STOP,0,NULL);
 }
}
'''
q=W/f'extra-{mode}.c';q.write_text(s[:a]+body+s[b:]);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(q),'-o',str(W/f'extra-{mode}'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
# All fixtures enter via native save/scene loading, no runtime actor injection.
text=(O/'include/tables/entrance_table.h').read_text()
def entry(name):return int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\('+name+r',',text)[1],16)
def fixture(tag,age,sceneEntry,cs,pos,room=0,done=1,night=0):
 q=bytearray(Path('/workspace/kokiri-speed-v66/child.save'if age else'/workspace/proto-soldier-v68/soldier.save').read_bytes());q[0x1409]=1;struct.pack_into('>III',q,0,sceneEntry,age,cs);struct.pack_into('>H',q,0xc,0xc000 if night else 0x8000);quest=struct.unpack_from('>I',q,0xa4)[0];struct.pack_into('>I',q,0xa4,(quest|1)if done else(quest&~1));event=struct.unpack_from('>H',q,0xed4+8)[0];struct.pack_into('>H',q,0xed4+8,(event|0x100)if done else(event&~0x100));
 if cs:struct.pack_into('>i',q,0x1364,0)
 struct.pack_into('>fffhHhB',q,0x1368,*pos,0,0xff if cs else 0xdff,sceneEntry,room);(W/(tag+'.save')).write_bytes(q)
field=entry('ENTR_HYRULE_FIELD_3');kf=entry('ENTR_KOKIRI_FOREST_0')
for tag,age,done,night in [('field-after',0,1,0),('field-after-night',0,1,1),('field-absent-before',0,0,0),('field-absent-child',1,1,0)]:fixture(tag,age,field,0,(4690,-160,8440),done=done,night=night)
fixture('forest-before',0,kf,0,(-60,0,-280),done=0);fixture('forest-absent-after',0,kf,0,(-60,0,-280),done=1)
fixture('party',1,entry('ENTR_LON_LON_RANCH_0'),0xfff3,(0,0,-400));fixture('beta-credits',0,entry('ENTR_GORON_CITY_0'),0xfff1,(150,40,-1320),room=1);fixture('beta-grip',0,field,0,(-9385,-260,7300))
# Reconstruct the cumulative patch in RAM; no ROM is written to disk.
patch=Path('/workspace/artifacts')/('Mr_Burns_Mr_Bean_DE_PAL10_'+('DEBUG_'if mode=='debug'else'')+'Sonichu_Medaillon_V71.bps')
js="const fs=require('fs');global.BinFile=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/modules/BinFile');const p=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/RomPatcher');const r=p.applyPatch(new BinFile(process.argv[1]),p.parsePatchFile(new BinFile(process.argv[2])),{requireValidation:true});fs.writeFileSync(1,Buffer.from(r._u8array));"
rom=subprocess.check_output(['node','-e',js,str(O/'baseroms/pal-1.0/baserom.z64'),str(patch)]);fd=os.memfd_create('v71-extra-'+mode);os.write(fd,rom);del rom
names=os.environ.get('EXTRA_TAGS','field-after,field-after-night,field-absent-before,field-absent-child,forest-before,forest-absent-after,party,beta-credits,beta-grip').split(',')
def run(tag):
 env=os.environ.copy();env.update(DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null')
 p=subprocess.run([str(W/f'extra-{mode}'),'/proc/self/fd/'+str(fd),f'v71-{mode}-{tag}','1400','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(W/(tag+'.save'))],pass_fds=(fd,),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=150);out=p.stdout.decode(errors='replace');(W/f'{mode}-{tag}.log').write_text(out);return dict(tag=tag,mode=mode,passed=p.returncode==0 and'EXTRA_PASSED'in out,exit=p.returncode,tail=out[-1000:])
results=[]
p=W/(f'extras-{mode}'+os.environ.get('RESULT_SUFFIX','')+'.json')
if p.exists():results=[r for r in json.loads(p.read_text())if r['tag']not in names]
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
 for future in concurrent.futures.as_completed([pool.submit(run,tag)for tag in names]):
  r=future.result();results.append(r);p.write_text(json.dumps(results,indent=2));print(r,flush=True)

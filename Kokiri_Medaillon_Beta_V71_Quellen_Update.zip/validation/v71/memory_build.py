"""Standard PAL build, with large temporary link/ROM outputs kept in anonymous RAM files."""
from pathlib import Path
import os,sys,json,re,subprocess,struct,hashlib,time,concurrent.futures
import ipl3checksum
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer');A=Path('/workspace/artifacts')
sys.path.insert(0,str(O/'tools'));import compress
state={};held=[]
def run(args,**kw):return subprocess.run(args,check=True,**kw)
def newfd(name):
 fd=os.memfd_create(name);held.append(fd);return fd
def pfd(fd):return '/proc/self/fd/'+str(fd)
def checksum(data):struct.pack_into('>II',data,16,*ipl3checksum.CICKind.CIC_X105.calculateChecksum(data))
def build(mode):
 if mode=='debug':
  run([sys.executable,str(R/'tools/build_debug_version.py'),str(O)])
  objs=['build/pal-1.0/src/code/graph.o','build/pal-1.0/src/code/z_sram.o','build/pal-1.0/src/overlays/gamestates/ovl_select/z_select.o','build/pal-1.0/src/overlays/misc/ovl_kaleido_scope/z_kaleido_scope.o','build/pal-1.0/src/overlays/misc/ovl_kaleido_scope/z_kaleido_debug.o']
 else:
  run([sys.executable,str(R/'tools/build_debug_version.py'),str(O),'--restore'])
  objs=['build/pal-1.0/src/code/graph.o','build/pal-1.0/src/code/z_sram.o','build/pal-1.0/src/overlays/gamestates/ovl_select/z_select.o','build/pal-1.0/src/overlays/misc/ovl_kaleido_scope/z_kaleido_scope.o','build/pal-1.0/src/overlays/misc/ovl_kaleido_scope/z_kaleido_debug.o']
 objs+=['build/pal-1.0/assets/scenes/misc/hakaana_ouke/hakaana_ouke_room_2.o','build/pal-1.0/src/overlays/actors/ovl_Sonichu_V70/z_sonichu_v70.o']
 segments=['code','ovl_select','ovl_kaleido_scope','ovl_Sonichu_V70','hakaana_ouke_room_2']
 targets=['build/pal-1.0/segments/'+n+'.plf'for n in segments]+['build/pal-1.0/segments/'+n+'.reloc.o'for n in segments if n.startswith('ovl_')]
 with (W/f'build-{mode}.log').open('w')as log:run(['make','-j4','VERSION=pal-1.0','COMPARE=0','PYTHON='+sys.executable,*targets],cwd=O,stdout=log,stderr=subprocess.STDOUT)
 elf=newfd('merzen-'+mode+'-elf')
 cmd=['mips-linux-gnu-ld','-T','build/pal-1.0/oot-pal-1.0.ld','-T','build/pal-1.0/linker_scripts/makerom.ld','-T','build/pal-1.0/undefined_syms.txt','--emit-relocs','-o',pfd(elf)]
 with(W/f'link-{mode}.log').open('w')as log:run(cmd,cwd=O,pass_fds=(elf,),stdout=log,stderr=subprocess.STDOUT)
 nm=subprocess.check_output(['mips-linux-gnu-nm','-n',pfd(elf)],pass_fds=(elf,),text=True)
 sy={n:int(a,16)for a,t,n in re.findall(r'^([0-9a-f]{8}) ([A-Za-z]) (\S+)$',nm,re.M)}
 rawfd=newfd('merzen-'+mode+'-raw')
 run(['mips-linux-gnu-objcopy','--pad-to',hex(sy['_RomSize']),'-O','binary',pfd(elf),pfd(rawfd)],pass_fds=(elf,rawfd))
 os.lseek(rawfd,0,0);raw=bytearray(os.read(rawfd,sy['_RomSize']));assert len(raw)==sy['_RomSize'];checksum(raw)
 ranges=set()
 for part in(O/'build/pal-1.0/compress_ranges.txt').read_text().strip().split(','):
  ends=part.split('-');ranges.update(range(int(ends[0]),int(ends[-1])+1))
 packed=bytearray(compress.compress_rom(memoryview(raw),sy['_dmadataSegmentRomStart'],ranges,'yaz0',0x800000,True,4));checksum(packed)
 fd=newfd('merzen-'+mode+'-compressed');os.write(fd,packed)
 globals=['gSaveContext','gActorOverlayTable','gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68','_ovl_Elf_Msg2SegmentRomSize','_ovl_Sonichu_V70SegmentRomSize','_hakaana_ouke_room_2SegmentRomSize','gSonichuV70DL']
 selected={n:sy[n]for n in globals};(W/f'symbols-{mode}.json').write_text(json.dumps(selected,indent=2))
 sha=hashlib.sha256(packed).hexdigest();state[mode]=dict(fd=fd,bytes=len(packed),sha256=sha,symbols=selected)
 held.remove(elf);held.remove(rawfd);os.close(elf);os.close(rawfd)
 assert sha!='dea9a36ee24b5c3658a7aaac4441eb7d34f808532d05305aa04140cb3169e26b','stale V70 build'
 for n in segments:
  for ext in ['.plf','.map']:
   q=O/'build/pal-1.0/segments'/(n+ext)
   if q.exists():q.unlink() # Only newly generated, reproducible partial-link outputs.
 print('BUILD_READY',mode,sha,selected,flush=True)
 return fd

def test(mode):
 sy=state[mode]['symbols'];old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
 for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
 # Record an additional front-facing overhead close-up in the test camera only.
 base=base.replace('photo(x+25,y+32,z+22,x,y+1,z)','photo(x,y+45,z+18,x,y+1,z)')
 p=W/f'runner-{mode}.c';p.write_text(base);run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(p),'-o',str(W/f'runner-{mode}'),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'])
 tags=['medallion-1','medallion-0']if mode=='normal'else['medallion-1'];fd=state[mode]['fd'];env=os.environ.copy();env.update(DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null')
 def one(tag):
  p=subprocess.run([str(W/f'runner-{mode}'),pfd(fd),f'v71-{mode}-{tag}','1500','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),'/workspace/yellow-poe-v70/'+tag+'.save'],pass_fds=(fd,),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300)
  out=p.stdout.decode(errors='replace');(W/f'{mode}-{tag}.log').write_text(out);return dict(mode=mode,tag=tag,passed=p.returncode==0 and'NEW_PROP_PASSED'in out,exit=p.returncode,tail=out[-750:])
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:results=list(pool.map(one,tags))
 (W/f'results-{mode}.json').write_text(json.dumps(results,indent=2));print('TEST_RESULTS',results,flush=True);assert all(x['passed']for x in results)

def patches():
 report={}
 for mode in ['normal','debug']:
  fd=state[mode]['fd'];n='Mr_Burns_Mr_Bean_DE_PAL10_'+('DEBUG_'if mode=='debug'else'')+'Sonichu_Medaillon_V71.bps'
  run(['/workspace/toolchain/Flips/flips','--create','--bps',str(O/'baseroms/pal-1.0/baserom.z64'),pfd(fd),str(A/n)],pass_fds=(fd,))
  # Independent implementation applies the generated BPS to the clean basis.
  js="const fs=require('fs'),c=require('crypto');global.BinFile=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/modules/BinFile');const p=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/RomPatcher');const actual=Buffer.from(p.applyPatch(new BinFile(process.argv[1]),p.parsePatchFile(new BinFile(process.argv[2])),{requireValidation:true})._u8array);const expected=fs.readFileSync(process.argv[3]);if(!actual.equals(expected))throw Error('Mismatch');console.log(c.createHash('sha256').update(actual).digest('hex'));"
  sha=subprocess.check_output(['node','-e',js,str(O/'baseroms/pal-1.0/baserom.z64'),str(A/n),pfd(fd)],pass_fds=(fd,),text=True).strip();assert sha==state[mode]['sha256']
  report[mode]=dict(file=n,sha256=sha,byte_identical=True,source_validated=True,patch_bytes=(A/n).stat().st_size)
 (W/'patch-verification.json').write_text(json.dumps(report,indent=2));print('PATCHES_READY',report,flush=True)

def main():
 build('normal');test('normal');print('WAITING_FOR_COMMAND',flush=True)
 seen=0
 while True:
  q=W/'command.json'
  if q.exists():
   msg=json.loads(q.read_text())
   if msg['id']!=seen:
    seen=msg['id'];action=msg['action']
    try:
     if action=='normal':build('normal');test('normal')
     elif action=='debug':build('debug');test('debug')
     elif action=='patches':patches()
     elif action=='finish':
      run([sys.executable,str(R/'tools/build_debug_version.py'),str(O),'--restore']);break
     (W/'command-result.json').write_text(json.dumps(dict(id=seen,action=action,passed=True)))
    except Exception as exc:
     (W/'command-result.json').write_text(json.dumps(dict(id=seen,action=action,passed=False,error=str(exc))));print('COMMAND_FAILED',repr(exc),flush=True)
    print('WAITING_FOR_COMMAND',flush=True)
  time.sleep(.5)
if __name__=='__main__':main()

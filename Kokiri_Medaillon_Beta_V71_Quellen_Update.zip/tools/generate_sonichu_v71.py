"""Recognizable floor medallion: original face projection, tiled CI4 front, thin 3D edge."""
from pathlib import Path
import json,math,sys
from PIL import Image
from n64_model import emit
R=Path(__file__).resolve().parents[1];D=R/'models/sonichu-v71';D.mkdir(parents=True,exist_ok=True)
W=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/workspace/sonichu-v71')
im=Image.open(W/'original-front.png').convert('RGBA').resize((128,128),Image.Resampling.LANCZOS)
im.save(D/'front.png');Image.new('RGBA',(16,16),(232,210,0,255)).save(D/'edge.png')
# Trace the original silhouette, including the hole in its hanging loop.
mask=im.getchannel('A');on=lambda x,y:0<=x<128 and 0<=y<128 and mask.getpixel((x,y))>=128
edges={}
for y in range(128):
 for x in range(128):
  if not on(x,y):continue
  for yes,a,b in [(not on(x,y-1),(x,y),(x+1,y)),(not on(x+1,y),(x+1,y),(x+1,y+1)),(not on(x,y+1),(x+1,y+1),(x,y+1)),(not on(x-1,y),(x,y+1),(x,y))]:
   if yes:edges.setdefault(a,[]).append(b)
def rdp(points,epsilon):
 if len(points)<=2:return points
 a,b=points[0],points[-1];dx,dy=b[0]-a[0],b[1]-a[1];den=math.hypot(dx,dy)
 dist=[abs(dy*(p[0]-a[0])-dx*(p[1]-a[1]))/den if den else math.dist(p,a)for p in points]
 i=max(range(len(points)),key=lambda i:dist[i])
 return rdp(points[:i+1],epsilon)[:-1]+rdp(points[i:],epsilon)if dist[i]>epsilon else [a,b]
loops=[]
while edges:
 start=next(iter(edges));p=start;loop=[]
 while True:
  loop.append(p);opts=edges[p];n=opts.pop()
  if not opts:del edges[p]
  p=n
  if p==start:break
 pivot=max(range(len(loop)),key=lambda i:math.dist(start,loop[i]))
 poly=rdp(loop[:pivot+1],1.6)[:-1]+rdp(loop[pivot:]+[start],1.6)[:-1]
 if len(poly)>=3:loops.append(poly)
model=dict(bones=[dict(name='root',parent=-1,position=[0,0,0])],vertices=[],materials=[],triangles=[])
def vertex(x,y,z):
 i=len(model['vertices']);model['vertices'].append(dict(bone=0,position=[round(x),round(y),round(z)]));return i
def tri(mat,idx,uv,normal):model['triangles'].append(dict(material=mat,corners=[dict(vertex=i,uv=uv[j],normal=normal)for j,i in enumerate(idx)]))
# Four 64x64 tiles retain a full 128x128 face without exceeding N64 TMEM.
for row in range(2):
 for col in range(2):
  mat=len(model['materials']);model['materials'].append(dict(name='front_'+str(mat),texture='front.png',crop=[col*64,row*64,(col+1)*64,(row+1)*64],size=[64,64]))
  x0=-800+col*800;z0=-800+row*800
  ids=[vertex(x0,60,z0),vertex(x0+800,60,z0),vertex(x0+800,60,z0+800),vertex(x0,60,z0+800)]
  uv=[[0,1],[1,1],[1,0],[0,0]]
  for face in [[0,3,1],[1,3,2]]:tri(mat,[ids[i]for i in face],[uv[i]for i in face],[0,127,0])
mat=len(model['materials']);model['materials'].append(dict(name='edge',texture='edge.png',size=[16,16]))
for loop in loops:
 for a,b in zip(loop,loop[1:]+loop[:1]):
  ax,az=(a[0]/128-.5)*1600,(a[1]/128-.5)*1600;bx,bz=(b[0]/128-.5)*1600,(b[1]/128-.5)*1600
  nx,nz=bz-az,-(bx-ax);length=math.hypot(nx,nz);normal=[round(nx/length*127),0,round(nz/length*127)]
  ids=[vertex(ax,0,az),vertex(bx,0,bz),vertex(bx,60,bz),vertex(ax,60,az)]
  for face in [[0,1,2],[0,2,3]]:tri(mat,[ids[i]for i in face],[[0,0]]*3,normal)
s=emit(model,D,'SonichuV70',False);s='\n'.join(line for line in s.splitlines()if not line.startswith('static StandardLimb'))+'\n';s=s.replace('G_TX_WRAP','G_TX_CLAMP')
(R/'tools/sonichu_model_v71.inc.c').write_text(s);(R/'tools/sonichu_v71_source.json').write_text(json.dumps(model,separators=(',',':')))
report=dict(original_triangles=2808,triangles=len(model['triangles']),front_triangles=8,edge_triangles=len(model['triangles'])-8,front_resolution=[128,128],tiles=4,tile_resolution=[64,64],longest_diameter=16,thickness=.6,texture_bytes=4*2048+128,palette_bytes=5*32,silhouette_loops=len(loops),face_from_original=True)
(W/'model-report.json').write_text(json.dumps(report,indent=2)+'\n');print(report)

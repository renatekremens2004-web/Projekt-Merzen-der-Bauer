"""After V70: fit the pistol grip into the beta Goron's palm; unarmed beta in Goron credits."""
from pathlib import Path
import re,sys
R=Path(__file__).resolve().parents[1];O=Path(sys.argv[1]);B=R/'tools/originals/beta-credits-v71'
def original(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((O/rel).read_bytes())
 return p.read_text()
def write(rel,s):
 p=O/rel
 if p.read_text()!=s:p.write_text(s)
rel='src/overlays/actors/ovl_En_Go2/proto_soldier_v68.inc.c';s=original(rel)
a=s.index('    if(gSaveContext.gameMode!=GAMEMODE_NORMAL');b=s.index('\n    slot=',a)
s=s[:a]+'''    if(gSaveContext.gameMode==GAMEMODE_END_CREDITS){
        if((u16)this->actor.params!=0x7F5C||play->sceneId!=SCENE_GORON_CITY){Actor_Kill(&this->actor);return;}
    }else if(gSaveContext.gameMode!=GAMEMODE_NORMAL||((u16)this->actor.params==0x7F5B?(!LINK_IS_ADULT||play->sceneId!=SCENE_HYRULE_FIELD):(!LINK_IS_CHILD||play->sceneId!=SCENE_DEATH_MOUNTAIN_TRAIL))){Actor_Kill(&this->actor);return;}
'''+s[b:]
needle='    Actor_SetFocus(&this->actor,60);';assert s.count(needle)==1;s=s.replace(needle,'    if(gSaveContext.gameMode==GAMEMODE_END_CREDITS){this->actor.flags&=~(ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_FRIENDLY);return;}\n'+needle)
old='Matrix_Translate(600.0f,-400.0f,450.0f,MTXMODE_APPLY);Matrix_Scale(.70f,.70f,.70f,MTXMODE_APPLY);Matrix_Translate(-600.0f,400.0f,-450.0f,MTXMODE_APPLY);'
new='Matrix_Translate(700.0f,-250.0f,0.0f,MTXMODE_APPLY);Matrix_Scale(.70f,.70f,.70f,MTXMODE_APPLY);Matrix_Translate(-600.0f,350.0f,-250.0f,MTXMODE_APPLY);'
assert s.count(old)==1;s=s.replace(old,new);write(rel,s)
folder='extracted/pal-1.0/assets/scenes/overworld/spot18/';p=next((O/folder).glob('*room_1*03000348_ActorEntryList.inc.c'));rel=str(p.relative_to(O));s=original(rel);n=s.count('ACTOR_');write(rel,s+'    {ACTOR_EN_GO2,{-100,40,-1430},{0,0,0},0x7F5C}, /* ordinary beta Goron, no military equipment */\n');macroA='LENGTH_'+p.name.removesuffix('.inc.c')
p=next((O/folder).glob('*room_1*03000340_ObjectList.inc.c'));rel=str(p.relative_to(O));s=original(rel);m=s.count('OBJECT_');write(rel,s+'    OBJECT_OF1S,\n    OBJECT_OF1D_MAP, /* beta model and native idle animation */\n');macroO='LENGTH_'+p.name.removesuffix('.inc.c')
rel=folder+'spot18_room_1.h';s=original(rel)
for macro,before,after in [(macroA,n,n+1),(macroO,m,m+2)]:s,k=re.subn(r'(#define '+macro+' )'+str(before)+r'\b',lambda m:m[1]+str(after),s);assert k==1
write(rel,s);print('Beta V71: grip attached to palm; unarmed, helmetless beta in Darunia credits room.')

/* Private mint Kokiri only. Native models are local to this private overlay; no object-bank slots are added. */
#include "mint_field_standing_v71.inc.c"
extern u64 gMintFieldBodyV71[];
extern u64 gMintFieldHeadV71[];
static Gfx* MintField_SetEnvColorV71(GraphicsContext* gfxCtx,u8 r,u8 g,u8 b,u8 a){
 Gfx* dl=GRAPH_ALLOC(gfxCtx,2*sizeof(Gfx));gDPSetEnvColor(dl,r,g,b,a);gSPEndDisplayList(dl+1);return dl;
}
static ColliderCylinderInit sMintFieldCylinderV71={
 {COL_MATERIAL_NONE,AT_NONE,AC_NONE,OC1_ON|OC1_TYPE_ALL,OC2_TYPE_2,COLSHAPE_CYLINDER},
 {ELEM_MATERIAL_UNK0,{0,HIT_SPECIAL_EFFECT_NONE,0},{0,HIT_BACKLASH_NONE,0},ATELEM_NONE,ACELEM_NONE,OCELEM_ON},
 {20,46,0,{0,0,0}}
};
static CollisionCheckInfoInit2 sMintFieldColInfoV71={0,0,0,0,MASS_IMMOVABLE};
static s32 EnKo_IsFieldMintV71(Actor* actor,PlayState* play){return (u16)actor->params==0x7E00&&play->sceneId==SCENE_HYRULE_FIELD;}
static void* EnKo_FieldModelV71(PlayState* play,void* symbol){return symbol;}
static void EnKo_FieldInitV71(EnKo* this,PlayState* play){
 u32 old=gSegments[6];this->unk_210=0;
 if(play->sceneId!=SCENE_HYRULE_FIELD||!LINK_IS_ADULT||gSaveContext.gameMode!=GAMEMODE_NORMAL||!CHECK_QUEST_ITEM(QUEST_MEDALLION_FOREST)){Actor_Kill(&this->actor);return;}
 gSegments[6]=OS_K0_TO_PHYSICAL(EnKo_FieldModelV71(play,gMintFieldBodyV71));
 SkelAnime_InitFlex(play,&this->skelAnime,&gKm1Skel,NULL,this->jointTable,this->morphTable,16);
 Animation_PlayLoop(&this->skelAnime,&sMintFieldStandingAnimV71);gSegments[6]=old;
 Actor_SetScale(&this->actor,.01f);ActorShape_Init(&this->actor.shape,0,ActorShadow_DrawCircle,18);
 this->actor.flags=ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_FRIENDLY|ACTOR_FLAG_UPDATE_CULLING_DISABLED;
 this->actor.naviEnemyId=0xFF;this->actor.attentionRangeType=ATTENTION_RANGE_1;this->actor.textId=0x7238;
 Collider_InitCylinder(play,&this->collider);Collider_SetCylinder(play,&this->collider,&this->actor,&sMintFieldCylinderV71);
 CollisionCheck_SetInfo2(&this->actor.colChkInfo,NULL,&sMintFieldColInfoV71);this->interactInfo.talkState=0;this->modelAlpha=255;this->unk_210=1;
 Actor_UpdateBgCheckInfo(play,&this->actor,0,0,0,UPDBGCHECKINFO_FLAG_2);
 if(this->actor.floorHeight>BGCHECK_Y_MIN+10)this->actor.world.pos.y=this->actor.floorHeight;
}
static void EnKo_FieldUpdateV71(EnKo* this,PlayState* play){
 if(!this->unk_210)return;
 SkelAnime_Update(&this->skelAnime);Actor_SetFocus(&this->actor,42);
 if(this->actor.xzDistToPlayer<160)Math_SmoothStepToS(&this->actor.shape.rot.y,this->actor.yawTowardsPlayer,4,500,0);
 if(Actor_TalkOfferAccepted(&this->actor,play))this->interactInfo.talkState=1;
 if(this->interactInfo.talkState&&Message_GetState(&play->msgCtx)==TEXT_STATE_CLOSING)this->interactInfo.talkState=0;
 if(!this->interactInfo.talkState)Actor_OfferTalk(&this->actor,play,100);
 Collider_UpdateCylinder(&this->actor,&this->collider);CollisionCheck_SetOC(play,&play->colChkCtx,&this->collider.base);
}
static s32 EnKo_FieldHeadV71(PlayState* play,s32 limb,Gfx** dl,Vec3f* pos,Vec3s* rot,void* arg,Gfx** gfx){
 if(limb==15){
  void* head=EnKo_FieldModelV71(play,gMintFieldHeadV71);pos->x-=300;
  gSPSegment((*gfx)++,6,head);gSPSegment((*gfx)++,0x0A,(u8*)head+((play->gameplayFrames%120<4)?0x1690:0xE90));*dl=(Gfx*)0x06000800;
 }return false;
}
static void EnKo_FieldDrawV71(EnKo* this,PlayState* play){
 u32 old=gSegments[6];void* body=EnKo_FieldModelV71(play,gMintFieldBodyV71);
 if(!this->unk_210)return;
 gSegments[6]=OS_K0_TO_PHYSICAL(body);
 OPEN_DISPS(play->state.gfxCtx,"mint field",0);
 gSPSegment(POLY_OPA_DISP++,6,body);gSPSegment(POLY_OPA_DISP++,8,MintField_SetEnvColorV71(play->state.gfxCtx,0,130,70,255));gSPSegment(POLY_OPA_DISP++,9,MintField_SetEnvColorV71(play->state.gfxCtx,110,170,20,255));
 func_80034BA0(play,&this->skelAnime,EnKo_FieldHeadV71,NULL,&this->actor,255);
 gSegments[6]=old;gSPSegment(POLY_OPA_DISP++,6,OS_PHYSICAL_TO_K0(old));
 CLOSE_DISPS(play->state.gfxCtx,"mint field",1);
}

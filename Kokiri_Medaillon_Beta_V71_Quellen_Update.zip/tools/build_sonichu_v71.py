"""After V70: replace the distorted reduced medallion with a faithful tiled face and thin 3D edge."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];O=Path(sys.argv[1]);B=R/'tools/originals/sonichu-v71'
def original(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((O/rel).read_bytes())
 return p.read_text()
def write(rel,s):
 p=O/rel
 if p.read_text()!=s:p.write_text(s)
rel='extracted/pal-1.0/assets/scenes/misc/hakaana_ouke/sonichu_model_v70.inc.c';original(rel);write(rel,(R/'tools/sonichu_model_v71.inc.c').read_text())
rel='src/overlays/actors/ovl_Sonichu_V70/z_sonichu_v70.c';s=original(rel);needle=' Actor_SetFocus(actor,3);';assert s.count(needle)==1
s=s.replace(needle,' /* Match the native floor slope so the face cannot disappear into the ground. */\n func_800359B8(actor,actor->shape.rot.y,&actor->shape.rot);\n'+needle);write(rel,s)
print('V71 medallion: faithful 128x128 original face, four 64x64 CI4 tiles, thin 3D edge; existing actor and Navi text retained.')
folder=O/'extracted/pal-1.0/assets/scenes/misc/hakaana_ouke'
for p in folder.glob('hakaana_ouke_room_2_*ActorEntryList.inc.c'):
 rel=str(p.relative_to(O));s=original(rel);needle='{ACTOR_SONICHU_V70,{0,120,-1140}'
 assert s.count(needle)==1;write(rel,s.replace(needle,'{ACTOR_SONICHU_V70,{-110,120,-1155}'))
print('Moved clear of the raised inscription border onto the flat floor to its left.')

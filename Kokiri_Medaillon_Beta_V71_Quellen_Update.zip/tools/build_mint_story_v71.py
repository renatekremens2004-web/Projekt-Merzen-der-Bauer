"""After V70/V71 medallion: mint Kokiri moves out after Forest Temple; visible native party dancer."""
from pathlib import Path
import sys,re
from build_story import messages,Layout,rewrite
R=Path(__file__).resolve().parents[1];O=Path(sys.argv[1]);B=R/'tools/originals/mint-story-v71'
def original(rel):
 p=B/rel
 if not p.exists():p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((O/rel).read_bytes())
 return p.read_text()
def write(rel,s):
 p=O/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists()or p.read_text()!=s:p.write_text(s)
rel='src/overlays/actors/ovl_En_Ko/z_en_ko.c';s=original(rel)
needle='    if(EnKo_IsEarlyV66(thisx)&&(play->sceneId!=';i=s.index(needle)
s=s[:i]+"    if(EnKo_IsEarlyV66(thisx)&&LINK_IS_ADULT&&gSaveContext.gameMode==GAMEMODE_NORMAL&&CHECK_QUEST_ITEM(QUEST_MEDALLION_FOREST)){Actor_Kill(thisx);return;}\n"+s[i:];write(rel,s)
# Only the private medallion/field actor owns the outdoor model data. Child Field never loads it.
folder='src/overlays/actors/ovl_Sonichu_V70/'
for name in ['mint_field_v71.inc.c','mint_field_standing_v71.inc.c','mint_field_body_v71.inc.c','mint_field_head_v71.inc.c']:write(folder+name,(R/'tools'/name).read_text())
rel=folder+'z_sonichu_v70.c';s=original(rel)
s=s.replace('extern Gfx gSonichuV70DL[];','''#include "src/overlays/actors/ovl_En_Ko/z_en_ko.h"
#include "assets/objects/object_km1/object_km1.h"
#include "mint_field_body_v71.inc.c"
#include "mint_field_head_v71.inc.c"
#include "mint_field_v71.inc.c"
extern Gfx gSonichuV70DL[];''')
s=s.replace('static void Sonichu_Init(Actor* actor,PlayState* play) {','static void Sonichu_Init(Actor* actor,PlayState* play) {\n if((u16)actor->params==0x7E00){EnKo_FieldInitV71((EnKo*)actor,play);if(((EnKo*)actor)->unk_210)Actor_ChangeCategory(play,&play->actorCtx,actor,ACTORCAT_NPC);return;}')
s=s.replace('static void Sonichu_Update(Actor* actor,PlayState* play) {','static void Sonichu_Update(Actor* actor,PlayState* play) {if((u16)actor->params==0x7E00){EnKo_FieldUpdateV71((EnKo*)actor,play);return;}')
s=s.replace(' void* room=NULL;',' void* room=NULL;\n if((u16)actor->params==0x7E00){EnKo_FieldDrawV71((EnKo*)actor,play);return;}')
s=s.replace('ActorProfile Sonichu_V70_Profile=', 'static void Sonichu_Destroy(Actor* actor,PlayState* play){if((u16)actor->params==0x7E00&&((EnKo*)actor)->unk_210)Collider_DestroyCylinder(play,&((EnKo*)actor)->collider); }\nActorProfile Sonichu_V70_Profile=')
s=s.replace('sizeof(Actor),Sonichu_Init,NULL,','sizeof(EnKo),Sonichu_Init,Sonichu_Destroy,');write(rel,s)
# Keep Field room data unchanged: only the private overlay owns the outdoor models.
folder='extracted/pal-1.0/assets/scenes/overworld/spot00/'
write(folder+'mint_field_models_v71.inc.c',(R/'tools/mint_field_body_v71.inc.c').read_text()+(R/'tools/mint_field_head_v71.inc.c').read_text());rel=folder+'spot00_room_0.c';write(rel,original(rel))
p=next((O/folder).glob('*030007C4_ActorEntryList.inc.c'));rel=str(p.relative_to(O));s=original(rel);n=s.count('ACTOR_');write(rel,s+'    {ACTOR_SONICHU_V70,{4750,200,8420},{0,-16384,0},0x7E00}, /* adult Kokiri after Forest Temple */\n');rel=folder+'spot00_room_0.h';h=original(rel);macro='LENGTH_'+p.name.removesuffix('.inc.c');h,k=re.subn(r'(#define '+macro+' )'+str(n)+r'\b',lambda m:m[1]+str(n+1),h);assert k==1;write(rel,h)
# Replace an existing, clearly filmed early-party Kokiri; no extra dancer or object slot.
folder='extracted/pal-1.0/assets/scenes/overworld/spot20/';write(folder+'mint_party_head_v71.inc.c',(R/'tools/mint_party_head_v71.inc.c').read_text());rel=folder+'spot20_room_0.c';write(rel,original(rel)+'\n#include "mint_party_head_v71.inc.c"\n')
p=next((O/folder).glob('*03000CB0_ActorEntryList.inc.c'));rel=str(p.relative_to(O));s=original(rel);pat=r'(ACTOR_DEMO_EC,\s*\{\s*-170,\s*0,\s*-197\s*\},[^}]+)(0x0000)(\s*\},[^\n]*\n\s*0x000E)';s,k=re.subn(pat,lambda m:m[1]+'0x0071'+m[3],s);assert k==1;s=s.replace('{   -170,      0,   -197 }','{185,0,-318}').replace('0x693F,  0x0071','0x1800,  0x0071');write(rel,s)
rel='src/overlays/actors/ovl_Demo_Ec/mint_credits_v69.inc.c';s=original(rel);s=s.replace('actor->home.rot.z == 0x69','(actor->home.rot.z == 0x69 || actor->home.rot.z == 0x71)');s='extern u64 gMintPartyHeadV71[];\n'+s
needle='    if (limbIndex == 15) {\n';replacement=needle+'''        if(((Actor*)thisx)->home.rot.z==0x71){
            void* head=(u8*)play->roomCtx.curRoom.segment+SEGMENT_OFFSET(gMintPartyHeadV71);
            pos->x-=300.0f;gSPSegment((*gfx)++,6,head);
            gSPSegment((*gfx)++,0x0A,(u8*)head+((play->gameplayFrames%120<4)?0x1690:0xE90));
            *dList=(Gfx*)0x06000800;return false;
        }
''';s=s.replace(needle,replacement,1);write(rel,s)
rel='src/overlays/actors/ovl_Demo_Ec/z_demo_ec.c';s=original(rel);s=s.replace('slot>=0 && Object_IsLoaded(&play->objectCtx,slot))','(this->actor.home.rot.z==0x71 || (slot>=0 && Object_IsLoaded(&play->objectCtx,slot))))');write(rel,s)
# New dialogue only; preserve all existing messages and all child magic code.
rel='extracted/pal-1.0/text/message_data.h';s=original(rel);assert'7238'not in messages(s);L=Layout(O);text="{name} jo was geht? Du wunderst dich bestimmt mich hier zu sehen hab ich recht oder hab ich recht? Ich habe an einer neuen Magie gearbeitet. Meine Experimente haben sich bezahlt gemacht. Die Kokiri werden bald alle in der Lage sein diesen Wald zu verlassen ohne in der Außenwelt zu sterben. Das ist revolutionär man, jaaa haha, right on!";lines=L.wrap(text,210);body,_=rewrite('COLOR(DEFAULT) ""',dict(pages=['\n'.join(lines[i:i+4])for i in range(0,len(lines),4)]),L,'7238');block='DEFINE_MESSAGE(0x7238, TEXTBOX_TYPE_BLACK, TEXTBOX_POS_VARIABLE,\nMSG(/* MISSING */),\nMSG("Hey!"),\nMSG('+body+'),\nMSG("Salut!")\n)\n';at=re.search(r'DEFINE_MESSAGE\(0x(?:FFFC|FFFD)',s);at=at.start()if at else len(s);write(rel,s[:at]+block+s[at:]);print('Mint story V71: adult field after Forest Temple; native early-party dance, forest credits pose unchanged.')

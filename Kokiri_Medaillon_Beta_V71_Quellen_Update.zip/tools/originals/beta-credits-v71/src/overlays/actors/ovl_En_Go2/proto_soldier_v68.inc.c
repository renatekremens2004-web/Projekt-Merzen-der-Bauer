#include "assets/objects/object_oF1s/object_oF1s.h"
static s32 EnGo2_IsEarlyV65(Actor* a) { return (u16)a->params==0x7F5C||(u16)a->params==0x7F5B; }
static void EnGo2_InitEarlyV65(EnGo2* this,PlayState* play) {
    s32 slot;u32 old;
    this->isAwake=false;
    if(gSaveContext.gameMode!=GAMEMODE_NORMAL||((u16)this->actor.params==0x7F5B?(!LINK_IS_ADULT||play->sceneId!=SCENE_HYRULE_FIELD):(!LINK_IS_CHILD||play->sceneId!=SCENE_DEATH_MOUNTAIN_TRAIL))){Actor_Kill(&this->actor);return;}
    slot=Object_GetSlot(&play->objectCtx,OBJECT_OF1S);
    if(slot<0){Actor_Kill(&this->actor);return;}
    if(!Object_IsLoaded(&play->objectCtx,slot)){this->actor.flags=ACTOR_FLAG_UPDATE_CULLING_DISABLED;return;}
    old=gSegments[6];gSegments[6]=OS_K0_TO_PHYSICAL(play->objectCtx.slots[slot].segment);
    SkelAnime_InitFlex(play,&this->skelAnime,&object_oF1s_Skel_000110,NULL,this->jointTable,this->morphTable,18);
    gSegments[6]=old;Animation_PlayLoop(&this->skelAnime,&gGoronAnim_010590);
    this->actor.flags=ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_FRIENDLY|ACTOR_FLAG_UPDATE_CULLING_DISABLED;
    this->actor.naviEnemyId=0xFF;this->actor.attentionRangeType=ATTENTION_RANGE_1;
    Actor_SetScale(&this->actor,.01f);ActorShape_Init(&this->actor.shape,0,ActorShadow_DrawCircle,26);
    Collider_InitCylinder(play,&this->collider);Collider_SetCylinder(play,&this->collider,&this->actor,&sCylinderInit);
    this->collider.base.atFlags=AT_NONE;this->collider.base.acFlags=AC_NONE;
    this->collider.dim.radius=22;this->collider.dim.height=68;this->actor.colChkInfo.mass=MASS_IMMOVABLE;
    this->actor.textId=(u16)this->actor.params==0x7F5B?0x7234:0x7230;this->dialogState=0;this->isAwake=true;
}
static void EnGo2_UpdateEarlyV65(EnGo2* this,PlayState* play) {
    if(!this->isAwake){EnGo2_InitEarlyV65(this,play);return;}
    SkelAnime_Update(&this->skelAnime);
    if((u16)this->actor.params==0x7F5B){s32 i;for(i=11;i<=13;i++)this->jointTable[i]=sGoronSoldierV39Pose[i];}
    Actor_UpdateBgCheckInfo(play,&this->actor,0,0,0,UPDBGCHECKINFO_FLAG_2);
    if(this->actor.floorHeight>BGCHECK_Y_MIN+10)this->actor.world.pos.y=this->actor.floorHeight;
    Actor_SetFocus(&this->actor,60);this->actor.textId=(u16)this->actor.params==0x7F5B?0x7234:0x7230;
    if(Actor_TalkOfferAccepted(&this->actor,play))this->dialogState=1;
    if(this->dialogState&&Message_GetState(&play->msgCtx)==TEXT_STATE_CLOSING)this->dialogState=0;
    if(!this->dialogState)Actor_OfferTalk(&this->actor,play,110);
    Collider_UpdateCylinder(&this->actor,&this->collider);CollisionCheck_SetOC(play,&play->colChkCtx,&this->collider.base);
}
extern Gfx gProtoPistolV68DL[];
static void EnGo2_DrawEarlyV65(EnGo2* this,PlayState* play) {
    s32 slot=Object_GetSlot(&play->objectCtx,OBJECT_OF1S);u32 old=gSegments[6];
    SoldierV39Matrices ctx;ctx.goron=this;ctx.handFound=ctx.headFound=ctx.torsoFound=false;
    if(!this->isAwake||slot<0||!Object_IsLoaded(&play->objectCtx,slot))return;
    gSegments[6]=OS_K0_TO_PHYSICAL(play->objectCtx.slots[slot].segment);
    OPEN_DISPS(play->state.gfxCtx,"early goron",0);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
    gSPSegment(POLY_OPA_DISP++,6,play->objectCtx.slots[slot].segment);
    gSPSegment(POLY_OPA_DISP++,8,SEGMENTED_TO_VIRTUAL(object_oF1s_Blob_00217C));
    if((u16)this->actor.params==0x7F5B){
        s32 hat=Object_GetSlot(&play->objectCtx,OBJECT_GORON_SOLDIERS_V39);
        SkelAnime_DrawFlexOpa(play,this->skelAnime.skeleton,this->jointTable,this->skelAnime.dListCount,NULL,EnGo2_SoldierV39Post,&ctx);
        if(ctx.handFound){Matrix_Push();Matrix_Put(&ctx.hand);Matrix_Translate(600.0f,-400.0f,450.0f,MTXMODE_APPLY);Matrix_Scale(.70f,.70f,.70f,MTXMODE_APPLY);Matrix_Translate(-600.0f,400.0f,-450.0f,MTXMODE_APPLY);gSPMatrix(POLY_OPA_DISP++,MATRIX_FINALIZE(play->state.gfxCtx,"proto pistol",2),G_MTX_LOAD|G_MTX_MODELVIEW|G_MTX_NOPUSH);gSPDisplayList(POLY_OPA_DISP++,gProtoPistolV68DL);Matrix_Pop();}
        if(ctx.headFound&&hat>=0&&Object_IsLoaded(&play->objectCtx,hat)){
            gSPSegment(POLY_OPA_DISP++,6,play->objectCtx.slots[hat].segment);
            Matrix_Push();Matrix_Put(&ctx.head);Matrix_Scale(.95f,.95f,.95f,MTXMODE_APPLY);
            gSPMatrix(POLY_OPA_DISP++,MATRIX_FINALIZE(play->state.gfxCtx,"proto helmet",3),G_MTX_LOAD|G_MTX_MODELVIEW|G_MTX_NOPUSH);gSPDisplayList(POLY_OPA_DISP++,gGoronSoldierV39HelmetDL);Matrix_Pop();
        }
    }else{
    SkelAnime_DrawFlexOpa(play,this->skelAnime.skeleton,this->jointTable,this->skelAnime.dListCount,NULL,NULL,this);
    }
    gSegments[6]=old;gSPSegment(POLY_OPA_DISP++,6,OS_PHYSICAL_TO_K0(old));
    CLOSE_DISPS(play->state.gfxCtx,"early goron",1);
    Gfx_SetupDL_25Opa(play->state.gfxCtx);
}

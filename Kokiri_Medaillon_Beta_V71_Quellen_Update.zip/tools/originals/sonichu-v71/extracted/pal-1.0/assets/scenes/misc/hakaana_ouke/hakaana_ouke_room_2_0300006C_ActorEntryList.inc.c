    {
        ACTOR_EN_OKARINA_TAG,
        {      0,    127,  -1200 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x17FF, // params
    }, // 0
    {
        ACTOR_OBJ_SYOKUDAI,
        {     60,     60,  -1112 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x2400, // params
    }, // 1
    {
        ACTOR_OBJ_SYOKUDAI,
        {    -60,     60,  -1112 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x2400, // params
    }, // 2

    {ACTOR_SONICHU_V70,{0,120,-1140},{0,0,0},0}, /* face-up medallion on the flat platform beside the Sun Song inscription */

#include "ultra64.h"
#include "actor.h"
#include "play_state.h"
#include "save.h"
#include "gfx.h"
#include "gfx_setupdl.h"
#include "sys_matrix.h"
#include "z_lib.h"
#include "segmented_address.h"
extern Gfx gSonichuV70DL[];
static void Sonichu_Init(Actor* actor,PlayState* play) {
 if(play->sceneId!=SCENE_ROYAL_FAMILYS_TOMB||actor->room!=2||gSaveContext.gameMode!=GAMEMODE_NORMAL){Actor_Kill(actor);return;}
 actor->flags=ACTOR_FLAG_ATTENTION_ENABLED|ACTOR_FLAG_TALK_WITH_C_UP|ACTOR_FLAG_UPDATE_CULLING_DISABLED;
 actor->attentionRangeType=ATTENTION_RANGE_0;actor->naviEnemyId=0xFF;actor->textId=0x7237;
 Actor_SetScale(actor,.01f);ActorShape_Init(&actor->shape,0,NULL,0);
 Actor_UpdateBgCheckInfo(play,actor,0,0,0,UPDBGCHECKINFO_FLAG_2);
 if(actor->floorHeight>BGCHECK_Y_MIN+10)actor->world.pos.y=actor->floorHeight+1;
 Actor_SetFocus(actor,3);
}
static void Sonichu_Update(Actor* actor,PlayState* play) {Actor_TalkOfferAccepted(actor,play);Actor_SetFocus(actor,3);}
static void Sonichu_Draw(Actor* actor,PlayState* play) {
 void* room=NULL;
 if(actor->room==play->roomCtx.curRoom.num)room=play->roomCtx.curRoom.segment;
 else if(actor->room==play->roomCtx.prevRoom.num)room=play->roomCtx.prevRoom.segment;
 if(room==NULL)return;
 OPEN_DISPS(play->state.gfxCtx,"sonichu floor prop",0);
 Gfx_SetupDL_25Opa(play->state.gfxCtx);
 gSPSegment(POLY_OPA_DISP++,3,room);
 MATRIX_FINALIZE_AND_LOAD(POLY_OPA_DISP++,play->state.gfxCtx,"sonichu floor prop",1);
 gSPDisplayList(POLY_OPA_DISP++,gSonichuV70DL);
 gSPSegment(POLY_OPA_DISP++,3,OS_PHYSICAL_TO_K0(gSegments[3]));
 CLOSE_DISPS(play->state.gfxCtx,"sonichu floor prop",2);
}
ActorProfile Sonichu_V70_Profile={ACTOR_SONICHU_V70,ACTORCAT_PROP,ACTOR_FLAG_UPDATE_CULLING_DISABLED,OBJECT_GAMEPLAY_KEEP,sizeof(Actor),Sonichu_Init,NULL,Sonichu_Update,Sonichu_Draw};

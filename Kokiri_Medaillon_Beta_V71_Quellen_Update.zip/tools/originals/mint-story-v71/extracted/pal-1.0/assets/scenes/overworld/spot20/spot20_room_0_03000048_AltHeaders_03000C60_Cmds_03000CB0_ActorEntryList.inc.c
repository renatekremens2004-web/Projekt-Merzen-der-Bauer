    {
        ACTOR_DEMO_EC,
        {     -1,      0,   -280 }, // pos
        {  0x0000, -0x7DDE,  0x0000 }, // rot
         0x0000, // params
    }, // 0
    {
        ACTOR_DEMO_EC,
        {     -1,      0,   -280 }, // pos
        {  0x0000, -0x7DDE,  0x0000 }, // rot
         0x0001, // params
    }, // 1
    {
        ACTOR_DEMO_EC,
        {   -129,      0,   -166 }, // pos
        {  0x0000,  0x73E9,  0x0000 }, // rot
         0x0013, // params
    }, // 2
    {
        ACTOR_DEMO_EC,
        {    -89,      0,   -295 }, // pos
        {  0x0000,  0x6EEF,  0x0000 }, // rot
         0x000F, // params
    }, // 3
    {
        ACTOR_DEMO_EC,
        {     40,      0,   -263 }, // pos
        {  0x0000, -0x71C7,  0x0000 }, // rot
         0x0013, // params
    }, // 4
    {
        ACTOR_DEMO_EC,
        {      8,      0,   -174 }, // pos
        {  0x0000, -0x7D28,  0x0000 }, // rot
         0x000F, // params
    }, // 5
    {
        ACTOR_DEMO_EC,
        {    -33,      0,   -336 }, // pos
        {  0x0000,  0x760B,  0x0000 }, // rot
         0x001F, // params
    }, // 6
    {
        ACTOR_DEMO_EC,
        {    -85,      0,   -379 }, // pos
        {  0x0000,  0x65B0,  0x0000 }, // rot
         0x001F, // params
    }, // 7
    {
        ACTOR_DEMO_EC,
        { 200, 0, -530 }, // pos
        {  0x0000, -0x65B0,  0x0000 }, // rot
         0x001E, // params
    }, // 8
    {
        ACTOR_DEMO_EC,
        {    -81,      0,    -82 }, // pos
        {  0x0000, -0x7F4A,  0x0000 }, // rot
         0x001E, // params
    }, // 9
    {
        ACTOR_DEMO_EC,
        {   -151,      0,   -112 }, // pos
        {  0x0000,  0x71C7,  0x0000 }, // rot
         0x001E, // params
    }, // 10
    {
        ACTOR_DEMO_EC,
        { 184, 0, -402 }, // pos
        {  0x0000, -0x69F5,  0x0000 }, // rot
         0x001E, // params
    }, // 11
    {
        ACTOR_DEMO_EC,
        {   -170,      0,   -197 }, // pos
        {  0x0000,  0x693F,  0x0000 }, // rot
         0x000E, // params
    }, // 12
    {
        ACTOR_DEMO_EC,
        {    -79,      0,   -158 }, // pos
        {  0x0000, -0x7F4A,  0x0000 }, // rot
         0x000F, // params
    }, // 13
    {
        ACTOR_DEMO_EC,
        {     85,      0,   -170 }, // pos
        {  0x0000, -0x6CCD,  0x0000 }, // rot
         0x0013, // params
    }, // 14
    {
        ACTOR_EN_LIGHT,
        {    -82,      0,   -515 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03F5, // params
    }, // 15
    {
        ACTOR_EN_LIGHT,
        {    -60,      0,   -445 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03F6, // params
    }, // 16
    {
        ACTOR_EN_LIGHT,
        {    -73,      0,   -548 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03F7, // params
    }, // 17
    {
        ACTOR_EN_LIGHT,
        {    -79,      0,   -482 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03F8, // params
    }, // 18
    {
        ACTOR_EN_LIGHT,
        {    -27,      0,   -427 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03F9, // params
    }, // 19
    {
        ACTOR_EN_LIGHT,
        {     84,      0,   -556 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03FA, // params
    }, // 20
    {
        ACTOR_EN_LIGHT,
        {     96,      0,   -520 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03FB, // params
    }, // 21
    {
        ACTOR_EN_LIGHT,
        {     99,      0,   -489 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03FC, // params
    }, // 22
    {
        ACTOR_EN_LIGHT,
        {     79,      0,   -452 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03FD, // params
    }, // 23
    {
        ACTOR_EN_LIGHT,
        {     15,      0,   -416 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03FE, // params
    }, // 24
    {
        ACTOR_EN_LIGHT,
        {     45,      0,   -429 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x03FF, // params
    }, // 25

    { ACTOR_ELF_MSG2, { 25, 0, -415 }, { 0, 9000, 0 }, 0x3FA0 }, /* V29 skipper_v26 */
    { ACTOR_ELF_MSG2, { 130, 0, -325 }, { 0, -5000, 0 }, 0x3FA1 }, /* V29 kowalski_v26 */
    { ACTOR_ELF_MSG2, { 230, 0, -225 }, { 0, -19000, 0 }, 0x3FA2 }, /* V29 private_v26 */
    { ACTOR_ELF_MSG2, { 245, 0, -315 }, { 0, -15000, 0 }, 0x3FA3 }, /* V29 rico_v26 */
    { ACTOR_ELF_MSG2, { -45, 0, -225 }, { 0, 26000, 0 }, 0x3FA4 }, /* V29 pingu_v25 */

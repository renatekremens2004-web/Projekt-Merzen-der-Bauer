/* Use the existing Kokiri dance and body; replace only this marked dancer's head. */
static s32 DemoEc_IsMintV69(Actor* actor, PlayState* play) {
    return actor->params == 14 && actor->home.rot.z == 0x69 &&
           play->sceneId == SCENE_LON_LON_RANCH && gSaveContext.gameMode == GAMEMODE_END_CREDITS;
}
static s32 DemoEc_MintHeadV69(PlayState* play, s32 limbIndex, Gfx** dList, Vec3f* pos,
                             Vec3s* rot, void* thisx, Gfx** gfx) {
    s32 slot;
    u32 savedSegment;
    if (limbIndex == 15) {
        slot = Object_GetSlot(&play->objectCtx, OBJECT_OE9);
        savedSegment = gSegments[6];
        gSegments[6] = OS_K0_TO_PHYSICAL(play->objectCtx.slots[slot].segment);
        pos->x -= 300.0f;
        gSPSegment((*gfx)++, 0x06, play->objectCtx.slots[slot].segment);
        gSPSegment((*gfx)++, 0x0A, SEGMENTED_TO_VIRTUAL(
            (play->gameplayFrames % 120 < 4) ? object_oE9_Tex_001690 : object_oE9_Tex_000E90));
        *dList = object_oE9_DL_000800;
        gSegments[6] = savedSegment;
    }
    return false;
}
static void DemoEc_MintHeadPostV69(PlayState* play, s32 limbIndex, Gfx** dList,
                                  Vec3s* rot, void* thisx, Gfx** gfx) {
    DemoEc* this = (DemoEc*)thisx;
    if (limbIndex == 15) {
        gSPSegment((*gfx)++, 0x06, play->objectCtx.slots[this->drawObjectSlot].segment);
    }
}

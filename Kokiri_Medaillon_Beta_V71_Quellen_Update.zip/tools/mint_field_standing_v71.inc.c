static s16 sMintFieldStandingFramesV71[]={
     0x0000, // 0
     0x0874, // 1
    -0x016, // 2
    -0x4000, // 3
    -0x93F, // 4
    -0xC17, // 5
    -0x416C, // 6
     0x093F, // 7
     0x0C17, // 8
     0x7444, // 9
    -0x5E0, // 10
     0x489D, // 11
     0x4AF8, // 12
     0x43A2, // 13
     0x3856, // 14
     0x18DB, // 15
     0x105F, // 16
     0x07E9, // 17
     0x55A6, // 18
     0x138F, // 19
    -0x433A, // 20
    -0x38E, // 21
     0x1185, // 22
     0x025F, // 23
     0x095F, // 24
     0x04FB, // 25
     0x0505, // 26
    -0x9DA, // 27
    -0x9D5, // 28
     0x029B, // 29
     0x0272, // 30
     0x0000, // 31
     0x0053, // 32
    -0x4FB, // 33
    -0x505, // 34
     0x09DA, // 35
     0x09D5, // 36
     0x029B, // 37
     0x0272, // 38
     0x0000, // 39
     0x0053, // 40
     0x0000, // 41

};
static JointIndex sMintFieldStandingJointsV71[]={
    {
        0, // x
        1, // y
        2, // z
    }, // 0
    {
        3, // x
        0, // y
        3, // z
    }, // 1
    {
        25, // x
        27, // y
        29, // z
    }, // 2
    {
        0, // x
        0, // y
        31, // z
    }, // 3
    {
        4, // x
        5, // y
        6, // z
    }, // 4
    {
        33, // x
        35, // y
        37, // z
    }, // 5
    {
        0, // x
        0, // y
        39, // z
    }, // 6
    {
        7, // x
        8, // y
        6, // z
    }, // 7
    {
        0, // x
        0, // y
        9, // z
    }, // 8
    {
        0, // x
        10, // y
        11, // z
    }, // 9
    {
        12, // x
        13, // y
        14, // z
    }, // 10
    {
        15, // x
        16, // y
        0, // z
    }, // 11
    {
        0, // x
        17, // y
        18, // z
    }, // 12
    {
        19, // x
        20, // y
        21, // z
    }, // 13
    {
        22, // x
        23, // y
        0, // z
    }, // 14
    {
        0, // x
        0, // y
        24, // z
    }, // 15

};
static AnimationHeader sMintFieldStandingAnimV71={
    {
        2, // frameCount
    }, // common
    sMintFieldStandingFramesV71, // frameData
    sMintFieldStandingJointsV71, // jointIndices
    25, // staticIndexMax

};

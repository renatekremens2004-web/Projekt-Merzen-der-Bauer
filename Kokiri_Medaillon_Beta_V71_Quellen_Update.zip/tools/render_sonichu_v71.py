from pathlib import Path
import bpy,sys
from mathutils import Vector
args=sys.argv[sys.argv.index('--')+1:];source=Path(args[0]);W=Path(args[1]);W.mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=str(source))
obj=next(o for o in bpy.context.scene.objects if o.type=='MESH');bpy.context.view_layer.objects.active=obj;obj.select_set(True);bpy.ops.object.transform_apply(location=False,rotation=True,scale=True)
for mat in obj.data.materials:
 nodes=mat.node_tree.nodes;tex=next(n for n in nodes if n.type=='TEX_IMAGE');out=next(n for n in nodes if n.type=='OUTPUT_MATERIAL');em=nodes.new('ShaderNodeEmission');mat.node_tree.links.new(tex.outputs['Color'],em.inputs['Color']);mat.node_tree.links.new(em.outputs[0],out.inputs['Surface'])
p=[obj.matrix_world@v.co for v in obj.data.vertices];lo=Vector(tuple(min(v[i] for v in p)for i in range(3)));hi=Vector(tuple(max(v[i]for v in p)for i in range(3)));center=(lo+hi)/2
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=1;scene.cycles.use_denoising=False;scene.render.film_transparent=True;scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGBA';scene.render.resolution_x=512;scene.render.resolution_y=512;scene.render.resolution_percentage=100;scene.view_settings.view_transform='Standard';scene.view_settings.look='Medium High Contrast' if False else 'None'
bpy.ops.object.camera_add(location=center+Vector((0,-10,0)));camera=bpy.context.object;camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler();camera.data.type='ORTHO';camera.data.ortho_scale=max(hi.x-lo.x,hi.z-lo.z)*1.06;scene.camera=camera
scene.render.filepath=str(W/'original-front.png');bpy.ops.render.render(write_still=True)
camera.location=center+Vector((0,10,0));camera.rotation_euler=(center-camera.location).to_track_quat('-Z','Y').to_euler();scene.render.filepath=str(W/'original-back.png');bpy.ops.render.render(write_still=True)
print('ORIGINAL_BOUNDS',list(lo),list(hi))

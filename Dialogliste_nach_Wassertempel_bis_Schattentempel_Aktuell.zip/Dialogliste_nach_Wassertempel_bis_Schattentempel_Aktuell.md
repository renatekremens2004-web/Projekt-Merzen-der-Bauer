# Aktueller Dialog: nach Wassertempel bis Ende Schattentempel

Aus dem aktuellen deutschen Quellstand ausgelesen. Keine neuen Formulierungen für dieses Kapitel: Hier steht der tatsächlich eingebaute Wortlaut. Die gerade beauftragten Änderungen am Wasserabschnitt ändern diese Abschrift nicht.

Hauptteil: Kakarikos Ereignis, Windmühle, Brunnen, Schattentempel und Mr. Bean in der Halle der Weisen. Danach folgen optionale Ortsgespräche, Händler, Zielerfassungen und bedingte Rückbezüge. Diese Texte sind keine einzige lange Unterhaltung; je nach Fortschritt, Zeitlinie und Ansprache werden unterschiedliche IDs verwendet.

[Spielername] ist dynamisch. Die Seiten entsprechen den Textbox-Seiten. Auswahl und direkte Fortsetzungen sind markiert. Mr. Beans englische Sätze sind auch in der deutschen Spielfassung englisch.

Zum Bearbeiten genügt etwa: „5031, Seite 3 ersetzen durch …“.

## 1. Nach dem Wassertempel – Navi und Kakarikos brennender Brunnen

### 0154

Projekttext.
Navis Story-Hinweis nach dem Wasseramulett, vor Kakarikos Folgeereignis.

**Seite 1**

> Okay, supi! Langsam gehen uns die
> Orte aus. Also laß mal wieder zurück
> nach Kakariko gehen und die Mühle
> von dem einen Typen versauen!

### 501B

Noch vorhandener Originaltext.
Sheiks kurzer Warnruf zu Beginn des brennenden Kakariko-Ereignisses.

**Seite 1**

> Zurück, [Spielername]!

### 5030

Projekttext.

**Seite 1**

> Okay, ich sehe, Du hast noch genug
> Herzen. Na perfekt. Solltest aber
> vielleicht mal mehr Herzteile sammeln.

### 501C

Projekttext.

**Seite 1**

> [Spielername], es gab da einst
> einen Dämon, den jemand im Brunnen
> eingesperrt hat. Das war Mr. Bean!
> Nur er kommt auf sowas Verrücktes.

**Seite 2**

> Das absolute Genie, der Typ.

**Seite 3**

> Na ja, jetzt ist die Kraft des Dämons
> gewachsen. Irgendwie wegen Friedrich
> Merz. Der ist, glaube ich, selbst ein
> Dämon. Seine Frisur sieht zumindest

**Seite 4**

> dämonisch beschissen aus.

**Seite 5**

> Und das Siegel ist jetzt halt
> gebrochen, ne? Und ja, ist jetzt halt
> Mist, ne?

### 0155

Projekttext.
Bedingter Navi-Story-Hinweis. Nicht jede hier aufgeführte Navi-ID wird automatisch aufgerufen.

**Seite 1**

> Okay, das komische Ding kam
> eindeutig aus dem Brunnen. Glaubst
> Du, das wird jetzt der nächste
> Dungeon sein? Einfach so? Der

**Seite 2**

> Brunnen von Kakariko? Müssen wir
> dann das Brunnenlied lernen?

## 2. Sheik und Nocturne des Schattens

### 5031

Projekttext.

**Seite 1**

> [Spielername], leider ist Mr. Bean
> nicht mehr hier. Damals hat er Zelda
> bei der Flucht aus dem Schloß gut
> beschützt. Davon hast Du ja sogar

**Seite 2**

> geträumt.

**Seite 3**

> Dann verlor er gegen Merz. Die haben
> krass gekämpft, aber Merz spielte
> unfair. Muß man einfach sagen.

**Seite 4**

> Heute kein großer Reim. Ich wußte
> nichts vom Schattentempel! Das Blut,
> die Schädel... Als hätte man da Leute
> gefoltert.

**Seite 5**

> Schon beim Brunnen denkt man: War
> dieser Dämon ein Serienmörder?
> Spannende Theorie. Aber der Tempel
> ist ja auch nicht besser.

**Seite 6**

> Und das war kein einzelner irrer
> Täter, sondern Hyrule selbst. Das ist
> jetzt ein bißchen unglücklich.

**Seite 7**

> Versetzen wir das ganz weit in die
> Vergangenheit. Nicht bloß sieben
> Jahre! Machen wir erst mal einen
> hohen Bogen drum.

**Seite 8**

> Das werden wir bei Zeit mal
> aufarbeiten. Der Zugang liegt hinter
> dem Friedhof. Mr. Bean ist der Weise
> des Schattens.

**Seite 9**

> Besiege den Dämon. Dann lerne jetzt
> die Nocturne des Schattens, unseren
> neuen Teleport-Song.

### 0077

Noch vorhandener Originaltext.

**Seite 1**

> Du hast die
> Nocturne des Schattens
> erlernt!

### 501D

Projekttext.

**Seite 1**

> [Spielername], Du weißt, was zu
> tun ist. Du kannst auch in den
> Geistertempel gehen, falls Du da
> nicht schon warst. Ich würde erst

**Seite 2**

> den Schattentempel machen. Der
> Dämon kam ja gerade ganz frisch aus
> dem Brunnen, ne?

### 0157

Projekttext.
Bedingter Navi-Hinweis nach Erlernen der Nocturne.

**Seite 1**

> Alles klar, ich wollte schon immer
> mal einen Song haben, mit dem wir
> zum ekligsten und gefährlichsten Ort
> Hyrules zurückreisen können.

## 3. Windmühle als Erwachsener – Hymne des Sturms

### 5034

Projekttext.
Erwachsener Windmühlenmann vor dem Vorspielen auf der Okarina.

**Seite 1**

> Auch nach sieben Jahren bin ich
> immer noch sowas von wütend. Ich
> stehe jeden Tag mit einem wütenden
> Gefühl auf und ziehe mir meine

**Seite 2**

> wütenden Schuhe an.

**Seite 3**

> Der hat meine ganze Mühle
> geschrottet. Das ist unfaßbar.

**Seite 4**

> Sag mal, wißt ihr eigentlich, wie
> teuer dieser ganze Schuppen hier
> gewesen ist?

### 5035

Projekttext.
Okarina-Gespräch als Erwachsener; danach wird die Hymne der Stürme beigebracht.

**Seite 1**

> Ey, ich werde wahnsinnig. Das ist
> doch jetzt... Sag mir bitte nicht, daß
> das eine Okarina ist.

**Seite 2**

> Sag mir nicht, daß Du der Wichser
> von damals gewesen bist, sonst
> werde ich Dir so in die Fresse hauen.

**Seite 3**

> Irgendjemand hat damals diese
> absolut bescheuerte Regenmusik
> gespielt. Warum gibt es sowas
> überhaupt? Warum erlauben die

**Seite 4**

> Götter das?

**Seite 5**

> Ich erkläre Dir jetzt das Lied, einfach
> nur damit Du weißt, daß Du es auf
> keinen Fall spielen sollst. Jetzt ist es
> sowieso zu spät.

**Seite 6**

> Gott sei Dank hast Du keine
> Zeitmaschine oder so.

### 00D6

Noch vorhandener Originaltext.

**Seite 1**

> Du hast die
> Hymne des Sturms
> erlernt!

### 508E

Projekttext.

**Seite 1**

> Oh nein, das war ein Fehler!

## 4. Zurück als Kind – Windmühle und Entleeren des Brunnens

### 5032

Projekttext.
Kindervariante des Windmühlenmannes vor dem Regenlied.

**Seite 1**

> Ich bin so stinkig, mein Blut kocht,
> ich könnte explodieren! Mir geht der
> Hut hoch!

**Seite 2**

> Ein Kind, das eins zu eins aussieht
> wie Du, wird eines Tages diese ganze
> Mühle mit seiner bekloppten
> Regenmusik zerstören!

**Seite 3**

> Ich hoffe, das wirst nicht Du sein!
> Ich übe diese Beschwerde vorsorglich
> seit Wochen.

### 5033

Projekttext.
Reaktion auf die ruinierte Windmühle in der Kindheit.

**Seite 1**

> Was zur Hölle geht hier vor sich? Du
> hast meine Mühle zerstört! Du hast
> alles kaputtgemacht! Diese Mühle hat
> mit meinem Einkommen zu tun. Wenn

**Seite 2**

> ich nicht genug Kram mühle, lande ich
> auf der Straße!

## 5. Brunnen – Shaggy, Velma, Daphne, Scooby und Fred

### 71BA

Projekttext.
Shaggy; freiwilliges Gespräch im Brunnen.

**Seite 1**

> ZOINKS! Hier ist echt ne Menge Blut.
> Ich hatte gehofft, das ist KETCHUP!

**Seite 2**

> Da vergeht einem echt der Appetit...
> Wobei, was rede ich denn DA!

**Seite 3**

> Ein leckeres Sandwich wäre jetzt
> doch genau das Richtige. Hmm!

### 71BB

Projekttext.
Velma; eigener Platz im Brunnen.

**Seite 1**

> JINKIES! Der Gestank hier unten ist
> unbeschreiblich ekelig. Es riecht nach
> Schwefel und Eisen.

**Seite 2**

> Ob es wirklich so gut war, daß wir
> uns aufteilen? Ich hoffe, die anderen
> sind vorsichtig...

### 71BC

Projekttext.
Daphne; eigener Platz im Brunnen.

**Seite 1**

> JEEPERS! Hier unten sollte echt mal
> geputzt werden. Und das ist definitiv
> kein Platz für Kinder wie Dich!

**Seite 2**

> Wo ist überhaupt Fred? Wobei,
> Velma dürfte mich natürlich auch
> gerne begleiten...

**Seite 3**

> Mit ihr würde ich mich hier gleich
> viel wohler fühlen. Und das liegt nicht
> nur an ihrer Taschenlampe.

### 71BD

Projekttext.
Scooby-Doo; eigener Platz im Brunnen.

**Seite 1**

> Ruh-roh! Rer Brunnen ist riel zu
> gruselig! Wo ist Raggy?

**Seite 2**

> Für einen Scooby-Snack würde ich ja
> bleiben... Zwei? Rein, lieber drei!

**Seite 3**

> Scooby-Dooby-Doo! Aber jetzt bitte
> raus hier!

### 71BE

Projekttext.
Fred; eigener Platz im Brunnen.

**Seite 1**

> FUCK! Hier unten gibt es echt eine
> Menge Fallen, und ich Idiot habe
> natürlich mein Notizbuch vergessen!

**Seite 2**

> Wie schade. Blöder, blöder Fred! Was
> bin ich nur für ein Hornochse!

**Seite 3**

> Eine Falle MIT einer Falle zu fangen,
> wäre so schön gewesen. Aber ohne
> Notizbuch? Das wäre unprofessionell.

## 6. Brunnen – Schwangerschaftstest, Organe und Starwalker

### 608B

Projekttext.
Navi beim Anvisieren des Schwangerschaftstests.

**Seite 1**

> Oof, hier liegt ein
> Schwangerschaftstest.
> Mein Beileid...

### 71E4

Projekttext.
Navi beim Anvisieren der Organe auf dem roten Boden.

**Seite 1**

> Ohhh...nooooo....Lass uns bitte nicht
> zu viel Zeit hier unten verbringen,
> ja?

### 721F

Noch vorhandener Originaltext.
Original Starwalker im Brunnen; Pause vor seinem Namen.

**Seite 1**

> Those meddling kids and their dog are
> pissing me off.
> I'm the original Starwalker

## 7. Brunnen und Schattentempel – örtliche Navi-Untersuchungen

### 0126

Projekttext.
Auslöser: Brunnen – Raum 0.

**Seite 1**

> Ich höre in diesem Raum geisterhafte
> Stimmen flüstern.

**Seite 2**

> Mir doch scheißegal, was die zu
> sagen haben. Ich ignoriere die einfach.

### 0128

Projekttext.
Auslöser: Schattentempel – Raum 19.

**Seite 1**

> Die Geister in diesem Raum sind
> schon wieder am Flüstern.

**Seite 2**

> Sie flüstern mir zu.

**Seite 3**

> Okay, die sollen mal aufhören, mich
> zu belästigen, die Geister.

### 0129

Projekttext.
Auslöser: Brunnen – Raum 0.

**Seite 1**

> Da steht: "Alles Gute von oben." Das
> ist doch safe wieder ironisch gemeint.

### 012A

Projekttext.
Auslöser: Brunnen – Raum 0.

**Seite 1**

> Bei dieser Mauer steht irgendwas
> über Tiefe. Ob das mit dem Giant
> Squid zu tun hat?

### 012B

Projekttext.
Auslöser: Brunnen – Raum 0.

**Seite 1**

> Wäre es jetzt nicht witzig, das hier
> alles unter Wasser zu stellen?

### 0181

Projekttext.
Auslöser: Schattentempel – Raum 6.

**Seite 1**

> Jetzt redet auch noch diese
> bescheuerte Mauer mit mir.

**Seite 2**

> Wieso will alles in diesem Dungeon
> mit mir reden? Was soll das?

### 0184

Projekttext.
Auslöser: Schattentempel – Raum 21.

**Seite 1**

> Yo, siehst Du da vorne die Tür? Laß
> da mal gucken, ob wir da hinkommen
> können.

### 0191

Projekttext.
Auslöser: Brunnen – Raum 0, Schattentempel – Raum 9.

**Seite 1**

> Ich präsentiere: die nervigsten
> Gegner in diesem ganzen Abenteuer.

## 8. Brunnen – Auge der Wahrheit und Schattengewand

### 0039

Noch vorhandener Originaltext.

**Seite 1**

> Das Auge der Wahrheit!
> Plaziere es auf [C] und sieh
> mit [C] hindurch! Du wirst
> viele Geheimnisse lüften!

**Seite 2**

> Setzt Du es ein,
> kostet es magische Energie.
> Mit [C] kannst Du es auch
> wieder deaktivieren.

### 71DC

Projekttext.
Fundtext des Schattengewands. Der tatsächliche Buildtext wird unverändert abgeschrieben, einschließlich noch vorhandener Bezeichnungen.

**Seite 1**

> Du hast das Schattengewand
> gefunden!

**Seite 2**

> Es ersetzt Deine bisherige Kleidung
> und wird sofort angelegt. Das
> Gewand paßt Dir als Kind und als
> Erwachsener.

**Seite 3**

> Solange Du das Schattengewand
> trägst, nimmst Du nur noch ein
> Viertel des gewöhnlichen Schadens.

**Seite 4**

> Sonnen-, Feuer- und Wassergewand
> halbieren den Schaden. Das
> Schattengewand schützt Dich noch
> stärker.

## 9. Schattentempel – Wände, Statue und Warnungen

### 0208

Projekttext.
Auslöser: Schattentempel – Raum 0.

**Seite 1**

> Der Schattentempel. Hier ruhen
> Hyrules blutige Zeugnisse von großer
> Gier und blindem Haß. Es ist gar
> nicht mal so lange her.

### 0209

Noch vorhandener Originaltext.
Auslöser: Schattentempel – Raum 0.

**Seite 1**

> In der Dunkelheit verborgen...
> Das bloße Auge listig täuschend...
> Bleibt der rechte Weg verhüllt...

### 020A

Noch vorhandener Originaltext.
Auslöser: Schattentempel – Raum 0.

**Seite 1**

> Jenem mit dem Auge der Wahrheit
> wird sich manches offenbaren, was
> noch von Dunkelheit umgeben...

### 0224

Noch vorhandener Originaltext.
Auslöser: Schattentempel – Raum 2.

**Seite 1**

> Drehe meinen Schnabel zum
> Schädel der Wahrheit.

**Seite 2**

> Andernfalls stürzt Du in
> unendliche Dunkelheit!

### 022B

Noch vorhandener Originaltext.
Auslöser: Brunnen – Raum 0.

**Seite 1**

> Hier steht die Inschrift
> aus dem Wappen
> der Königsfamilie von Hyrule.

### 023C

Noch vorhandener Originaltext.
Auslöser: Schattentempel – Raum 2.

**Seite 1**

> Die Schatten werden sich nur dem
> offenbaren, der die Augen der
> Wahrheit besitzt. Es heißt, man
> könne sie in Kakariko finden...

## 10. Schattentempel – Kenny und Gleitstiefel

### 71B8

Projekttext.
Navi über den lebenden Kenny vor Erhalt der Gleitstiefel; Kenny ist hier ein anvisierbares Modell.

**Seite 1**

> Ich verstehe den Typen nicht, der
> nuschelt zu sehr.

### 0054

Noch vorhandener Originaltext.
Fundtext der Gleitstiefel; Steuerkreuz oben wechselt im aktuellen Hack die Stiefel.

**Seite 1**

> Die Gleitstiefel!
> Mit diesen seltsamen Schuhen
> schwebst Du über den Boden.

**Seite 2**

> Du kannst damit für
> kurze Zeit sogar Abgründe
> überqueren. Habe Mut und
> vertraue den Stiefeln!

### 71B9

Projekttext.
Navi über den toten Kenny im späteren Tempelabschnitt nach Erhalt der Gleitstiefel.

**Seite 1**

> Ihr habt Kenny getötet, ihr Schweine!

## 11. Schattentempel – Crocker, Skelett auf dem Schiff und Starwalker

### 6089

Projekttext.
Crockers Gespräch enthält Navis Antwort als ausdrücklich benannte weitere Seite derselben Nachricht.

**Seite 1**

> Blut auf dem Boden? Totenschädel in
> den Wänden?

**Seite 2**

> Seltsame Wände, durch die man
> hindurchgehen kann? Das kann nur
> eins bedeuten!

**Seite 3**

> Das ist das Werk von HELFENDEN
> ELFEN!!

**Seite 4**

> Navi: Ich bin eine Fee, Du anämischer
> Nerd!

### 7211

Projekttext.
Freundliches Skelett auf der Geisterfähre.

**Seite 1**

> RATTLE ME BONES!! WELCOME
> ABOARD MATEY!

### 721C

Noch vorhandener Originaltext.
Original Starwalker im Schattentempel; Pause vor seinem Namen.

**Seite 1**

> Those skulls are pissing me off.
> I'm the original Starwalker

### 5071

Noch vorhandener Originaltext.
Navi-Warnung beim Untergang der Geisterfähre.
Zeitgesteuerte Einblendung bzw. Textpause im Spiel.

**Seite 1**

> [Spielername]!
> Das Schiff sinkt!
> Spring ab!
> Rette Dich auf festen Boden!

## 12. Bongo Bongo – Navis Zielerfassung

### 0624

Projekttext.

**Seite 1**

> Roter Tod. Setzt sich selbst in Brand
> und rennt schreiend herum. Du bist
> wirklich ein saudummes Drecksvieh.

## 13. Halle der Weisen – Mr. Bean und Schattenamulett

### 5022

Projekttext.
Mr. Bean als Schattenweiser. Seine deutschen Sprachslots enthalten bewußt englische Sätze.

**Seite 1**

> [Spielername]! You did it! I was
> just coming to help.

**Seite 2**

> A Sage of Shadow? Me? I thought
> this was the shady waiting room.

### 5025

Projekttext.

**Seite 1**

> Merz says I died fighting him? How
> very flattering.

**Seite 2**

> I got Zelda out on horseback. Then
> there was a low branch.

**Seite 3**

> It caught my head. I fell off. Broke
> my neck.

**Seite 4**

> Very inconvenient. Zelda got away,
> though. That was rather the point.

**Seite 5**

> The Shadow Temple? Lovely place.
> Very peaceful.

**Seite 6**

> Rather a lot of sharp decorations. I
> recommend the back entrance.

### 502B

Projekttext.

**Seite 1**

> Zelda is safe. And my neck no longer
> hurts. One advantage, I suppose.

### 502C

Projekttext.

**Seite 1**

> You'll see Zelda soon.
> She explains things rather better.

**Seite 2**

> Six Sages. One Merz.
> I like those odds.

### 5026

Projekttext.

**Seite 1**

> Please look after Zelda. I'll stay off
> horses for a bit.

**Seite 2**

> Take my shadow power. Apparently I
> have some.

### 0041

Projekttext.

**Seite 1**

> Das Amulett des Schattens!
> Mr. Bean ist einer der
> Weisen. Er überträgt Dir
> seine Kraft!

### 5023

Projekttext.
Zeitgesteuerter Abschied; nur kurze Einblendung.
Zeitgesteuerte Einblendung bzw. Textpause im Spiel.

**Seite 1**

> Find Zelda.
> Tell her I helped.

## 14. Unmittelbarer Übergang zum nächsten Kapitel

### 0156

Projekttext.

**Seite 1**

> Aber warum heißt das Ding
> Geistertempel und nicht
> Wüstentempel? Müßte der
> Schattentempel nicht eher

**Seite 2**

> Geistertempel heißen? Was soll
> Schatten in diesem Zusammenhang
> überhaupt bedeuten?

### 0158

Projekttext.
Ausblick auf die Wüste nach diesem Kapitel; als Übergang enthalten.

**Seite 1**

> Na dann pack die Sonnencreme aus
> und nimm Dein Handtuch mit, es geht
> ab IN DIE WÜÜÜÜÜÜSTE!

## A. Kakariko – zusätzliche Figuren und Gespräche in der Zukunft

### 71C5

Projekttext.
Mr. Mackey in einem normalen Kakariko-Haus, nicht im Spinnenhaus.

**Seite 1**

> Ich bin Mr. Mackey, mhhkay? Und ich
> bin NICHT Friedrich Merz!

**Seite 2**

> Nur weil jemand einen großen Kopf
> und wenig Haare hat, ist er doch
> nicht gleich dieser Kerl, mhhkay!

**Seite 3**

> Gestern hat mich einer nach
> Steuersenkungen gefragt. Ich bin
> Schulberater, mhhkay!

**Seite 4**

> Dieses ständige Verwechseln ist nicht
> okay. Also wirklich nicht okay,
> mhhkay.

### 5085

Projekttext.

**Seite 1**

> Die Krabbelminen-Frau hat Zigaretten
> direkt neben den Krabbelminen
> geraucht.

**Seite 2**

> Der ganze Laden ist dadurch komplett
> explodiert. Dabei ist sie gestorben.

### 5086

Projekttext.

**Seite 1**

> Ist Dir schon mal aufgefallen, daß der
> Drache im Feuertempel irgendwie echt
> attraktiv ist?

**Seite 2**

> Was? Nein?! Ähh... Mir auch nicht!
> Wer denkt denn so was?

**Seite 3**

> Mega komisch einfach. Ich hab
> überhaupt keinen bestimmten Drachen
> gemeint.

**Seite 4**

> Volvagia heißt der übrigens. Also hab
> ich gehört. Zufällig.

### 505C

Projekttext.

**Seite 1**

> Hast Du diese seltsamen Kinder
> getroffen? Sie nennen sich Fanboy
> und Chum Chum.

**Seite 2**

> Halten sich für so 'ne Art
> Superhelden. Pah! Was Menschen
> nicht alles tun, um sich von der
> Arbeit zu drücken!

### 507D

Projekttext.

**Seite 1**

> Glaubst Du, Goronen stehen auf Rock
> and Ball Torture?

### 5088

Projekttext.

**Seite 1**

> Hab letztens so ein Horrorkid-Ding
> getroffen.

**Seite 2**

> Niedliches Kerlchen.

**Seite 3**

> Tut keiner Fliege was zuleide.

### 5089

Projekttext.

**Seite 1**

> Jetzt ist es schon sieben Jahre her,
> daß Waluigi von der Schule geflogen
> ist...

**Seite 2**

> ...und er hat immer noch nischts aus
> seinem Leben gemacht. Was ein
> Loser, meine Liebe!

### 508A

Projekttext.

**Seite 1**

> Waluigi? Dieser seltsame lila Typ?

**Seite 2**

> Was ein Loser. Aus dem wird doch
> eh nichts mehr, Liebling!

### 507B

Projekttext.

**Seite 1**

> Scheiße, ich hab' meinen Lego
> Naboo-Starfighter im Schattentempel
> liegen lassen!

**Seite 2**

> Und die Bauanleitung ist natürlich
> auch noch drin!

### 507C

Projekttext.

**Seite 1**

> Scheiße, ich hab' meinen Lego
> Naboo-Starfighter im Schattentempel
> liegen lassen!

**Seite 2**

> Und die Bauanleitung ist natürlich
> auch noch drin!

## B. Kakariko – Mr. Beans Haus und Reaktionen auf die Ereignisse

### 505B

Projekttext.

**Seite 1**

> He! Du kommst einfach in ein
> fremdes Haus? Was werden Deine
> Eltern dazu sagen?

**Seite 2**

> Na, egal...

**Seite 3**

> Das ist ohnehin nicht mein Haus. Hier
> wohnt der große Mr. Bean. Ein Mann
> von höchstem Ansehen!

**Seite 4**

> Er ging zum Friedhof, um eine
> widerliche Kreatur zu bezwingen. Auf
> Bean ist eben Verlaß.

**Seite 5**

> Seit Friedrich Merz hier sein Unwesen
> treibt, wimmelt es von solchen
> Scheußlichkeiten!

**Seite 6**

> Mr. Bean hat schon oft für Frieden im
> Dorf gesorgt. Sein Mut ist über jeden
> Zweifel erhaben.

**Seite 7**

> Nun gut.

**Seite 8**

> Er ist noch nicht zurück. Sicher hat
> er alles wohlüberlegt. Bean überläßt
> nichts dem Zufall.

### 505F

Projekttext.

**Seite 1**

> Mr. Bean ist fort. Wenn jemand die
> Lage im Griff hat, dann er. Trotzdem
> mache ich mir Sorgen.

### 5079

Projekttext.

**Seite 1**

> Hier lebte Mr. Bean. Er hat das Haus
> großzügig dem Dorf geöffnet. Ein
> vorbildlicher Mann!

**Seite 2**

> Auch Du darfst hinein. Bean vertraut
> seinen Mitmenschen.

### 507A

Noch vorhandener Originaltext.

**Seite 1**

> Dieses Dorf gehörte einst den
> Shiekah, aber jetzt kann jeder
> hier leben.

### 507E

Noch vorhandener Originaltext.

**Seite 1**

> Das Feuer hätte uns fast
> vernichtet! Aber gemeinsam haben
> wir es gelöscht! Gute Arbeit,
> denkst Du nicht auch?

### 505E

Noch vorhandener Originaltext.

**Seite 1**

> Fühle Dich ganz wie zu Hause.
> Das Essen ist allerdings
> noch nicht fertig!

### 505D

Projekttext.

**Seite 1**

> Willkommen in Kakariko! Bist Du zum
> ersten Mal hier?

**Seite 2**

> Mr. Bean ließ das Dorf für einfache
> Leute wie uns erbauen. Ein fähiger,
> großherziger Mann!

### 5063

Projekttext.

**Seite 1**

> Es ist [Uhrzeit] Uhr! Zeit, Dir etwas
> über Kakariko zu erzählen.

**Seite 2**

> Mr. Bean, Zeldas verläßlicher
> Beschützer, ließ dieses Dorf für
> einfache Leute wie uns erbauen.

**Seite 3**

> Noch sind wir wenige. Doch mit
> seinem klugen Rat wird hier bald das
> Leben blühen!

**Seite 4**

> Für den Aufstieg brauchst Du eine
> königliche Erlaubnis. Das sollte ein
> Mann wie Bean wissen.

### 5064

Noch vorhandener Originaltext.

**Seite 1**

> Es ist jetzt genau [Uhrzeit] Uhr.

### 5065

Noch vorhandener Originaltext.

**Seite 1**

> Es ist jetzt [Uhrzeit] Uhr.
> Ach, übrigens: Weißt Du, was im
> Schloß passiert ist?

### 5068

Noch vorhandener Originaltext.

**Seite 1**

> Ein komischer Typ lebt in der 
> Windmühle. Warst Du schon bei
> ihm, großer Held?

### 5069

Projekttext.

**Seite 1**

> Meine Eltern erklären mir ständig, daß
> ich später Verantwortung übernehmen
> muß. Die Erwachsenen haben Merz
> eingeladen. Ich habe Fragen.

## C. Kakariko – weitere erreichbare Ortsgespräche und Varianten

### 5029

Noch vorhandener Originaltext.

**Seite 1**

> Ich sage Dir: Die jungen
> Leute sind zu nichts mehr 
> zu gebrauchen!

### 502A

Noch vorhandener Originaltext.

**Seite 1**

> Schau Dir die Kleine da drüben an.
> Sie kümmert sich aufopferungsvoll
> um ihre Hühner, und das, obwohl sie 
> gegen Federn allergisch ist.

**Seite 2**

> Was für ein Mädchen! Ich würde
> ihr gern helfen, ich fühle mich zur
> Zeit wie ein Wohltäter! Geht's Dir
> nicht auch so?

### 5055

Noch vorhandener Originaltext.

**Seite 1**

> Hey! Schön, Dich wiederzusehen!
> Ich gebe Dir dieses
> Erinnerungsstück.

### 5056

Projekttext.

**Seite 1**

> Mit [C-Up] schaust Du Dich um. Sehr
> nützlich, falls Du kontrollieren
> möchtest, ob der TODESBERG noch
> da ist.

### 5057

Projekttext.

**Seite 1**

> Ich hab nen sau guten Kollegen
> namens Okto. Er ist ein Oktorok.

**Seite 2**

> Na, egal...

**Seite 3**

> Vielleicht begegnest Du ihm ja mal.
> Das ist ein stabiler Kollege, man
> kann's nicht anders sagen!

**Seite 4**

> Na, egal...

### 5058

Projekttext.

**Seite 1**

> Falls Du Okto triffst: Grüß ihn von
> mir!

### 5059

Noch vorhandener Originaltext.
Direkte Fortsetzung: 505A.

**Seite 1**

> Macht es Dir Spaß, fremde Leute
> zu so später Stunde noch zu
> belästigen? Du hast wohl gar
> keine Erziehung genossen.

**Seite 2**

> Na, egal...

### 505A

Noch vorhandener Originaltext.

**Seite 1**

> Die Frau kümmert sich um die
> Hühner, reagiert aber allergisch
> auf Federn.

**Seite 2**

> Na, egal...

### 5060

Projekttext.

**Seite 1**

> Mario und Luigi sind beides
> großartige Männer. Dann gibt es
> noch den gierigen Wario. Pfu!

**Seite 2**

> Und dieser Waluigi wird es nie zu
> etwas bringen. Manchen ist es wohl
> vorherbestimmt, ewig nutzlos zu sein.

**Seite 3**

> Und von Wawario und Wawaluigi
> will ich gar nicht erst anfangen!

### 5061

Projekttext.

**Seite 1**

> Mario und Luigi sind beides
> großartige Männer. Dann gibt es
> noch den gierigen Wario. Pfu!

**Seite 2**

> Und dieser Waluigi wird es nie zu
> etwas bringen. Manchen ist es wohl
> vorherbestimmt, ewig nutzlos zu sein.

**Seite 3**

> Und von Wawario und Wawaluigi
> will ich gar nicht erst anfangen!

### 5062

Projekttext.

**Seite 1**

> Mario und Luigi sind beides
> großartige Männer. Dann gibt es
> noch den gierigen Wario. Pfu!

**Seite 2**

> Und dieser Waluigi wird es nie zu
> etwas bringen. Manchen ist es wohl
> vorherbestimmt, ewig nutzlos zu sein.

**Seite 3**

> Und von Wawario und Wawaluigi
> will ich gar nicht erst anfangen!

### 507F

Projekttext.

**Seite 1**

> Ah, wie findest Du denn meinen
> Bart? Ist das nicht ein toller
> Schnurrbart?

**Seite 2**

> Dafür benutze ich das edelste
> Bartwachs, das man in diesem Land
> kriegen kann. Das muß auch mal
> gesagt werden.

### 5080

Projekttext.

**Seite 1**

> Du schaust schon wieder auf meinen
> Schnurrbart. Versteh ich.

**Seite 2**

> Das edelste Bartwachs im ganzen
> Land. Billiges Zeug kommt mir da
> nicht rein!

### 5081

Projekttext.

**Seite 1**

> Wie findest Du meinen Schnurrbart?
> Edelstes Bartwachs! Dafür ist auch
> in schweren Zeiten Geld da.

### 5082

Projekttext.

**Seite 1**

> Mein Schnurrbart steht wenigstens
> noch. Das Wachs hält, auch wenn
> draußen alles zusammenbricht.

### 5083

Projekttext.

**Seite 1**

> Ich habe ja nichts gegen Goronen.
> Aber müssen die wirklich nackt
> rumlaufen?

**Seite 2**

> Mein Nachbar sagt, das sei ihre
> Kultur. Meine Unterhose ist übrigens
> auch kulturell gewachsen.

### 5084

Projekttext.

**Seite 1**

> Der Gorone hat mir erklärt, das sei
> keine Nacktheit, sondern geologische
> Freiheit. Jetzt denke ich seit Stunden
> darüber nach.

## D. Hühnerfrau, Mario und Beginn der optionalen Tauschquest

### 503E

Projekttext.
Direkte Fortsetzung: 503F.

**Seite 1**

> Ich habe Kiki gezüchtet. Von diesem
> Huhn bekomme ich keine Allergie.

**Seite 2**

> Es paßt in die Hosentasche. Das war
> bei meinen Schweinen anders. Söder
> brauchte offenbar keine Tasche.

**Seite 3**

> Kiki weckt selbst die größten
> Schlafmützen. Es gackert mit
> erstaunlicher Überzeugung.

**Seite 4**

> Ganz glücklich wirkt es trotzdem
> nicht.

**Seite 5**

> Du scheinst gut mit Hühnern
> auszukommen. Nimm dieses Ei mit.

**Seite 6**

> Wenn Kiki geschlüpft ist, bring es
> irgendwann zurück. Ich möchte sehen,
> ob es sich wohlfühlt.

### 503F

Noch vorhandener Originaltext.

**Seite 1**

> Was hältst Du davon? 
> Willst Du es ausprobieren?
> Ja!
> Nein!

_Die Antwortmöglichkeiten stehen in ihrer tatsächlichen Reihenfolge oben._

### 5040

Noch vorhandener Originaltext.

**Seite 1**

> Oh, wie schade... Haben die Hühner
> immer nach Dir gehackt, als Du
> noch kleiner warst?

### 5042

Noch vorhandener Originaltext.

**Seite 1**

> Bitte sorge gut für Kiki!
> Okay?

### 5043

Noch vorhandener Originaltext.
Direkte Fortsetzung: 5044.

**Seite 1**

> Oh, Kiki sieht ja sehr gesund und
> fröhlich aus. Es muß eine arge
> Schlafmütze geweckt haben!

**Seite 2**

> Das hast Du gut gemacht!
> Ich werde Dir ein sehr seltenes
> Hühnchen mitgeben, wenn Du willst.

**Seite 3**

> Ich nenne es Henni, es hat einmal
> meinem Bruder gehört. Die blauen 
> Federn sehen sehr schön aus,
> nicht wahr? Es ist sooooo süß!

**Seite 4**

> Seit mein Bruder verschwunden ist,
> gackert Henni gar nicht mehr!

### 5044

Noch vorhandener Originaltext.

**Seite 1**

> Möchtest Du Henni behalten?
>
> Ja!
> Nein!

_Die Antwortmöglichkeiten stehen in ihrer tatsächlichen Reihenfolge oben._

### 5045

Noch vorhandener Originaltext.

**Seite 1**

> Also magst Du Kiki doch lieber.
> Okay, dann behalte sie noch für
> eine Weile!

### 5047

Noch vorhandener Originaltext.

**Seite 1**

> Mein Bruder muß sehr einsam
> gewesen sein...

### 5015

Projekttext.

**Seite 1**

> Zzz... Malon macht das prima...

**Seite 2**

> Luigi kümmert sich... nur noch ein
> Pilz... Zzz...

### 5016

Projekttext.

**Seite 1**

> Luigi leitet jetzt die Farm. Er nennt
> es unsere große Urlaubsvertretung.

**Seite 2**

> Ich darf mich hier ausruhen. Malon
> hilft weiter auf der Farm. Luigi
> erklärt ihr jeden Morgen, wie toll ihre
> Schicht wird.

**Seite 3**

> Ein Urlaub ohne Rückreisetermin!
> Mamma mia, da hätte ich vorher
> besser nach dem Reiseplan gefragt.

### 5017

Projekttext.

**Seite 1**

> Epona ist bei Dir und Luigi ist
> glücklich? Großartig! Dann kann
> Mario wieder nach Hause. Let's-a go!

### 508B

Projekttext.

**Seite 1**

> Der Bärtige da ist Mario von der
> Farm. Luigi hat ihm einen Urlaub
> organisiert. Sehr großzügig. Ohne
> festes Ende.

### 508C

Projekttext.

**Seite 1**

> Er übt hier seine Super-Schlaftechnik.
> An der Motivation scheitert es nicht:
> Luigi schickt ihm jeden Morgen ein
> fröhliches Hallo.

### 508D

Projekttext.

**Seite 1**

> Mario ist wieder auf der Farm. Luigi
> hat sich riesig gefreut!

**Seite 2**

> Mein kleiner Richard wedelt
> wenigstens nur mit dem Schwanz.
> Luigi bedankt sich gleich bei jedem
> einzelnen Muskel.

## E. Kakarikos Läden und optionale Tauschquest

### 5046

Noch vorhandener Originaltext.

**Seite 1**

> Eine alte Vettel betreibt den
> Hexenladen hinter diesem Shop.
> Nimm die Tür links neben der
> Theke, wenn Du hinein willst!

### 5048

Projekttext.

**Seite 1**

> Hihihi! Ich bin die Schleimhexe.

**Seite 2**

> Ich produziere feinsten Hexenschleim.
> Willst Du was davon haben, dann
> mußt Du auch zahlen.

**Seite 3**

> Für meine besten Sachen brauche ich
> diese seltsamen Gewächse aus den
> Verlorenen Wäldern. Hast Du was
> dabei?

### 5049

Projekttext.

**Seite 1**

> Schnüffel...

**Seite 2**

> Dieser Duft! Ein seltener Pilz aus
> den Verlorenen Wäldern!

**Seite 3**

> Den brauche ich für meinen
> Hexenschleim. Jetzt stell Dich nicht
> so an!

### 504A

Projekttext.
Direkte Fortsetzung: 504B.

**Seite 1**

> Der Taugenichts ist also in die
> Verlorenen Wälder gegangen. Und Du
> bringst seinen Pilz. Na schön.

### 504B

Projekttext.

**Seite 1**

> Her mit dem Pilz! Für den
> Hexenschleim!
> Ja!
> Nein!

_Die Antwortmöglichkeiten stehen in ihrer tatsächlichen Reihenfolge oben._

### 504C

Projekttext.

**Seite 1**

> Ach, komm! Nur ein bißchen Pilz für
> den Hexenschleim. Du brauchst den
> doch nicht zum Angucken!

### 504D

Projekttext.

**Seite 1**

> Hier. Mein stärkster Hexenschleim.
> Also Medizin. Offiziell ist das
> Medizin.

**Seite 2**

> Bring ihn dem Dummkopf in den
> Verlorenen Wäldern. Ob es ihm noch
> hilft? Hihihi!

### 504F

Projekttext.

**Seite 1**

> Gegen Dummheit hilft leider auch
> mein feinster Hexenschleim nicht. Ich
> arbeite dran. Hihihi!

### 500C

Projekttext.

**Seite 1**

> Hihihi! Feinster Hexenschleim! Willst
> Du was davon haben, mußt Du auch
> zahlen.

**Seite 2**

> Blaues Elixier: 100 Rubine.
>
> Kaufen!
> Nicht kaufen!

_Die Antwortmöglichkeiten stehen in ihrer tatsächlichen Reihenfolge oben._

### 500D

Projekttext.

**Seite 1**

> Dann gibt es heute keinen
> Hexenschleim für Dich. Komm wieder,
> wenn Du zahlst. Hihihi!

### 500E

Projekttext.

**Seite 1**

> Zu wenig Rubine! Von Luft und Liebe
> kann ich keinen Hexenschleim kochen.
> Hihihi!

### 006D

Projekttext.

**Seite 1**

> Tu mir den Gefallen: Komm mir nicht
> mit dem Scheißauge der Wahrheit
> hier rein. Das geht komplett schief.

**Seite 2**

> Links oder rechts? Finde den
> Schlüssel. Ein Spiel: 10 Rubine.
> Ja!
> Nein!

_Die Antwortmöglichkeiten stehen in ihrer tatsächlichen Reihenfolge oben._

## F. Gemeinsame Schatz- und Dungeon-Meldungen

### 0060

Noch vorhandener Originaltext.

**Seite 1**

> Ein kleiner Schlüssel!
> Er öffnet eine verschlossene
> Tür. Du kannst ihn nur in
> diesem Labyrinth einsetzen.

### 0066

Noch vorhandener Originaltext.

**Seite 1**

> Die Labyrinth-Karte!
> Drücke START, um sie im
> Karten-Bildschirm anzusehen!

**Seite 2**

> Blaue Räume hast Du bereits
> aufgesucht.
> Der blinkende Raum zeigt
> Deine derzeitige Position.

**Seite 3**

> Bewege [Control-Pad], um ein
> Stockwerk auszuwählen.

### 0067

Noch vorhandener Originaltext.

**Seite 1**

> Der Kompaß!
> Jetzt siehst Du auf Deiner
> Karte alle Schatztruhen
> dieses Labyrinths!

### 00C7

Noch vorhandener Originaltext.

**Seite 1**

> Der Master-Schlüssel!
> Jetzt kannst Du endlich jenen
> Raum betreten, in dem der
> Endgegner lauert.

## G. Navi – Gegnerbeschreibungen im Brunnen und Schattentempel

### 0604

Projekttext.

**Seite 1**

> Du achtbeiniger Vollidiot! Dreh Dich
> ruhig um und zeig uns Deinen
> Schwachpunkt. Ja, genau so. Meine
> Fresse.

### 0605

Projekttext.

**Seite 1**

> Die Riesen-Skulltula zeigt uns
> freiwillig ihren weichen Bauch. So ein
> großes Vieh und so unfaßbar dumm.

### 0607

Projekttext.

**Seite 1**

> Ein Dekuranha. Mach die Fresse zu,
> Du Scheißunkraut. Ich reiß Dich samt
> Wurzel aus diesem Drecksloch.

### 0608

Projekttext.

**Seite 1**

> Der große Dekuranha hält den Kopf
> extra weit hoch. Ja, danke, Du
> Trottel. Da kommen wir prima dran.

### 0611

Projekttext.

**Seite 1**

> Ein Feuerflatterer. Brennt schon und
> fliegt uns trotzdem noch in die
> Fresse. Halt doch einfach mal still!

### 0612

Projekttext.

**Seite 1**

> Ein Flederbeißer. Du hast die ganze
> Höhle zum Fliegen. Warum muß es
> ausgerechnet mein Gesicht sein, Du
> Wichser?

### 061B

Projekttext.

**Seite 1**

> Ein Stalfos-Ritter. Der hat nicht mal
> mehr Fleisch an den Knochen und
> spielt trotzdem den harten Kerl.

### 061C

Projekttext.

**Seite 1**

> Eine blaue Knochenfratze. Kannst Du
> Dein beschissenes Maul auch
> schließen, oder fehlen Dir dafür die
> Muskeln?

### 061D

Projekttext.

**Seite 1**

> Eine bleiche Knochenfratze. Kaum ist
> das Feuer aus, kriegst Du aufs Maul.
> Flieg ruhig noch näher, Du Trottel.

### 061E

Projekttext.

**Seite 1**

> Eine grüne Knochenfratze. Noch so
> ein brennender Schädel. Wie viele von
> diesen Arschlöchern gibt's hier bitte?

### 061F

Projekttext.

**Seite 1**

> Eine Skullwandula. Die wartet, bis wir
> an der Wand hängen, und springt uns
> an. Du feige kleine Drecksspinne.

### 0620

Projekttext.

**Seite 1**

> Eine goldene Skulltula. Ich höre Dein
> Gekratze seit fünf Minuten. Halt
> endlich die Fresse da oben!

### 0629

Projekttext.

**Seite 1**

> Bongo Bongo. Der trommelt hier mit
> seinen Riesenpranken auf UNSEREM
> Fußboden. Hör auf damit, Du
> Arschloch!

### 062A

Projekttext.

**Seite 1**

> Ein Zombie. Hör auf, so zu stöhnen!
> Und nimm die Finger von uns, Du
> widerlicher Grabscher!

### 062D

Projekttext.

**Seite 1**

> Ein Wickel-Zombie. Riecht bestimmt
> schon durch die ganzen Bandagen.
> Bleib bloß weg, Du gammeliges
> Schwein.

### 062E

Projekttext.

**Seite 1**

> Diese Hände halten uns fest, damit
> ihr häßlicher Kumpel uns ansabbern
> kann. Laß los, Du verdammter
> Grabscher!

### 062F

Projekttext.

**Seite 1**

> Ein Hirnsauger. Der hat diesen ganzen
> Scheiß mit den Händen geplant? So
> eine widerliche Drecksau.

### 0630

Projekttext.

**Seite 1**

> Ein Deckengrapscher. Hör auf, über
> meinem Kopf zu hängen! Komm
> runter, dann brech' ich Dir jeden
> Finger einzeln.

### 0631

Projekttext.

**Seite 1**

> Ein Bodengrapscher. Jetzt teilt sich
> das Arschloch auch noch auf. Drei
> kleine Wichser sind keine
> Verbesserung.

### 0637

Projekttext.

**Seite 1**

> Ein Raubschleim. Kotz den Schild
> wieder aus, Du schleimiger Wichser!
> Der war verdammt noch mal teuer!

### 0639

Projekttext.

**Seite 1**

> Ein Strahlzyklop. Starrt uns die ganze
> Zeit an. Glotz woanders hin, Du
> einäugiger Drecksack!

## H. Weitere bedingte Hinweise, Salias Lied und spätere Rückbezüge

### 015F

Projekttext.

**Seite 1**

> [Spielername], mir gefällt das hier
> immer weniger. Ich hoffe, daß wir
> dem Ursprung dieses ganzen Mists
> näherkommen.

### 00E0

Noch vorhandener Originaltext.

**Seite 1**

> Willst Du mit Salia sprechen?
>
> Ja!
> Nein!

_Die Antwortmöglichkeiten stehen in ihrer tatsächlichen Reihenfolge oben._

### 00E1

Noch vorhandener Originaltext.

**Seite 1**

> Willst Du dann mit mir sprechen? 
>
> Ja!
> Nein!

_Die Antwortmöglichkeiten stehen in ihrer tatsächlichen Reihenfolge oben._

### 016C

Projekttext.
Salia per Okarina vor dem Schattenamulett.

**Seite 1**

> Sind alle sechs Weisen vereint,
> können sie Friedrich Merz verbannen.

**Seite 2**

> Für das Siegel brauchen sie noch den
> Siebten Weisen.

**Seite 3**

> Das ist jemand, den Du kennst,
> [Spielername]. Mehr weiß ich auch
> nicht.

**Seite 4**

> Du mußt zwischen Vergangenheit und
> Zukunft reisen, um die anderen
> Weisen zu erwecken.

**Seite 5**

> Ich bleibe hier erreichbar. Für die
> großen Sitzungen haben sie ja jetzt
> die Krabbelminen-Frau.

### 016D

Projekttext.
Salia per Okarina nach dem Schattenamulett, abhängig von den übrigen Amuletten.

**Seite 1**

> Die sechs Weisen geben Dir ihre
> Kraft. Ich drücke Dir von hier aus die
> Daumen.

**Seite 2**

> Das Schicksal Hyrules liegt jetzt bei
> Dir. Und zum Teil bei einer
> überarbeiteten Bowling-Angestellten.

### 70E3

Noch vorhandener Originaltext.
Späteres Finale im Schloß, kein zusätzlicher Text unmittelbar nach Bongo Bongo.
Zeitgesteuerte Einblendung bzw. Textpause im Spiel.

**Seite 1**

> Das Schatten-Siegel ist gebrochen!
> Bitte rette die Prinzessin!

### 5024

Noch vorhandener Originaltext.
Bedingter Hinweis nach allen erforderlichen Tempeln; nicht zwingend direkt nach dem Schattentempel.

**Seite 1**

> [Spielername], der Auserwählte!
> Endlich!

**Seite 2**

> Alle Sechs Weisen sind erweckt!
> Es ist soweit: Der entscheidende
> Kampf gegen den Großmeister des
> Bösen soll nun beginnen!

**Seite 3**

> Zuvor jedoch sollst Du jene
> treffen, die auf Dich wartet...

**Seite 4**

> Sie harrt Deiner in der
> Zitadelle der Zeit...

---

153 verschiedene Nachrichten, einschließlich der optionalen Texte. Die Spieldatei wurde durch diesen Export nicht verändert.

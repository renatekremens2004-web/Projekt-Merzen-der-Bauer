# Phantom-Amthor-Köpfe

Burns-Kopf: vom Nutzer bereitgestelltes Archiv `the-simpsons-game-mr-burns.zip`, darin `burns_lowpoly.obj` aus The Simpsons Game. Original-Rip von **Hell Inspector**, gemäß beigefügter README: https://www.vg-resource.com/user-39500.html.

Smithers-Kopf: vom Nutzer bereitgestelltes Archiv `mr-smithers-animated-simpsons.zip`, darin `Crazy Gesture.fbx` mit `char_swatches_lit_bmp.png` und `eyeball_bmp_0.png`. Verwendet wird nur der Kopf aus der Ruhepose, keine fremde Lauf-/Kampfanimation.

Die beiden `phantom_*_source.json` enthalten die verkleinerten, am Hals ausgeschnittenen Köpfe. Größe wird jeweils gleichmäßig verändert. Die Orientierung entspricht Phantom Ganons ursprünglicher Kopf-Achse: +X nach vorne, -Y nach oben, +Z seitlich. Skelett und übrige Boss-Geometrie stammen weiterhin aus der privaten Original-ROM beim lokalen Bau.

`amthor_bossname_de.png` ist die neu gesetzte deutsche Boss-Einblendung. Englisch und Französisch bleiben in der ursprünglichen Textur erhalten. Die Schrift wurde mit Open Sans Condensed Bold erzeugt; zum normalen Neubau genügt die mitgelieferte PNG.

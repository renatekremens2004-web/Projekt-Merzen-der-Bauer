# Merzen der Bauer – Mr. Burns und Mr. Bean in Hyrule

Deutsche Europa/PAL-1.0-Modifikation von **Ocarina of Time**. Mr. Burns verkörpert Friedrich Merz und ersetzt die menschlichen Ganondorf-Gestalten; Mr. Bean übernimmt Impas Rolle. Philipp Amthor erscheint als Phantom-Boss mit Smithers-Kopf; in seiner Enthüllung ist davor ein Burns-Kopf zu sehen.

## Aktuelle Fassung: Phantom Amthor, Bean, Darunia und Deku-Baum

Phantom Ganon behält Körper, Pferd, Skelett und Kampfablauf. Die native Enthüllung wechselt vom Burns-Kopf zum Smithers-Kopf. Deutsche Boss-Einblendung „Merz' Musterschüler / PHILIPP AMTHOR“, eigene Begrüßung „Sooo, genug Schabernack!“ und Navis 15-oder-55-Spruch. Die neuen Köpfe erhalten Szenenlicht und verschwinden mit dem nativen Zerfallseffekt.

Bean erklärt seinen Genickbruch durch den Ast beim Reiten. Darunia begründet seinen Chefposten ausgiebig mit Fähigkeiten, die alle Goronen haben. Der Deku-Baum verkündet bis unmittelbar vor seinem Tod, wie unaufhaltsam er sei; Mido hält anschließend seinen Kompost-Monolog über den Deku-Baum. Der lange Jabu-Jabu-Einkaufsdialog wird nach Zeldas Flucht mit dem kürzeren Text eines bodennahen Markt-NPCs getauscht. Keine NPCs versetzt.

**962 eigene deutsche Nachrichten; alle bisherigen Modelle, Weisen-/Maskentexte und Kapitel enthalten.** [Dialogübersicht](planning/AMTHOR_BEAN_DARUNIA_DEKU_DIALOGE_AKTUELL.md) · [Prüfbericht](TESTING_PHANTOM_AMTHOR.md) · [Echte Bilder](previews/phantom-amthor/) · [Gesamtpatch](patches/Mr_Burns_Mr_Bean_DE_PAL10_Amthor_Bean_Darunia_Deku.bps).

### Vorherige Fassung: Thaddäus, Waluigi und Maskenreaktionen

Die vollständigen Thaddäus- und Waluigi-Dialoge sowie die deutschen Maskenreaktionen sind eingebaut. Junge Ruto bleibt erhalten. [Dialoge](planning/THADDAEUS_WALUIGI_DIALOGE_AKTUELL.md) · [Maskenreaktionen](planning/MASKEN_REAKTIONEN_AKTUELL.md) · [Prüfung](TESTING_WEISE_MASKEN.md).

### Vorherige Fassung: Wallace in Dodongos Höhle

Wallace steht als ansprechbarer NPC nur für Kind-Link am westlichen Rand des Bombenblumen-Treppenraums (Raum 2), abseits des Eingangs. Eigene Proportionen, dezente Kopf-/Armbewegungen, native Beleuchtung und Schatten. Er erforscht extremes Klima und die Goronen und erzählt von Merz' Kohleabbaufiasko. Als Erwachsener fehlt er. Alle bisherigen Wald-/Navi-/Salia-Änderungen und Modelle sind enthalten. [Prüfung](TESTING_WALLACE.md) · [Ingame-Bilder](previews/wallace/) · [Gesamtpatch](patches/Mr_Burns_Mr_Bean_DE_PAL10_Wallace.bps).

### Vorherige Fassung: Wald, Navi und Salias Reise

Sheiks Gedicht, Kokiri-Sprüche, Papphai des erwachsenen Forschers, Navi-Texte bis nach dem Feuertempel und Salias Reise-Spruch nach dem Waldamulett. [Prüfung](TESTING_WALD_NAVI_FEUER.md) · [Navi-Texte](planning/NAVI_NACH_WALDTEMPEL_BIS_FEUER_AKTUELL.md).

### Vorherige Fassung: Thaddäus und Waluigi als Weise

Erwachsene Ruto ist durch Thaddäus ersetzt, Naboru durch den Waluigi aus Mario Party 3. Die Änderungen gelten für die nativen Tempelauftritte, Weisen-Szenen, das Finale und die Credits, einschließlich des Körpers unter der zerfallenden Eisenritter-Rüstung. Junge Ruto und der Thaddäus beim Tauchspiel bleiben erhalten. **Neue Kapitel-Dialoge folgen später; jetzt wurden nur Modelle und Namen geändert.**

Tripple T ist jetzt 60 statt 54 Spieleinheiten hoch, zeigt in die ursprüngliche Blickrichtung des Deku-Sprosses und hat detailliertere Augentexturen. [Prüfung](TESTING_WASSER_GEISTER_WEISE.md) · [Echte Bilder](previews/wasser-geister-weise/) · [Gesamtpatch](patches/Mr_Burns_Mr_Bean_DE_PAL10_Wasser_Geister_Weise.bps).

### Vorherige Fassung: Waldtempel, Navi und Tripple T

Deine 14 Navi-Texte, Majoras Maske in einem inneren westlichen Gang und Tripple T als Deku-Sproß nach dem Waldamulett. **724 eigene Nachrichten, alle bisherigen Änderungen enthalten.** 0120 unverändert, keine festen Lesezeiten geändert. [Aktuelle Navi-Texte](planning/NAVI_WALDTEMPEL_AKTUELL.md) · [Prüfung](TESTING_WALDTEMPEL_SAHUR.md) · [Echte Bilder](previews/waldtempel-sahur/).

### Vorherige Fassung: Waldweise v2

Sitz in den Credits am Schulter-/Halsansatz statt auf Darunias Haarspitze, eigene angepaßte Sitzpose und Kamerawinkel. Neue Geschichte über den eingestürzten Krabbelminenladen, ihren Tod und die Warnung in der Vergangenheit. Weiterhin **706** eigene Nachrichten und alle bisherigen Änderungen. [Prüfung einschließlich Normalstart](TESTING_WALDWEISE_V2.md) · [Echte Ingame-Bilder](previews/waldweise-v2/).

### Vorherige Fassung: Krabbelminen-Frau als Waldweise

Erwachsene Proportionen, eigenes Skelett, Enthüllung nach dem Waldtempel und eigener Sitz auf Darunias Schultern in den Credits. Junge Salia bleibt erhalten. **706** eigene Nachrichten und alle bisherigen Änderungen. [Prüfung und Speichergrenzen](TESTING_WALDWEISE.md) · [Echte Ingame-Bilder](previews/waldweise/) · [Weitere Weisen geplant](planning/WALDKAPITEL.md).

### Vorherige Fassung: Mido in der Zukunft

Mido findet den Spieler auch nach sieben Jahren noch scheiße und hat sich mit König Zora für eine mögliche Siegesfeier nach Merz’ Niederlage verabredet. **698** eigene Nachrichten; alle bisherigen Änderungen enthalten. [Prüfung](TESTING_MIDO_ZUKUNFT.md) · [Ingame-Bilder](previews/mido-zukunft/).

### Vorherige Fassung: Wald-Auftakt

Erwachsener Kokiri, zweideutige Shiek-Hinweise und Boris: seit vorgestern tot, angeblich schon immer Rennsportler, „Uga Paluga“ als angeblich alte Catchphrase. **695** eigene Nachrichten, alle bisherigen Änderungen enthalten. [Prüfung](TESTING_WALD_AUFTAKT.md) · [Ingame-Bilder](previews/wald-auftakt/) · [Weitere Modellpläne](planning/WALDKAPITEL.md).

### Vorherige Fassung: Okto am Wasser

Okto schwimmt jetzt am tatsächlichen Wasserpegel im Eingangsraum von Jabu-Jabu. Vom trockenen Ufer mit A ansprechen; native Wasserringe, friedliches und wiederholbares Gespräch. Alle 682 eigenen Nachrichten und bisherigen Änderungen enthalten. [Prüfung](TESTING_OKTO_WASSER.md) · [Ingame-Bilder](previews/okto-wasser/).

### Vorherige Fassung: Okto, der Oktorok

Ein zusätzlicher friedlicher Oktorok rechts im Eingangsraum von Jabu-Jabu: normal ansprechen, wiederholt reden, keine Angriffe und kein Gegner für den Raumabschluß. Normale Oktoroks und der große Oktorok behalten ihr Verhalten. **682** bearbeitete Nachrichten, sämtliche bisherigen Änderungen enthalten. [Prüfung und Belegung](TESTING_OKTO.md) · [Ingame-Bilder](previews/okto/).

### Vorherige Fassung: Eule und Tagesdialoge

Alle 34 Euleneinträge geprüft und die Stimme an 33 Stellen geschärft, ohne die Identität vorwegzunehmen. Zitteraal- und Bean-Rettungsgag bei zwei tagsüber erreichbaren Marktplatzbewohnern, in Erst-/Wiederholungsgesprächen und nach Zeldas Flucht; ohne Flaschenbedingung. Nachtwache bekommt einen eigenen Dienstspruch. Merz nennt Bean nun „Herr Bohne“. Weiterhin **681** bearbeitete Nachrichten mit sämtlichen bisherigen Modellen und schnellerem Schreibtempo. [Prüfung und Belegung](TESTING_EULE_TAGESDIALOGE.md) · [Ingame-Beispiele](previews/eule-tagesdialoge/).

### Vorherige Fassung: eigene NPC- und Händlerstimmen

Neue Nutzerideen bei Händlern, Spinnenfamilie und Bewohnern verteilt. 46 zusätzliche Nachrichtenzustände, insgesamt **681**; 634 bisherige eigene Texte unverändert, ein Kokiri-Text neu gefaßt. Modelle, schnelleres Schreibtempo und normaler Spielstart enthalten. [Prüfung und Belegung](TESTING_NPC_STIMMEN.md) · [Ingame-Beispiele](previews/npc-stimmen/).

### Vorherige Fassung: weitere Alltagsgags in Hyrule und Kakariko

Alle sechs neuen Nutzerideen auf zuvor originale NPC-Gespräche verteilt. Neun Textzustände überarbeitet; insgesamt **635** eigene Nachrichten. Bisherige Dialoge, Modelle und schnelleres Schreibtempo enthalten. [Prüfung und Belegung](TESTING_ALLTAGSGAGS.md) · [Ingame-Beispiele](previews/alltagsgags/).

### Vorherige Fassung: mehr Gespräche in Hyrule-Stadt

27 bisher originale Nachrichten ersetzt und den gewünschten Gesichts-Gag in den Folgedialog der Frau bei den Geschäften aufgenommen. Deine neuen Stadt-Ideen und weitere Überraschungen auf passende Bewohner verteilt, bestehende Ideen erhalten. Insgesamt **626 bearbeitete deutsche Nachrichten**, schnelleres Schreibtempo und alle bisherigen Modelle enthalten. [Prüfung und Belegung](TESTING_HYRULE_NPCS.md) · [Vier echte Ingame-Beispiele](previews/stadt-nachschlag/).

### Vorherige Fassung: schnelleres Texttempo

Normale deutsche Textboxen bauen ihre Schrift ungefähr doppelt so schnell auf. Jede Seite wartet weiterhin auf den Tastendruck; feste Zeitvorgaben, Auswahlfragen, Cutscenes und Dialogtexte behalten ihre bisherige Steuerung. Alle bisherigen Änderungen mit 599 bearbeiteten Nachrichten enthalten, normaler Spielstart. [Prüfung und Nachbau](TESTING_TEXTTEMPO.md).

### Vorherige Fassung: Zoras über Musik und Mido

Der Tierarzt-Nachtrag und ein allgemeiner Ruto-Nachtrag werden durch die beiden neuen Nutzerideen ersetzt: kurz crazy klingende Musik beim Verlassen der Höhle sowie ein Zora, der Mido kennt und nicht ausstehen kann. Deine übrigen Dialogvorgaben bleiben erhalten. Weiterhin **599 deutsche Nachrichten** mit allen bisherigen Änderungen. [Prüfung](TESTING_ZORA_GAGS.md) · [Bilder](previews/zora-gags/).

### Vorherige Fassung: Navi zieht über Gegner her

Alle 93 Gegner-Zieltextplätze neu geschrieben: direkte, härtere Beleidigungen über ihr tatsächliches Verhalten. Skulltula als achtbeiniger Vollidiot, wütende Navi bei der Killermuschel. Alte Rechtschreibung, bestehende Seitenzahlen und feste Zeiten erhalten. Insgesamt **599 deutsche Nachrichten**, alle bisherigen Änderungen enthalten. [Prüfung](TESTING_NAVI_ROASTS.md) · [Ingame-Bilder](previews/navi-roasts/).

### Vorherige Fassung: LEGO X-Wing im Schattentempel

Ein LEGO X-Wing mit 24 Spieleinheiten Spannweite liegt im ersten Schädelraum des Schattentempels. Der Mann im blauen Hemd unten im erwachsenen Kakariko hat ihn dort vergessen. Dachbewohner und NPC-Positionen bleiben erhalten. Insgesamt **599 deutsche Nachrichten**, alle bisherigen Änderungen enthalten. [Prüfung](TESTING_XWING.md) · [Bilder](previews/xwing/).

### Vorherige Fassung: Nintendo 64 in Jabu-Jabu

Ein kleiner Nintendo 64 mit Ocarina-of-Time-Kassette und Controller liegt auf der unteren Plattform bei Rutos erstem Sturz. Das Gehäuse ist 10 Spieleinheiten breit, passend für Kinder-Link. Z anvisieren, dann C-Up für Navis Kommentar; wiederholbar. Insgesamt **597 deutsche Nachrichten**. Alle bisherigen Modelle und Dialogkapitel enthalten. [Prüfung](TESTING_N64_JABU.md) · [Ingame-Bilder](previews/n64-jabu/).

### Vorherige Fassung: Habeck in der Halle der Weisen

Das gelieferte Habeck-Modell ersetzt Rauru mit eigenen Proportionen, 2341 Dreiecken und 24 Hauptgelenken. Eine ausführliche Erklärung verbindet seine Geistereule mit Stasis, Energieversorgung und Zeitreise. Der Dachbewohner im jungen Kakariko berichtet tags/nachts vom Sturz des Mannes im Anzug. 14 Nachrichten dieses Kapitels, insgesamt **596 deutsche Nachrichten**. [Prüfung](TESTING_HABECK.md) · [Ingame-Beispiele](previews/habeck/).

### Vorherige Fassung: Drei Steine, Flucht und Masterschwert

22 Nachrichten für die Flucht, Merz nach dem Masterschwert, Soldaten, Marktreaktionen und einen einmaligen Navi-Kommentar; insgesamt **584 deutsche Nachrichten**. Alle bisherigen Modell- und Dialogänderungen sind enthalten. Feste Textzeiten bleiben erhalten. [Prüfung](TESTING_ZEITUEBERGANG.md) · [Ingame-Beispiele](previews/zeituebergang/).

### Vorherige Fassung: Zoras, Jabu-Jabu und Navis Gegner-Roasts

59 Nachrichten für Zoras, Ruto, Flaschenpost, Wundererbsen, Karte und neue Navi-Kommentare; dazu alle 93 Navi-Zieltextplätze als individuelle Roasts. Insgesamt **564 deutsche Nachrichten**. König Zora verspricht den Saphir für Klimaanlagen, Ruto versteckt sich vor Merz und verschwindet nach dem Dungeon tatsächlich aus dem Thronsaal. Barinade begrüßt den Spieler vor dem Kampfbeginn mit einer neuen Textbox. [Prüfung](TESTING_ZORAS_JABU.md) · [Ingame-Beispiele](previews/zoras-jabu/).

### Vorherige Fassung: Thaddäus beim Tauchspiel

Der Tauchspiel-Leiter ist Thaddäus: 254 Quelldreiecke, eigenes Skelett mit 27 Gelenken, gleichmäßige Skalierung und Szenenlicht. Zehn neue Nachrichten einschließlich eigener Niederlagen-, Absage- und Geldmangeltexte, insgesamt **422 deutsche Nachrichten**. Die übrigen Zoras behalten ihre Modelle; junge und erwachsene Ruto bleiben vorerst erhalten. [Prüfung](TESTING_THADDAEUS.md) · [Ingame-Beispiele](previews/thaddaeus/).

### Vorherige Fassung: Mario und Luigi auf der Farm

Talon heißt Mario, Basil heißt Luigi. 75 Farmnachrichten und Verweise sind neu gefaßt; weitere Namensverweise wurden vereinheitlicht. Hauptsprache bleibt Deutsch mit typischen Ausrufen wie „Mamma mia!“, „Wahoo!“ und „Let’s-a go!“. Luigi deutet auch Niederlagen und das verschlossene Tor begeistert positiv. Insgesamt **412 Nachrichten**. [Prüfung](TESTING_MARIO_LUIGI.md) · [Ingame-Beispiele](previews/farm-mario-luigi/).

### Vorherige Fassung: Goronen und Kakariko

84 zusätzliche Nachrichten für Goronen, Kakariko, Darunia und Navi; drei bestehende Navi-Kommentare neu gefaßt. Insgesamt 349 Nachrichten. Navis Mund-Rückblick erscheint erst nach erhaltenem Goronen-Opal. Darunias kurze Warnrufe behalten die originalen Lesezeiten. [Prüfung](TESTING_GORONEN.md) · [Ingame-Beispiele](previews/goronen-kakariko/).

### Vorherige Dialog- und Bean-Revision

83 neue Nachrichten für Hyrule-Stadt, Farm, Maskenladen, Bowling, Zelda und Methusa. Zusammen mit den bisherigen Kapiteln sind 265 Nachrichten überarbeitet. Beispiele: [Ingame-Dialoge](previews/dialoge-stadt/). [Prüfung und Grafik-Hinweise](TESTING_DIALOGE.md).

Beans Proportionen bleiben erhalten; seine Hose erhält nur in der schwarzweißen Reit-Rückblende weichere Gelenkübergänge. Das Wiegenlied erhält einen Blickwinkel innerhalb der gebauten Hofkulisse. Die schwarzen Wandlücken im Cloud-Renderer werden mit eingeschaltetem Software-Clipping gezeichnet; die frühere Empfehlung zum Abschalten war falsch. [Aktuelle Grafikprüfung und Originalvergleich](TESTING_GRAFIK.md).

### Beans ursprüngliche Proportionen

Bean wurde aus dem bereitgestellten Wii-FBX neu gebunden. Sein Modell wird einheitlich skaliert und verwendet jetzt die Gelenkabstände des Originalmodells. Die langen Impa-Beine und -Arme werden nicht mehr in Beans Körper hineingezogen. Alle **1.258 Quelldreiecke**, die Kopf- und Gesichtsform sowie der 128×128-Texturatlas bleiben erhalten.

Die ursprünglichen Animationswinkel werden mit den passenden Körpermaßen abgespielt. Bei normalen Auftritten und als Weiser paßt die rein visuelle Wurzelbewegung zu seiner Hüfthöhe. Beim Reiten bleibt der ursprüngliche Sattelpunkt erhalten. Einige Kameraeinstellungen beim Wiegenlied und beim Reiten wurden neu eingerahmt. Szenenlicht, Oberflächennormalen, Nebel und Ein-/Ausblenden bleiben wirksam.

## Spielen mit BPS-Patch

Es werden **keine vollständigen ROMs** veröffentlicht.

1. Die eigene unveränderte Europa/PAL-1.0-ROM als `.z64` entpacken. Erwartete MD5: `e040de91a74b61e3201db0e2323f768a`.
2. In [RomPatcher.js](https://www.marcrobledo.com/RomPatcher.js/) die Original-ROM und [den aktuellen BPS-Patch](patches/Mr_Burns_Mr_Bean_DE_PAL10_Wasser_Geister_Weise.bps) auswählen.
3. Das erzeugte Spiel im N64-Emulator öffnen. Normale PAL-Spielstände verwenden; ältere Emulator-Save-States enthalten noch die alten Modelldaten.

Die Patch-Ausgabe wird mit RomPatcher.js bytegenau gegen die gebaute ROM geprüft. Prüfsummen stehen in [SHA256SUMS.txt](SHA256SUMS.txt). Das Spiel benötigt weiterhin **4 MB RAM** und funktioniert auch mit 8 MB. Eine zusätzliche Detailstufe durch das Expansion Pak gibt es nicht.

## Handlung und Spielregeln

152 Kokiri-/Deku-Baum-Nachrichten, 30 Bean-Nachrichten beziehungsweise Verweise und 83 Nachrichten für Stadt, Farm, Zelda, Navi und die Eule sind überarbeitet: mit den weiteren Kapiteln und dem Nintendo-64-Gag insgesamt **597 deutsche Nachrichten**. Weitere Gebiete enthalten überwiegend die Originaltexte. Die gesamte Merz-Handlung ist noch nicht fertig.

Bean spricht selbst geschriebene englische Kommentare und tanzt beim Beibringen von Zeldas Wiegenlied. Andere Figuren sprechen Deutsch in alter Rechtschreibung. Der vom Spieler gewählte Name wird weiterhin nativ eingesetzt. Item-, Alters-, Ausrüstungs-, Shop-, Lied- und Questregeln bleiben erhalten. Es gibt keinen Inventarfilter oder Reparaturcode. Phantom-Ganon und die große Ganon-Monsterform bleiben unverändert.

## Ingame-Beispiele und Prüfung

Aktuelle, unveränderte Emulatoraufnahmen: [Bean im Schloßhof](previews/bean-proportions/Schlosshof.png), [beim Wiegenlied](previews/bean-proportions/Wiegenlied.png), [auf dem Pferd](previews/bean-proportions/Pferd.png), [in der Rückblende](previews/bean-proportions/Pferd_Rueckblende.png) und [in der Halle der Weisen](previews/bean-proportions/Halle_der_Weisen.png).

[Prüfung dieser Revision](TESTING_PROPORTIONEN.md) und [maschinelle Nachweise](validation/bean-proportions/). Ein vollständiger Spieldurchlauf und echte N64-Hardware sind weiterhin nicht geprüft. Finger und Gesicht verwenden vereinfachte Animationen.

Die früheren Berichte [TESTING.md](TESTING.md), [TESTING_KOKIRI.md](TESTING_KOKIRI.md) und [TESTING_PAL_V2.md](TESTING_PAL_V2.md) dokumentieren die jeweiligen früheren Fassungen.

## Selbst bauen

Grundlage: [zeldaret/oot](https://github.com/zeldaret/oot), Commit `14759abf9abb4295de142cdc1452998630ea70fb`. Die vorbereiteten Modelldaten und Tänze sind enthalten; für einen normalen Neubau ist Blender nicht erforderlich. Python benötigt Pillow und NumPy. Eine erneute Ableitung der Weisen-Animationen ist mit tools/generate_sage_models.py möglich; die benötigten Referenzbewegungen stehen in tools/sage_animation_reference.json.

1. Die eigene PAL-1.0-ROM nach `baseroms/pal-1.0/baserom.z64` im OOT-Verzeichnis legen und `make setup VERSION=pal-1.0 N_THREADS=4 -j4` mit den im OOT-README beschriebenen Werkzeugen ausführen.
2. Im Mod-Projekt nacheinander ausführen:

```sh
python3 tools/build_mod.py /pfad/zum/oot pal-1.0
python3 tools/build_bean.py /pfad/zum/oot
python3 tools/build_squid.py /pfad/zum/oot
python3 tools/build_story.py /pfad/zum/oot
python3 tools/build_zoras.py /pfad/zum/oot
python3 tools/build_transition.py /pfad/zum/oot
python3 tools/build_habeck.py /pfad/zum/oot
python3 tools/build_n64_gag.py /pfad/zum/oot
python3 tools/build_xwing.py /pfad/zum/oot
python3 tools/build_text_speed.py /pfad/zum/oot
python3 tools/build_npc_stimmen.py /pfad/zum/oot
python3 tools/build_friendly_octorok.py /pfad/zum/oot
python3 tools/prepare_sage_cameras.py /pfad/zum/oot
python3 tools/build_bowling_sage.py /pfad/zum/oot
python3 tools/build_sahur.py /pfad/zum/oot
python3 tools/build_majora.py /pfad/zum/oot
python3 tools/build_water_spirit_sages.py /pfad/zum/oot
python3 tools/build_wald_dialoge.py /pfad/zum/oot
python3 tools/build_wallace.py /pfad/zum/oot
python3 tools/build_mask_reactions.py /pfad/zum/oot
python3 tools/build_sage_names.py /pfad/zum/oot
python3 tools/build_phantom_amthor.py /pfad/zum/oot
```

3. Im OOT-Verzeichnis ausführen:

```sh
make VERSION=pal-1.0 COMPARE=0 N_THREADS=4 -j4
make compress VERSION=pal-1.0 COMPARE=0 N_THREADS=4 -j4
```

4. Mit der OOT-Python-Umgebung und MIPS-binutils auf PATH: `python tools/verify_zoras_revision.py /pfad/zum/oot /pfad/zur/Thaddaeusfassung.z64`. Als Vergleich dient die zuvor veröffentlichte Thaddäus-Fassung mit SHA256 `6f0cde068467749b34afb5785f7a1c7a5bf864bdb8c9bdfd3c4e017890f4fb7c`. Diese vollständige Vergleichs-ROM bleibt lokal. Ältere Vergleichswerkzeuge und Prüfberichte beziehen sich auf ihre jeweilige frühere Fassung.

Ausgabe: `build/pal-1.0/oot-pal-1.0-compressed.z64`. Test-ROMs mit direktem Szenenstart werden niemals als Produktionsfassung ausgegeben. Lokale Sicherungen unter `tools/originals/` gehören nicht in Veröffentlichungen.

### Modellvorbereitung wiederholen

Die Originaldateien liegen unter `models/bean/`. Nur zur erneuten Vorbereitung werden Blender und NumPy benötigt:

```sh
blender -b --python tools/export_bean_fbx.py -- models/bean/Mr_Bean.fbx tools/bean_source.json
python3 tools/rebind_bean.py
```

Anschließend die drei Generatoren wie oben ausführen. [Modellnachweise](CREDITS.md) und [Handlungsleitlinien](story/LEITLINIEN.md).

Die neuen Weisen- und Maskentexte liegen in story/weise_thaddaeus_waluigi_de.json, story/weise_masken_kontext_de.json und story/masken_reaktionen_de.json. build_story.py liest sie automatisch ein. Nach einem erneuten Textbau build_habeck.py und abschließend build_sage_names.py anwenden. Der Namensbau überspringt ausdrücklich verfaßte Storytexte, damit die weiterhin junge Prinzessin Ruto korrekt erwähnt bleibt. build_mask_reactions.py ergänzt die sprachabhängige Tabelle und die begrenzten Kokiri-/Tauchspiel-Ausnahmen.


Phantom Amthor: `build_phantom_amthor.py` abschließend nach dem Text-/Namensbau anwenden. Der Bau liest die beiden vorbereiteten Kopf-JSONs und Texturen aus `models/phantom-amthor`; Blender ist dafür nicht erforderlich. Nur die optionale erneute Ableitung aus den hochgeladenen Originalmodellen verwendet `blender -b -t 2 -P tools/export_phantom_heads.py -- /pfad/burns_lowpoly.obj /pfad/Crazy_Gesture.fbx`. Die zusätzliche Textbox 209B verwendet den nativen EVENT-Abschluß von 002D und dessen untere Bildschirmposition. Der Marktplatz-Tausch erfolgt nur nach Zeldas Flucht, in deutscher Sprache, nach Prüfung von Maskenreaktionen; NPC-Positionen bleiben nativ.

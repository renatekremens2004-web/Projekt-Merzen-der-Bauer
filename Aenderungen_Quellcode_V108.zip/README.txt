Source delta for the existing V107 project. Reapply tools/build_dialogue_v94.py last; it now preserves the approved V108 two-handed sword damage. This ZIP contains no ROM or save files.

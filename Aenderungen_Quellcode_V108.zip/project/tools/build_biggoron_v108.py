"""Double the existing two-handed sword damage without changing other attacks."""
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
p = root / 'src/code/z_collision_check.c'
s = p.read_text()
old = '(DMG_SLASH_KOKIRI|DMG_SPIN_KOKIRI|DMG_JUMP_KOKIRI)'
new = '(DMG_SLASH_KOKIRI|DMG_SPIN_KOKIRI|DMG_JUMP_KOKIRI|DMG_SLASH_GIANT|DMG_SPIN_GIANT|DMG_JUMP_GIANT)'
assert s.count(old) + s.count(new) == 2, 'Expected both native sword damage paths'
s = s.replace(old, new)
if p.read_text() != s:
    p.write_text(s)
print('V108: two-handed sword damage doubled in table and generic damage paths.')

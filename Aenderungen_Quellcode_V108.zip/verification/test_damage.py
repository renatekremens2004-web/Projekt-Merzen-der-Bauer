from pathlib import Path
import re,subprocess,ctypes,json
W=Path(__file__).parent;O=Path('/workspace/oot-burns-pal');text=(O/'src/code/z_collision_check.c').read_text();header=(O/'include/collision_check.h').read_text();defines='\n'.join(l for l in header.splitlines()if l.startswith('#define DMG_'))
def function(name):
 a=text.index(name+'(');a=text.rfind('\n',0,a)+1;b=text.index('\n}',a)+2;return text[a:b]
s='''#include <stdint.h>\n#include <assert.h>\ntypedef uint8_t u8;typedef int32_t s32;typedef uint32_t u32;typedef float f32;\n#define UNUSED\n#define false 0\n#define NULL ((void*)0)\n#define ASSERT(a,b,c,d) assert(a)\n#define ACTOR_PLAYER 0\n#define ACTOR_EN_M_THUNDER 1\n#define ACTOR_EN_IK 2\n#define ACTORCAT_ENEMY 5\n#define AC_HIT 2\n#define AC_HARD 4\n#define ACELEM_HIT 2\n#define ACELEM_NO_DAMAGE 4\ntypedef struct {u8 table[32];} DamageTable;\ntypedef struct {int id,params,category;struct{DamageTable*damageTable;u8 damage,damageReaction,health;}colChkInfo;}Actor;\ntypedef struct Collider {Actor*actor;int acFlags;}Collider;\ntypedef struct ColliderElement {int acElemFlags;Collider*acHit;struct ColliderElement*acHitElem;struct{u32 dmgFlags;u8 damage;}atDmgInfo;struct{int defense;}acDmgInfo;}ColliderElement;\ntypedef void PlayState;typedef void CollisionCheckContext;\n'''+defines+'\n'+function('s32 CollisionCheck_IsPlayerMasterSwordHit').replace('s32 CollisionCheck_IsPlayerMasterSwordHit','s32 CollisionCheck_IsPlayerMasterSwordHit')+'\n'+function('void CollisionCheck_ApplyDamage')+'\n'+function('u8 CollisionCheck_GetSwordDamage')+'''
int table_damage(unsigned flags,int value,int attacker,int hard){DamageTable table={0};Actor at={.id=attacker};Actor victim={.id=9,.colChkInfo={.damageTable=&table,.health=200}};Collider atk={.actor=&at};Collider def={.actor=&victim,.acFlags=AC_HIT|(hard?AC_HARD:0)};ColliderElement ae={.atDmgInfo={.dmgFlags=flags}},de={.acElemFlags=ACELEM_HIT,.acHit=&atk,.acHitElem=&ae};for(int i=0;i<32;i++)table.table[i]=value;CollisionCheck_ApplyDamage(0,0,&def,&de);return victim.colChkInfo.damage;}
'''
new='(DMG_SLASH_KOKIRI|DMG_SPIN_KOKIRI|DMG_JUMP_KOKIRI|DMG_SLASH_GIANT|DMG_SPIN_GIANT|DMG_JUMP_GIANT)';old='(DMG_SLASH_KOKIRI|DMG_SPIN_KOKIRI|DMG_JUMP_KOKIRI)';result=[]
for tag,code in [('v107',s.replace(new,old)),('v108',s)]:
 p=W/(tag+'-damage.c');p.write_text(code);subprocess.run(['gcc','-shared','-fPIC','-O2',str(p),'-o',str(W/(tag+'-damage.so'))],check=True)
a,b=[ctypes.CDLL(str(W/(t+'-damage.so')))for t in ['v107','v108']];giant={10,23,26}
# Three shared two-handed sword attack flags; all unrelated attack types retain V107 behavior.
for i in range(32):
 flag=1<<i;av=a.CollisionCheck_GetSwordDamage(flag);bv=b.CollisionCheck_GetSwordDamage(flag);assert bv==av*(2 if i in giant else 1),(i,av,bv)
 for value in [0,1,4,8,15]:
  for attacker in [0,1,9]:
   av=a.table_damage(flag,value,attacker,0);bv=b.table_damage(flag,value,attacker,0);assert bv==av*(2 if i in giant and attacker in [0,1]else 1),(i,value,attacker,av,bv)
   assert b.table_damage(flag,value,attacker,1)==0
 result.append(dict(bit=i,generic_before=av if False else a.CollisionCheck_GetSwordDamage(flag),generic_after=b.CollisionCheck_GetSwordDamage(flag)))
assert [b.CollisionCheck_GetSwordDamage(1<<i)for i in [10,23,26]]==[8,8,16]
(W/'damage-results.json').write_text(json.dumps(dict(passed=True,flags_checked=32,table_combinations=480,hard_armor_combinations=480,details=result),indent=2));print('DAMAGE_PASSED 32 flags;480 table hits;480 hard-armor checks;Biggoron 8/8/16')

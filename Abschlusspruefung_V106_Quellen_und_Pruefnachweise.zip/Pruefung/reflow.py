from pathlib import Path
import sys,re,json,hashlib
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer');sys.path.insert(0,str(R/'tools'))
from build_story import messages,split_pages,plain,LEX,controls,Layout,c_text
src=(W/'message_data.before.h').read_text();m=messages(src);layout=Layout(O)
# This audit preserves existing wording, including literal names and spelling.
def preserved_wrap(text,width):
 lines=[];line=''
 for word in text.split():
  assert layout.width(word)<=width,(word,width)
  candidate=(line+' '+word).strip()
  if line and layout.width(candidate)>width:lines.append(line);line=word
  else:line=candidate
 if line:lines.append(line)
 return lines
layout.wrap=preserved_wrap

exec(Path('/tmp/goron-dialogue-v105/apply.py').read_text().split('def styled(body):')[1].split('\npages={')[0].join(['def styled(body):','']))
report={};bodies={};skipped=[]
for i,d in m.items():
 b=d['parts'][2][2];ps,seps=split_pages(b)
 if i=='71B3' or len(ps)<2 or any(s!='BOX_BREAK'for s in seps):continue
 if any(w in b for w in ['ITEM_ICON(', 'TEXT_SPEED(', 'BACKGROUND(', 'QUICKTEXT_', 'HIGHSCORE(', 'FISH_INFO','MARATHON_TIME','RACE_TIME','POINTS','TOKENS','TIME','OCARINA']):continue
 # Restrict to plain prose: retain a trailing choice page and all native end controls.
 toks=LEX.findall(b);unsupported=[t for t in toks if not(t.startswith('"')or t in ['NAME','UNSKIPPABLE','BOX_BREAK','EVENT','PERSISTENT','TWO_CHOICE','THREE_CHOICE']or t.startswith(('COLOR(','TEXTID(','FADE(','SFX(')))]
 if unsupported:continue
 pp=[' '.join(plain(x).split())for x in ps];orig=pp.copy();changed=[]
 choice=any(t in toks for t in ['TWO_CHOICE','THREE_CHOICE'])
 for n in range(len(pp)-1):
  if choice and n>=len(pp)-2:continue
  a,z=pp[n:n+2]
  if not a or not z or re.search(r'[.!?:…]["\u201c\u201d]*$',a):continue
  # Only awkward continuation fragments, never intentional named/sign pages.
  if not(z[0].islower() or z.startswith(('Friedrich','Merz','Arsch','Hände','Zoras','Königreich'))):continue
  tail=re.split(r'[.!?]',z)[0]
  if len(tail)>95 and len(z)>110:continue
  full=a+' '+z;candidates=[]
  for match in re.finditer(r'(?<=[.!?])\s+',a):
   pos=match.end();left=full[:pos].strip();right=full[pos:].strip()
   if not left or not right:continue
   if left.endswith(('Mr.','Dr.','bzw.','z.')):continue
   if len(layout.wrap(left,210))<=4 and len(layout.wrap(right,210))<=4:
    candidates.append((abs(len(left)-len(right)),pos,left,right))
  if not candidates:
   # A long sentence may need a clause break, but do not turn ordinary balanced
   # continuations into a comprehensive prose reformat.
   if len(z)>65:continue
   for match in re.finditer(r'[,;]\s+|\s+(?=(?:aber|weil|wenn|damit|und|daß|denn)\b)',a):
    pos=match.end() if ','in match.group()or';'in match.group()else match.start()+1
    left=full[:pos].strip();right=full[pos:].strip()
    if len(left)>25 and len(right)>25 and len(layout.wrap(left,210))<=4 and len(layout.wrap(right,210))<=4:candidates.append((abs(len(left)-len(right))+100,pos,left,right))
  if candidates:
   _,_,left,right=min(candidates);pp[n:n+2]=[left,right];changed.append(n+1)
 if pp==orig:continue
 # Preserve the exact sequence of non-whitespace characters AND their colors.
 pairs=styled(b);before=[p for p in pairs if not p[0].isspace()];after=[];pos=0;blocks=[]
 prefix=[t for t in toks if t.startswith('SFX(')]
 end=[t for t in toks if t in ['EVENT','PERSISTENT']or t.startswith(('TEXTID(','FADE('))]
 for n,t in enumerate(pp):
  rendered='\n'.join(layout.wrap(t,210));assert len(rendered.splitlines())<=4
  if pos<len(pairs)and pairs[pos][0]==' ':pos+=1
  runs=[];last=None;buf=''
  for ch in rendered:
   old,col=pairs[pos];assert old==ch or(old==' 'and ch=='\n'),(i,pos,old,ch)
   if not ch.isspace():after.append((ch,col))
   if last is not None and col!=last:runs.append('COLOR('+last+') '+c_text(buf,last));buf=''
   last=col;buf+=ch;pos+=1
  if buf:runs.append('COLOR('+last+') '+c_text(buf,last))
  # Original choice formatting is retained verbatim on its untouched last page.
  if choice and n==len(pp)-1:
   original=ps[n];blocks.append(original.strip());continue
  lead=('UNSKIPPABLE 'if'UNSKIPPABLE'in ps[n]else'')+(' '.join(prefix)+' 'if n==0 and prefix else'')
  blocks.append(lead+' '.join(runs))
 assert pos==len(pairs) and before==after,(i,'character/color mismatch')
 nb='\n'+'\nBOX_BREAK\n'.join(blocks)
 if not choice:nb+=(' '+' '.join(end)if end else'')
 nb+='\n'
 assert controls(nb)==controls(b),(i,controls(nb),controls(b))
 assert len(split_pages(nb)[0])==len(ps)
 report[i]=dict(before=orig,after=pp,moved_boundaries=changed,controls=controls(b));bodies[i]=nb
for i in sorted(bodies,key=lambda k:m[k]['parts'][2][0],reverse=True):
 a,b,_=m[i]['parts'][2];src=src[:a]+bodies[i]+src[b:]
now=messages(src)
for i,d in m.items():
 for lang in [0,1,3]:assert d['parts'][lang][2]==now[i]['parts'][lang][2]
 assert [p for p in styled(d['parts'][2][2])if not p[0].isspace()]==[p for p in styled(now[i]['parts'][2][2])if not p[0].isspace()],i
 if i not in bodies:assert d['parts'][2][2]==now[i]['parts'][2][2]
assert '401B'in bodies,'explicit user example repaired'
(W/'reflow-bodies.json').write_text(json.dumps(bodies,ensure_ascii=False,indent=2));(W/'reflow-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(W/'message_data.proposed.h').write_text(src)
print('Proposed',len(bodies),'messages,',sum(len(x['moved_boundaries'])for x in report.values()),'boundaries')
for i,x in report.items():
 print(i,':', '; '.join(x['before'][n-1][-55:]+' / '+x['before'][n][:45]+' --> '+x['after'][n-1][-55:]+' / '+x['after'][n][:65]for n in x['moved_boundaries']))

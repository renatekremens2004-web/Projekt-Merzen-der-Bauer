from pathlib import Path
import json,struct,os,subprocess,concurrent.futures,time
w=Path(__file__).resolve().parent;s=json.loads((w/'all-symbols-normal.json').read_text());base=(w/'dodongo-walk.c').read_text();(w/'adult-reward-walk.c').write_text(base);exe=w/'adult-reward-walk';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(w/'adult-reward-walk.c'),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
results=[]
def one(spec):
 name,scene,bit,room,xyz=spec;q=bytearray((w/f'reward-{name}.save').read_bytes());e=struct.unpack_from('>I',q)[0];struct.pack_into('>I',q,0xd4+scene*0x1c+8,1<<room);struct.pack_into('>fffhHhB',q,0x1368,*xyz,-32768,0xdff,e,room);struct.pack_into('>H',q,0x70,(struct.unpack_from('>H',q,0x70)[0]&0xfff)|0x1000);save=w/f'final-reward-{name}.save';save.write_bytes(q);t=time.monotonic();log=w/f'final-reward-{name}.log'
 with log.open('w')as out:
  try:r=subprocess.run([str(exe),str(w/'normal.z64'),f'final-reward-{name}-v106-direct','13000','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(save)],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null',REWARD_SCENE=hex(scene),REWARD_BIT=hex(bit)),stdout=out,stderr=subprocess.STDOUT,timeout=1500);ok=r.returncode==0;error=None if ok else log.read_text()[-2100:]
  except Exception as x:ok=False;error=repr(x)
 results.append(dict(case=name,passed=ok,error=error,elapsed=round(time.monotonic()-t,1)));(w/'final-water-results.json').write_text(json.dumps(results,indent=2));print('ADULT_REWARD_RETRY',name,ok,error or'',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as p:list(p.map(one,[('water',0x16,4,1,(0,-277,100))]))

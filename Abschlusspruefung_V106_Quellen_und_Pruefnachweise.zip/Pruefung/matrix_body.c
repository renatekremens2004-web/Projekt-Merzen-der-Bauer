static void capture_render(void){}
static FILE* batch;static unsigned total,idx,epoch=300,loaded=0,phase=0,mark=0,oldpause=0,hash0=0,failures=0,paused=0,menu_requested=0;static unsigned exp_scene,exp_room,exp_age,do_pause;static char casename[65];
static unsigned be32(FILE*f){unsigned q=0;for(int i=0;i<4;i++)q=(q<<8)|fgetc(f);return q;}
static unsigned hashmem(unsigned a,unsigned n){unsigned h=2166136261;for(unsigned i=0;i<n;i++)h=(h^DebugMemRead8(a+i))*16777619;return h;}
static unsigned colhash(void){unsigned h=r32(play+0x7c0);if(h<0x80000000||h>0x80400000-44)return 0;unsigned v=r32(h+0x10),p=r32(h+0x18),nv=DebugMemRead16(h+12),np=DebugMemRead16(h+20);if(v<0x80000000||v+nv*6>0x80400000||p<0x80000000||p+np*16>0x80400000)return 0;return hashmem(v,nv*6)^hashmem(p,np*16);}
static void dumpactors(void){for(int c=0;c<12;c++)for(unsigned p=r32(play+0x1c34+c*8),n=0;p>=0x80000000&&p<0x80400000&&n<250;p=r32(p+0x124),n++)if(r32(p+0x130))printf("ACTOR %s id=%04x params=%04x draw=%x xyz=%.1f,%.1f,%.1f\n",casename,DebugMemRead16(p),DebugMemRead16(p+0x1c),r32(p+0x134),rf(p+0x24),rf(p+0x28),rf(p+0x2c));}
static unsigned resources(void){unsigned c=play+0x117a4,begin=r32(c),end=r32(c+4),last=begin,n=DebugMemRead8(c+8),bad=0;for(unsigned i=0;i<n&&i<19;i++){unsigned p=c+12+i*0x44;int obj=(int16_t)DebugMemRead16(p);if(obj<0)obj=-obj;if(obj>0&&obj<=0x1b0){unsigned e=r32(p+4)+r32(OBJECTS+obj*8+4)-r32(OBJECTS+obj*8);if(e>last)last=e;}}
 unsigned od=DebugMemRead16(DENIED_OBJECT),ad=DebugMemRead16(DENIED_OVERLAY),ai=DebugMemRead16(DENIED_INSTANCE);if(n>19||last>end||od||ad||ai)bad=1;
 for(unsigned q=0;q<3;q++){unsigned ctx=r32(play),off=0x2a8+q*16;if(r32(ctx+off+8)>r32(ctx+off+12))bad=1;}
 printf("RESOURCE %s slots=%u used=%u free=%d denied=%u,%u,%u last=%x bad=%u\n",casename,n,last-begin,(int)(end-last),od,ad,ai,DebugMemRead16(DENIED_LAST),bad);return bad;}
static void nextcase(unsigned f,int inject){
 if(!batch){batch=fopen(getenv("BATCH_FILE"),"rb");need(batch!=NULL,"batch exists");total=be32(batch);}
 if(idx>=total){printf("MATRIX_COMPLETE cases=%u failures=%u\n",idx,failures);CoreDoCommand(M64CMD_STOP,0,NULL);return;}
 need(fread(casename,1,64,batch)==64,"case name");casename[64]=0;unsigned v=be32(batch);exp_scene=v>>16;exp_room=(v>>8)&255;exp_age=v&255;do_pause=be32(batch);
 unsigned char snap[0x1428];need(fread(snap,1,sizeof(snap),batch)==sizeof(snap),"case fixture");
 if(inject){for(unsigned i=0;i<sizeof(snap);i++)DebugMemWrite8(savebase+i,snap[i]);DebugMemWrite32(savebase+0x135c,0);DebugMemWrite8(play+0x11de8,exp_age);DebugMemWrite16(savebase+0x1412,0xffef);DebugMemWrite8(play+0x1d6c,0);unsigned game=GAMETABLE+3*0x30;DebugMemWrite8(play+0x11de9,1);DebugMemWrite32(play+0xc,r32(game+0x18));DebugMemWrite32(play+0x10,0x12518);DebugMemWrite32(play+0x98,0);play=0;player=0;}
 printf("CASE_BEGIN %u %s scene=%x room=%u age=%u pause=%u\n",idx,casename,exp_scene,exp_room,exp_age,do_pause);idx++;epoch=f;loaded=phase=mark=oldpause=hash0=paused=menu_requested=0;
}
static void finishcase(unsigned f,const char*state){unsigned bad=resources();if(bad)failures++;printf("CASE_DONE %s status=%s resources_ok=%u paused=%u\n",casename,state,!bad,paused);if(buttons)buttons(0);nextcase(f,1);}
static void onframe(unsigned f){
 baseframe(f);if(f==300){nextcase(f,0);return;}if(f<350)return;findplay();if(!play||!player)return;unsigned dt=f-epoch,v=0;
 if(dt<45)return;unsigned scene=DebugMemRead16(play+0xa4),room=DebugMemRead8(play+0x11cbc),st=DebugMemRead16(play+0x10934);
 if(!loaded){if(scene!=exp_scene||room!=exp_room){if(dt>120){printf("FIXTURE_MISMATCH %s got=%x/%u expected=%x/%u\n",casename,scene,room,exp_scene,exp_room);finishcase(f,"fixture-mismatch");}return;}loaded=1;dumpactors();resources();printf("SCENE_READY %s xyz=%.1f,%.1f,%.1f floor=%x\n",casename,rf(player+0x24),rf(player+0x28),rf(player+0x2c),DebugMemRead16(player+0x88));}
 if(scene!=exp_scene||room!=exp_room){printf("AUTO_TRANSITION %s got=%x/%u\n",casename,scene,room);finishcase(f,"automatic-transition");return;}
 if(dt>=75&&!do_pause){finishcase(f,"load-only");return;}
 if(phase==0&&dt>=75){hash0=colhash();v=0x10;phase=1;mark=f;menu_requested=1;}
 if(phase==1&&st==6){unsigned name=r32(play+0x10898),tail=((name+3584+15)&~15)+7168;paused=1;printf("PAUSE_READY %s tail=%x end=%x\n",casename,tail,r32(play+0x117a8));if(tail>r32(play+0x117a8)){puts("PAUSE_OVERFLOW");failures++;}phase=2;mark=f;}
 if(phase==1&&f>mark+110){printf("PAUSE_UNAVAILABLE %s cs=%u msg=%x state=%u\n",casename,DebugMemRead8(play+0x1d6c),DebugMemRead16(play+0x104d0),st);finishcase(f,"load-only-menu-unavailable");return;}
 if(phase==2&&f==mark+12)v=0x10;
 if(phase==2&&st==0){phase=3;mark=f;}
 if(phase==3&&f>mark+20){unsigned hash1=colhash();printf("COLLISION %s before=%x after=%x unchanged=%u\n",casename,hash0,hash1,hash0==hash1);if(hash0!=hash1){puts("COLLISION_CHANGED_AFTER_PAUSE");failures++;}dumpactors();finishcase(f,"pause-roundtrip");return;}
 if(dt>340){printf("CASE_TIMEOUT %s phase=%u pause=%u\n",casename,phase,st);failures++;finishcase(f,"timeout");return;}
 if(buttons)buttons(v);
}

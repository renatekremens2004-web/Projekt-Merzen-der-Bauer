from pathlib import Path
import re,json,csv,struct
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');s=json.loads((W/'all-symbols-normal.json').read_text());tab={id:name for name,id in re.findall(r'DEFINE_OBJECT\((\w+),\s*(\w+)\)',(O/'include/tables/object_table.h').read_text())}
def size(id):
 
 if id not in tab:return 0
 n=tab[id];return s['_'+n+'SegmentRomEnd']-s['_'+n+'SegmentRomStart']
# Native baseline sizes from the clean PAL DMA table, independent of the mod ELF.
clean=(O/'baseroms/pal-1.0/baserom-decompressed.z64').read_bytes();names=[r[0]for r in list(csv.reader((O/'baseroms/pal-1.0/segments.csv').open()))[1:]]
base={n:struct.unpack_from('>II',clean,0x7950+i*16)[1]-struct.unpack_from('>II',clean,0x7950+i*16)[0]for i,n in enumerate(names)}
delta={id:size(id)-base.get(n,0)for id,n in tab.items()if '_'+n+'SegmentRomEnd'in s and size(id)!=base.get(n,0)}
rows=[]
for p in (O/'extracted/pal-1.0/assets/scenes').rglob('*ObjectList.inc.c'):
 folder=p.parent;scene=folder.name;main=folder/(scene+'_scene.inc.c')
 if not main.exists():continue
 text=main.read_text();m=re.search(r'SCENE_CMD_SPECIAL_FILES\([^,]*,\s*(OBJECT_\w+)\)',text)
 sub=m[1]if m and m[1]!='OBJECT_INVALID' else None
 ids=list(dict.fromkeys(re.findall(r'\bOBJECT_\w+',p.read_text())))
 if any(i not in tab for i in ids):continue
 for age,link in [('child','OBJECT_LINK_CHILD'),('adult','OBJECT_LINK_BOY')]:
  allids=list(dict.fromkeys(['OBJECT_GAMEPLAY_KEEP',link]+([sub]if sub else [])+ids));needed=sum(size(i)for i in allids)
  # Common pool; special scene allocations are reported separately below.
  cap=1000*1024-4096
  if scene=='ganon_boss':cap=1150*1024-4096
  if scene in ['jyasinboss','ganon']:cap=1050*1024-4096
  if scene=='kenjyanoma':cap=1050*1024-4096
  if scene=='spot20' and'AltHeaders'in p.name:cap=1128*1024-4096
  # Resolve the actual room setup header instead of treating credits as ordinary gameplay.
  sym=p.name.removesuffix('.inc.c');cmd=next((q for q in folder.glob('*.inc.c') if 'SCENE_CMD_OBJECT_LIST' in q.read_text() and sym in q.read_text()),None);layers=[0]
  if cmd:
   name=cmd.name.removesuffix('.inc.c');matched=[]
   for q in folder.glob('*AltHeaders.inc.c'):
    entries=re.findall(r'^\s*(\w+)\s*,',q.read_text(),re.M)
    matched.extend(i+1 for i,e in enumerate(entries)if e==name)
   if matched:layers=matched
  if scene=='ganon_demo':cap=(1000 if 4 in layers else 1150)*1024-4096
  if scene=='kenjyanoma':cap=(1226 if min(layers)>=5 else 1050)*1024-4096
  if scene=='spot20'and any(i in [9,11]for i in layers):cap=1128*1024-4096
  # Scene setup headers may omit/change the sub-keep during credits.
  choices=[]
  scene_arrays=list(folder.glob(scene+'_scene*AltHeaders.inc.c'))
  for layer in layers:
   scmd=main
   if scene_arrays and layer>0:
    entries=re.findall(r'^\s*(\w+)\s*,',scene_arrays[0].read_text(),re.M)
    selected=entries[layer-1]if layer<=len(entries)else 'NULL'
    if selected=='NULL'and layer==3 and len(entries)>1:selected=entries[1]
    if selected!='NULL'and(folder/(selected+'.inc.c')).exists():scmd=folder/(selected+'.inc.c')
   km=re.search(r'SCENE_CMD_SPECIAL_FILES\([^,]*,\s*(OBJECT_\w+)\)',scmd.read_text())
   keep=km[1]if km and km[1]!='OBJECT_INVALID'else None
   current=['OBJECT_GAMEPLAY_KEEP',link]+([keep]if keep else [])+ids
   choices.append((sum(size(i)for i in current),current))
  needed,allids=max(choices,key=lambda v:v[0])
  supported=True;reason=''
  if age=='adult'and scene=='spot15':supported=False;reason='Hyrule Castle is a child scene'
  if age=='adult'and scene=='spot09'and min(layers)>=4:supported=False;reason='CS_DEST_GERUDO_VALLEY_CREDITS explicitly selects child Link'
  rows.append(dict(file=str(p.relative_to(O)),scene=scene,age=age,layers=layers,supported=supported,reason=reason,needed=needed,slots=len(allids),capacity=cap,excess=needed-cap,growth=sum(delta.get(i,0)for i in allids)))
report={'baseline_object_growth':delta,'rooms':rows,'over_1MB':[r for r in rows if r['excess']>0],'too_many_slots':[r for r in rows if r['slots']>19],'supported_overflows':[r for r in rows if r['excess']>0 and r['supported']]};(W/'object-bank-audit.json').write_text(json.dumps(report,indent=2))
print('Objects with growth:',{i:d for i,d in delta.items()if d>0});print('Object lists audited',len(rows)//2,'over pool',len(report['over_1MB']),'slot overflow',len(report['too_many_slots']),'supported overflows',len(report['supported_overflows']))
for r in report['over_1MB'][:35]:print(r['scene'],r['age'],r['needed'],r['excess'],r['growth'],Path(r['file']).name)

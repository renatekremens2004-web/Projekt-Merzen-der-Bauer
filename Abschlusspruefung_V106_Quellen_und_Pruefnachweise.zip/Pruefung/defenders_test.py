from pathlib import Path
import json,subprocess,os
w=Path(__file__).resolve().parent;s=json.loads((w/'all-symbols-normal.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(s[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/defenders-stall.bin').replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=Path('/workspace/defenders-v63/body.c').read_text();body='static FILE* recordPipe=0; static unsigned pending=0,videoFrames=0; static void capture_render(void){}\n'+body[body.index('static void onframe('):]
for k,v in [('SHOT_OFFSET',hex(s['gDefenderShotsV60']-s['_ovl_En_Go2SegmentStart'])),('SOUND_OFFSET',hex(s['gDefenderSoundStartsV62']-s['_ovl_En_Go2SegmentStart'])),('SFXBANKS_ADDR',hex(s['gSfxBanks']))]:body=body.replace(k,v)
(w/'defenders.c').write_text(base[:a]+body+base[b:]);exe=w/'defenders';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(w/'defenders.c'),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
with(w/'defenders-normal.log').open('w')as f:r=subprocess.run([str(exe),str(w/'normal.z64'),'defenders-regression-v106-direct','7500','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),'/workspace/defenders-v63/nocturne.save'],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=1500)
print('DEFENDERS_CURRENT_RESULT',r.returncode,flush=True)

from pathlib import Path
import re,json,struct,math
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');E=O/'extracted/pal-1.0/assets/scenes'
scenes=[(int(h,16),seg,enum)for h,seg,enum in re.findall(r'/\* 0x([0-9A-F]+) \*/ DEFINE_SCENE\((\w+),\s*\w+,\s*(\w+)',(O/'include/tables/scene_table.h').read_text())]
entr={}
for h,n,sc in re.findall(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\((\w+),\s*(\w+)',(O/'include/tables/entrance_table.h').read_text()):entr.setdefault(sc,int(h,16))
# Support only normal gameplay scene setups. Credits/story cutscenes get their own
# native scripted runs; this is room-load and pause regression coverage.
cases=[]
for scene,seg,enum in scenes:
 if enum not in entr or scene in [0x1a] or scene>=0x65:continue
 f=next(E.rglob(seg+'.c'),None)
 if not f:continue
 prefix=seg.removesuffix('_scene');rooms=sorted((p for p in f.parent.glob(prefix+'_room_*.c')if re.search(r'_room_(\d+)\.c$',p.name)),key=lambda p:int(re.search(r'_room_(\d+)\.c$',p.name)[1]))
 if not rooms:continue
 floors=[];vp=next(f.parent.glob(seg+'*VtxList.inc.c'),None);pp=next(f.parent.glob(seg+'*PolyList.inc.c'),None)
 if vp and pp:
  vs=[tuple(map(int,x))for x in re.findall(r'\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\}',vp.read_text())]
  polys=re.findall(r'COLPOLY_VTX\((\d+),[^)]*\).*?COLPOLY_VTX\((\d+),[^)]*\).*?COLPOLY_VTX\((\d+),[^)]*\).*?COLPOLY_SNORMAL\(([-.\d]+)\).*?COLPOLY_SNORMAL\(([-.\d]+)\).*?COLPOLY_SNORMAL\(([-.\d]+)\)',pp.read_text(),re.S)
  for a,b,c,nx,ny,nz in polys:
   if float(ny)>.98:
    vv=[vs[int(i)]for i in [a,b,c]];floors.append(tuple(sum(v[k]for v in vv)/3 for k in range(3)))
 for p in rooms:
  room=int(re.search(r'_room_(\d+)\.c$',p.name)[1]);af=next(f.parent.glob(p.stem+'_*ActorEntryList.inc.c'),None)
  xyz=(0,100,0)
  if af:
   nums=re.findall(r'(ACTOR_\w+)\s*,\s*\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\}',re.sub(r'//[^\n]*','',af.read_text()))
   ranked=sorted(nums,key=lambda x:0 if any(v in x[0]for v in ['EN_BOX','EN_GO2','ELF_MSG2','EN_KO','EN_ITEM00','OBJ_TSUBO'])else 1)
   if ranked:xyz=tuple(map(int,ranked[0][1:]))
  if floors:
   xyz=min(floors,key=lambda t:(t[0]-xyz[0])**2+(t[2]-xyz[2])**2+4*(t[1]-xyz[1])**2)
  ages=[1]if scene in [0,1,2,8,0x11,0x12,0x13]else[0]
  if scene==6:ages=[1,0]
  if scene>=0x1b:ages=[1,0]
  # Exclude age/scene combinations that normal entrances never use.
  if enum in ['SCENE_HYRULE_CASTLE','SCENE_CASTLE_COURTYARD_GUARDS_DAY','SCENE_CASTLE_COURTYARD_GUARDS_NIGHT','SCENE_CASTLE_COURTYARD_ZELDA','SCENE_MARKET_DAY','SCENE_MARKET_NIGHT','SCENE_MARKET_ENTRANCE_DAY','SCENE_MARKET_ENTRANCE_NIGHT','SCENE_BACK_ALLEY_DAY','SCENE_BACK_ALLEY_NIGHT']:ages=[1]
  if enum in ['SCENE_MARKET_RUINS','SCENE_MARKET_ENTRANCE_RUINS','SCENE_OUTSIDE_GANONS_CASTLE']:ages=[0]
  # Focus normal accessible main world, every dungeon room and every changed
  # gameplay room. House interiors are included; unused test maps are excluded.
  for age in ages:
   name=f'{scene:02x}-{prefix}-{room}-'+('child'if age else'adult')
   q=bytearray(Path('/workspace/kokiri-speed-v66/child.save'if age else'/workspace/zoras-erwachsen/boots-land.save').read_bytes());e=entr[enum]
   struct.pack_into('>III',q,0,e,age,0);q[0xed4:0xf34]=bytes(0x60);q[0xd4:0xd4+101*0x1c]=bytes(101*0x1c)
   struct.pack_into('>I',q,0xa4,0);struct.pack_into('>H',q,0xc,0x8000);struct.pack_into('>I',q,0x10,0);struct.pack_into('>HH',q,0x2e,0x140,0x140)
   struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,xyz[0],xyz[1]+3,xyz[2],0,0xdff,e,room);q[0x1409]=1
   pause=scene<0x10 or scene>=0x1b
   cases.append(dict(name=name,scene=scene,enum=enum,room=room,age=age,entrance=e,xyz=xyz,pause=pause,save=bytes(q).hex()))
(W/'matrix.json').write_text(json.dumps(cases,indent=2));print('MATRIX',len(cases),'rooms',len(set((c['scene'],c['room'])for c in cases)))
for k in range(2):
 cs=cases[k::2];out=bytearray(struct.pack('>I',len(cs)))
 for c in cs:out+=c['name'].encode()[:63].ljust(64,b'\0')+struct.pack('>HBBI',c['scene'],c['room'],c['age'],c['pause'])+bytes.fromhex(c['save'])
 (W/f'matrix-{k}.bin').write_bytes(out);(W/f'matrix-{k}-first.save').write_bytes(bytes.fromhex(cs[0]['save']))

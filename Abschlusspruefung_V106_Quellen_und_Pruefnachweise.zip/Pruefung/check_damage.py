from pathlib import Path
import ast,re,subprocess,json,hashlib
w=Path(__file__).resolve().parent;o=Path('/workspace/oot-burns-pal');old=Path('/workspace/shadow-tunic/test_damage_equipment.py').read_text();tree=ast.parse(old)
ns={}
for node in tree.body:
 if isinstance(node,ast.FunctionDef)and node.name=='function':exec(compile(ast.Module([node],type_ignores=[]),'<function>','exec'),{'re':re},ns)
extract=ns['function'];prefix=next(ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='prefix'for t in n.targets))
health=extract((o/'src/code/z_parameter.c').read_text(),'Health_ChangeBy');header=(o/'include/shadow_tunic.h').read_text();tests=r'''
int main(void){unsigned cases=0;const int hits[]={-2048,-512,-65,-64,-33,-32,-17,-16,-8,-4,-3,-2,-1,0,1,4,16,64};
for(int age=0;age<2;age++)for(int tunic=1;tunic<=3;tunic++)for(int light=0;light<2;light++)for(int shadow=0;shadow<2;shadow++)for(int dd=0;dd<2;dd++)for(int h=0;h<8;h++)for(unsigned k=0;k<sizeof(hits)/sizeof(*hits);k++){
 memset(&gSaveContext,0,sizeof(gSaveContext));gSaveContext.save.linkAge=age;gSaveContext.save.info.equips.equipment=tunic<<8;gSaveContext.save.info.infTable[28]=(light?0x2000:0)|(shadow?0x4000:0);gSaveContext.save.info.playerData.isDoubleDefenseAcquired=dd;gSaveContext.save.info.playerData.healthCapacity=320;int hp=h==7?320:h*16;gSaveContext.save.info.playerData.health=hp;
 SaveContext before=gSaveContext;int amount=hits[k],div=1;if(amount<0){if(shadow&&tunic==1)div=4;else if(dd||(light&&tunic==1)||tunic==2||tunic==3)div=2;amount=-((-amount+div-1)/div);}int expect=hp+amount;if(expect<0)expect=0;if(expect>320)expect=320;
 int alive=Health_ChangeBy(NULL,hits[k]);assert(gSaveContext.save.info.playerData.health==expect);assert(alive==(expect>0));gSaveContext.save.info.playerData.health=before.save.info.playerData.health;assert(!memcmp(&before,&gSaveContext,sizeof(before)));cases++;}
 printf("DAMAGE_LOGIC_PASSED %u cases\n",cases);return 0;}
'''
src=prefix+'\n'+header+'\n'+health+'\n'+tests;(w/'damage-test.c').write_text(src);subprocess.run(['gcc','-std=c11','-O2',str(w/'damage-test.c'),'-o',str(w/'damage-test')],check=True)
r=subprocess.check_output([str(w/'damage-test')],text=True);print(r);(w/'damage-verification.json').write_text(json.dumps(dict(passed=True,cases=int(re.search(r'(\d+) cases',r)[1]),source_sha256=hashlib.sha256(health.encode()).hexdigest(),header_sha256=hashlib.sha256(header.encode()).hexdigest(),method='Host compilation of actual current Health_ChangeBy and tunic macros; not a ROM combat test'),indent=2))

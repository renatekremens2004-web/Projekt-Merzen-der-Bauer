from pathlib import Path
import json,struct,hashlib
import crunch64
w=Path(__file__).resolve().parent;a=(w/'gameplay-audit-debug-r1.z64').read_bytes();b=(w/'debug.z64').read_bytes();old=json.loads((w/'all-symbols-debug-r1.json').read_text());new=json.loads((w/'all-symbols-debug.json').read_text());off=new['_dmadataSegmentRomStart'];names={v:k[1:-15]for k,v in new.items()if k.startswith('_')and k.endswith('SegmentRomStart')};same=[];diff=[];details={}
def seg(rom,i):
 vs,ve,ps,pe=struct.unpack_from('>IIII',rom,off+16*i)
 if not ve:return None
 if pe==0xffffffff:return (vs,ve,None)
 data=rom[ps:ps+ve-vs]if pe==0 else crunch64.yaz0.decompress(rom[ps:pe])
 assert len(data)==ve-vs
 return vs,ve,bytes(data)
for i in range(3000):
 x=seg(a,i);y=seg(b,i)
 if x is None or y is None:assert x is y;break
 name=names.get(y[0],hex(y[0]));record=dict(index=i,name=name,before_size=x[1]-x[0],after_size=y[1]-y[0],vrom_same=x[:2]==y[:2])
 if x[2]==y[2]:same.append(record)
 else:diff.append(record)
 if name=='code':
  textsize=new['_codeSegmentTextEnd']-new['_codeSegmentTextStart'];changes=[j for j,(p,q)in enumerate(zip(x[2],y[2]))if p!=q];lo=new['sGerMessageEntryTable']-new['_codeSegmentStart'];hi=new['sFraMessageEntryTable']-new['_codeSegmentStart'];details=dict(text_binary_identical=x[2][:textsize]==y[2][:textsize],text_bytes=textsize,changed_bytes=len(changes),changed_byte_min=min(changes),changed_byte_max=max(changes),all_changes_in_german_message_pointer_table=all(lo<=j<hi for j in changes),allowed_range=[lo,hi])
r=dict(before_sha256=hashlib.sha256(a).hexdigest(),after_sha256=hashlib.sha256(b).hexdigest(),segments=len(same)+len(diff),unchanged_segments=len(same),changed_segments=diff,code=details,all_actor_overlay_binaries_identical=not any(x['name'].startswith('ovl_')for x in diff),all_other_assets_identical=all(x['name']in ['makerom','dmadata','code','ger_message_data_static']for x in diff));(w/'binary-equivalence-debug.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))

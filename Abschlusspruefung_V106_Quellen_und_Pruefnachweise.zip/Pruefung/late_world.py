from pathlib import Path
import json,struct,subprocess,os
w=Path(__file__).resolve().parent;sy=json.loads((w/'all-symbols-normal.json').read_text());matrix=json.loads((w/'matrix.json').read_text());cases=[]
for scene,room,age in [(0x51,0,0),(0x52,0,1),(0x52,0,0),(0x55,0,1),(0x55,0,0),(0x55,1,0),(0x5f,0,1),(0x60,0,1),(0x60,0,0),(0x61,0,0),(0x62,0,0),(0x62,1,0),(0x5b,3,0),(0x56,0,0),(0x5a,0,0),(0x5d,0,0),(0x63,0,1),(0x63,0,0)]:
 c=next((x for x in matrix if(x['scene'],x['room'],x['age'])==(scene,room,age)),None)
 if not c:continue
 for night in [False,True]:
  d=c.copy();q=bytearray.fromhex(c['save']);struct.pack_into('>I',q,0xa4,0x1fffff);struct.pack_into('>H',q,0xf30,0x7000)
  for word,bits in [(0,0x280),(2,0x20),(3,0x80),(4,0x701)]:struct.pack_into('>H',q,0xed4+word*2,bits)
  struct.pack_into('>H',q,0xc,0xc000 if night else 0x8000);struct.pack_into('>I',q,0x10,int(night));struct.pack_into('>i',q,0x1364,0 if room==0 else 1)
  d.update(name='late-'+c['name']+('-night'if night else'-day'),save=q.hex());cases.append(d)
out=bytearray(struct.pack('>I',len(cases)))
for c in cases:out+=c['name'].encode()[:63].ljust(64,b'\0')+struct.pack('>HBBI',c['scene'],c['room'],c['age'],c['pause'])+bytes.fromhex(c['save'])
(w/'late-world.bin').write_bytes(out);(w/'late-world-first.save').write_bytes(bytes.fromhex(cases[0]['save']));(w/'late-world-cases.json').write_text(json.dumps(cases,indent=2))
with(w/'late-world.log').open('w')as f:r=subprocess.run([str(w/'matrix-recover'),str(w/'normal.z64'),'late-world-v106-direct','25000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(w/'late-world-first.save')],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null',BATCH_FILE=str(w/'late-world.bin'),MATRIX_DUMP=str(w/'late-world-crash.bin')),stdout=f,stderr=subprocess.STDOUT,timeout=1800)
print('LATE_WORLD_RESULT',r.returncode,flush=True)

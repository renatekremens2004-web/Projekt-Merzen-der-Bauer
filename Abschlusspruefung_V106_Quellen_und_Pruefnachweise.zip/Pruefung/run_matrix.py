from pathlib import Path
import json,subprocess,os,sys,concurrent.futures,time
W=Path(__file__).resolve().parent;mode=sys.argv[1]if len(sys.argv)>1 else'normal';sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/stalled-matrix.bin')
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);body=(W/'matrix_body.c').read_text()
for token,name in [('OBJECTS','gObjectTable'),('DENIED_OBJECT','gObjectBankDeniedV68'),('DENIED_OVERLAY','gActorOverlayDeniedV68'),('DENIED_INSTANCE','gActorInstanceDeniedV68'),('DENIED_LAST','gActorLastDeniedV68'),('GAMETABLE','gGameStateOverlayTable')]:body=body.replace(token,hex(sy[name]))
c=W/f'matrix-{mode}.c';c.write_text(base[:a]+body+base[b:]);exe=W/f'matrix-{mode}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
def one(k):
 log=W/f'matrix-{mode}-{k}.log'
 with log.open('w')as out:r=subprocess.run([str(exe),str(W/(mode+'.z64')),f'final-matrix-{mode}-{k}-direct','200000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(W/f'matrix-{k}-first.save')],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null',BATCH_FILE=str(W/f'matrix-{k}.bin')),stdout=out,stderr=subprocess.STDOUT,timeout=7200)
 print('MATRIX_EXIT',mode,k,r.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as p:list(p.map(one,range(2)))

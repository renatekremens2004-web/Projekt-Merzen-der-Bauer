from pathlib import Path
import subprocess, json, hashlib

W = Path(__file__).resolve().parent
O = Path('/workspace/oot-burns-pal')
R = Path('/workspace/Projekt-Merzen-der-Bauer')
header = O / 'extracted/pal-1.0/text/message_data.h'
before = header.read_bytes()
with (W / 'finish-sources.log').open('w') as log:
    subprocess.run(['python3', str(R / 'tools/build_debug_version.py'), str(O), '--restore'], check=True, stdout=log, stderr=subprocess.STDOUT)
    # Regenerate the encoded header without the broken -MF/output alias.
    cpp = subprocess.Popen(['gcc', '-E', '-P', '-xc', '-D_LANGUAGE_C', '-Iinclude', '-Iextracted/pal-1.0', 'assets/text/message_data.h'], cwd=O, stdout=subprocess.PIPE, stderr=log)
    subprocess.run(['python3', 'tools/msgenc.py', '--encoding', 'utf-8', '--charmap', 'assets/text/charmap.nes.txt', '-', '/tmp/message_data_v99.enc.nes.h'], cwd=O, stdin=cpp.stdout, stdout=log, stderr=subprocess.STDOUT, check=True)
    cpp.stdout.close()
    assert cpp.wait() == 0
    objects = ['src/code/graph.o', 'src/code/z_sram.o', 'src/overlays/gamestates/ovl_select/z_select.o', 'src/overlays/misc/ovl_kaleido_scope/z_kaleido_scope.o', 'src/overlays/misc/ovl_kaleido_scope/z_kaleido_debug.o']
    subprocess.run(['make', '-s', '-j4', 'VERSION=pal-1.0', 'COMPARE=0', 'PYTHON=/workspace/toolchain/venv/bin/python3', *['build/pal-1.0/' + p for p in objects]], cwd=O, check=True, stdout=log, stderr=subprocess.STDOUT)
assert header.read_bytes() == before
(W / 'source-restoration.json').write_text(json.dumps(dict(normal_production_sources_restored=True, dialogue_preserved=True, dialogue_sha256=hashlib.sha256(before).hexdigest()), indent=2))
print('NORMAL_SOURCES_RESTORED')

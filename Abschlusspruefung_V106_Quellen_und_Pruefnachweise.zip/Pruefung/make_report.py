from pathlib import Path
import collections, hashlib, json, re

W = Path(__file__).resolve().parent
load = lambda n: json.loads((W / n).read_text())
patch = load('patch-verification.json')
text = load('final-text-proof.json')
buffers = load('final-buffer-proof.json')
matrix = load('matrix-completed.json')
static = load('object-bank-audit.json')
lists = load('list-length-audit.json')
exports = load('export-verification.json')
assert all(c['resources_ok'] for c in matrix.values())
assert len(matrix) == 519
assert lists['checked'] == 1815 and not lists['mismatches']
assert not static['supported_overflows'] and not static['too_many_slots']
assert text['count'] == 62 and text['all_2233_wording_colors_controls_unchanged']
assert buffers['all_within_buffers']
assert exports['source_sha256'] == text['final_source_sha256']
assert (W / 'final-title-exit.txt').read_text().strip() == '0'
native_logs = {
    'Neuer Spielstand, Intro und freie Steuerung': ('newgame-normal.log', 'NATIVE_NEW_GAME_PASSED'),
    'Vollständige Credits-Kette mit Endspiel-Flags': ('credits-late-normal.log', 'FULL_CREDITS_PASSED stages=19'),
    'Titelbildschirm, Demos, Musik und Dateimenü': ('extra93/qa-normal.log', 'SINGLE_TITLE_PASSED'),
    'Kakariko-Verteidigung bis Nocturne': ('defenders-normal.log', 'NATIVE_DEFENDERS_BOTH_PARTS_PASSED'),
    'Hammer-Truhe, tatsächlicher Gegenstandserhalt': ('final-talk5-hammer.log', 'FINAL_DIALOGUE_PASSED text=38'),
    'Kokiri auf Hyrule-Feld, alle vier Textseiten': ('final-talk7-mint.log', 'FINAL_DIALOGUE_PASSED text=7238'),
    'Tauchspiel, native Auswahl und Gesprächsende': ('final-talk2-diver.log', 'FINAL_DIALOGUE_PASSED text=4053'),
    'Angelspiel, native Auswahl und Gesprächsende': ('final-dialogue-fishing.log', 'FINAL_DIALOGUE_PASSED text=407b'),
}
# The first dialogue runner's filenames have a different prefix.
if not (W / native_logs['Angelspiel, native Auswahl und Gesprächsende'][0]).exists():
    native_logs['Angelspiel, native Auswahl und Gesprächsende'] = ('final-fishing.log', 'FINAL_DIALOGUE_PASSED text=407b')
for label, (name, marker) in native_logs.items():
    assert marker in (W / name).read_text(), (label, name)
for name in ['reward-retry-results.json', 'final-water-results.json', 'handheld-retest.json', 'flare-results.json']:
    assert all(c['passed'] for c in load(name)), name
assert 'BOSS_REWARD_ROUTE_PASSED' in (W / 'dodongo-walk.log').read_text()
for mode in ['normal', 'debug']:
    eq = load('binary-equivalence' + ('-debug' if mode == 'debug' else '') + '.json')
    assert eq['all_actor_overlay_binaries_identical'] and eq['all_other_assets_identical']
    assert eq['code']['text_binary_identical'] and eq['code']['all_changes_in_german_message_pointer_table']
    assert eq['after_sha256'] == patch['builds'][mode]['rom_sha256']
counts = dict(collections.Counter(x['status'] for x in matrix.values()))
report = dict(
    release='V106', date='2026-10-27',
    conclusion='Keine bekannten Durchspiel-Blocker in den geprüften Abläufen; kein vollständiger manueller Durchlauf.',
    continuous_manual_start_to_finish_playthrough=False,
    environment=dict(emulator='Mupen64Plus / cached interpreter', native_rdram_bytes=4194304, debug_features=0),
    matrix=dict(planned_cases=521, completed_entries=519, results=counts, all_completed_resource_checks_passed=True, separately_corrected_native_entries=['18-HAKAdan_bs-0-adult -> native room 1', '23-shrine-0-child -> native spawn'], late_world_day_night_cases=36),
    static_checks=dict(scene_list_lengths=1815, mismatches=0, object_lists=610, age_evaluations=1220, supported_overflows=0, slot_overflows=0, unsupported_configurations_over_pool=2),
    dialogues=dict(changed_ids=text['changed_ids'], count=62, wording_colors_controls_unchanged=True, other_languages_unchanged=True, messages_checked=2233, max_raw_bytes=buffers['largest_raw'], max_decoded_upper_bound=buffers['largest_decoded_upper_bound'], source_sha256=text['final_source_sha256']),
    native_final_text_probes=native_logs,
    boss_reward_routes=['Deku-Baum', 'König Dodongo', 'Jabu-Jabu', 'Waldtempel', 'Feuertempel', 'Wassertempel', 'Schattentempel', 'Geistertempel'],
    boss_reward_fixtures_note='Belohnungsketten beginnen mit besiegtem Boss; das sind keine acht vollständig gespielten Bosskämpfe.',
    legacy_checks=dict(normal_tasks=26, debug_tasks=26, normal_photo_path_only_failures_corrected=3, final_outcome='passed'),
    host_damage_checks=load('damage-verification.json'),
    patches=patch,
    source_restoration=load('source-restoration.json'),
    limitations=['Kein zusammenhängender manueller Durchlauf eines neuen Spielstands bis zum Endboss.', 'Nicht jedes Gespräch, jede Nebenquest, jede Animation oder zufällige Gaster-Begegnung einzeln ausgespielt.', 'Emulatorprüfung, kein Original-N64-Hardwaretest oder Nachweis identischer Leistung auf jedem Emulator.'],
)
(W / 'Abschlusspruefung_V106.json').write_text(json.dumps(report, ensure_ascii=False, indent=2))
notes = '''V106 – Abschlussprüfung der modifizierten Ocarina-of-Time-Version
Stand: 27. Oktober 2026

Ergebnis und Grenzen
-------------------
In den geprüften Abläufen sind keine bekannten Durchspiel-Blocker übrig geblieben. Die früher auffälligen Inventar-/Boden-/Ladeprobleme wurden in gezielten Wiederholungstests nicht erneut ausgelöst. Das ist eine umfangreiche automatisierte Emulatorprüfung mit gezielt vorbereiteten Spielständen, KEIN lückenloser manueller Durchlauf eines neuen Spielstands bis zum Endboss. Deshalb ist es keine Garantie für sämtliche möglichen Spielzustände.

Für den geplanten normalen Spieldurchlauf: den Normal-Patch benutzen. Normal und DEBUG sind jeweils vollständige kumulative BPS-Patches auf eine saubere Ocarina-of-Time-PAL-1.0-ROM, nicht auf eine bereits gepatchte ROM. Beim Wechsel auf V106 das Spiel neu starten; keine alten Emulator-Savestates laden. Ein regulärer neuer Spielstand ist der passende Ausgangspunkt für den geplanten Durchlauf.

Was V106 ändert
---------------
Nur die Seitenaufteilung von 62 deutschen Text-IDs wurde verbessert. Keine Wörter, Sätze, Pointen oder Gegenstands-/Questlogik geändert. Zeichenfarben, Fortsetzungen, Auswahltexte und relevante Ablaufsteuerung sind erhalten. Vergleich sämtlicher 2.233 deutschen Texte und aller übrigen Sprachfassungen bestanden. Lange Sätze bekommen bei Bedarf eine eigene Seite; absichtliche Pausen bleiben bestehen. Das ist keine automatische Neuformatierung jedes Textes.

Alle kompilierten deutschen Meldungen passen in die nativen Textpuffer. Größter geprüfter Rohtext: 1.180 Bytes; konservative größte dekodierte Seite: 155 Zeichen, bei Puffergrenzen von 1.280 beziehungsweise 200. Der zentrale Dialoghelfer erzeugt denselben Stand erneut, ohne Änderungen. Die vollständige TXT-Liste enthält 2.015 Text-IDs auf 3.688 Seiten, ohne 218 Maskenreaktions-IDs; normale Maskenquest-Gespräche bleiben enthalten.

Gebiete, Räume und Speicher
-------------------------
Mupen64Plus mit 4 MiB RDRAM, also ohne Expansion Pak. 521 geplante Raum-/Alterskonstellationen: 519 abgeschlossene Matrixeinträge plus zwei separat korrigierte Prüfungen mit dem tatsächlichen Spieleingang. Von den 519 Einträgen:
  418: Inventar geöffnet und geschlossen, Kollision vorher/nachher verglichen.
   46: Laden geprüft; Menü wegen laufendem Spielzustand nicht verfügbar.
   25: Nur Laden geprüft, überwiegend Bossbereiche.
    4: Automatischer Szenenübergang.
   26: Angeforderte Testkonstellation wurde vom Spiel auf einen anderen Raum/Altersaufbau umgeleitet. Diese zählen nicht als bestandener Test genau des angeforderten Raumes.
Alle 519 abgeschlossenen Ressourcenprüfungen bestanden. Zusätzlich 36 Endspiel-Konstellationen bei Tag/Nacht für wichtige Außenbereiche und Figuren. Wario und Mystery Machine in Kinder-Kakariko bei Tag und Nacht geladen; der neue Kokiri auf Hyrule-Feld nach dem Waldtempel geladen und ansprechbar.

Geprüft wurden Objektbankgrenzen und 19 Objektplätze, abgewiesene Actor-/Objekt-Allokationen, Grafikbefehls-/Matrixpuffer und bei Menürückkehr der unveränderte statische Kollisionsinhalt. Statische Prüfung von 1.815 Szenenlisten: keine falsche Listengröße. 610 Objektlisten in beiden Altersvarianten geprüft: kein Überlauf einer unterstützten Konstellation und keine Liste über 19 Plätzen. Zwei theoretische Überschreitungen betreffen ausdrücklich unbenutzte Alterskombinationen, nicht den normalen Spielweg.

Gezielte spielbare Prüfungen
---------------------------
Normal und DEBUG: 26 Wiederholungsgruppen mit Inventar/Equippen, Bodenhalt und Raumwechseln in Dodongos Höhle, Brunnen und Steppe; außerdem Feuertempel-, Schattentempel-, Vogel-, Habeck- und Goronen-Abläufe. Drei ursprüngliche Normal-Testfehler waren falsche Screenshot-Dateipfade; die entsprechenden Game-Boy-Tests wurden erneut erfolgreich ausgeführt.

Dodongos Höhle: Statuen/blauer Schalter, Gitter und echter Übergang zum Echsenraum; Pieps/Käfig als Kind und Altersausschluss als Erwachsener; Pieps bei König Dodongo. Brunnen: wiederholte Raumwechsel und Silberrubin-Sammelmechanik mit Öffnen des Gitters trotz entfernter ReDeads. Game Boy Color und Advance über echte Tunnelübergänge, beim Advance vor und nach dem Waldtempel. Feuertempel: entfernte Felsen/Raubschleime, Bodenplatten-Raumabschluss und Türen; beide Flammenderwisch-Räume mit beginnender Kampfanimation und Inventarrückkehr; Hammer-Truhe einschließlich tatsächlichem Hammer-Erhalt. Schattentempel: entfernte automatische Hinweise, Wahrheitstatue und verbliebene Hindernisse; Bongo-Bongo/Pieps-Eingriff mit nativer Todes-/Belohnungsfortsetzung.

Alle acht Hauptboss-Belohnungsketten: vom besiegten Boss durch Portal, Stein/Amulett- und Weisen-Sequenz bis zurück zur frei steuerbaren Spielwelt. Diese Teststände starten mit bereits besiegtem Boss; sie ersetzen keine acht komplett gespielten Kämpfe. Die neue dreiseitige Wasser-Sheik-Fortsetzung wurde zusätzlich im endgültigen Build geprüft.

Neuer Spielstand: tatsächlich neu angelegte SRAM-Datei, Namen eingegeben, normales Intro bis Navi und freie Kinder-Link-Steuerung samt Inventar; drei Herzen und keine Debug-Ausrüstung. Habeck: Nein-/Ja-Zweige, drei Geschenke, Rückkehr zur Zitadelle. Kakariko-Dämon: beide Szenenteile, drei Soldaten, 23 Schüsse (9/8/6), passende drei Sounds, kein Spielerschaden, Ende mit Nocturne und Entfernung der Szenen-Soldaten. Finale: Einsturz, Musik-/Triangle-Guy-Übergänge, Ansprache und anschließende Ganon-Verwandlung. Komplette Credits-Kette mit 19 Szenenübergängen und Endspiel-Questflags bis zum Kinder-Schlosshof.

Titelbildschirm: Einblendung, vier Zyklen, die drei Attract-Demos, Musikfortschritt/Loop und Start ins orange Dateimenü. Beschleunigung mit Eisenstiefeln, Unterwasserschwert, beschleunigtes Kisten-/Blockschieben geprüft. Schadensschutz zusätzlich mit 6.912 Fällen am tatsächlich verwendeten C-Code geprüft; dies ist ein Host-Test, keine Serie von ROM-Kämpfen. Licht-/Wallace-/Wassergewand halbieren, Schattengewand viertelt.

Zusätzliche finale Textproben: Hammer-Fund, Kokiri auf der Steppe, Tauchspiel und Angelspiel bis Auswahl/Gesprächsende; Wasser-Sheik bis Rückkehr zur Spielwelt. Nicht jeder NPC-Dialog und nicht jede Nebenquest wurde einzeln ausgespielt. Die Raum-/Objektprüfung belegt Ressourcenverträglichkeit, nicht jede Animation oder jede zufällige Gaster-Begegnung.

Einordnung auffälliger Testversuche
---------------------------------
Ungültig hergeleitete Einstiegspunkte in Bongo Bongos Arena und vor der Zitadelle führten in frühen Testläufen zu einem Absturz/Voidausgang. Wiederholung mit nativem Eingang bestand; dafür wurde kein Spielcode geändert. Weitere falsche Bodenhöhen, Raum-Clear-Bits, die falsche Seite einer Truhe, ein entfernter Kokiri-Teleport und ein zu früher Start-Knopfdruck im Titeltest wurden als Testaufbau korrigiert. Der erste lange Titeltest überschritt unter paralleler Emulatorlast sein Zeitlimit; der endgültige Test bestand. Diese frühen Versuche werden nicht als erfolgreiche Spieletests mitgezählt.

Build-Nachweis
--------------
Die breite Raum- und Gameplay-Prüfung lief zunächst auf dem ersten V106-Build. Danach kamen weitere reine Seitenkorrekturen hinzu. Binärer Vergleich BEIDER finalen Builds: sämtliche Actor-Overlays, Modelle, Szenen, Audio und ausführbarer Hauptcode sind gegenüber dem jeweils geprüften ersten Build bytegleich. Änderungen liegen nur in deutscher Textbank, deren Zeigertabelle, ROM-DMA-Adressen und Header-Prüfsumme. Die abschließenden Textproben sowie die Flammenderwisch-Prüfungen liefen auf dem finalen Normal-Build. Die Quellen wurden zum Schluss auf Normal zurückgestellt.

Beide BPS mit Flips erzeugt, mit RomPatcher.js unabhängig auf die saubere PAL-1.0-Basis angewendet und bytegenau mit dem jeweiligen Build verglichen. ROM-Prüfsummen und 64-MiB-Größe stimmen. Dieser Download enthält Patches und Dokumentation, keine ROMs oder Spielstände.

Nicht abgedeckt
--------------
Kein zusammenhängender manueller neuer Durchlauf bis zum Abspann; nicht sämtliche Kombinationen aus Reihenfolge, Nebenquests, Speichern/Laden und zufälligen Ereignissen; kein Original-N64-Hardwaretest. Im geprüften Umfang ist kein offener Produktionsfehler bekannt. Eine uneingeschränkte Zusage „jeder mögliche Ablauf funktioniert“ wäre durch diese Tests nicht belegt.
'''
notes += '\nSHA-256\n-------\nSaubere PAL-1.0-Basis: ' + patch['base_sha256'] + '\n'
for mode, p in patch['builds'].items():
    notes += mode + ' ROM: ' + p['rom_sha256'] + '\n' + p['filename'] + ': ' + p['patch_sha256'] + '\n'
(W / 'Abschlusspruefung_V106.txt').write_text(notes)
print('FINAL_REPORT_READY', counts)

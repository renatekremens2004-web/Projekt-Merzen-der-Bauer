from pathlib import Path
import json, re, struct, subprocess, os, concurrent.futures

W = Path(__file__).resolve().parent
sy = json.loads((W / 'all-symbols-normal.json').read_text())
base = (W / 'final-talk7-mint.c').read_text()
a = base.index('static void capture_render(void){}')
b = base.index('static void setting(', a)
body = r'''
static void capture_render(void){}
static unsigned first=0,changed=0,paused=0;
static void onframe(unsigned f){
 baseframe(f);if(f==340){play=0;player=0;}if(f<380)return;findplay();if(!play||!player)return;
 unsigned boss=actor(0x99),p=DebugMemRead16(play+0x10934),v=0;
 if(boss){unsigned af=r32(boss+0x180);if(!first)first=af;if(af!=first)changed=1;}
 if(p==6)paused=1;
 if((f>=700&&f<702)||(f>=820&&f<822))v=0x10;
 if(buttons)buttons(v);
 if(f==650||f==1000)bank();
 if(f%200==0)printf("FLARE f=%u boss=%x action=%x changed=%u pause=%u xyz=%.1f,%.1f,%.1f\n",f,boss,boss?r32(boss+0x180):0,changed,p,rf(player+0x24),rf(player+0x28),rf(player+0x2c));
 if(f==1050){need(boss&&r32(boss+0x134),"Flare Dancer starts and remains visible");need(changed,"native combat action advances");need(paused&&!p,"inventory closes during combat");need(rf(player+0x28)>rf(player+0x80)-20,"player remains on room floor after inventory");bank();puts("NATIVE_FLARE_START_AND_PAUSE_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
}
'''
matrix = json.loads((W / 'matrix.json').read_text())
results = []
def one(room, xyz):
    d = next(c for c in matrix if (c['scene'], c['room'], c['age']) == (4, room, 0))
    q = bytearray.fromhex(d['save'])
    struct.pack_into('>i', q, 0x1364, 1)
    struct.pack_into('>fffhHhB', q, 0x1368, *xyz, -32768, 0xdff, d['entrance'], room)
    struct.pack_into('>I', q, 0xd4 + 4 * 0x1c + 8, 0)
    struct.pack_into('>H', q, 0x70, (struct.unpack_from('>H', q, 0x70)[0] & 0xfff) | 0x1000)
    c = W / f'flare-{room}.c'
    c.write_text(base[:a] + body.replace('YFLOOR', str(xyz[1])) + base[b:])
    exe = W / f'flare-{room}'
    subprocess.run(['gcc', '-O2', '-I/workspace/toolchain/root/usr/include/mupen64plus', str(c), '-o', str(exe), '-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu', '-l:libmupen64plus.so.2', '-ldl', '-lm'], check=True)
    save = W / f'flare-{room}.save'
    save.write_bytes(q)
    log = W / f'flare-{room}.log'
    with log.open('w') as out:
        r = subprocess.run([str(exe), str(W / 'normal.z64'), f'flare-{room}-v106-direct', '1200', '4', hex(sy['gSaveContext']), hex(sy['gActorOverlayTable']), str(save)], env=dict(os.environ, DISPLAY=':99', CREDITS_AUDIO_PATH='/dev/null'), stdout=out, stderr=subprocess.STDOUT, timeout=300)
    ok = r.returncode == 0 and 'NATIVE_FLARE_START_AND_PAUSE_PASSED' in log.read_text()
    results.append(dict(room=room, passed=ok, log=log.name))
    print('FLARE_RESULT', room, ok, flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    list(pool.map(lambda pair: one(*pair), [(3, (-361, 80, -1080)), (24, (-2928, 2920, 359))]))
(W / 'flare-results.json').write_text(json.dumps(results, indent=2))
assert all(x['passed'] for x in results)

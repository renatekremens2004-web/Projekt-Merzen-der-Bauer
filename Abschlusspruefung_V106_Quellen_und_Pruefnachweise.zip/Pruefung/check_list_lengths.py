from pathlib import Path
import re,json
w=Path(__file__).resolve().parent;e=Path('/workspace/oot-burns-pal/extracted/pal-1.0/assets/scenes');defs={};checked=[];bad=[]
for p in e.rglob('*.h'):
 for name,num in re.findall(r'#define\s+LENGTH_(\w+)\s+(\d+)',p.read_text()):defs[name]=int(num)
for p in e.rglob('*.inc.c'):
 if not any(p.name.endswith(x)for x in ['ActorEntryList.inc.c','ObjectList.inc.c','PlayerEntryList.inc.c','TransitionActorEntryList.inc.c','RoomList.inc.c']):continue
 name=p.name.removesuffix('.inc.c')
 if name not in defs:continue
 text=re.sub(r'/\*.*?\*/|//[^\n]*','',p.read_text(),flags=re.S)
 if name.endswith('ObjectList')or name.endswith('RoomList'):
  actual=len(re.findall(r'\bOBJECT_\w+\b',text))if name.endswith('ObjectList')else text.count('ROM_FILE(')
  if name.endswith('RoomList')and actual==0:actual=text.count('{')
 else:
  actual=0;depth=0
  for ch in text:
   if ch=='{':
    if depth==0:actual+=1
    depth+=1
   if ch=='}':depth-=1
 row=dict(file=str(p.relative_to(e)),declared=defs[name],actual=actual);checked.append(row)
 if defs[name]!=actual:bad.append(row)
(w/'list-length-audit.json').write_text(json.dumps(dict(checked=len(checked),mismatches=bad,lists=checked),indent=2));print('Scene list lengths:',len(checked),'checked;',len(bad),'mismatches')
for x in bad[:25]:print(x)

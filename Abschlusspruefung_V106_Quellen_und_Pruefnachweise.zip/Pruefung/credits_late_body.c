static void capture_render(void){}
static unsigned prevscene=999,prevlayer=999,stages=0,finalstart=0,stageshot=0;
static void onframe(unsigned f){
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;unsigned scene=DebugMemRead16(play+0xa4),layer=r32(savebase+0x1360),cs=DebugMemRead16(play+0x1d74);
 if(scene!=prevscene||layer!=prevlayer){printf("CREDITS_STAGE f=%u scene=%x layer=%u cs=%u mode=%u\n",f,scene,layer,cs,r32(savebase+0x135c));bank();stages++;stageshot=0;prevscene=scene;prevlayer=layer;}
 if(!stageshot&&cs>=40){stageshot=1;CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);for(int c=0;c<12;c++)for(unsigned a=r32(play+0x1c34+c*8),n=0;a>=0x80000000&&a<0x80400000&&n<200;a=r32(a+0x124),n++)if(r32(a+0x130))printf("CREDITS_ACTOR scene=%x layer=%u id=%x params=%x draw=%x\n",scene,layer,DebugMemRead16(a),DebugMemRead16(a+0x1c),r32(a+0x134));}
 if(f%200==0){printf("CREDITS_PROGRESS f=%u scene=%x layer=%u cs=%u\n",f,scene,layer,cs);bank();}
 if(scene==FINALSCENE){if(!finalstart){finalstart=f;for(int c=0;c<12;c++)for(unsigned a=r32(play+0x1c34+c*8),n=0;a>=0x80000000&&a<0x80400000&&n<200;a=r32(a+0x124),n++)if(r32(a+0x130))printf("FINAL_CREDIT_ACTOR id=%x params=%x draw=%x\n",DebugMemRead16(a),DebugMemRead16(a+0x1c),r32(a+0x134));}
 if(f>finalstart+400){need(stages>=19,"native credits chain reaches final courtyard through all stages");bank();printf("FULL_CREDITS_PASSED stages=%u frame=%u\n",stages,f);CoreDoCommand(M64CMD_STOP,0,NULL);}}
 need(f<23000,"full credits eventually reach courtyard");
}

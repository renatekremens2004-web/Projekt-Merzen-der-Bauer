from pathlib import Path
import json,os,subprocess
w=Path(__file__).resolve().parent;s=json.loads((w/'all-symbols-normal.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(s[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/newgame-stall.bin').replace('obj<=0x1af','obj<=0x1b0')
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);body=(w/'newgame_body.c').read_text().replace('GAMETABLE',hex(s['gGameStateOverlayTable']));(w/'newgame.c').write_text(base[:a]+body+base[b:]);exe=w/'newgame'
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(w/'newgame.c'),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
with(w/'newgame-normal.log').open('w')as f:r=subprocess.run([str(exe),str(w/'normal.z64'),'fresh-native-file-v106-c','13000','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable'])],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=1500)
print('NEWGAME_RESULT',r.returncode,flush=True)

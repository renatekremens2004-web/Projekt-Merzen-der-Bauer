from pathlib import Path
import json,struct,re,subprocess,os,concurrent.futures,time,signal
import psutil
w=Path(__file__).resolve().parent;sy=json.loads((w/'all-symbols-normal.json').read_text())
for p in psutil.process_iter(['pid','cmdline']):
 a=p.info['cmdline']or[]
 if len(a)>1 and a[1]==str(w/'resume_matrix.py'):
  for c in p.children(recursive=True):c.terminate()
  p.terminate()
time.sleep(1)
done=set()
for p in list(w.glob('matrix-normal-[01].log'))+list(w.glob('resume-*.log')):done.update(re.findall(r'CASE_DONE (\S+)',p.read_text()))
done.update(['18-HAKAdan_bs-0-adult','23-shrine-0-child']);cases=[c for c in json.loads((w/'matrix.json').read_text())if c['name']not in done]
for c in cases:
 q=bytearray.fromhex(c['save'])
 if c['room']==0:struct.pack_into('>i',q,0x1364,0)
 c['save']=q.hex()
 # Native entrance resolution maps the temple exterior to its adult ruins.
 if c['scene']in [0x23,0x24]and c['age']==0:c['scene']=0x25
 if c['scene']==0x25 and c['age']==1:c['scene']=0x23
(w/'remaining-batch-cases.json').write_text(json.dumps(cases,indent=2))
s=(w/'matrix-normal.c').read_text().replace('0x8000633c',hex(sy['__osActiveQueue'])).replace('fopen("/tmp/stalled-matrix.bin","wb")','fopen(getenv("MATRIX_DUMP"),"wb")').replace('fclose(d);alarm(15);','fclose(d);_exit(97);');(w/'matrix-recover.c').write_text(s);exe=w/'matrix-recover';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(w/'matrix-recover.c'),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
def one(k):
 cs=cases[k::2];attempt=0
 while cs:
  attempt+=1;out=bytearray(struct.pack('>I',len(cs)))
  for c in cs:out+=c['name'].encode()[:63].ljust(64,b'\0')+struct.pack('>HBBI',c['scene'],c['room'],c['age'],c['pause'])+bytes.fromhex(c['save'])
  dat=w/f'remaining-batch-{k}-{attempt}.bin';dat.write_bytes(out);fixture=w/f'remaining-batch-{k}-{attempt}.save';fixture.write_bytes(bytes.fromhex(cs[0]['save']));log=w/f'remaining-batch-{k}-{attempt}.log';t=time.monotonic()
  with log.open('w')as f:r=subprocess.run([str(exe),str(w/'normal.z64'),f'remaining-batch-{k}-{attempt}-v106-direct','100000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(fixture)],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null',BATCH_FILE=str(dat),MATRIX_DUMP=str(w/f'remaining-batch-{k}-{attempt}-crash.bin')),stdout=f,stderr=subprocess.STDOUT,timeout=3600)
  text=log.read_text();finished=set(re.findall(r'CASE_DONE (\S+)',text));print('BATCH_REMAINING',k,attempt,'exit',r.returncode,'done',len(finished),'elapsed',round(time.monotonic()-t,1),flush=True)
  cs=[c for c in cs if c['name']not in finished]
  if cs and r.returncode:
   starts=re.findall(r'CASE_BEGIN \d+ (\S+)',text);bad=starts[-1]if starts else cs[0]['name'];(w/f'remaining-batch-{k}-{attempt}-needs-triage.txt').write_text(bad);print('NEEDS_TRIAGE',bad,flush=True);cs=[c for c in cs if c['name']!=bad]
  elif cs:raise RuntimeError('Batch stopped without error or completion')
 print('REMAINING_GROUP_DONE',k,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as p:list(p.map(one,range(2)))

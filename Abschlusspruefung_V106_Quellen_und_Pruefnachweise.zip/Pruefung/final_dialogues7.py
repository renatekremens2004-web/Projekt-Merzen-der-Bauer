from pathlib import Path
import json,os,re,struct,subprocess,concurrent.futures,time
w=Path(__file__).resolve().parent;sy=json.loads((w/'all-symbols-normal.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/final-talk7-stall.bin').replace('obj<=0x1af','obj<=0x1b0');base=base.replace('static void onframe(unsigned f){', 'static void onframe(unsigned f){')
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned seen=0,closed=0,choiced=0,lastid=0,inventory=0;
static void onframe(unsigned f){
 baseframe(f);if(f==340){play=0;player=0;}if(f<370)return;findplay();if(!play||!player)return;
 unsigned npc=target(NPC,PARAM),m=play+0x20d8,id=DebugMemRead16(m+0xe2f8),mm=DebugMemRead8(m+0xe304),v=0;
 if(npc&&!seen&&f>=400){int yaw=(int16_t)DebugMemRead16(npc+0xb6);float ang=yaw*3.14159265f/32768.0f;photo(rf(npc+0x24)+150,rf(npc+0x28)+130,rf(npc+0x2c)+230,rf(npc+0x24),rf(npc+0x28)+35,rf(npc+0x2c));position(player,rf(npc+0x24)+sinf(ang)*(HAMMER?-DIST:DIST),rf(npc+0x28)+1,rf(npc+0x2c)+cosf(ang)*(HAMMER?-DIST:DIST),yaw+(HAMMER?0:32768));DebugMemWrite16(player+0x82c,yaw+(HAMMER?0:32768));wf(player+0x68,0);}
 if(id==TEXT&&mm)seen=1;
 if(mm&&id!=lastid){printf("FINAL_TEXT f=%u id=%x bytes=%u\n",f,id,r32(m+0xe300));lastid=id;}
 if(seen&&mm==0x35&&DebugMemRead8(m+0xe3e6)==2){DebugMemWrite8(m+0xe3e5,1);choiced=1;}
 need(r32(m+0xe300)<1280,"whole text stays within native buffer");need(DebugMemRead16(m+0xe3d4)<=200,"native decoded page fits");
 if(f>440&&f%12<2&&(mm==0||mm==6||mm==7||mm==0x34||mm==0x35))v=0x80;
 if(seen&&!mm){if(!closed)closed=f;if(f>closed+45){bank();if(CHOICE)need(choiced,"native choice reached and declined");if(HAMMER)need(DebugMemRead8(savebase+0x74+15)==0x11,"hammer actually acquired by native chest");printf("FINAL_DIALOGUE_PASSED text=%x choice=%u hammer=%u\n",TEXT,choiced,HAMMER);CoreDoCommand(M64CMD_STOP,0,NULL);}}
 if(f%300==0){printf("FINAL_PROGRESS f=%u npc=%x msg=%x mode=%u seen=%u choice=%u xyz=%.1f,%.1f,%.1f\n",f,npc,id,mm,seen,choiced,rf(player+0x24),rf(player+0x28),rf(player+0x2c));bank();}
 if(npc&&f%300==0)printf("INTERACT actorFlags=%x playerFlags=%x talk=%x dist=%.1f yaw=%d shape=%d cs=%u\n",r32(npc+4),r32(player+0x66c),r32(player+0x684),rf(player+0x688),(int16_t)DebugMemRead16(player+0x82c),(int16_t)DebugMemRead16(player+0xb6),DebugMemRead8(player+0x434));if(npc&&f%300==0)printf("DETAIL unk210=%u talkstate=%u text=%x dy=%.1f xz=%.1f pflags=%x npcUpdate=%x action=%x chestAction=%x getitem=%d intactor=%x\n",DebugMemRead8(npc+0x200),DebugMemRead16(npc+0x1d8),DebugMemRead16(npc+0x10e),rf(npc+0x94),rf(npc+0x90),r32(player+4),r32(npc+0x130),r32(player+0x664),r32(npc+0x1e8),(int16_t)DebugMemRead16(player+0x414),r32(player+0x67c));if(f==800)CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);if(buttons)buttons(v);need(f<4500,"native dialogue completes");
}
'''
matrix=json.loads((w/'matrix.json').read_text());results=[]
def one(spec):
 name,scene,room,age,npc,param,text,choice,dist=spec;data=next(c for c in matrix if(c['scene'],c['room'],c['age'])==(scene,room,age));q=bytearray.fromhex(data['save']);struct.pack_into('>i',q,0x1364,0 if room==0 else 1);struct.pack_into('>H',q,0x34,99)
 if name=='mint':
  struct.pack_into('>I',q,0xa4,1);struct.pack_into('>H',q,0xedc,0x100);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,4685,-159,8420,16384,0xdff,data['entrance'],0)
 if name=='hammer':
  q[0x74+15]=255;struct.pack_into('>fffhHhB',q,0x1368,-2220,4680,420,24576,0xdff,data['entrance'],13)
 src=body
 for k,v in [('NPC',npc),('PARAM',param),('TEXT',text),('CHOICE',choice),('DIST',dist),('HAMMER',int(name=='hammer'))]:src=src.replace(k,str(v))
 c=w/f'final-talk7-{name}.c';c.write_text(base[:a]+src+base[b:]);exe=w/f'final-talk7-{name}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True);save=w/f'final-talk7-{name}.save';save.write_bytes(q);log=w/f'final-talk7-{name}.log';t=time.monotonic()
 with log.open('w')as out:
  try:r=subprocess.run([str(exe),str(w/'normal.z64'),f'final-talk7-{name}-v106-direct','7000','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=out,stderr=subprocess.STDOUT,timeout=650);passed=r.returncode==0 and 'FINAL_DIALOGUE_PASSED' in log.read_text();error=None if passed else log.read_text()[-2200:]
  except Exception as e:passed=False;error=repr(e)
 results.append(dict(case=name,passed=passed,error=error,elapsed=round(time.monotonic()-t,1)));(w/'final-talk7-results.json').write_text(json.dumps(results,indent=2));print('FINAL_DIALOGUE',name,passed,error or'',flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as p:list(p.map(one,[('mint',0x51,0,0,0x161,0x7e00,0x7238,0,65)]))

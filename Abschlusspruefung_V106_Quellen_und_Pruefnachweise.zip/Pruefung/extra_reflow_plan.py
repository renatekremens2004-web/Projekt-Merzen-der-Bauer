from pathlib import Path
import json,re,sys
w=Path(__file__).resolve().parent;sys.path.insert(0,'/workspace/Projekt-Merzen-der-Bauer/tools');from build_story import *
src=Path('/workspace/oot-burns-pal/extracted/pal-1.0/text/message_data.h').read_text();m=messages(src);layout=Layout(Path('/workspace/oot-burns-pal'))
def wrap(t,width=210):
 out=[];line=''
 for word in t.split():
  c=(line+' '+word).strip()
  if line and layout.width(c)>width:out.append(line);line=word
  else:line=c
 if line:out.append(line)
 return out
layout.wrap=wrap
helper=Path('/tmp/navi-dialogue-next/apply.py').read_text();exec(helper[helper.index('def pack(t):'):helper.index('\ntexts={')])
plan={}
for i in ['0156','022B','0629','4043','404E','4053','406E','407B','600C','6064','7207','720D','7238','723B']:
 b=m[i]['parts'][2][2];ps,ss=split_pages(b);choice=any('CHOICE'in p for p in ps);prose=ps[:-1]if choice else ps;t=' '.join(' '.join(plain(p).split())for p in prose);new=pack(t)
 plan[i]=dict(before=[' '.join(plain(p).split())for p in ps],after=new+([' '.join(plain(ps[-1]).split())]if choice else[]),choice=choice)
 print(i,len(ps),'->',len(plan[i]['after']))
 for k,p in enumerate(new):print(k+1,p)
(w/'extra-reflow-plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2))

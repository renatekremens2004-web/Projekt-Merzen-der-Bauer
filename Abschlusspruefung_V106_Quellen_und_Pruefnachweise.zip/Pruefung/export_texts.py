from pathlib import Path
import sys,re,json,hashlib
O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer');W=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tools'))
from build_story import messages,split_pages,LEX,controls
source=O/'extracted/pal-1.0/text/message_data.h';raw=source.read_bytes();m=messages(raw.decode());face=(O/'src/code/z_face_reaction.c').read_text();mask=set()
for name in ['sMaskReactionSetTextIds','gGermanMaskReactionTextIds']:
 body=face.split(name+'[',1)[1].split('= {',1)[1].split('\n};',1)[0]
 for row in re.findall(r'\{([^{}]*)\}',body):mask|={f'{int(x,16):04X}'for x in re.findall(r'0x[\da-fA-F]+',row)[1:]if int(x,16)}
mask.add('7161');assert mask<=set(m)
def readable(body):
 out=''
 for t in LEX.findall(body):
  if t.startswith('"'):out+=json.loads(t)
  elif t=='NAME':out+='[Spielername]'
  elif t=='TIME':out+='[Uhrzeit]'
  elif t=='RACE_TIME':out+='[Rennzeit]'
  elif t=='POINTS':out+='[Punkte]'
  elif t=='TOKENS':out+='[Skulltula-Symbole]'
  elif t=='FISH_INFO':out+='[Fischgröße]'
  elif t=='MARATHON_TIME':out+='[Marathonzeit]'
  elif t.startswith('HIGHSCORE('):out+='[Bestwert: '+t[10:-1]+']'
  elif t in ['TWO_CHOICE','THREE_CHOICE']:out+='\n'
 return out

def emit(i,lines,records,context=None):
 body=m[i]['parts'][2][2];ps,_=split_pages(body);lines+=['### '+i,'']
 if context:lines+=[context,'']
 for n,page in enumerate(ps,1):
  lines+=['**Seite '+str(n)+'**',''];text=readable(page)
  if 'CHOICE'in page:lines+=['> '+' '.join(x.split())for x in text.splitlines()if x.strip()]+['']
  else:lines+=['> '+' '.join(text.split()),'']
 follow=[f'{int(x,16):04X}'for x in re.findall(r'TEXTID\(0x([\da-fA-F]+)\)',body)]
 if follow:lines+=['Fortsetzung: '+', '.join('**'+x+'**'+(' (Maskenreaktion ausgelassen)'if x in mask else'')for x in follow)+'.','']
 records.append(dict(id=i,pages=[readable(p)for p in ps],controls=controls(body),context=context))

# Complete stored German message bank, not a hand-picked list of NPCs.
included=set(m)-mask;all_lines=['# Gesamter deutscher Spieltext – V106, ohne Maskenreaktionen','',
'Vollständiger Export der aktuellen deutschen Spiel-Textbank nach Text-IDs. Enthält alle gespeicherten Dialoge, Zwischensequenzen, Auswahlzweige, Gegenstands-, Laden-, Hinweis- und Systemtexte; auch seltene oder derzeit nicht erreichbare Text-IDs. Das ist ein Bestand der Textbank, keine Behauptung, daß jeder Eintrag im normalen Spiel ausgelöst wird.','',
'Ausgenommen sind die Maskenreaktionen aus der ursprünglichen und der deutschen Reaktionstabelle sowie der deutsche Sonderfall 7161. Normale Maskenhändler-, Kauf-, Rückgabe- und Maskenquest-Gespräche bleiben enthalten. Die vollständige Ausschlußliste steht in der Begleitdatei.','',
'Jede Seite entspricht einer Textbox-Seite. Bildschirmzeilen sind verbunden. Variablen wie Name, Uhrzeit oder Bestwerte sind als Platzhalter bezeichnet. Steuerzeichen und Farben werden nicht als gesprochener Text dargestellt. Die technische JSON-Fassung erhält zusätzlich die Ablaufsteuerung.',''];all_records=[];lastgroup=None
for i in sorted(included,key=lambda x:int(x,16)):
 group=i[0]
 if group!=lastgroup:all_lines+=['## Textbereich '+group+'000–'+group+'FFF',''];lastgroup=group
 emit(i,all_lines,all_records)
assert {r['id']for r in all_records}==included
stem='Gesamter_Spieldialog_DE_V106_ohne_Maskenreaktionen';full='\n'.join(all_lines)
for ext in ['md','txt']:(W/(stem+'.'+ext)).write_text(full)
(W/(stem+'.json')).write_text(json.dumps(all_records,ensure_ascii=False,indent=2))
(W/'Ausgelassene_Maskenreaktionen_V106.txt').write_text('Ausgelassene Maskenreaktions-IDs (aus nativer und deutscher Reaktionstabelle; kein Filter nach Wörtern):\n\n'+'\n'.join(sorted(mask))+'\n')

# Goron dialogue: explicit speaker/role grouping plus the stored rare alternatives.
sections=[]
def add(title,ids):sections.append((title,ids.split()))
add('Kind – Darunia, Auftrag und Nachspiel','301A 301B 3020 301C 301F 301D 301E 3023 3048 3004 3000 3001 3068 3005 3006 3029')
add('Kind – Gorone vor Dodongos Höhle','3008 302A 3021 3027')
add('Kind – Donnerblumen-Gorone am Todesberg','300A 300B 300C 300D 302B 3027')
add('Kind – kleiner rollender Gorone','3009 3026 3027')
add('Kind – großer rollender Gorone und Bombentasche','3011 3012 3013')
add('Kind – Eingang von Goronia','3014 3015 3027')
add('Kind – Gorone auf der Plattform','3016 3017 3067')
add('Kind – unterste Ebene von Goronia','3017 3018 3019 302C 3027')
add('Kind – Treppenhaus','300E 3022')
add('Kind – Verbindung zu den Verlorenen Wäldern','3024 3025 302F')
add('Kind – Gorone beim Weg zum Gipfel','3064 3065')
add('Kind – Gorone im Basar','7122')
add('Kind – früher Gorone / Beta-Gorone','7230')
add('Erwachsen – Darunias Sohn vor und nach dem Feuertempel','3030 3031 3032 3033 3034 3035 3036 3037 3038 3041 3042')
add('Erwachsen – Darunia im Feuertempel','3039')
add('Erwachsen – gefangene Goronen im Feuertempel','3051 3071 3052 3069 306A 306B 306C 306D 306E 306F 3070 303A')
add('Erwachsen – Goronen nach der Befreiung / zusätzliche Zustände','3043 3044 3057 305B')
add('Goronen-Laden – Begrüßung, Gespräche und Kaufablauf','7241 0083 300F 302D 3028 3047 3057 305B 3010 302E 0084 0085 0086 0096')
add('Goronen-Laden – Warenbeschreibungen und Kaufangebote','00A3 008B 00B1 007C 001C 0006 001D 001E 00AA 0093 00AC 0095 00A5 008E')
add('Medigoron – Schmiede und Verkauf','3049 304A 304B 304C 304D 304E 304F 3050')
add('Biggoron – Tauschgeschäft und Schwert','3053 3054 3055 3056 3058 3059 305A 305C 305D 305E 3002 3003')
add('Erwachsen – Soldaten am Todesberg, in Goronia und Kakariko','7200 7201 7202 7203 7205')
add('Erwachsen – verirrter Soldat im Wald','7204')
add('Erwachsen – Soldaten an der Gerudo-Grenze und auf der Steppe','7206 7207 7208 7209 720A 720B')
add('Erwachsen – Soldat bei Wawario in der Zelle','720C')
add('Erwachsen – Schrotflinten-Soldaten im Todeskrater','7224 7225 7226')
add('Erwachsen – Hunting-Rifle-Soldat in Darunias Raum','7228')
add('Erwachsen – Flammenwerfer-Soldat','7229')
add('Erwachsen – Beta-Soldat mit Pistole','7234')
add('Kontext – Wallace als ersetzte Goronen-Rolle und Feuerweiser','209E 209D 303C 303D 303E 303F 3045 3046 70E1')
add('Kontext – zugehörige Fund- und Ladenmeldungen','0081 003C 0050 0093 00AA')
covered={i for _,ids in sections for i in ids};excluded30={'3040','305F','3060','3061','3062','3063','3066','3072','3073'}
remaining={i for i in m if i.startswith('30')}-covered-excluded30
if remaining:add('Weitere gespeicherte Goronen-Textvarianten / nicht eindeutig zugeordnete Zustände',' '.join(sorted(remaining)))
# Check all literal 30xx message IDs in the live Goron actor paths are accounted for.
actor='\n'.join((O/r).read_text()for r in ['src/overlays/actors/ovl_En_Go2/z_en_go2.c','src/overlays/actors/ovl_En_Du/z_en_du.c'])
refs={f'{int(x,16):04X}'for x in re.findall(r'0x(30[\da-fA-F]{2})',actor)}&set(m)
assert refs<={i for _,ids in sections for i in ids}|excluded30,refs-covered-excluded30
lines=['# Sämtliche Goronen-NPC-Dialoge – aktueller Stand V106','',
'Aktuelle deutsche Projekttexte, nach Figuren, Orten und Zeitlinien geordnet. Wiederholungen und Auswahlzweige sind enthalten; gemeinsame Texte erscheinen bei mehreren Figuren erneut. Maskenreaktionen sind nicht enthalten. Wallace und die zugehörigen Fundmeldungen stehen ausdrücklich als Kontext in eigenen Abschnitten. Die neu eingebauten Soldaten und beide Beta-Goronen-Auftritte sind enthalten.','',
'Jede Seite entspricht einer Textbox-Seite. [Spielername] ist der Spielstandsname. Zusätzliche gespeicherte Varianten sind als solche gekennzeichnet; nicht jeder gespeicherte Eintrag muß im regulären Spiel erreichbar sein.',''];records=[]
for title,ids in sections:
 lines+=['## '+title,'']
 for i in ids:
  assert i in m and i not in mask,(title,i)
  emit(i,lines,records)
stem='Dialogliste_Goronen_NPCs_Kind_und_Erwachsen_V106_Aktuell';md='\n'.join(lines)
for ext in ['md','txt']:(W/(stem+'.'+ext)).write_text(md)
(W/(stem+'.json')).write_text(json.dumps(records,ensure_ascii=False,indent=2))
assert source.read_bytes()==raw
summary=dict(source_sha256=hashlib.sha256(raw).hexdigest(),all_stored_german_messages=len(m),excluded_mask_reaction_ids=len(mask),included_ids=len(included),full_export_pages=sum(len(r['pages'])for r in all_records),goron_unique_ids=len({r['id']for r in records}),goron_entries=len(records),goron_actor_30xx_ids_covered=True,source_unchanged=True)
(W/'export-verification.json').write_text(json.dumps(summary,indent=2));print(summary)
# Current Zora speakers and the characters that replace their native roles.
zsections=[
('Zora-Bewohner – Kind, Zoras Reich','4006 4007 4008 4009 400A 400B 400C 400D 400E 400F 4010 4011 402F'),
('Zora-Bewohner – Hylia-See und Rückfragen','4020 4021 402A 402D 402E'),
('König Zora – Kind und Rutos Verschwinden','401A 401B 401C 402B'),
('Ruto – Jabu-Jabus Inneres','404B 404C 404D 404E 404F 4050 4051 4052 4048 401E'),
('Ruto – nach Jabu-Jabu, beide Wunsch-Antworten','4022 4023 4024 4025 4026 4029 4027 4028 402C'),
('Thaddäus – Tauchspiel (ersetzte Zora-Rolle)','4053 4054 405A 405B 4055 4056 405C 405D 0136 0138'),
('König Zora – Erwachsener, Auftauen und Wassertempel','4012 4013 401F 4039 4044 4045'),
('König Zora – Tauschquest','4014 4015 4016'),
('Zusätzlicher erwachsener Zora in Zoras Reich','209F'),
('Thaddäus – Wassertempel und Wasserweiser (ersetzt die erwachsene Ruto)','403E 4041 4042 4046 4049 404A 70E2'),
('Zora-Laden – Begrüßung und Gespräche','7241 0083 403A 403B 0084 0085 0086 0096'),
('Zora-Laden – Waren und Angebote','00AB 0094 00A0 008A 00B0 007D 00AF 007B 00AC 0095 00A2 0087 00B3 007E 00A5 008E'),
('Kontext – zugehörige Fund- und Erzählmeldungen','4005 4033 4034 4035 0051 0054 0082 003D'),
('Kontext – Eishöhlen-Figur über einen Zora-Actor','706B')]
zl=['# Zora-NPCs – aktuelle deutsche Dialoge, Stand V106','',
'Aus den aktuellen Projektquellen ausgelesen. In V106 wurden ausschließlich Seitenumbrüche korrigiert; alle Wörter und Sätze sind erhalten. Nach Figuren und Zeitlinien sortiert, mit Auswahlzweigen. Thaddäus als Ersatz für Zora-Rollen, gemeinsame Ladentexte und Fundmeldungen sind separat gekennzeichnet. Keine Maskenreaktionen.',''];zr=[]
for title,ids in zsections:
 zl+=['## '+title,'']
 for i in ids.split():
  assert i in m and i not in mask,(title,i)
  emit(i,zl,zr)
# Literal text IDs called by the native Zora / Ruto / King / diving implementations.
covered={r['id']for r in zr};outside=set()
for overlay in ['En_Zo','En_Kz','En_Ru1','En_Ru2','En_Diving_Game']:
 files=(O/'src/overlays/actors'/('ovl_'+overlay)).glob('*.c')
 for f in files:
  text=f.read_text();calls=re.findall(r'(?:return|textId\s*=|textId\s*==|Message_(?:Continue|Start)Textbox\(play,)\s*0x([\da-fA-F]{4})',text)
  outside|={f'{int(x,16):04X}'for x in calls if f'{int(x,16):04X}'in m}-covered-mask
if outside:
 zl+=['## Weitere gespeicherte / im Zora-Code verwendete Varianten','']
 for i in sorted(outside):emit(i,zl,zr,'Zusätzliche Variante aus dem Zora-/Ruto-/Tauchspiel-Code.')
stem='Dialogliste_Zora_NPCs_Kind_und_Erwachsen_V106_Aktuell';zmd='\n'.join(zl)
for ext in ['md','txt']:(W/(stem+'.'+ext)).write_text(zmd)
(W/(stem+'.json')).write_text(json.dumps(zr,ensure_ascii=False,indent=2))
summary.update(zora_unique_ids=len({r['id']for r in zr}),zora_entries=len(zr),zora_sources_unchanged=True)
(W/'export-verification.json').write_text(json.dumps(summary,indent=2));print('ZORA_EXPORT',summary['zora_unique_ids'])

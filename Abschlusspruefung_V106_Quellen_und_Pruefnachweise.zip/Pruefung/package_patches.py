from pathlib import Path
import hashlib, json, subprocess, struct
import ipl3checksum

W = Path(__file__).resolve().parent
base = Path('/workspace/oot-burns-pal/baseroms/pal-1.0/baserom.z64')
js = """const fs=require('fs');global.BinFile=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/modules/BinFile');const p=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/RomPatcher');const b=Buffer.from(p.applyPatch(new BinFile(process.argv[1]),p.parsePatchFile(new BinFile(process.argv[2])),{requireValidation:true})._u8array);if(!b.equals(fs.readFileSync(process.argv[3])))throw Error('Mismatch');"""
proof = {'base_sha256': hashlib.sha256(base.read_bytes()).hexdigest(), 'builds': {}}
for mode in ['normal', 'debug']:
    rom = W / (mode + '.z64')
    data = rom.read_bytes()
    assert len(data) == 0x4000000
    crc = ipl3checksum.CICKind.CIC_X105.calculateChecksum(data)
    assert struct.unpack_from('>II', data, 16) == crc
    name = 'Mr_Burns_Mr_Bean_DE_PAL10_' + ('DEBUG_' if mode == 'debug' else '') + 'Abschlusstest_V106.bps'
    patch = W / name
    subprocess.run(['/workspace/toolchain/Flips/flips', '--create', '--bps', str(base), str(rom), str(patch)], check=True)
    subprocess.run(['node', '-e', js, str(base), str(patch), str(rom)], check=True)
    proof['builds'][mode] = dict(filename=name, bytes=len(data), rom_sha256=hashlib.sha256(data).hexdigest(), patch_bytes=patch.stat().st_size, patch_sha256=hashlib.sha256(patch.read_bytes()).hexdigest(), n64_checksum_verified=True, independently_applied_byte_identical=True)
    print('PATCH_VERIFIED', mode, proof['builds'][mode], flush=True)
(W / 'patch-verification.json').write_text(json.dumps(proof, indent=2))

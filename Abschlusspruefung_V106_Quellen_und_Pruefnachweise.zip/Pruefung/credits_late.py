from pathlib import Path
import json,re,struct,os,subprocess
w=Path(__file__).resolve().parent;o=Path('/workspace/oot-burns-pal');mode='normal';s=json.loads((w/'all-symbols-normal.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(s[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('/workspace/bean-rider/stalled-ram.bin','/tmp/credits-stall.bin').replace('obj<=0x1af','obj<=0x1b0').replace('DebugMemWrite32(savebase+0x135c,0);','DebugMemWrite32(savebase+0x135c,3);').replace('"ScreenWidth",640','"ScreenWidth",320').replace('"ScreenHeight",480','"ScreenHeight",240')
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);scenes=(o/'include/tables/scene_table.h').read_text();final=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_SCENE\([^\n]*SCENE_CASTLE_COURTYARD_ZELDA',scenes)[1],16)
body=(w/'credits_late_body.c').read_text().replace('FINALSCENE',str(final));(w/'credits_late.c').write_text(base[:a]+body+base[b:]);exe=w/'credits_late'
subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(w/'credits_late.c'),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
e=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\(ENTR_GERUDO_VALLEY_0,',(o/'include/tables/entrance_table.h').read_text())[1],16)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,e,1,0xfff2);struct.pack_into('>i',q,0x1364,0);q[0x1409]=1;struct.pack_into('>I',q,0xa4,0x1fffff);struct.pack_into('>H',q,0xf30,0x7000);(w/'credits_late.save').write_bytes(q)
with(w/'credits-late-normal.log').open('w')as f:r=subprocess.run([str(exe),str(w/'normal.z64'),'full-credits-late-v106-direct','24000','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(w/'credits_late.save')],env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=2500)
print('FULL_CREDITS_RESULT',r.returncode,flush=True)

from pathlib import Path
import sys,shutil,json,hashlib
root=Path(__file__).resolve().parent;target=Path(sys.argv[1]).resolve()
assert (target/'Makefile').is_file(),target
manifest=json.loads((root/'source-manifest.json').read_text())
for rel,expected in manifest.items():
 p=root/'production'/rel
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,rel
for rel in manifest:
 p=root/'production'/rel;q=target/rel;q.parent.mkdir(parents=True,exist_ok=True)
 if q.is_symlink():q.unlink()
 shutil.copyfile(p,q)
print('V88 production sources and native music assets installed. Build PAL1.0 with the existing toolchain.')

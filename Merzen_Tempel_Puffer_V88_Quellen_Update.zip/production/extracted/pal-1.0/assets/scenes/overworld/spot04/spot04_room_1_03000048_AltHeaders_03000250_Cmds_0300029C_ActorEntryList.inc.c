    {
        ACTOR_OBJECT_KANKYO,
        {   3409,   -143,   -818 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 0
    {
        ACTOR_OBJ_DEKUJR,
        {   3704,   -172,  -1074 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x1E00, // params
    }, // 1
    {
        ACTOR_BG_TREEMOUTH,
        {   3882,   -171,  -1161 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 2
    {
        ACTOR_EN_GS,
        {   3800,   -159,  -2230 }, // pos
        {  0x0000, -0x31C7,  0x0000 }, // rot
         0x391F, // params
    }, // 3
    {
        ACTOR_EN_GS,
        {   4740,   -157,   -700 }, // pos
        {  0x0000,  0x638E,  0x0000 }, // rot
         0x3A20, // params
    }, // 4

    { ACTOR_ELF_MSG2, { 2185, -1, -300 }, { 0, 0, 1 }, 0x3F9F }, /* V28 */

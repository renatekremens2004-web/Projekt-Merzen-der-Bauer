    {
        ACTOR_BG_TREEMOUTH,
        {   3882,   -171,  -1161 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 0
    {
        ACTOR_DEMO_EFFECT,
        {   3225,    -61,   -377 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x0FA /* 0xFF06 */, // params
    }, // 1
    {
        ACTOR_OBJECT_KANKYO,
        {   3057,    -79,   -754 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 2

    { ACTOR_ELF_MSG2, { 2185, -1, -300 }, { 0, 0, 1 }, 0x3F9F }, /* V28 */

    {
        ACTOR_OBJECT_KANKYO,
        {   3409,   -143,   -818 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 0
    {
        ACTOR_EN_KAREBABA,
        {   2293,     -1,   -496 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0001, // params
    }, // 3
    {
        ACTOR_EN_KAREBABA,
        {   3126,   -180,  -1555 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0001, // params
    }, // 4
    {
        ACTOR_EN_KAREBABA,
        {   4129,   -170,   -548 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0001, // params
    }, // 5
    {
        ACTOR_BG_TREEMOUTH,
        {   3882,   -171,  -1161 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
        -0x001 /* 0xFFFF */, // params
    }, // 6
    {
        ACTOR_EN_GS,
        {   3800,   -159,  -2230 }, // pos
        {  0x0000, -0x31C7,  0x0000 }, // rot
         0x391F, // params
    }, // 7
    {
        ACTOR_EN_GS,
        {   4740,   -157,   -700 }, // pos
        {  0x0000,  0x638E,  0x0000 }, // rot
         0x3A20, // params
    }, // 8

    { ACTOR_ELF_MSG2, { 2185, -1, -300 }, { 0, 0, 1 }, 0x3F9F }, /* V28 */

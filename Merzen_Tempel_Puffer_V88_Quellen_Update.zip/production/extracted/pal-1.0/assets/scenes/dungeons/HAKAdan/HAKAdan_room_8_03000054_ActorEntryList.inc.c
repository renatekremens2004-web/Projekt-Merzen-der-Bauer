    {
        ACTOR_EN_ST,
        {   4706,   -424,    259 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0001, // params
    }, // 1
    {
        ACTOR_EN_ST,
        {   4379,   -564,    257 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x0001, // params
    }, // 2
    {
        ACTOR_EN_ST,
        {   4262,   -600,    920 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x0001, // params
    }, // 3
    {
        ACTOR_BG_HAKA_TRAP,
        {   4258,   -835,   1114 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 4
    {
        ACTOR_BG_HAKA_TRAP,
        {   4258,   -835,    614 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0000, // params
    }, // 5


    {
        ACTOR_OBJ_TSUBO,
        {  -1806,    -63,   -344 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x500F, // params
    }, // 0
    {
        ACTOR_OBJ_TSUBO,
        {  -1721,    -63,     61 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x520F, // params
    }, // 1
    {
        ACTOR_OBJ_TSUBO,
        {  -1407,    -63,     61 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x5403, // params
    }, // 2
    {
        ACTOR_OBJ_TSUBO,
        {  -1614,    -63,     61 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x5E01, // params
    }, // 3
    {
        ACTOR_OBJ_TSUBO,
        {  -1055,    -63,   -257 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x600C, // params
    }, // 4
    {
        ACTOR_OBJ_TSUBO,
        {  -1050,    -63,   -130 }, // pos
        {  0x0000,  0x4000,  0x0000 }, // rot
         0x6203, // params
    }, // 5
    {
        ACTOR_EN_TUBO_TRAP,
        {  -1507,    -63,     61 }, // pos
        {  0x0000, -0x8000,  0x0000 }, // rot
         0x00F5, // params
    }, // 6
    {
        ACTOR_BG_HAKA_MEGANE,
        {  -1274,    -63,   -185 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x0003, // params
    }, // 15
    {
        ACTOR_BG_HAKA_MEGANE,
        {   -514,    -63,   -185 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x0003, // params
    }, // 16
    {
        ACTOR_BG_HAKA_MEGANE,
        {  -1074,    -63,   -185 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x0003, // params
    }, // 17
    {
        ACTOR_BG_HAKA_MEGANE,
        {  -1834,    -63,   -405 }, // pos
        {  0x0000, -0x4000,  0x0000 }, // rot
         0x0003, // params
    }, // 18
    {
        ACTOR_BG_HAKA_MEGANE,
        {   -794,    -63,   -465 }, // pos
        {  0x0000,  0x0000,  0x0000 }, // rot
         0x0003, // params
    }, // 19


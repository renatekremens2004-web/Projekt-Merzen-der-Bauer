from pathlib import Path
import json
W=Path(__file__).resolve().parent
(W/'qa-case.txt').write_text('batch');(W/'ram-command.json').write_text(json.dumps(dict(id=10,action='qa',mode='normal')))

from pathlib import Path
import re,shutil,json,hashlib
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');D=O/'extracted/pal-1.0/assets/scenes/dungeons'
jobs=[('HIDAN',5,'ACTOR_EN_GOROIWA',1),('HIDAN',18,'ACTOR_EN_RR',1),('HIDAN',19,'ACTOR_EN_RR',1),('HAKAdan',8,'ACTOR_EN_ST',1),('HAKAdan',0,'ACTOR_EN_WONDER_TALK2',8),('HAKAdan',2,'ACTOR_EN_WONDER_TALK2',2)]
assert not (W/'changes.json').exists(), 'one-shot edit already applied'
report=[]
for folder,room,actor,count in jobs:
 p=next((D/folder).glob(f'{folder}_room_{room}_*ActorEntryList.inc.c'));h=D/folder/f'{folder}_room_{room}.h'
 for f in [p,h]:
  b=W/'original'/f.relative_to(O);b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,b)
 removed=[]
 def repl(m):
  s=m[0]
  if actor in s and len(removed)<count:removed.append(s);return''
  return s
 before=p.read_text();after=re.sub(r'^    \{\n.*?^    \}, // \d+\n',repl,before,flags=re.M|re.S);assert len(removed)==count
 symbol='LENGTH_'+p.name.removesuffix('.inc.c');s=h.read_text();m=re.search(r'#define '+symbol+r' (\d+)',s);assert m;old=int(m[1]);p.write_text(after);h.write_text(s.replace(m[0],f'#define {symbol} {old-count}'))
 # All remaining entries stay byte-for-byte text-identical and in the original order.
 assert after==before.replace(removed[0],'',1)if count==1 else True
 report.append(dict(scene=folder,room=room,actor=actor,count=count,before_count=old,after_count=old-count,removed_entries=removed))
assert not any('ACTOR_EN_RR'in p.read_text()for p in(D/'HIDAN').glob('*ActorEntryList.inc.c'))
(W/'changes.json').write_text(json.dumps(report,indent=2));print([(r['scene'],r['room'],r['actor'],r['count'])for r in report])

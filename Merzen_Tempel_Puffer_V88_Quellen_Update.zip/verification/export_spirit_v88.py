from pathlib import Path
import sys,re,json,hashlib,zipfile
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');W=Path('/workspace/dungeon-buffer-v88');D=W/'dialogue';D.mkdir(exist_ok=True);sys.path.insert(0,str(R/'tools'))
from build_story import messages,split_pages,LEX,controls
p=O/'extracted/pal-1.0/text/message_data.h';raw=p.read_bytes();m=messages(raw.decode());edits={}
for path in (R/'story').glob('*.json'):
 for i in json.loads(path.read_text())['messages']:edits.setdefault(i,[]).append(path.name)
def ids(t):return t.split()
def seq(a,b):return [f'{n:04X}'for n in range(a,b+1)if f'{n:04X}'in m]
def decode(body):
 out=''
 for mt in LEX.finditer(body):
  t=mt.group()
  if t.startswith('"'):out+=json.loads(t)
  elif t=='NAME':out+='[Spielername]'
  elif t in ['MARATHON_TIME','RACE_TIME']:out+='[Rennzeit]'
  elif t in ['POINTS','TOKENS']:out+='[Punkte]'
  elif t.startswith('HIGHSCORE('):out+='[Bestwert]'
 return out.strip()
loc={}
for region in ['jyasinzou','jyasinboss','men','gerudoway']:
 for path in (O/f'extracted/pal-1.0/assets/scenes/dungeons/{region}').glob('*ActorEntryList*.c'):
  for mt in re.finditer(r'\bACTOR_(ELF_MSG2?)\b,\s*\{[^}]*\},\s*(?://[^\n]*\n\s*)?\{[^}]*\},\s*(?://[^\n]*\n\s*)?(-?0x[0-9a-fA-F]+)',path.read_text()):
   param=int(mt[2],16)&65535
   if param>=0x3f00:continue
   ident=f'{(param&255)+0x100:04X}';room=re.search(r'_room_(\d+)',path.name)[1]
   if ident in m:loc.setdefault(ident,[]).append(region+', Raum '+room)
itemids=[]
for ident,entry in m.items():
 if int(ident,16)<0x100 and any(w in decode(entry['parts'][2][2]).lower()for w in ['spiegelschild','kompaß','karte des geister','gerudo-paß','krafthandschuhe','geisteramulett','requiem der geister']):itemids.append(ident)
groups=[
('0. Abschluß des Schattentempels – Mr. Bean und Schattenamulett',ids('5022 5025 502B 502C 5026 0041 5023')),
('1. Navis Story-Hinweise vor und nach dem Wüstenkapitel',ids('0156 0158 015A 015B 0124')),
('2. Zusätzliche Figuren – Wario, Wawario und Wawaluigi',ids('601C 608D 608E')),
('3. Gerudotal – Zimmermannschef und Running Man',ids('606A 606B 606C 6086 607D 607E 607F 6080 6081 6082 6083 6084 6085')),
('4. Gerudo-Festung – Wachen, Paß, Tor, Training und Bogenschießen',seq(0x6000,0x600A)+seq(0x6010,0x601B)+ids('6037 6038')+seq(0x6040,0x6049)+ids('6069')),
('5. Gerettete Zimmerleute und ihre Varianten',seq(0x605B,0x6068)),
('6. Gespensterwüste – Teppichhändler und Wüstengeist',ids('6077 71C6 600B')),
('7. Wüstenkoloss – Sheik und Requiem der Geister',ids('600C 0076')),
('8. Eule am Geistertempel',ids('6079 607A 607B 607C')),
('9. Marty und Doc am Wüstenkoloss, Mauzi und Starwalker im Tempel',ids('71BF 71C0 71C1 71C2 71C3 721D')),
('10. Waluigi als Kind begegnen – sämtliche Angebote und Antworten',seq(0x601D,0x6027)),
('11. Entführung von Waluigi',ids('6028 603B 603C 603D 603E')),
('12. Geistertempel – örtliche Navi-Hinweise, Schilder und Fundtexte',sorted(loc)+ids('0105')+seq(0x600D,0x600F)+itemids),
('13. Verhexter Waluigi, Eisenprinz und Befreiung',seq(0x6029,0x6035)),
('14. Koume und Kotake – Kampf, Fusion und vollständiger Abschiedsstreit',seq(0x604A,0x605A)),
('15. Halle der Weisen – Waluigi und Geisteramulett',ids('6039 603A 6036 003F')),
('16. Gegner-Zielerfassung im Kapitel',ids('0632 0633 0634 0635')),
('17. Weitere gespeicherte Varianten aus dem gesamten 6000er-Kapitel',seq(0x6000,0x6086)),
('18. Grenz-Soldaten, Flammenwerfer und der Mitgefangene',seq(0x7206,0x720C)+ids('7229 7234')),
('19. Späterer Rückbezug – Waluigi beim Geistersiegel und Navis dritte Handschuhe',ids('70E4 005C')),
('20. Abschluß und bedingter Kontakt – Zitadelle der Zeit und Salias Lied',ids('5024 00E0 00E1 016D'))]
# Include every native cutscene text for Requiem and the Spirit Medallion.
coverage=[]
for path in [O/'src/overlays/actors/ovl_Demo_Im/z_demo_im_cutscene_data.inc.c',O/'extracted/pal-1.0/assets/scenes/overworld/spot11/gDesertColossusRequiemOfSpiritCs.csdata.inc.c',O/'src/overlays/actors/ovl_En_Nb/sage_medallion_cameras.inc.c', O/'extracted/pal-1.0/assets/scenes/overworld/spot11/gDesertColossusNabooruCapturedCs.csdata.inc.c']:
 if path.exists():
  csids=re.findall(r'CS_TEXT\(0x([0-9A-F]{4})',path.read_text());coverage.append(dict(source=str(path.relative_to(O)),ids=csids));groups.append(('Anhang: vollständige Textabdeckung '+path.name,csids))
seen=set();records=[]
lines=['# Aktuelle Dialoge: Gerudotal, Wüste und Geistertempel','','Aktueller eingebauter Stand V88, 25. Oktober 2026. Direkt aus dem deutschen Spieltext ausgelesen: vom Abschluß des Schattentempels mit Mr. Bean in der Halle der Weisen über Gerudotal, Festung und Wüste bis Waluigi in der Halle der Weisen. Die neuen Grenz-Soldaten, der Flammenwerfer-Gorone, der Mitgefangene, der bewaffnete Beta-Gorone und Starwalker sind mit enthalten. Dieser Export ändert keine Spieltexte.','','Text-IDs, Seiten und Auswahlantworten entsprechen den Spieltexten. [Spielername] bleibt dynamisch. Bedingte Antworten, Wiederholungen und alternative Zustände werden nicht automatisch alle nacheinander gesprochen. Zeilenumbrüche innerhalb einer Seite sind nur für die Lesbarkeit zusammengezogen.','','Zum Ändern genügt etwa: „6023, Seite 2 neu: …“.','']
for title,items in groups:
 k=0
 while k<len(items):
  ident=items[k]
  if ident not in m:k+=1;continue
  for nxt in re.findall(r'TEXTID\(0x([0-9A-Fa-f]+)\)',m[ident]['parts'][2][2]):
   nxt=nxt.upper()
   if nxt not in items:items.insert(k+1,nxt)
  k+=1
 fresh=[i for i in items if i in m and i not in seen]
 if not fresh:continue
 lines+=['## '+title,'']
 for ident in fresh:
  if ident in seen:continue
  seen.add(ident);body=m[ident]['parts'][2][2];pages,_=split_pages(body);pages=[decode(page)for page in pages];targets=re.findall(r'TEXTID\(0x([0-9A-Fa-f]+)\)',body)
  record=dict(id=ident,section=title,pages=pages,controls=controls(body),project_sources=edits.get(ident,[]));records.append(record)
  lines+=['### '+ident,'']
  lines+=['Aktuell eingebauter Text.','']
  notes={'5022':'Mr. Bean als Schattenweiser; sein Wortlaut bleibt auch im deutschen Spiel englisch.', '7234':'Beta-Gorone mit verkleinerter Pistole am Gerudotal; nur als Erwachsener.', '601C':'Wario in Kakariko als Kind; optionaler Hinweis auf Waluigi.', '608D':'Wawario im Gefängnis der Gerudo-Festung, nur Erwachsene.', '608E':'Wawaluigi beim Zelt im Gerudotal, nur Erwachsene.', '71BF':'Erste Begegnung aus Sicht von Marty und Doc: ausschließlich als erwachsener Link am Wüstenkoloss. Die Fortsetzungen 71C0–71C2 gehören zum selben Gespräch.', '71C3':'Mauzi im erwachsenen Teil des Geistertempels.', '721D':'Original Starwalker im Geistertempel; Pause vor seinem Namen.', '6019':'Besorgte Kindervariante der Gerudo am Talboden.', '601A':'Fortsetzung bzw. Reaktion der besorgten Kindervariante.', '6069':'Kindervariante am Wüstentor.', '6077':'Erwachsener Teppichhändler; 71C6 ist dessen eigene Kindervariante.', '71C6':'Kindervariante des Teppichhändlers; Erwachsenenangebot bleibt getrennt.', '7229':'Flammenwerfer-Gorone auf der Hyrule-Feld-Seite vor dem Gerudotal, nur Erwachsene.', '720C':'Unbewaffneter Soldat in der Gefängniszelle bei Wawario.', '70E4':'Späterer Rückbezug im Schloß; kein zusätzlicher unmittelbarer Geistertempel-Abschied.', '005C':'Späterer Titanhandschuh-Fundtext im Schloß samt Navis Rückverweis.', '5024':'Bedingter Hinweis nach allen erforderlichen Tempeln. Bei der üblichen Reihenfolge ist dies das Ende des Geistertempel-Kapitels; andere Reihenfolgen können ihn früher oder später auslösen.', '016D':'Salia per Okarina nach dem Schattenamulett, abhängig von den übrigen Amuletten. Kein zusätzlicher automatischer Dialog nach dem Endboß.'}
  if ident in notes:lines += [notes[ident],'']
  timed=[x for x in controls(body)if x.startswith(('FADE','BOX_BREAK_DELAYED'))]
  if timed:lines+=['Zeitgesteuert: '+', '.join(timed)+'.','']
  if ident in loc:lines+=['_Navi: '+', '.join(loc[ident])+'._','']
  if targets:lines+=['_Direkte Fortsetzung: '+', '.join(targets)+'._','']
  for n,page in enumerate(pages,1):
   lines+=['**Seite '+str(n)+'**','']
   if '\n' in page and not any(c in body for c in ['TWO_CHOICE','THREE_CHOICE']):page=re.sub(r'(?<!\n)\n(?!\n)',' ',page)
   lines+=['> '+line if line else'>'for line in page.splitlines()]+['']
  if 'TWO_CHOICE'in body or'THREE_CHOICE'in body:lines+=['_Die Antwortauswahl steht in ihrer tatsächlichen Reihenfolge auf der zugehörigen Seite._','']

for row in coverage:assert set(row['ids'])<=seen,row
lines += ['---','',str(len(records))+' verschiedene Nachrichten. Optionales, Varianten und spätere Rückbezüge sind entsprechend beschriftet.','']
text='\n'.join(lines)+'\n';base='Dialogliste_Schattentempelabschluss_bis_Geistertempel_V88';files=[base+'.md',base+'.txt',base+'_Verzeichnis.json']
(D/files[0]).write_text(text);(D/files[1]).write_text(re.sub(r'^> ?', '',text,flags=re.M));(D/files[2]).write_text(json.dumps(dict(source_sha256=hashlib.sha256(raw).hexdigest(),total_messages=len(records),messages=records,cutscene_coverage=coverage),ensure_ascii=False,indent=2)+'\n');(R/'planning'/files[0]).write_text(text)
assert raw==p.read_bytes()
(W/'package-manifest.json').write_text(json.dumps(dict(files=files),indent=2)+'\n');print('Export:',len(records),'IDs,',len(text),'characters; messages unchanged.')

with zipfile.ZipFile(D/(base+'.zip'),'w',zipfile.ZIP_DEFLATED)as z:
 for n in files:z.write(D/n,n)
files.append(base+'.zip');(W/'spirit-export-manifest.json').write_text(json.dumps(dict(files=files),indent=2)+'\n')

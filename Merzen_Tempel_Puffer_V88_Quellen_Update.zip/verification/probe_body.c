static void capture_render(void){}
static unsigned countid(unsigned id){unsigned n=0;for(int c=0;c<12;c++)for(unsigned a=r32(play+0x1c34+c*8),i=0;a>=0x80000000&&a<0x80400000&&i<180;a=r32(a+0x124),i++)if(DebugMemRead16(a)==id&&r32(a+0x130))n++;return n;}
static void onframe(unsigned f){
 static unsigned initialized=0,tiles=0,oldCount=999,paused=0,closed=0,pmark=0,moved=0;static float boulderX,boulderZ;static unsigned statueYaw;
 unsigned v=0;int fire=strstr(scenario,"fire")!=NULL,r=EXPECTED_ROOM;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 need(DebugMemRead16(play+0xa4)==(fire?4:7),"expected dungeon remains active");need(DebugMemRead8(play+0x11cbc)==r,"expected room remains active");
 unsigned msg=play+0x20d8,id=DebugMemRead16(msg+0xe2f8),mm=DebugMemRead8(msg+0xe304),st=DebugMemRead16(play+0x10934);
 if(!fire&&(r==0||r==2)){need(!countid(0x185),"all automatic Shadow wall-message triggers absent");need(!mm||!(id==0x208||id==0x209||id==0x20a||id==0x224||id==0x23c),"no removed automatic wall text opens");}
 if(!initialized){initialized=1;
  if(fire&&r==5){need(countid(0x130)==5&&!target(0x130,0x0f04),"exactly one boulder removed, five retain original path IDs");unsigned b=actor(0x130);boulderX=rf(b+0x24);boulderZ=rf(b+0x2c);}
  if(fire&&(r==18||r==19)){need(!countid(0xdd),"Like Like absent");tiles=countid(0x6b);need(tiles==(r==18?5:8),"all original floor tile enemies retained");}
  if(!fire&&r==8){need(countid(0x37)==3,"one big Skulltula removed, three remain");need(countid(0xbc)==2,"both native guillotines retained");}
  if(!fire&&r==2){need(countid(0xf7)==8,"all truth-spinner puzzle actors retained");need(!(r32(play+0x1d28)&(1u<<27)),"truth puzzle initially unsolved");statueYaw=DebugMemRead16(target(0xf7,0)+0xb6);}
  bank();
 }
 if(fire&&r==5){unsigned b=actor(0x130);if(b&&(fabsf(rf(b+0x24)-boulderX)>10||fabsf(rf(b+0x2c)-boulderZ)>10))moved=1;}
 if(!fire&&(r==0||r==2)&&f>=380&&f<530){
  static float x0[]={-792,-1074,-1612,-1273,-1553,-1827,-794,-514},z0[]={85,-188,-67,-185,-462,-190,-465,-185};
  unsigned i=(f-380)/18;if(r==0&&i<8)position(player,x0[i],-63,z0[i],0);else if(r==2)position(player,f<455?738:304,-63,f<455?54:294,0);
 }
 if(!fire&&r==2&&f>=550&&f<554){unsigned a=target(0xf7,0);position(player,780,-63,55,-16384);wf(a+0x140,1.0f);}
 if(fire&&(r==18||r==19)){
  unsigned n=countid(0x6b);
  if(n!=oldCount){printf("FLOOR_TILES f=%u room=%d remaining=%u clear=%x temp=%x\n",f,r,n,r32(play+0x1d3c),r32(play+0x1d40));oldCount=n;}
  if(f>1000&&n==0){unsigned doors=0;for(int c=0;c<12;c++)for(unsigned a=r32(play+0x1c34+c*8),i=0;a>=0x80000000&&a<0x80400000&&i<180;a=r32(a+0x124),i++)if(DebugMemRead16(a)==0x2e&&r32(a+0x130)){
   printf("EXIT_DOOR params=%x bars=%.2f room=%d\n",DebugMemRead16(a+0x1c),rf(a+0x160),(signed char)DebugMemRead8(a+3));need(rf(a+0x160)<.01f,"exit door remains unbarred after native tile battle");doors++;
  }
  need((r32(play+0x1d3c)|r32(play+0x1d40))&(1u<<r),"native enemy room-clear flag still triggered");need(doors>0||r==19,"native exit remains present");bank();printf("DUNGEON_PROBE_PASSED room=%d tiles=%u no_like_like=1\n",r,tiles);CoreDoCommand(M64CMD_STOP,0,NULL);}
 }else{
  if(f==700){v=0x10;pmark=f;}
  if(st==6&&!paused){paused=1;pmark=f;unsigned name=r32(play+0x10898);need((((name+3584+15)&~15)+7168)<=r32(play+0x117a8),"pause workspace stays inside object bank");}
  if(paused&&!closed&&st==6&&f>pmark+40)v=0x10;
  if(paused&&st==0&&!closed)closed=f;
  if(closed&&f>closed+60){need(rf(player+0x28)>-1800,"player retains floor after menu roundtrip");if(fire)need(moved,"remaining boulders still follow paths");if(!fire&&r==2)need(DebugMemRead16(target(0xf7,0)+0xb6)!=statueYaw,"native statue still rotates after a push");bank();printf("DUNGEON_PROBE_PASSED room=%d menu_roundtrip=1\n",r);CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
 if(f%150==0){printf("PROBE f=%u scene=%u room=%d xyz=%.1f %.1f %.1f enemies=%u msg=%x mode=%u pause=%u\n",f,DebugMemRead16(play+0xa4),r,rf(player+0x24),rf(player+0x28),rf(player+0x2c),r32(play+0x1c34+5*8-4),id,mm,st);bank();}
 if(buttons)buttons(v);if(f>1800){puts("DUNGEON_PROBE_TIMEOUT");exit(96);}
}

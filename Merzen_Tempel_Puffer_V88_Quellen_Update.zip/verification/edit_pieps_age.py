from pathlib import Path
import shutil,json
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal')
assert not (W/'pieps-age.json').exists()
paths=['src/code/z_actor.c','src/overlays/actors/ovl_En_Bird/pieps_actor_v75.inc.c','src/overlays/actors/ovl_Boss_Dodongo/pieps_boss_v75.inc.c']
for rel in paths:
 p=O/rel;b=W/'original'/rel
 if not b.exists():b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,b)
 s=p.read_text()
 if rel.endswith('z_actor.c'):
  old='''            if (play->sceneId == SCENE_DODONGOS_CAVERN && actorEntry->id == ACTOR_EN_BIRD &&
                actorEntry->params == 0x7501 && play->roomCtx.prevRoom.num >= 0) {'''
  new='''            if (play->sceneId == SCENE_DODONGOS_CAVERN && actorEntry->id == ACTOR_EN_BIRD &&
                actorEntry->params == 0x7501 && LINK_IS_ADULT) {
                /* Pieps belongs to the child chapter; do not load his overlay as an adult. */
                actorEntry++;
            } else if (play->sceneId == SCENE_DODONGOS_CAVERN && actorEntry->id == ACTOR_EN_BIRD &&
                       actorEntry->params == 0x7501 && play->roomCtx.prevRoom.num >= 0) {'''
  assert old in s;s=s.replace(old,new,1)
  old='''    if (sPiepsPendingRoomV85 >= 0) {
        if (play->sceneId != SCENE_DODONGOS_CAVERN ||''';new=old.replace('if (play->sceneId','if (LINK_IS_ADULT || play->sceneId');assert old in s;s=s.replace(old,new,1)
 elif rel.endswith('pieps_actor_v75.inc.c'):
  old=' u32 saved=gSegments[6];this->unk_194=0;this->rotYStep=CAM_ID_NONE;';new=old+'\n if(LINK_IS_ADULT){Actor_Kill(&this->actor);return;}'
  assert old in s;s=s.replace(old,new,1)
 else:
  old='if(!GET_INFTABLE(0x1CA)||sPiepsAssistedV75)return false;';assert old in s;s=s.replace(old,'if(LINK_IS_ADULT||!GET_INFTABLE(0x1CA)||sPiepsAssistedV75)return false;',1)
  old='if(GET_INFTABLE(0x1CA))Actor_Spawn';assert old in s;s=s.replace(old,'if(LINK_IS_CHILD&&GET_INFTABLE(0x1CA))Actor_Spawn',1)
 p.write_text(s)
(W/'pieps-age.json').write_text(json.dumps(dict(files=paths,child_only=True,adult_cage_skipped_before_overlay_load=True,adult_boss_assistance_disabled=True,adult_post_boss_bird_disabled=True,child_flags_unchanged=True),indent=2))

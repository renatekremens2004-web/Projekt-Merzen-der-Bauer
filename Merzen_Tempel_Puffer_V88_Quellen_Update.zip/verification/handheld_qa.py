from pathlib import Path
import os,sys,subprocess,struct,re,json
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];kind=sys.argv[3];fd=int(rom.rsplit('/',1)[1]);s=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(s[n]))
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);runner=W/f'handheld-{mode}-{kind}';c=runner.with_suffix('.c');c.write_text(base[:a]+(W/'handheld_body.c').read_text()+base[b:]);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());child=kind=='child';post=kind=='adultafter';struct.pack_into('>III',q,0,0xee,child,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,2160,0,150,-32768,0xdff,0xee,0);q[0x1409]=1;struct.pack_into('>HH',q,0x2e,0x140,0x140);struct.pack_into('>H',q,0x70,(struct.unpack_from('>H',q,0x70)[0]&0xff00)|(0x11 if child else 0x12));q[0xd4+0x55*0x1c:0xd4+0x56*0x1c]=bytes(0x1c)
quest=struct.unpack_from('>I',q,0xa4)[0];struct.pack_into('>I',q,0xa4,(quest|1)if post else(quest&~1));ev=struct.unpack_from('>H',q,0xed4+8)[0];struct.pack_into('>H',q,0xed4+8,(ev|0x100)if post else(ev&~0x100));fixture=W/f'handheld-{kind}.save';fixture.write_bytes(q);log=W/f'{mode}-handheld-{kind}.log'
photos=Path('/workspace/bean-rider/screens-handheld-v88-'+mode+'-'+kind+'-direct');before=set(photos.glob('*.png'))
with log.open('w')as f:r=subprocess.run([str(runner),rom,'handheld-v88-'+mode+'-'+kind+'-direct','2200','4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(fixture)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=240)
assert r.returncode==0,(r.returncode,log.read_text()[-2800:]);print('HANDHELD_CASE_PASSED',mode,kind,flush=True)

import shutil
new=sorted(set(photos.glob('*.png'))-before,key=lambda p:p.name);assert len(new)>=2;shutil.copyfile(new[0],W/f'handheld-proof-{mode}-{kind}.png')

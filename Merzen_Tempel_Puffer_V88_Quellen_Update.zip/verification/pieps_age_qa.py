from pathlib import Path
import os,sys,json,re,struct,subprocess
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom,mode,kind=sys.argv[1:4];fd=int(rom.rsplit('/',1)[1]);sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());s=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:s=s.replace(hex(old[n]),hex(sy[n]))
a=s.index('static void capture_render(void){}');b=s.index('static void setting(',a);body=(W/'pieps_age_body.c').read_text()
for macro,n in [('BOSS_VRAM','_ovl_Boss_DodongoSegmentStart'),('EXPLODE','BossDodongo_Explode'),('DEATH','BossDodongo_DeathCutscene')]:body=body.replace(macro,hex(sy[n]))
runner=W/f'pieps-age-{mode}-{kind}';c=runner.with_suffix('.c');c.write_text(s[:a]+body+s[b:]);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
child=kind.endswith('child');cage=kind.startswith('cage');clear=kind.startswith('cleared');scene=1 if cage else 0x12;room=3 if cage else 1;text=(O/'include/tables/entrance_table.h').read_text();name='ENTR_DODONGOS_CAVERN_0'if cage else'ENTR_DODONGOS_CAVERN_BOSS_0';e=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\('+name+r',',text)[1],16)
q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,e,child,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,*((2920,100,-2292)if cage else(-890,-1523.76,-2804)),0,0xdff,e,room);q[0x1409]=1;q[0xd4+scene*0x1c:0xd4+(scene+1)*0x1c]=bytes(0x1c);struct.pack_into('>H',q,0xf30,(struct.unpack_from('>H',q,0xf30)[0]&~0x400)if cage else(struct.unpack_from('>H',q,0xf30)[0]|0x400));struct.pack_into('>HH',q,0x2e,0x140,0x140)
if not cage:struct.pack_into('>H',q,0xed4+14,struct.unpack_from('>H',q,0xed4+14)[0]|2)
if clear:struct.pack_into('>I',q,0xd4+scene*0x1c+8,2)
fixture=W/f'pieps-age-{kind}.save';fixture.write_bytes(q);log=W/f'{mode}-pieps-{kind}.log'
with log.open('w')as f:r=subprocess.run([str(runner),rom,'pieps-age-v88-'+mode+'-'+kind+'-direct','1300','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(fixture)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=240)
assert r.returncode==0,(kind,r.returncode,log.read_text()[-2500:]);print('PIEPS_AGE_CASE_PASSED',mode,kind,flush=True)

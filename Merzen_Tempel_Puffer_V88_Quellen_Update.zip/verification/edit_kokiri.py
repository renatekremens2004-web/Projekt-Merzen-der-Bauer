from pathlib import Path
import re,json,shutil
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');D=O/'extracted/pal-1.0/assets/scenes/overworld/spot04'
assert not (W/'kokiri-removals.json').exists(), 'one-shot edit already applied'
jobs=[('spot04_room_0_03000048_AltHeaders_030006B0_Cmds_03000700_ActorEntryList.inc.c','ACTOR_EN_DEKUNUTS',3,None),('spot04_room_0_03000048_AltHeaders_030006B0_Cmds_03000700_ActorEntryList.inc.c','ACTOR_EN_DEKUBABA',1,(1427,0,94)),('spot04_room_1_03000088_ActorEntryList.inc.c','ACTOR_EN_KAREBABA',2,None),('spot04_room_1_03000048_AltHeaders_03000160_Cmds_030001A8_ActorEntryList.inc.c','ACTOR_EN_DEKUBABA',2,None)]
report=[]
for name,actor,count,coords in jobs:
 p=D/name;h=D/(name.split('_0300')[0]+'.h')
 for f in [p,h]:
  b=W/'original'/f.relative_to(O)
  if not b.exists():b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,b)
 removed=[];before=p.read_text()
 def repl(m):
  s=m[0]
  if actor in s and len(removed)<count:
   xyz=tuple(map(int,re.search(r'\{\s*(-?\d+),\s*(-?\d+),\s*(-?\d+)\s*\}, // pos',s).groups()))
   if coords is None or xyz==coords:removed.append(s);return ''
  return s
 after=re.sub(r'^    \{\n.*?^    \}, // \d+\n',repl,before,flags=re.M|re.S);assert len(removed)==count
 symbol='LENGTH_'+name.removesuffix('.inc.c');hs=h.read_text();m=re.search(r'#define '+symbol+r' (\d+)',hs);assert m;old=int(m[1]);p.write_text(after);h.write_text(hs.replace(m[0],f'#define {symbol} {old-count}'))
 verify=before
 for s in removed:verify=verify.replace(s,'',1)
 assert verify==after
 report.append(dict(file=str(p.relative_to(O)),actor=actor,removed_count=count,before_count=old,after_count=old-count,removed_entries=removed))
assert not any('ACTOR_EN_DEKUNUTS' in p.read_text() for p in D.glob('*ActorEntryList.inc.c'))
(W/'kokiri-removals.json').write_text(json.dumps(report,indent=2));print([(r['actor'],r['removed_count'],r['after_count'])for r in report])
p=W/'ram_build.py';p.write_text(p.read_text().replace("names=['spot04_room_1'","names=['spot04_room_0','spot04_room_1'"))

from pathlib import Path
import os,sys,subprocess,json,hashlib,io,zipfile
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];romfd=int(rom.rsplit('/',1)[1]);base=O/'baseroms/pal-1.0/baserom.z64'
assert hashlib.md5(base.read_bytes()).hexdigest()=='e040de91a74b61e3201db0e2323f768a'
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());assert 'gRoomAuditV86'not in sy
assert 'gRoomAuditV86'not in(O/'src/code/z_actor.c').read_text()
assert (W/f'batch-{mode}-passed.json').exists()
fd=os.memfd_create('v88-'+mode+'-bps');out='/proc/self/fd/'+str(fd);fds=(romfd,fd)
subprocess.run(['/workspace/toolchain/Flips/flips','--create','--bps',str(base),rom,out],pass_fds=fds,check=True)
js="const fs=require('fs'),c=require('crypto');global.BinFile=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/modules/BinFile');const p=require('/workspace/toolchain/RomPatcher.js/rom-patcher-js/RomPatcher');const actual=Buffer.from(p.applyPatch(new BinFile(process.argv[1]),p.parsePatchFile(new BinFile(process.argv[2])),{requireValidation:true})._u8array);const expected=fs.readFileSync(process.argv[3]);if(!actual.equals(expected))throw Error('Mismatch');console.log(c.createHash('sha256').update(actual).digest('hex'));"
sha=subprocess.check_output(['node','-e',js,str(base),out,rom],pass_fds=fds,text=True).strip();assert json.loads((W/f'batch-{mode}-passed.json').read_text())['rom_sha256']==sha
patch=Path(out).read_bytes();name='Mr_Burns_Mr_Bean_DE_PAL10_'+('DEBUG_'if mode=='debug'else'')+'Tempel_Puffer_V88.bps';proof=dict(mode=mode,file=name,rom_sha256=sha,patch_sha256=hashlib.sha256(patch).hexdigest(),source_md5='e040de91a74b61e3201db0e2323f768a',byte_identical_after_independent_apply=True,patch_bytes=len(patch),rom_bytes=Path(rom).stat().st_size);(W/f'patch-{mode}-verification.json').write_text(json.dumps(proof,indent=2));files={name:patch};prefix=''
if mode=='normal':
 guide=(W/'README-release.txt').read_text();files['V88_Tempel_Puffer_Hinweise.txt']=guide.encode()
 for n in json.loads((W/'spirit-export-manifest.json').read_text())['files']:
  files[n]=(W/'dialogue'/n).read_bytes()
 for k,label in [('child','Game_Boy_Color'),('adultbefore','Game_Boy_Advance')]:
  files[label+'_Tunnel_V88.png']=(W/('handheld-proof-normal-'+k+'.png')).read_bytes()
 rels=set()
 for origin in [Path('/workspace/title-collapse-v84/original'),Path('/workspace/player-music-v85/original'),Path('/workspace/room-audio-v86/original'),Path('/workspace/pause-floor-v87/original'),W/'original']:
  rels.update(str(p.relative_to(origin))for p in origin.rglob('*')if p.is_file())
 rels.update(['assets/audio/soundfonts/Soundfont_40.xml','assets/audio/sequences/seq_112.seq','assets/audio/sequences/seq_113.seq','include/fast_run_v66.h','include/object_room_budget_v86.h','tools/build_object_room_budget_v86.py'])
 rels.update(str(p.relative_to(O))for p in(O/'assets/audio/samples/SampleBank_0').glob('MalonV84_*.aifc'))
 manifest={rel:hashlib.sha256((O/rel).read_bytes()).hexdigest()for rel in sorted(rels)};(W/'source-manifest.json').write_text(json.dumps(manifest,indent=2))
 checks=dict(native_ram_bytes=4194304,normal_cases=json.loads((W/'batch-normal-passed.json').read_text()),debug_cases=json.loads((W/'batch-debug-passed.json').read_text()),changes=json.loads((W/'changes.json').read_text()),dependency_audit=json.loads((W/'dependency-audit.json').read_text()),kokiri_removals=json.loads((W/'kokiri-removals.json').read_text()),pieps_age=json.loads((W/'pieps-age.json').read_text()),handheld_placement=json.loads((W/'handheld-placement.json').read_text()),full_start_to_finish_playthrough=False,gameplay_code_changes=True,gameplay_code_change_scope="Pieps age guards only")
 (W/'verification-summary.json').write_text(json.dumps(checks,indent=2))
 apply='''from pathlib import Path
import sys,shutil,json,hashlib
root=Path(__file__).resolve().parent;target=Path(sys.argv[1]).resolve()
assert (target/'Makefile').is_file(),target
manifest=json.loads((root/'source-manifest.json').read_text())
for rel,expected in manifest.items():
 p=root/'production'/rel
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected,rel
for rel in manifest:
 p=root/'production'/rel;q=target/rel;q.parent.mkdir(parents=True,exist_ok=True)
 if q.is_symlink():q.unlink()
 shutil.copyfile(p,q)
print('V88 production sources and native music assets installed. Build PAL1.0 with the existing toolchain.')
'''
 buf=io.BytesIO()
 with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  z.writestr('LIESMICH_V88.txt',guide);z.writestr('apply_sources_v88.py',apply);z.writestr('source-manifest.json',json.dumps(manifest,indent=2));z.writestr('V88_Pruefungen.json',json.dumps(checks,indent=2))
  for rel in sorted(rels):z.write(O/rel,'production/'+rel)
  for p in W.iterdir():
   if p.is_file()and p.suffix in('.py','.c','.json','.log')and p.stat().st_size<1500000 and not any(x in p.name for x in ['stress','build-owner','objects-','qa-normal-','qa-debug-']):z.write(p,'verification/'+p.name)
 files['Merzen_Tempel_Puffer_V88_Quellen_Update.zip']=buf.getvalue()
 with zipfile.ZipFile(io.BytesIO(files['Merzen_Tempel_Puffer_V88_Quellen_Update.zip']))as z:
  for rel,h in manifest.items():assert hashlib.sha256(z.read('production/'+rel)).hexdigest()==h
 prefix='''## V88 — Tempel entlastet, Kokiri-Gegner reduziert und Handhelds versetzt

Feuertempel: ein Rollfels im Felslabyrinth und beide Raubschleime entfernt. Schattentempel: eine große Skulltula und zehn Auslöser automatischer Wandtexte entfernt. Pfade, übrige Gegner, Fallbeile und Rätselmechaniken bleiben erhalten. Bodenplatten-Kämpfe/Raumfreigaben, Vogelstatue, frühere Textstellen und Inventar-Rückkehr in Normal/DEBUG mit 4 MiB geprüft. Kokiri-Wald: alle drei feindlichen adulten Deku-Spucker und fünf Pflanzen altersabhängig entfernt. GBC/GBA auf die geladene Seite des Tunnels versetzt; Vorwärtsweg mit normaler Kamera, Inventar-Rückkehr und erneutes Betreten als Kind und Erwachsener geprüft. Pieps erscheint ausschließlich als Kind. Kumulativ einschließlich V87.

- [DEBUG-BPS-Patch](Mr_Burns_Mr_Bean_DE_PAL10_DEBUG_Tempel_Puffer_V88.bps)
- [Normaler BPS-Patch](Mr_Burns_Mr_Bean_DE_PAL10_Tempel_Puffer_V88.bps)
- [Dialoge: Schattentempel-Abschluß bis Geistertempel](Dialogliste_Schattentempelabschluss_bis_Geistertempel_V88.md)
- [Hinweise und Prüfumfang](V88_Tempel_Puffer_Hinweise.txt)
- [Quellen-Update](Merzen_Tempel_Puffer_V88_Quellen_Update.zip)

Auf saubere PAL-1.0-ROM anwenden. Nach ROM-Wechsel regulären Spielstand statt altem Emulator-Savestate laden. Kein vollständiger Spieldurchlauf als getestet behauptet.

---

'''
if mode=='debug':
 summary=json.loads((W/'verification-summary.json').read_text());summary['debug_cases']=json.loads((W/'batch-debug-passed.json').read_text());summary['patch_verification']={m:json.loads((W/f'patch-{m}-verification.json').read_text())for m in ['normal','debug']}
 (W/'verification-final.json').write_text(json.dumps(summary,indent=2));files['V88_Pruefungen.json']=json.dumps(summary,indent=2).encode()
import publish_ram_artifacts as pub
report=pub.publish(files,'V88 cumulative '+mode+' patch: reduce Fire/Shadow/Kokiri enemies and relocate handhelds into the loaded tunnel',prefix);(W/f'public-{mode}.json').write_text(json.dumps(report,indent=2));print('PATCH_PUBLIC',mode,report,flush=True)

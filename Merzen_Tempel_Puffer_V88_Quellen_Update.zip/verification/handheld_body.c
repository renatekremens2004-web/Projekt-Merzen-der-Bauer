static void capture_render(void){}
static unsigned countid(unsigned id){unsigned n=0;for(int c=0;c<12;c++)for(unsigned a=r32(play+0x1c34+c*8),i=0;a>=0x80000000&&a<0x80400000&&i<180;a=r32(a+0x124),i++)if(DebugMemRead16(a)==id&&r32(a+0x130))n++;return n;}
static void onframe(unsigned f){
 static unsigned first=0,paused=0,closed=0,pmark=0,checked=0,returned=0,reentered=0;unsigned v=0;
 int child=strstr(scenario,"-child-")!=NULL,post=strstr(scenario,"-adultafter-")!=NULL;
 baseframe(f);if(f<350)return;findplay();if(!play||!player)return;
 need(DebugMemRead16(play+0xa4)==0x55,"test remains in Kokiri Forest");
 unsigned room=DebugMemRead8(play+0x11cbc),g=target(0x173,0x3f9f),st=DebugMemRead16(play+0x10934);
 if(f==365){need(room==0,"start in actual forest room");need(!countid(0x60),"no hostile Deku Scrubs in adult forest");if(!child&&!post)need(countid(0x55)==3,"three remaining adult forest plants load");bank();}
 // Follow the corridor forward; retain the ordinary gameplay camera throughout.
 if(f>=380&&f<460)position(player,2160,0,150.0f-(f-380)*5.0f,-32768);
 if(f>=460&&f<500)position(player,2160,0,-240,-32768);
 if(f>=520&&f<640)v=0x20;
 if(room==1&&g&&!first)first=f;
 if(f==650){
  need(first&&room==1&&g&&r32(g+0x134),"handheld draws after forward native room transition");
  need(DebugMemRead16(g+0x10e)==(child?0x71ea:0x71eb),"age-correct handheld text");
  need(fabsf(rf(g+0x24)-2185)<.1&&fabsf(rf(g+0x2c)+300)<.1,"handheld lies on loaded side of tunnel");
  if(child)need(countid(0xc7)==3,"three remaining child corridor plants load");else if(!post)need(countid(0x55)==4,"four remaining adult corridor plants load");
  need(rf(player+0x28)>-10&&rf(player+0x28)<10,"handheld location has native floor at its height");checked=1;bank();CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);
 }
 if(f==700){v=0x10;pmark=f;}
 if(st==6&&!paused){paused=1;pmark=f;unsigned name=r32(play+0x10898);need((((name+3584+15)&~15)+7168)<=r32(play+0x117a8),"pause scratch stays inside reserved bank");}
 if(paused&&!closed&&st==6&&f>pmark+40)v=0x10;
 if(paused&&st==0&&!closed)closed=f;
 if(f>=900&&f<980)position(player,2160,0,-240+(f-900)*5.0f,0);
 if(f==1090){need(room==0,"returned to forest through native room boundary");returned=1;bank();}
 if(f>=1120&&f<1200)position(player,2160,0,150-(f-1120)*5.0f,-32768);
 if(f>=1200&&f<1240)position(player,2160,0,-240,-32768);
 if(f>=1260&&f<1380)v=0x20;
 if(f==1400){need(room==1&&g&&r32(g+0x134),"handheld reloads on repeat corridor entry");reentered=1;bank();CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
 if(f%30==0){bank();printf("HANDHELD_ENTRY f=%u room=%u prev=%d g=%x plants=%u/%u scrubs=%u xyz=%.1f %.1f %.1f pause=%u\n",f,room,(signed char)DebugMemRead8(play+0x11cd0),g,countid(0x55),countid(0xc7),countid(0x60),rf(player+0x24),rf(player+0x28),rf(player+0x2c),st);}
 if(f>1450){bank();need(checked&&closed&&returned&&reentered,"forward entry, inventory roundtrip and repeat entry complete");need(rf(player+0x28)>-10,"floor retained after inventory and repeated room entry");puts("HANDHELD_ROOM_ENTRY_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}
 if(buttons)buttons(v);
}

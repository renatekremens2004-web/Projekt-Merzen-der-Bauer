from pathlib import Path
import os,sys,json,re,subprocess,struct,concurrent.futures,hashlib,runpy
W=Path(__file__).resolve().parent;O=Path('/workspace/oot-burns-pal');rom=sys.argv[1];mode=sys.argv[2];fd=int(rom.rsplit('/',1)[1]);case=os.environ.get('V88_CASE')or(W/'qa-case.txt').read_text().strip();sy=json.loads((W/f'all-symbols-{mode}.json').read_text())
if case=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit(0)
if case.startswith('pieps-') and case!='pieps-bosses':
 subprocess.run([sys.executable,str(W/'pieps_age_qa.py'),rom,mode,case.removeprefix('pieps-')],pass_fds=(fd,),check=True);sys.exit(0)
if case.startswith('handheld-'):
 subprocess.run([sys.executable,str(W/'handheld_qa.py'),rom,mode,case.removeprefix('handheld-')],pass_fds=(fd,),check=True);sys.exit(0)
if case=='finalize':
 cases=['fire-5','fire-18','fire-19','shadow-0','shadow-2','shadow-8','handheld-child','handheld-adultbefore','handheld-adultafter','pieps-cage-child','pieps-cage-adult','pieps-boss-child','pieps-boss-adult','pieps-cleared-adult']
 for c in cases:assert ('HANDHELD_ROOM_ENTRY_PASSED' if c.startswith('handheld-') else 'PIEPS_AGE_PASSED' if c.startswith('pieps-') else 'DUNGEON_PROBE_PASSED')in(W/f'{mode}-{c}.log').read_text(),c
 (W/f'batch-{mode}-passed.json').write_text(json.dumps(dict(cases=cases,rom_sha256=hashlib.sha256(Path(rom).read_bytes()).hexdigest())));sys.exit(0)
if case in ('batch','pieps-bosses'):
 cases=['fire-5','fire-18','fire-19','shadow-0','shadow-2','shadow-8','handheld-child','handheld-adultbefore','handheld-adultafter','pieps-cage-child','pieps-cage-adult','pieps-boss-child','pieps-boss-adult','pieps-cleared-adult']
 if case=='pieps-bosses':cases=['pieps-boss-child','pieps-boss-adult']
 def one(c):subprocess.run([sys.executable,__file__,rom,mode],pass_fds=(fd,),env=dict(os.environ,V88_CASE=c),check=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(one,cases))
 if case=='batch':(W/f'batch-{mode}-passed.json').write_text(json.dumps(dict(cases=cases,rom_sha256=hashlib.sha256(Path(rom).read_bytes()).hexdigest())))
 sys.exit(0)
base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text();old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text())
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a);room=int(case.split('-')[1]);body=(W/'probe_body.c').read_text().replace('EXPECTED_ROOM',str(room));runner=W/f'probe-{mode}-{case}';c=runner.with_suffix('.c');c.write_text(base[:a]+body+base[b:]);subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(runner),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
fire=case.startswith('fire');scene=4 if fire else 7;entr=(O/'include/tables/entrance_table.h').read_text();en='ENTR_FIRE_TEMPLE_0'if fire else'ENTR_SHADOW_TEMPLE_0';e=int(re.search(r'/\* 0x([0-9A-F]+) \*/ DEFINE_ENTRANCE\('+en+r',',entr)[1],16)
xyz={('fire',5):(2449,2940,-346),('fire',18):(340,0,-1500),('fire',19):(880,240,-1750),('shadow',0):(-792,-63,85),('shadow',2):(780,-63,55),('shadow',8):(4591,-480,59)}[(case.split('-')[0],room)]
q=bytearray(Path('/workspace/zoras-erwachsen/boots-land.save').read_bytes());struct.pack_into('>III',q,0,e,0,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,*xyz,0,0xdff,e,room);q[0x1409]=1;q[0xd4+scene*0x1c:0xd4+(scene+1)*0x1c]=bytes(0x1c);struct.pack_into('>HH',q,0x2e,0x140,0x140);eq=struct.unpack_from('>H',q,0x70)[0];struct.pack_into('>H',q,0x70,(eq&0x00ff)|0x1200);fixture=W/(case+'.save');fixture.write_bytes(q);log=W/f'{mode}-{case}.log'
with log.open('w')as f:r=subprocess.run([str(runner),rom,'v88-'+mode+'-'+case+'-direct','2200','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(fixture)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH='/dev/null'),stdout=f,stderr=subprocess.STDOUT,timeout=240)
assert r.returncode==0,(r.returncode,log.read_text()[-2100:]);print('DUNGEON_CASE_PASSED',mode,case,flush=True)

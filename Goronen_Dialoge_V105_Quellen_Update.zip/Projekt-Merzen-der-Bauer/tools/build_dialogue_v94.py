"""Reapply the reviewed German V94 dialogue last, without restoring old snapshots."""
from pathlib import Path
import sys,json
from build_story import messages
R=Path(__file__).resolve().parents[1];O=Path(sys.argv[1]).resolve();path=O/'extracted/pal-1.0/text/message_data.h';source=path.read_text();bodies=json.loads((R/'tools/dialogue_v94_bodies.json').read_text())
for ident in ['723D','723E','723F']:
 if ident not in messages(source):
  a=source.index('DEFINE_MESSAGE(0x6007,');b=source.index('\nDEFINE_MESSAGE(',a+1);block=source[a:b].replace('DEFINE_MESSAGE(0x6007,','DEFINE_MESSAGE(0x'+ident+',',1);source=source[:b]+'\n'+block+'\n'+source[b:]
parsed=messages(source)
for ident in sorted(bodies,key=lambda x:parsed[x]['parts'][2][0],reverse=True):
 a,b,_=parsed[ident]['parts'][2];source=source[:a]+bodies[ident]+source[b:]
path.write_text(source)
p=O/'src/overlays/actors/ovl_En_Daiku/z_en_daiku.c';s=p.read_text()
if 'static u16 germanOpenings[]'not in s:
 old='if (this->actor.textId == 0x6007) {';assert old in s
 s=s.replace(old,'if (this->actor.textId == 0x6007 ||\n                    (gSaveContext.language == LANGUAGE_GER && this->actor.textId >= 0x723D && this->actor.textId <= 0x723F)) {',1)
 old='this->actor.textId = 0x6007;';assert old in s
 s=s.replace(old,'static u16 germanOpenings[] = { 0x6007, 0x723D, 0x723E, 0x723F };\n                    this->actor.textId = (gSaveContext.language == LANGUAGE_GER)\n                        ? germanOpenings[ENDAIKU_GET_TYPE(&this->actor)] : 0x6007;',1);p.write_text(s)
print('V94 German bodies applied; three private carpenter openings and native fight trigger retained.')

# Persist the requested German Kokiri tutorial removals and shop greeting scope.
for rel, replacements in json.loads((R/'tools/kokiri_v99_actor_patches.json').read_text()).items():
    p=O/rel;s=p.read_text()
    for before,after in replacements:
        if after in s:continue
        assert s.count(before)==1,(rel,'Kokiri patch anchor')
        s=s.replace(before,after,1)
    p.write_text(s)

p=O/'src/overlays/actors/ovl_En_Hy/z_en_hy.c';s=p.read_text()
before='? 0x7014 : 0x70A4)';after='? 0x7014 : (gSaveContext.language == LANGUAGE_GER ? 0x7014 : 0x70A4))'
if after not in s:
    assert s.count(before)==1
    s=s.replace(before,after,1);p.write_text(s)

# Persist German Pikachu mask pause label at the original IA4 slot.
label=R/'tools/pikachu_mask_label.png'
if label.exists():
    (O/'extracted/pal-1.0/assets/textures/item_name_static/gKeatonMaskItemNameGERTex.ia4.png').write_bytes(label.read_bytes())

# Persist reviewed V103 German owl conversation endings.
p=O/'src/overlays/actors/ovl_En_Owl/z_en_owl.c';s=p.read_text()
for name,before,after in json.loads((R/'tools/owl_v103_actor_patches.json').read_text()):
    signature = '(Actor* thisx, PlayState* play) {' if name == 'EnOwl_Init' else '(EnOwl* this, PlayState* play) {'
    a=s.index('void '+name+signature);b=s.index('\n}\n',a)+3;block=s[a:b]
    if after in block:continue
    assert block.count(before)==1,(name,'owl route anchor')
    s=s[:a]+block.replace(before,after,1)+s[b:]
p.write_text(s)

# Freigegebene Dialoge direkt einbauen

Ausdrückliche Nutzeranweisung vom 27. Oktober 2026: Wenn neue Texte festgelegt und freigegeben sind, sollen sie direkt eingebaut werden. Ein reines Quellenupdate oder eine Lesefassung reicht dafür nicht als Abschluss. Die freigegebenen Änderungen in den nächsten spielbaren kumulativen Normal-/DEBUG-Patch übernehmen, die betroffenen Abläufe prüfen und die Download-Dateien bereitstellen. Kein erneutes Nachfragen zur bereits erteilten Freigabe.

Wortlaut möglichst nah am Diktat halten. Nur Versprecher, Schreibweise, Grammatik und Seitenaufteilung bereinigen; keine zusätzlichen Gags, Vergleiche oder Pointen hinzufügen. Nicht genannte Dialoge erhalten. Notwendige Anschluss- und Auswahlsteuerung mitprüfen, damit gekürzte Gespräche enden und keine alten Textanhänge folgen.

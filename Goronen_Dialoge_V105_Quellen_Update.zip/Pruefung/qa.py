from pathlib import Path
import json,sys,re,struct,os,subprocess,runpy
W=Path(__file__).resolve().parent;rom,mode=sys.argv[1:3];fd=int(rom.rsplit('/',1)[1])
if(W/'qa-case.txt').exists()and(W/'qa-case.txt').read_text().strip()=='publish':runpy.run_path(str(W/'deliver.py'),run_name='__main__');sys.exit()
sy=json.loads((W/f'all-symbols-{mode}.json').read_text());old=json.loads(Path('/workspace/yellow-poe-v70/symbols-normal.json').read_text());base=Path('/workspace/yellow-poe-v70/runner-normal.c').read_text()
for n in ['gGameStateOverlayTable','gObjectTable','gObjectBankDeniedV68','gActorOverlayDeniedV68','gActorInstanceDeniedV68']:base=base.replace(hex(old[n]),hex(sy[n]))
base=base.replace('/workspace/bean-rider/config-%s','/tmp/config-%s').replace('/workspace/bean-rider/screens-%s','/tmp/screens-%s').replace('obj<=0x1af','obj<=0x1b0');a=base.index('static void capture_render(void){}');b=base.index('static void setting(',a)
body=r'''
static void capture_render(void){}
static unsigned seen=0,follow=0,lastid=0,closed=0;
static void onframe(unsigned f){
 baseframe(f);if(f<380)return;findplay();if(!play||!player)return;
 if(NPC==0x13d&&f==400)DebugMemWrite32(play+0x1d28,r32(play+0x1d28)|0x40);
 unsigned g=actor(NPC),m=play+0x20d8,id=DebugMemRead16(m+0xe2f8),mode=DebugMemRead8(m+0xe304);
 if(g&&!seen&&f>=400){photo(rf(g+0x24)+120,rf(g+0x28)+160,rf(g+0x2c)+220,rf(g+0x24),rf(g+0x28)+65,rf(g+0x2c));float ang=(int16_t)DebugMemRead16(g+0xb6)*3.14159265f/32768.0f;position(player,rf(g+0x24)+sinf(ang)*DIST,rf(g+0x28),rf(g+0x2c)+cosf(ang)*DIST,(int16_t)DebugMemRead16(g+0xb6)+32768);}
 if(mode&&id!=lastid){printf("GORON_TEXT f=%u id=%04X len=%u\n",f,id,r32(m+0xe300));lastid=id;}
 if(id==FIRST&&mode)seen=1;if(id==NEXT&&mode)follow=1;
 need(r32(m+0xe300)<1280,"whole message fits native buffer");need(DebugMemRead16(m+0xe3d4)<=200,"decoded page fits native buffer");
 if(f%300==0)printf("GORON_STATE f=%u actor=%x id=%x mode=%x seen=%u follow=%u\n",f,g,id,mode,seen,follow);
 if(seen&&follow&&!mode){if(!closed)closed=f;if(f>closed+20){bank();puts("GORON_NATIVE_PASSED");CoreDoCommand(M64CMD_STOP,0,NULL);}}
 if(buttons)buttons((f>440&&f%12<2&&(mode==0||mode==6||mode==7||mode==0x34||mode==0x35))?0x80:0);
 if(f==650)bank();need(f<3000,"Goron linked dialogue completes");
}
'''
cases=[('darunia',0x98,1,0x301a,0x301b,65),('medigoron',0x13d,2,0x304a,0x304b,170)]
for case,npc,room,first,nxt,dist in cases:
 logpath=W/f'qa-{mode}-{case}.log'
 if logpath.exists()and'GORON_NATIVE_PASSED'in logpath.read_text():continue
 text=body
 for k,v in [('FIRST',first),('NEXT',nxt),('NPC',npc),('DIST',dist)]:text=text.replace(k,str(v))
 c=W/f'probe-{mode}-{case}.c';c.write_text(base[:a]+text+base[b:]);exe=W/f'probe-{mode}-{case}';subprocess.run(['gcc','-O2','-I/workspace/toolchain/root/usr/include/mupen64plus',str(c),'-o',str(exe),'-L/workspace/toolchain/root/usr/lib/x86_64-linux-gnu','-l:libmupen64plus.so.2','-ldl','-lm'],check=True)
 q=bytearray(Path('/workspace/kokiri-speed-v66/child.save').read_bytes());struct.pack_into('>III',q,0,0x14d,1,0);q[0xed4:0xf34]=bytes(0x60);struct.pack_into('>II',q,0xa0,0,0);struct.pack_into('>H',q,0xc,0x8000);struct.pack_into('>I',q,0x10,0);struct.pack_into('>i',q,0x1364,1);struct.pack_into('>fffhHhB',q,0x1368,91 if room==1 else -951,41 if room==1 else 400,-1380 if room==1 else 1400,0,0xdff,0x14d,room);q[0x1409]=1;save=W/f'{case}.save';save.write_bytes(q)
 with logpath.open('w')as log:r=subprocess.run([str(exe),rom,f'goron-v105-direct-{mode}-{case}','3200','4',hex(sy['gSaveContext']),hex(sy['gActorOverlayTable']),str(save)],pass_fds=(fd,),env=dict(os.environ,DISPLAY=':99',CREDITS_AUDIO_PATH=str(W/f'{mode}-{case}.pcm')),stdout=log,stderr=subprocess.STDOUT,timeout=400)
 log=logpath.read_text();assert r.returncode==0 and'GORON_NATIVE_PASSED'in log,(case,r.returncode,log[-2300:]);print('NATIVE_GORON_PASS',mode,case,flush=True)

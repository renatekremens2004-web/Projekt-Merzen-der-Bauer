from pathlib import Path
import subprocess,json,sys,os
W=Path('/workspace/zoras');R=Path('/workspace/bean-rider/fixtures');fixture,case,frames=sys.argv[1:4];mp=R/(fixture+'.symbols.json');d=json.loads((mp if mp.exists() else W/'production-symbols.json').read_text());env=dict(os.environ,DISPLAY=':99')
with (W/(case+'.log')).open('w') as out:
 subprocess.run([str(W/'runner'),str(R/(fixture+'.z64')),case,frames,'4',hex(d['gSaveContext']),hex(d['gActorOverlayTable'])],env=env,stdout=out,stderr=subprocess.STDOUT,check=True)
print('Completed',case)

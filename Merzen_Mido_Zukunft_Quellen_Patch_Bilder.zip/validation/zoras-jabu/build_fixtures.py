from pathlib import Path
import subprocess,os,shutil,sys,re,json
O=Path('/workspace/oot-burns-pal');R=Path('/workspace/bean-rider/fixtures');opening=O/'src/overlays/gamestates/ovl_opening/z_opening.c';base=subprocess.check_output(['git','-C',str(O),'show','HEAD:src/overlays/gamestates/ovl_opening/z_opening.c'],text=True);play=O/'src/code/z_play.c';play_base=play.read_text()
variants={'king-pre':'ENTR_ZORAS_DOMAIN_1','king-post':'ENTR_ZORAS_DOMAIN_1','beans':'ENTR_ZORAS_RIVER_0','navi-letter':'ENTR_HYRULE_FIELD_0','navi-after':'ENTR_ZORAS_FOUNTAIN_0','barinade':'ENTR_JABU_JABU_BOSS_0','map-jabu':'ENTR_JABU_JABU_0','map-deku':'ENTR_DEKU_TREE_0'}
env=dict(os.environ);cmd=['make','VERSION=pal-1.0','COMPARE=0','N_THREADS=4','VENV=/workspace/toolchain/venv','-j4']
try:
 for name,entrance in variants.items():
  if len(sys.argv)>1 and name not in sys.argv[1:]:continue
  s=base.replace('#include "gfx.h"','#include "gfx.h"\n#include "item.h"\n#include "scene.h"\n#include "message.h"');a=s.index('{',s.index('void TitleSetup_SetupTitleScreen('));end=s.index('\n}',a)
  body=f'''
    gSaveContext.gameMode = GAMEMODE_NORMAL;
    this->state.running = false;
    gSaveContext.fileNum = 0;
    gSaveContext.save.linkAge = LINK_AGE_CHILD;
    Sram_InitNewSave();
    gSaveContext.language = LANGUAGE_GER;
    gSaveContext.save.entranceIndex = {entrance};
    gSaveContext.save.cutsceneIndex = CS_INDEX_NONE;
    gSaveContext.sceneLayer = 0;
    gSaveContext.save.dayTime = CLOCK_TIME(12,30);
    gSaveContext.save.info.playerData.playerName[0] = FILENAME_UPPERCASE('L');
    gSaveContext.save.info.playerData.playerName[1] = FILENAME_UPPERCASE('U');
    gSaveContext.save.info.playerData.playerName[2] = FILENAME_UPPERCASE('K');
    gSaveContext.save.info.playerData.playerName[3] = FILENAME_UPPERCASE('A');
    gSaveContext.save.info.playerData.playerName[4] = FILENAME_UPPERCASE('S');
    gSaveContext.save.info.inventory.items[SLOT_OCARINA] = ITEM_OCARINA_FAIRY;
    gSaveContext.save.info.inventory.items[SLOT_BOOMERANG] = ITEM_BOOMERANG;
    gSaveContext.save.info.inventory.questItems |= (1 << QUEST_KOKIRI_EMERALD);
    gSaveContext.save.info.playerData.rupees = 99;
    {'SET_EVENTCHKINF(EVENTCHKINF_GAVE_LETTER_TO_KING_ZORA); SET_EVENTCHKINF(EVENTCHKINF_37); gSaveContext.save.info.inventory.questItems |= (1 << QUEST_ZORA_SAPPHIRE);' if name=='king-post' else ''}
    {'SET_EVENTCHKINF(EVENTCHKINF_05); SET_EVENTCHKINF(EVENTCHKINF_09); SET_EVENTCHKINF(EVENTCHKINF_RECEIVED_WEIRD_EGG); SET_EVENTCHKINF(EVENTCHKINF_TALON_RETURNED_FROM_CASTLE); SET_EVENTCHKINF(EVENTCHKINF_OBTAINED_ZELDAS_LETTER); gSaveContext.save.info.inventory.questItems |= (1 << QUEST_SONG_SARIA); gSaveContext.save.info.inventory.upgrades |= (1 << 6); SET_EVENTCHKINF(EVENTCHKINF_25); gSaveContext.save.info.inventory.questItems |= (1 << QUEST_GORON_RUBY); gSaveContext.save.info.playerData.naviTimer = 650;' if name.startswith('navi-') else ''}
    {'gSaveContext.save.info.inventory.items[SLOT_BOTTLE_1] = ITEM_BOTTLE_RUTOS_LETTER;' if name=='navi-letter' else ''}
    {'SET_EVENTCHKINF(EVENTCHKINF_37); gSaveContext.save.info.inventory.questItems |= (1 << QUEST_ZORA_SAPPHIRE);' if name=='navi-after' else ''}
    SET_NEXT_GAMESTATE(&this->state, Play_Init, PlayState);'''
  opening.write_text(s[:a+1]+body+s[end:]);p=play_base
  if name.startswith('map-'):
   marker='    D_8012D1F8 = &this->state.input[0];';assert p.count(marker)==1
   p=p.replace(marker,'''    if (this->gameplayFrames == 120 && this->msgCtx.msgLength == 0) {
        Message_StartTextbox(this, 0x0066, NULL);
    }
'''+marker)
  play.write_text(p)
  with (R/('build-'+name+'.log')).open('w') as log:subprocess.run(cmd,cwd=O,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();symbols={k:int(re.search(r'0x([0-9a-f]+)\s+'+k+r'\s*$',mp,re.M)[1],16) for k in ['gSaveContext','gActorOverlayTable']}
  (R/(name+'.symbols.json')).write_text(json.dumps(symbols))
  shutil.copyfile(O/'build/pal-1.0/oot-pal-1.0.z64',R/(name+'.z64'));print('Built',name,flush=True)
finally:
 opening.write_text(base);play.write_text(play_base)
 with (R/'build-normal.log').open('w') as log:subprocess.run(cmd,cwd=O,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Production opening and Play_Main restored.',flush=True)

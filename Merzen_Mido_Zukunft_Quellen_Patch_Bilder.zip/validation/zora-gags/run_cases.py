from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import subprocess,sys
W=Path('/workspace/zora-gags');jobs=[('zora-gag-mido-focus-direct-clip-on','mido',1000),('zora-gag-music-focus-direct-clip-on','music',1000),('zora-gag-music-english-focus-direct-clip-on','english',1000)]
def run(j):subprocess.run([sys.executable,str(W/'run.py'),*map(str,j)],check=True)
with ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(run,jobs))

from pathlib import Path
import json,re,struct,math
W=Path('/workspace/zora-gags');O=Path('/workspace/oot-burns-pal');s=Path('/workspace/transition/runner.c').read_text();marker='  if(f==300 && strstr(scenario,"navi"))'
block='''  if(strstr(scenario,"zora-gag")){
   int wanted=strstr(scenario,"mido")?0:1;uint32_t npc=0;
   for(int cat=0;cat<12;cat++)for(uint32_t a=r32(play+0x1c34+cat*8),n=0;a>=0x80000000 && a<0x80400000 && n<100;a=r32(a+0x124),n++)if(DebugMemRead16(a)==0x1ce && (DebugMemRead16(a+0x1c)&63)==wanted && r32(a+0x130))npc=a;
   if(f==200 && npc){int facing=DebugMemRead16(npc+0xb6);position(player,rf(npc+0x24)+sinf(facing*3.14159265f/32768)*70,rf(npc+0x28),rf(npc+0x2c)+cosf(facing*3.14159265f/32768)*70,facing+0x8000);}
   if(f%100==0)printf("ZORA_GAG f=%u actor=%08x type=%d pos=(%.1f %.1f %.1f) text=%04x lang=%u sapphire=%x\\n",f,npc,wanted,npc?rf(npc+0x24):0,npc?rf(npc+0x28):0,npc?rf(npc+0x2c):0,npc?DebugMemRead16(npc+0x10e):0,DebugMemRead8(savebase+0x1409),r32(savebase+0xa4)&0x100000);
  }
''';s=s.replace(marker,block+marker);(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
for name,pos,yaw,lang in [('mido',(-787.,14.,-416.),32586,1),('music',(772.,24.,52.),18386,1),('english',(772.,24.,52.),18386,0)]:
 b=bytearray(Path('/workspace/transition/market-post.save').read_bytes());struct.pack_into('>I',b,0,0x108);struct.pack_into('>I',b,4,1);struct.pack_into('>I',b,8,0);b[0x1409]=lang;struct.pack_into('>I',b,0x1360,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,0x108,1);struct.pack_into('>H',b,0x1412,0xffef);b[0x1414]=0;(W/(name+'.save')).write_bytes(b)
print(syms)

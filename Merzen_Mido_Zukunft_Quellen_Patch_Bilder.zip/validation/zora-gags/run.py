from pathlib import Path
import subprocess,json,os,sys
W=Path('/workspace/zora-gags');s=json.loads((W/'symbols.json').read_text());case,snapshot,frames=sys.argv[1:4]
with (W/(case+'.log')).open('w') as out:
 p=subprocess.Popen([str(W/'runner'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,frames,'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(snapshot+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=out,stderr=subprocess.STDOUT)
 try:status=p.wait(timeout=600)
 except subprocess.TimeoutExpired:p.kill();p.wait();raise
 if status:raise SystemExit(status)
print('Completed',case)

from pathlib import Path
import sys,json
R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal');sys.path.insert(0,str(R/'tools'));import build_story as b
native=b.messages((R/'tools/originals/pal-1.0/extracted/pal-1.0/text/message_data.h').read_text());current=b.messages((O/'extracted/pal-1.0/text/message_data.h').read_text());report={}
for f in (R/'story').glob('*.json'):
 for ident,entry in json.loads(f.read_text())['messages'].items():
  old=native[entry.get('native_template',ident)]['parts'][2][2];new=current[ident]['parts'][2][2];assert b.controls(old)==b.controls(new),ident
  report[ident]={'template':entry.get('native_template',ident),'controls':b.controls(new),'pages':len(b.split_pages(new)[0])}
assert len(report)==584
assert report['700A']['controls']==['BOX_BREAK_DELAYED(60)','BOX_BREAK_DELAYED(90)','BOX_BREAK_DELAYED(80)','FADE(50)'],report['700A']
Path('/workspace/transition/control-checks.json').write_text(json.dumps(report,indent=2)+'\n');print('584 control sequences match native templates; 700A timing preserved')

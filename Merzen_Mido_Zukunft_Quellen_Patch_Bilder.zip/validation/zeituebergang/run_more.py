from concurrent.futures import ThreadPoolExecutor
import subprocess,sys
jobs=[('guard-joke-focus-final-direct-clip-on','guard',1300),('market-12-prox-focus-after-direct-clip-on','market-post',1800),('market-12-prox-focus-before-direct-clip-on','market-pre',1000),('market-7-focus-hero-direct-clip-on','market-post',1100),('market-4-focus-hair-direct-clip-on','market-post',1100)]
def run(j):subprocess.run([sys.executable,'/workspace/transition/run.py',*map(str,j)],check=True)
with ThreadPoolExecutor(max_workers=2) as ex:list(ex.map(run,jobs))

from pathlib import Path
import struct,json,re
W=Path('/workspace/transition');O=Path('/workspace/oot-burns-pal');b=bytearray(Path('/workspace/graphics-audit/beans.save').read_bytes())
def u32(s,o,x):struct.pack_into('>I',s,o,x)
def u16(s,o,x):struct.pack_into('>H',s,o,x)
def flag(s,x,on=True,base=0xed4):
 o=base+2*(x>>4);v=struct.unpack_from('>H',s,o)[0];u16(s,o,(v|(1<<(x&15))) if on else (v&~(1<<(x&15))))
def save(name,entrance,age=1,cs=0,post=False,ms=False,respawn=None,lang=1):
 s=bytearray(b);u32(s,0,entrance);u32(s,4,age);u32(s,8,cs);u32(s,0x1360,0);u32(s,0x1364,0);u16(s,0x1412,0xffef);s[0x1414]=0;s[0x1409]=lang;u16(s,0xc,0x8000);u16(s,0x30,0x30);u16(s,0x34,99);u32(s,0xa4,0x1c1000)
 for f in [0x09,0x25,0x37,0x40]:flag(s,f)
 flag(s,0x80,post);flag(s,0x45,ms);flag(s,0x1cf,False,0xef8);flag(s,0x6c,False,0xef8)
 if respawn:
  u32(s,0x1364,1);struct.pack_into('>fffhHhB',s,0x1368,*respawn,0xdff,entrance,0)
 if name=='sword':
  flag(s,0x4b);flag(s,0x4f);s[0x74+7]=8
 (W/(name+'.save')).write_bytes(s)
save('chase',0xcd,cs=0xfff1)
save('dying',0xad,post=True)
save('guard',0x7e,post=True)
save('market-pre',0xb1)
save('market-post',0xb1,post=True)
save('sword',0x53,post=True,respawn=(-1.,68.,50.,-32768))
save('navi-adult',0xcd,age=0,post=True,ms=True)
save('navi-child',0xcd,post=True)
save('navi-english',0xcd,age=0,post=True,ms=True,lang=0)
s=Path('/workspace/graphics-audit/runner.c').read_text()
s=s.replace('   if(strstr(scenario,"bowling"))npc=actor(0x14b);','''   if(strstr(scenario,"bowling"))npc=actor(0x14b);
   if(strstr(scenario,"dying") || strstr(scenario,"guard-joke"))npc=actor(0x178);''')
s=s.replace('if(strstr(scenario,"bowling"))distance=65;','if(strstr(scenario,"bowling") || strstr(scenario,"dying") || strstr(scenario,"guard-joke"))distance=65;')
s=s.replace('  if(strstr(scenario,"navi") && mode==0)value=0;','''  if(f%100==0)printf("PROGRESS f=%u fled=%x master=%x navi_seen=%x guard_dead=%x cs=%u\\n",f,DebugMemRead16(savebase+0xee4)&1,DebugMemRead16(savebase+0xedc)&0x20,DebugMemRead16(savebase+0xf30)&0x8000,DebugMemRead16(savebase+0xf04)&0x1000,DebugMemRead16(play+0x1d74));
  if(f==1400 && strstr(scenario,"navi-once"))DebugMemWrite16(savebase+0x38,650);
  if(strstr(scenario,"navi") && mode==0)value=0;''')
# Extra snapshots after the first ready frame, without changing production timing.
s=s.replace('  if(f%100==0){\n   printf("STATE', '''  if((mode==7 || mode==0x34 || mode==0x35) && age==14){printf("PHOTO f=%u id=%04x pos=%u\\n",f,id,pos);CoreDoCommand(M64CMD_TAKE_NEXT_SCREENSHOT,0,NULL);}
  if(f%100==0){
   printf("STATE''')
(W/'runner.c').write_text(s)
m=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();d={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',m,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};assert d['gGameStateOverlayTable']-d['gActorOverlayTable']==0x8e10;(W/'symbols.json').write_text(json.dumps(d));print(d)

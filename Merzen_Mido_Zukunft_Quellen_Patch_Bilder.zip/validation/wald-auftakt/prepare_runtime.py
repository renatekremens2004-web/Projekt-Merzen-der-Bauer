from pathlib import Path
import struct,re,json
W=Path('/workspace/forest-dialogue');O=Path('/workspace/oot-burns-pal')
s=Path('/workspace/okto-water/runner.c').read_text()
s=s.replace('   if(strstr(scenario,"mask"))npc=', '   if(strstr(scenario,"forest-kokiri"))npc=actor_type(0x163,4);\n   if(strstr(scenario,"forest-boris"))npc=actor(0x122);\n   if(strstr(scenario,"forest-shiek-repeat"))npc=actor(0x48);\n   if(strstr(scenario,"mask"))npc=')
s=s.replace('   if(npc){','   if(npc){')
s=s.replace('  if(strstr(scenario,"hostile")){static', '''  if(strstr(scenario,"forest-boris") && f%50==0){uint32_t b=actor(0x122);printf("BORIS f=%u actor=%08x action=%08x path=%d timer=%d timerstate=%u\\n",f,b,b?r32(b+0x180):0,b?(int16_t)DebugMemRead16(b+0x188):0,b?(int16_t)DebugMemRead16(b+0x186):0,DebugMemRead16(savebase+0x13ca));}
  if(strstr(scenario,"hostile")){static''')
(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
def flag(b,x,on):
 o=0xed4+2*(x>>4);v=struct.unpack_from('>H',b,o)[0];struct.pack_into('>H',b,o,(v|1<<(x&15)) if on else (v&~(1<<(x&15))))
for name,ent,med,cs,respawn in [('kokiri',0x433,False,0,(-30.,16.,165.,-32768)),('kokiri-after',0xee,True,0,(669.,0.,570.,-32768)),('boris',0x453,False,0,(-63.,-530.,-2010.,-32768)),('shiek',0x53,False,0,(-1.,68.,50.,-32768)),('shiek-repeat',0x53,False,0,(-1.,68.,50.,-32768))]:
 b=bytearray(Path('/workspace/transition/navi-adult.save').read_bytes())
 struct.pack_into('>III',b,0,ent,0,cs);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*respawn,0xdff,ent,0)
 struct.pack_into('>I',b,0xa4,(struct.unpack_from('>I',b,0xa4)[0]&~1)|(1 if med else 0));flag(b,0xc5,name=='shiek-repeat');flag(b,0x48,False);flag(b,0x50,False);flag(b,0x55,False)
 b[0x74+9]=0xff
 (W/(name+'.save')).write_bytes(b)

# Front of the native Kokiri in Mido's house; completed forest scene uses EVENTCHKINF_48 too.
b=bytearray((W/'kokiri.save').read_bytes());struct.pack_into('>fffh',b,0x1368,-60.,0.,88.,1000);(W/'house.save').write_bytes(b)
b=bytearray((W/'kokiri-after.save').read_bytes());flag(b,0x48,True);(W/'outside.save').write_bytes(b)

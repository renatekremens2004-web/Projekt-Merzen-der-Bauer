from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/forest-dialogue');s=json.loads((W/'symbols.json').read_text())
def run(topic):
 case='forest-'+topic+os.environ.get('FOREST_RUN','-v1')+('-focus-direct-clip-on' if topic=='kokiri-after' else '-direct-clip-on')
 limit=3000 if topic=='shiek' else 1800
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/('runner-v2' if os.environ.get('FOREST_RUN')=='-v2' else 'runner')),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(topic+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:] or ['boris','kokiri','kokiri-after','shiek','shiek-repeat']))

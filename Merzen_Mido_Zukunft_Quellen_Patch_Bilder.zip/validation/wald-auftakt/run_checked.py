from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/forest-dialogue');s=json.loads((W/'symbols.json').read_text())
cases={'boris':('runner-v2','boris',1800,False),'kokiri':('runner','house',1800,False),'kokiri-after':('runner','outside',1800,False),'shiek':('runner','shiek',3000,False),'shiek-repeat':('runner','shiek-repeat',1800,True)}
def run(topic):
 exe,save,limit,focus=cases[topic];case='forest-'+save+os.environ.get('FOREST_RUN','-checked')+('-focus-direct-clip-on' if focus else '-direct-clip-on')
 with (W/(case+'.log')).open('w') as log:subprocess.run([str(W/exe),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(limit),'4',hex(s['gSaveContext']),hex(s['gActorOverlayTable']),str(W/(save+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
# Scenario names retain the matching input and positioning logic from the recorded successful cases.
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:] or list(cases)))

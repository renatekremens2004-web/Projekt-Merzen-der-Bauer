from pathlib import Path
import re,json,struct,math
W=Path('/workspace/stadt-nachschlag');O=Path('/workspace/oot-burns-pal')
s=Path('/workspace/transition/runner.c').read_text()
marker='  if(f==300 && strstr(scenario,"navi"))'
block='''  if(f==450 && strstr(scenario,"stadt-")) {
   uint32_t npc=0;float distance=70;
   if(strstr(scenario,"market-"))npc=actor_type(0x16e,atoi(strstr(scenario,"market-")+7));
   if(strstr(scenario,"haggle")){npc=actor_type(0x1ad,0);distance=125;}
   if(npc){int facing=DebugMemRead16(npc+0xb6);position(player,rf(npc+0x24)+sinf(facing*3.14159265f/32768)*distance,rf(npc+0x28),rf(npc+0x2c)+cosf(facing*3.14159265f/32768)*distance,facing+0x8000);printf("NATIVE_NPC actor=%08x id=%x type=%x pos=(%.1f %.1f %.1f)\\n",npc,DebugMemRead16(npc),DebugMemRead16(npc+0x1c),rf(npc+0x24),rf(npc+0x28),rf(npc+0x2c));}
  }
'''
s=s.replace(marker,block+marker)
(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/'symbols.json').write_text(json.dumps(syms))
for name,typ,x,y,z,yaw,post,lang in [('woman',1,480,0,-202,-0x33e9,False,1),('woman-post',1,480,0,-202,-0x33e9,True,1),('woman-english',1,480,0,-202,-0x33e9,False,0),('jogger',3,289,0,488,0x4000,False,1),('beggar',5,-387,0,-228,0x4000,False,1),('haggle',0,250,2,400,0,False,1)]:
 b=bytearray(Path('/workspace/transition/market-pre.save').read_bytes());a=yaw*math.pi/32768;dist=125 if name=='haggle' else 70;struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,x+math.sin(a)*dist,y,z+math.cos(a)*dist,(yaw+32768+32768)%65536-32768,0xdff,0xb1,0);b[0x1409]=lang
 if post:struct.pack_into('>H',b,0xee4,struct.unpack_from('>H',b,0xee4)[0]|1)
 (W/(name+'.save')).write_bytes(b)

from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/stadt-nachschlag');syms=json.loads((W/'symbols.json').read_text())
jobs=[('stadt-woman-market-1-focus-direct-clip-on','woman',1300),('stadt-woman-post-market-1-focus-direct-clip-on','woman-post',1000),('stadt-jogger-market-3-focus-direct-clip-on','jogger',1100),('stadt-beggar-market-5-focus-direct-clip-on','beggar',1200),('stadt-haggle-focus-direct-clip-on','haggle',1700),('stadt-woman-english-market-1-focus-direct-clip-on','woman-english',1200)]
jobs.append(('stadt-beggar-fish-market-5-focus-direct-clip-on','beggar-fish',1200))
if len(sys.argv)>1:jobs=[j for j in jobs if any(x in j[0] for x in sys.argv[1:])]
def run(job):
 case,snapshot,frames=job
 with (W/(case+'.log')).open('w') as out:subprocess.run([str(W/'runner'),'/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64',case,str(frames),'4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/(snapshot+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,jobs))

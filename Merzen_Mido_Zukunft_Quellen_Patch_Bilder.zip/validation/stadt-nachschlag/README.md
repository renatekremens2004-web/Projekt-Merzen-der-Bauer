Sieben gezielte 4-MB-Szenarien, native NPCs/Kamera und Controller-Dialoge; keine vollständigen ROMs, Spielstände oder Emulator-Binaries enthalten. Einzelheiten: ../../TESTING_HYRULE_NPCS.md.

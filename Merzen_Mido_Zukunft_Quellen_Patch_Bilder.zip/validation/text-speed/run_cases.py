from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,os,sys
W=Path('/workspace/text-speed');jobs=[]
for revision in ['before','after']:
 for snapshot in ['mido','music','english']:
  jobs.append((revision,snapshot,1600,''))
 jobs.append((revision,'mido',1600,'-button-b'))

def run(job):
 revision,snapshot,frames,extra=job
 case=f'text-speed-{revision}-zora-gag-{snapshot}-measure{extra}-focus-direct-clip-on'
 syms=json.loads((W/(revision+'-symbols.json')).read_text())
 rom=W/'baseline.z64' if revision=='before' else Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64')
 with (W/(case+'.log')).open('w') as out:
  subprocess.run([str(W/'runner'),str(rom),case,str(frames),'4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/(snapshot+'.save'))],env=dict(os.environ,DISPLAY=':99'),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,jobs))

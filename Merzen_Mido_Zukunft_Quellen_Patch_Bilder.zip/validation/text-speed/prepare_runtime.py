from pathlib import Path
import json,re,struct
W=Path('/workspace/text-speed');O=Path('/workspace/oot-burns-pal')
s=Path('/workspace/zora-gags/runner.c').read_text()
s=s.replace('int wanted=strstr(scenario,"mido")?0:1;', 'int wanted=strstr(scenario,"choice")?3:(strstr(scenario,"mido")?0:1);')
# Per-frame observation; no writes to message state, contents or timing.
s=s.replace('  static unsigned key=0,age=0;', '''  if(mode)printf("REVEAL f=%u id=%04x mode=%x page=%u draw=%u length=%u timer=%u delay=%u choice=%u cs=%u\\n",f,id,mode,pos,DebugMemRead16(m+0xe3d2),DebugMemRead16(m+0xe3d4),DebugMemRead16(m+0xe3e8),DebugMemRead16(m+0xe3ea),DebugMemRead8(m+0xe3e5),DebugMemRead8(play+0x1d6c));
  static unsigned key=0,age=0;''')
needle=' if(buttons)buttons(value);'
s=s.replace(needle,''' if(play && strstr(scenario,"measure")) {
  uint32_t m=play+0x20d8;unsigned mode=DebugMemRead8(m+0xe304),id=DebugMemRead16(m+0xe2f8);
  static unsigned ready=0;static int spoke=0,finished=0,pressed_b=0;
  if(mode)spoke=1;
  if(mode) value=0x20;
  if(mode==7 || mode==0x35) {
   ready++;
   if(ready==80)value|=0x80;
   if(mode==0x35 && ready==80)finished=1;
  }else ready=0;
  if(strstr(scenario,"button-b") && mode==6 && DebugMemRead16(m+0xe3d2)>=10 && !pressed_b){value|=0x40;pressed_b=1;printf("B_PRESS f=%u id=%04x\\n",f,id);}
  if(spoke && finished && mode==0){printf("CONVERSATION_COMPLETE f=%u\\n",f);CoreDoCommand(M64CMD_STOP,0,NULL);}
 }
'''+needle)
(W/'runner.c').write_text(s)
for label,path in [('before',W/'baseline.map'),('after',O/'build/pal-1.0/oot-pal-1.0.map')]:
 mp=path.read_text();syms={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};(W/(label+'-symbols.json')).write_text(json.dumps(syms))
b=bytearray((W/'music.save').read_bytes());struct.pack_into('>I',b,0xa4,struct.unpack_from('>I',b,0xa4)[0]&~0x100000);struct.pack_into('>H',b,0xeda,struct.unpack_from('>H',b,0xeda)[0]|1);(W/'choice.save').write_bytes(b)

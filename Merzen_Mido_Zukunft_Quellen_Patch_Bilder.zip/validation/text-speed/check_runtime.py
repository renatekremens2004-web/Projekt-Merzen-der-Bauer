from pathlib import Path
import re,json
W=Path('/workspace/text-speed')
pattern=re.compile(r'REVEAL f=(\d+) id=([0-9a-f]+) mode=([0-9a-f]+) page=(\d+) draw=(\d+) length=(\d+) timer=(\d+) delay=(\d+) choice=(\d+) cs=(\d+)')
def trace(case):
 text=(W/(case+'.log')).read_text()
 assert 'completed: 0' in text,case
 assert not any(x in text for x in ['UNKNOWN GBI COMMAND','Using Vertex outside buffer','N64 CRASH']),case
 assert set(re.findall(r'RAM=(\d+)',text))=={'4194304'}
 return [tuple(int(x,16 if i in [1,2] else 10) for i,x in enumerate(m)) for m in pattern.findall(text)]
def ordinary(rev,snapshot,extra=''):
 return f'text-speed-{rev}-zora-gag-{snapshot}-measure{extra}-focus-direct-clip-on'
def pages(rows,ident):
 out={}
 for row in rows:
  f,id,mode,page,draw,length,*_=row
  if id!=ident:continue
  if mode==6:
   p=out.setdefault(page,{'start':f,'length':length,'draw_positions':[]});p['draw_positions'].append(draw)
  elif mode in [7,0x35] and page in out and 'ready' not in out[page]:out[page]['ready']=f
 return {k:{**v,'reveal_frames':v['ready']-v['start']} for k,v in out.items() if 'ready' in v}
report={'normal_dialogues':{},'controls':{}}
for snapshot,ident in [('mido',0x402d),('music',0x402e)]:
 before=pages(trace(ordinary('before',snapshot)),ident);after=pages(trace(ordinary('after',snapshot)),ident)
 assert before.keys()==after.keys() and before
 for p,a in before.items():
  b=after[p];assert a['length']==b['length'];assert .45 <= b['reveal_frames']/a['reveal_frames'] <= .65,(snapshot,a,b)
  assert max(y-x for x,y in zip(a['draw_positions'],a['draw_positions'][1:]))<=3
  assert 2 in {y-x for x,y in zip(b['draw_positions'],b['draw_positions'][1:])}
  # Controller waits 80 whole frames on a completed page; no early close.
  for rev,data in [('before',a),('after',b)]:
   rows=trace(ordinary(rev,snapshot));ready=[r[0] for r in rows if r[1]==ident and r[3]==p and r[2] in [7,0x35]]
   assert len(ready)>=80 and ready[-1]-ready[0]>=79
 report['normal_dialogues'][snapshot]={'before':before,'after':after}
# Foreign-language control uses exactly the same per-frame native state.
a=trace(ordinary('before','english'));b=trace(ordinary('after','english'));assert a==b
report['controls']['english_trace_identical_frames']=len(a)
# Native automatic cutscene message includes three delayed page breaks and fade.
a=[r for r in trace('text-speed-before-sword-timed-direct-clip-on') if r[1]==0x700a]
b=[r for r in trace('text-speed-after-sword-timed-direct-clip-on') if r[1]==0x700a]
assert a and a==b;assert len({r[3] for r in a})==5 # initial undecoded page plus four text pages
assert {r[2] for r in a}>={6,8,0x35};assert {r[9] for r in a}=={2}
report['controls']['merz_700a_timed_trace_identical_frames']=len(a)
# Ordinary shop question, native cursor/default selection, purchase follow-up.
a=trace('text-speed-before-beans-walk-focus-direct-clip-on');b=trace('text-speed-after-beans-walk-focus-direct-clip-on')
def question(rows):
 candidates=[r for r in rows if r[1]==0x405e and r[2]==0x35];assert candidates
 ready=candidates[0];page=ready[3]
 span=[r for r in rows if r[1]==0x405e and r[3]==page and r[2] in [6,0x35] and r[0]<=ready[0]]
 start=span[0][0]
 return [(r[0]-start,)+r[1:] for r in span]
qa=question(a);qb=question(b)
assert qa and qa==qb
assert all(r[8]==0 for r in qa)
assert any(r[1] in [0x0048] for r in a),sorted({hex(r[1]) for r in a})
report['controls']['bean_seller_choice_page_reveal_identical_relative_frames']=len(qa)
# B's native instant reveal/finish stays available; do not reinterpret the key.
for rev in ['before','after']:
 case=ordinary(rev,'mido','-button-b');rows=trace(case);s=(W/(case+'.log')).read_text();assert s.count('B_PRESS ')==1
 press=int(re.search(r'B_PRESS f=(\d+)',s)[1]);ready=min(r[0] for r in rows if r[0]>=press and r[2]==0x35)
 assert ready-press<=3
 report['controls']['b_'+rev]={'press_frame':press,'ready_frame':ready}
report['production_sha256']=json.loads((W/'patch-verification.json').read_text())['target_sha256']
report['note']='Same native 4-MB ROMs and controller traces, test SaveContext snapshots, Link positioned for conversations; no message state or timers written.'
(W/'runtime-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({**report,'normal_dialogues':{k:{rev:{str(p):{a:b for a,b in data.items() if a!='draw_positions'} for p,data in pages.items()} for rev,pages in v.items()} for k,v in report['normal_dialogues'].items()}},indent=2))

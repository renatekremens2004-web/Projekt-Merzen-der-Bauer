from pathlib import Path
import subprocess,json,os
from concurrent.futures import ThreadPoolExecutor
W=Path('/workspace/text-speed')
def run(rev):
 syms=json.loads((W/(rev+'-symbols.json')).read_text());case=f'text-speed-{rev}-sword-timed-direct-clip-on'
 rom=W/'baseline.z64' if rev=='before' else Path('/workspace/oot-burns-pal/build/pal-1.0/oot-pal-1.0-compressed.z64')
 with (W/(case+'.log')).open('w') as out:subprocess.run([str(W/'runner'),str(rom),case,'1600','4',hex(syms['gSaveContext']),hex(syms['gActorOverlayTable']),str(W/'sword.save')],env=dict(os.environ,DISPLAY=':99'),stdout=out,stderr=subprocess.STDOUT,check=True,timeout=600)
 print('Completed',case,flush=True)
with ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,['before','after']))

from pathlib import Path
import subprocess,sys
W=Path('/workspace/xwing')
jobs=[('toy-npc-release-before-focus-direct-clip-on','npc',1100),('toy-npc-release-after-focus-direct-clip-on','npc-after',1100),('toy-npc-release-english-focus-direct-clip-on','npc-english',1100)]
for j in jobs:subprocess.run([sys.executable,str(W/'run.py'),*map(str,j)],check=True)

from pathlib import Path
import struct,json,re
W=Path('/workspace/xwing');O=Path('/workspace/oot-burns-pal');s=Path('/workspace/n64-gag/runner.c').read_text()
s=s.replace('  if(f==300 && strstr(scenario,"navi"))', '''  if(strstr(scenario,"toy-view"))value=0;
  if(f%100==0 && strstr(scenario,"toy-npc")){uint32_t n=actor_type(0x16e,10);printf("TOY_NPC f=%u actor=%08x params=%x pos=(%.1f %.1f %.1f) text=%04x age=%u lang=%u shadow=%x\\n",f,n,n?DebugMemRead16(n+0x1c):0,n?rf(n+0x24):0,n?rf(n+0x28):0,n?rf(n+0x2c):0,n?DebugMemRead16(n+0x10e):0,r32(savebase+4),DebugMemRead8(savebase+0x1409),r32(savebase+0xa4)&0x10);}
  if(f==300 && strstr(scenario,"navi"))''')
(W/'runner.c').write_text(s)
mp=(O/'build/pal-1.0/oot-pal-1.0.map').read_text();d={n:int(re.search(r'0x([0-9a-f]+)\s+'+n+r'\s*$',mp,re.M)[1],16) for n in ['gSaveContext','gActorOverlayTable','gGameStateOverlayTable']};assert d['gGameStateOverlayTable']-d['gActorOverlayTable']==0x8e10;(W/'symbols.json').write_text(json.dumps(d))
base=Path('/workspace/transition/market-pre.save').read_bytes()
for name,entrance,age,lang,pos,yaw,shadow in [('temple',0x37,0,1,(-1650.,-63.,-130.),-32768,0),('temple-side',0x37,0,1,(-1700.,-63.,-380.),-8000,0),('temple-near',0x37,0,1,(-1780.,-63.,-360.),0,0),('npc',0xdb,0,1,(-926.,0.,610.),23000,0),('npc-after',0xdb,0,1,(-926.,0.,610.),23000,1),('npc-english',0xdb,0,0,(-926.,0.,610.),23000,0)]:
 b=bytearray(base);struct.pack_into('>I',b,0,entrance);struct.pack_into('>I',b,4,age);struct.pack_into('>I',b,8,0);struct.pack_into('>H',b,0xc,0x8000);b[0x1409]=lang
 struct.pack_into('>I',b,0x1360,0);struct.pack_into('>I',b,0x1364,1);struct.pack_into('>fffhHhB',b,0x1368,*pos,yaw,0xdff,entrance,0);struct.pack_into('>H',b,0x1412,0xffef);b[0x1414]=0
 struct.pack_into('>H',b,0x2e,48);struct.pack_into('>H',b,0x30,48)
 x=struct.unpack_from('>H',b,0xedc)[0];struct.pack_into('>H',b,0xedc,x|0x20)
 q=struct.unpack_from('>I',b,0xa4)[0];struct.pack_into('>I',b,0xa4,(q|0x10) if shadow else (q&~0x10))
 (W/(name+'.save')).write_bytes(b)
print(d)

from pathlib import Path
import subprocess,os,shutil,sys
O=Path('/workspace/oot-burns-pal');R=Path('/workspace/bean-rider/fixtures');p=O/'src/overlays/gamestates/ovl_opening/z_opening.c';base=subprocess.check_output(['git','-C',str(O),'show','HEAD:src/overlays/gamestates/ovl_opening/z_opening.c'],text=True)
variants={'squid':('ENTR_ZORAS_DOMAIN_0','CS_INDEX_NONE',True),'squid-repeat':('ENTR_ZORAS_DOMAIN_0','CS_INDEX_NONE',True),'squid-poor':('ENTR_ZORAS_DOMAIN_0','CS_INDEX_NONE',True)}
env=dict(os.environ,LD_LIBRARY_PATH='/workspace/toolchain/root/usr/lib/x86_64-linux-gnu');env['PATH']='/workspace/toolchain/bin:/workspace/toolchain/root/usr/bin:'+env['PATH'];cmd=['make','VERSION=pal-1.0','COMPARE=0','N_THREADS=4','VENV=/workspace/toolchain/venv','-j4']
try:
 for name,(entrance,cs,child) in variants.items():
  if len(sys.argv)>1 and name not in sys.argv[1:]:continue
  s=base.replace('#include "gfx.h"','#include "gfx.h"\n#include "item.h"\n#include "scene.h"\n#include "message.h"')
  a=s.index('{',s.index('void TitleSetup_SetupTitleScreen('));end=s.index('\n}',a)
  body=f'''
    gSaveContext.gameMode = GAMEMODE_NORMAL;
    this->state.running = false;
    gSaveContext.fileNum = 0;
    gSaveContext.save.linkAge = {'LINK_AGE_CHILD' if child else 'LINK_AGE_ADULT'};
    Sram_InitNewSave();
    gSaveContext.language = LANGUAGE_GER;
    gSaveContext.save.entranceIndex = {entrance};
    gSaveContext.save.cutsceneIndex = {cs};
    gSaveContext.sceneLayer = {('GET_CUTSCENE_LAYER('+cs+')') if cs!='CS_INDEX_NONE' else '0'};
    gSaveContext.save.dayTime = CLOCK_TIME({18 if name=='boris' else 12},30);
    gSaveContext.save.info.playerData.playerName[0] = FILENAME_UPPERCASE('L');
    gSaveContext.save.info.playerData.playerName[1] = FILENAME_UPPERCASE('U');
    gSaveContext.save.info.playerData.playerName[2] = FILENAME_UPPERCASE('K');
    gSaveContext.save.info.playerData.playerName[3] = FILENAME_UPPERCASE('A');
    gSaveContext.save.info.playerData.playerName[4] = FILENAME_UPPERCASE('S');
    gSaveContext.save.info.inventory.items[SLOT_OCARINA] = ITEM_OCARINA_FAIRY;
    gSaveContext.save.info.inventory.questItems |= (1 << QUEST_KOKIRI_EMERALD);
    {'SET_INFTABLE(INFTABLE_76);' if name=='mask' else ''}
    {'SET_EVENTCHKINF(EVENTCHKINF_25);' if name=='bowling' else ''}
    {'SET_EVENTCHKINF(EVENTCHKINF_TALON_RETURNED_FROM_CASTLE);' if name=='mario' else ''}
    gSaveContext.save.info.playerData.rupees = {0 if name=='squid-poor' else 99};
    {'SET_EVENTCHKINF(EVENTCHKINF_OBTAINED_SILVER_SCALE);' if name=='squid-repeat' else ''}
    {'gSaveContext.save.info.playerData.naviTimer = 650;' if name=='navi' else ''}
    {'SET_EVENTCHKINF(EVENTCHKINF_05); SET_EVENTCHKINF(EVENTCHKINF_09); SET_EVENTCHKINF(EVENTCHKINF_RECEIVED_WEIRD_EGG); SET_EVENTCHKINF(EVENTCHKINF_TALON_RETURNED_FROM_CASTLE); SET_EVENTCHKINF(EVENTCHKINF_OBTAINED_ZELDAS_LETTER); gSaveContext.save.info.inventory.questItems |= (1 << QUEST_SONG_SARIA); gSaveContext.save.info.inventory.upgrades |= (1 << 6); SET_EVENTCHKINF(EVENTCHKINF_25); gSaveContext.save.info.playerData.naviTimer = 650;' if name.startswith('navi-') else ''}
    {'gSaveContext.save.info.inventory.questItems |= (1 << QUEST_GORON_RUBY);' if name=='navi-after' else ''}
    {'gSaveContext.chamberCutsceneNum = CHAMBER_CS_SHADOW;' if name=='sage' else ''}
    {'SET_EVENTINF_INGO_RACE_STATE(INGO_RACE_STATE_FIRST_WIN);' if name=='luigi-win' else ''}
    {'SET_EVENTINF_INGO_RACE_STATE(INGO_RACE_STATE_TRAPPED_WIN_EPONA);' if name=='luigi-gate' else ''}
    SET_NEXT_GAMESTATE(&this->state, Play_Init, PlayState);'''
  p.write_text(s[:a+1]+body+s[end:])
  with (R/('build-'+name+'.log')).open('w') as log:subprocess.run(cmd,cwd=O,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  shutil.copyfile(O/'build/pal-1.0/oot-pal-1.0.z64',R/(name+'.z64'));print('Built',name,flush=True)
finally:
 p.write_text(base)
 with (R/'build-normal.log').open('w') as log:subprocess.run(cmd,cwd=O,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('Normal opening restored.',flush=True)

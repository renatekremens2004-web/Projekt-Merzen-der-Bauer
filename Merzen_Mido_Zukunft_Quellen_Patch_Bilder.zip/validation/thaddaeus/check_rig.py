from pathlib import Path
import json,math
R=Path('/workspace/Projekt-Merzen-der-Bauer');m=json.loads((R/'tools/squid_source.json').read_text());bones=m['bones']
def mat(a):
 x,y,z=[v*math.pi/32768 for v in a];cx,sx,cy,sy,cz,sz=math.cos(x),math.sin(x),math.cos(y),math.sin(y),math.cos(z),math.sin(z)
 return [[cz*cy,cz*sy*sx-sz*cx,cz*sy*cx+sz*sx],[sz*cy,sz*sy*sx+cz*cx,sz*sy*cx-cz*sx],[-sy,cy*sx,cy*cx]]
def mm(a,b):return [[sum(a[i][k]*b[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
def mv(a,v):return [sum(a[i][j]*v[j] for j in range(3)) for i in range(3)]
world=[]
for b in bones:
 p=b['parent'];rot=mat(b['rest_rotation'])
 if p<0:world.append((rot,[x*m['scale'] for x in b['world_head']]))
 else:
  pr,pt=world[p];world.append((mm(pr,rot),[a+b for a,b in zip(pt,mv(pr,b['position']))]))
# Rest geometry must reconstruct the original source with uniform scale;
# compare after removing the single global ground/centering offset.
errors=[]
for v in m['vertices']:
 r,t=world[v['bone']];p=[a+b for a,b in zip(t,mv(r,v['position']))];expected=v['source_world'];errors.append([a-b for a,b in zip(p,expected)])
mean=[sum(e[i] for e in errors)/len(errors) for i in range(3)];error=max(math.dist(e,mean) for e in errors);assert error<10,error
for clip in m['animations'].values():
 for p in clip['frames']:assert len(p['rotation'])==27 and all(0<=x<=65535 for a in p['rotation'] for x in a)
assert len(m['triangles'])==254
print('Uniform-scale rest reconstruction maximum error:',error,'model units;',error*.01,'world units')
(R/'tools/squid_rig_report.json').write_text(json.dumps({'source_triangles':254,'rigid_source_vertices':len(m['vertices']),'source_bones':27,'pose_entries':28,'uniform_model_height_world_units':100,'actor_scale_xyz':[.01,.01,.01],'maximum_rest_reconstruction_error_world_units':error*.01,'source_animations':{k:{'frames':len(v['frames']),'max_omitted_non_root_translation_world_units':v['max_child_translation_error_units']*.01} for k,v in m['animations'].items()},'native_throw_length_frames':60},indent=2)+'\n')

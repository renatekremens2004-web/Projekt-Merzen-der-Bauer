"""Add one German, non-combat Octorok at Jabu-Jabu's entrance."""
from pathlib import Path
import sys
INIT='''    /* Only this placed instance is a villager; native enemies/projectiles are untouched. */
    if (play->sceneId == SCENE_JABU_JABU && thisx->room == 0 && thisx->params == 0x7F00) {
        thisx->params = 0x7F;
        if (gSaveContext.language != LANGUAGE_GER) {
            Collider_InitCylinder(play, &this->collider);
            Actor_Kill(thisx);
            return;
        }
        Actor_ChangeCategory(play, &play->actorCtx, thisx, ACTORCAT_NPC);
        thisx->flags &= ~ACTOR_FLAG_HOSTILE;
        thisx->flags |= ACTOR_FLAG_FRIENDLY | ACTOR_FLAG_ATTENTION_ENABLED;
        thisx->naviEnemyId = 0xFF;
        thisx->attentionRangeType = ATTENTION_RANGE_1;
        thisx->colChkInfo.mass = MASS_IMMOVABLE;
        Actor_SetScale(thisx, 0.01f);
        SkelAnime_Init(play, &this->skelAnime, &gOctorokSkel, &gOctorokFloatAnim,
                       this->jointTable, this->morphTable, 38);
        Collider_InitCylinder(play, &this->collider);
        Collider_SetCylinder(play, &this->collider, thisx, &sOctorockColliderInit);
        this->collider.base.atFlags = AT_NONE;
        this->collider.base.acFlags = AC_NONE;
        this->collider.dim.yShift = 0;
        this->collider.dim.height = 45;
        this->headScale.x = this->headScale.y = this->headScale.z = 1.0f;
        thisx->floorHeight = BgCheck_EntityRaycastDown4(&play->colCtx, &thisx->floorPoly,
                                                      &floorBgId, thisx, &thisx->world.pos);
        if (!BgCheck_GetWaterSurface(play, &play->colCtx, thisx->world.pos.x, thisx->world.pos.z,
                                     &ySurface, &outWaterBox) || ySurface <= thisx->floorHeight) {
            Actor_Kill(thisx);
            return;
        }
        thisx->world.pos.y = thisx->home.pos.y = ySurface;
        this->actionFunc = EnOkuta_Friendly;
        return;
    }

'''
HELPER='''void EnOkuta_SpawnRipple(EnOkuta* this, PlayState* play);

/* A repeatable talk actor: no attack, damage, projectile, water-hide or death path. */
static void EnOkuta_Friendly(EnOkuta* this, PlayState* play) {
    SkelAnime_Update(&this->skelAnime);
    Math_SmoothStepToS(&this->actor.shape.rot.y, this->actor.yawTowardsPlayer, 5, 0x400, 0);
    Actor_SetFocus(&this->actor, 30.0f);
    this->actor.textId = 0x00F8;
    if (!Actor_TalkOfferAccepted(&this->actor, play)) {
        Actor_OfferTalk(&this->actor, play, 100.0f);
    }
    Collider_UpdateCylinder(&this->actor, &this->collider);
    CollisionCheck_SetOC(play, &play->colChkCtx, &this->collider.base);
    EnOkuta_SpawnRipple(this, play);
}

'''
UPDATE='''    if (this->actor.params == 0x7F) {
        EnOkuta_Friendly(this, play);
        return;
    }

'''
CORE_OLD = '((profile->category == ACTORCAT_ENEMY) && Flags_GetClear(play, play->roomCtx.curRoom.num))'
CORE_NEW = '''((profile->category == ACTORCAT_ENEMY) && Flags_GetClear(play, play->roomCtx.curRoom.num) &&
         !(actorId == ACTOR_EN_OKUTA && params == 0x7F00 && play->sceneId == SCENE_JABU_JABU &&
           play->roomCtx.curRoom.num == 0 && gSaveContext.language == LANGUAGE_GER))'''
ENTRY='''    {
        ACTOR_EN_OKUTA,
        {    140,   -300,      0 }, // pool edge, snapped to the native water surface
        { 0x0000, 0x0000, 0x0000 },
        0x7F00, // dedicated friendly instance; no combat or room-clear role
    },
'''
def apply(oot):
 p=oot/'src/overlays/actors/ovl_En_Okuta/z_en_okuta.c';s=p.read_text()
 if HELPER not in s:
  marker='void EnOkuta_Init(Actor* thisx, PlayState* play) {';assert s.count(marker)==1;s=s.replace(marker,HELPER+marker)
  marker='    Actor_ProcessInitChain(thisx, sInitChain);';assert s.count(marker)==1;s=s.replace(marker,INIT+marker)
  marker='    if (!(player->stateFlags1 & (PLAYER_STATE1_TALKING';assert s.count(marker)==1;s=s.replace(marker,UPDATE+marker)
  marker='    if (this->actor.params == 0) {\n        SkelAnime_DrawOpa';assert s.count(marker)==1;s=s.replace(marker,'    if (this->actor.params == 0 || this->actor.params == 0x7F) {\n        SkelAnime_DrawOpa');p.write_text(s)
 d=oot/'extracted/pal-1.0/assets/scenes/dungeons/bdan';p=d/'bdan_room_0_03000068_ActorEntryList.inc.c';s=p.read_text()
 if ENTRY not in s:assert s.count('ACTOR_')==5;p.write_text(s+ENTRY)
 p=d/'bdan_room_0.h';s=p.read_text();s=s.replace('#define LENGTH_bdan_room_0_03000068_ActorEntryList 5','#define LENGTH_bdan_room_0_03000068_ActorEntryList 6');p.write_text(s)
 p=oot/'src/code/z_actor.c';s=p.read_text()
 if CORE_NEW not in s:
  assert s.count(CORE_OLD)==1;s=s.replace(CORE_OLD,CORE_NEW);p.write_text(s)
 print('One friendly German Octorok; native object already loaded; NPC category and talk-only update.')
if __name__=='__main__':apply(Path(sys.argv[1]).resolve())

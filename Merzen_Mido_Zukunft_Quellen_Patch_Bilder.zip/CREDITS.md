# Modellnachweis

**Mr. Burns** von **chicosantossaraiva**, aus der vom Nutzer hochgeladenen Datei `mr._burns.glb`.

- Modell: https://sketchfab.com/3d-models/mr-burns-ee4d3e31c49c4f79a6fc0b281fb4ca6c
- Autor: https://sketchfab.com/chicosantossaraiva
- Lizenz: Creative Commons Attribution 4.0, https://creativecommons.org/licenses/by/4.0/
- Änderungen der aktuellen deutschen Fassung: 2.419 Dreiecke mit erhaltener Gesichts- und Pupillengeometrie; Übertragung der Hautgewichte aus der bereitgestellten Mixamo-FBX; Bindung an zwei originale Ocarina-of-Time-Skelette; quantisierte N64-Vertices, Texturfarben als Vertexfarben und Oberflächennormalen für die Szenenbeleuchtung.

Die bereitgestellte Datei `Mr Burns walk.fbx` diente als Rig- und Hautgewichtvorlage. Ihre Walk-Animation wird nicht als Ersatzschleife verwendet. Burns wird im Spiel von Ganondorfs originalen Animationen bewegt.

Die weiteren Burns-Modelle wurden geprüft und werden in dieser Fassung nicht verwendet.

## Mr. Bean und Tänze

Vom Nutzer bereitgestellte Dateien:

- `Wii - Mr Beans Wacky World - Mr Bean.fbx`: Modell, Skelett und eingebetteter 256×256-Texturatlas.
- `Samba Dancing.fbx` und `Swing Dancing.fbx`: Tanzbewegungen mit Mixamo-Benennung.

Alle 1.258 Modelldreiecke wurden an Impas ursprüngliches Skelett angepaßt. Die Textur wurde auf 128×128 CI8 mit 256 Farben umgesetzt. Proportionen, Hautgewichte und Oberflächennormalen wurden für die ursprünglichen N64-Matrizen vorbereitet. Die Tänze wurden auf die ursprünglichen 40-/55-Frame-Animationsplätze übertragen. Eine weitergehende Urheber- oder Lizenzangabe für diese vom Nutzer gelieferten FBX-Dateien liegt nicht vor.

Die Bean-Kommentare sind eigens für dieses Projekt geschrieben und keine belegten Zitate aus den Filmen oder der Serie.

Spielgrundlage: https://github.com/zeldaret/oot, Commit `14759abf9abb4295de142cdc1452998630ea70fb`.
Die Original-ROM stammt vom Nutzer. Zum eigenen Neubauen der aktuellen deutschen Fassung wird eine eigene Europa/PAL-1.0-ROM benötigt.

## Revision der Bean-Proportionen

Das erneut bereitgestellte Original-FBX liegt unter `models/bean/Mr_Bean.fbx`; die beiden Tanzdateien sind dort ebenfalls erhalten. Die Modellvorbereitung verwendet die ursprünglichen Körper- und Gelenkabstände, eine einheitliche Skalierung und neu transformierte Normalen. Die Impa-Hierarchie mit 16 Gliedern und 15 Matrixplätzen bleibt erhalten; die Gelenkabstände gehören jetzt zu Bean.

Die Gewichtung an Knien und Schuhen wurde für die N64-Bindung angepaßt. Zwei bereits im Original-FBX abgesetzte Schuhteile wurden als starre Stücke an die Hosenenden gesetzt. Ihre Geometrie wird dabei nicht gestreckt. Die vereinfachte Finger- und Gesichtsanimation bleibt eine Einschränkung der Umsetzung.

## Thaddäus / Squidward

Sieben vom Nutzer bereitgestellte Archive wurden untersucht. Gewählt wurde das starre 254-Dreieck-Modell aus `squidward-breathing-spongebob-supersponge.zip` zusammen mit dem kompatiblen Ruheclip aus `squidward-idle-2-spongebob-supersponge.zip`. Die bereitgestellten Dateinamen ordnen es dem SuperSponge-Prototyp zu; eine unabhängige Herkunfts- oder Lizenzprüfung liegt nicht vor. Quelle im Projekt: `models/squid/Breathe.fbx` und `Idle.fbx`; Texturen aus dem Idle-Archiv.

Alle 254 Dreiecke, die ursprünglichen starren Gewichte und sämtliche 27 Gelenke bleiben erhalten. Die Originalbewegungen werden mit festen Knochenlängen in das N64-Format übertragen; geringe animierte Verschiebungen einzelner Nicht-Wurzelgelenke werden dabei verworfen. Die Wurfbewegung ist eine für das Tauchspiel geschriebene Armbewegung im eigenen Rig, keine unveränderte Punch-Animation. Texturen werden in RGBA16 umgesetzt, Oberflächennormalen und Szenenbeleuchtung bleiben wirksam. Thaddäus' Dialoge sind eigene Parodie, keine wörtlichen Serien-Zitate.

"""Build Pieps' Blender rig from the original extracted model data. Blender 4.3+."""
import bpy,json,math,sys
from pathlib import Path
from mathutils import Matrix,Vector,Euler
W=Path(__file__).resolve().parent;D=json.loads((W/'pieps_model.json').read_text());S=D['scale'];C=Matrix.Rotation(math.pi/2,4,'X');Q=Matrix.Rotation(-math.pi/2,4,'Z')
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1;scene.render.fps=D['fps'];scene.frame_start=1;scene.frame_end=6
characters=bpy.data.collections.new('Pieps | Modell und Rig');scene.collection.children.link(characters)
forms=bpy.data.collections.new('Rig-Formen (nicht rendern)');scene.collection.children.link(forms);forms.hide_render=True
presentation=bpy.data.collections.new('Vorschau | Kamera und Licht');scene.collection.children.link(presentation)
def rehome(obj,col):
 for c in list(obj.users_collection):c.objects.unlink(obj)
 col.objects.link(obj)
def natives(joints,rest=False):
 out=[]
 for l in D['limbs']:
  p=joints[0]if l['index']==0 else l['pos'];angles=[v*math.pi/32768 for v in joints[l['index']+1]]
  m=Matrix.Translation(Vector(p))@Euler(angles,'XYZ').to_matrix().to_4x4()
  if l['parent']is not None:m=out[l['parent']]@m
  out.append(m)
 return out
def bone_matrix(m):
 o=C@m@Q;o.translation*=S;return o
rest=natives(D['rest_joints'])
arm=bpy.data.armatures.new('Pieps | Original-Skelett');rig=bpy.data.objects.new('Pieps_Rig',arm);characters.objects.link(rig);bpy.context.view_layer.objects.active=rig;rig.select_set(True);rig.show_in_front=True;arm.display_type='OCTAHEDRAL'
rig['Herkunft']='Originales Pieps-Modell aus unserem OoT-Projekt; 9 originale Knochen plus Flug-Steuerung.';rig['Bedienung']='Pose Mode: CTRL_Flug = gesamter Vogel; Koerper = Körperbewegung; Fluegel.L / .R = Flügelschlag. Zuerst Original-Action duplizieren oder neue Action anlegen.'
controls=arm.collections.new('Steuerung');helpers=arm.collections.new('Original-Skelett | Hilfsknochen')
bpy.ops.object.mode_set(mode='EDIT');e=arm.edit_bones.new('CTRL_Flug');e.head=(0,0,-.035);e.tail=(0,.07,-.035)
for l,m in zip(D['limbs'],rest):
 e=arm.edit_bones.new(l['name']);e.tail=(0,.04,0);e.matrix=bone_matrix(m);e.length=.07 if l['index']in(3,6)else .04;e.parent=arm.edit_bones[D['limbs'][l['parent']]['name']]if l['parent']is not None else arm.edit_bones['CTRL_Flug'];e.use_connect=False
bpy.ops.object.mode_set(mode='OBJECT')
for b in arm.bones:
 iscontrol=b.name in ['CTRL_Flug','Koerper','Fluegel.L','Fluegel.R'];(controls if iscontrol else helpers).assign(b);b.use_deform=b.name in ['Fluegel_Mesh.L','Fluegel_Mesh.R','Koerper_Mesh']
helpers.is_visible=False
mats={}
for t in D['textures']:
 mat=bpy.data.materials.new(t['name']);mat.use_nodes=True;mat.use_backface_culling=False;nodes=mat.node_tree.nodes;bsdf=nodes.get('Principled BSDF');bsdf.inputs['Roughness'].default_value=.85
 tex=nodes.new('ShaderNodeTexImage');tex.name='Originaltextur';tex.image=bpy.data.images.load(str(W/'Texturen'/f"{t['name']}{'_Spiegelung' if t['offset']==0xd00 else ''}.png"));tex.image.pack();tex.interpolation='Closest';tex.extension='EXTEND';mat.node_tree.links.new(tex.outputs['Color'],bsdf.inputs['Base Color']);mat.node_tree.links.new(tex.outputs['Alpha'],bsdf.inputs['Alpha']);bsdf.inputs['Specular IOR Level'].default_value=.15
 mats[t['offset']]=mat
mesh_objs=[];total_tris=0
for l,m in zip(D['limbs'],rest):
 if not l['faces']:continue
 verts=[];faces=[];uvs=[];matidx=[];materials=[];lookup={}
 for f in l['faces']:
  if f['texture']not in materials:materials.append(f['texture'])
  t=next(t for t in D['textures']if t['offset']==f['texture']);ids=[]
  for corner in f['corners']:
   key=corner['address']
   if key not in lookup:lookup[key]=len(verts);verts.append(tuple((C@m@Vector(corner['position']))*S))
   ids.append(lookup[key]);u,v=corner['st'];uvs.append(((u/32+.5)/(t['width']*(2 if t['offset']==0xd00 else 1)),1-(v/32+.5)/t['height']))
  faces.append(ids);matidx.append(materials.index(f['texture']))
 mesh=bpy.data.meshes.new(l['name']+' | Originalgeometrie');mesh.from_pydata(verts,[],faces);mesh.update();obj=bpy.data.objects.new({'Fluegel_Mesh.L':'Pieps_Fluegel.L','Fluegel_Mesh.R':'Pieps_Fluegel.R','Koerper_Mesh':'Pieps_Koerper'}[l['name']],mesh);characters.objects.link(obj);obj.parent=rig
 for mat in materials:mesh.materials.append(mats[mat])
 uv=mesh.uv_layers.new(name='Original_UV')
 for loop,item in zip(uv.data,uvs):loop.uv=item
 for poly,idx in zip(mesh.polygons,matidx):poly.material_index=idx;poly.use_smooth=False
 vg=obj.vertex_groups.new(name=l['name']);vg.add(list(range(len(verts))),1,'REPLACE');mod=obj.modifiers.new('Pieps | Skelett','ARMATURE');mod.object=rig;mesh_objs.append(obj);total_tris+=len(faces)
# Custom control shapes. The geometry itself remains untouched.
def shape(name,kind):
 if kind=='ring':v=[(math.cos(i*math.tau/32),math.sin(i*math.tau/32),0)for i in range(32)];edges=[(i,(i+1)%32)for i in range(32)]
 else:v=[(0,0,0),(0,1,0),(-.3,.65,0),(0,1,0),(.3,.65,0)];edges=[(0,1),(1,2),(3,4)]
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(v,edges,[]);o=bpy.data.objects.new(name,mesh);forms.objects.link(o);o.hide_render=True;o.hide_set(True);return o
ring=shape('Form | Flugsteuerung','ring');arrow=shape('Form | Fluegel','arrow')
for p in rig.pose.bones:
 p.rotation_mode='QUATERNION'
 if p.name in ['CTRL_Flug','Koerper','Fluegel.L','Fluegel.R']:
  p.custom_shape=arrow if p.name.startswith('Fluegel.')else ring;p.custom_shape_scale_xyz=(.8,.8,.8);p.color.palette={'CTRL_Flug':'THEME04','Koerper':'THEME03','Fluegel.L':'THEME04','Fluegel.R':'THEME01'}[p.name]
  if p.name.startswith('Fluegel.'):
   p['Hinweis']='Für Flügelschlag lokal um Z drehen. R, Z, Z im Pose Mode. Original-Flug hat etwa +/-50 Grad.'
# Bake the exact native animation to the rig, including its original body bob.
rig.animation_data_create();action=bpy.data.actions.new('Pieps_Original_Fluegelschlag');action.use_fake_user=True;rig.animation_data.action=action
for frame in range(1,D['frame_count']+2):
 scene.frame_set(frame);transforms=natives(D['frames'][(frame-1)%D['frame_count']]);rig.pose.bones['CTRL_Flug'].matrix_basis=Matrix.Identity(4)
 for l,m in zip(D['limbs'],transforms):
  p=rig.pose.bones[l['name']];p.matrix=bone_matrix(m);bpy.context.view_layer.update();p.keyframe_insert(data_path='location',frame=frame,group=p.name);p.keyframe_insert(data_path='rotation_quaternion',frame=frame,group=p.name);p.keyframe_insert(data_path='scale',frame=frame,group=p.name)
for fc in action.fcurves:
 for k in fc.keyframe_points:k.interpolation='LINEAR'
 fc.modifiers.new('CYCLES')
scene.frame_set(1);bpy.context.view_layer.update()
# Neutral action for making your own poses; the original animation remains available.
original=rig.animation_data.action;neutral=bpy.data.actions.new('Pieps_Neutral | Eigene Animation starten');neutral.use_fake_user=True;rig.animation_data.action=neutral
for p in rig.pose.bones:p.matrix_basis=Matrix.Identity(4);p.keyframe_insert(data_path='location',frame=1,group=p.name);p.keyframe_insert(data_path='rotation_quaternion',frame=1,group=p.name);p.keyframe_insert(data_path='scale',frame=1,group=p.name)
rig.animation_data.action=original;scene.frame_set(1);bpy.context.view_layer.update()
readme='''PIEPS – ANIMIERBARE BLENDER-VERSION

Originalgeometrie, Originaltexturen und originales 9-Knochen-Skelett.
26 Dreiecke. Zusätzlicher Steuerknochen CTRL_Flug.

1. Pieps_Rig auswählen, Pose Mode (Strg+Tab).
2. CTRL_Flug verschiebt und dreht den ganzen Vogel.
3. Koerper bewegt den Körper einschließlich der Flügel.
4. Fluegel.L und Fluegel.R steuern die beiden Flügel separat.
5. R, Z, Z dreht einen Flügel um seine lokale Schlagachse.
6. I setzt Keyframes; im Action Editor neue Action anlegen oder Original duplizieren.

Pieps_Original_Fluegelschlag: originale 6 Frames, 20 fps, zyklisch.
Frame 7 wiederholt Frame 1 für eine nahtlose Kurve; Wiedergabebereich 1–6.
Pieps_Neutral: ausgebreitete neutrale Flügel als Start für eigene Animationen.

Unter Armature > Bone Collections sind die ursprünglichen Hilfsknochen ausgeblendet.
Texturen sind in der .blend gepackt und zusätzlich als PNG beigelegt.
Das Modell ist absichtlich extrem polygonarm. Flügel und Schwanz haben teilweise
keine Dicke; transparente Texturen erzeugen die Silhouette. Es gibt keine eigenen
Schnabel-, Gesichts- oder Beinknochen. Für Lippenbewegungen / Laufen müsste man
das Modell weiter modellieren und riggen. Flugbahnen und alle drei Körperteile
lassen sich bereits animieren. Nur der Flügelschlag ist eine originale Spielanimation;
Flugbahnen der Cutscenes werden im Spiel per Code gesteuert.

Die .glb ist eine zusätzliche Austauschversion mit Skelett und Originalanimation.
Die .blend enthält außerdem die neutrale Action, Steuerformen und Vorschaulicht.
Diese Blender-Datei verändert weder die ROM noch den Patch.
'''
text=bpy.data.texts.new('LIESMICH | Pieps');text.write(readme);(W/'LIESMICH.txt').write_text(readme,encoding='utf-8')
# Lightweight studio preview, kept separate from the export selection.
world=bpy.data.worlds.new('Pieps | Studio');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.065,.09,.12,1);world.node_tree.nodes['Background'].inputs[1].default_value=.5;scene.world=world
coords=[o.matrix_world@v for o in mesh_objs for v in [Vector(x)for x in o.bound_box]];lo=Vector(tuple(min(v[i]for v in coords)for i in range(3)));hi=Vector(tuple(max(v[i]for v in coords)for i in range(3)));center=(lo+hi)/2;span=max(hi-lo)
def aim(obj,target):obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.camera_add(location=center+Vector((span*1.4,-span*1.8,span*.9)));cam=bpy.context.object;rehome(cam,presentation);cam.name='Vorschaukamera';aim(cam,center);cam.data.type='ORTHO';cam.data.ortho_scale=span*1.35;scene.camera=cam
for name,delta,power,size in [('Hauptlicht',(-.5,-.7,1),12,.7),('Aufhellung',(.7,.3,.4),6,.5)]:
 bpy.ops.object.light_add(type='AREA',location=center+Vector(delta)*span*2);o=bpy.context.object;rehome(o,presentation);o.name=name;o.data.energy=power;o.data.shape='DISK';o.data.size=size;aim(o,center)
scene.view_settings.view_transform='Standard';scene.render.engine='CYCLES';scene.cycles.samples=32;scene.cycles.use_denoising=False;scene.render.resolution_x=800;scene.render.resolution_y=800;scene.render.resolution_percentage=100;scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
# The default viewport opens on Pieps, with the rig selected and textures visible.
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True);bpy.context.view_layer.objects.active=rig
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':
   area.spaces.active.shading.type='MATERIAL';area.spaces.active.region_3d.view_distance=span*2;area.spaces.active.region_3d.view_location=center;area.spaces.active.region_3d.view_rotation=cam.rotation_euler.to_quaternion();area.spaces.active.clip_start=.001
# Export only original geometry and its rig.
bpy.ops.object.select_all(action='DESELECT');rig.select_set(True)
for o in mesh_objs:o.select_set(True)
args=dict(filepath=str(W/'Pieps_Animierbar.glb'),export_format='GLB',use_selection=True,export_animations=True,export_force_sampling=True,export_frame_range=True,export_animation_mode='ACTIVE_ACTIONS',export_anim_slide_to_zero=True)
scene.frame_end=7;props=bpy.ops.export_scene.gltf.get_rna_type().properties;args={k:v for k,v in args.items()if k in props};bpy.ops.export_scene.gltf(**args);scene.frame_end=6
for o in mesh_objs:o.select_set(False)
bpy.context.view_layer.objects.active=rig;bpy.ops.object.mode_set(mode='POSE');bpy.ops.wm.save_as_mainfile(filepath=str(W/'Pieps_Animierbar.blend'))
scene.render.filepath=str(W/'Pieps_Vorschau.png');bpy.ops.render.render(write_still=True)
print('PIEPS_BUILD_DONE',json.dumps(dict(bones=len(arm.bones),triangles=total_tris,frames=D['frame_count'],bind_bounds=[list(lo),list(hi)])))

from pathlib import Path
import sys,re,json,shutil
O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer');W=Path('/tmp/names-v111');sys.path.insert(0,str(R/'tools'));from build_story import *
p=O/'extracted/pal-1.0/text/message_data.h';s=p.read_text();before=messages(s);layout=Layout(O);bodies=json.load(open(R/'tools/dialogue_v94_bodies.json'));changed={}
for k,v in before.items():
 b=v['parts'][2][2];text=plain(b)
 if not re.search('Ganondorf',text,re.I):continue
 assert not controls(b),(k,controls(b))
 text=' '.join(text.split()).replace('Ganondorfs',"Friedrich Merz'").replace('Ganondorf','Friedrich Merz')
 lines=layout.wrap(text,210);assert len(lines)<=4,(k,lines)
 new='\n'+c_text('\n'.join(lines),'DEFAULT')+'\n';changed[k]=new;bodies[k]=new
assert set(changed)=={'0414','0418','0419'},changed
for k in sorted(changed,key=lambda k:before[k]['parts'][2][0],reverse=True):a,b,_=before[k]['parts'][2];s=s[:a]+changed[k]+s[b:]
p.write_text(s);(R/'tools/dialogue_v94_bodies.json').write_text(json.dumps(bodies,ensure_ascii=False,indent=2)+'\n')
assert all(not re.search('ganondorf',plain(v['parts'][2][2]),re.I)for v in messages(s).values())
(W/'Geaenderte_Texte_V111.txt').write_text('\n\n'.join(k+'\n'+plain(v)for k,v in changed.items()))
(W/'changes.json').write_text(json.dumps(dict(ids=list(changed),no_ganondorf_in_german_messages=True,all_control_tokens_unchanged=True,all_messages_within_four_lines=True),indent=2))
for f in ['ram_build.py','package_patches.py']:shutil.copy('/tmp/boss-title-v110/'+f,W/f)
p=W/'package_patches.py';p.write_text(p.read_text().replace('Bossname_V110','Namensreste_V111'))
print('ALL_GERMAN_GANONDORF_MENTIONS_REPLACED',list(changed))

from pathlib import Path
import sys,re,json,struct,hashlib,subprocess
import crunch64
W=Path(__file__).parent;V=Path('/tmp/boss-title-v110');O=Path('/workspace/oot-burns-pal');R=Path('/workspace/Projekt-Merzen-der-Bauer');sys.path.insert(0,str(R/'tools'));from build_story import *
parsed=messages((O/'extracted/pal-1.0/text/message_data.h').read_text());assert all(not re.search('Ganondorf',plain(v['parts'][2][2]),re.I)for v in parsed.values());out={}
for mode in ['normal','debug']:
 a=(V/(mode+'.z64')).read_bytes();b=(W/(mode+'.z64')).read_bytes();old=json.load(open(V/f'all-symbols-{mode}.json'));new=json.load(open(W/f'all-symbols-{mode}.json'));off=new['_dmadataSegmentRomStart'];assert old['_dmadataSegmentRomStart']==off;same=0;changed=[]
 for i in range(3000):
  va,ve,ps,pe=struct.unpack_from('>IIII',b,off+16*i)
  if not ve:break
  def seg(rom):
   vs,ve,ps,pe=struct.unpack_from('>IIII',rom,off+16*i)
   if pe==0xffffffff:return None
   return bytes(rom[ps:ps+ve-vs]if pe==0 else crunch64.yaz0.decompress(rom[ps:pe]))
  x,y=seg(a),seg(b)
  if x==y:same+=1;continue
  name=next((k[1:-15]for k,v in new.items()if k.startswith('_')and k.endswith('SegmentRomStart')and v==va),hex(va));changed.append(name)
  if name=='code':
   textend=new['_codeSegmentTextEnd']-new['_codeSegmentStart'];assert x[:textend]==y[:textend],'executable code changed'
   differences=[j for j,(u,v)in enumerate(zip(x,y))if u!=v];lo=new['sGerMessageEntryTable']-new['_codeSegmentStart'];hi=new['sStaffMessageEntryTable']-new['_codeSegmentStart'];assert all(lo<=j<hi for j in differences),'change outside localized pointer tables'
  if name=='ger_message_data_static':assert b'Ganondorf'not in y
 assert set(changed)<=set(['makerom','dmadata','code','ger_message_data_static']),changed
 for k in ['0414','0418','0419']:
  values=sorted(v for name,v in new.items()if name.startswith('_message_0x')and name.endswith('_ger'));start=new['_message_0x'+k+'_ger'];size=next(v for v in values if v>start)-start;assert size<1280
 out[mode]=dict(unchanged_segments=same,changed_segments=changed,executable_code_unchanged=True,actors_audio_scenes_and_textures_byte_identical=True,zero_ganondorf_in_german_message_data=True)
p=O/'extracted/pal-1.0/text/message_data.h';h=hashlib.sha256(p.read_bytes()).hexdigest();subprocess.run([sys.executable,str(R/'tools/build_dialogue_v94.py'),str(O)],check=True);assert hashlib.sha256(p.read_bytes()).hexdigest()==h
(W/'Verifikation_V111.json').write_text(json.dumps(out,indent=2));print('VERIFIED',out)

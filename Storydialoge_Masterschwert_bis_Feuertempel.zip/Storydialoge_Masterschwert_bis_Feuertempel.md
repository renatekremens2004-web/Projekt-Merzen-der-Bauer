# Aktuelle Dialoge: Master-Schwert bis Feuertempel

Stand: 21. Oktober 2026, eingebauter deutscher PAL-1.0-Stand V22. Abschrift zum Durchgehen und Umschreiben; Die sechs neuen Nachrichten zu Wallace und dem Nachspiel sind enthalten; der Export selbst ändert keine Spieltexte oder ROM-Dateien.

Beginn: Erwachen bei Robert Habeck nach dem Ziehen des Master-Schwerts. Ende: Wallace als Weise des Feuers, Feueramulett und unmittelbare Reaktionen nach dem Feuertempel. Boris, alle erwachsenen Kokiri-Zustände, Goronia, sämtliche platzierten Feuertempel-Gefangenen und optionale Nebenbegegnungen dieser Kapitel sind ebenfalls enthalten. Andere frei bereisbare Weltregionen und spätere Hauptkapitel sind nicht Gegenstand dieser Liste.

Jede vierstellige Nummer ist eine Text-ID. Jede Seite und jede Auswahl bleibt einzeln erkennbar; [Spielername] ist dynamisch. Angezeigt wird der tatsächliche deutsche Wortlaut einschließlich vorhandener Originaltexte. Die Hauptgeschichte und ihre bedingten Alternativen stehen zuerst; frei erreichbare Nebenbegegnungen und Gegner-Zielerfassung folgen im Anhang. Diese Varianten werden nicht alle automatisch hintereinander abgespielt.

**Zum Bearbeiten:** Beispielsweise „704F, Seite 2 neu: …“ oder „014E ersetzen durch …“.

## Inhaltsübersicht

- 0. Unmittelbar nach dem Ziehen des Schwerts – Merz, Grenzszene zur vorigen Liste
- 1. Erwachen in der Halle der Weisen – Robert Habeck und Navi
- 2. Zitadelle der Zeit – Navi und Sheiks erster Auftritt
- 3. Navis natürliche Story-Hinweise während des Waldkapitels
- 4. Kakariko – Boris als Geist, Rennen und Fanghaken
- 5. Kokiri-Wald vor der Befreiung – alle erwachsenen Bewohner
- 6. Verlorene Wälder – Mido vor dem Waldtempel
- 7. Salia per Okarina vor dem Waldtempel
- 8. Heilige Lichtung – Navi, Sheik und das Menuett des Waldes
- 9. Waldtempel – örtliche Navi-Hinweise und Fackeln
- 10. Waldtempel – Feen-Bogen und neue Begegnungen
- 11. Philipp Amthor – Begrüßung, Navi-Zielerfassung und Merz nach dem Sieg
- 12. Waldweise – Krabbelminen-Frau und Waldamulett
- 13. Zurück im Kokiri-Wald – Tripple T erscheint und erklärt die Herkunft
- 14. Nach dem Waldtempel – Mido und Salia per Okarina
- 15. Kokiri-Wald nach der Befreiung – neue Bewohnertexte
- 16. Übergang zum nächsten Kapitel – Navis nächster Story-Hinweis
- 17. Goronia als Erwachsener – Darunias Sohn und das feuerfeste Gewand
- 18. Todeskrater – Hitze, Sheik und der Bolero des Feuers
- 19. Feuertempel – Darunia vor seinem Vorstoß zum Drachen
- 20. Feuertempel – sämtliche örtlichen Navi-Hinweise
- 21. Gefangene Goronen – Ansprache, Befreiung und alle tatsächlich platzierten Ratschläge
- 22. Wallace im Feuertempel – vor und nach dem Öffnen seiner Zelle
- 23. Wallace Hammer und Volvagia
- 24. Halle der Weisen – Wallace und das Feueramulett
- 25. Nach dem Feuertempel – Goronia und Navis nächster Hinweis
- A. Optionale Windmühle beim Kakariko-Besuch – Regenlied
- B. Gemeinsame Okarina-Bedienung bei Salias Lied
- C. Fado – optionale erwachsene Tauschquest, unabhängig vom Waldtempel
- D. Gemeinsame Dungeon-Fundtexte
- E. Kakariko – der Volvagia-Verehrer
- F. Gespeicherte Zusatztexte – keine regulären Stationen dieser deutschen Hauptgeschichte

## 0. Unmittelbar nach dem Ziehen des Schwerts – Merz, Grenzszene zur vorigen Liste

### 700A

Projekttext.
Kurze Merz-Szene unmittelbar nach dem Schwertziehen; danach beginnt das eigentliche Erwachen bei Habeck. Zur vollständigen Abschnittsgrenze mit enthalten.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(60), BOX_BREAK_DELAYED(90), BOX_BREAK_DELAYED(80), FADE(50). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Herr Bohne kämpfte gut. Wie zu
> erwarten.

**Seite 2**

> Er starb mit Ehre. Ich habe ihn
> ermordet.

**Seite 3**

> Zelda entkam. Doch letztendlich
> gewinnt immer...

**Seite 4**

> ...die politische Mitte!

## 1. Erwachen in der Halle der Weisen – Robert Habeck und Navi

### 704E

Projekttext.
Beginn dieser Liste, unmittelbar nach Merz 700A aus der vorigen Liste.

**Seite 1**

> [Spielername]...

**Seite 2**

> Wach auf. Wir müssen reden. Es ist
> leider etwas kompliziert geworden.

### 704F

Projekttext.
Habecks Vorstellung. Die über TEXTID verbundenen Erklärungen 0121–0123 folgen hier ebenfalls vollständig.
Direkte native Fortsetzung: 0121.

**Seite 1**

> Ich bin Robert Habeck, Weiser des
> Lichts. Also, zunächst einmal: schön,
> daß Du wieder da bist.

**Seite 2**

> Ich kam Friedrich Merz schon früh
> auf die Schliche. Seine Pläne waren
> keine normale Regierungspolitik.

**Seite 3**

> Er wollte Hyrule besitzen. Die
> Menschen, die Tempel, die Rohstoffe.
> Zusammenhalt erschien ihm als
> Kostenpunkt.

**Seite 4**

> Ich stellte ihn auf dem Todesberg zur
> Rede. Sachlich, wie ich fand. Er stieß
> mich den Berg hinunter.

**Seite 5**

> Das war, um es vorsichtig zu sagen,
> keine besonders offene Form des
> politischen Austausches.

**Seite 6**

> Ich bin dabei gestorben. Dieser
> menschliche Körper hier ist eine
> geistige Erscheinung. Mit Anzug.

**Seite 7**

> Die Hyrule-Zeitung hatte mich vorher
> schon völlig zerrissen. Jeden Tag eine
> neue Schlagzeile.

**Seite 8**

> Als Mensch konnte ich mich also
> kaum noch öffentlich zeigen. Nach
> dem Sturz zusätzlich körperlich nicht.

**Seite 9**

> Nun fragst Du Dich vielleicht,
> weshalb eine gewisse Eule erstaunlich
> viel über Deine Reise wußte.

**Seite 10**

> Diese Eule war ich, [Spielername].
> Methusa. Ich möchte das ausdrücklich
> und ohne jedes Mißverständnis sagen.

### 0121

Projekttext.
Direkte native Fortsetzung: 0122.

**Seite 1**

> Aber eine Geistereule. Das Wort
> Geist ist hier entscheidend. Keine
> lebendige Eule mit einem Nebenberuf.

**Seite 2**

> Ich war bereits tot. Die Eule war
> eine vorübergehende, durch
> Sonnenenergie getragene Geistgestalt.

**Seite 3**

> Das bedeutet: Ich hatte keinen
> Vogelkörper, der irgendwo auf eine
> Wiese hätte fallen können.

**Seite 4**

> Ich sammelte Solarenergie. Damit ließ
> sich für kurze Zeit eine örtlich
> begrenzte Eulenform herstellen.

**Seite 5**

> An bestimmten Orten war besonders
> viel magische Energie vorhanden. Dort
> konnte ich mit Dir sprechen.

**Seite 6**

> Nicht überall. Und nicht ständig.
> Diese Energie lag gewissermaßen in
> kleinen, unpraktischen Inseln vor.

**Seite 7**

> Zwischen diesen Inseln konnte ich Dir
> folgen, aber nicht beliebig körperlich
> in die Welt eingreifen.

**Seite 8**

> In die Stadt zu gehen hätte mehr
> Energie gebraucht. Häuser, Schatten,
> eine sehr schwierige Versorgungslage.

**Seite 9**

> Gegen Merz zu kämpfen hätte noch
> mehr gebraucht. Eine Geistereule ist
> nun einmal kein Kraftwerk.

**Seite 10**

> Ich konnte beraten. Sehr ausführlich
> beraten. Für einen Faustkampf reichte
> die solare Restladung nicht.

### 0122

Projekttext.
Direkte native Fortsetzung: 0123.

**Seite 1**

> Inzwischen hat Merz mir auch diesen
> Energie-Wasserhahn zugedreht. Bildlich
> gesprochen, versteht sich.

**Seite 2**

> Es floß dort kein Wasser aus einer
> Sonne. Der Hahn bezeichnet die
> Zufuhr magisch nutzbarer Energie.

**Seite 3**

> Er ließ die alten Energieorte
> versiegeln. Keine Zufuhr, keine
> Erscheinung. Also auch keine
> Geistereule mehr.

**Seite 4**

> Du wirst mich draußen daher vorerst
> nicht wieder als Eule treffen. Auch
> nicht abends mit Speicher.

**Seite 5**

> Hier in der Halle der Weisen ist es
> anders. Hier besteht ein
> geschlossener magischer Schutzraum.

**Seite 6**

> Diese Magie hält meine menschliche
> Geistgestalt aufrecht. Ich stehe vor
> Dir, ohne wieder lebendig zu sein.

**Seite 7**

> Die Kraft bleibt größtenteils hier. Ich
> kann sie nicht einfach in einen Eimer
> füllen und nach draußen tragen.

**Seite 8**

> Die Halle schützt, was in ihr ist.
> Außerhalb greifen andere Bindungen.
> Weshalb? Weil diese Bindungen so
> sind.

**Seite 9**

> Das ist keine besonders befriedigende
> Erklärung. Es ist leider die technisch
> genaueste, die wir haben.

**Seite 10**

> Du und Navi befandet Euch hier in
> magischer Stasis. Kein gewöhnliches
> Koma. Eine sehr geregelte
> Verwahrung.

### 0123

Projekttext.

**Seite 1**

> Der Körper konnte heranwachsen,
> während Bewußtsein und
> Wahrnehmung ruhten. Beides ist
> getrennt geregelt.

**Seite 2**

> Wäre alles vollständig eingefroren
> gewesen, wärst Du noch klein. Genau
> das wollten wir ja vermeiden.

**Seite 3**

> Für Navi galt derselbe Schutz. Feen
> altern dabei anders. Bitte verwechsle
> Alterung nicht mit Flugleistung.

**Seite 4**

> Hier konnte ich die Stasis versorgen,
> obwohl draußen die Energie fehlte.
> Innenversorgung, Außenversorgung.

**Seite 5**

> Das ist derselbe Unterschied, wegen
> dessen eine Lampe im Haus leuchten
> kann, ohne den ganzen Wald zu
> erhellen.

**Seite 6**

> Nur daß die Lampe hier Magie ist,
> das Haus eine Weisenhalle und der
> Wald eine etwas überlastete
> Metapher.

**Seite 7**

> Die Zitadelle der Zeit steht übrigens
> noch. Merz hat sie nicht einfach
> abreißen können.

**Seite 8**

> Die ist aus dermaßen stabilem Beton
> gebaut. Da kannst Du mit einer
> schwarzen Zauberkugel lange
> gegenreden.

**Seite 9**

> Das Master-Schwert öffnete ihm
> leider das Heilige Reich. Die
> Eingangssicherung war weniger solide
> als der Beton.

**Seite 10**

> Bevor ich nun zu Kleidung, Muskeln
> und der verbleibenden Zeit komme:
> Erschrick nicht. Schau Dich einmal an.

### 7050

Projekttext.
Navi in der Halle der Weisen, zwischen Habecks Erklärungen.

**Seite 1**

> [Spielername], Du bist erwachsen!
> Und ich habe sieben Jahre nicht
> gemeckert? Das macht mir Angst.

### 7051

Projekttext.
Auswahl: Ja führt zu 7053; Nein zu 7052 und von dort zurück zu 7051. Nicht alle Varianten laufen nacheinander.

**Seite 1**

> Das Master-Schwert erkannte Dich
> als Herrn der Zeiten. Du warst für
> den Kampf aber noch zu jung.

**Seite 2**

> Deshalb die sieben Jahre Stasis.
> Deine Kleidung wuchs durch Magie
> mit. Eine mitwachsende Ausstattung.

**Seite 3**

> Ohne diese Regelung hätten wir jetzt
> ein sehr unangenehmes Problem mit
> Deiner Hose.

**Seite 4**

> Auch die Muskeln wurden magisch
> erhalten. Sonst könntest Du nach
> sieben Jahren nicht einmal aufstehen.

**Seite 5**

> Das war kein kostenloses
> Fitneßprogramm. Es war eine
> Maßnahme gegen körperlichen Abbau.

**Seite 6**

> Die Gegenstände waren dagegen nicht
> alle in diesen Schutz einbezogen.
> Unterschiedliche Zuständigkeiten.

**Seite 7**

> Der Bumerang war seit Jabu-Jabus
> Innerem sowieso feucht. Sieben Jahre
> Lagerung waren dann keine
> Verbesserung.

**Seite 8**

> Einiges ist verschimmelt, anderes
> paßt nicht zu Deiner jetzigen Gestalt.
> Du kannst nicht alles benutzen.

**Seite 9**

> Bei einer Rückkehr in Deine Kindheit
> steht Dir wieder die damalige, noch
> brauchbare Ausrüstung zur Verfügung.

**Seite 10**

> Das ist eine Zustandsfrage entlang
> der Zeitbindung. Kein Vorschlag,
> Schimmel durch Schwertschwingen zu
> entfernen.

**Seite 11**

> Hast Du das soweit verstanden?
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 7052

Projekttext.
Direkte native Fortsetzung: 7051.

**Seite 1**

> Das ist verständlich. Vielleicht war
> die Erklärung zu knapp. Ich beginne
> noch einmal bei der Stasis.

### 7053

Projekttext.

**Seite 1**

> Mit dem Master-Schwert im
> Zeitenfels kannst Du genau sieben
> Jahre zurück.

**Seite 2**

> Nicht acht. Nicht sechs. Nicht bis
> letzten Dienstag. Zwei feste
> Endpunkte.

**Seite 3**

> Dein Schlaf lud die Zeitmagie auf und
> band sie an Dein damaliges Selbst.

**Seite 4**

> Nun bist Du geweckt. Die Endpunkte
> stehen fest. Mehr Zeit ist nicht drin.

**Seite 5**

> Wie zwei Haltestellen. Der Schlaf
> baut die Strecke, das Schwert öffnet
> sie.

**Seite 6**

> Die Bindung am Zeitenfels muß noch
> freigegeben werden. Folge erst Deiner
> Aufgabe.

**Seite 7**

> Merz betrat das Heilige Reich und riß
> das Triforce-Fragment an sich.

**Seite 8**

> Seither verwüstet er Hyrule. Er nennt
> das Eigenverantwortung.

**Seite 9**

> Er vertrieb Menschen, entweihte
> Tempel und sperrte die Energie. Das
> ist böse.

**Seite 10**

> Wecke die anderen Weisen! Ihre
> Amulette bündeln unsere Kraft gegen
> Merz.

**Seite 11**

> Ich bin der Weise des Lichts. Hier
> kann ich helfen. Selbst hinausziehen
> kann ich nicht.

**Seite 12**

> [Spielername], Du trägst das
> Master-Schwert. Befreie die Tempel
> und finde die Weisen!

**Seite 13**

> Beginne im Wald. Dort erschließt sich
> der weitere Weg.

**Seite 14**

> Ich übertrage Dir meine Macht. Eine
> gezielte Übertragung. Kein
> Magie-Eimer.

**Seite 15**

> Geh nun. Und falls jemand fragt: Ja,
> ich war die Eule. Die Geistereule.

### 0040

Projekttext.

**Seite 1**

> Das Amulett des Lichts!
> Robert Habeck, der Weise,
> gibt Dir seine Kraft!

### 70E9

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Zeitgesteuerte Textcodes: FADE(80). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Finde die anderen
> Weisen und rette Hyrule!

## 2. Zitadelle der Zeit – Navi und Sheiks erster Auftritt

### 7054

Projekttext.
Navi in der nativen ersten Erwachsenen-Cutscene der Zitadelle. Kein frei gewählter C-Knopf-Hinweis.

**Seite 1**

> [Spielername], Yo, als ob wir jetzt
> einfach sieben Jahre lang eingefroren
> waren. Das kann doch nicht sein!

**Seite 2**

> Und Dein ganzer Scheiß ist auch
> komplett kaputt. Deine ganzen Items
> sind ja völlig geschrottet!

**Seite 3**

> Jetzt müssen wir die anderen Weisen
> finden. Ich weiß überhaupt nicht, was
> hier abgeht.

**Seite 4**

> Das ist echt heftig. Total verrückt.
> Uiuiuiuiuiui!

### 7056

Projekttext.

**Seite 1**

> Ich habe auf Dich gewartet. Friedrich
> Merz hatte leider sieben Jahre
> Vorsprung.

### 7057

Projekttext.

**Seite 1**

> Friedrich Merz hat Hyrule in den
> Untergang gestürzt. Die ganze Stadt
> liegt in Trümmern, und er ist der
> Meinung, das Volk sei schuld.

**Seite 2**

> Im Wald gibt's kaum noch Orte zu
> wohnen.

**Seite 3**

> Die Goronen wurden genutzt, um an
> einer neuen Waffe zu arbeiten.

**Seite 4**

> Der See ist jetzt kälter als das Herz
> von Katharina Reiche.

**Seite 5**

> Auf dem Friedhof liegen jetzt noch
> mehr Leute begraben als vorher, weil
> die alle gestorben sind.

**Seite 6**

> Und jetzt versucht er sich auch noch
> die Wüste an den Nagel zu reißen.

**Seite 7**

> Du mußt die fünf Weisen aus den
> fünf Tempeln zusammenbringen. Nur
> sie können Merz wieder abwählen.

**Seite 8**

> So überliefern es die Shiekah. Daß er
> alles für Eure Zukunft tut, überliefert
> hauptsächlich Merz.

### 7077

Projekttext.

**Seite 1**

> Man nennt mich Sheik. Ich wurde von
> Mr. Bean trainiert.

### 7078

Projekttext.

**Seite 1**

> Das Masterschwert. Es ist das heilige
> Schwert. Und nur das heilige Schwert
> ist es wert.

### 7079

Projekttext.

**Seite 1**

> Du hast bereits drei Orte besucht.
> Und jetzt gibt's noch fünf weitere
> Orte. Die sind sogar noch krasser!

### 707A

Projekttext.

**Seite 1**

> Im Waldtempel wartet eine alte
> Freundin. Du bist ihr als Kind schon
> begegnet.

**Seite 2**

> Damals wirkte sie oft etwas müde.
> Sie hatte viel um die Ohren. Du
> solltest ihr helfen.

**Seite 3**

> Doch ohne weitere Ausrüstung
> erreichst Du den Tempel nicht.

**Seite 4**

> Suche in Kakariko nach einem Haken.
> Dort hat jemand vorgesorgt. Für die
> Zeit nach seinem Tod.

**Seite 5**

> Verstanden, [Spielername]? Eine
> alte Bekanntschaft. Laß Dich
> überraschen.

### 700F

Projekttext.
Sheik erneut angesprochen, Fanghaken fehlt noch.

**Seite 1**

> In Kakariko mußt Du einen alten
> Freund besuchen. Einen Freund, der
> aus dem Jenseits zurückgekehrt ist.

### 7010

Projekttext.
Sheik erneut angesprochen, Fanghaken vorhanden.

**Seite 1**

> Ich sehe, Du verfügst nun über den
> Fanghaken. Hast Du ihn Dir signieren
> lassen? Der gehörte mal einem
> großartigen Rennmeister.

## 3. Navis natürliche Story-Hinweise während des Waldkapitels

### 0120

Projekttext.
Einmaliger freiwilliger deutscher Story-Hinweis nach dem Master-Schwert. Übersteuert die normalen Hinweise, bis die eigene Gesehen-Markierung gesetzt ist.

**Seite 1**

> Warte mal, mir fällt das jetzt erst
> auf, aber warum war König Zora so
> mega langsam?

**Seite 2**

> Gott, ich hoffe, der Typ ist in dieser
> neuen Zukunft tot!

### 014E

Projekttext.
Natürlicher Navi-Hinweis ohne Fanghaken, sobald 0120 erledigt ist.

**Seite 1**

> Hey, weißt Du was? Wenn wir Glück
> haben, ist dieser alte Totengräber
> endlich krepiert.

**Seite 2**

> Der wollte Dir doch diesen
> Enterhaken überlassen, oder?

### 0150

Projekttext.
Natürlicher Navi-Hinweis mit Fanghaken, ohne Waldamulett; bei passenden Außenwelt-Hinweisskripten.

**Seite 1**

> Sieben Jahre sind vergangen. Für
> Salia war das keine kleine Pause. Ich
> mache mir Sorgen um sie und den
> Wald.

### 015F

Projekttext.
Allgemeiner Ersatztext. Im Waldtempel hat das Hinweisskript diesen Grundwert; daraus folgt kein zusätzlicher zeitgesteuerter Dialog nach jeder Raumwarnung.

**Seite 1**

> [Spielername], mir gefällt das hier
> immer weniger. Ich hoffe, daß wir
> dem Ursprung dieses ganzen Mists
> näherkommen.

## 4. Kakariko – Boris als Geist, Rennen und Fanghaken

### 5041

Projekttext.
Boris stellt sich beim ersten Ansprechen vor; nach dem Rennen getrennte Meldungen 502F und 502D/502E.

**Seite 1**

> Ah, ein Besucher. Sieben Jahre
> verändern ein Leben. Einst ging ich
> unter den Lebenden. Nun bin ich tot.

**Seite 2**

> Die Zeit nimmt uns alles.
> Gewohnheiten. Zukunftspläne.
> Irgendwann den eigenen Körper.

**Seite 3**

> Ich bin vorgestern beim Verlassen der
> Windmühle die Treppe runtergestürzt.
> Für einen alten Mann wie mich war
> das das Todesurteil.

**Seite 4**

> Wettrennen waren stets der Kern
> meiner Persönlichkeit. Boris, der
> größte Renner Hyrules!

**Seite 5**

> Das habe ich ständig erzählt. Jeder
> wußte es. Auch dieser Junge auf dem
> Friedhof hat es immer gesagt.

**Seite 6**

> Falls Du Dich nicht erinnerst: Es war
> wirklich ein fester Teil meines
> Charakters. Schon immer.

**Seite 7**

> Uga Paluga! Meine alte Catchphrase.
> Erinnerst Du Dich? Das habe ich
> früher immer gesagt.

**Seite 8**

> Renn noch einmal gegen mich! Dann
> bekommst Du meinen Enterhaken.
> Steht so im Testament.

**Seite 9**

> Den brauchst Du für den Waldtempel.
> Ohne den kommst Du da nicht rein.
> So. Jetzt rennen wir.

### 502F

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Native Rennzeit-Anzeige. [Rennzeit] ist der tatsächliche gemessene Wert.

**Seite 1**

> Die Zeit beträgt
> [Rennzeit]!

### 502D

Projekttext.
Nach dem ersten Rennen: Fanghaken noch nicht im Inventar.

**Seite 1**

> Noch einmal wollte ich auf irdischer
> Welt wandeln, um gegen Dich, meinen
> guten Freund, im Rennen anzutreten.

**Seite 2**

> Du hast gewonnen. Nimm nun Deinen
> Preis. Er soll Dir gute Dienste auf
> Deinem Abenteuer erweisen.

**Seite 3**

> Und wenn Du wiederkommst, dann
> renn gerne wieder gegen Deinen
> großen Rennsport-Boris-Kollegen an.
> Uga Paluga, sage ich da!

**Seite 4**

> Auf dem Rückweg geht es zur
> Windmühle. Paß an der Treppe auf.
> Ich spreche aus Erfahrung.

### 502E

Projekttext.
Alternative nach erneutem Rennen mit Fanghaken. Kein automatisch angehängter zweiter Monolog.

**Seite 1**

> Wieder da? Hat der Enterhaken
> geholfen? Und natürlich: Lust auf
> Rennsport? Mein uraltes
> Markenzeichen!

### 0036

Projekttext.

**Seite 1**

> Du hast den Fanghaken von
> Boris geerbt, der so manch
> ein Wettrennen gewonnen hat.

**Seite 2**

> Benutze ihn, um entfernte
> Objekte zu Dir zu holen oder
> um Dich an ein Objekt
> heranzuziehen.

**Seite 3**

> Halte [C] gedrückt und ziele
> mit [Control-Pad]. Läßt Du [C] los,
> schießt Du den Fanghaken ab.

## 5. Kokiri-Wald vor der Befreiung – alle erwachsenen Bewohner

### 1055

Projekttext.
 Kokiri-Typ CHILD_0; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Erstansprache; Wiederholungs-ID: 1056.

**Seite 1**

> Ich bin vielleicht ein Kokiri, aber doch
> kein Idiot??

**Seite 2**

> Das eine hat mit dem anderen
> überhaupt nichts zu tun.

### 1056

Projekttext.
 Kokiri-Typ CHILD_0; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Wiederholung bei erneutem Ansprechen nach 1055.

**Seite 1**

> Ich bin immer noch ein Kokiri. Und
> immer noch kein Idiot. Nur damit wir
> das geklärt haben.

### 105A

Projekttext.
 Kokiri-Typ CHILD_1; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Hey, soll ich Dir das Menuett des
> Waldes beibringen?

**Seite 2**

> Nee, haha, ich verarsch Dich nur.
> Haha! Laß Dich von mir nicht auf den
> Arm nehmen.

### 105D

Projekttext.
 Kokiri-Typ CHILD_2; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Erstansprache; Wiederholungs-ID: 105E.

**Seite 1**

> Der Deku-Baum läßt Grüße ausrichten.

**Seite 2**

> Und jetzt verpiss Dich, Fremder!

### 105E

Projekttext.
 Kokiri-Typ CHILD_2; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Wiederholung bei erneutem Ansprechen nach 105D.

**Seite 1**

> Der Deku-Baum läßt Grüße ausrichten.
> Und jetzt verpiss Dich, Fremder!

### 105B

Projekttext.
 Kokiri-Typ CHILD_3; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Direkte native Fortsetzung: 105C.

**Seite 1**

> Es gab mal so nen Typen, der hier
> wohnte. Der hieß [Spielername].

**Seite 2**

> Mann, bin ich froh, daß der nie
> gecheckt hat, daß ich ihm noch 50
> Rubine schulde.

### 105C

Projekttext.

**Seite 1**

> Falls Du [Spielername] siehst: Du
> hast mich nie getroffen. Und ich
> hatte nie 50 Rubine.

### 105F

Projekttext.
 Kokiri-Typ CHILD_4; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Was zur Hölle ist vor sieben Jahren
> mit dem Deku-Baum passiert?

**Seite 2**

> Sieben Jahre! Ich hab immer noch
> dran zu knabbern. Als ob der jetzt
> einfach tot ist.

**Seite 3**

> Und zwar seit sieben Jahren übrigens.
> Ich war auf hundert weitere
> eingestellt.

**Seite 4**

> Ich hatte eine coole Hütte. Einen
> entspannten Tag. Wie konnte das so
> eskalieren?

### 1057

Projekttext.
 Kokiri-Typ CHILD_5; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Der ganze Wald ist zwar total
> verkommen und voller Monster, aber
> wenigstens kommen die importierten
> Pfeile noch an. Werden jetzt im

**Seite 2**

> Laden verkauft.

### 1058

Projekttext.
 Kokiri-Typ CHILD_6; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Erstansprache; Wiederholungs-ID: 1059.

**Seite 1**

> Ein Mann, der sich Philipp Amthor
> nannte, kam hierher.

**Seite 2**

> Der wollte mit uns spielen. Ihh, Alter,
> was will denn dieser Opa hier??

**Seite 3**

> Ich dachte erst, der sucht
> [Spielername]. Aber nein. Der
> wollte ernsthaft mit uns spielen.

### 1059

Projekttext.
 Kokiri-Typ CHILD_6; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Wiederholung bei erneutem Ansprechen nach 1058.

**Seite 1**

> Philipp Amthor. Der wollte mit uns
> spielen. Ich faß es immer noch nicht.

### 104E

Projekttext.
 Kokiri-Typ CHILD_7; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Ich bin Fan von Rockmusik. Richtig
> sau gute Musik.

### 104F

Projekttext.
 Kokiri-Typ CHILD_8; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Direkte native Fortsetzung: 1050.

**Seite 1**

> Ich habe den Mann, der sich Philipp
> nennt, oft beobachtet. Ich stelle fest,
> er ist ein Loser. Und Charisma hat er
> auch nicht.

### 1050

Projekttext.
 Kokiri-Typ CHILD_8; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Falls Du ihn suchst: Die Villa von
> diesem Philipp Amthor findest Du an
> der Heiligen Lichtung, tief in den
> Verlorenen Wäldern.

### 1051

Projekttext.
 Kokiri-Typ CHILD_9; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Erinnerst Du Dich noch an den Lego
> Leucht-Geist?

### 1052

Projekttext.
 Kokiri-Typ CHILD_10; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Yeah, der Deku-Schild ist wohl zu
> klein für Sie geworden. Das liegt
> daran, daß Sie so riesige
> Monsterhände haben. Also, aus meiner

**Seite 2**

> Perspektive sind das Monsterhände.
> Ich bin mein ganzes Leben lang ein
> Kind gewesen.

### 1053

Projekttext.
 Kokiri-Typ CHILD_11; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.
Direkte native Fortsetzung: 1054.

**Seite 1**

> Oh, Sie fragen nach Salia? Die finden
> Sie in den Verlorenen Wäldern.

### 1054

Projekttext.
 Kokiri-Typ CHILD_11; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Jetzt ist nicht nur Salia
> verschwunden, sondern auch noch
> Mido. Was ist, wenn der Kokiri, der
> im Laden arbeitet, als nächstes

**Seite 2**

> verschwindet? Wo soll ich denn
> sonst meine Pfeile kaufen?

## 6. Verlorene Wälder – Mido vor dem Waldtempel

### 1060

Projekttext.
Midos erste Ansprache vor der Tempelbefreiung, bevor sein Lied-/Durchgangsereignis gesetzt wurde.
Erstansprache; Wiederholungs-ID: 1061.

**Seite 1**

> Sieben Jahre, [Spielername]. Und
> weißt Du was? Ich finde Dich immer
> noch scheiße. Manche Dinge bleiben.

### 1061

Projekttext.
Midos Wiederholungszustand vor der Tempelbefreiung.
Wiederholung bei erneutem Ansprechen nach 1060.

**Seite 1**

> Falls Du es vergessen hast,
> [Spielername]: Ich finde Dich
> immer noch scheiße. Auch sieben
> Jahre später.

**Seite 2**

> Mit König Zora bin ich schon
> verabredet: Wenn Friedrich Merz
> besiegt ist, gehen wir zusammen auf
> eine mögliche Siegesfeier.

**Seite 3**

> Du rettest Hyrule, ich gehe feiern.
> Jeder leistet seinen Beitrag.

### 1067

Projekttext.
Midos Reaktion auf Salias Lied; eigenes Ereignis im Gespräch.
Direkte native Fortsetzung: 106F.

**Seite 1**

> Oh Mann, ich faß es nicht! Wolltest
> Du mich gerade ernsthaft mit der
> Blutmagie kontrollieren? Nein? Oh.
> Dann habe ich Dich falsch

**Seite 2**

> eingeschätzt, tut mir leid. Okay, bitte
> befreie diesen Wald, okay?

### 106F

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Direkte native Fortsetzung: 1068.

**Seite 1**

> Nun gut...
> Ich vertraue Dir.

### 1068

Projekttext.
Mido nach dem Lied-/Durchgangsereignis, vor der Tempelbefreiung.

**Seite 1**

> Und Du warst echt in einem Wal? In
> einem Wal drin? Das ist ja verrückt!
> Aber dann scheinst Du ja auf einem
> guten Weg zu sein. Ich habe Dich

**Seite 2**

> unterschätzt.

**Seite 3**

> Wenn Friedrich Merz besiegt ist, bin
> ich mit König Zora für die Siegesfeier
> verabredet. Nur damit Du Bescheid
> weißt.

## 7. Salia per Okarina vor dem Waldtempel

### 016A

Projekttext.
Salia per Okarina als Erwachsener, solange das Waldamulett fehlt. Salia ist weiterhin Salia; die Krabbelminen-Frau übernimmt ausschließlich die Waldweisen-Rolle.

**Seite 1**

> [Spielername], im Waldtempel ist
> Böses im Busch.

**Seite 2**

> Der Waldtempel gehört einem reichen
> Fatzke namens Philipp Amthor.

**Seite 3**

> Ich gehe dort hin, um herauszufinden,
> was hier fischig ist.

**Seite 4**

> Wir sehen uns bestimmt wieder. Zu
> 100 Prozent! Ich wüßte nicht, warum
> das nicht passieren sollte.

## 8. Heilige Lichtung – Navi, Sheik und das Menuett des Waldes

### 0107

Projekttext.
Automatische Gangwarnung auf der Heiligen Lichtung; kein beliebig oft angebotener Story-Ruf.

**Seite 1**

> Enger Gang. Laß Dir an der Ecke
> nicht schon wieder eine verpassen.

**Seite 2**

> Mit [Z] richtest Du Dich aus und
> blickst geradeaus in den Gang.

**Seite 3**

> Halte [Z] und gehe seitwärts um die
> Ecke. Denk ausnahmsweise vor
> Deinem Schädel mit.

### 106C

Projekttext.

**Seite 1**

> Der Wald ist grün, und Mr. Bean war
> sehr kühn. Er gab sein Leben, um
> dieses Land zu schützen.

**Seite 2**

> Friedrich Merz ist die ganze Zeit nur
> am Grützen. Hier im Wald wächst so
> mancher Pilz. Philipp Amthor ist ein
> schwacher Knilch.

**Seite 3**

> Die Welt ist zweifelsohne voller
> Schönheit, [Spielername].

**Seite 4**

> Und eine dieser Schönheiten ist
> dieser Song, den ich geschrieben
> habe. Das Menuett des Waldes.

**Seite 5**

> Im Tempel wartet eine alte Freundin
> auf Dich. Du bist ihr schon mal
> begegnet, und die Wiedervereinigung
> wird süß.

### 0073

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Du hast das
> Menuett des Waldes
> erlernt!

### 106D

Projekttext.
Gemeinsam verwendeter Abschlußsatz: erscheint nach dem Menuett UND nach dem Bolero. Im Waldabschnitt bereits vollständig aufgeführt; derselbe aktuelle Wortlaut wird hier erneut benutzt, kein eigener neuer Feuer-Abschied.

**Seite 1**

> [Spielername]... Deine alte Freundin
> wartet. Und ich meine nicht mich.

## 9. Waldtempel – örtliche Navi-Hinweise und Fackeln

### 0105

Projekttext.
Gemeinsamer anvisierbarer Zeitblock-Hinweis: Waldtempel sowie Feuertempel-Räume 1 und 11. Oben bereits vollständig enthalten.
Örtlicher Navi-Hinweis: Feuertempel, Raum 1, Feuertempel, Raum 11, Waldtempel, Raum 2.

**Seite 1**

> Hey, da ist mal wieder einer von
> diesen Minecraft-Blöcken.

### 018C

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 2.

**Seite 1**

> Ey Junge, sag jetzt nicht, daß wir
> diese Geister durch den ganzen Laden
> hier verfolgen müssen. Ey, bitte nicht.

### 018D

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 2.

**Seite 1**

> [Spielername], Okay, immerhin
> brennt jetzt wieder eine von den
> Fackeln. Wir arbeiten uns langsam
> vor. Ey, das wird noch lange dauern.

### 018F

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 11.

**Seite 1**

> Also, ich weiß ja nicht, ob Du es
> schon gemerkt hast, aber auf dem
> Boden sind Pfeile, ne? Just saying.

### 0190

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 19.

**Seite 1**

> Boah, gut, daß ich fliegen kann. Sonst
> hätte ich mich jetzt eingekotzt.

### 0191

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 19, Waldtempel, Raum 20.

**Seite 1**

> Ich präsentiere: die nervigsten
> Gegner in diesem ganzen Abenteuer.

### 0192

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 19.

**Seite 1**

> Boah, hoffentlich ist da Geld drin.

### 0194

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 12, Waldtempel, Raum 13, Waldtempel, Raum 16.

**Seite 1**

> Okay, langsam sehe ich, daß wir das
> Rätsel lösen. Die Fackel haben wir
> doch am Eingang dieses Tempels
> gesehen, oder?

### 0195

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 12, Waldtempel, Raum 13, Waldtempel, Raum 16.

**Seite 1**

> Nicht lang fackeln.

### 0197

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 14.

**Seite 1**

> Meinst Du, wir können den Schalter
> irgendwie wieder entfrieren? Wenn
> wir da irgendwie... Keine Ahnung. Ich
> weiß auch nicht.

### 0198

Projekttext.
Örtlicher Navi-Hinweis: Waldtempel, Raum 15.

**Seite 1**

> [Spielername], Junge, was ist das
> hier für eine Todesfalle? Die Decke
> fällt herab!

## 10. Waldtempel – Feen-Bogen und neue Begegnungen

### 0031

Projekttext.

**Seite 1**

> Das ist der Feenbogen. Navis
> Kollegen haben den gebaut.
> Die besten Feenbogenbauer in
> ganz Hyrule.

**Seite 2**

> Drücke [C], um den Bogen
> zu benutzen. Halte [C] und
> ziele mit [Control-Pad]. Laß [C] los,
> um Pfeile abzuschießen!

### 6087

Projekttext.
Fanboy im Waldtempel; eigener Gesprächsort, getrennt von Chum Chum.

**Seite 1**

> Hey, hey, hey! Ich bin's, Fanboy!
> Chum Chum und ich haben es uns zur
> Aufgabe gemacht, gegen Friedrich
> Merz vorzugehen!

**Seite 2**

> Plan A: Merz besiegen! Plan B: erst
> mal einen Frosty Freezy Freeze
> trinken! Ich habe schon dreimal Plan
> B durchgeführt. Es läuft SUPER!

**Seite 3**

> Chum Chum bewacht den anderen
> Gang. Zwei Helden, doppelte
> Sicherheit! Sag ihm, er soll unsere
> Ausrüstung nicht essen!

### 6088

Projekttext.
Chum Chum im Waldtempel; eigener Gesprächsort, getrennt von Fanboy.

**Seite 1**

> Grüße, hier ist Chum Chum am
> Apparat! Fanboy ist echt der coolste
> Typ! Zusammen werden wir Friedrich
> Merz besiegen. Denn wahre Helden

**Seite 2**

> kämpfen nun mal gegen böse
> Superschurken!

**Seite 3**

> Fanboy hat gesagt, ich soll diesen
> Gang bewachen. Das mache ich seit
> Stunden. Der Gang hat sich keinen
> Zentimeter bewegt. VERDÄCHTIG!

**Seite 4**

> Sobald Merz auftaucht, schlage ich
> Alarm! Ich kann so laut schreien, daß
> er seine eigene Politik nicht mehr
> hört. Das hilft bestimmt!

### 0109

Projekttext.
Zielerfassung der herumliegenden Majora-Maske im Tempelgang; keine automatische Ansprache am Tempelanfang.

**Seite 1**

> Junge, was zum Teufel? Dieser
> Maskenhändler meinte doch, die
> Maske wäre mega wichtig und selten.

**Seite 2**

> Warum liegt das Teil hier einfach so
> rum? Was soll sowas??

## 11. Philipp Amthor – Begrüßung, Navi-Zielerfassung und Merz nach dem Sieg

### 209B

Projekttext.
Amthors hinzugefügte Begrüßung nach der Gesichtsenthüllung und vor der Bosseinblendung.

**Seite 1**

> Sooo, genug Schabernack!

### 062B

Projekttext.
Navi-Bossbeschreibung während der Reiter-/Gemäldephase.

**Seite 1**

> Philipp Amthor. Ist der 15 oder 55?
> Keine Ahnung. Schieß den Scheißkerl
> vom Pferd, wenn er aus dem Bild
> kommt!

### 061A

Projekttext.
Navi-Bossbeschreibung während der zweiten Kampfphase.

**Seite 1**

> Philipp Amthor. Ich habe keine
> Ahnung, ob der jetzt 15 oder 55 ist.

**Seite 2**

> Der sieht aus, als müßte er für
> Mathe lernen und seinen Rentenantrag
> ausfüllen. Schlag ihm seinen Scheiß
> zurück!

### 108E

Projekttext.
Merz spricht nach Amthors Niederlage; nicht Amthor selbst.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(60), BOX_BREAK_DELAYED(60), FADE(60). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Du bist stärker, als ich dachte. Dabei
> hast Du sieben Jahre lang gefaulenzt!

**Seite 2**

> Philipp Amthor besiegen kann jeder.
> Der Typ ist eine Flasche.

**Seite 3**

> Deshalb werde ich ihn nun in den
> Hades verbannen. Er hat seinen
> Kanzler enttäuscht!

## 12. Waldweise – Krabbelminen-Frau und Waldamulett

### 106A

Projekttext.
Die Krabbelminen-Frau erscheint als Waldweise nach dem Sieg.

**Seite 1**

> Hey, so sehen wir uns wieder.

**Seite 2**

> Der ganze Krabbelminen-Schuppen ist
> irgendwann zusammengebrochen, weil
> Friedrich Merz Hyrule kaputtgespart
> hat.

**Seite 3**

> Jetzt ist da alles komplett Schrott
> und voller Zombies.

**Seite 4**

> Nicht wegen böser Magie. Ne, ne. Der
> hat das mit seinen Reformen
> vollkommen versaut.

**Seite 5**

> Anyway, die alte Krabbelminenbude
> ist zusammengebrochen und hat
> meinen Schädel gecrusht.

### 108F

Projekttext.
Fortsetzung der Waldweisen-Szene, einschließlich der vorhandenen festen Textpause.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(30). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Also, ich sag's mal so: Wenn Du
> irgendwie in die Vergangenheit reisen
> könntest oder sowas ...

**Seite 2**

> Rein theoretisch.

**Seite 3**

> ... und mich warnen könntest, dann
> würd ich mir 'nen anderen Job
> suchen.

**Seite 4**

> Ist eher ungeil, tot zu sein. Honestly.

### 1090

Projekttext.

**Seite 1**

> Jetzt bin ich halt die Weise des
> Waldes. Hatte ja sonst nichts mehr
> vor. Bin tot.

**Seite 2**

> Hier, nimm das Waldamulett. Friedrich
> Merz muß weg. Ich hab mit dem
> Typen noch 'ne Rechnung offen.

### 003E

Projekttext.

**Seite 1**

> Das Waldamulett! Die
> Krabbelminen-Frau gibt Dir
> ihre Kraft!

### 106B

Projekttext.
Kurzer zeitgesteuerter Abschied der Waldweisen.
Zeitgesteuerte Textcodes: FADE(80). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Tot sein ist echt ungeil.

## 13. Zurück im Kokiri-Wald – Tripple T erscheint und erklärt die Herkunft

### 1062

Projekttext.
Tripple Ts erster Text nach dem Auftauchen; danach folgen weitere native Abschnitte und ein Rückblick.

**Seite 1**

> Jo jo jo jo jo, ich bin es! Tripple T
> ist am Start.

**Seite 2**

> Meine Güte, ich hab echt lang
> gewartet. Aber endlich ist
> Deku-Baum-Zeit.

**Seite 3**

> Ich bin der neue Deku-Baum. Das ist
> mein neuer Job, mein neues Ding.

**Seite 4**

> Tung Tung Tung Sahur ist aller Zeit
> bereit und stets von Sorgen befreit.

**Seite 5**

> Hahaha! Jetzt kippen wir den
> Fun-Schalter des Spaßmodus mal auf
> 0 und werden ernst.

### 1063

Projekttext.

**Seite 1**

> Friedrich Merz hat den Wald nicht
> einfach vergessen. Er hat die Tempel
> absichtlich verkommen lassen.

**Seite 2**

> Erst alles kaputtsparen und dann
> sagen, die Bewohner hätten sich nicht
> genug angestrengt.

**Seite 3**

> Die Kokiri altern nicht. Du schon.
> Deine alten Freunde erkennen Dich
> deshalb kaum wieder.

### 1064

Projekttext.

**Seite 1**

> Jetzt wird's kurz persönlich: Du bist
> kein Kokiri. Du bist ein Hylianer!

**Seite 2**

> Der alte Deku-Baum hat Dich als Kind
> aufgenommen. Daher bist Du mit den
> Kokiri aufgewachsen.

**Seite 3**

> Und nun brauchen wir Dich, um
> grausame Pläne zu verhindern.

### 1065

Projekttext.
Zeitgesteuerter Rückblick. Die fünf festen Seitenzeiten bleiben erhalten.
Zeitgesteuerte Textcodes: BOX_BREAK_DELAYED(90), BOX_BREAK_DELAYED(90), BOX_BREAK_DELAYED(90), BOX_BREAK_DELAYED(90), FADE(90). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Friedrich Merz ging zu den Goronen,
> angeblich für den Kohleabbau.

**Seite 2**

> Doch er hatte etwas viel, viel
> Schlimmeres im Sinn.

**Seite 3**

> Dort wurde auch Uranerz für eine
> Massenvernichtungswaffe abgebaut.

**Seite 4**

> Geh zu den Goronen und befreie den
> Forscher!

**Seite 5**

> Er wird gezwungen, an diesem Projekt
> zu arbeiten.

### 1066

Projekttext.
Rückkehr nach dem Rückblick; ebenfalls möglicher Wiederholungszustand vor der abschließenden Fortschrittsmarkierung.

**Seite 1**

> Begib Dich nun zum Todesberg,
> [Spielername]. Dort im Feuertempel
> wird der Projektleiter von Projekt
> Atom-Donnerblume festgehalten.

**Seite 2**

> Friedrich Merz darf niemals so weit
> kommen!

**Seite 3**

> Und keine Sorge, Tripple T paßt hier
> auf.

**Seite 4**

> Tung Tung Tung Tung Tung Tung Tung
> Tung Tung Tung Sahur!

### 1078

Projekttext.
Tripple Ts spätere Wiederholungsvariante nach dem Herkunfts-/Abschlußereignis.

**Seite 1**

> Hey, hey, Kollege, ich bin's, Tripple T!
> Wie geht's voran? Hast Du schon das
> mit der Bombe gelöst?

## 14. Nach dem Waldtempel – Mido und Salia per Okarina

### 1070

Projekttext.
Mido nach der Tempelbefreiung, erste Ansprache.
Direkte native Fortsetzung: 1071.

**Seite 1**

> Oh wow, Du hast es wirklich
> geschafft, [Spielername]! Ehrlich
> gesagt glaube ich nicht, daß der
> Deku-Baum damals wegen Dir

**Seite 2**

> gestorben ist.

**Seite 3**

> Du bist zwar arrogant, und ich kann
> Dich nicht leiden, aber Salia hatte
> immer großes Vertrauen in Dich.

### 1071

Projekttext.
Mido nach der Tempelbefreiung, Wiederholung.
Direkte native Fortsetzung: 10D6.

**Seite 1**

> Du kannst gehen. Ich werde
> gemeinsam mit Tripple T diesen Wald
> beschützen.

### 10D6

Projekttext.

**Seite 1**

> Ich sehe vielleicht aus wie ein Kind,
> aber ich werde mich von Tung Tung
> Tung Sahur ausbilden lassen.

### 016B

Projekttext.
Salia per Okarina nach dem Waldamulett und vor den folgenden Amuletten. Kein zusätzlicher Dialog der Waldweisen.

**Seite 1**

> Jaa, keine Sorge, [Spielername],
> mir geht's prächtig.

**Seite 2**

> Ich bin auf ne coole Reise gegangen,

**Seite 3**

> weil Hyrule mir zu konservativ wurde.

## 15. Kokiri-Wald nach der Befreiung – neue Bewohnertexte

### 1072

Projekttext.
 Kokiri-Typ CHILD_0; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Ich bin vielleicht ein Kokiri, aber doch
> kein Idiot??

### 1073

Projekttext.
 Kokiri-Typ CHILD_1; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Hey, soll ich Dir das Menuett des
> Waldes beibringen?

**Seite 2**

> Nee, haha, ich verarsch Dich nur. Laß
> Dich von mir nicht auf den Arm
> nehmen.

### 1074

Projekttext.
 Kokiri-Typ CHILD_2; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Der Deku-Baum läßt Grüße ausrichten.
> Und jetzt verpiss Dich, Fremder!

### 1075

Projekttext.
 Kokiri-Typ CHILD_3; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Es gab mal so nen Typen namens
> [Spielername]. Dem schulde ich
> noch 50 Rubine.

**Seite 2**

> Mann, bin ich froh, daß der das nie
> gecheckt hat.

### 1076

Projekttext.
 Kokiri-Typ CHILD_4; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Der Wald erholt sich. Schön. Der alte
> Deku-Baum ist trotzdem seit sieben
> Jahren tot.

**Seite 2**

> Ich komm darauf noch nicht klar.
> Hundert Jahre hab ich gesagt.
> HUNDERT.

### 1077

Projekttext.
 Kokiri-Typ CHILD_6; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Der Wald ist wieder ruhig. Hoffentlich
> kommt dieser Opa Amthor jetzt nicht
> wieder her und will mit uns spielen.

### 1079

Projekttext.
 Kokiri-Typ CHILD_7; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Ich bin Fan von Rockmusik. Richtig
> sau gute Musik.

### 107A

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
 Kokiri-Typ CHILD_8; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Seit es im Wald wieder
> sicher ist, glaube ich,
> daß [Spielername] zurückkehren 
> wird!

### 107B

Projekttext.
 Kokiri-Typ CHILD_9; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Erinnerst Du Dich noch an den Lego
> Leucht-Geist?

### 107C

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
 Kokiri-Typ CHILD_10; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner. Kokiri-Typ CHILD_11; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Sicher wird [Spielername] eines 
> Tages zurückkommen...

## 16. Übergang zum nächsten Kapitel – Navis nächster Story-Hinweis

### 0151

Projekttext.
Nächster natürlicher Story-Hinweis mit Waldamulett, solange das Feueramulett fehlt. Als Übergang aufgenommen.

**Seite 1**

> Ey, ich werde wahnsinnig. Jetzt hat
> der Scheiß Friedrich Merz auch noch
> den Todesberg versaut!

**Seite 2**

> Das ist echt schlimm. Mann, da sieht
> man die Welt mit anderen Augen,
> was?

## 17. Goronia als Erwachsener – Darunias Sohn und das feuerfeste Gewand

### 3030

Projekttext.
Darunias Sohn vor dem Anhalten seiner Rollbewegung; spätere Dialoge sind getrennte Zustände.

**Seite 1**

> Hau ab! Friedrich Merz hat uns schon
> genug eingebrockt. Ich brauch nicht
> noch so einen Verrückten!

### 3031

Projekttext.
Reaktion auf das Stoppen seiner Rollbewegung durch die Bombe; danach 3032 beim Gespräch.

**Seite 1**

> AAAAAAAAAH! AUA! WAS ZUR
> HÖLLE?!

**Seite 2**

> WARUM HAST DU EINE BOMBE
> GEGEN MICH GEWORFEN, DU
> VERRÜCKTER?!

**Seite 3**

> WARUM DACHTEST DU, DAS SEI
> OKAY?!

**Seite 4**

> Und jetzt willst Du auch noch meinen
> Namen wissen? Der ist mir peinlich.

**Seite 5**

> Das ist der dümmste Name der Welt.
> So ein schrottiger Quatschname!
> Was hat mein Vater sich dabei
> gedacht?!

**Seite 6**

> Na gut... Ich heiße [Spielername].

### 3032

Projekttext.
Erste ausführliche Erklärung nach dem Anhalten. Native Fortsetzung bei Bestätigung zur Auswahl 3034.
Direkte native Fortsetzung: 3033.

**Seite 1**

> Ohhh... Äh. Wie war DEIN Name?

**Seite 2**

> Auch [Spielername]? Ups.

**Seite 3**

> Dann hab ich gerade Deinen Namen
> beleidigt. Und zwar ziemlich
> ausführlich.

**Seite 4**

> Nichts für ungut! Ist ein besonderer
> Name, nicht?

**Seite 5**

> Vater hat mich nach Dir benannt.
> Das hätte er mir vielleicht VORHER
> erklären sollen.

**Seite 6**

> Tut mir leid, [Spielername].
> Wirklich.

**Seite 7**

> Mein Vater hat mir die Legende
> erzählt, daß Du damals zusammen mit
> seiner Hilfe den Zugang zu Dodongos
> Höhle wieder freigemacht hast.

**Seite 8**

> Friedrich Merz hat alle Goronen zur
> Arbeit im Feuertempel gezwungen.

**Seite 9**

> Dort sollten sie Uranerz für seine
> Waffe abbauen.

**Seite 10**

> Nicht nur das: Im Feuertempel wird
> auch ein großer Forscher
> festgehalten. Sein Name ist Wallace.

**Seite 11**

> Friedrich Merz zwang ihn, für ihn zu
> arbeiten. Andernfalls würde er einen
> brutalen Drachen auf Kakariko hetzen.

**Seite 12**

> Wallace hatte keine andere Wahl.

### 3033

Projekttext.
Bedingte Zwischenreaktion; führt ebenfalls zur Auswahl 3034. Kein zusätzliches neues Thema.

**Seite 1**

> Es ist alles so furchtbar. Wir sind
> die Goronen. Wir stehen für Frieden,
> nicht für Zerstörung!

### 3034

Projekttext.
Auswahl über den Drachen oder die Goronen: vor dem ersten vollständigen Drachengespräch kann die Wallace-Antwort noch zu 3033 führen; nach 3035 führt sie zu 3036.

**Seite 1**

> Ich sag Dir alles, was ich weiß.

**Seite 2**

> Worüber willst Du reden?
>
> Über den Drachen
> Über Wallace

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 3035

Projekttext.
Drachen-Thema; setzt bei Bestätigung die native Gesprächsmarkierung und führt zu 3034 zurück.
Direkte native Fortsetzung: 3033.

**Seite 1**

> Volvagia heißt der Drache. Er lebt im
> Feuertempel und war einst ein
> wunderschönes Geschöpf.

**Seite 2**

> Friedrich Merz hat es jedoch auch
> geschafft, das zu versauen. Jetzt ist
> der Drache blutdürstig und ziemlich
> gefährlich. Und er spuckt Feuer.

**Seite 3**

> Es gibt nur einen Mann, der Volvagia
> aufhalten kann: Wallace.

**Seite 4**

> Das hat Friedrich Merz nicht gefallen.
> Deswegen hat er Wallace sein
> Equipment weggenommen: einen
> besonderen Hammer, der jetzt im

**Seite 5**

> Feuertempel versteckt ist.

**Seite 6**

> Mein Vater ist dorthin gegangen, um
> an den Wallace-Hammer zu gelangen.

### 3036

Projekttext.
Wallace-Antwortzweig: Forschung bei den Goronen, Donnerblumen, Merz und Gewandübergabe. Beim Schließen wird die Goronen-Rüstung angeboten; Kauf-/Belohnungslogik unverändert.

**Seite 1**

> Wallace kam einst zu uns, erzählte
> mir mein Vater, um mehr über das
> Volk der Goronen zu lernen. Wie wir
> hier in diesem Klima überleben und

**Seite 2**

> wie unser Steinmetabolismus
> funktioniert.

**Seite 3**

> Wallace zeigte sich ebenfalls
> interessiert an unseren nativen
> Gewächsen, den Donnerblumen. Die
> kennst Du ja. Das sind Pflanzen, die

**Seite 4**

> wie eine Bombe explodieren.

**Seite 5**

> Friedrich Merz bekam davon Wind und
> engagierte Wallace, um die ultimative
> Waffe zu konstruieren.

**Seite 6**

> Du mußt Wallace da rausholen,
> [Spielername]! Nimm dafür dieses
> Gewand. Er hat es selbst basierend
> auf seiner Forschung entwickelt.

### 0050

Projekttext.
Erhalt der feuerfesten, orangefarbenen Goronen-Rüstung. Text und Farbänderung sind bereits eingebaut.

**Seite 1**

> Die Goronen-Rüstung! Wallace
> hat die erfunden. Sie schützt
> Erwachsene vor extremer
> Hitze.

### 3037

Projekttext.
Erste Ansprache des kleinen Goronen mit Goronen-Rüstung und ohne Feueramulett.
Erstansprache; Wiederholungs-ID: 3038.

**Seite 1**

> Ich dachte immer, es wäre spannend,
> wenn ich ganz Goronia für mich
> selbst hätte, [Spielername]. Aber
> jetzt ist niemand hier, der mit mir

**Seite 2**

> spielen kann.

**Seite 3**

> Deshalb spiele ich mit mir selbst.
> Warte, das hat sich gerade ein
> bißchen komisch angehört.

**Seite 4**

> Ich habe mich gerade wie ein Loser
> angehört, der den ganzen Tag Doodle
> Jump auf seinem Handy spielt. Das
> meinte ich damit.

### 3038

Projekttext.
Wiederholung mit Goronen-Rüstung und ohne Feueramulett.
Wiederholung bei erneutem Ansprechen nach 3037.

**Seite 1**

> Der Eingang zum Feuertempel ist im
> Büro meines Vaters hinter der
> Statue. Dort, wo er damals stand, als
> Du sein Blut kontrolliert hast.

**Seite 2**

> Das hat er mir auch erzählt. Total
> verrückt.

## 18. Todeskrater – Hitze, Sheik und der Bolero des Feuers

### 3040

Projekttext.
Allgemeine zeitgesteuerte Hitze-Warnung; kann an passenden Stellen vor dem sicheren Schutz erscheinen.
Zeitgesteuerte Textcodes: FADE(60). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> [Spielername], was machst Du
> denn? Wenn wir uns hier weiter
> aufhalten, werden wir in Flammen
> aufgehen!

### 303E

Projekttext.
Sheiks Auftritt im Todeskrater vor dem Erlernen des Bolero des Feuers.

**Seite 1**

> Hier ist alles voller Feuer, und der
> Einkauf ist echt teuer.

**Seite 2**

> Wallace ist der Mann, den Du suchst.
> Todesberg ist der Flug, den Du
> buchst.

**Seite 3**

> Mr. Bean war ein großer Krieger. Ich
> steig gleich wieder in den Flieger.

**Seite 4**

> Und nun lerne den nächsten
> Teleport-Song: den Bolero des Feuers.

**Seite 5**

> Dann mußt Du nicht wieder den
> ganzen Weg hierher latschen und so.

### 0074

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Du hast den
> Bolero des Feuers
> erlernt!

### 088B

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Reine Okarina-Hintergrundanzeige mit PERSISTENT und BACKGROUND. Kein sprechbarer Satz; leerer Wortlaut ist beabsichtigt.

**Seite 1**


Text 106D ist oben bereits vollständig enthalten.

## 19. Feuertempel – Darunia vor seinem Vorstoß zum Drachen

### 3039

Projekttext.
Darunia am Anfang des Feuertempels. Er ist in dieser Begegnung noch Darunia; Wallace übernimmt die spätere Feuerweisen-Rolle.

**Seite 1**

> Ich werde wahnsinnig,
> [Spielername]! Aus dem
> Drei-Käse-Hoch ist jetzt ein
> Neun-Käse-Hoch geworden. Es ist

**Seite 2**

> sieben Jahre her, und Du bist so in
> die Höhe gewachsen!

**Seite 3**

> Merz hat mich gezwungen, mein
> eigenes Volk anzuleiten, hier Bergbau
> für seine grauenvolle Bombe zu
> betreiben.

**Seite 4**

> Auch Wallace ist hier. Er war mir
> immer ein guter Freund. Wir haben
> immer gerne zusammen Käse
> gegessen. Ich habe den Käse dann auf

**Seite 5**

> Steinen gegessen, weil ich ein Gorone
> bin.

**Seite 6**

> Und jetzt wird es endlich Zeit für die
> Rebellion! Hilf mir, die Männer und
> Frauen meines Volkes zu befreien. Ja,
> es gibt auch Goronen-Frauen. Was

**Seite 7**

> dachtest Du denn?

**Seite 8**

> Während Du Dich um Wallace
> kümmerst, werde ich schon mal meine
> anderen Männer suchen und von ihrer
> Tätigkeit erlösen.

**Seite 9**

> Ich bitte Dich: Bewahre Goronia und
> den Rest dieses Landes vor einem
> Super-GAU!

**Seite 10**

> Merz bedroht Hyrule mit
> Abschreckungslärm, mit Superwaffen,
> Neutronen und Tod.

**Seite 11**

> Das ist die moderne Inquisition gegen
> Dich und die Goronen-Union. Wir
> sehen uns!

## 20. Feuertempel – sämtliche örtlichen Navi-Hinweise

Text 0105 ist oben bereits vollständig enthalten.

### 01A3

Projekttext.
Navi: örtlicher freiwilliger Hinweis bei den rollenden Felsen, Raum 5.
Örtlicher Navi-Hinweis: Feuertempel, Raum 5.

**Seite 1**

> [Spielername], boah Junge, hörst
> Du diese Musik im Hintergrund? Ich
> weiß jetzt nicht genau, was das hier
> implizieren soll.

### 01A5

Projekttext.
Navi: anvisierbarer Hinweis mit Aussicht auf Darunias Raum, Raum 10.
Örtlicher Navi-Hinweis: Feuertempel, Raum 10.

**Seite 1**

> Hey, haben wir hier in der Nähe nicht
> den Alten da getroffen?

### 01A7

Projekttext.
Navi: örtlicher freiwilliger Hinweis bei der Statue, Raum 13.
Örtlicher Navi-Hinweis: Feuertempel, Raum 13.

**Seite 1**

> Oh Junge, nicht schon wieder eine
> von diesen beschissenen häßlichen
> Statuen.

**Seite 2**

> Wenn ich Augen hätte, bräuchte ich
> jetzt Bleichmittel, um die zu reinigen.

**Seite 3**

> Ich habe übrigens Augen. Man sieht
> sie nur nicht.

**Seite 4**

> Ich habe eine ganz interessante
> Feengestalt. Auch wenn Du mich vor
> allem als leuchtenden Ball
> wahrnimmst.

**Seite 5**

> Aber ich habe so was wie
> Fotorezeptoren. Ich sehe schon, was
> hier abgeht, ne?

**Seite 6**

> Ich bin jetzt nicht blind oder so. Das
> wollte ich nur mal klargestellt haben.

### 01A9

Projekttext.
Navi: automatische Warnung am verrosteten Schalter, Räume 10 und 11; beide verwenden denselben Schalterindex 19. Keine zwei garantiert nacheinander abgespielten Dialoge.
Örtlicher Navi-Hinweis: Feuertempel, Raum 10, Feuertempel, Raum 11.

**Seite 1**

> Ja Junge, warum überrascht mich das
> nicht, daß hier auch wieder alles
> kaputtgespart wurde?

**Seite 2**

> Der Schalter ist ja komplett hinüber.
> Toll, Alter.

## 21. Gefangene Goronen – Ansprache, Befreiung und alle tatsächlich platzierten Ratschläge

### 3051

Projekttext.
Normaler Gorone bei noch geschlossener Zelle. Wallace hat hierfür stattdessen 209E.

**Seite 1**

> Man kann diese Steine nicht essen.
> Mir wird nur schlecht von ihnen, und
> ich schmecke Metall in meinem Mund.

### 3071

Projekttext.
Gemeinsamer Befreiungs-Auftakt nach Öffnen einer Zelle; beim Bestätigen folgt genau der zu diesem Gefangenen gehörende Text. Nicht sämtliche Ratschläge hintereinander.

**Seite 1**

> Es ist endlich Zeit zurückzuschlagen!

### 3052

Projekttext.
 Tatsächlich platzierter Gefangener in Raum 17, Zellenschalter 9. Folgt bei diesem Goronen nach 3071.

**Seite 1**

> Es wird Zeit, daß die Goronen sich
> Goronia zurückholen. Merz, leck Eier!

### 306A

Projekttext.
 Tatsächlich platzierter Gefangener in Raum 23, Zellenschalter 5. Folgt bei diesem Goronen nach 3071.

**Seite 1**

> Mir gefällt Dein orangenes Gewand.
> Ich kenne den Typen, der das Ding
> erfunden hat. Ziemlich cooler Kerl!

### 306B

Projekttext.
 Tatsächlich platzierter Gefangener in Raum 4, Zellenschalter 4. Folgt bei diesem Goronen nach 3071.

**Seite 1**

> Du hast mich gerettet! Jetzt kann
> ich endlich zu meiner Frau und
> meinen Kindern zurückkehren. Meinen
> Goronen-Kindern.

**Seite 2**

> Die sind relativ schnell ausgewachsen,
> falls Du mal ein Goronenkind siehst.
> Die werden relativ schnell erwachsen.
> Das ist bei uns einfach so.

**Seite 3**

> Rein visuell meine ich natürlich. Vom
> Geist her sind die immer noch relativ
> kindisch drauf. Sind ja auch Kinder.

### 306C

Projekttext.
 Tatsächlich platzierter Gefangener in Raum 22, Zellenschalter 2. Folgt bei diesem Goronen nach 3071.

**Seite 1**

> Möge uns das Feuer dieses Tempels
> zum Siege gereichen, um auch
> Friedrich Merz' letzte Haare zu
> verbrennen!

### 306D

Projekttext.
 Tatsächlich platzierter Gefangener in Raum 5, Zellenschalter 10. Folgt bei diesem Goronen nach 3071.

**Seite 1**

> Als Dank für meine Befreiung verrate
> ich Dir etwas: Merz ist ein geiziges,
> gieriges Gerippe.

**Seite 2**

> Das ist kein Geheimnis. Das ist ein
> Fakt.

### 306E

Projekttext.
 Tatsächlich platzierter Gefangener in Raum 2, Zellenschalter 8. Folgt bei diesem Goronen nach 3071.

**Seite 1**

> Ich war selbst daran interessiert, die
> ultimative Waffe zu konstruieren.
> Aber Merz hat es zu weit getrieben.
> Deswegen weise ich jede Schuld von

**Seite 2**

> mir.

### 306F

Projekttext.
 Tatsächlich platzierter Gefangener in Raum 11, Zellenschalter 11. Folgt bei diesem Goronen nach 3071.

**Seite 1**

> Jetzt erkenne ich, daß das
> Wettrüsten zu nichts Gutem führt.

### 3070

Projekttext.
 Tatsächlich platzierter Gefangener in Raum 20, Zellenschalter 1. Folgt bei diesem Goronen nach 3071.

**Seite 1**

> Danke, daß Du mich befreit hast. Laß
> mich Dir ein Geheimnis anvertrauen:
> Manchmal rolle ich mich zusammen,
> um mich selbst als Bowlingkugel zu

**Seite 2**

> verwenden.

## 22. Wallace im Feuertempel – vor und nach dem Öffnen seiner Zelle

### 209E

Projekttext.
Wallace in Raum 5, bevor sein Zellenschalter aktiviert wurde.

**Seite 1**

> Oh, hi, lad! Wallace hier. Die Zelle
> ist von außen verriegelt. Da haben
> wir den Käse. Leider nur im
> übertragenen Sinne.

**Seite 2**

> Könntest Du den Schalter für die
> Zelle suchen? Ich muß hier raus,
> bevor aus meinem Gouda Fondue
> wird!

### 209D

Projekttext.
V22: Wallace nach der Befreiung; Outfit-Prototyp, Zwangsprojekt, Hammer und Gouda für den Drachen. Hinter dem gemeinsamen Befreiungs-Auftakt 3071. Er ersetzt hier den Gefangenen mit Schalterindex 3 und damit dessen normalen Ratschlag 3069.

**Seite 1**

> Oh, hi, lad! Wallace hier. Schön, Dich
> wiederzusehen! Danke, daß Du mich
> befreit hast. Du bist ein schlaues
> Bürschchen.

**Seite 2**

> Ich sehe, Du trägst mein Outfit. Das
> war ursprünglich ein Prototyp, aber
> ich freue mich, daß er funktioniert!

**Seite 3**

> Die letzte Zeit war schrecklich für
> mich. Friedrich Merz hat mich hier
> festgehalten und gezwungen, Tag und
> Nacht an Projekt Atom-Donnerblume

**Seite 4**

> zu arbeiten.

**Seite 5**

> Es tut mir so leid, lad. Aber hätte
> ich mich geweigert, hätte er diesen
> furchtbaren Drachen auf die
> unschuldigen Bewohnerinnen und

**Seite 6**

> Bewohner Kakarikos gehetzt. Das
> konnte ich einfach nicht zulassen.

**Seite 7**

> Deswegen habe ich einen besonderen
> Hammer entwickelt. Merz fand das
> heraus und sperrte mich aus Zorn in
> diese Zelle.

**Seite 8**

> Bitte finde diesen Hammer. Ich selbst
> werde mich nun zu dem Drachen
> begeben und meinem Schicksal ins
> Auge blicken.

**Seite 9**

> Ich habe noch ein Stück Gouda in der
> Tasche. Vielleicht läßt sich die
> Drachendame damit besänftigen. Wir
> treffen uns dort, lad!

## 23. Wallace Hammer und Volvagia

### 0038

Projekttext.
Erhalt des bereits umbenannten Wallace Hammers.

**Seite 1**

> Der Wallace Hammer!
> Wallace hat ihn entwickelt.
> Mit [C] zerschlägst Du
> Objekte. Du brauchst beide

**Seite 2**

> Hände!

### 0621

Projekttext.
Navi-Zielerfassung von Volvagia; keine zusätzliche Boss-Begrüßung.

**Seite 1**

> Volvagia. Irgendein komischer Typ aus
> Kakariko steht auf diesen Drachen.
> Was stimmt mit dem nicht?

## 24. Halle der Weisen – Wallace und das Feueramulett

### 303C

Projekttext.
Wallace als Weise des Feuers nach dem Sieg über Volvagia.

**Seite 1**

> Oh, hi, lad! Das ging wohl ganz
> schön nach hinten los. Tja, Hochmut
> kommt vor dem Fall!

**Seite 2**

> Ich wollte den fürchterlichen Drachen
> mit einem Stück Gouda besänftigen.
> Liebe geht schließlich durch den
> Magen.

**Seite 3**

> Doch unsere Drachendame war wohl
> laktoseintolerant. Da hatten wir den
> Käse!

**Seite 4**

> Nicht einmal Wensleydale konnte mir
> diesmal das Leben retten. Gegen den
> Tod ist kein Käse gewachsen.

### 3045

Projekttext.
Wallaces längere Erklärung in der Halle der Weisen.

**Seite 1**

> Nun bin ich also der Weise des
> Feuers. Aus Schaden wird man klug,
> lad. Aus diesem leider erst nach dem
> Tod.

**Seite 2**

> Ich hoffe, Du gehst weiterhin Deinem
> Entdeckergeist nach und wirst nicht
> müde, Fragen zu stellen.

**Seite 3**

> Wer nicht fragt, bleibt dumm! Und
> wer rastet, der rostet. Das gilt auch
> für einen Forscher.

**Seite 4**

> Friedrich Merz hat ja das gesamte
> Forschungsgeld in Hyrule gekürzt. Da
> liegt der Hund begraben!

**Seite 5**

> Mit leeren Taschen ist schlecht
> forschen. Aber Not macht
> erfinderisch. Also machen wir weiter,
> lad!

### 3046

Projekttext.
Wallace kündigt die Übergabe des Feueramuletts an.

**Seite 1**

> Hier, lad! Das Feueramulett. Meine
> Kraft für Dich. Auf daß Du Merz
> ordentlich Feuer unter dem Hintern
> machst!

### 003C

Projekttext.

**Seite 1**

> Das Amulett des Feuers!
> Wallace, der Weise des
> Feuers, überträgt Dir seine
> Kraft!

### 303D

Projekttext.
Wallaces kurzer zeitgesteuerter Abschied über Gromit.
Zeitgesteuerte Textcodes: FADE(80). Die Werte sind nur dokumentiert, nicht geändert.

**Seite 1**

> Und wenn Du Gromit siehst, biete
> ihm ein Stück Käse an. Er ist ein
> braver Junge!

## 25. Nach dem Feuertempel – Goronia und Navis nächster Hinweis

### 3041

Projekttext.
Darunias Sohn nach dem Feueramulett: erste Ansprache, mit direkter Fortsetzung 3042. V22: Vater ist zurück; der Sohn fragt nach Wallace.
Direkte native Fortsetzung: 3042.

**Seite 1**

> Du hast es geschafft,
> [Spielername]! Der Drache wurde
> besiegt. Mein Vater ist auch zurück.
> Aber wo ist Wallace?

### 3042

Projekttext.
Nach dem Feueramulett: Wiederholung bzw. direkte Fortsetzung von 3041.

**Seite 1**

> Wenn ich groß bin, möchte ich
> genauso werden wie die großen
> Männer in meinem Leben, von denen
> ich gelernt habe.

**Seite 2**

> Mein Vater, das mutige Oberhaupt
> der Goronen. Du, [Spielername],
> der mutige Junge, der uns zweimal
> den steinigen Arsch gerettet hat. Und

**Seite 3**

> Wallace, ein Forscher, der sein Herz
> immer am rechten Fleck hatte.

### 3043

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Gemeinsame kurze Dankeszeile der betreffenden Goronen nach dem Feueramulett.

**Seite 1**

> Danke, [Spielername]!

### 0152

Projekttext.
Nächster freiwilliger Navi-Story-Hinweis nach dem Feueramulett, solange die Eisenstiefel fehlen. Keine zwingend automatisch bei Volvagias Tod laufende Textbox.

**Seite 1**

> So, alles klar. Schätze, als Nächstes
> müssen wir dann zu den Zoras.

**Seite 2**

> Da wird bestimmt alles in bester
> Ordnung sein. Ich wüßte nicht, warum
> dort irgendein Problem lauern sollte.

**Seite 3**

> Oder irgendeine Gefahr. Wir gehen da
> hin und kriegen dieses Amulett
> wahrscheinlich einfach direkt
> geschenkt.

**Seite 4**

> Ich glaube nicht, daß das in
> irgendeiner Form schiefgeht.

## Nebenhandlungen, Zusatzvarianten und Zielerfassung

## A. Optionale Windmühle beim Kakariko-Besuch – Regenlied

### 5034

Projekttext.
Optional schon bei diesem Besuch erreichbar. Für den Waldtempel nicht nötig; daher nur im Anhang.

**Seite 1**

> Auch nach sieben Jahren bin ich
> immer noch sowas von wütend. Ich
> stehe jeden Tag mit einem wütenden
> Gefühl auf und ziehe mir meine

**Seite 2**

> wütenden Schuhe an.

**Seite 3**

> Der hat meine ganze Mühle
> geschrottet. Das ist unfaßbar.

**Seite 4**

> Sag mal, wißt ihr eigentlich, wie
> teuer dieser ganze Schuppen hier
> gewesen ist?

### 5035

Projekttext.

**Seite 1**

> Ey, ich werde wahnsinnig. Das ist
> doch jetzt... Sag mir bitte nicht, daß
> das eine Okarina ist.

**Seite 2**

> Sag mir nicht, daß Du der Wichser
> von damals gewesen bist, sonst
> werde ich Dir so in die Fresse hauen.

**Seite 3**

> Irgendjemand hat damals diese
> absolut bescheuerte Regenmusik
> gespielt. Warum gibt es sowas
> überhaupt? Warum erlauben die

**Seite 4**

> Götter das?

**Seite 5**

> Ich erkläre Dir jetzt das Lied, einfach
> nur damit Du weißt, daß Du es auf
> keinen Fall spielen sollst. Jetzt ist es
> sowieso zu spät.

**Seite 6**

> Gott sei Dank hast Du keine
> Zeitmaschine oder so.

### 508E

Projekttext.

**Seite 1**

> Oh nein, das war ein Fehler!

### 00D6

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Du hast die
> Hymne des Sturms
> erlernt!

## B. Gemeinsame Okarina-Bedienung bei Salias Lied

### 00E0

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Gemeinsame Okarina-Abfrage; nicht bei jedem Anruf zusätzlich angezeigt.

**Seite 1**

> Willst Du mit Salia sprechen?
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 00E1

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Gemeinsame Okarina-Abfrage; nicht bei jedem Anruf zusätzlich angezeigt.

**Seite 1**

> Willst Du dann mit mir sprechen? 
>
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

## C. Fado – optionale erwachsene Tauschquest, unabhängig vom Waldtempel

### 10B7

Projekttext.
Direkte native Fortsetzung: 10B8.

**Seite 1**

> Keine Sorge, ich habe dem Typen
> gezeigt, wie man hier aus dem Wald
> rauskommt. Also dem wird's schon
> gut gehen. Oder warte, ich glaube,

**Seite 2**

> ich habe ihm... Oh nein. Ich habe ihm
> die falsche Richtung gesagt. Ach,
> wird schon passen.

### 10B8

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Die Medizin besteht aus 
> Waldpilzen! Gib sie mir! 
> Ja!
> Nein!

_Auswahlantworten in ihrer tatsächlichen Reihenfolge stehen auf dieser Seite._

### 10B9

Projekttext.
 Kokiri-Typ CHILD_FADO; Auswahl abhängig vom Waldamulett und ggf. der jeweiligen Ansprache-Markierung. Keine fortlaufende Gesamtrede aller hier aufgelisteten Bewohner.

**Seite 1**

> Wenn Du dem Typen begegnest, dann
> warne ihn vor dem Waldmonster.

### 10BA

Projekttext.

**Seite 1**

> Schilde haben wir. Schwerter nicht.
> Für Streit bitte an Mido wenden.

### 10DF

Projekttext.

**Seite 1**

> Keine Sorge, ich habe dem Typen
> gezeigt, wie man hier aus dem Wald
> rauskommt. Also dem wird's schon
> gut gehen. Oder warte, ich glaube,

**Seite 2**

> ich habe ihm... Oh nein. Ich habe ihm
> die falsche Richtung gesagt. Ach,
> wird schon passen.

## D. Gemeinsame Dungeon-Fundtexte

### 0067

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Der Kompaß!
> Jetzt siehst Du auf Deiner
> Karte alle Schatztruhen
> dieses Labyrinths!

### 0066

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Die Labyrinth-Karte!
> Drücke START, um sie im
> Karten-Bildschirm anzusehen!

**Seite 2**

> Blaue Räume hast Du bereits
> aufgesucht.
> Der blinkende Raum zeigt
> Deine derzeitige Position.

**Seite 3**

> Bewege [Control-Pad], um ein
> Stockwerk auszuwählen.

### 0060

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.

**Seite 1**

> Ein kleiner Schlüssel!
> Er öffnet eine verschlossene
> Tür. Du kannst ihn nur in
> diesem Labyrinth einsetzen.

## E. Kakariko – der Volvagia-Verehrer

### 5086

Projekttext.
Optionaler Kakariko-NPC mit dem Drachen-Gag; unabhängig vom exakten Tempelfortschritt.

**Seite 1**

> Ist Dir schon mal aufgefallen, daß der
> Drache im Feuertempel irgendwie echt
> attraktiv ist?

**Seite 2**

> Was? Nein?! Ähh... Mir auch nicht!
> Wer denkt denn so was?

**Seite 3**

> Mega komisch einfach. Ich hab
> überhaupt keinen bestimmten Drachen
> gemeint.

**Seite 4**

> Volvagia heißt der übrigens. Also hab
> ich gehört. Zufällig.

## F. Gespeicherte Zusatztexte – keine regulären Stationen dieser deutschen Hauptgeschichte

### 303A

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Gespeicherter Zusatztext. Kein direkter Aufruf in der aktuellen Darunia-Begegnung oder Feuerweisen-Cutscene nachgewiesen; nicht als reguläre Szene auffassen.

**Seite 1**

> Ich bin gerettet!
> Hab Dank!
> Bitte, nimm dies!

### 303B

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Gespeicherter Zusatztext. Kein direkter Aufruf in der aktuellen Darunia-Begegnung oder Feuerweisen-Cutscene nachgewiesen; nicht als reguläre Szene auffassen.

**Seite 1**

> [Spielername]... Schnell... 
> Ich kann die Last nicht
> länger tragen...

**Seite 2**

> Raus hier!

### 303F

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Gespeicherte Abschiedsvariante. Die aktuelle Bolero-Cutscene verwendet stattdessen 106D.

**Seite 1**

> [Spielername]... Bis bald...

### 3069

Vorhandener Originaltext ohne eigenen Kapitel-Ersatz.
Normaler Ratschlag des Gefangenen mit Schalterindex 3. In der deutschen Erwachsenenfassung ist dieser Gefangene Wallace und sagt stattdessen 209D. Nur zur Übersicht als gespeicherte Alternative enthalten.

**Seite 1**

> Da Du mich befreit hast, verrate
> ich Dir ein Geheimnis!

**Seite 2**

> In diesem Tempel gibt es Türen,
> die Dich beim Versuch, sie zu 
> öffnen, erschlagen! Sei gewarnt!

**Seite 3**

> Besitzt Du das Relikt der Goronen,
> kannst Du sie zerschmettern!


from pathlib import Path
import sys,re,json,hashlib,zipfile,io
W=Path(__file__).resolve().parent;R=Path('/workspace/Projekt-Merzen-der-Bauer');O=Path('/workspace/oot-burns-pal')
sys.path.insert(0,str(R/'tools'))
from build_story import messages,split_pages,LEX,controls
src=(O/'extracted/pal-1.0/text/message_data.h').read_text();ms=messages(src)
sections=[]
def section(title,desc,entries):sections.append((title,desc,entries))
def ids(s):return s.split()
# Stable actor variants; explicitly include choices, not just initial messages.
child=[('Fado','10D7 10D8 10D9 10DA'),('Kokiri 0','1004 1042 1025'),('Kokiri 1','1005 1006 1043 1023'),('Kokiri 2','1007 1022'),('Kokiri 3','1008 1009 1044 1021'),('Kokiri 4','100A 100B 1042 1097'),('Kokiri 5','100C 100D 1043 10B0'),('Kokiri 6','100E 1019 1043 10B5'),('Kokiri 7 – Auswahl','1035 1036 1037'),('Kokiri 8 – Auswahl','1038 1039 103A 103B'),('Kokiri 9','103C 104B'),('Kokiri 10','103D 104C'),('Kokiri 11 – Auswahl','103E 103F 1040')]
adult=[('Fado – Tauschgeschäft im Wald','10B7 10B8 10B9 10BA 10DF'),('Kokiri 0','1055 1056 1072'),('Kokiri 1','105A 1073'),('Kokiri 2','105D 105E 1074'),('Kokiri 3','105B 1075'),('Kokiri 4','105F 1076'),('Kokiri 5 – Ladenbereich','1057'),('Kokiri 6','1058 1059 1077'),('Kokiri 7','104E 1079'),('Kokiri 8','104F 1050 107A'),('Kokiri 9','1051 107B'),('Kokiri 10','1052 107C'),('Kokiri 11','1053 1054 107C')]
section('Kind – Mido','Im Wald und in seinem Haus; abhängig von Ausrüstung, Gesprächsfortschritt, Smaragd und Zeldas Brief.', [('Mido',ids('102F 1030 1033 1034 1045 1046 1028'))])
section('Kind – Salia','Begrüßung, Gespräche im Wald und Haus, Abschied an der Brücke und Salias Lied. Erfasst auch die jeweiligen Fortsetzungen und Antwortzweige.', [('Salia',ids('1001 1002 1003 1010 1031 1032 1047 1048 1011 1094 1012 1013 1014 10A8 10AA 10AB 10AC 10AD'))])
section('Kind – übrige Kokiri','Die Nummern entsprechen den festen EnKo-Typen im Code, nicht einer Sprechreihenfolge. Pro Figur stehen zunächst die frühen Texte, danach die Varianten nach dem Deku-Baum und nach Zeldas Brief. Nicht jeder Typ hat für jeden Zustand einen eigenen Text.',[(n,ids(s))for n,s in child])
section('Kind – minzgrüner Kokiri','Erstes Gespräch mit Freischaltung der Laufmagie, Wiederholung und Abschluss der Magieanimation.', [('Minzgrüner Kokiri',ids('7231 7232 7233'))])
section('Erwachsen – Mido','Verlorene Wälder: vor dem Lied, nach dem Vorspielen und nach Abschluss des Waldtempels.', [('Mido',ids('1060 1061 1067 1068 1070 1071'))])
section('Erwachsen – übrige Kokiri','Die letzten 107x-Varianten gelten nach Erhalt des Wald-Amuletts. Die übrigen 104x/105x-Nachrichten gehören zum Zustand davor; einzelne Figuren haben einen eigenen Wiederholungstext.',[(n,ids(s))for n,s in adult])
section('Erwachsen – minzgrüner Kokiri','7235: vor dem Waldtempel im Kokiri-Wald. 7238: nach dem Waldtempel draußen am Waldeingang auf der Hyrule-Steppe.', [('Minzgrüner Kokiri',ids('7235 7238'))])
# Shop NPC speech and all item descriptions/purchase outcomes actually used by the Kokiri inventory.
shop=(O/'src/overlays/actors/ovl_En_Ossan/z_en_ossan.c').read_text()
item=(O/'src/overlays/actors/ovl_En_GirlA/z_en_girla.c').read_text()
section('Beide Zeitebenen – Kokiri-Laden','Gemeinsame Begrüßung und Gesprächsoption des Ladenbesitzers. 10BA wird außerdem von Fado beim Tausch verwendet; dieselbe ID ist kein zusätzlicher Dialog.', [('Ladenbesitzer',ids('009E 10BA'))])
# Actual German reaction table; native default rows are not used for German.
masknames=['Fuchs-/Pikachu-Maske','Schädel-Maske','Geister-Maske','Hasenohren','Goronen-Maske','Zora-Maske','Gerudo-Maske','Maske des Wissens']
maskrows={'Salia':'7104 710E 7127 7134 714D 7151 011E 7166','Mido':'7105 710F 7128 7135 714E 7152 014F 7167','Fado':'7106 7110 712A 7136 713C 7153 0159 7168','Kokiri-Gruppe 1 (Typen 0, 2, 3, 4, 7, 8, 11)':'7107 7111 712B 7137 713D 7154 015D 716A','Kokiri-Gruppe 2 (Typen 1, 5, 6, 9, 10)':'7108 7112 712C 7138 713E 7155 015E 716B'}
for who,s in maskrows.items():section('Maskenreaktionen – '+who,'Deutsche Zuordnung aus dem aktuellen Code; Reaktionen ersetzen das normale Gespräch, solange die jeweilige Maske getragen wird.',[(m,[i])for m,i in zip(masknames,ids(s))])
section('Besondere Maskenreaktion – Kokiri 3','Maske des Wissens als Kind: dieser Text hat Vorrang vor der normalen Gruppenreaktion.', [('Gedankenlesen',ids('7163'))])
section('Salias Lied – Fernkontakt als Kind','Fortschrittsabhängige Antworten über die Okarina, inklusive direkter Nähe zu Salia.', [('Salia',ids('0160 0161 0162 0163 0164 0165 0166 0167 0168 0169'))])
section('Salias Lied – Fernkontakt als Erwachsener','Fortschrittsabhängige Antworten über die Okarina; diese Hinweise sind keine reguläre Salia-Figur im Wald.', [('Salia',ids('016A 016B 016C 016D'))])
section('Anhang – Waren und Kauftexte des Kokiri-Ladens','Beschreibungen und Auswahltexte der acht dort angebotenen Waren; allgemeine Kaufmeldungen werden auch in anderen Läden verwendet.', [('Laden und Kaufabwicklung',ids('0083 0084 0085 0086')),('Deku-Schild',ids('009F 0089')),('Deku-Nüsse (5)',ids('00B2 007F')),('Deku-Nüsse (10)',ids('00A2 0087')),('Deku-Stab',ids('00A1 0088')),('Deku-Kerne (30)',ids('00DF 00DE')),('Pfeile (10)',ids('00A0 008A')),('Pfeile (30)',ids('00C1 009B')),('Herz',ids('00AC 0095'))])
# Forest sidecast clearly separated because requested NPC category is Kokiri.
section('Anhang – Triple T im Kokiri-Wald (erwachsen)','Kein Kokiri, aber für den aktuellen Waldabschnitt relevant. Rückblick, Auftrag und spätere Wiederholung.', [('Tung Tung Tung Sahur',ids('1062 1063 1064 1065 1066 1078'))])

def decode(body):
 out=''
 for m in LEX.finditer(body):
  t=m.group()
  if t.startswith('"'):out+=json.loads(t)
  elif t=='NAME':out+='[Spielername]'
  elif t=='TIME':out+='[Uhrzeit]'
  elif t.startswith('HIGHSCORE('):out+='[Bestzeit]'
  elif t=='TOKENS':out+='[Skulltulas]'
  elif t=='POINTS':out+='[Punkte]'
 return out
records=[];lines=['# Aktuelle Kokiri-Dialoge – Kind und Erwachsen (V95)','', 'Direkt aus dem aktuellen deutschen Spieltext und den Actor-Zuordnungen exportiert. Texte und Seitenumbrüche werden hier nur gezeigt, nicht umgeschrieben. `[Spielername]` ist der variable Spielstandname. Die einzelnen Bildschirmzeilen sind zu lesbaren Absätzen verbunden; **Seite** entspricht weiterhin einer echten Textbox-Seite.','', 'Enthalten: Mido, Salia, Fado, sämtliche normalen Kokiri-Typen, der neue minzgrüne Kokiri, der Ladenbesitzer und alle deutschen Maskenreaktionen. Triple T steht separat im Anhang. Salia ist als Erwachsene nicht als normal ansprechbare Figur im Wald vorhanden. Mehrere Zustände können dieselbe Text-ID verwenden.','']
for title,desc,entries in sections:
 lines+=['## '+title,'',desc,''];seen=set()
 for speaker,startids in entries:
  lines+=['### '+speaker,''];queue=list(startids)
  while queue:
   ident=queue.pop(0)
   if ident in seen:
    lines+=['Text **'+ident+'**: siehe oben in diesem Abschnitt.',''];continue
   seen.add(ident);assert ident in ms,ident
   body=ms[ident]['parts'][2][2];pages,seps=split_pages(body);ct=controls(body)
   lines+=['#### '+ident,'','Aktuell eingebauter Text.','']
   timing=[x for x in ct if x.startswith(('FADE','BOX_BREAK_DELAYED'))]
   if timing:lines+=['Zeit-/Geschwindigkeitssteuerung: '+', '.join(timing)+'.','']
   pp=[]
   for n,page in enumerate(pages,1):
    t=decode(page);pp.append(t)
    lines+=['**Seite '+str(n)+'**','']
    # Keep choice options as separate lines to avoid obscuring answer branches.
    if 'CHOICE' in page:
     for ln in t.splitlines():lines+=['> '+ln]
    else:lines+=['> '+' '.join(t.splitlines())]
    lines+=['']
   follow=re.findall(r'TEXTID\("\\x([0-9A-Fa-f]{2})\\x([0-9A-Fa-f]{2})"\)',body)
   nextids=[''.join(x).upper() for x in follow]+[f'{int(x,16):04X}' for x in re.findall(r'TEXTID\(0x([0-9A-Fa-f]+)\)',body)]
   if nextids:lines+=['Fortsetzung: '+', '.join('**'+x+'**'for x in nextids)+'.',''];queue=nextids+queue
   choices=[x for x in ct if x in ('TWO_CHOICE','THREE_CHOICE')]
   if choices:lines+=['Auswahl: '+', '.join(choices)+'.','']
   records.append(dict(section=title,speaker=speaker,id=ident,pages=pp,controls=ct,continuations=nextids))
md='\n'.join(lines);stem='Dialogliste_Kokiri_Kind_und_Erwachsen_V95';files={stem+'.md':md.encode(),stem+'.txt':md.encode(),stem+'.json':json.dumps(records,ensure_ascii=False,indent=2).encode()}
for name,data in files.items():(W/name).write_bytes(data)
(R/'planning'/ (stem+'.md')).write_text(md)
(W/'export-summary.json').write_text(json.dumps(dict(entries=len(records),unique_messages=len({x['id']for x in records}),pages=sum(len(x['pages'])for x in records),source_sha256=hashlib.sha256(src.encode()).hexdigest()),indent=2))
print((W/'export-summary.json').read_text())
